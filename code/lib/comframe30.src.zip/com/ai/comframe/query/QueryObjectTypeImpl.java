/*   */ package com.ai.comframe.query;
/*   */ 
/*   */ import com.ai.appframe2.bo.impl.DefaultObjectType;
/*   */ 
/*   */ public class QueryObjectTypeImpl extends DefaultObjectType
/*   */ {
/*   */   public void setMapingEnty(String sql)
/*   */   {
/* 7 */     this.m_mapingEntyType = "sql";
/* 8 */     this.m_tableName = sql;
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.query.QueryObjectTypeImpl
 * JD-Core Version:    0.5.4
 */