/*     */ package com.ai.comframe.query;
/*     */ 
/*     */ import com.ai.comframe.client.TaskInfo;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.utils.TableAssembleUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.QBOVmTaskInfoBean;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IQBOVmTaskInfoValue;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class TaskInfoHelper
/*     */ {
/*  38 */   public static HashMap m_flow_attrs = new HashMap();
/*     */ 
/*  42 */   public static HashMap m_task_attrs = new HashMap();
/*     */ 
/*  46 */   public static String TABLE_TASK = "{VM_TASK}";
/*     */ 
/*  50 */   public static String TABLE_TASK_TS = "{VM_TASK_TS}";
/*     */ 
/*  54 */   public static String TABLE_FLOW = "{VM_WF}";
/*     */ 
/*  58 */   public static String H_TABLE_TASK = "{H_VM_TASK}";
/*     */ 
/*  62 */   public static String H_TABLE_TASK_TS = "{H_VM_TASK_TS}";
/*     */ 
/*  66 */   public static String H_TABLE_FLOW = "{H_VM_WF}";
/*     */ 
/*  68 */   public static String PREFIX_TASK = "TASK";
/*  69 */   public static String PREFIX_FLOW = "FLOW";
/*     */ 
/*     */   public static int getCount(ResultSet result) {
/*  72 */     int ret = 0;
/*     */     try {
/*  74 */       while (result.next())
/*  75 */         ret = result.getInt("COUNT");
/*     */     }
/*     */     catch (SQLException e) {
/*  78 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  81 */     return ret;
/*     */   }
/*     */ 
/*     */   public static IQBOVmTaskInfoValue[] transerToQvalue(TaskInfo[] info) throws Exception {
/*  85 */     List taskList = new ArrayList();
/*     */     try {
/*  87 */       for (int i = 0; i < info.length; ++i) {
/*  88 */         IQBOVmTaskInfoValue vmTaskInfo = new QBOVmTaskInfoBean();
/*  89 */         vmTaskInfo.setChildWorkflowCount(info[i].getChildWorkflowCount());
/*  90 */         vmTaskInfo.setCreateDate(new Timestamp(info[i].getCreateDate().getTime()));
/*  91 */         vmTaskInfo.setDecisionResult(info[i].getDecisionResult());
/*  92 */         vmTaskInfo.setDescription(info[i].getDescription());
/*  93 */         vmTaskInfo.setDuration(info[i].getDuration());
/*  94 */         vmTaskInfo.setErrorMessage(info[i].getErrorMessage());
/*     */ 
/*  96 */         vmTaskInfo.setFinishStaffId(info[i].getFinishStaffId());
/*  97 */         vmTaskInfo.setIsCurrentTask(info[i].getIsCurrentTask());
/*  98 */         vmTaskInfo.setLabel(info[i].getLabel());
/*  99 */         vmTaskInfo.setLastTaskId(info[i].getLastTaskId());
/*     */ 
/* 101 */         vmTaskInfo.setLockStaffId(info[i].getLockStaffId());
/* 102 */         vmTaskInfo.setParentTaskId(info[i].getParentTaskId());
/* 103 */         vmTaskInfo.setQueueId(info[i].getQueueId());
/* 104 */         vmTaskInfo.setState(info[i].getState());
/* 105 */         vmTaskInfo.setStateDate(new Timestamp(info[i].getStateDate().getTime()));
/* 106 */         vmTaskInfo.setStationId(info[i].getStationId());
/* 107 */         vmTaskInfo.setTaskBaseType(info[i].getTaskBasetype());
/* 108 */         vmTaskInfo.setTaskId(info[i].getTaskId());
/* 109 */         vmTaskInfo.setTaskStaffId(info[i].getTaskStaffId());
/* 110 */         vmTaskInfo.setTaskTag(info[i].getTaskTag());
/* 111 */         vmTaskInfo.setTaskTemplateId(info[i].getTaskTemplateId());
/* 112 */         vmTaskInfo.setTaskType(info[i].getTasktype());
/* 113 */         vmTaskInfo.setTemplateVersionId(info[i].getWorkflowTaskTemplateId());
/* 114 */         vmTaskInfo.setTemplateTag(info[i].getWorkflowCode());
/*     */ 
/* 116 */         vmTaskInfo.setWarningTimes(info[i].getWarningTimes());
/* 117 */         vmTaskInfo.setWorkflowId(info[i].getWorkflowId());
/* 118 */         vmTaskInfo.setWorkflowName(info[i].getWorkflowName());
/* 119 */         vmTaskInfo.setWorkflowObjectId(info[i].getWorkflowObjectId());
/* 120 */         vmTaskInfo.setWorkflowObjectType(info[i].getWorkflowObjectType());
/* 121 */         vmTaskInfo.setWorkflowState(info[i].getWorkflowState());
/* 122 */         vmTaskInfo.setRegionId(info[i].getRegionId());
/* 123 */         taskList.add(vmTaskInfo);
/*     */       }
/*     */     } catch (Exception e) {
/* 126 */       e.printStackTrace();
/*     */     }
/* 128 */     return (IQBOVmTaskInfoValue[])(IQBOVmTaskInfoValue[])taskList.toArray(new IQBOVmTaskInfoValue[0]);
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskValue[] transerToValue(ResultSet result) throws Exception {
/* 132 */     List taskList = new ArrayList();
/*     */     try {
/* 134 */       while (result.next()) {
/* 135 */         IBOVmTaskValue info = new BOVmTaskBean();
/* 136 */         info.setDecisionResult(result.getString("DECISION_RESULT"));
/* 137 */         info.setDescription(result.getString("DESCRIPTION"));
/* 138 */         info.setErrorMessage(result.getString("ERROR_MESSAGE"));
/* 139 */         info.setFinishStaffId(result.getString("FINISH_STAFF_ID"));
/* 140 */         info.setIsCurrentTask(result.getString("IS_CURRENT_TASK"));
/* 141 */         info.setLabel(result.getString("LABEL"));
/* 142 */         info.setLastTaskId(result.getString("LAST_TASK_ID"));
/* 143 */         info.setLockStaffId(result.getString("LOCK_STAFF_ID"));
/* 144 */         info.setQueueId(result.getString("QUEUE_ID"));
/* 145 */         info.setState(result.getInt("STATE"));
/* 146 */         info.setStationId(result.getString("STATION_ID"));
/* 147 */         info.setTaskId(result.getString("TASK_ID"));
/* 148 */         info.setTaskStaffId(result.getString("TASK_STAFF_ID"));
/* 149 */         info.setTaskTag(result.getString("TASK_TAG"));
/* 150 */         info.setTaskTemplateId(result.getLong("TASK_TEMPLATE_ID"));
/* 151 */         info.setWarningTimes(result.getInt("WARNING_TIMES"));
/* 152 */         info.setWorkflowId(result.getString("WORKFLOW_ID"));
/* 153 */         info.setChildWorkflowCount(result.getLong("CHILD_WORKFLOW_COUNT"));
/* 154 */         info.setRegionId(result.getString("REGION_ID"));
/* 155 */         taskList.add(info);
/*     */       }
/*     */     } catch (SQLException e) {
/* 158 */       e.printStackTrace();
/*     */     }
/* 160 */     return (IBOVmTaskValue[])(IBOVmTaskValue[])taskList.toArray(new IBOVmTaskValue[0]);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] transer(ResultSet result)
/*     */   {
/* 169 */     List taskList = new ArrayList();
/*     */     try {
/* 171 */       while (result.next()) {
/* 172 */         TaskInfo info = new TaskInfo();
/* 173 */         info.setCreateDate(result.getTimestamp("CREATE_DATE"));
/* 174 */         info.setDecisionResult(result.getString("DECISION_RESULT"));
/* 175 */         info.setDescription(result.getString("DESCRIPTION"));
/* 176 */         info.setErrorMessage(result.getString("ERROR_MESSAGE"));
/* 177 */         info.setFinishDate(result.getTimestamp("FINISH_DATE"));
/* 178 */         info.setFinishStaffId(result.getString("FINISH_STAFF_ID"));
/* 179 */         info.setIsCurrentTask(result.getString("IS_CURRENT_TASK"));
/* 180 */         info.setWorkflowKind(result.getInt("WORKFLOW_KIND"));
/* 181 */         info.setLabel(result.getString("LABEL"));
/* 182 */         info.setLastTaskId(result.getString("LAST_TASK_ID"));
/* 183 */         info.setLockDate(result.getTimestamp("LOCK_DATE"));
/* 184 */         info.setLockStaffId(result.getString("LOCK_STAFF_ID"));
/* 185 */         info.setParentTaskId(result.getString("PARENT_TASK_ID"));
/* 186 */         info.setQueueId(result.getString("QUEUE_ID"));
/* 187 */         info.setState(result.getInt("STATE"));
/* 188 */         info.setStateDate(result.getTimestamp("STATE_DATE"));
/* 189 */         info.setStationId(result.getString("STATION_ID"));
/* 190 */         info.setTaskBasetype(result.getString("TASK_BASE_TYPE"));
/* 191 */         info.setTaskId(result.getString("TASK_ID"));
/* 192 */         info.setTaskStaffId(result.getString("TASK_STAFF_ID"));
/* 193 */         info.setTaskTag(result.getString("TASK_TAG"));
/* 194 */         info.setTaskTemplateId(result.getLong("TASK_TEMPLATE_ID"));
/* 195 */         info.setTasktype(result.getString("TASK_TYPE"));
/* 196 */         info.setWarningDate(result.getTimestamp("WARNING_DATE"));
/* 197 */         info.setWarningTimes(result.getInt("WARNING_TIMES"));
/* 198 */         info.setWorkflowCode(result.getString("WORKFLOW_CODE"));
/* 199 */         info.setWorkflowCreateDate(result.getTimestamp("WORKFLOW_CREATE_DATE"));
/* 200 */         info.setWorkflowCreateStaffId(result.getString("WORKFLOW_CREATE_STAFF_ID"));
/* 201 */         info.setWorkflowDuration(result.getLong("WORKFLOW_DURATION"));
/* 202 */         info.setWorkflowErrorMessage(result.getString("WORKFLOW_ERROR_MESSAGE"));
/* 203 */         info.setWorkflowId(result.getString("WORKFLOW_ID"));
/* 204 */         info.setWorkflowName(result.getString("WORKFLOW_NAME"));
/* 205 */         info.setWorkflowObjectId(result.getString("WORKFLOW_OBJECT_ID"));
/* 206 */         info.setWorkflowObjectType(result.getString("WORKFLOW_OBJECT_TYPE"));
/* 207 */         info.setWorkflowParentTaskId(result.getString("WORKFLOW_PARENT_TASK_ID"));
/* 208 */         info.setWorkflowState(result.getInt("WORKFLOW_STATE"));
/* 209 */         info.setWorkflowTaskTemplateId(result.getLong("WORKFLOW_TASK_TEMPLATE_ID"));
/* 210 */         info.setWorkflowWarningDate(result.getTimestamp("WORKFLOW_WARNING_DATE"));
/* 211 */         info.setWorkflowWarningTimes(result.getInt("WORKFLOW_WARNING_TIMES"));
/* 212 */         info.setRegionId(result.getString("REGION_ID"));
/*     */ 
/* 214 */         taskList.add(info);
/*     */       }
/*     */     } catch (SQLException e) {
/* 217 */       e.printStackTrace();
/*     */     }
/* 219 */     return (TaskInfo[])(TaskInfo[])taskList.toArray(new TaskInfo[0]);
/*     */   }
/*     */ 
/*     */   public static String createSQLAllTask(AssembleDef def)
/*     */     throws Exception
/*     */   {
/* 243 */     List unionSqls = new ArrayList();
/* 244 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK, def);
/* 245 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 246 */     String taskTS = TableAssembleUtil.getTableName(TABLE_TASK_TS, def);
/* 247 */     String sqlTask = createSQL(taskTb, flowTb);
/* 248 */     String sqlTaskTS = createSQL(taskTS, flowTb);
/* 249 */     unionSqls.add(sqlTask);
/* 250 */     unionSqls.add(sqlTaskTS);
/* 251 */     return createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisAllTask(AssembleDef def, String[] date) throws Exception {
/* 255 */     List unionSqls = new ArrayList();
/* 256 */     if ((date != null) && (date.length > 0)) {
/* 257 */       for (int i = 0; i < date.length; ++i) {
/* 258 */         def.setSdate(date[i]);
/* 259 */         String taskHTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK, def);
/* 260 */         String flowHTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 261 */         String taskTSHTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK_TS, def);
/* 262 */         String hisTask = createSQL(taskHTb, flowHTb);
/* 263 */         String hisTaskTS = createSQL(taskTSHTb, flowHTb);
/* 264 */         unionSqls.add(hisTask);
/* 265 */         unionSqls.add(hisTaskTS);
/*     */       }
/*     */     }
/* 268 */     return createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLAllTaskCount(AssembleDef def)
/*     */     throws Exception
/*     */   {
/* 292 */     List unionSqls = new ArrayList();
/* 293 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK, def);
/* 294 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 295 */     String taskTS = TableAssembleUtil.getTableName(TABLE_TASK_TS, def);
/* 296 */     unionSqls.add(createSQL(taskTb, flowTb));
/* 297 */     unionSqls.add(createSQL(taskTS, flowTb));
/* 298 */     return createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisAllTaskCount(AssembleDef def, String[] date) throws Exception {
/* 302 */     List unionSqls = new ArrayList();
/* 303 */     if ((date != null) && (date.length > 0)) {
/* 304 */       for (int i = 0; i < date.length; ++i) {
/* 305 */         def.setSdate(date[i]);
/* 306 */         String taskHTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK, def);
/* 307 */         String flowHTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 308 */         String taskTSHTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK_TS, def);
/* 309 */         String hisTask = createSQL(taskHTb, flowHTb);
/* 310 */         String hisTaskTS = createSQL(taskTSHTb, flowHTb);
/* 311 */         unionSqls.add(hisTask);
/* 312 */         unionSqls.add(hisTaskTS);
/*     */       }
/*     */     }
/* 315 */     return createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   public static String createQueryResult(List querySql, boolean onlyCount) throws Exception {
/* 319 */     StringBuffer sql = new StringBuffer();
/* 320 */     if (onlyCount)
/* 321 */       sql.append("SELECT count(1) as ").append("COUNT").append(" FROM ( ");
/*     */     else {
/* 323 */       sql.append("SELECT * FROM (");
/*     */     }
/* 325 */     sql.append(unionQuery(querySql)).append(" ) TASK_VIEW ");
/* 326 */     return sql.toString();
/*     */   }
/*     */ 
/*     */   private static String unionQuery(List querySql) throws Exception {
/* 330 */     StringBuffer sql = new StringBuffer();
/* 331 */     if ((querySql == null) || (querySql.size() == 0)) {
/* 332 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.query.TaskInfoHelper_unionSql"));
/*     */     }
/* 334 */     for (int i = 0; i < querySql.size(); ++i) {
/* 335 */       String tmpSql = String.valueOf(querySql.get(i));
/* 336 */       if (i == 0)
/* 337 */         sql.append(tmpSql);
/*     */       else {
/* 339 */         sql.append(" union all ").append(tmpSql);
/*     */       }
/*     */     }
/* 342 */     return sql.toString();
/*     */   }
/*     */ 
/*     */   public static String createSQLTask(AssembleDef def)
/*     */     throws Exception
/*     */   {
/* 348 */     List unionSql = new ArrayList();
/* 349 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK, def);
/* 350 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 351 */     String tmpSql = createSQL(taskTb, flowTb);
/* 352 */     unionSql.add(tmpSql);
/* 353 */     return createQueryResult(unionSql, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLTaskTS(AssembleDef def) throws Exception {
/* 357 */     List unionSql = new ArrayList();
/* 358 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK_TS, def);
/* 359 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 360 */     String tmpSql = createSQL(taskTb, flowTb);
/* 361 */     unionSql.add(tmpSql);
/* 362 */     return createQueryResult(unionSql, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisTask(AssembleDef def, String[] date) throws Exception {
/* 366 */     List unionSqls = new ArrayList();
/* 367 */     for (int i = 0; i < date.length; ++i) {
/* 368 */       def.setSdate(date[i]);
/* 369 */       String taskTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK, def);
/* 370 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 371 */       String tmpSql = createSQL(taskTb, flowTb);
/* 372 */       if (!unionSqls.contains(tmpSql)) {
/* 373 */         unionSqls.add(tmpSql);
/*     */       }
/*     */     }
/* 376 */     return createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisTaskTS(AssembleDef def, String[] date) throws Exception {
/* 380 */     List unionSqls = new ArrayList();
/* 381 */     for (int i = 0; i < date.length; ++i) {
/* 382 */       def.setSdate(date[i]);
/* 383 */       String taskTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK_TS, def);
/* 384 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 385 */       String tmpSql = createSQL(taskTb, flowTb);
/* 386 */       if (!unionSqls.contains(tmpSql)) {
/* 387 */         unionSqls.add(tmpSql);
/*     */       }
/*     */     }
/* 390 */     return createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLTaskCount(AssembleDef def) throws Exception {
/* 394 */     List unionSql = new ArrayList();
/* 395 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK, def);
/* 396 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 397 */     String tmpSql = createSQL(taskTb, flowTb);
/* 398 */     unionSql.add(tmpSql);
/* 399 */     return createQueryResult(unionSql, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLTaskTSCount(AssembleDef def) throws Exception {
/* 403 */     List unionSql = new ArrayList();
/* 404 */     String taskTb = TableAssembleUtil.getTableName(TABLE_TASK_TS, def);
/* 405 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 406 */     String tmpSql = createSQL(taskTb, flowTb);
/* 407 */     unionSql.add(tmpSql);
/* 408 */     return createQueryResult(unionSql, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisTaskCount(AssembleDef def, String[] date) throws Exception {
/* 412 */     List unionSqls = new ArrayList();
/* 413 */     for (int i = 0; i < date.length; ++i) {
/* 414 */       def.setSdate(date[i]);
/* 415 */       String taskTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK, def);
/* 416 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 417 */       String tmpSql = createSQL(taskTb, flowTb);
/* 418 */       if (!unionSqls.contains(tmpSql)) {
/* 419 */         unionSqls.add(tmpSql);
/*     */       }
/*     */     }
/* 422 */     return createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLHisTaskTSCount(AssembleDef def, String[] date) throws Exception {
/* 426 */     List unionSqls = new ArrayList();
/* 427 */     for (int i = 0; i < date.length; ++i) {
/* 428 */       def.setSdate(date[i]);
/* 429 */       String taskTb = TableAssembleUtil.getHisTableName(H_TABLE_TASK_TS, def);
/* 430 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 431 */       String tmpSql = createSQL(taskTb, flowTb);
/* 432 */       if (!unionSqls.contains(tmpSql)) {
/* 433 */         unionSqls.add(tmpSql);
/*     */       }
/*     */     }
/* 436 */     return createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   private static String createSQL(String taskTb, String flowTb)
/*     */   {
/* 441 */     StringBuffer bf = new StringBuffer();
/* 442 */     bf.append("SELECT ");
/* 443 */     Iterator itTask = m_task_attrs.entrySet().iterator();
/* 444 */     String key = ""; String value = "";
/* 445 */     while (itTask.hasNext()) {
/* 446 */       Map.Entry entry = (Map.Entry)itTask.next();
/* 447 */       key = (String)entry.getKey();
/* 448 */       value = (String)entry.getValue();
/* 449 */       if ((taskTb.indexOf("TS") == -1) && (key.equals("PARENT_TASK_ID")))
/* 450 */         bf.append("'-1'");
/* 451 */       else if ((taskTb.indexOf("TS") > -1) && (key.equals("LAST_TASK_ID")))
/* 452 */         bf.append("'-1'");
/*     */       else {
/* 454 */         bf.append(PREFIX_TASK).append(".").append(value);
/*     */       }
/* 456 */       bf.append(" AS ").append(key).append(",");
/*     */     }
/* 458 */     Iterator itFlow = m_flow_attrs.entrySet().iterator();
/* 459 */     while (itFlow.hasNext()) {
/* 460 */       Map.Entry entry = (Map.Entry)itFlow.next();
/* 461 */       key = (String)entry.getKey();
/* 462 */       value = (String)entry.getValue();
/* 463 */       bf.append(PREFIX_FLOW).append(".").append(value);
/* 464 */       bf.append(" AS ").append(key).append(",");
/*     */     }
/* 466 */     bf.delete(bf.length() - 1, bf.length());
/* 467 */     bf.append(" FROM ");
/* 468 */     bf.append(taskTb).append(" ").append(PREFIX_TASK).append(",");
/* 469 */     bf.append(flowTb).append(" ").append(PREFIX_FLOW).append(" where ").append(PREFIX_TASK).append(".").append("WORKFLOW_ID").append(" = ").append(PREFIX_FLOW).append(".").append("WORKFLOW_ID");
/*     */ 
/* 473 */     return bf.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 525 */     AssembleDef def = new AssembleDef();
/* 526 */     def.setQueueId("workflow");
/*     */ 
/* 528 */     String[] aa = { "201101", "201102" };
/* 529 */     String sh = createSQLHisTask(def, aa);
/*     */ 
/* 533 */     System.out.println(sh);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 478 */     m_task_attrs.put("CREATE_DATE", "CREATE_DATE");
/*     */ 
/* 480 */     m_task_attrs.put("DECISION_RESULT", "DECISION_RESULT");
/* 481 */     m_task_attrs.put("DESCRIPTION", "DESCRIPTION");
/* 482 */     m_task_attrs.put("DURATION", "DURATION");
/* 483 */     m_task_attrs.put("ERROR_MESSAGE", "ERROR_MESSAGE");
/* 484 */     m_task_attrs.put("FINISH_DATE", "FINISH_DATE");
/* 485 */     m_task_attrs.put("FINISH_STAFF_ID", "FINISH_STAFF_ID");
/* 486 */     m_task_attrs.put("IS_CURRENT_TASK", "IS_CURRENT_TASK");
/* 487 */     m_task_attrs.put("LABEL", "LABEL");
/* 488 */     m_task_attrs.put("LAST_TASK_ID", "LAST_TASK_ID");
/* 489 */     m_task_attrs.put("LOCK_DATE", "LOCK_DATE");
/* 490 */     m_task_attrs.put("LOCK_STAFF_ID", "LOCK_STAFF_ID");
/* 491 */     m_task_attrs.put("PARENT_TASK_ID", "PARENT_TASK_ID");
/* 492 */     m_task_attrs.put("QUEUE_ID", "QUEUE_ID");
/* 493 */     m_task_attrs.put("STATE", "STATE");
/* 494 */     m_task_attrs.put("STATE_DATE", "STATE_DATE");
/* 495 */     m_task_attrs.put("STATION_ID", "STATION_ID");
/* 496 */     m_task_attrs.put("TASK_BASE_TYPE", "TASK_BASE_TYPE");
/* 497 */     m_task_attrs.put("TASK_ID", "TASK_ID");
/* 498 */     m_task_attrs.put("TASK_STAFF_ID", "TASK_STAFF_ID");
/* 499 */     m_task_attrs.put("TASK_TAG", "TASK_TAG");
/* 500 */     m_task_attrs.put("TASK_TEMPLATE_ID", "TASK_TEMPLATE_ID");
/* 501 */     m_task_attrs.put("TASK_TYPE", "TASK_TYPE");
/* 502 */     m_task_attrs.put("WARNING_DATE", "WARNING_DATE");
/* 503 */     m_task_attrs.put("WARNING_TIMES", "WARNING_TIMES");
/* 504 */     m_task_attrs.put("REGION_ID", "REGION_ID");
/* 505 */     m_flow_attrs.put("WORKFLOW_KIND", "WORKFLOW_KIND");
/* 506 */     m_flow_attrs.put("WORKFLOW_ID", "WORKFLOW_ID");
/* 507 */     m_flow_attrs.put("WORKFLOW_CODE", "TEMPLATE_TAG");
/* 508 */     m_flow_attrs.put("WORKFLOW_CREATE_DATE", "CREATE_DATE");
/* 509 */     m_flow_attrs.put("WORKFLOW_CREATE_STAFF_ID", "CREATE_STAFF_ID");
/* 510 */     m_flow_attrs.put("WORKFLOW_DURATION", "DURATION");
/* 511 */     m_flow_attrs.put("WORKFLOW_ERROR_MESSAGE", "ERROR_MESSAGE");
/* 512 */     m_flow_attrs.put("WORKFLOW_NAME", "LABEL");
/* 513 */     m_flow_attrs.put("WORKFLOW_OBJECT_ID", "WORKFLOW_OBJECT_ID");
/* 514 */     m_flow_attrs.put("WORKFLOW_OBJECT_TYPE", "WORKFLOW_OBJECT_TYPE");
/* 515 */     m_flow_attrs.put("WORKFLOW_PARENT_TASK_ID", "PARENT_TASK_ID");
/* 516 */     m_flow_attrs.put("WORKFLOW_STATE", "STATE");
/* 517 */     m_flow_attrs.put("WORKFLOW_TASK_TEMPLATE_ID", "TEMPLATE_VERSION_ID");
/* 518 */     m_flow_attrs.put("WORKFLOW_WARNING_DATE", "WARNING_DATE");
/* 519 */     m_flow_attrs.put("WORKFLOW_WARNING_TIMES", "WARNING_TIMES");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.query.TaskInfoHelper
 * JD-Core Version:    0.5.4
 */