/*    */ package com.ai.comframe.query;
/*    */ 
/*    */ import com.ai.comframe.client.TaskTemplateInfo;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ 
/*    */ public class TemplateInfoHelper
/*    */ {
/*    */   public static TaskTemplateInfo[] transfer(TaskTemplate[] task, WorkflowTemplate wt)
/*    */   {
/* 11 */     TaskTemplateInfo[] result = new TaskTemplateInfo[task.length];
/* 12 */     for (int i = 0; i < task.length; ++i) {
/* 13 */       TaskTemplateInfo t = new TaskTemplateInfo();
/* 14 */       t.setLabel(task[i].getLabel());
/* 15 */       t.setTask_tag(task[i].getTaskTag());
/* 16 */       t.setTask_template_id(task[i].getTaskTemplateId());
/* 17 */       t.setTask_type(task[i].getTaskType());
/* 18 */       t.setTask_type_base(TaskConfig.getInstance().getBasalType(task[i].getTaskType()));
/* 19 */       t.setWorkflow_template_code(wt.getTaskTag());
/* 20 */       t.setWorkflow_template_id(wt.getTaskTemplateId());
/* 21 */       result[i] = t;
/*    */     }
/* 23 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.query.TemplateInfoHelper
 * JD-Core Version:    0.5.4
 */