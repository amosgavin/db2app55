/*     */ package com.ai.comframe.query;
/*     */ 
/*     */ import com.ai.comframe.client.VmWorkflowAttrInfo;
/*     */ import com.ai.comframe.client.WorkflowInfo;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.utils.TableAssembleUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class WorkflowInfoHelper
/*     */ {
/*  24 */   public static HashMap m_flow_attrs = new HashMap();
/*     */ 
/*  29 */   public static String TABLE_FLOW = "{VM_WF}";
/*     */ 
/*  34 */   public static String H_TABLE_FLOW = "{H_VM_WF}";
/*     */ 
/*  36 */   public static String PREFIX_FLOW = "FLOW";
/*     */ 
/*     */   public static int getCount(ResultSet result) {
/*  39 */     int ret = 0;
/*     */     try {
/*  41 */       while (result.next())
/*  42 */         ret = result.getInt("COUNT");
/*     */     }
/*     */     catch (SQLException e) {
/*  45 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  48 */     return ret;
/*     */   }
/*     */ 
/*     */   public static IBOVmWFValue[] transerToValue(ResultSet rs)
/*     */   {
/*  57 */     List flowList = new ArrayList();
/*     */     try {
/*  59 */       while (rs.next()) {
/*  60 */         IBOVmWFValue info = new BOVmWFBean();
/*  61 */         info.setCreateStaffId(rs.getString("CREATE_STAFF_ID"));
/*  62 */         info.setCurrentTaskId(rs.getString("CURRENT_TASK_ID"));
/*  63 */         info.setDescription(rs.getString("DESCRIPTION"));
/*  64 */         info.setDuration(rs.getLong("DURATION"));
/*  65 */         info.setEngineType(rs.getString("ENGINE_TYPE"));
/*  66 */         info.setEngineWorkflowId(rs.getString("ENGINE_WORKFLOW_ID"));
/*  67 */         info.setErrorMessage(rs.getString("ERROR_MESSAGE"));
/*  68 */         info.setWorkflowKind(rs.getInt("WORKFLOW_KIND"));
/*  69 */         info.setLabel(rs.getString("LABEL"));
/*  70 */         info.setOpStaffId(rs.getString("OP_STAFF_ID"));
/*  71 */         info.setParentTaskId(rs.getString("PARENT_TASK_ID"));
/*  72 */         info.setQueueId(rs.getString("QUEUE_ID"));
/*  73 */         info.setState(rs.getInt("STATE"));
/*  74 */         info.setWorkflowId(rs.getString("WORKFLOW_ID"));
/*  75 */         info.setVars(rs.getString("VARS"));
/*  76 */         info.setRegionId(rs.getString("REGION_ID"));
/*  77 */         info.setWarningTimes(rs.getInt("WARNING_TIMES"));
/*  78 */         info.setWorkflowObjectId(rs.getString("WORKFLOW_OBJECT_ID"));
/*  79 */         info.setWorkflowObjectType(rs.getString("WORKFLOW_OBJECT_TYPE"));
/*  80 */         flowList.add(info);
/*     */       }
/*     */     } catch (Exception e) {
/*  83 */       e.printStackTrace();
/*     */     }
/*  85 */     return (IBOVmWFValue[])(IBOVmWFValue[])flowList.toArray(new IBOVmWFValue[0]);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] transer(ResultSet rs)
/*     */   {
/*  94 */     List flowList = new ArrayList();
/*     */     try {
/*  96 */       while (rs.next()) {
/*  97 */         WorkflowInfo info = new WorkflowInfo();
/*  98 */         info.setCreateDate(rs.getTimestamp("CREATE_DATE"));
/*  99 */         info.setCreateStaffId(rs.getString("CREATE_STAFF_ID"));
/* 100 */         info.setCurrentTaskId(rs.getString("CURRENT_TASK_ID"));
/* 101 */         info.setDescription(rs.getString("DESCRIPTION"));
/* 102 */         info.setDistrictId(rs.getString("REGION_ID"));
/* 103 */         info.setDuration(rs.getLong("DURATION"));
/* 104 */         info.setEngineType(rs.getString("ENGINE_TYPE"));
/* 105 */         info.setEngineWorkflowId(rs.getString("ENGINE_WORKFLOW_ID"));
/* 106 */         info.setErrorCount(rs.getLong("ERROR_COUNT"));
/* 107 */         info.setErrorMessage(rs.getString("ERROR_MESSAGE"));
/* 108 */         info.setFinishDate(rs.getTimestamp("FINISH_DATE"));
/* 109 */         info.setWorkflowKind(rs.getInt("WORKFLOW_KIND"));
/* 110 */         info.setLabel(rs.getString("LABEL"));
/* 111 */         info.setOpStaffId(rs.getString("OP_STAFF_ID"));
/* 112 */         info.setParentTaskId(rs.getString("PARENT_TASK_ID"));
/* 113 */         info.setQueueId(rs.getString("QUEUE_ID"));
/* 114 */         info.setStartDate(rs.getTimestamp("START_DATE"));
/* 115 */         info.setState(rs.getInt("STATE"));
/* 116 */         info.setStateDate(rs.getTimestamp("STATE_DATE"));
/* 117 */         info.setWorkflowId(rs.getString("WORKFLOW_ID"));
/* 118 */         info.setTaskTag(rs.getString("TEMPLATE_TAG"));
/* 119 */         info.setTaskTemplateId(rs.getLong("TEMPLATE_VERSION_ID"));
/* 120 */         info.setTaskType(rs.getString("WORKFLOW_TYPE"));
/* 121 */         info.setUserTaskCout(rs.getLong("USER_TASK_COUNT"));
/* 122 */         info.setVars(rs.getString("VARS"));
/* 123 */         info.setWarningDate(rs.getTimestamp("WARNING_DATE"));
/* 124 */         info.setWarningTimes(rs.getInt("WARNING_TIMES"));
/* 125 */         info.setWorkflowObjectId(rs.getString("WORKFLOW_OBJECT_ID"));
/* 126 */         info.setWorkflowObjectType(rs.getString("WORKFLOW_OBJECT_TYPE"));
/* 127 */         info.setRegionId(rs.getString("REGION_ID"));
/* 128 */         flowList.add(info);
/*     */       }
/*     */     } catch (Exception e) {
/* 131 */       e.printStackTrace();
/*     */     }
/* 133 */     return (WorkflowInfo[])(WorkflowInfo[])flowList.toArray(new WorkflowInfo[0]);
/*     */   }
/*     */ 
/*     */   public static String createSQLWorkflow(AssembleDef def) throws Exception {
/* 137 */     List unionSqls = new ArrayList();
/* 138 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 139 */     String tmp = createSQL(flowTb);
/* 140 */     unionSqls.add(tmp);
/* 141 */     return TaskInfoHelper.createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLWorkflowCount(AssembleDef def) throws Exception {
/* 145 */     List unionSqls = new ArrayList();
/* 146 */     String flowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 147 */     String tmp = createSQL(flowTb);
/* 148 */     unionSqls.add(tmp);
/* 149 */     return TaskInfoHelper.createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLWorkflowHis(AssembleDef def, String[] date) throws Exception {
/* 153 */     List unionSqls = new ArrayList();
/* 154 */     for (int i = 0; i < date.length; ++i) {
/* 155 */       def.setSdate(date[i]);
/* 156 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 157 */       String tmp = createSQL(flowTb);
/* 158 */       unionSqls.add(tmp);
/*     */     }
/* 160 */     return TaskInfoHelper.createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLWorkflowHisCount(AssembleDef def, String[] date) throws Exception {
/* 164 */     List unionSqls = new ArrayList();
/* 165 */     for (int i = 0; i < date.length; ++i) {
/* 166 */       def.setSdate(date[i]);
/* 167 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 168 */       String tmp = createSQL(flowTb);
/* 169 */       unionSqls.add(tmp);
/*     */     }
/* 171 */     return TaskInfoHelper.createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   public static String createSQLAllWorkflow(AssembleDef def, String[] date) throws Exception {
/* 175 */     List unionSqls = new ArrayList();
/* 176 */     String curflowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 177 */     unionSqls.add(createSQL(curflowTb));
/* 178 */     for (int i = 0; i < date.length; ++i) {
/* 179 */       def.setSdate(date[i]);
/* 180 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 181 */       String tmp = createSQL(flowTb);
/* 182 */       unionSqls.add(tmp);
/*     */     }
/* 184 */     return TaskInfoHelper.createQueryResult(unionSqls, false);
/*     */   }
/*     */ 
/*     */   public static String createSQLAllWorkflowCount(AssembleDef def, String[] date) throws Exception {
/* 188 */     List unionSqls = new ArrayList();
/* 189 */     String curflowTb = TableAssembleUtil.getTableName(TABLE_FLOW, def);
/* 190 */     unionSqls.add(createSQL(curflowTb));
/* 191 */     for (int i = 0; i < date.length; ++i) {
/* 192 */       def.setSdate(date[i]);
/* 193 */       String flowTb = TableAssembleUtil.getHisTableName(H_TABLE_FLOW, def);
/* 194 */       String tmp = createSQL(flowTb);
/* 195 */       unionSqls.add(tmp);
/*     */     }
/* 197 */     return TaskInfoHelper.createQueryResult(unionSqls, true);
/*     */   }
/*     */ 
/*     */   private static String createSQL(String flowTb) throws Exception {
/* 201 */     StringBuffer bf = new StringBuffer();
/* 202 */     bf.append("SELECT ");
/* 203 */     IBOVmWFValue wf = new BOVmWFBean();
/* 204 */     String[] column = wf.getPropertyNames();
/* 205 */     for (int i = 0; i < column.length; ++i) {
/* 206 */       bf.append(PREFIX_FLOW).append(".").append(column[i]);
/* 207 */       bf.append(" AS ").append(column[i]).append(",");
/*     */     }
/* 209 */     if (flowTb.indexOf("HIS") > -1) {
/* 210 */       bf.append("");
/* 211 */       bf.append(" AS ").append("TRANSFER_DATE").append(",");
/*     */     }
/* 213 */     bf.delete(bf.length() - 1, bf.length());
/* 214 */     bf.append(" FROM ");
/* 215 */     bf.append(flowTb).append(" ").append(PREFIX_FLOW);
/* 216 */     return bf.toString();
/*     */   }
/*     */ 
/*     */   public static VmWorkflowAttrInfo[] transfer(IBOVmWFAttrValue[] beans)
/*     */   {
/* 222 */     VmWorkflowAttrInfo[] result = new VmWorkflowAttrInfo[beans.length];
/* 223 */     for (int i = 0; i < beans.length; ++i) {
/* 224 */       result[i] = new VmWorkflowAttrInfo();
/* 225 */       if (beans[i].getAttrCode() != null) {
/* 226 */         result[i].setAttrCode(beans[i].getAttrCode());
/*     */       }
/* 228 */       if (beans[i].getAttrName() != null) {
/* 229 */         result[i].setAttrName(beans[i].getAttrName());
/*     */       }
/* 231 */       if (beans[i].getAttrValue() != null) {
/* 232 */         result[i].setAttrValue(beans[i].getAttrValue());
/*     */       }
/* 234 */       result[i].setAttrId(beans[i].getAttrId());
/* 235 */       result[i].setWorkflowId(beans[i].getWorkflowId());
/*     */     }
/* 237 */     return result;
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] transfer(IBOVmWFValue[] beans) {
/* 241 */     WorkflowInfo[] result = new WorkflowInfo[beans.length];
/* 242 */     for (int i = 0; i < beans.length; ++i) {
/* 243 */       result[i] = new WorkflowInfo();
/* 244 */       result[i].setCurrentTaskId(beans[i].getCurrentTaskId());
/* 245 */       result[i].setDuration(beans[i].getDuration());
/* 246 */       result[i].setCreateStaffId(beans[i].getCreateStaffId());
/* 247 */       result[i].setDescription(beans[i].getDescription());
/* 248 */       result[i].setDistrictId(beans[i].getRegionId());
/* 249 */       result[i].setEngineType(beans[i].getEngineType());
/* 250 */       result[i].setEngineWorkflowId(beans[i].getEngineWorkflowId());
/* 251 */       result[i].setErrorCount(beans[i].getErrorCount());
/* 252 */       result[i].setErrorMessage(beans[i].getErrorMessage());
/* 253 */       result[i].setWorkflowKind(beans[i].getWorkflowKind());
/* 254 */       result[i].setLabel(beans[i].getLabel());
/* 255 */       result[i].setOpStaffId(beans[i].getOpStaffId());
/* 256 */       result[i].setParentTaskId(beans[i].getParentTaskId());
/* 257 */       result[i].setQueueId(beans[i].getQueueId());
/* 258 */       result[i].setState(beans[i].getState());
/* 259 */       result[i].setWorkflowId(beans[i].getWorkflowId());
/* 260 */       result[i].setTaskTag(beans[i].getTemplateTag());
/* 261 */       result[i].setTaskTemplateId(beans[i].getTemplateVersionId());
/* 262 */       result[i].setTaskType(beans[i].getWorkflowType());
/* 263 */       result[i].setUserTaskCout(beans[i].getUserTaskCount());
/* 264 */       result[i].setVars(beans[i].getVars());
/* 265 */       result[i].setWorkflowObjectId(beans[i].getWorkflowObjectId());
/* 266 */       result[i].setWorkflowObjectType(beans[i].getWorkflowObjectType());
/* 267 */       if (beans[i].getCreateDate() != null)
/* 268 */         result[i].setCreateDate(beans[i].getCreateDate());
/* 269 */       if (beans[i].getFinishDate() != null)
/* 270 */         result[i].setFinishDate(beans[i].getFinishDate());
/* 271 */       if (beans[i].getStateDate() != null)
/* 272 */         result[i].setStateDate(beans[i].getStateDate());
/* 273 */       if (beans[i].getStartDate() != null)
/* 274 */         result[i].setStartDate(beans[i].getStartDate());
/* 275 */       if (beans[i].getWarningDate() != null)
/* 276 */         result[i].setWarningDate(beans[i].getWarningDate());
/* 277 */       result[i].setWarningTimes(beans[i].getWarningTimes());
/*     */     }
/* 279 */     return result;
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] transfer(IBOHVmWFValue[] beans) {
/* 283 */     WorkflowInfo[] result = new WorkflowInfo[beans.length];
/* 284 */     for (int i = 0; i < beans.length; ++i) {
/* 285 */       result[i] = new WorkflowInfo();
/* 286 */       result[i].setCurrentTaskId(beans[i].getCurrentTaskId());
/* 287 */       result[i].setDuration(beans[i].getDuration());
/* 288 */       result[i].setCreateStaffId(beans[i].getCreateStaffId());
/* 289 */       result[i].setDescription(beans[i].getDescription());
/* 290 */       result[i].setDistrictId(beans[i].getRegionId());
/* 291 */       result[i].setEngineType(beans[i].getEngineType());
/* 292 */       result[i].setEngineWorkflowId(beans[i].getEngineWorkflowId());
/* 293 */       result[i].setErrorCount(beans[i].getErrorCount());
/* 294 */       result[i].setErrorMessage(beans[i].getErrorMessage());
/* 295 */       result[i].setWorkflowKind(beans[i].getWorkflowKind());
/* 296 */       result[i].setLabel(beans[i].getLabel());
/* 297 */       result[i].setOpStaffId(beans[i].getOpStaffId());
/* 298 */       result[i].setParentTaskId(beans[i].getParentTaskId());
/* 299 */       result[i].setQueueId(beans[i].getQueueId());
/* 300 */       result[i].setState(beans[i].getState());
/* 301 */       result[i].setWorkflowId(beans[i].getWorkflowId());
/* 302 */       result[i].setTaskTag(beans[i].getTemplateTag());
/*     */ 
/* 304 */       result[i].setTaskTemplateId(beans[i].getTemplateVersionId());
/* 305 */       result[i].setTaskType(beans[i].getWorkflowType());
/* 306 */       result[i].setUserTaskCout(beans[i].getUserTaskCount());
/* 307 */       result[i].setVars(beans[i].getVars());
/* 308 */       result[i].setWorkflowObjectId(beans[i].getWorkflowObjectId());
/*     */ 
/* 310 */       result[i].setWorkflowObjectType(beans[i].getWorkflowObjectType());
/* 311 */       if (beans[i].getCreateDate() != null)
/* 312 */         result[i].setCreateDate(beans[i].getCreateDate());
/* 313 */       if (beans[i].getFinishDate() != null)
/* 314 */         result[i].setFinishDate(beans[i].getFinishDate());
/* 315 */       if (beans[i].getStateDate() != null)
/* 316 */         result[i].setStateDate(beans[i].getStateDate());
/* 317 */       if (beans[i].getStartDate() != null)
/* 318 */         result[i].setStartDate(beans[i].getStartDate());
/* 319 */       if (beans[i].getWarningDate() != null)
/* 320 */         result[i].setWarningDate(beans[i].getWarningDate());
/* 321 */       result[i].setWarningTimes(beans[i].getWarningTimes());
/*     */     }
/* 323 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.query.WorkflowInfoHelper
 * JD-Core Version:    0.5.4
 */