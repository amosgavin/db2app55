/*     */ package com.ai.comframe.config.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.cache.VmAlarmConfigCacheImpl;
/*     */ import com.ai.comframe.cache.VmHoliDayCacheImpl;
/*     */ import com.ai.comframe.client.service.interfaces.IComframeCallBusiDefaultSV;
/*     */ import com.ai.comframe.config.dao.interfaces.IVmAlarmConfigDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.queue.WarningTaskBean;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV;
/*     */ import java.lang.reflect.Method;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmAlarmConfigSVImpl
/*     */   implements IVmAlarmConfigSV
/*     */ {
/*  35 */   private static transient Log logger = LogFactory.getLog(VmAlarmConfigSVImpl.class);
/*     */ 
/*     */   public static IComframeCallBusiDefaultSV getBusiService() {
/*  38 */     return (IComframeCallBusiDefaultSV)ServiceFactory.getService(IComframeCallBusiDefaultSV.class);
/*     */   }
/*     */ 
/*     */   public Timestamp calculateAlarmTime(String alarmTimeMethod, long templateId, String templateTag, String taskTag, String workflowObjId, String workflowObjTypeId, int duration, int alarmtimes, int isHoliday) throws RemoteException, Exception
/*     */   {
/*  43 */     Timestamp date = null;
/*  44 */     if (StringUtils.isEmptyString(alarmTimeMethod))
/*  45 */       date = getBusiService().getAlarmTimeDefault(templateId, templateTag, taskTag, workflowObjId, workflowObjTypeId, duration, alarmtimes, isHoliday);
/*     */     else {
/*     */       try
/*     */       {
/*  49 */         int index = alarmTimeMethod.lastIndexOf(".");
/*  50 */         String method = alarmTimeMethod.substring(index + 1);
/*  51 */         String className = alarmTimeMethod.substring(0, index);
/*  52 */         Class c = Class.forName(className);
/*  53 */         Object instance = c.newInstance();
/*  54 */         Method m = c.getMethod(method, new Class[] { Long.TYPE, String.class, String.class, String.class, String.class, Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*  55 */         date = (Timestamp)m.invoke(instance, new Object[] { new Long(templateId), templateTag, taskTag, workflowObjId, workflowObjTypeId, new Integer(duration), new Integer(alarmtimes), new Integer(isHoliday) });
/*     */       }
/*     */       catch (Exception e) {
/*  58 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_accordToProcessTemplate") + templateTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_taskTemplate") + taskTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateAlarmTime_getAlartTimeMethod") + alarmTimeMethod + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_getException") + e.getMessage(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  64 */     return date;
/*     */   }
/*     */ 
/*     */   public int calculateDuration(String durationTimeMethod, long templateId, String templateTag, String taskTag, String workflowObjId, String workflowObjTypeId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  70 */     int duration = 0;
/*  71 */     if (StringUtils.isEmptyString(durationTimeMethod))
/*  72 */       duration = getBusiService().getDurationDefault(templateId, templateTag, taskTag, workflowObjId, workflowObjTypeId);
/*     */     else {
/*     */       try
/*     */       {
/*  76 */         int index = durationTimeMethod.lastIndexOf(".");
/*  77 */         String method = durationTimeMethod.substring(index + 1);
/*  78 */         String className = durationTimeMethod.substring(0, index);
/*  79 */         Class c = Class.forName(className);
/*  80 */         Object instance = c.newInstance();
/*  81 */         Method m = c.getMethod(method, new Class[] { Long.TYPE, String.class, String.class, String.class, String.class });
/*  82 */         Integer f = (Integer)m.invoke(instance, new Object[] { new Long(templateId), templateTag, taskTag, workflowObjId, workflowObjTypeId });
/*  83 */         duration = f.intValue();
/*     */       }
/*     */       catch (Exception e) {
/*  86 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_accordToProcessTemplate") + templateTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_taskTemplate") + taskTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_getGSMethod") + durationTimeMethod + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_getException") + e.getMessage(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  92 */     return duration;
/*     */   }
/*     */ 
/*     */   public void dealAlarm(String alarmdealMethod, long templateId, String templateTag, String taskTag, String staffId, String stationId, String workflowObjId, String workflowObjTypeId, int alarmTimes) throws RemoteException, Exception
/*     */   {
/*  97 */     if (StringUtils.isEmptyString(alarmdealMethod))
/*  98 */       getBusiService().alarmDealDefault(templateId, templateTag, taskTag, staffId, stationId, workflowObjId, workflowObjTypeId, alarmTimes);
/*     */     else
/*     */       try
/*     */       {
/* 102 */         int index = alarmdealMethod.lastIndexOf(".");
/* 103 */         String method = alarmdealMethod.substring(index + 1);
/* 104 */         String className = alarmdealMethod.substring(0, index);
/* 105 */         Class c = Class.forName(className);
/* 106 */         Object instance = c.newInstance();
/* 107 */         Method m = c.getMethod(method, new Class[] { Long.TYPE, String.class, String.class, String.class, String.class, String.class, String.class, Integer.TYPE });
/* 108 */         m.invoke(instance, new Object[] { new Long(templateId), templateTag, taskTag, staffId, stationId, workflowObjId, workflowObjTypeId, new Integer(alarmTimes) });
/*     */       }
/*     */       catch (Exception e) {
/* 111 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_accordToProcessTemplate") + templateTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_taskTemplate") + taskTag + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.dealAlarm_dealOverTimeWarnMth") + alarmdealMethod + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.AlarmUtil.calculateDuration_getException") + e.getMessage(), e);
/*     */       }
/*     */   }
/*     */ 
/*     */   public IBOVmAlarmConfigValue[] getAlarmConfig(String taskTag, String templateTag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 121 */     if ((templateTag == null) || (taskTag == null))
/*     */     {
/* 123 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.VmAlarmConfigSVImpl_templateTagNullOrTaskTagNull") + "templateTag=" + templateTag + " taskTag=" + taskTag);
/*     */     }
/* 125 */     HashMap obj = CacheFactory.getAll(VmAlarmConfigCacheImpl.class);
/* 126 */     if (obj == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     List templateAlarm = new ArrayList();
/* 130 */     Iterator it = obj.entrySet().iterator();
/* 131 */     while (it.hasNext()) {
/* 132 */       Map.Entry tmp = (Map.Entry)it.next();
/* 133 */       IBOVmAlarmConfigValue alarmValue = (IBOVmAlarmConfigValue)tmp.getValue();
/* 134 */       if ((templateTag.equals(alarmValue.getTemplateTag())) && (taskTag.equals(alarmValue.getTaskTag()))) {
/* 135 */         templateAlarm.add(alarmValue);
/*     */       }
/*     */     }
/* 138 */     return (IBOVmAlarmConfigValue[])(IBOVmAlarmConfigValue[])templateAlarm.toArray(new IBOVmAlarmConfigValue[0]);
/*     */   }
/*     */ 
/*     */   public IBOVmAlarmConfigValue[] getAlarmConfigs(String templateTag) throws RemoteException, Exception {
/* 142 */     if (templateTag == null) {
/* 143 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.VmAlarmConfigSVImpl_templateTagNull") + "templateTag=" + templateTag);
/*     */     }
/* 145 */     HashMap obj = CacheFactory.getAll(VmAlarmConfigCacheImpl.class);
/* 146 */     if (obj == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     List templateAlarm = new ArrayList();
/* 150 */     Iterator it = obj.entrySet().iterator();
/* 151 */     while (it.hasNext()) {
/* 152 */       Map.Entry tmp = (Map.Entry)it.next();
/* 153 */       IBOVmAlarmConfigValue alarmValue = (IBOVmAlarmConfigValue)tmp.getValue();
/* 154 */       if ((templateTag.equals(alarmValue.getTemplateTag())) && (StringUtils.isEmptyString(alarmValue.getTaskTag()))) {
/* 155 */         templateAlarm.add(alarmValue);
/*     */       }
/*     */     }
/* 158 */     if (templateAlarm.size() == 0)
/* 159 */       return null;
/* 160 */     return (IBOVmAlarmConfigValue[])(IBOVmAlarmConfigValue[])templateAlarm.toArray(new IBOVmAlarmConfigValue[0]);
/*     */   }
/*     */ 
/*     */   public IBOVmHoliDayValue[] loadAllHolidays() throws RemoteException, Exception {
/* 164 */     IVmAlarmConfigDAO alarmDao = (IVmAlarmConfigDAO)ServiceFactory.getService(IVmAlarmConfigDAO.class);
/* 165 */     return alarmDao.loadAllHolidays();
/*     */   }
/*     */ 
/*     */   public IBOVmAlarmConfigValue[] loadAllVmAlarmConfigs() throws RemoteException, Exception {
/* 169 */     IVmAlarmConfigDAO alarmDao = (IVmAlarmConfigDAO)ServiceFactory.getService(IVmAlarmConfigDAO.class);
/* 170 */     return alarmDao.loadAllVmAlarmConfigs();
/*     */   }
/*     */ 
/*     */   public Timestamp[] getHolidayList() throws Exception {
/* 174 */     HashMap obj = CacheFactory.getAll(VmHoliDayCacheImpl.class);
/* 175 */     if (obj == null) {
/* 176 */       return null;
/*     */     }
/* 178 */     Iterator it = obj.entrySet().iterator();
/* 179 */     Timestamp[] date = new Timestamp[obj.size()];
/* 180 */     int i = 0;
/* 181 */     while (it.hasNext()) {
/* 182 */       Map.Entry tmp = (Map.Entry)it.next();
/* 183 */       IBOVmHoliDayValue holidayValue = (IBOVmHoliDayValue)tmp.getValue();
/* 184 */       date[i] = holidayValue.getHoliday();
/* 185 */       ++i;
/*     */     }
/* 187 */     return date;
/*     */   }
/*     */ 
/*     */   public IBOVmHoliDayValue[] getHolidayValue() throws RemoteException, Exception {
/* 191 */     HashMap obj = CacheFactory.getAll(VmHoliDayCacheImpl.class);
/* 192 */     List holidayValue = new ArrayList();
/* 193 */     Iterator it = obj.entrySet().iterator();
/* 194 */     while (it.hasNext()) {
/* 195 */       Map.Entry tmp = (Map.Entry)it.next();
/* 196 */       IBOVmHoliDayValue tmpholidayValue = (IBOVmHoliDayValue)tmp.getValue();
/* 197 */       holidayValue.add(tmpholidayValue);
/*     */     }
/* 199 */     if (holidayValue.size() == 0) {
/* 200 */       return new IBOVmHoliDayValue[0];
/*     */     }
/* 202 */     return (IBOVmHoliDayValue[])(IBOVmHoliDayValue[])holidayValue.toArray(new IBOVmHoliDayValue[0]);
/*     */   }
/*     */ 
/*     */   public void saveAlarmConfig(IBOVmAlarmConfigValue[] values) throws RemoteException, Exception {
/* 206 */     IVmAlarmConfigDAO alarmDao = (IVmAlarmConfigDAO)ServiceFactory.getService(IVmAlarmConfigDAO.class);
/* 207 */     alarmDao.saveAlarmConfig(values);
/*     */   }
/*     */ 
/*     */   public void saveHolidayConfig(IBOVmHoliDayValue[] beans) throws RemoteException, Exception
/*     */   {
/* 212 */     IVmAlarmConfigDAO alarmDao = (IVmAlarmConfigDAO)ServiceFactory.getService(IVmAlarmConfigDAO.class);
/* 213 */     alarmDao.saveHolidayConfig(beans);
/*     */   }
/*     */ 
/*     */   public void updateDuration(String taskId, int duration, String type) throws RemoteException, Exception {
/* 217 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 218 */     if (type.equalsIgnoreCase("task")) {
/* 219 */       IBOVmTaskValue task = taskSv.getVmTaskByID(taskId);
/* 220 */       task.setDuration(duration);
/* 221 */       taskSv.saveVmTaskInstance(task);
/*     */     }
/* 223 */     if (type.equalsIgnoreCase("taskTrans")) {
/* 224 */       IBOVmTaskTSValue taskTS = taskSv.getVmTaskTSByID(taskId);
/* 225 */       taskTS.setDuration(duration);
/* 226 */       taskSv.saveVmTaskTSInstance(taskTS);
/*     */     }
/* 228 */     if (type.equalsIgnoreCase("workflow")) {
/* 229 */       IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 230 */       IBOVmWFValue workflow = workflowSv.getVmWorkflowBeanbyId(taskId);
/* 231 */       workflow.setDuration(duration);
/* 232 */       workflowSv.saveVmWorkflowInstacne(workflow);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateWarning(String taskId, Timestamp date, int alarmTimes, String type) throws RemoteException, Exception {
/* 237 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 238 */     if (type.equalsIgnoreCase("task")) {
/* 239 */       IBOVmTaskValue task = taskSv.getVmTaskByID(taskId);
/* 240 */       task.setWarningTimes(alarmTimes);
/* 241 */       if (date != null)
/* 242 */         task.setWarningDate(date);
/*     */       else {
/* 244 */         task.setWarningDate(null);
/*     */       }
/* 246 */       taskSv.saveVmTaskInstance(task);
/*     */     }
/* 248 */     if (type.equalsIgnoreCase("taskTrans")) {
/* 249 */       IBOVmTaskTSValue taskTS = taskSv.getVmTaskTSByID(taskId);
/* 250 */       taskTS.setWarningTimes(alarmTimes);
/* 251 */       if (date != null)
/* 252 */         taskTS.setWarningDate(date);
/*     */       else {
/* 254 */         taskTS.setWarningDate(null);
/*     */       }
/* 256 */       taskSv.saveVmTaskTSInstance(taskTS);
/*     */     }
/* 258 */     if (type.equalsIgnoreCase("workflow")) {
/* 259 */       IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 260 */       IBOVmWFValue workflow = workflowSv.getVmWorkflowBeanbyId(taskId);
/* 261 */       workflow.setWarningTimes(alarmTimes);
/* 262 */       if (date != null)
/* 263 */         workflow.setWarningDate(date);
/*     */       else {
/* 265 */         workflow.setWarningDate(null);
/*     */       }
/* 267 */       workflowSv.saveVmWorkflowInstacne(workflow);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void warning(WarningTaskBean bean)
/*     */     throws RemoteException, Exception
/*     */   {
/* 276 */     IBOVmAlarmConfigValue[] alarm = getAlarmConfig(bean.getTaskTag(), bean.getTemplateTag());
/* 277 */     if ((alarm == null) || (alarm.length < 1)) {
/* 278 */       updateWarning(bean.getTaskId(), null, bean.getAlarmtimes(), bean.getType());
/*     */     } else {
/* 280 */       if (alarm.length > 1) {
/* 281 */         logger.error("According to the template code：" + bean.getTemplateTag() + " and the task code：" + bean.getTaskTag() + " found more than one record in Configuration table,it will be used to take the first");
/*     */       }
/*     */ 
/* 286 */       dealAlarm(alarm[0].getAlarmDealMethod(), alarm[0].getTemplateVersionId(), bean.getTemplateTag(), bean.getTaskTag(), bean.getStaffId(), bean.getStationId(), bean.getWorkflowObjId(), bean.getWorkflowObjTypeId(), bean.getAlarmtimes() + 1);
/*     */ 
/* 290 */       Timestamp date = calculateAlarmTime(alarm[0].getAlarmTimeMethod(), alarm[0].getTemplateVersionId(), bean.getTemplateTag(), bean.getTaskTag(), bean.getWorkflowObjId(), bean.getWorkflowObjTypeId(), (int)bean.getDuration(), bean.getAlarmtimes() + 1, alarm[0].getIsHoliday());
/*     */ 
/* 294 */       updateWarning(bean.getTaskId(), date, bean.getAlarmtimes() + 1, bean.getType());
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmAlarmConfigValue[] getAlarmConfigs(String cond, HashMap param) throws RemoteException, Exception
/*     */   {
/* 300 */     IVmAlarmConfigDAO alarmDao = (IVmAlarmConfigDAO)ServiceFactory.getService(IVmAlarmConfigDAO.class);
/* 301 */     return alarmDao.getAlarmConfigs(cond, param);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.VmAlarmConfigSVImpl
 * JD-Core Version:    0.5.4
 */