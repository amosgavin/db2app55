/*      */ package com.ai.comframe.config.service.impl;
/*      */ 
/*      */ import com.ai.appframe2.bo.DataContainer;
/*      */ import com.ai.appframe2.service.ServiceFactory;
/*      */ import com.ai.appframe2.util.StringUtils;
/*      */ import com.ai.comframe.client.ComframeClient;
/*      */ import com.ai.comframe.client.TaskInfo;
/*      */ import com.ai.comframe.config.bo.BOVmEngineTemplateVersionBean;
/*      */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*      */ import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
/*      */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*      */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*      */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*      */ import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
/*      */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*      */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*      */ import com.ai.comframe.config.service.interfaces.IWorkflowConsoleSV;
/*      */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*      */ import com.ai.comframe.query.TaskInfoHelper;
/*      */ import com.ai.comframe.utils.AssembleDef;
/*      */ import com.ai.comframe.utils.DataSourceUtil;
/*      */ import com.ai.comframe.utils.IDAssembleUtil;
/*      */ import com.ai.comframe.utils.PropertiesUtil;
/*      */ import com.ai.comframe.utils.TimeUtil;
/*      */ import com.ai.comframe.utils.WrapPropertiesUtil;
/*      */ import com.ai.comframe.vm.common.Constant;
/*      */ import com.ai.comframe.vm.common.ParameterDefine;
/*      */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IQBOVmTaskInfoValue;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.rmi.RemoteException;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.fileupload.FileItem;
/*      */ import org.apache.commons.httpclient.util.DateUtil;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class WorkflowConsoleSVImpl
/*      */   implements IWorkflowConsoleSV
/*      */ {
/*   59 */   private static final Log log = LogFactory.getLog(WorkflowConsoleSVImpl.class);
/*      */   private static final String W_PUBLISH_ENGINETYPE = "workflow.publish.engineType";
/*      */   private static final String W_TEMPLATE_NAME = "workflow.template.name";
/*      */ 
/*      */   public String[][] getWorkflowState()
/*      */     throws Exception, RemoteException
/*      */   {
/*   73 */     return Constant.WORKFLOW_STATE;
/*      */   }
/*      */ 
/*      */   public String[][] getTaskState() throws Exception, RemoteException {
/*   77 */     return Constant.TASK_STATE;
/*      */   }
/*      */ 
/*      */   public String[][] getVMDealType() throws Exception, RemoteException {
/*   81 */     return Constant.VM_DEAL_TYPE;
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String templateTag, String staffId, String objectTypeId, String objectId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*   88 */     String workflowId = ComframeClient.createWorkflow(templateTag, staffId, objectTypeId, objectId, aVars, null, null);
/*   89 */     log.debug("IWorkflowConsole.createWorkflow(" + templateTag + "," + staffId + "," + objectTypeId + "," + objectId + ")  return results:" + workflowId);
/*   90 */     return workflowId;
/*      */   }
/*      */ 
/*      */   public void dropWorkflow(String workflowId) throws Exception
/*      */   {
/*   95 */     ComframeClient.dropWorkflow(workflowId);
/*      */   }
/*      */ 
/*      */   public boolean finishUserTask(String taskId, String staffId, String result, String reason, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  101 */     return ComframeClient.finishUserTask(taskId, staffId, result, reason, aVars);
/*      */   }
/*      */ 
/*      */   public void fireWorkflowExceptionByTaskId(String taskId, String errorCode, String errorMessage) throws Exception
/*      */   {
/*  106 */     ComframeClient.fireWorkflowExceptionByTaskId(taskId, PropertiesUtil.getSystemUserId(), errorCode, errorMessage);
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String currentTaskId, long goBackTaskTemplateId, String staffId, String reason, Map aVars) throws RemoteException, Exception
/*      */   {
/*  111 */     boolean isPushDataSource = false;
/*      */     try
/*      */     {
/*  114 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(currentTaskId));
/*  115 */       IWorkflowEngineSV workflowEngine = (IWorkflowEngineSV)ServiceFactory.getService(IWorkflowEngineSV.class);
/*  116 */       boolean bool1 = workflowEngine.goBackToTask(currentTaskId, goBackTaskTemplateId, aVars, staffId, reason);
/*      */ 
/*  120 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  118 */       if (isPushDataSource == true)
/*  119 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean jumpToTask(String currentTaskId, long goBackTaskTemplateId, String staffId, String reason, Map aVars) throws RemoteException, Exception
/*      */   {
/*  125 */     boolean isPushDataSource = false;
/*      */     try {
/*  127 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(currentTaskId));
/*  128 */       IWorkflowEngineSV workflowEngine = (IWorkflowEngineSV)ServiceFactory.getService(IWorkflowEngineSV.class);
/*  129 */       boolean bool1 = workflowEngine.jumpToTask(currentTaskId, goBackTaskTemplateId, aVars, staffId, reason);
/*      */ 
/*  133 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  131 */       if (isPushDataSource == true)
/*  132 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void lockTask(String taskId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  138 */     ComframeClient.lockTask(taskId, staffId);
/*      */   }
/*      */ 
/*      */   public boolean printUserTask(String taskId, String staffId, Map aVars) throws RemoteException, Exception
/*      */   {
/*  143 */     return ComframeClient.printUserTask(taskId, staffId, aVars);
/*      */   }
/*      */ 
/*      */   public String reAuthorizeTask(String taskId, String authorizeStaffId, String authorizeStationId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  154 */     return ComframeClient.reAuthorizeTask(taskId, authorizeStaffId, authorizeStationId, staffId);
/*      */   }
/*      */ 
/*      */   public void releaseTaskLock(String taskId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  159 */     ComframeClient.realseTask(taskId);
/*      */   }
/*      */ 
/*      */   public void resumeExceptionWorkflow(String workflowId) throws Exception
/*      */   {
/*  164 */     ComframeClient.resumeExceptionWorkflow(workflowId);
/*      */   }
/*      */   public int resumeExceptionWorkflows(String queueID, String[] workflowIds) throws RemoteException, Exception {
/*  167 */     return ComframeClient.resumeExceptionWorkflows(queueID, workflowIds);
/*      */   }
/*      */ 
/*      */   public void resumeWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception {
/*  171 */     ComframeClient.resumeWorkflow(workflowId, staffId, reason);
/*      */   }
/*      */ 
/*      */   public void suspendWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  176 */     ComframeClient.stopWorkflow(workflowId, staffId, reason);
/*      */   }
/*      */ 
/*      */   public void terminateWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  181 */     ComframeClient.terminateWorkflow(workflowId, staffId, reason);
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String workflowId, String staffId, String errorCode, String errorMessage) throws Exception {
/*  185 */     ComframeClient.cancelWorkflow(workflowId, staffId, errorCode, errorMessage);
/*      */   }
/*      */ 
/*      */   public void setWorkflowVars(String workflowId, HashMap aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  197 */     ComframeClient.setWorkflowVars(workflowId, aVars);
/*      */   }
/*      */ 
/*      */   public String toSvg(String workflowId) throws RemoteException, Exception {
/*  201 */     return ComframeClient.toSvg(workflowId);
/*      */   }
/*      */ 
/*      */   public String toSvg(long templateId, String taskTag) throws Exception
/*      */   {
/*  206 */     return ComframeClient.toSvg(templateId, taskTag);
/*      */   }
/*      */ 
/*      */   public String toHisSvg(String workflowId, String sdate) throws Exception, RemoteException {
/*  210 */     return ComframeClient.toSvgHis(workflowId, sdate);
/*      */   }
/*      */ 
/*      */   public String toDojo(String workflowId) throws RemoteException, Exception {
/*  214 */     return ComframeClient.toDojo(workflowId);
/*      */   }
/*      */ 
/*      */   public String toDojo(long templateId, String taskTag) throws Exception {
/*  218 */     return ComframeClient.toDojo(templateId, taskTag);
/*      */   }
/*      */ 
/*      */   public String toDojoHis(String workflowId, String sdate) throws Exception {
/*  222 */     return ComframeClient.toDojoHis(workflowId, sdate);
/*      */   }
/*      */ 
/*      */   public IBOVmWFValue[] queryWorkflow(String regionID, String queueID, String workflowObjectId, String busiOrderType, int state, String startTime, String endTime, int startIndex, int endIndex)
/*      */     throws Exception, RemoteException
/*      */   {
/*  228 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/*  229 */     HashMap param = new HashMap();
/*  230 */     if (!StringUtils.isEmptyString(regionID)) {
/*  231 */       cond.append(" and ").append("REGION_ID").append("=:").append("REGION_ID");
/*  232 */       param.put("REGION_ID", regionID);
/*      */     }
/*      */ 
/*  235 */     if (!StringUtils.isEmptyString(queueID)) {
/*  236 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/*  237 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/*  240 */     if (!StringUtils.isEmptyString(workflowObjectId)) {
/*  241 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append("=:").append("WORKFLOW_OBJECT_ID");
/*  242 */       param.put("WORKFLOW_OBJECT_ID", workflowObjectId);
/*      */     }
/*  244 */     if (!StringUtils.isEmptyString(busiOrderType)) {
/*  245 */       cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append("=:").append("WORKFLOW_OBJECT_TYPE");
/*  246 */       param.put("WORKFLOW_OBJECT_TYPE", busiOrderType);
/*      */     }
/*      */ 
/*  249 */     if (!StringUtils.isEmptyString(startTime)) {
/*  250 */       cond.append(" and ").append("CREATE_DATE").append("> :aStartDate ");
/*  251 */       param.put("aStartDate", Timestamp.valueOf(startTime));
/*      */     }
/*      */ 
/*  254 */     if (!StringUtils.isEmptyString(endTime)) {
/*  255 */       cond.append(" and ").append("CREATE_DATE").append("< :aEndDate");
/*  256 */       param.put("aEndDate", Timestamp.valueOf(endTime));
/*      */     }
/*      */ 
/*  259 */     if (state != -1)
/*      */     {
/*  261 */       cond.append(" and ").append("STATE").append("=:").append("STATE");
/*  262 */       param.put("STATE", String.valueOf(state));
/*      */     }
/*  264 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  265 */     boolean isPushDataSource = false;
/*      */     try {
/*  267 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  268 */       IBOVmWFValue[] arrayOfIBOVmWFValue = workflowSv.getWorkflowBeans(queueID, cond.toString(), param, startIndex, endIndex);
/*      */ 
/*  272 */       return arrayOfIBOVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/*  270 */       if (isPushDataSource == true)
/*  271 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getVmWorkflowCount(String regionID, String queueID, String workflowObjectId, String busiOrderType, int state, String startTime, String endTime) throws Exception {
/*  276 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/*  277 */     HashMap param = new HashMap();
/*      */ 
/*  279 */     if (!StringUtils.isEmptyString(regionID)) {
/*  280 */       cond.append(" and ").append("REGION_ID").append("=:").append("REGION_ID");
/*  281 */       param.put("REGION_ID", regionID);
/*      */     }
/*      */ 
/*  284 */     if (!StringUtils.isEmptyString(queueID)) {
/*  285 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/*  286 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/*  289 */     if (!StringUtils.isEmptyString(workflowObjectId)) {
/*  290 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append("=:").append("WORKFLOW_OBJECT_ID");
/*  291 */       param.put("WORKFLOW_OBJECT_ID", workflowObjectId);
/*      */     }
/*  293 */     if (!StringUtils.isEmptyString(busiOrderType)) {
/*  294 */       cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append("=:").append("WORKFLOW_OBJECT_TYPE");
/*  295 */       param.put("WORKFLOW_OBJECT_TYPE", busiOrderType);
/*      */     }
/*      */ 
/*  298 */     if (!StringUtils.isEmptyString(startTime)) {
/*  299 */       cond.append(" and ").append("CREATE_DATE").append("> :aStartDate ");
/*  300 */       param.put("aStartDate", Timestamp.valueOf(startTime));
/*      */     }
/*      */ 
/*  303 */     if (!StringUtils.isEmptyString(endTime)) {
/*  304 */       cond.append(" and ").append("CREATE_DATE").append("< :aEndDate");
/*  305 */       param.put("aEndDate", Timestamp.valueOf(endTime));
/*      */     }
/*      */ 
/*  308 */     if (state != -1)
/*      */     {
/*  310 */       cond.append(" and ").append("STATE").append("=:").append("STATE");
/*  311 */       param.put("STATE", String.valueOf(state));
/*      */     }
/*  313 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  314 */     boolean isPushDataSource = false;
/*      */     try {
/*  316 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  317 */       int i = workflowSv.getWorkflowBeansCount(queueID, cond.toString(), param);
/*      */ 
/*  321 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  319 */       if (isPushDataSource == true)
/*  320 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOVmWFValue[] queryChildWorkflow(String taskId, int startIndex, int endIndex)
/*      */     throws Exception, RemoteException
/*      */   {
/*  328 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  330 */     HashMap param = new HashMap();
/*  331 */     param.put("parentTaskId", taskId);
/*  332 */     param.put("workflowType", new Integer(1));
/*  333 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  334 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  335 */     boolean isPushDataSource = false;
/*      */     try {
/*  337 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  338 */       IBOVmWFValue[] arrayOfIBOVmWFValue = workflowSv.getWorkflowBeans(queueID, cond, param, startIndex, endIndex);
/*      */ 
/*  342 */       return arrayOfIBOVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/*  340 */       if (isPushDataSource == true)
/*  341 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOVmWFValue getWorkflowByParentTaskId(String parentTaskId) throws Exception, RemoteException
/*      */   {
/*  347 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  350 */     HashMap param = new HashMap();
/*  351 */     param.put("parentTaskId", parentTaskId);
/*      */ 
/*  353 */     param.put("workflowType", new Integer(2));
/*      */ 
/*  355 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*      */ 
/*  357 */     String queueID = IDAssembleUtil.unwrapPrefix(parentTaskId);
/*  358 */     boolean isPushDataSource = false;
/*      */     try {
/*  360 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  361 */       IBOVmWFValue[] wfs = workflowSv.getWorkflowBeans(queueID, cond, param, -1, -1);
/*      */ 
/*  363 */       if ((null != wfs) && (wfs.length > 0)) {
/*  364 */         localIBOVmWFValue = wfs[0];
/*      */         return localIBOVmWFValue;
/*      */       }
/*  366 */       IBOVmWFValue localIBOVmWFValue = null;
/*      */ 
/*  370 */       return localIBOVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/*  368 */       if (isPushDataSource == true)
/*  369 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOHVmWFValue getHWorkflowByParentTaskId(String parentTaskId, String acctPreiod) throws Exception, RemoteException
/*      */   {
/*  375 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  378 */     HashMap param = new HashMap();
/*  379 */     param.put("parentTaskId", parentTaskId);
/*      */ 
/*  381 */     param.put("workflowType", new Integer(2));
/*      */ 
/*  383 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*      */ 
/*  385 */     String queueID = IDAssembleUtil.unwrapPrefix(parentTaskId);
/*  386 */     boolean isPushDataSource = false;
/*      */     try {
/*  388 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  389 */       IBOHVmWFValue[] wfs = workflowSv.getHisWorkflowBeans(queueID, cond, param, -1, -1, acctPreiod);
/*  390 */       if ((null != wfs) && (wfs.length > 0)) {
/*  391 */         localIBOHVmWFValue = wfs[0];
/*      */         return localIBOHVmWFValue;
/*      */       }
/*  393 */       IBOHVmWFValue localIBOHVmWFValue = null;
/*      */ 
/*  397 */       return localIBOHVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/*  395 */       if (isPushDataSource == true)
/*  396 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int queryChildWorkflowCount(String taskId) throws Exception, RemoteException {
/*  401 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  403 */     HashMap param = new HashMap();
/*  404 */     param.put("parentTaskId", taskId);
/*  405 */     param.put("workflowType", new Integer(1));
/*  406 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  407 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  408 */     boolean isPushDataSource = false;
/*      */     try {
/*  410 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  411 */       int i = workflowSv.getWorkflowBeansCount(queueID, cond, param);
/*      */ 
/*  415 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  413 */       if (isPushDataSource == true)
/*  414 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOHVmWFValue[] queryHisChildWorkflow(String taskId, int startIndex, int endIndex, String sdate)
/*      */     throws Exception, RemoteException
/*      */   {
/*  422 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  424 */     HashMap param = new HashMap();
/*  425 */     param.put("parentTaskId", taskId);
/*  426 */     param.put("workflowType", new Integer(1));
/*  427 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  428 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  429 */     boolean isPushDataSource = false;
/*      */     try {
/*  431 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  432 */       IBOHVmWFValue[] arrayOfIBOHVmWFValue = workflowSv.getHisWorkflowBeans(queueID, cond, param, startIndex, endIndex, sdate);
/*      */ 
/*  436 */       return arrayOfIBOHVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/*  434 */       if (isPushDataSource == true)
/*  435 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int queryHisChildWorkflowCount(String taskId, String sdate) throws Exception, RemoteException {
/*  440 */     String cond = "PARENT_TASK_ID = :parentTaskId and WORKFLOW_KIND = :workflowType ";
/*      */ 
/*  442 */     HashMap param = new HashMap();
/*  443 */     param.put("parentTaskId", taskId);
/*  444 */     param.put("workflowType", new Integer(1));
/*  445 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*  446 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  447 */     boolean isPushDataSource = false;
/*      */     try {
/*  449 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  450 */       int i = workflowSv.getHisWorkflowBeansCount(queueID, cond, param, sdate);
/*      */ 
/*  454 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  452 */       if (isPushDataSource == true)
/*  453 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOVmTaskValue[] queryVmTask(String workflowID, int workflowState)
/*      */     throws Exception, RemoteException
/*      */   {
/*  466 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*  467 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowID);
/*  468 */     boolean isPushDataSource = false;
/*      */     try {
/*  470 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  471 */       StringBuffer cond = new StringBuffer();
/*  472 */       HashMap param = new HashMap();
/*  473 */       if (!StringUtils.isEmptyString(workflowID)) {
/*  474 */         cond.append("WORKFLOW_ID").append("=:").append("WORKFLOW_ID");
/*  475 */         param.put("WORKFLOW_ID", workflowID);
/*      */       }
/*  477 */       IBOVmTaskValue[] arrayOfIBOVmTaskValue = taskSv.getVmTaskBean(queueID, cond.toString(), param, -1, -1);
/*      */ 
/*  481 */       return arrayOfIBOVmTaskValue;
/*      */     }
/*      */     finally
/*      */     {
/*  479 */       if (isPushDataSource == true)
/*  480 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOVmTaskTSValue[] queryVmTaskTrans(String parentTaskId, String workflowID)
/*      */     throws Exception
/*      */   {
/*  493 */     List taskTs = new ArrayList();
/*  494 */     queryVmTaskTrans(parentTaskId, workflowID, taskTs);
/*  495 */     return (IBOVmTaskTSValue[])(IBOVmTaskTSValue[])taskTs.toArray(new IBOVmTaskTSValue[0]);
/*      */   }
/*      */ 
/*      */   private void queryVmTaskTrans(String parentTaskId, String workflowID, List taskTs) throws Exception {
/*  499 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*  500 */     boolean isPushDataSource = false;
/*      */     try {
/*  502 */       String queueID = IDAssembleUtil.unwrapPrefix(workflowID);
/*  503 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  504 */       StringBuffer cond = new StringBuffer(" 1=1 ");
/*  505 */       HashMap param = new HashMap();
/*  506 */       if (!StringUtils.isEmptyString(parentTaskId)) {
/*  507 */         cond.append(" and ").append("PARENT_TASK_ID").append("=:").append("PARENT_TASK_ID");
/*  508 */         param.put("PARENT_TASK_ID", parentTaskId);
/*      */       }
/*  510 */       if (!StringUtils.isEmptyString(workflowID)) {
/*  511 */         cond.append(" and ").append("WORKFLOW_ID").append("=:").append("WORKFLOW_ID");
/*  512 */         param.put("WORKFLOW_ID", workflowID);
/*      */       }
/*  514 */       IBOVmTaskTSValue[] vmTaskTs = taskSv.getVmTaskTSBean(queueID, cond.toString(), param, -1, -1);
/*  515 */       if ((vmTaskTs == null) || (vmTaskTs.length == 0)) {
/*      */         return;
/*      */       }
/*  518 */       for (int i = 0; i < vmTaskTs.length; ++i) {
/*  519 */         taskTs.add(vmTaskTs[i]);
/*  520 */         queryVmTaskTrans(vmTaskTs[i].getTaskId(), vmTaskTs[i].getWorkflowId(), taskTs);
/*      */       }
/*      */     } finally {
/*  523 */       if (isPushDataSource == true)
/*  524 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public DataContainer[] getWorkflowInstVars(String workflowId, String templateTag) throws Exception, RemoteException
/*      */   {
/*  530 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  531 */     WorkflowTemplate template = templateSv.getWorkflowTemplateByTag(templateTag);
/*  532 */     List vars = template.getVars();
/*  533 */     List temp = new ArrayList();
/*  534 */     Map instVars = ComframeClient.getWorkflowVars(workflowId);
/*  535 */     for (int i = 0; i < vars.size(); ++i) {
/*  536 */       ParameterDefine pd = (ParameterDefine)vars.get(i);
/*  537 */       DataContainer dc = new DataContainer();
/*  538 */       dc.set("ATTR_NAME", pd.name);
/*  539 */       dc.set("ATTR_TYPE", pd.dataType);
/*  540 */       dc.set("ATTR_VALUE", instVars.get(pd.name));
/*  541 */       temp.add(dc);
/*      */     }
/*  543 */     return (DataContainer[])(DataContainer[])temp.toArray(new DataContainer[0]);
/*      */   }
/*      */ 
/*      */   public DataContainer[] getTemplateVars(String templateCode) throws Exception, RemoteException {
/*  547 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  548 */     WorkflowTemplate template = templateSv.getWorkflowTemplateByTag(templateCode);
/*      */ 
/*  550 */     if (template == null) {
/*  551 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.templateNotExist") + templateCode);
/*      */     }
/*      */ 
/*  554 */     List vars = template.getVars();
/*  555 */     List temp = new ArrayList();
/*  556 */     for (int i = 0; i < vars.size(); ++i) {
/*  557 */       ParameterDefine pd = (ParameterDefine)vars.get(i);
/*  558 */       if ((!pd.inOutType.equalsIgnoreCase("in")) && (!pd.inOutType.equalsIgnoreCase("inout")))
/*      */         continue;
/*  560 */       DataContainer dc = new DataContainer();
/*  561 */       dc.set("ATTR_NAME", pd.name);
/*  562 */       dc.set("ATTR_TYPE", pd.dataType);
/*  563 */       dc.set("ATTR_VALUE", pd.defaultValue);
/*      */ 
/*  565 */       temp.add(dc);
/*      */     }
/*      */ 
/*  568 */     return (DataContainer[])(DataContainer[])temp.toArray(new DataContainer[0]);
/*      */   }
/*      */ 
/*      */   public DataContainer[] getTemplatesFromDir(String dir, String classpath) throws Exception, RemoteException {
/*  572 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  573 */     String[] templates = templateSV.getTemplateTagFromLocal(dir, classpath);
/*  574 */     DataContainer[] dcs = new DataContainer[templates.length];
/*  575 */     for (int i = 0; i < dcs.length; ++i) {
/*  576 */       dcs[i] = new DataContainer();
/*  577 */       dcs[i].set("TEMPLATE_TAG", templates[i]);
/*      */     }
/*  579 */     return dcs;
/*      */   }
/*      */ 
/*      */   public String publishEngineTemplate(IBOVmTemplateValue[] vmTemplate, Timestamp validDate, Timestamp expireDate, String staffID, String xmlStr)
/*      */     throws Exception, RemoteException
/*      */   {
/*  592 */     String resultMsg = "";
/*      */ 
/*  595 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*      */ 
/*  597 */     Class c = Class.forName(WrapPropertiesUtil.getStringProperties("wrap.core.engine.ComframeCallEngine"));
/*  598 */     Method m = c.getMethod("deployEngineTemplate", new Class[] { String.class, String.class });
/*  599 */     Object instance = c.newInstance();
/*  600 */     IBOVmEngineTemplateVersionValue[] engineTemplates = new BOVmEngineTemplateVersionBean[vmTemplate.length];
/*  601 */     for (int i = 0; i < vmTemplate.length; ++i) {
/*      */       try {
/*  603 */         templateSv.deployVmTemplate(vmTemplate[i], expireDate, validDate, staffID, xmlStr);
/*      */ 
/*  605 */         IBOVmTemplateValue temp = vmTemplate[i];
/*  606 */         String engineType = temp.getEngineType();
/*  607 */         String workflowTemplateCode = temp.getTemplateTag();
/*  608 */         m.invoke(instance, new Object[] { workflowTemplateCode, engineType });
/*  609 */         if ("Y".equals(vmTemplate[i].getPublish())) {
/*  610 */           engineTemplates[i] = new BOVmEngineTemplateVersionBean();
/*  611 */           engineTemplates[i].setStsToNew();
/*  612 */           engineTemplates[i].setEngineTemplateId(temp.getTemplateTag());
/*  613 */           Timestamp now = TimeUtil.getSysTime();
/*  614 */           engineTemplates[i].setCreateDate(now);
/*  615 */           engineTemplates[i].setEngineVerion("" + now.getTime());
/*  616 */           templateSv.saveVmEngineTemplateVersionValue(engineTemplates[i]);
/*      */         }
/*      */       } catch (Exception e) {
/*  619 */         e.printStackTrace();
/*  620 */         log.error("Deploy template(" + vmTemplate[i].getTemplateTag() + ")failed:" + e.getMessage());
/*  621 */         if (resultMsg.equals(""))
/*  622 */           resultMsg = vmTemplate[i].getTemplateTag();
/*      */         else {
/*  624 */           resultMsg = resultMsg + "," + vmTemplate[i].getTemplateTag();
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  630 */     if (!resultMsg.equals(""))
/*  631 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_templateDeployFailed") + resultMsg;
/*      */     else {
/*  633 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_vmTemplateDeploySuccess");
/*      */     }
/*  635 */     return resultMsg;
/*      */   }
/*      */ 
/*      */   public String publishTemplates(IBOVmTemplateValue[] vmTemplate, Timestamp validDate, Timestamp expireDate, String staffID, String xmlStr) throws Exception, RemoteException {
/*  639 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  640 */     String resultMsg = "";
/*      */ 
/*  642 */     for (int i = 0; i < vmTemplate.length; ++i) {
/*      */       try {
/*  644 */         templateSv.deployVmTemplate(vmTemplate[i], expireDate, validDate, staffID, xmlStr);
/*      */       }
/*      */       catch (Exception e) {
/*  647 */         log.error("Get Templates(" + vmTemplate[i].getTemplateTag() + ")Failed:" + e.getMessage());
/*  648 */         if (resultMsg.equals("")) {
/*  649 */           resultMsg = vmTemplate[i].getTemplateTag();
/*      */         }
/*      */         else {
/*  652 */           resultMsg = resultMsg + "," + vmTemplate[i].getTemplateTag();
/*      */         }
/*      */       }
/*      */     }
/*  656 */     if (!resultMsg.equals(""))
/*  657 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_templateDeployFailed") + resultMsg;
/*      */     else {
/*  659 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_vmTemplateDeploySuccess");
/*      */     }
/*  661 */     return resultMsg;
/*      */   }
/*      */ 
/*      */   public String publishCommercialTemplates(long[] templateId, String[] templateNames, Timestamp validDate, String notes, String EngineType) throws Exception, RemoteException {
/*  665 */     String resultMsg = "";
/*  666 */     for (int i = 0; i < templateNames.length; ++i) {
/*      */       try {
/*  668 */         publishCommercialTemplate(templateId[i], templateNames[i], validDate, notes, EngineType);
/*      */       }
/*      */       catch (Exception e) {
/*  671 */         log.error("Deploy template(" + templateNames[i] + ")failed:" + e.getMessage());
/*  672 */         if (resultMsg.equals("")) {
/*  673 */           resultMsg = templateNames[i];
/*      */         }
/*      */         else {
/*  676 */           resultMsg = resultMsg + "," + templateNames[i];
/*      */         }
/*      */       }
/*      */     }
/*  680 */     if (!resultMsg.equals("")) {
/*  681 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_templateDeployFailed") + resultMsg;
/*      */     }
/*      */     else {
/*  684 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.impl.WorkflowConsoleImpl.publishTemplates_templateDeploySuccess");
/*      */     }
/*  686 */     return resultMsg;
/*      */   }
/*      */ 
/*      */   public void publishCommercialTemplate(long templateId, String template, Timestamp validDate, String notes, String EngineType)
/*      */     throws Exception, RemoteException
/*      */   {
/*      */   }
/*      */ 
/*      */   public String getWorkflowInsPopMenu(String workflowstate)
/*      */   {
/*  902 */     String[][] tmpss = Constant.WORKFLOW_ACTION;
/*  903 */     String result = "[";
/*  904 */     for (int i = 0; i < tmpss.length; ++i) {
/*  905 */       boolean isEnable = false;
/*  906 */       if ((tmpss[i][2] == null) || (tmpss[i][2].equals(""))) {
/*  907 */         isEnable = true;
/*      */       }
/*      */       else {
/*  910 */         String[] stss = StringUtils.split(tmpss[i][2], ',');
/*  911 */         for (int j = 0; j < stss.length; ++j) {
/*  912 */           if (stss[j].equalsIgnoreCase(workflowstate) == true) {
/*  913 */             isEnable = true;
/*  914 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  918 */       if (i > 0) {
/*  919 */         result = result + ",";
/*      */       }
/*  921 */       result = result + "{id:'menu" + (i + 1) + "',enable:'" + isEnable + "',name:'" + tmpss[i][1] + "',func:'" + tmpss[i][0] + "'}";
/*      */     }
/*  923 */     result = result + "]";
/*  924 */     return result;
/*      */   }
/*      */ 
/*      */   public String getWorkflowTaskInsPopMenu(String wokflowstate, String taskstate) {
/*  928 */     String[][] tmpss = Constant.TASK_ACTION;
/*  929 */     String result = "[";
/*  930 */     for (int i = 0; i < tmpss.length; ++i) {
/*  931 */       boolean isEnable = false;
/*      */ 
/*  935 */       if ((tmpss[i][2] == null) || (tmpss[i][2].equals(""))) {
/*  936 */         isEnable = true;
/*      */       }
/*      */       else {
/*  939 */         String[] stss = StringUtils.split(tmpss[i][2], ',');
/*  940 */         for (int j = 0; j < stss.length; ++j) {
/*  941 */           if (stss[j].equalsIgnoreCase(wokflowstate) == true) {
/*  942 */             isEnable = true;
/*  943 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  947 */       if (isEnable == true) {
/*  948 */         if ((tmpss[i][3] == null) || (tmpss[i][3].equals(""))) {
/*  949 */           isEnable = true;
/*      */         }
/*      */         else {
/*  952 */           String[] stss = StringUtils.split(tmpss[i][3], ',');
/*  953 */           isEnable = false;
/*  954 */           for (int j = 0; j < stss.length; ++j) {
/*  955 */             if (stss[j].equalsIgnoreCase(taskstate) == true) {
/*  956 */               isEnable = true;
/*  957 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  962 */       if (i > 0) {
/*  963 */         result = result + ",";
/*      */       }
/*  965 */       result = result + "{id:'menu" + (i + 1) + "',enable:'" + isEnable + "',name:'" + tmpss[i][1] + "',func:'" + tmpss[i][0] + "'}";
/*      */     }
/*      */ 
/*  968 */     result = result + "]";
/*  969 */     return result;
/*      */   }
/*      */ 
/*      */   public String getWorkflowTaskTransInsPopMenu(String wokflowstate, String taskstate) {
/*  973 */     String[][] tmpss = Constant.TASKTRANS_ACTION;
/*  974 */     String result = "[";
/*  975 */     for (int i = 0; i < tmpss.length; ++i) {
/*  976 */       boolean isEnable = false;
/*  977 */       if ((tmpss[i][2] == null) || (tmpss[i][2].equals(""))) {
/*  978 */         isEnable = true;
/*      */       }
/*      */       else {
/*  981 */         String[] stss = StringUtils.split(tmpss[i][2], ',');
/*  982 */         for (int j = 0; j < stss.length; ++j) {
/*  983 */           if (stss[j].equalsIgnoreCase(wokflowstate) == true) {
/*  984 */             isEnable = true;
/*  985 */             break;
/*      */           }
/*      */         }
/*      */       }
/*  989 */       if (isEnable == true) {
/*  990 */         if ((tmpss[i][3] == null) || (tmpss[i][3].equals(""))) {
/*  991 */           isEnable = true;
/*      */         }
/*      */         else {
/*  994 */           String[] stss = StringUtils.split(tmpss[i][3], ',');
/*  995 */           isEnable = false;
/*  996 */           for (int j = 0; j < stss.length; ++j) {
/*  997 */             if (stss[j].equalsIgnoreCase(taskstate) == true) {
/*  998 */               isEnable = true;
/*  999 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1004 */       if (i > 0) {
/* 1005 */         result = result + ",";
/*      */       }
/* 1007 */       result = result + "{id:'menu" + (i + 1) + "',enable:'" + isEnable + "',name:'" + tmpss[i][1] + "',func:'" + tmpss[i][0] + "'}";
/*      */     }
/*      */ 
/* 1010 */     result = result + "]";
/* 1011 */     return result;
/*      */   }
/*      */ 
/*      */   public IBOVmAlarmConfigValue[] getAlarmConfig(String taskTag, String templateTag)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1072 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1073 */     return alarmConfigSV.getAlarmConfig(taskTag, templateTag);
/*      */   }
/*      */ 
/*      */   public IBOVmAlarmConfigValue[] getAlarmConfigs(String templateTag)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1083 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1084 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1085 */     HashMap param = new HashMap();
/* 1086 */     if ((templateTag != null) && (templateTag.length() > 0)) {
/* 1087 */       cond.append(" and ").append("TEMPLATE_TAG").append(" = :").append("TEMPLATE_TAG");
/* 1088 */       param.put("TEMPLATE_TAG", templateTag);
/*      */     }
/*      */ 
/* 1091 */     return alarmConfigSV.getAlarmConfigs(cond.toString(), param);
/*      */   }
/*      */ 
/*      */   public java.util.Date[] getHolidayList()
/*      */     throws RemoteException, Exception
/*      */   {
/* 1100 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1101 */     return alarmConfigSV.getHolidayList();
/*      */   }
/*      */ 
/*      */   public IBOVmHoliDayValue[] getHolidayValue()
/*      */     throws RemoteException, Exception
/*      */   {
/* 1110 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1111 */     return alarmConfigSV.getHolidayValue();
/*      */   }
/*      */ 
/*      */   public void saveAlarmConfig(IBOVmAlarmConfigValue[] values)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1120 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1121 */     alarmConfigSV.saveAlarmConfig(values);
/*      */   }
/*      */ 
/*      */   public void saveHolidayConfig(IBOVmHoliDayValue[] beans)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1130 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1131 */     alarmConfigSV.saveHolidayConfig(beans);
/*      */   }
/*      */ 
/*      */   public void updateWarning(String taskId, Timestamp date, int alarmTimes, String type)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1142 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1143 */     alarmConfigSV.updateWarning(taskId, date, alarmTimes, type);
/*      */   }
/*      */ 
/*      */   public String[][] getAllDataSources() throws Exception, RemoteException
/*      */   {
/* 1148 */     return (String[][])null;
/*      */   }
/*      */ 
/*      */   public String[] getCenterIds() throws Exception, RemoteException
/*      */   {
/* 1153 */     return null;
/*      */   }
/*      */ 
/*      */   public String[] getDataSources() throws Exception, RemoteException
/*      */   {
/* 1158 */     return null;
/*      */   }
/*      */ 
/*      */   public IBOVmTemplateValue[] getPublishedVMTemplates(String taskTag)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1165 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean jumpToTask(long currentTaskId, long goBackTaskTemplateId, String staffId, String reason, Map vars)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1172 */     return false;
/*      */   }
/*      */ 
/*      */   public String publishLocalToCommer(String[] template, Timestamp validDate, String notes, String EngineType)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1181 */     return null;
/*      */   }
/*      */ 
/*      */   public void publishLocalToCommerSingle(FileItem fileItem, Timestamp validDate, String notes, String EngineType)
/*      */     throws Exception, RemoteException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void publishLocalToCommerSingle(String templateXmlStr, Timestamp validDate, String notes, String EngineType)
/*      */     throws Exception, RemoteException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void publishLocalToCommerSingle(String templateXmlStr, Timestamp validDate, String notes, String engineType, String taskTag)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1200 */     System.out.println("in method publishLocalToCommerSingle");
/*      */ 
/* 1205 */     Class factoryClass = Class.forName("com.ai.comframe.wrap.core.ComframeWrapFactory");
/* 1206 */     Method factoryMethod = factoryClass.getMethod("getComframeCallEngineInstance", new Class[] { String.class });
/* 1207 */     Object engineObj = factoryMethod.invoke(factoryClass.newInstance(), new Object[] { engineType });
/*      */ 
/* 1209 */     Class engineClass = engineObj.getClass();
/* 1210 */     Method engineMethod = engineClass.getMethod("deployEngineTemplate", new Class[] { String.class });
/* 1211 */     engineMethod.invoke(factoryClass.newInstance(), new Object[] { taskTag });
/*      */   }
/*      */ 
/*      */   public void publishTemplate(String templateXmlStr, Timestamp validDate, String notes)
/*      */     throws Exception, RemoteException
/*      */   {
/*      */   }
/*      */ 
/*      */   public IBOVmTemplateValue[] getVmTemplates(String queueID, String templateTag, String templateType, int $startrowindex, int $endrowindex)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1231 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1232 */     StringBuffer cond = new StringBuffer();
/* 1233 */     HashMap param = new HashMap();
/* 1234 */     cond.append(" 1=1 ");
/* 1235 */     if ((queueID != null) && (queueID.length() > 0)) {
/* 1236 */       cond.append(" and ").append("QUEUE_ID").append(" =:").append("QUEUE_ID");
/* 1237 */       param.put("QUEUE_ID", queueID);
/*      */     }
/* 1239 */     if ((templateTag != null) && (templateTag.length() > 0)) {
/* 1240 */       cond.append(" and ").append("TEMPLATE_TAG").append(" like :").append("TEMPLATE_TAG");
/* 1241 */       param.put("TEMPLATE_TAG", templateTag + "%");
/*      */     }
/* 1243 */     if ((templateType != null) && (templateType.length() > 0) && (!"-1".equals(templateType))) {
/* 1244 */       cond.append(" and ").append("TEMPLATE_TYPE").append(" =:").append("TEMPLATE_TYPE");
/* 1245 */       param.put("TEMPLATE_TYPE", templateType);
/*      */     }
/*      */ 
/* 1248 */     return templateSv.getVmTemplates(cond.toString(), param, $startrowindex, $endrowindex);
/*      */   }
/*      */ 
/*      */   public int getVmTemplatesCount(String queueID, String templateTag, String templateType) throws Exception, RemoteException
/*      */   {
/* 1253 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1254 */     StringBuffer cond = new StringBuffer();
/* 1255 */     HashMap param = new HashMap();
/* 1256 */     cond.append(" 1=1 ");
/* 1257 */     if ((queueID != null) && (queueID.length() > 0)) {
/* 1258 */       cond.append(" and ").append("QUEUE_ID").append(" =:").append("QUEUE_ID");
/* 1259 */       param.put("QUEUE_ID", queueID);
/*      */     }
/* 1261 */     if ((templateTag != null) && (templateTag.length() > 0)) {
/* 1262 */       cond.append(" and ").append("TEMPLATE_TAG").append(" like :").append("TEMPLATE_TAG");
/* 1263 */       param.put("TEMPLATE_TAG", templateTag + "%");
/*      */     }
/* 1265 */     if ((templateType != null) && (templateType.length() > 0) && (!"-1".equals(templateType))) {
/* 1266 */       cond.append(" and ").append("TEMPLATE_TYPE").append(" =:").append("TEMPLATE_TYPE");
/* 1267 */       param.put("TEMPLATE_TYPE", templateType);
/*      */     }
/* 1269 */     return templateSv.getVmTemplatesCount(cond.toString(), param);
/*      */   }
/*      */ 
/*      */   public IBOVmTemplateVersionValue[] getAllTemplateVersionByTag(String templateTag) throws Exception, RemoteException {
/* 1273 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1274 */     StringBuffer cond = new StringBuffer();
/* 1275 */     HashMap param = new HashMap();
/* 1276 */     if ((templateTag != null) && (templateTag.length() > 0)) {
/* 1277 */       cond.append("TEMPLATE_TAG").append("=:").append("TEMPLATE_TAG");
/* 1278 */       param.put("TEMPLATE_TAG", templateTag);
/*      */     }
/* 1280 */     return templateSv.getVmTemplateVersion(cond.toString(), param);
/*      */   }
/*      */ 
/*      */   public IQBOVmTemplateValue[] getPublishedTemplates(String queueID, String taskTag, String sValidDate, String eValidDate, int $STARTROWINDEX, int $ENDROWINDEX) throws RemoteException, Exception {
/* 1284 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1285 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1286 */     HashMap param = new HashMap();
/* 1287 */     if ((queueID != null) && (queueID.length() > 0)) {
/* 1288 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/* 1289 */       param.put("QUEUE_ID", queueID);
/*      */     }
/* 1291 */     if ((taskTag != null) && (taskTag.length() > 0)) {
/* 1292 */       cond.append(" and ").append("TEMPLATE_TAG").append(" like :").append("TEMPLATE_TAG");
/* 1293 */       param.put("TEMPLATE_TAG", taskTag + "%");
/*      */     }
/* 1295 */     if ((sValidDate != null) && (sValidDate.length() > 0)) {
/* 1296 */       cond.append(" and ").append("VALID_DATE").append(" > :S").append("VALID_DATE");
/* 1297 */       param.put("SVALID_DATE", Timestamp.valueOf(sValidDate));
/*      */     }
/*      */ 
/* 1300 */     if ((eValidDate != null) && (eValidDate.length() > 0)) {
/* 1301 */       cond.append(" and ").append("VALID_DATE").append(" < :E").append("VALID_DATE");
/* 1302 */       param.put("EVALID_DATE", Timestamp.valueOf(eValidDate));
/*      */     }
/* 1304 */     return templateSv.getPublishedTemplates(cond.toString(), param, $STARTROWINDEX, $ENDROWINDEX);
/*      */   }
/*      */ 
/*      */   public int getPublishedTemplatesCount(String queueID, String taskTag, String sValidDate, String eValidDate) throws RemoteException, Exception
/*      */   {
/* 1309 */     ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1310 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1311 */     HashMap param = new HashMap();
/* 1312 */     if ((queueID != null) && (queueID.length() > 0)) {
/* 1313 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/* 1314 */       param.put("QUEUE_ID", queueID);
/*      */     }
/* 1316 */     if ((taskTag != null) && (taskTag.length() > 0)) {
/* 1317 */       cond.append(" and ").append("TEMPLATE_TAG").append(" like :").append("TEMPLATE_TAG");
/* 1318 */       param.put("TEMPLATE_TAG", taskTag + "%");
/*      */     }
/* 1320 */     if ((sValidDate != null) && (sValidDate.length() > 0)) {
/* 1321 */       cond.append(" and ").append("VALID_DATE").append(" > :S").append("VALID_DATE");
/* 1322 */       param.put("SVALID_DATE", Timestamp.valueOf(sValidDate));
/*      */     }
/*      */ 
/* 1325 */     if ((eValidDate != null) && (eValidDate.length() > 0)) {
/* 1326 */       cond.append(" and ").append("VALID_DATE").append(" < :E").append("VALID_DATE");
/* 1327 */       param.put("EVALID_DATE", Timestamp.valueOf(eValidDate));
/*      */     }
/* 1329 */     return templateSv.getPublishedTemplatesCount(cond.toString(), param);
/*      */   }
/*      */ 
/*      */   public IQBOVmTaskInfoValue[] getTaskInfo(String queueID, String stations, String staffId, String state, String orderId, int $STARTROWINDEX, int $ENDROWINDEX) throws RemoteException, Exception {
/* 1333 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1334 */     HashMap param = new HashMap();
/* 1335 */     if (!StringUtils.isEmptyString(queueID)) {
/* 1336 */       cond.append(" and ").append("QUEUE_ID").append(" = :").append("QUEUE_ID");
/* 1337 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/* 1340 */     if (!StringUtils.isEmptyString(stations)) {
/* 1341 */       cond.append(" and ").append("STATION_ID").append(" = :").append("STATION_ID");
/* 1342 */       param.put("STATION_ID", stations);
/*      */     }
/*      */ 
/* 1345 */     if (!StringUtils.isEmptyString(staffId)) {
/* 1346 */       cond.append(" and ").append("TASK_STAFF_ID").append(" = :").append("TASK_STAFF_ID");
/* 1347 */       param.put("TASK_STAFF_ID", staffId);
/*      */     }
/*      */ 
/* 1354 */     if (!StringUtils.isEmptyString(orderId)) {
/* 1355 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :").append("WORKFLOW_OBJECT_ID");
/* 1356 */       param.put("WORKFLOW_OBJECT_ID", orderId);
/*      */     }
/*      */ 
/* 1359 */     cond.append(" and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") ");
/*      */ 
/* 1362 */     TaskInfo[] infos = ComframeClient.getTaskInfos(queueID, cond.toString(), param, $STARTROWINDEX, $ENDROWINDEX);
/* 1363 */     return TaskInfoHelper.transerToQvalue(infos);
/*      */   }
/*      */ 
/*      */   public int getTaskInfoCount(String queueID, String stations, String staffId, String state, String orderId) throws RemoteException, Exception {
/* 1367 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1368 */     HashMap param = new HashMap();
/* 1369 */     if (!StringUtils.isEmptyString(queueID)) {
/* 1370 */       cond.append(" and ").append("QUEUE_ID").append(" = :").append("QUEUE_ID");
/* 1371 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/* 1374 */     if (!StringUtils.isEmptyString(stations)) {
/* 1375 */       cond.append(" and ").append("STATION_ID").append(" = :").append("STATION_ID");
/* 1376 */       param.put("STATION_ID", stations);
/*      */     }
/*      */ 
/* 1379 */     if (!StringUtils.isEmptyString(staffId)) {
/* 1380 */       cond.append(" and ").append("TASK_STAFF_ID").append(" = :").append("TASK_STAFF_ID");
/* 1381 */       param.put("TASK_STAFF_ID", staffId);
/*      */     }
/*      */ 
/* 1389 */     if (!StringUtils.isEmptyString(orderId)) {
/* 1390 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :").append("WORKFLOW_OBJECT_ID");
/* 1391 */       param.put("WORKFLOW_OBJECT_ID", orderId);
/*      */     }
/*      */ 
/* 1394 */     cond.append(" and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") ");
/*      */ 
/* 1397 */     return ComframeClient.getTaskCount(queueID, cond.toString(), param);
/*      */   }
/*      */ 
/*      */   public IBOHVmWFValue[] queryHisWorkflow(String sdate, String regionID, String queueID, String workflowObjectId, String busiOrderType, int state, String startTime, String endTime, int startIndex, int endIndex) throws Exception, RemoteException {
/* 1401 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1402 */     HashMap param = new HashMap();
/* 1403 */     if (!StringUtils.isEmptyString(regionID)) {
/* 1404 */       cond.append(" and ").append("REGION_ID").append("=:").append("REGION_ID");
/* 1405 */       param.put("REGION_ID", regionID);
/*      */     }
/*      */ 
/* 1408 */     if (!StringUtils.isEmptyString(queueID)) {
/* 1409 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/* 1410 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/* 1413 */     if (!StringUtils.isEmptyString(workflowObjectId)) {
/* 1414 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append("=:").append("WORKFLOW_OBJECT_ID");
/* 1415 */       param.put("WORKFLOW_OBJECT_ID", workflowObjectId);
/*      */     }
/* 1417 */     if (!StringUtils.isEmptyString(busiOrderType)) {
/* 1418 */       cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append("=:").append("WORKFLOW_OBJECT_TYPE");
/* 1419 */       param.put("WORKFLOW_OBJECT_TYPE", busiOrderType);
/*      */     }
/*      */ 
/* 1422 */     if (!StringUtils.isEmptyString(startTime)) {
/* 1423 */       cond.append(" and ").append("CREATE_DATE").append("> :aStartDate ");
/* 1424 */       param.put("aStartDate", Timestamp.valueOf(startTime));
/*      */     }
/*      */ 
/* 1427 */     if (!StringUtils.isEmptyString(endTime)) {
/* 1428 */       cond.append(" and ").append("CREATE_DATE").append("< :aEndDate");
/* 1429 */       param.put("aEndDate", Timestamp.valueOf(endTime));
/*      */     }
/*      */ 
/* 1432 */     if (state != -1)
/*      */     {
/* 1434 */       cond.append(" and ").append("STATE").append("=:").append("STATE");
/* 1435 */       param.put("STATE", String.valueOf(state));
/*      */     }
/* 1437 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 1438 */     boolean isPushDataSource = false;
/*      */     try {
/* 1440 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1441 */       IBOHVmWFValue[] arrayOfIBOHVmWFValue = workflowSv.getHisWorkflowBeans(queueID, cond.toString(), param, startIndex, endIndex, sdate);
/*      */ 
/* 1445 */       return arrayOfIBOHVmWFValue;
/*      */     }
/*      */     finally
/*      */     {
/* 1443 */       if (isPushDataSource)
/* 1444 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getHVmWorkflowCount(String sdate, String regionID, String queueID, String busiOrderId, String busiOrderType, int state, String startTime, String endTime) throws Exception, RemoteException {
/* 1449 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1450 */     HashMap param = new HashMap();
/*      */ 
/* 1452 */     if (!StringUtils.isEmptyString(regionID)) {
/* 1453 */       cond.append(" and ").append("REGION_ID").append("=:").append("REGION_ID");
/* 1454 */       param.put("REGION_ID", regionID);
/*      */     }
/*      */ 
/* 1457 */     if (!StringUtils.isEmptyString(queueID)) {
/* 1458 */       cond.append(" and ").append("QUEUE_ID").append("=:").append("QUEUE_ID");
/* 1459 */       param.put("QUEUE_ID", queueID);
/*      */     }
/*      */ 
/* 1462 */     if (!StringUtils.isEmptyString(busiOrderId)) {
/* 1463 */       cond.append(" and ").append("WORKFLOW_OBJECT_ID").append("=:").append("WORKFLOW_OBJECT_ID");
/* 1464 */       param.put("WORKFLOW_OBJECT_ID", busiOrderId);
/*      */     }
/* 1466 */     if (!StringUtils.isEmptyString(busiOrderType)) {
/* 1467 */       cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append("=:").append("WORKFLOW_OBJECT_TYPE");
/* 1468 */       param.put("WORKFLOW_OBJECT_TYPE", busiOrderType);
/*      */     }
/*      */ 
/* 1471 */     if (!StringUtils.isEmptyString(startTime)) {
/* 1472 */       cond.append(" and ").append("CREATE_DATE").append("> :aStartDate ");
/* 1473 */       param.put("aStartDate", Timestamp.valueOf(startTime));
/*      */     }
/*      */ 
/* 1476 */     if (!StringUtils.isEmptyString(endTime)) {
/* 1477 */       cond.append(" and ").append("CREATE_DATE").append("< :aEndDate");
/* 1478 */       param.put("aEndDate", Timestamp.valueOf(endTime));
/*      */     }
/*      */ 
/* 1481 */     if (state != -1)
/*      */     {
/* 1483 */       cond.append(" and ").append("STATE").append("=:").append("STATE");
/* 1484 */       param.put("STATE", String.valueOf(state));
/*      */     }
/* 1486 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 1487 */     boolean isPushDataSource = false;
/*      */     try {
/* 1489 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1490 */       int i = workflowSv.getHisWorkflowBeansCount(queueID, cond.toString(), param, sdate);
/*      */ 
/* 1494 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1492 */       if (isPushDataSource == true)
/* 1493 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOHVmTaskValue[] queryHVmTask(java.sql.Date sdate, String workflowId, int workflowState)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1506 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 1507 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/* 1508 */     boolean isPushDataSource = false;
/*      */     try {
/* 1510 */       String tmpdate = DateUtil.formatDate(sdate, "yyyyMM");
/* 1511 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1512 */       StringBuffer cond = new StringBuffer();
/* 1513 */       HashMap param = new HashMap();
/* 1514 */       if (!StringUtils.isEmptyString(workflowId)) {
/* 1515 */         cond.append("WORKFLOW_ID").append("=:").append("WORKFLOW_ID");
/* 1516 */         param.put("WORKFLOW_ID", workflowId);
/*      */       }
/* 1518 */       IBOHVmTaskValue[] arrayOfIBOHVmTaskValue = taskSv.getHisVmTaskBean(queueID, cond.toString(), param, -1, -1, tmpdate);
/*      */ 
/* 1522 */       return arrayOfIBOHVmTaskValue;
/*      */     }
/*      */     finally
/*      */     {
/* 1520 */       if (isPushDataSource == true)
/* 1521 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOHVmTaskTSValue[] queryHVmTaskTrans(java.sql.Date sdate, String parentTaskId, String workflowId)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1534 */     List taskTs = new ArrayList();
/* 1535 */     String tmpdate = DateUtil.formatDate(sdate, "yyyyMM");
/* 1536 */     queryHVmTaskTrans(parentTaskId, workflowId, taskTs, tmpdate);
/*      */ 
/* 1540 */     return (IBOHVmTaskTSValue[])(IBOHVmTaskTSValue[])taskTs.toArray(new IBOHVmTaskTSValue[0]);
/*      */   }
/*      */ 
/*      */   private void queryHVmTaskTrans(String parentTaskId, String workflowID, List taskTs, String sdate) throws Exception {
/* 1544 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 1545 */     boolean isPushDataSource = false;
/*      */     try {
/* 1547 */       String queueID = IDAssembleUtil.unwrapPrefix(workflowID);
/* 1548 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1549 */       StringBuffer cond = new StringBuffer(" 1=1 ");
/* 1550 */       HashMap param = new HashMap();
/* 1551 */       if (!StringUtils.isEmptyString(parentTaskId)) {
/* 1552 */         cond.append(" and ").append("PARENT_TASK_ID").append("=:").append("PARENT_TASK_ID");
/* 1553 */         param.put("PARENT_TASK_ID", parentTaskId);
/*      */       }
/* 1555 */       if (!StringUtils.isEmptyString(workflowID)) {
/* 1556 */         cond.append(" and ").append("WORKFLOW_ID").append("=:").append("WORKFLOW_ID");
/* 1557 */         param.put("WORKFLOW_ID", workflowID);
/*      */       }
/* 1559 */       IBOHVmTaskTSValue[] vmTaskTs = taskSv.getHisVmTaskTSBean(queueID, cond.toString(), param, -1, -1, sdate);
/* 1560 */       if ((vmTaskTs == null) || (vmTaskTs.length == 0)) {
/*      */         return;
/*      */       }
/* 1563 */       for (int i = 0; i < vmTaskTs.length; ++i) {
/* 1564 */         taskTs.add(vmTaskTs[i]);
/* 1565 */         queryHVmTaskTrans(vmTaskTs[i].getTaskId(), vmTaskTs[i].getWorkflowId(), taskTs, sdate);
/*      */       }
/*      */     } finally {
/* 1568 */       if (isPushDataSource == true)
/* 1569 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[][] getDefaultPeriod() throws Exception {
/* 1574 */     String[] tmp = AssembleDef.getDefautTimePeriod();
/* 1575 */     String[][] result = new String[tmp.length][2];
/* 1576 */     for (int i = 0; i < tmp.length; ++i) {
/* 1577 */       result[i][0] = tmp[i];
/* 1578 */       result[i][1] = tmp[i];
/*      */     }
/* 1580 */     return result;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.WorkflowConsoleSVImpl
 * JD-Core Version:    0.5.4
 */