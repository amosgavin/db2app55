package com.ai.comframe.config.service.interfaces;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
import com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue;
import com.ai.comframe.queue.QueueParam;
import java.rmi.RemoteException;

public abstract interface IVmQueueConfigSV
{
  public abstract IBOVmQueueConfigValue[] getAllVmQueueConfigs()
    throws RemoteException, Exception;

  public abstract IBOVmQueueConfigValue getVmQueueConfig(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract String[] getAllDistinctVmQueueID()
    throws RemoteException, Exception;

  public abstract DataContainerInterface[] getAllDistinctVmQueueList()
    throws RemoteException, Exception;

  public abstract IBOVmWorkflowObjectValue[] getAllVmWorkflowObject()
    throws RemoteException, Exception;

  public abstract void insertVMQueueServer(QueueParam paramQueueParam)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.IVmQueueConfigSV
 * JD-Core Version:    0.5.4
 */