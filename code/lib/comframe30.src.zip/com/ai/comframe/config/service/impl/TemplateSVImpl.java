/*     */ package com.ai.comframe.config.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.ClassLoaderUtil;
/*     */ import com.ai.appframe2.common.Util;
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.FileUtils;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import com.ai.appframe2.util.resource.ClasspathResourceLoading;
/*     */ import com.ai.appframe2.util.resource.Resource;
/*     */ import com.ai.comframe.cache.VmTemplateCacheImpl;
/*     */ import com.ai.comframe.cache.VmTemplateVersionCacheImpl;
/*     */ import com.ai.comframe.client.WorkflowTemplateInfo;
/*     */ import com.ai.comframe.config.bo.BOVmTemplateVersionBean;
/*     */ import com.ai.comframe.config.dao.interfaces.IVmTemplateDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*     */ import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.utils.WrapPropertiesUtil;
/*     */ import com.ai.comframe.vm.common.VMUtil;
/*     */ import com.ai.comframe.vm.common.VMUtilDojo;
/*     */ import com.ai.comframe.vm.template.VMClassTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.impl.VMClassTemplateImpl;
/*     */ import com.ai.comframe.vm.template.impl.WorkflowTemplateImpl;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TemplateSVImpl
/*     */   implements ITemplateSV
/*     */ {
/*  57 */   private static final Log log = LogFactory.getLog(TemplateSVImpl.class);
/*     */ 
/*     */   public String getEngineType(String templateTag) throws RemoteException, Exception {
/*  60 */     String engineType = null;
/*  61 */     Object obj = CacheFactory.get(VmTemplateCacheImpl.class, templateTag);
/*  62 */     if (obj != null) {
/*  63 */       engineType = ((IBOVmTemplateValue)obj).getEngineType();
/*     */     } else {
/*  65 */       IVmTemplateDAO td = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/*  66 */       IBOVmTemplateValue tmpVmTemplate = td.getVmTemplateByTag(templateTag);
/*  67 */       engineType = tmpVmTemplate.getEngineType();
/*     */     }
/*     */ 
/*  70 */     if (StringUtils.isEmptyString(engineType)) {
/*  71 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.WorkflowTemplateFactory.getAllTemplateTags.queueid") + templateTag);
/*     */     }
/*  73 */     return engineType;
/*     */   }
/*     */ 
/*     */   public String[] getAllTemplateTags() throws RemoteException, Exception {
/*  77 */     IBOVmTemplateValue[] templateValues = getAllVmTemplateFromCache();
/*  78 */     if (templateValues == null) {
/*  79 */       return null;
/*     */     }
/*  81 */     String[] ret = new String[templateValues.length];
/*  82 */     for (int i = 0; i < templateValues.length; ++i) {
/*  83 */       ret[i] = templateValues[i].getTemplateTag();
/*     */     }
/*  85 */     return ret;
/*     */   }
/*     */ 
/*     */   public String getQueueId(String templateTag) throws RemoteException, Exception {
/*  89 */     String queueId = null;
/*  90 */     Object obj = CacheFactory.get(VmTemplateCacheImpl.class, templateTag);
/*  91 */     if (obj != null) {
/*  92 */       queueId = ((IBOVmTemplateValue)obj).getQueueId();
/*     */     } else {
/*  94 */       IVmTemplateDAO td = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/*  95 */       IBOVmTemplateValue tmpVmTemplate = td.getVmTemplateByTag(templateTag);
/*  96 */       queueId = tmpVmTemplate.getQueueId();
/*     */     }
/*     */ 
/*  99 */     if (StringUtils.isEmptyString(queueId)) {
/* 100 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.WorkflowTemplateFactory.getAllTemplateTags.queueid") + templateTag);
/*     */     }
/* 102 */     return queueId;
/*     */   }
/*     */ 
/*     */   public boolean isVmEngineType(String engineType) throws RemoteException, Exception
/*     */   {
/* 107 */     return "VM".equals(engineType);
/*     */   }
/*     */ 
/*     */   public boolean isPublish(String templateTag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 113 */     String publish = "";
/* 114 */     Object obj = CacheFactory.get(VmTemplateCacheImpl.class, templateTag);
/* 115 */     if (obj != null) {
/* 116 */       publish = ((IBOVmTemplateValue)obj).getPublish();
/*     */     } else {
/* 118 */       IVmTemplateDAO td = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 119 */       IBOVmTemplateValue tmpVmTemplate = td.getVmTemplateByTag(templateTag);
/* 120 */       publish = tmpVmTemplate.getPublish();
/*     */     }
/*     */ 
/* 123 */     return "Y".equals(publish);
/*     */   }
/*     */ 
/*     */   public String[] getTemplateTagFromLocal(String dir, String classpath)
/*     */     throws RemoteException, Exception
/*     */   {
/* 134 */     String S_FILE_TYPE = "wvm";
/* 135 */     SortedSet set = new TreeSet();
/* 136 */     if ("classpath".equals(classpath)) {
/* 137 */       ClasspathResourceLoading.clear();
/* 138 */       String[] paths = ClassLoaderUtil.getClassPath().split(File.pathSeparator);
/* 139 */       for (int i = 0; i < paths.length; ++i) {
/* 140 */         if ((paths[i] != null) && (paths[i].trim().length() > 0)) {
/* 141 */           if ((!"classpath".equals(dir)) && (dir != null) && (dir.length() > 0) && 
/* 142 */             (paths[i].indexOf(dir) == -1)) {
/*     */             continue;
/*     */           }
/*     */ 
/* 146 */           ClasspathResourceLoading.addPath(paths[i]);
/*     */         }
/*     */       }
/* 149 */       Resource[] resources = ClasspathResourceLoading.loadAllClassPathResources("." + S_FILE_TYPE);
/* 150 */       if ((resources == null) || (resources.length == 0))
/* 151 */         return new String[0];
/* 152 */       for (int i = 0; i < resources.length; ++i)
/* 153 */         set.add(resources[i].getAlias().substring(0, resources[i].getAlias().lastIndexOf("." + S_FILE_TYPE)).replace('/', '.'));
/*     */     }
/*     */     else
/*     */     {
/*     */       try {
/* 158 */         String[] fileNames = FileUtils.getSubFileArrayByName(dir, new String[] { S_FILE_TYPE }, true);
/* 159 */         int begin = dir.length();
/* 160 */         if ((dir.charAt(dir.length() - 1) != '\\') || (dir.charAt(dir.length() - 1) != '/')) {
/* 161 */           begin += 1;
/*     */         }
/* 163 */         for (int i = 0; i < fileNames.length; ++i) {
/* 164 */           fileNames[i] = fileNames[i].substring(begin, fileNames[i].lastIndexOf("." + S_FILE_TYPE));
/* 165 */           fileNames[i] = fileNames[i].replace('/', '.');
/* 166 */           fileNames[i] = fileNames[i].replace('\\', '.');
/* 167 */           set.add(fileNames[i]);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 171 */         throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.WorkflowTemplateFactory.getAllWorkflowNames_getProcessTemplateFailed") + e.getMessage(), e);
/*     */       }
/*     */     }
/* 174 */     return (String[])(String[])set.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue[] loadAllVmTemplate()
/*     */     throws RemoteException, Exception
/*     */   {
/* 180 */     IVmTemplateDAO td = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 181 */     return td.getAllTemplates();
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] loadAllVmTemplateVersion() throws RemoteException, Exception {
/* 185 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 186 */     return templateDao.getAllVmTemplateVersion();
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue[] getAllVmTemplateFromCache() throws RemoteException, Exception {
/* 190 */     IBOVmTemplateValue[] ret = null;
/* 191 */     HashMap allTemplate = CacheFactory.getAll(VmTemplateCacheImpl.class);
/* 192 */     ret = new IBOVmTemplateValue[allTemplate.size()];
/* 193 */     Iterator templates = allTemplate.entrySet().iterator();
/* 194 */     int i = 0;
/* 195 */     while (templates.hasNext()) {
/* 196 */       Map.Entry e = (Map.Entry)templates.next();
/* 197 */       ret[i] = ((IBOVmTemplateValue)e.getValue());
/* 198 */       ++i;
/*     */     }
/* 200 */     return ret;
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] getAllVmTemplateVersionFromCache() throws RemoteException, Exception
/*     */   {
/* 205 */     IBOVmTemplateVersionValue[] ret = null;
/* 206 */     HashMap allTemplateVersion = CacheFactory.getAll(VmTemplateVersionCacheImpl.class);
/* 207 */     if (allTemplateVersion == null) {
/* 208 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_refreshVersion"));
/*     */     }
/* 210 */     ret = new IBOVmTemplateVersionValue[allTemplateVersion.size()];
/* 211 */     Iterator templates = allTemplateVersion.entrySet().iterator();
/* 212 */     int i = 0;
/* 213 */     while (templates.hasNext()) {
/* 214 */       Map.Entry e = (Map.Entry)templates.next();
/* 215 */       ret[i] = ((IBOVmTemplateVersionValue)e.getValue());
/* 216 */       ++i;
/*     */     }
/* 218 */     return ret;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplateByID(long templateID) throws RemoteException, Exception {
/* 222 */     WorkflowTemplate templateInfo = null;
/* 223 */     List curTemplate = new ArrayList();
/* 224 */     HashMap allTemplate = CacheFactory.getAll(VmTemplateVersionCacheImpl.class);
/* 225 */     Iterator templates = allTemplate.entrySet().iterator();
/* 226 */     Timestamp expireDate = null;
/* 227 */     Timestamp validDate = null;
/*     */ 
/* 229 */     while (templates.hasNext()) {
/* 230 */       Map.Entry e = (Map.Entry)templates.next();
/* 231 */       IBOVmTemplateVersionValue version = (IBOVmTemplateVersionValue)e.getValue();
/* 232 */       if (version.getTemplateVersionId() == templateID) {
/* 233 */         curTemplate.add(version);
/* 234 */         expireDate = version.getExpireDate();
/* 235 */         validDate = version.getValidDate();
/*     */       }
/*     */     }
/*     */ 
/* 239 */     if (curTemplate.size() > 0) {
/* 240 */       templateInfo = getWorkflowInfoFromVersion(curTemplate, templateID, expireDate, validDate);
/*     */     }
/*     */ 
/* 243 */     return templateInfo;
/*     */   }
/*     */ 
/*     */   private WorkflowTemplate getWorkflowInfoFromVersion(List curTemplate, long templateID, Timestamp expireDate, Timestamp validDate) {
/* 247 */     String content = getContentFromCache(curTemplate);
/* 248 */     Element root = null;
/*     */     try {
/* 250 */       root = XmlUtil.parseXmlOfString(content);
/*     */     } catch (Exception ex) {
/* 252 */       throw new RuntimeException(ex);
/*     */     }
/* 254 */     WorkflowTemplate result = new WorkflowTemplateImpl(null, null, root);
/* 255 */     result.setTaskTemplateId(templateID);
/* 256 */     result.setExpireDate(expireDate);
/* 257 */     result.setValidDate(validDate);
/* 258 */     return result;
/*     */   }
/*     */ 
/*     */   private String getContentFromCache(List curTemplate) {
/* 262 */     StringBuffer content = new StringBuffer();
/* 263 */     for (int i = 0; i < curTemplate.size(); ++i) {
/* 264 */       content.append(getContents(curTemplate, i));
/*     */     }
/* 266 */     return content.toString();
/*     */   }
/*     */ 
/*     */   public VMClassTemplate getVMClassTemplate(String templateTag) throws RemoteException, Exception {
/* 270 */     boolean isPublish = isPublish(templateTag);
/* 271 */     if (isPublish) {
/* 272 */       return getVMClassTemplateFromCache(templateTag);
/*     */     }
/* 274 */     return getVMClassTemplateFromFile(templateTag);
/*     */   }
/*     */ 
/*     */   private String getContentFromFile(String templateTag) throws Exception {
/* 278 */     String fileName = StringUtils.replace(templateTag, ".", "/") + ".wvm";
/* 279 */     StringBuffer content = new StringBuffer();
/* 280 */     InputStream is = null;
/* 281 */     BufferedReader br = null;
/*     */     try {
/* 283 */       is = Util.getResourceAsStream(WorkflowEngineFactory.class, fileName);
/* 284 */       if (is == null)
/* 285 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.templateNotExist") + templateTag);
/* 286 */       br = new BufferedReader(new InputStreamReader(is));
/* 287 */       String line = null;
/* 288 */       while ((line = br.readLine()) != null)
/* 289 */         content.append(line);
/*     */     }
/*     */     finally {
/* 292 */       if (br != null)
/* 293 */         br.close();
/* 294 */       if (is != null)
/* 295 */         is.close();
/*     */     }
/* 297 */     return content.toString();
/*     */   }
/*     */ 
/*     */   private VMClassTemplate getVMClassTemplateFromFile(String templateTag) throws Exception {
/* 301 */     String fileName = StringUtils.replace(templateTag, ".", "/") + ".cvm";
/* 302 */     URL url = Util.getResource(super.getClass(), fileName);
/* 303 */     if (url == null) {
/* 304 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.getWorkflowTemplateFromFile_notLoadModel") + templateTag);
/*     */     }
/*     */ 
/* 307 */     log.info("Reprinted process template：" + templateTag + " file：" + url.getPath());
/* 308 */     InputStream input = Util.getResourceAsStream(super.getClass(), fileName);
/* 309 */     if (input == null)
/*     */     {
/* 311 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_nofindTemplate"));
/*     */     }
/* 313 */     Element root = null;
/*     */     try {
/* 315 */       root = XmlUtil.parseXml(input);
/*     */     } catch (Exception ex) {
/* 317 */       throw new RuntimeException(ex.getCause());
/*     */     }
/* 319 */     return new VMClassTemplateImpl(templateTag, root);
/*     */   }
/*     */ 
/*     */   private VMClassTemplate getVMClassTemplateFromCache(String templateTag)
/*     */     throws Exception
/*     */   {
/* 325 */     List curTemplate = new ArrayList();
/* 326 */     StringBuffer content = new StringBuffer();
/* 327 */     IBOVmTemplateVersionValue[] version = getVmTemplateVersionFromCacheByTag(templateTag);
/* 328 */     for (int i = 0; i < version.length; ++i) {
/* 329 */       content.append(getContents(curTemplate, i));
/*     */     }
/* 331 */     Element root = null;
/*     */     try {
/* 333 */       root = XmlUtil.parseXmlOfString(content.toString());
/*     */     }
/*     */     catch (Exception ex) {
/* 336 */       throw new RuntimeException(ex.getCause());
/*     */     }
/* 338 */     return new VMClassTemplateImpl(templateTag, root);
/*     */   }
/*     */ 
/*     */   private IBOVmTemplateVersionValue[] getVmTemplateVersionFromCacheByTag(String templateTag)
/*     */     throws Exception
/*     */   {
/* 360 */     IBOVmTemplateVersionValue[] tmpResult = getAllVmTemplateVersionFromCache();
/* 361 */     List ret = new ArrayList();
/* 362 */     for (int i = 0; i < tmpResult.length; ++i) {
/* 363 */       if (templateTag.equals(tmpResult[i].getTemplateTag())) {
/* 364 */         ret.add(tmpResult[i]);
/*     */       }
/*     */     }
/* 367 */     if (ret.size() == 0) {
/* 368 */       return null;
/*     */     }
/* 370 */     return (IBOVmTemplateVersionValue[])(IBOVmTemplateVersionValue[])ret.toArray(new IBOVmTemplateVersionValue[0]);
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplateByTag(String templateTag) throws RemoteException, Exception {
/* 374 */     if (isPublish(templateTag)) {
/* 375 */       return getWorkflowTemplateFromCache(templateTag);
/*     */     }
/* 377 */     return getWorkflowTemplateFromFile(templateTag);
/*     */   }
/*     */ 
/*     */   private WorkflowTemplate getWorkflowTemplateFromCache(String templateTag) throws RemoteException, Exception
/*     */   {
/* 382 */     WorkflowTemplate templateInfo = null;
/* 383 */     long templateID = 0L;
/* 384 */     Timestamp expireDate = null;
/* 385 */     Timestamp validDate = null;
/* 386 */     List curTemplate = new ArrayList();
/* 387 */     HashMap allTemplate = CacheFactory.getAll(VmTemplateVersionCacheImpl.class);
/* 388 */     Iterator templates = allTemplate.entrySet().iterator();
/*     */ 
/* 390 */     while (templates.hasNext()) {
/* 391 */       Map.Entry e = (Map.Entry)templates.next();
/* 392 */       IBOVmTemplateVersionValue version = (IBOVmTemplateVersionValue)e.getValue();
/* 393 */       if (version.getTemplateTag().equals(templateTag)) {
/* 394 */         expireDate = version.getExpireDate();
/* 395 */         validDate = version.getValidDate();
/* 396 */         Timestamp curDate = TimeUtil.getSysTime();
/* 397 */         if ((curDate.after(validDate)) && (curDate.before(expireDate)));
/* 398 */         curTemplate.add(version);
/*     */ 
/* 402 */         if ((templateID != 0L) && (templateID != version.getTemplateVersionId())) {
/* 403 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_getMoreByTag") + templateTag);
/*     */         }
/* 405 */         templateID = version.getTemplateVersionId();
/*     */       }
/*     */     }
/* 408 */     if (curTemplate.size() > 0) {
/* 409 */       templateInfo = getWorkflowInfoFromVersion(curTemplate, templateID, expireDate, validDate);
/*     */     }
/* 411 */     return templateInfo;
/*     */   }
/*     */ 
/*     */   public void saveVmTemplate(IBOVmTemplateValue templateBean) throws RemoteException, Exception {
/* 415 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 416 */     templateDao.saveVmTemplate(templateBean);
/*     */   }
/*     */ 
/*     */   public void deployVmTemplate(IBOVmTemplateValue templateBean, Timestamp expDate, Timestamp valDate, String staffID, String templateXml) throws RemoteException, Exception {
/* 420 */     WorkflowTemplate worktemplate = null;
/* 421 */     if ((templateXml != null) && (templateXml.length() > 0)) {
/* 422 */       Element root = XmlUtil.parseXmlOfString(templateXml);
/* 423 */       worktemplate = new WorkflowTemplateImpl(templateBean.getTemplateTag(), null, root);
/*     */     } else {
/* 425 */       worktemplate = getWorkflowTemplateFromFile(templateBean.getTemplateTag());
/*     */     }
/*     */ 
/* 428 */     templateBean.setLabel(worktemplate.getLabel());
/* 429 */     templateBean.setTemplateType(worktemplate.getTaskType());
/* 430 */     saveVmTemplate(templateBean);
/* 431 */     saveVmTemplateVersionToHis(templateBean.getTemplateTag(), staffID, valDate);
/* 432 */     if ("Y".equals(templateBean.getPublish()))
/* 433 */       saveVmTemplateVersion(templateBean.getTemplateTag(), expDate, valDate, staffID, templateXml);
/*     */   }
/*     */ 
/*     */   private void saveVmTemplateVersionToHis(String templateTag, String staffID, Timestamp valDate)
/*     */     throws Exception
/*     */   {
/* 459 */     if (TimeUtil.getSysTime().after(valDate)) {
/* 460 */       valDate = TimeUtil.getSysTime();
/*     */     }
/*     */ 
/* 463 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 464 */     HashMap param = new HashMap();
/* 465 */     cond.append(" and ").append("TEMPLATE_TAG").append("=:").append("TEMPLATE_TAG");
/* 466 */     param.put("TEMPLATE_TAG", templateTag);
/*     */ 
/* 468 */     cond.append(" and ").append("EXPIRE_DATE").append(">:").append("EXPIRE_DATE");
/* 469 */     param.put("EXPIRE_DATE", valDate);
/*     */ 
/* 471 */     IBOVmTemplateVersionValue[] valiData = getVmTemplateVersion(cond.toString(), param);
/* 472 */     if ((valiData != null) && (valiData.length > 0)) {
/* 473 */       for (int i = 0; i < valiData.length; ++i) {
/* 474 */         valiData[i].setExpireDate(valDate);
/*     */       }
/* 476 */       saveBathVmTemplateVersion(valiData);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveVmTemplateVersion(String templateTag, Timestamp expDate, Timestamp valDate, String staffID, String templateXml) throws RemoteException, Exception {
/* 481 */     String content = null;
/* 482 */     if ((templateXml != null) && (templateXml.length() > 0))
/* 483 */       content = templateXml;
/*     */     else {
/* 485 */       content = getContentFromFile(templateTag);
/*     */     }
/*     */ 
/* 488 */     int maxColomnLength = 2000;
/* 489 */     String contentLength = WrapPropertiesUtil.getStringProperties("template.content.length");
/* 490 */     if (!StringUtils.isEmptyString(contentLength)) {
/* 491 */       maxColomnLength = Integer.parseInt(contentLength);
/*     */     } else {
/* 493 */       String strDatabaseDialect = AIConfigManager.getConfigItem("DATABASE_DIALECT");
/* 494 */       if (("com.ai.appframe2.bo.dialect.DB2DialectImpl".equals(strDatabaseDialect)) || ("com.ai.appframe2.bo.dialect.MySQLDialectImpl".equals(strDatabaseDialect))) {
/* 495 */         maxColomnLength = 1000;
/*     */       }
/*     */     }
/* 498 */     IBOVmTemplateVersionValue[] templateVersion = setVmTemplateVersionContents(content, maxColomnLength);
/* 499 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 500 */     for (int i = 0; i < templateVersion.length; ++i) {
/* 501 */       templateVersion[i].setTemplateTag(templateTag);
/* 502 */       templateVersion[i].setValidDate(valDate);
/* 503 */       templateVersion[i].setExpireDate(expDate);
/* 504 */       templateVersion[i].setCreateStaffId(staffID);
/* 505 */       templateVersion[i].setCreateDate(TimeUtil.getSysTime());
/*     */     }
/* 507 */     templateDao.saveVmTemplateVersion(templateVersion);
/*     */   }
/*     */ 
/*     */   private IBOVmTemplateVersionValue[] setVmTemplateVersionContents(String content, int maxColomnLength)
/*     */     throws Exception
/*     */   {
/* 513 */     String leftString = content;
/* 514 */     List vmTemplateVersions = new ArrayList();
/* 515 */     if (content == null) {
/* 516 */       return null;
/*     */     }
/* 518 */     int i = 0;
/*     */     do {
/* 520 */       IBOVmTemplateVersionValue templateVersionValue = new BOVmTemplateVersionBean();
/* 521 */       templateVersionValue.setOrderNum(i);
/* 522 */       if (leftString.length() < maxColomnLength * 16) {
/* 523 */         setContents(templateVersionValue, leftString, maxColomnLength);
/* 524 */         leftString = "";
/*     */       } else {
/* 526 */         setContents(templateVersionValue, leftString.substring(0, maxColomnLength * 16), maxColomnLength);
/* 527 */         leftString = leftString.substring(maxColomnLength * 16);
/*     */       }
/* 529 */       vmTemplateVersions.add(templateVersionValue);
/* 530 */       ++i;
/* 531 */     }while (leftString.length() > 0);
/*     */ 
/* 533 */     return (IBOVmTemplateVersionValue[])(IBOVmTemplateVersionValue[])vmTemplateVersions.toArray(new IBOVmTemplateVersionValue[0]);
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplateFromFile(String templateTag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 541 */     String content = getContentFromFile(templateTag);
/* 542 */     if ((content == null) || (content.length() == 0)) {
/* 543 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.getWorkflowTemplateFromFile_notLoadModel") + templateTag);
/*     */     }
/* 545 */     Element root = XmlUtil.parseXmlOfString(content);
/* 546 */     WorkflowTemplate result = new WorkflowTemplateImpl(templateTag, null, root);
/* 547 */     result.setTaskTemplateId(-1L);
/* 548 */     return result;
/*     */   }
/*     */ 
/*     */   private String getContents(List curTemplate, int order)
/*     */   {
/* 553 */     StringBuffer content = new StringBuffer();
/* 554 */     for (int i = 0; i < curTemplate.size(); ++i) {
/* 555 */       IBOVmTemplateVersionValue version = (IBOVmTemplateVersionValue)curTemplate.get(i);
/* 556 */       if (version.getOrderNum() == order) {
/* 557 */         if ((version.getContent() != null) && (version.getContent().length() > 0)) {
/* 558 */           content.append(version.getContent());
/*     */         }
/* 560 */         if ((version.getContent1() != null) && (version.getContent1().length() > 0)) {
/* 561 */           content.append(version.getContent1());
/*     */         }
/* 563 */         if ((version.getContent2() != null) && (version.getContent2().length() > 0)) {
/* 564 */           content.append(version.getContent2());
/*     */         }
/* 566 */         if ((version.getContent3() != null) && (version.getContent3().length() > 0)) {
/* 567 */           content.append(version.getContent3());
/*     */         }
/* 569 */         if ((version.getContent4() != null) && (version.getContent4().length() > 0)) {
/* 570 */           content.append(version.getContent4());
/*     */         }
/* 572 */         if ((version.getContent5() != null) && (version.getContent5().length() > 0)) {
/* 573 */           content.append(version.getContent5());
/*     */         }
/* 575 */         if ((version.getContent6() != null) && (version.getContent6().length() > 0)) {
/* 576 */           content.append(version.getContent6());
/*     */         }
/* 578 */         if ((version.getContent7() != null) && (version.getContent7().length() > 0)) {
/* 579 */           content.append(version.getContent7());
/*     */         }
/* 581 */         if ((version.getContent8() != null) && (version.getContent8().length() > 0)) {
/* 582 */           content.append(version.getContent8());
/*     */         }
/* 584 */         if ((version.getContent9() != null) && (version.getContent9().length() > 0)) {
/* 585 */           content.append(version.getContent9());
/*     */         }
/* 587 */         if ((version.getContent10() != null) && (version.getContent10().length() > 0)) {
/* 588 */           content.append(version.getContent10());
/*     */         }
/* 590 */         if ((version.getContent11() != null) && (version.getContent11().length() > 0)) {
/* 591 */           content.append(version.getContent11());
/*     */         }
/* 593 */         if ((version.getContent12() != null) && (version.getContent12().length() > 0)) {
/* 594 */           content.append(version.getContent12());
/*     */         }
/* 596 */         if ((version.getContent13() != null) && (version.getContent13().length() > 0)) {
/* 597 */           content.append(version.getContent13());
/*     */         }
/* 599 */         if ((version.getContent14() != null) && (version.getContent14().length() > 0)) {
/* 600 */           content.append(version.getContent14());
/*     */         }
/* 602 */         if ((version.getContent15() != null) && (version.getContent15().length() > 0)) {
/* 603 */           content.append(version.getContent15());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 608 */     return content.toString();
/*     */   }
/*     */ 
/*     */   private void setContents(IBOVmTemplateVersionValue templateVersionValue, String content, int maxColomnLength) throws Exception {
/* 612 */     String leftString = content;
/* 613 */     if (leftString.length() > maxColomnLength) {
/* 614 */       templateVersionValue.setContent(leftString.substring(0, maxColomnLength));
/* 615 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 617 */       templateVersionValue.setContent(leftString);
/* 618 */       leftString = "";
/*     */     }
/*     */ 
/* 621 */     if (leftString.length() > maxColomnLength) {
/* 622 */       templateVersionValue.setContent1(leftString.substring(0, maxColomnLength));
/* 623 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 625 */       templateVersionValue.setContent1(leftString);
/* 626 */       leftString = "";
/*     */     }
/*     */ 
/* 629 */     if (leftString.length() > maxColomnLength) {
/* 630 */       templateVersionValue.setContent2(leftString.substring(0, maxColomnLength));
/* 631 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 633 */       templateVersionValue.setContent2(leftString);
/* 634 */       leftString = "";
/*     */     }
/*     */ 
/* 637 */     if (leftString.length() > maxColomnLength) {
/* 638 */       templateVersionValue.setContent3(leftString.substring(0, maxColomnLength));
/* 639 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 641 */       templateVersionValue.setContent3(leftString);
/* 642 */       leftString = "";
/*     */     }
/*     */ 
/* 645 */     if (leftString.length() > maxColomnLength) {
/* 646 */       templateVersionValue.setContent4(leftString.substring(0, maxColomnLength));
/* 647 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 649 */       templateVersionValue.setContent4(leftString);
/* 650 */       leftString = "";
/*     */     }
/*     */ 
/* 653 */     if (leftString.length() > maxColomnLength) {
/* 654 */       templateVersionValue.setContent5(leftString.substring(0, maxColomnLength));
/* 655 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 657 */       templateVersionValue.setContent5(leftString);
/* 658 */       leftString = "";
/*     */     }
/*     */ 
/* 661 */     if (leftString.length() > maxColomnLength) {
/* 662 */       templateVersionValue.setContent6(leftString.substring(0, maxColomnLength));
/* 663 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 665 */       templateVersionValue.setContent6(leftString);
/* 666 */       leftString = "";
/*     */     }
/*     */ 
/* 669 */     if (leftString.length() > maxColomnLength) {
/* 670 */       templateVersionValue.setContent7(leftString.substring(0, maxColomnLength));
/* 671 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 673 */       templateVersionValue.setContent7(leftString);
/* 674 */       leftString = "";
/*     */     }
/*     */ 
/* 677 */     if (leftString.length() > maxColomnLength) {
/* 678 */       templateVersionValue.setContent8(leftString.substring(0, maxColomnLength));
/* 679 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 681 */       templateVersionValue.setContent8(leftString);
/* 682 */       leftString = "";
/*     */     }
/*     */ 
/* 685 */     if (leftString.length() > maxColomnLength) {
/* 686 */       templateVersionValue.setContent9(leftString.substring(0, maxColomnLength));
/* 687 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 689 */       templateVersionValue.setContent9(leftString);
/* 690 */       leftString = "";
/*     */     }
/*     */ 
/* 693 */     if (leftString.length() > maxColomnLength) {
/* 694 */       templateVersionValue.setContent10(leftString.substring(0, maxColomnLength));
/* 695 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 697 */       templateVersionValue.setContent10(leftString);
/* 698 */       leftString = "";
/*     */     }
/*     */ 
/* 701 */     if (leftString.length() > maxColomnLength) {
/* 702 */       templateVersionValue.setContent11(leftString.substring(0, maxColomnLength));
/* 703 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 705 */       templateVersionValue.setContent11(leftString);
/* 706 */       leftString = "";
/*     */     }
/*     */ 
/* 709 */     if (leftString.length() > maxColomnLength) {
/* 710 */       templateVersionValue.setContent12(leftString.substring(0, maxColomnLength));
/* 711 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 713 */       templateVersionValue.setContent12(leftString);
/* 714 */       leftString = "";
/*     */     }
/*     */ 
/* 717 */     if (leftString.length() > maxColomnLength) {
/* 718 */       templateVersionValue.setContent13(leftString.substring(0, maxColomnLength));
/* 719 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 721 */       templateVersionValue.setContent13(leftString);
/* 722 */       leftString = "";
/*     */     }
/*     */ 
/* 725 */     if (leftString.length() > maxColomnLength) {
/* 726 */       templateVersionValue.setContent14(leftString.substring(0, maxColomnLength));
/* 727 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 729 */       templateVersionValue.setContent14(leftString);
/* 730 */       leftString = "";
/*     */     }
/*     */ 
/* 733 */     if (leftString.length() > maxColomnLength) {
/* 734 */       templateVersionValue.setContent15(leftString.substring(0, maxColomnLength));
/* 735 */       leftString = leftString.substring(maxColomnLength);
/*     */     } else {
/* 737 */       templateVersionValue.setContent15(leftString);
/* 738 */       leftString = "";
/*     */     }
/*     */ 
/* 741 */     if (leftString.length() <= 0)
/*     */       return;
/* 743 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_splitError"));
/*     */   }
/*     */ 
/*     */   private boolean isValidTimeInPeriod(Timestamp curTime, Timestamp startValidDate, Timestamp endValidDate)
/*     */   {
/* 748 */     boolean ret = true;
/* 749 */     if (startValidDate != null) {
/* 750 */       ret = curTime.after(startValidDate);
/*     */     }
/* 752 */     if (endValidDate != null) {
/* 753 */       ret = curTime.before(endValidDate);
/*     */     }
/* 755 */     return ret;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplateInfo[] getWorkflowTemplateInfo(String templateTag, String startValidDate, String endValidDate) throws RemoteException, Exception {
/* 759 */     IBOVmTemplateValue[] vmTemplate = getAllVmTemplateFromCache();
/* 760 */     List templateList = new ArrayList();
/* 761 */     if ((vmTemplate == null) || (vmTemplate.length == 0))
/*     */     {
/* 763 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_refreshTemplate"));
/*     */     }
/* 765 */     Timestamp startTime = null;
/* 766 */     Timestamp endTime = null;
/* 767 */     if ((startValidDate != null) && (startValidDate.length() > 0)) {
/* 768 */       startTime = Timestamp.valueOf(startValidDate);
/*     */     }
/* 770 */     if ((endValidDate != null) && (endValidDate.length() > 0)) {
/* 771 */       endTime = Timestamp.valueOf(endValidDate);
/*     */     }
/* 773 */     for (int i = 0; i < vmTemplate.length; ++i)
/*     */     {
/* 775 */       WorkflowTemplateInfo templateInfo = new WorkflowTemplateInfo();
/* 776 */       if ((templateTag == null) || (templateTag.length() == 0)) continue; if (!templateTag.equals(vmTemplate[i].getTemplateTag())) {
/*     */         continue;
/*     */       }
/* 779 */       templateInfo.setTemplateTag(vmTemplate[i].getTemplateTag());
/* 780 */       templateInfo.setTemplateType(vmTemplate[i].getTemplateType());
/* 781 */       if (isPublish(vmTemplate[i].getTemplateTag())) {
/* 782 */         IBOVmTemplateVersionValue[] version = getVmTemplateVersionFromCacheByTag(vmTemplate[i].getTemplateTag());
/* 783 */         if ((version == null) || (version.length == 0))
/*     */         {
/* 785 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.service.impl.TemplateSVImpl_usePublishRefresh"));
/*     */         }
/* 787 */         if (isValidTimeInPeriod(version[0].getValidDate(), startTime, endTime)) {
/* 788 */           templateInfo.setTemplateId(version[0].getTemplateVersionId());
/* 789 */           templateInfo.setValidDate(version[0].getValidDate());
/* 790 */           templateInfo.setCreateDate(version[0].getCreateDate());
/* 791 */           templateInfo.setContent(getContent(vmTemplate[i].getTemplateTag()));
/* 792 */           templateInfo.setCreateStaffId(version[0].getCreateStaffId());
/* 793 */           templateInfo.setExpireDate(version[0].getExpireDate());
/*     */         }
/*     */       } else {
/* 796 */         templateInfo.setTemplateId(-1L);
/* 797 */         templateInfo.setContent(getContent(vmTemplate[i].getTemplateTag()));
/*     */       }
/* 799 */       templateList.add(templateInfo);
/*     */     }
/* 801 */     return (WorkflowTemplateInfo[])(WorkflowTemplateInfo[])templateList.toArray(new WorkflowTemplateInfo[0]);
/*     */   }
/*     */ 
/*     */   private String getContent(String templateTag) throws Exception {
/* 805 */     if (isPublish(templateTag)) {
/* 806 */       IBOVmTemplateVersionValue[] version = getVmTemplateVersionFromCacheByTag(templateTag);
/* 807 */       List curTemplate = new ArrayList();
/* 808 */       for (int i = 0; i < version.length; ++i) {
/* 809 */         curTemplate.add(version[i]);
/*     */       }
/* 811 */       return getContentFromCache(curTemplate);
/*     */     }
/* 813 */     return getContentFromFile(templateTag);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] getAllVmTemplateVersionByTag(String templateTag) throws RemoteException, Exception {
/* 817 */     if ((templateTag == null) || (templateTag.length() == 0)) {
/* 818 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.dao.impl.VmTemplateDAOImpl_inputTemplateTag"));
/*     */     }
/*     */ 
/* 821 */     IBOVmTemplateVersionValue[] version = getAllVmTemplateVersionFromCache();
/*     */ 
/* 823 */     List result = new ArrayList();
/* 824 */     for (int i = 0; i < version.length; ++i) {
/* 825 */       if (version[i].getTemplateTag().equals(templateTag)) {
/* 826 */         result.add(version[i]);
/*     */       }
/*     */     }
/* 829 */     return (IBOVmTemplateVersionValue[])(IBOVmTemplateVersionValue[])result.toArray(new IBOVmTemplateVersionValue[0]);
/*     */   }
/*     */ 
/*     */   public void saveBathVmTemplateVersion(IBOVmTemplateVersionValue[] templateVersion) throws RemoteException, Exception
/*     */   {
/* 834 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 835 */     templateDao.saveVmTemplateVersion(templateVersion);
/*     */   }
/*     */ 
/*     */   public void saveBathVmTemplate(IBOVmTemplateValue[] template)
/*     */     throws RemoteException, Exception
/*     */   {
/* 842 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 843 */     templateDao.saveBatchVmTemplate(template);
/*     */   }
/*     */ 
/*     */   public boolean isProcess(String templateCode) throws RemoteException, Exception
/*     */   {
/* 848 */     WorkflowTemplate template = getWorkflowTemplateByTag(templateCode);
/* 849 */     return template.getTaskType().equalsIgnoreCase("process");
/*     */   }
/*     */ 
/*     */   public boolean isWorkflow(String templateCode) throws RemoteException, Exception {
/* 853 */     WorkflowTemplate template = getWorkflowTemplateByTag(templateCode);
/* 854 */     return template.getTaskType().equalsIgnoreCase("workflow");
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplate(long templateId, String templateCode) throws RemoteException, Exception
/*     */   {
/* 859 */     if ((templateId == -1L) && (((templateCode == null) || (templateCode.trim().length() == 0)))) {
/* 860 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeWorkflowImpl.getWorkflowTemplate_inputTemplateCode"));
/*     */     }
/*     */ 
/* 864 */     WorkflowTemplate wt = null;
/* 865 */     String msg = null;
/* 866 */     if (templateId != -1L) {
/* 867 */       wt = getWorkflowTemplateByID(templateId);
/* 868 */       msg = ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeWorkflowImpl.getWorkflowTemplate_templateNum") + templateId;
/*     */     }
/*     */     else {
/* 871 */       wt = getWorkflowTemplateByTag(templateCode);
/* 872 */       msg = ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeWorkflowImpl.getWorkflowTemplate_templateCode") + templateCode;
/*     */     }
/*     */ 
/* 875 */     if (wt == null) {
/* 876 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeWorkflowImpl.getWorkflowTemplate_noloadTemplate") + msg);
/*     */     }
/*     */ 
/* 880 */     return wt;
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue[] getVmTemplates(String cond, HashMap param, int $startrowindex, int $endrowindex) throws RemoteException, Exception
/*     */   {
/* 885 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 886 */     return templateDao.getVmTemplates(cond, param, $startrowindex, $endrowindex);
/*     */   }
/*     */ 
/*     */   public int getVmTemplatesCount(String cond, HashMap param) throws RemoteException, Exception {
/* 890 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 891 */     return templateDao.getVmTemplatesCount(cond, param);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] getVmTemplateVersion(String cond, HashMap param) throws RemoteException, Exception {
/* 895 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 896 */     return templateDao.getVmTemplateVersion(cond, param);
/*     */   }
/*     */ 
/*     */   public IQBOVmTemplateValue[] getPublishedTemplates(String cond, HashMap param, int $startrowindex, int $endrowindex) throws RemoteException, Exception
/*     */   {
/* 901 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 902 */     return templateDao.getPublishedTemplates(cond, param, $startrowindex, $endrowindex);
/*     */   }
/*     */ 
/*     */   public int getPublishedTemplatesCount(String cond, HashMap param) throws RemoteException, Exception
/*     */   {
/* 907 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 908 */     return templateDao.getPublishedTemplatesCount(cond, param);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue[] getTemplateByQueue(String queueID) throws RemoteException, Exception {
/* 912 */     List ret = new ArrayList();
/* 913 */     HashMap allTemplate = CacheFactory.getAll(VmTemplateCacheImpl.class);
/* 914 */     Iterator templates = allTemplate.entrySet().iterator();
/* 915 */     int i = 0;
/* 916 */     while (templates.hasNext()) {
/* 917 */       Map.Entry e = (Map.Entry)templates.next();
/* 918 */       IBOVmTemplateValue tmp = (IBOVmTemplateValue)e.getValue();
/* 919 */       if ((queueID != null) && (queueID.equals(tmp.getQueueId()))) {
/* 920 */         ret.add(tmp);
/*     */       }
/* 922 */       ++i;
/*     */     }
/* 924 */     return (IBOVmTemplateValue[])(IBOVmTemplateValue[])ret.toArray(new IBOVmTemplateValue[0]);
/*     */   }
/*     */ 
/*     */   public void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue[] engineTemplates)
/*     */     throws RemoteException, Exception
/*     */   {
/* 932 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 933 */     templateDao.saveVmEngineTemplateVersionValue(engineTemplates);
/*     */   }
/*     */ 
/*     */   public void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue engineTemplate)
/*     */     throws RemoteException, Exception
/*     */   {
/* 939 */     IVmTemplateDAO templateDao = (IVmTemplateDAO)ServiceFactory.getService(IVmTemplateDAO.class);
/* 940 */     templateDao.saveVmEngineTemplateVersionValue(engineTemplate);
/*     */   }
/*     */ 
/*     */   public String toSvg(long templateID, String taskTag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 946 */     WorkflowTemplate t = null;
/* 947 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 948 */     if (templateSV.isPublish(taskTag)) {
/* 949 */       if (templateID > 0L)
/* 950 */         t = templateSV.getWorkflowTemplateByID(templateID);
/*     */       else
/* 952 */         t = templateSV.getWorkflowTemplateByTag(taskTag);
/*     */     }
/*     */     else {
/* 955 */       t = templateSV.getWorkflowTemplateFromFile(taskTag);
/*     */     }
/* 957 */     if (t == null) {
/* 958 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.toSvg_cannotLoadTemplate"));
/*     */     }
/*     */ 
/* 961 */     return VMUtil.toSvg(t, "utf-8");
/*     */   }
/*     */ 
/*     */   public String toDojo(long templateID, String taskTag, String imagePath) throws RemoteException, Exception
/*     */   {
/* 966 */     WorkflowTemplate t = null;
/* 967 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 968 */     if (templateSV.isPublish(taskTag)) {
/* 969 */       if (templateID > 0L)
/* 970 */         t = templateSV.getWorkflowTemplateByID(templateID);
/*     */       else
/* 972 */         t = templateSV.getWorkflowTemplateByTag(taskTag);
/*     */     }
/*     */     else {
/* 975 */       t = templateSV.getWorkflowTemplateFromFile(taskTag);
/*     */     }
/* 977 */     if (t == null) {
/* 978 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.toSvg_cannotLoadTemplate"));
/*     */     }
/*     */ 
/* 981 */     return VMUtilDojo.toDojo(t, "utf-8", imagePath);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.TemplateSVImpl
 * JD-Core Version:    0.5.4
 */