package com.ai.comframe.config.service.interfaces;

import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
import java.rmi.RemoteException;
import java.util.HashMap;

public abstract interface IExceptionConfigSV
{
  public abstract IBOVmExceptionCodeValue[] queryExceptionCode(String paramString1, String paramString2, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract void saveExceptionCode(IBOVmExceptionCodeValue[] paramArrayOfIBOVmExceptionCodeValue)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeValue[] queryExcepCodeAndName(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionDescValue[] queryExceptionDesc(String paramString, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract void saveExceptionDesc(IBOVmExceptionDescValue[] paramArrayOfIBOVmExceptionDescValue)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionRuleValue[] queryExceptionRule(String paramString)
    throws RemoteException, Exception;

  public abstract void saveExceptionRule(IBOVmExceptionRuleValue[] paramArrayOfIBOVmExceptionRuleValue)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeDescRelatValue[] queryExceptionRelation(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeDescRelatValue[] queryExcepRelation(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeDescRelatValue[] queryExcepRelationByDescCode(String paramString)
    throws RemoteException, Exception;

  public abstract void saveExceptionRela(IBOVmExceptionCodeDescRelatValue[] paramArrayOfIBOVmExceptionCodeDescRelatValue)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionDescValue queryExceDesc(String paramString)
    throws RemoteException, Exception;

  public abstract void saveExceDesc(IBOVmExceptionDescValue paramIBOVmExceptionDescValue)
    throws RemoteException, Exception;

  public abstract int queryExceptionCodeCount(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract int queryExceptionDescCount(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeValue[] getExceptionCodebyWokflowObjType(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeValue[] getExceptionCodeValues(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeValue[] getExceptionCodeValuesBySql(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionCodeDescRelatValue[] getExcepRelation(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionRuleValue[] getExceptionRule(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.IExceptionConfigSV
 * JD-Core Version:    0.5.4
 */