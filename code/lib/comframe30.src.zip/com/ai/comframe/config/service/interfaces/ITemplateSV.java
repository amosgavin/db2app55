package com.ai.comframe.config.service.interfaces;

import com.ai.comframe.client.WorkflowTemplateInfo;
import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
import com.ai.comframe.vm.template.VMClassTemplate;
import com.ai.comframe.vm.template.WorkflowTemplate;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface ITemplateSV
{
  public abstract String getQueueId(String paramString)
    throws RemoteException, Exception;

  public abstract String getEngineType(String paramString)
    throws RemoteException, Exception;

  public abstract boolean isPublish(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmTemplateValue[] loadAllVmTemplate()
    throws RemoteException, Exception;

  public abstract IBOVmTemplateValue[] getAllVmTemplateFromCache()
    throws RemoteException, Exception;

  public abstract IBOVmTemplateVersionValue[] loadAllVmTemplateVersion()
    throws RemoteException, Exception;

  public abstract WorkflowTemplate getWorkflowTemplateByTag(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowTemplate getWorkflowTemplateByID(long paramLong)
    throws RemoteException, Exception;

  public abstract void saveVmTemplate(IBOVmTemplateValue paramIBOVmTemplateValue)
    throws RemoteException, Exception;

  public abstract void saveVmTemplateVersion(String paramString1, Timestamp paramTimestamp1, Timestamp paramTimestamp2, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract WorkflowTemplate getWorkflowTemplateFromFile(String paramString)
    throws RemoteException, Exception;

  public abstract String[] getAllTemplateTags()
    throws RemoteException, Exception;

  public abstract String[] getTemplateTagFromLocal(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract VMClassTemplate getVMClassTemplate(String paramString)
    throws RemoteException, Exception;

  public abstract void deployVmTemplate(IBOVmTemplateValue paramIBOVmTemplateValue, Timestamp paramTimestamp1, Timestamp paramTimestamp2, String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract WorkflowTemplateInfo[] getWorkflowTemplateInfo(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void saveBathVmTemplateVersion(IBOVmTemplateVersionValue[] paramArrayOfIBOVmTemplateVersionValue)
    throws RemoteException, Exception;

  public abstract void saveBathVmTemplate(IBOVmTemplateValue[] paramArrayOfIBOVmTemplateValue)
    throws RemoteException, Exception;

  public abstract boolean isProcess(String paramString)
    throws RemoteException, Exception;

  public abstract boolean isWorkflow(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowTemplate getWorkflowTemplate(long paramLong, String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmTemplateValue[] getVmTemplates(String paramString, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getVmTemplatesCount(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOVmTemplateVersionValue[] getVmTemplateVersion(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IQBOVmTemplateValue[] getPublishedTemplates(String paramString, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getPublishedTemplatesCount(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOVmTemplateValue[] getTemplateByQueue(String paramString)
    throws RemoteException, Exception;

  public abstract void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue[] paramArrayOfIBOVmEngineTemplateVersionValue)
    throws RemoteException, Exception;

  public abstract void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue paramIBOVmEngineTemplateVersionValue)
    throws RemoteException, Exception;

  public abstract String toSvg(long paramLong, String paramString)
    throws RemoteException, Exception;

  public abstract String toDojo(long paramLong, String paramString1, String paramString2)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.ITemplateSV
 * JD-Core Version:    0.5.4
 */