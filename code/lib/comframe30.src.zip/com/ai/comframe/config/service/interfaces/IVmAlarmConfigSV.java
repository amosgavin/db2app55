package com.ai.comframe.config.service.interfaces;

import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
import com.ai.comframe.queue.WarningTaskBean;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface IVmAlarmConfigSV
{
  public abstract IBOVmAlarmConfigValue[] loadAllVmAlarmConfigs()
    throws RemoteException, Exception;

  public abstract IBOVmHoliDayValue[] loadAllHolidays()
    throws RemoteException, Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfig(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfigs(String paramString)
    throws RemoteException, Exception;

  public abstract Timestamp[] getHolidayList()
    throws RemoteException, Exception;

  public abstract IBOVmHoliDayValue[] getHolidayValue()
    throws RemoteException, Exception;

  public abstract void saveAlarmConfig(IBOVmAlarmConfigValue[] paramArrayOfIBOVmAlarmConfigValue)
    throws RemoteException, Exception;

  public abstract void saveHolidayConfig(IBOVmHoliDayValue[] paramArrayOfIBOVmHoliDayValue)
    throws RemoteException, Exception;

  public abstract void updateWarning(String paramString1, Timestamp paramTimestamp, int paramInt, String paramString2)
    throws RemoteException, Exception;

  public abstract void updateDuration(String paramString1, int paramInt, String paramString2)
    throws RemoteException, Exception;

  public abstract int calculateDuration(String paramString1, long paramLong, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract Timestamp calculateAlarmTime(String paramString1, long paramLong, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException, Exception;

  public abstract void dealAlarm(String paramString1, long paramLong, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, int paramInt)
    throws RemoteException, Exception;

  public abstract void warning(WarningTaskBean paramWarningTaskBean)
    throws RemoteException, Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfigs(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV
 * JD-Core Version:    0.5.4
 */