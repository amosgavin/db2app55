/*     */ package com.ai.comframe.config.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.config.dao.interfaces.IExceptionConfigDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import com.ai.comframe.config.service.interfaces.IExceptionConfigSV;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class ExceptionConfigSVImpl
/*     */   implements IExceptionConfigSV
/*     */ {
/*     */   public IBOVmExceptionCodeValue[] queryExceptionCode(String workFlowType, String ExCode, int startIndex, int endIndex)
/*     */     throws RemoteException, Exception
/*     */   {
/*  17 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  18 */     IBOVmExceptionCodeValue[] exceptionCodes = exConfigDAO.queryExceptionCode(workFlowType, ExCode, startIndex, endIndex);
/*  19 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public int queryExceptionCodeCount(String workFlowType, String ExCode) throws RemoteException, Exception {
/*  23 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  24 */     int exceptionCodeCount = exConfigDAO.queryExceptionCodeCount(workFlowType, ExCode);
/*  25 */     return exceptionCodeCount;
/*     */   }
/*     */   public void saveExceptionCode(IBOVmExceptionCodeValue[] aBeans) throws Exception {
/*  28 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  29 */     exConfigDAO.saveExceptionCode(aBeans);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] queryExcepCodeAndName(String Code, String CodeName) throws RemoteException, Exception {
/*  33 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  34 */     IBOVmExceptionCodeValue[] exceptionCodes = exConfigDAO.queryExcepCodeAndName(Code, CodeName);
/*  35 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionDescValue[] queryExceptionDesc(String description, int startIndex, int endIndex) throws RemoteException, Exception {
/*  39 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  40 */     IBOVmExceptionDescValue[] exceptionDescs = exConfigDAO.queryExceptionDesc(description, startIndex, endIndex);
/*  41 */     return exceptionDescs;
/*     */   }
/*     */ 
/*     */   public int queryExceptionDescCount(String description) throws RemoteException, Exception {
/*  45 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  46 */     int exceptionDescsCount = exConfigDAO.queryExceptionDescCount(description);
/*  47 */     return exceptionDescsCount;
/*     */   }
/*     */ 
/*     */   public void saveExceptionDesc(IBOVmExceptionDescValue[] aBeans) throws RemoteException, Exception
/*     */   {
/*  52 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  53 */     exConfigDAO.saveExceptionDesc(aBeans);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRuleValue[] queryExceptionRule(String Desc) throws RemoteException, Exception {
/*  57 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  58 */     IBOVmExceptionRuleValue[] exceptionRules = exConfigDAO.queryExceptionRule(Desc);
/*  59 */     return exceptionRules;
/*     */   }
/*     */ 
/*     */   public void saveExceptionRule(IBOVmExceptionRuleValue[] aBeans) throws RemoteException, Exception {
/*  63 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  64 */     exConfigDAO.saveExceptionRule(aBeans);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExceptionRelation(String DescCode)
/*     */     throws RemoteException, Exception
/*     */   {
/*  70 */     String condition = "";
/*  71 */     HashMap map = new HashMap();
/*  72 */     condition = "EXCEPTION_DESC_CODE = :aDescCode ";
/*  73 */     map.put("aDescCode", DescCode);
/*  74 */     IExceptionConfigDAO exceptionDao = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  75 */     return exceptionDao.queryExceptionRelation(condition, map);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExcepRelation(String Code)
/*     */     throws RemoteException, Exception
/*     */   {
/*  81 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  82 */     IBOVmExceptionCodeDescRelatValue[] exceptionCodeDescRels = exConfigDAO.queryExcepRelation(Code);
/*  83 */     return exceptionCodeDescRels;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExcepRelationByDescCode(String DescCode) throws RemoteException, Exception {
/*  87 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  88 */     IBOVmExceptionCodeDescRelatValue[] exceptionCodeDescRels = exConfigDAO.queryExcepRelationByDescCode(DescCode);
/*  89 */     return exceptionCodeDescRels;
/*     */   }
/*     */ 
/*     */   public void saveExceptionRela(IBOVmExceptionCodeDescRelatValue[] aBeans) throws RemoteException, Exception
/*     */   {
/*  94 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/*  95 */     exConfigDAO.saveExceptionRela(aBeans);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionDescValue queryExceDesc(String Desc) throws RemoteException, Exception {
/*  99 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 100 */     IBOVmExceptionDescValue value = exConfigDAO.queryExceDesc(Desc);
/* 101 */     return value;
/*     */   }
/*     */ 
/*     */   public void saveExceDesc(IBOVmExceptionDescValue aBeans) throws RemoteException, Exception {
/* 105 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 106 */     exConfigDAO.saveExceDesc(aBeans);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodebyWokflowObjType(String workflowObjType) throws RemoteException, Exception {
/* 110 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 111 */     IBOVmExceptionCodeValue[] exceptionCodes = exConfigDAO.getExceptionCodebyWokflowObjType(workflowObjType);
/* 112 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodeValues(String condition, HashMap parameter) throws RemoteException, Exception {
/* 116 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 117 */     return exConfigDAO.getExceptionCodeValues(condition, parameter);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodeValuesBySql(String qrySql, HashMap parameter) throws RemoteException, Exception {
/* 121 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 122 */     return exConfigDAO.getExceptionCodeValuesBySql(qrySql, parameter);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] getExcepRelation(String condition, HashMap parameter) throws RemoteException, Exception {
/* 126 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 127 */     return exConfigDAO.getExcepRelation(condition, parameter);
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRuleValue[] getExceptionRule(String condition, HashMap parameter) throws RemoteException, Exception {
/* 131 */     IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 132 */     return exConfigDAO.getExceptionRule(condition, parameter);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.ExceptionConfigSVImpl
 * JD-Core Version:    0.5.4
 */