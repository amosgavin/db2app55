/*    */ package com.ai.comframe.config.service.impl;
/*    */ 
/*    */ import com.ai.appframe2.bo.DataContainer;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.complex.cache.CacheFactory;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.cache.VmQueueConfigCacheImpl;
/*    */ import com.ai.comframe.config.dao.interfaces.IVmQueueConfigDAO;
/*    */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*    */ import com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue;
/*    */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*    */ import com.ai.comframe.queue.QueueParam;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class VmQueueConfigSVImpl
/*    */   implements IVmQueueConfigSV
/*    */ {
/* 23 */   private static final transient Log logger = LogFactory.getLog(VmQueueConfigSVImpl.class);
/*    */ 
/*    */   public IBOVmQueueConfigValue[] getAllVmQueueConfigs() throws RemoteException, Exception {
/* 26 */     IVmQueueConfigDAO vmConfigDAO = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 27 */     return vmConfigDAO.getAllVmQueueConfigs();
/*    */   }
/*    */ 
/*    */   public IBOVmQueueConfigValue getVmQueueConfig(String queueId, String queueType) throws RemoteException, Exception {
/* 31 */     IBOVmQueueConfigValue vmQueueConfig = null;
/* 32 */     Object vmQueueCache = CacheFactory.get(VmQueueConfigCacheImpl.class, queueId + "|" + queueType);
/* 33 */     if (vmQueueCache == null) {
/* 34 */       if (logger.isDebugEnabled())
/* 35 */         logger.debug("VmQueueConfigCacheImpl get :" + queueId + "|" + queueType + "...null,read from database ");
/* 36 */       IVmQueueConfigDAO vmConfigDAO = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 37 */       vmQueueConfig = vmConfigDAO.getVmQueueConfig(queueId, queueType);
/*    */     }
/*    */     else {
/* 40 */       vmQueueConfig = (IBOVmQueueConfigValue)vmQueueCache;
/* 41 */       if (logger.isDebugEnabled())
/* 42 */         logger.debug("VmQueueConfigCacheImpl get :" + queueId + "|" + queueType + "...DataSource: " + vmQueueConfig.getDatasoure());
/*    */     }
/* 44 */     return vmQueueConfig;
/*    */   }
/*    */ 
/*    */   public String[] getAllDistinctVmQueueID() throws RemoteException, Exception {
/* 48 */     List ret = new ArrayList();
/* 49 */     IVmQueueConfigDAO vmConfigDAO = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 50 */     IBOVmQueueConfigValue[] vmQueueConfigs = vmConfigDAO.getAllVmQueueConfigs();
/* 51 */     for (int i = 0; i < vmQueueConfigs.length; ++i) {
/* 52 */       if (!ret.contains(vmQueueConfigs[i].getQueueId())) {
/* 53 */         ret.add(vmQueueConfigs[i].getQueueId());
/*    */       }
/*    */     }
/* 56 */     return (String[])(String[])ret.toArray(new String[0]);
/*    */   }
/*    */ 
/*    */   public DataContainerInterface[] getAllDistinctVmQueueList() throws RemoteException, Exception {
/* 60 */     List tmpResult = new ArrayList();
/* 61 */     List ret = new ArrayList();
/* 62 */     IVmQueueConfigDAO vmConfigDAO = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 63 */     IBOVmQueueConfigValue[] vmQueueConfigs = vmConfigDAO.getAllVmQueueConfigs();
/* 64 */     for (int i = 0; i < vmQueueConfigs.length; ++i) {
/* 65 */       if (!tmpResult.contains(vmQueueConfigs[i].getQueueId())) {
/* 66 */         tmpResult.add(vmQueueConfigs[i].getQueueId());
/* 67 */         DataContainerInterface tmp = new DataContainer();
/* 68 */         tmp.set("QUEUE_ID", vmQueueConfigs[i].getQueueId());
/* 69 */         ret.add(tmp);
/*    */       }
/*    */     }
/* 72 */     return (DataContainerInterface[])(DataContainerInterface[])ret.toArray(new DataContainerInterface[0]);
/*    */   }
/*    */ 
/*    */   public IBOVmWorkflowObjectValue[] getAllVmWorkflowObject() throws RemoteException, Exception {
/* 76 */     IVmQueueConfigDAO queueConfigDao = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 77 */     return queueConfigDao.getAllVmWorkflowObject();
/*    */   }
/*    */ 
/*    */   public void insertVMQueueServer(QueueParam param) throws RemoteException, Exception
/*    */   {
/* 82 */     IVmQueueConfigDAO queueConfigDao = (IVmQueueConfigDAO)ServiceFactory.getService(IVmQueueConfigDAO.class);
/* 83 */     queueConfigDao.insertVMQueueServer(param);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.VmQueueConfigSVImpl
 * JD-Core Version:    0.5.4
 */