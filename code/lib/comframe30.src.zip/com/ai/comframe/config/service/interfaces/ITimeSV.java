package com.ai.comframe.config.service.interfaces;

import java.rmi.RemoteException;
import java.sql.Timestamp;

public abstract interface ITimeSV
{
  public abstract Timestamp getSysdate()
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.ITimeSV
 * JD-Core Version:    0.5.4
 */