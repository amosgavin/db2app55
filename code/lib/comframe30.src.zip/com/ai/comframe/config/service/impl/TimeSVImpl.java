/*    */ package com.ai.comframe.config.service.impl;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.dao.interfaces.ITimeDAO;
/*    */ import com.ai.comframe.config.service.interfaces.ITimeSV;
/*    */ import java.rmi.RemoteException;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class TimeSVImpl
/*    */   implements ITimeSV
/*    */ {
/*    */   public Timestamp getSysdate()
/*    */     throws RemoteException, Exception
/*    */   {
/* 13 */     ITimeDAO timeDao = (ITimeDAO)ServiceFactory.getService(ITimeDAO.class);
/* 14 */     return timeDao.getSysdate();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.impl.TimeSVImpl
 * JD-Core Version:    0.5.4
 */