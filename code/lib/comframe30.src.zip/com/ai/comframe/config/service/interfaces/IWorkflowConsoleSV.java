package com.ai.comframe.config.service.interfaces;

import com.ai.appframe2.bo.DataContainer;
import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
import com.ai.comframe.vm.workflow.ivalues.IQBOVmTaskInfoValue;
import java.rmi.RemoteException;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.fileupload.FileItem;

public abstract interface IWorkflowConsoleSV
{
  public abstract IBOVmWFValue getWorkflowByParentTaskId(String paramString)
    throws Exception, RemoteException;

  public abstract IBOHVmWFValue getHWorkflowByParentTaskId(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String[][] getWorkflowState()
    throws Exception, RemoteException;

  public abstract String[][] getTaskState()
    throws Exception, RemoteException;

  public abstract String[][] getVMDealType()
    throws Exception, RemoteException;

  public abstract String[] getCenterIds()
    throws Exception, RemoteException;

  public abstract String[] getDataSources()
    throws Exception, RemoteException;

  public abstract String[][] getAllDataSources()
    throws Exception, RemoteException;

  public abstract String createWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap)
    throws RemoteException, Exception;

  public abstract void suspendWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void resumeWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void terminateWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void dropWorkflow(String paramString)
    throws RemoteException, Exception;

  public abstract void cancelWorkflow(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract void setWorkflowVars(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract String toSvg(String paramString)
    throws RemoteException, Exception;

  public abstract String toSvg(long paramLong, String paramString)
    throws RemoteException, Exception;

  public abstract String toDojo(String paramString)
    throws RemoteException, Exception;

  public abstract String toDojo(long paramLong, String paramString)
    throws RemoteException, Exception;

  public abstract void lockTask(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void releaseTaskLock(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract boolean finishUserTask(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean goBackToTask(String paramString1, long paramLong, String paramString2, String paramString3, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean jumpToTask(String paramString1, long paramLong, String paramString2, String paramString3, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean printUserTask(String paramString1, String paramString2, Map paramMap)
    throws RemoteException, Exception;

  public abstract void fireWorkflowExceptionByTaskId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String reAuthorizeTask(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract void resumeExceptionWorkflow(String paramString)
    throws RemoteException, Exception;

  public abstract int resumeExceptionWorkflows(String paramString, String[] paramArrayOfString)
    throws RemoteException, Exception;

  public abstract IBOVmWFValue[] queryWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, String paramString5, String paramString6, int paramInt2, int paramInt3)
    throws Exception, RemoteException;

  public abstract int getVmWorkflowCount(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt, String paramString5, String paramString6)
    throws Exception, RemoteException;

  public abstract IBOVmWFValue[] queryChildWorkflow(String paramString, int paramInt1, int paramInt2)
    throws Exception, RemoteException;

  public abstract IBOHVmWFValue[] queryHisChildWorkflow(String paramString1, int paramInt1, int paramInt2, String paramString2)
    throws Exception, RemoteException;

  public abstract int queryChildWorkflowCount(String paramString)
    throws Exception, RemoteException;

  public abstract int queryHisChildWorkflowCount(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract IBOVmTaskValue[] queryVmTask(String paramString, int paramInt)
    throws Exception, RemoteException;

  public abstract IBOVmTaskTSValue[] queryVmTaskTrans(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract DataContainer[] getWorkflowInstVars(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract DataContainer[] getTemplateVars(String paramString)
    throws Exception, RemoteException;

  public abstract DataContainer[] getTemplatesFromDir(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String publishTemplates(IBOVmTemplateValue[] paramArrayOfIBOVmTemplateValue, Timestamp paramTimestamp1, Timestamp paramTimestamp2, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String publishEngineTemplate(IBOVmTemplateValue[] paramArrayOfIBOVmTemplateValue, Timestamp paramTimestamp1, Timestamp paramTimestamp2, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String publishCommercialTemplates(long[] paramArrayOfLong, String[] paramArrayOfString, Timestamp paramTimestamp, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract void publishCommercialTemplate(long paramLong, String paramString1, Timestamp paramTimestamp, String paramString2, String paramString3)
    throws Exception, RemoteException;

  public abstract String publishLocalToCommer(String[] paramArrayOfString, Timestamp paramTimestamp, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract void publishLocalToCommerSingle(FileItem paramFileItem, Timestamp paramTimestamp, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract void publishLocalToCommerSingle(String paramString1, Timestamp paramTimestamp, String paramString2, String paramString3)
    throws Exception, RemoteException;

  public abstract void publishLocalToCommerSingle(String paramString1, Timestamp paramTimestamp, String paramString2, String paramString3, String paramString4)
    throws Exception, RemoteException;

  public abstract IBOVmTemplateValue[] getVmTemplates(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
    throws Exception, RemoteException;

  public abstract int getVmTemplatesCount(String paramString1, String paramString2, String paramString3)
    throws Exception, RemoteException;

  public abstract IBOVmTemplateVersionValue[] getAllTemplateVersionByTag(String paramString)
    throws Exception, RemoteException;

  public abstract IBOVmTemplateValue[] getPublishedVMTemplates(String paramString)
    throws Exception, RemoteException;

  public abstract String getWorkflowTaskInsPopMenu(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String getWorkflowTaskTransInsPopMenu(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String getWorkflowInsPopMenu(String paramString)
    throws Exception, RemoteException;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfigs(String paramString)
    throws RemoteException, Exception;

  public abstract void updateWarning(String paramString1, Timestamp paramTimestamp, int paramInt, String paramString2)
    throws RemoteException, Exception;

  public abstract IQBOVmTemplateValue[] getPublishedTemplates(String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getPublishedTemplatesCount(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract IQBOVmTaskInfoValue[] getTaskInfo(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getTaskInfoCount(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract IBOHVmWFValue[] queryHisWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt1, String paramString6, String paramString7, int paramInt2, int paramInt3)
    throws Exception, RemoteException;

  public abstract int getHVmWorkflowCount(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt, String paramString6, String paramString7)
    throws Exception, RemoteException;

  public abstract IBOHVmTaskValue[] queryHVmTask(Date paramDate, String paramString, int paramInt)
    throws Exception, RemoteException;

  public abstract IBOHVmTaskTSValue[] queryHVmTaskTrans(Date paramDate, String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String[][] getDefaultPeriod()
    throws Exception;

  public abstract String toHisSvg(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract String toDojoHis(String paramString1, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.service.interfaces.IWorkflowConsoleSV
 * JD-Core Version:    0.5.4
 */