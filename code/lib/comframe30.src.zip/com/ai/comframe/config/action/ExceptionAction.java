/*     */ package com.ai.comframe.config.action;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.web.CustomProperty;
/*     */ import com.ai.appframe2.web.DataContainerList;
/*     */ import com.ai.appframe2.web.HttpUtil;
/*     */ import com.ai.appframe2.web.action.BaseAction;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionCodeBean;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionCodeDescRelatBean;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionDescBean;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionRuleBean;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import com.ai.comframe.config.service.interfaces.IExceptionConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ExceptionAction extends BaseAction
/*     */ {
/*  33 */   private static final Log log = LogFactory.getLog(ExceptionAction.class);
/*     */ 
/*     */   public void SaveExCode(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  54 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try
/*     */     {
/*  57 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmExceptionCodeBean.class });
/*     */ 
/*  60 */       if (dcLists.length > 0) {
/*  61 */         IBOVmExceptionCodeValue[] beans = (IBOVmExceptionCodeValue[])(IBOVmExceptionCodeValue[])dcLists[0].getColDataContainerInterface(0);
/*  62 */         IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*  63 */         service.saveExceptionCode(beans);
/*  64 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */       else {
/*  67 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_noDataInput"));
/*     */       }
/*     */     } catch (Exception e) {
/*  69 */       cp.set("MESSAGE", e.getMessage());
/*  70 */       log.error(e.getMessage(), e);
/*     */     }
/*     */     finally {
/*  73 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void SaveExDesc(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*  81 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/*  83 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmExceptionDescBean.class });
/*     */ 
/*  86 */       if (dcLists.length > 0) {
/*  87 */         IBOVmExceptionDescValue[] beans = (IBOVmExceptionDescValue[])(IBOVmExceptionDescValue[])dcLists[0].getColDataContainerInterface(0);
/*  88 */         IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*  89 */         service.saveExceptionDesc(beans);
/*  90 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */       else {
/*  93 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_noDataInput"));
/*     */       }
/*     */     } catch (Exception e) {
/*  95 */       cp.set("MESSAGE", e.getMessage());
/*     */     }
/*     */     finally {
/*  98 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void SaveExRule(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 106 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try
/*     */     {
/* 111 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmExceptionRuleBean.class });
/*     */ 
/* 115 */       if (dcLists.length > 0) {
/* 116 */         IBOVmExceptionRuleValue[] beans = (IBOVmExceptionRuleValue[])(IBOVmExceptionRuleValue[])dcLists[0].getColDataContainerInterface(0);
/*     */ 
/* 118 */         IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*     */ 
/* 120 */         service.saveExceptionRule(beans);
/* 121 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */       else {
/* 124 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_noDataInput"));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 128 */       cp.set("MESSAGE", e.getMessage());
/* 129 */       e.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/* 133 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void SaveExRel(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 142 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 144 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmExceptionCodeDescRelatBean.class });
/* 145 */       if (dcLists.length > 0) {
/* 146 */         IBOVmExceptionCodeDescRelatValue[] beans = (IBOVmExceptionCodeDescRelatValue[])(IBOVmExceptionCodeDescRelatValue[])dcLists[0].getColDataContainerInterface(0);
/* 147 */         IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/* 148 */         service.saveExceptionRela(beans);
/* 149 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */     } catch (Exception e) {
/* 152 */       cp.set("MESSAGE", e.getMessage());
/*     */     }
/*     */     finally
/*     */     {
/* 156 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void SaveExUnion(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 164 */     CustomProperty cp = CustomProperty.getInstance();
/* 165 */     String desc = HttpUtil.getAsString(request, "desc");
/* 166 */     String isDelete = HttpUtil.getAsString(request, "isDelete");
/* 167 */     int length = HttpUtil.getAsInt(request, "length");
/* 168 */     Set set = new HashSet();
/* 169 */     for (int i = 0; i < length; ++i)
/* 170 */       set.add(HttpUtil.getAsString(request, "para" + i));
/*     */     try
/*     */     {
/* 173 */       IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/* 174 */       Iterator itera1 = set.iterator();
/* 175 */       String[] tempStr = new String[length];
/* 176 */       int i = 0;
/* 177 */       while (itera1.hasNext()) {
/* 178 */         tempStr[i] = itera1.next().toString();
/* 179 */         ++i;
/*     */       }
/* 181 */       IBOVmExceptionCodeDescRelatValue[] value = service.queryExcepRelationByDescCode(desc);
/* 182 */       List tmpList = new ArrayList();
/* 183 */       for (int k = 0; k < tempStr.length; ++k) {
/* 184 */         boolean isequal = false;
/* 185 */         for (int j = 0; j < value.length; ++j) {
/* 186 */           if ("true".equals(isDelete)) {
/* 187 */             if ((tempStr[k] != null) && (tempStr[k].equals(value[j].getExceptionCode()))) {
/* 188 */               value[j].delete();
/* 189 */               tmpList.add(value[j]);
/*     */             }
/*     */           }
/* 192 */           else if ((tempStr[k] == null) || (tempStr[k].equals(value[j].getExceptionCode()))) {
/* 193 */             isequal = true;
/*     */           }
/*     */         }
/*     */ 
/* 197 */         if ((!isequal) && (!"true".equals(isDelete))) {
/* 198 */           IBOVmExceptionCodeDescRelatValue bean = new BOVmExceptionCodeDescRelatBean();
/* 199 */           bean.setExceptionCode(tempStr[k]);
/* 200 */           bean.setExceptionDescCode(desc);
/* 201 */           bean.setState("U");
/* 202 */           tmpList.add(bean);
/*     */         }
/*     */       }
/* 205 */       BOVmExceptionCodeDescRelatBean[] newsaveBeans = (BOVmExceptionCodeDescRelatBean[])(BOVmExceptionCodeDescRelatBean[])tmpList.toArray(new BOVmExceptionCodeDescRelatBean[0]);
/* 206 */       service.saveExceptionRela(newsaveBeans);
/* 207 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */     } catch (Exception e) {
/* 209 */       cp.set("MESSAGE", e.getMessage());
/* 210 */       e.printStackTrace();
/*     */     }
/*     */     finally
/*     */     {
/* 214 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void SaveRel(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 223 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 225 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { IBOVmExceptionCodeDescRelatValue.class });
/*     */ 
/* 228 */       if (dcLists.length > 0) {
/* 229 */         IBOVmExceptionCodeDescRelatValue[] beans = (IBOVmExceptionCodeDescRelatValue[])(IBOVmExceptionCodeDescRelatValue[])dcLists[0].getColDataContainerInterface(0);
/*     */ 
/* 231 */         IExceptionConfigSV service = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/* 232 */         service.saveExceptionRela(beans);
/* 233 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */       else {
/* 236 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.web.exception.ExceptionAction.SaveRel_noDataDel"));
/*     */       }
/*     */     } catch (Exception e) {
/* 238 */       cp.set("MESSAGE", e.getMessage());
/*     */     }
/*     */     finally
/*     */     {
/* 242 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.action.ExceptionAction
 * JD-Core Version:    0.5.4
 */