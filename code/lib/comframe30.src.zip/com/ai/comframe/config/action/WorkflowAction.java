/*     */ package com.ai.comframe.config.action;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.SessionManager;
/*     */ import com.ai.appframe2.common.Util;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.web.CustomProperty;
/*     */ import com.ai.appframe2.web.DataContainerList;
/*     */ import com.ai.appframe2.web.HttpUtil;
/*     */ import com.ai.appframe2.web.action.BaseAction;
/*     */ import com.ai.appframe2.web.fileupload.ApacheUploadTool;
/*     */ import com.ai.comframe.client.ComframeClient;
/*     */ import com.ai.comframe.client.TaskInfo;
/*     */ import com.ai.comframe.config.bo.BOVmAlarmConfigBean;
/*     */ import com.ai.comframe.config.bo.BOVmHoliDayBean;
/*     */ import com.ai.comframe.config.bo.BOVmTemplateBean;
/*     */ import com.ai.comframe.config.bo.BOVmTemplateVersionBean;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*     */ import com.ai.comframe.config.service.interfaces.IWorkflowConsoleSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.fileupload.FileItem;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class WorkflowAction extends BaseAction
/*     */ {
/*  50 */   private static final Log log = Util.getLogger(WorkflowAction.class);
/*     */ 
/*     */   public IWorkflowConsoleSV getConsoleService() {
/*  53 */     return (IWorkflowConsoleSV)ServiceFactory.getService(IWorkflowConsoleSV.class);
/*     */   }
/*     */ 
/*     */   private String getStaffId() {
/*  57 */     String staffId = PropertiesUtil.getSystemUserId();
/*  58 */     UserInfoInterface user = SessionManager.getUser();
/*  59 */     if (user != null) {
/*  60 */       staffId = Long.toString(user.getID());
/*     */     }
/*  62 */     return staffId;
/*     */   }
/*     */ 
/*     */   public void startWorkflow(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  70 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), null);
/*     */ 
/*  72 */       DataContainerInterface dc = dcLists[0].getAllDataContainerInterface()[0];
/*  73 */       String queueId = dc.getAsString("QUEUE_ID");
/*  74 */       String wfObjTyId = dc.getAsString("WORKFLOW_OBJECT_TYPE");
/*  75 */       String wfObjId = dc.getAsString("WORKFLOW_OBJECT_ID");
/*  76 */       String templateTag = dc.getAsString("TEMPLATE_TAG");
/*  77 */       String vars = dc.getAsString("VARS");
/*     */ 
/*  79 */       if (queueId == null) {
/*  80 */         HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_processQueueEmpty"));
/*  81 */         return;
/*     */       }
/*  83 */       if (templateTag == null) {
/*  84 */         HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_workflowCodeEmpty"));
/*  85 */         return;
/*     */       }
/*  87 */       if (wfObjTyId == null) {
/*  88 */         HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_workflowObjEmpty"));
/*  89 */         return;
/*     */       }
/*  91 */       if (wfObjId == null) {
/*  92 */         HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_workflowObjCodeEmpty"));
/*  93 */         return;
/*     */       }
/*  95 */       HashMap p = new HashMap();
/*  96 */       if (vars != null) {
/*  97 */         String[] arrayVar = StringUtils.split(vars, '#');
/*  98 */         for (int i = 0; i < arrayVar.length; ++i) {
/*  99 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 100 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 101 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/* 105 */       String workflowId = getConsoleService().createWorkflow(templateTag, getStaffId(), wfObjTyId, wfObjId, p);
/*     */ 
/* 107 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_processStartSuccess") + ",workflowId=" + workflowId);
/*     */     }
/*     */     catch (Exception e) {
/* 110 */       log.error(e.getMessage(), e);
/* 111 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_processStartFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void finishUserTask(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 119 */       String taskId = HttpUtil.getParameter(request, "taskId");
/* 120 */       String vars = HttpUtil.getParameter(request, "vars");
/* 121 */       String result = HttpUtil.getParameter(request, "result");
/*     */ 
/* 123 */       Map p = new HashMap();
/* 124 */       if (vars != null) {
/* 125 */         String[] arrayVar = StringUtils.split(vars, '#');
/* 126 */         for (int i = 0; i < arrayVar.length; ++i) {
/* 127 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 128 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 129 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/* 133 */       getConsoleService().finishUserTask(taskId, getStaffId(), result, "", p);
/* 134 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_returnSucess"));
/*     */     }
/*     */     catch (Exception e) {
/* 137 */       log.error(e.getMessage(), e);
/* 138 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.startWorkflow_returnFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void lockTask(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 143 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 144 */       getConsoleService().lockTask(taskId, getStaffId(), "");
/* 145 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.lockTask_lockSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 148 */       log.error(e.getMessage(), e);
/* 149 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.lockTask_lockFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void releaseTaskLock(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 155 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 156 */       getConsoleService().releaseTaskLock(taskId, "", "");
/* 157 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.releaseTaskLock_releaseSucess"));
/*     */     }
/*     */     catch (Exception e) {
/* 160 */       log.error(e.getMessage(), e);
/* 161 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.releaseTaskLock_releaseFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void goBackToTask(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 167 */       String vars = HttpUtil.getParameter(request, "vars");
/* 168 */       String taskId = HttpUtil.getParameter(request, "taskId");
/* 169 */       long taskTemplateId = Long.parseLong(HttpUtil.getParameter(request, "taskTemplateId"));
/* 170 */       String notes = HttpUtil.getParameter(request, "notes");
/*     */ 
/* 172 */       HashMap p = new HashMap();
/* 173 */       if (vars != null) {
/* 174 */         String[] arrayVar = StringUtils.split(vars, '#');
/* 175 */         for (int i = 0; i < arrayVar.length; ++i) {
/* 176 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 177 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 178 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 183 */       getConsoleService().goBackToTask(taskId, taskTemplateId, getStaffId(), notes, p);
/* 184 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.goBackToTask_backToTaskSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 187 */       log.error(e.getMessage(), e);
/* 188 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.goBackToTask_backToTaskFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void jumpToTask(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 193 */       String vars = HttpUtil.getParameter(request, "vars");
/* 194 */       String taskId = HttpUtil.getParameter(request, "taskId");
/* 195 */       long taskTemplateId = Long.parseLong(HttpUtil.getParameter(request, "taskTemplateId"));
/* 196 */       String notes = HttpUtil.getParameter(request, "notes");
/*     */ 
/* 198 */       HashMap p = new HashMap();
/* 199 */       if (vars != null) {
/* 200 */         String[] arrayVar = StringUtils.split(vars, '#');
/* 201 */         for (int i = 0; i < arrayVar.length; ++i) {
/* 202 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 203 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 204 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 209 */       getConsoleService().jumpToTask(taskId, taskTemplateId, getStaffId(), notes, p);
/* 210 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.jumpToTask_jumpToTaskSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 213 */       log.error(e.getMessage(), e);
/* 214 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.jumpToTask_jumpToTaskFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void printUserTask(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 220 */       String taskId = HttpUtil.getParameter(request, "taskId");
/* 221 */       String vars = HttpUtil.getParameter(request, "vars");
/*     */ 
/* 223 */       HashMap p = new HashMap();
/* 224 */       if (vars != null) {
/* 225 */         String[] arrayVar = StringUtils.split(vars, '#');
/* 226 */         for (int i = 0; i < arrayVar.length; ++i) {
/* 227 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 228 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 229 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/* 233 */       getConsoleService().printUserTask(taskId, getStaffId(), p);
/* 234 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.printUserTask_setPrintSucess"));
/*     */     }
/*     */     catch (Exception e) {
/* 237 */       log.error(e.getMessage(), e);
/* 238 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.printUserTask_setPrintFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void fireWorkflowExceptionByTaskId(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 244 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 245 */       getConsoleService().fireWorkflowExceptionByTaskId(taskId, "ERROR", "ERROR");
/* 246 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.fireWorkflowExceptionByTaskId_setProcessExcSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 249 */       log.error(e.getMessage(), e);
/* 250 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.fireWorkflowExceptionByTaskId_setProcessExcFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void reAuthorizeTask(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 256 */       String taskId = HttpUtil.getParameter(request, "taskId");
/* 257 */       String staffId = HttpUtil.getParameter(request, "staffId");
/* 258 */       String stationId = HttpUtil.getParameter(request, "stationId");
/* 259 */       getConsoleService().reAuthorizeTask(taskId, staffId, stationId, getStaffId());
/* 260 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.reAuthorizeTask_reAuthorizeSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 263 */       log.error(e.getMessage(), e);
/* 264 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.reAuthorizeTask_reAuthorizeFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void suspendWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/*     */     try {
/* 271 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 272 */       getConsoleService().suspendWorkflow(taskId, getStaffId(), null);
/* 273 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.suspendWorkflow_suspendWorkflowSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 276 */       log.error(e.getMessage(), e);
/* 277 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.suspendWorkflow_suspendWorkflowFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resumeWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 282 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 283 */       getConsoleService().resumeWorkflow(taskId, getStaffId(), null);
/* 284 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeWorkflow_recoverWorkflowSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 287 */       log.error(e.getMessage(), e);
/* 288 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeWorkflow_recoverWorkflowFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void terminateWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 293 */       String taskId = HttpUtil.getParameter(request, "WORKFLOW_ID");
/* 294 */       getConsoleService().terminateWorkflow(taskId, getStaffId(), null);
/* 295 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.terminateWorkflow_endWorkflowSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 298 */       log.error(e.getMessage(), e);
/* 299 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.terminateWorkflow_endWorkflowFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dropWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 304 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 305 */       getConsoleService().dropWorkflow(taskId);
/* 306 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.dropWorkflow_delProcessDataSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 309 */       log.error(e.getMessage(), e);
/* 310 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.dropWorkflow_delProcessDataFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void fireException(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 315 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 316 */       String errorCode = HttpUtil.getParameter(request, "errorCode");
/* 317 */       getConsoleService().fireWorkflowExceptionByTaskId(taskId, errorCode, errorCode);
/* 318 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.fireException_releaseExceptionSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 321 */       log.error(e.getMessage(), e);
/* 322 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.fireException_releaseExceptionFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resumeExceptionWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*     */     try {
/* 327 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 328 */       getConsoleService().resumeExceptionWorkflow(taskId);
/* 329 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeExceptionWorkflow_resumeQueueSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 332 */       log.error(e.getMessage(), e);
/* 333 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeExceptionWorkflow_resumeQueueFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resumeExceptionWorkflows(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 338 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 340 */       String[] workflowids = HttpUtil.getParameter(request, "workflowIds").split(",");
/* 341 */       String queueID = IDAssembleUtil.unwrapPrefix(workflowids[0]);
/* 342 */       int count = getConsoleService().resumeExceptionWorkflows(queueID, workflowids);
/* 343 */       cp.set("FLAG", "Y");
/* 344 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeExceptionWorkflow_resumeQueueSuccess2", new Object[] { Integer.valueOf(count) }));
/* 345 */       HttpUtil.showInfo(response, cp);
/*     */     } catch (Exception e) {
/* 347 */       log.error(e.getMessage(), e);
/* 348 */       cp.set("FLAG", "N");
/* 349 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.resumeExceptionWorkflow_resumeQueueFailed") + e.getMessage());
/* 350 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void cancelWorkflow(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/*     */     try {
/* 357 */       String workflowId = HttpUtil.getParameter(request, "WORKFLOW_ID");
/* 358 */       String errorCode = HttpUtil.getParameter(request, "errorCode");
/* 359 */       getConsoleService().cancelWorkflow(workflowId, getStaffId(), errorCode, errorCode);
/* 360 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.cancelWorkflow_processCancelSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 363 */       log.error(e.getMessage(), e);
/* 364 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.cancelWorkflow_processCancelFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void toSvg(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 369 */     String resultXml = "";
/* 370 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 372 */       String workflowID = HttpUtil.getParameter(request, "WORKFLOW_ID");
/* 373 */       resultXml = getConsoleService().toSvg(workflowID);
/* 374 */       cp.set("SVGXML", resultXml);
/* 375 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     catch (Exception e) {
/* 378 */       log.error(e.getMessage(), e);
/* 379 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.toSvg_toSvgFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setWorkflowVars(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 388 */       String taskId = HttpUtil.getParameter(request, "workflowId");
/* 389 */       String vars = HttpUtil.getParameter(request, "vars");
/* 390 */       HashMap p = new HashMap();
/* 391 */       if (vars != null) {
/* 392 */         String[] arrayVar = StringUtils.split(vars, '#');
/* 393 */         for (int i = 0; i < arrayVar.length; ++i) {
/* 394 */           String[] tmp = StringUtils.split(arrayVar[i], ':');
/* 395 */           if ((tmp.length == 2) && (tmp[1] != null)) {
/* 396 */             p.put(tmp[0], tmp[1]);
/*     */           }
/*     */         }
/*     */       }
/* 400 */       getConsoleService().setWorkflowVars(taskId, p);
/*     */ 
/* 402 */       HttpUtil.showInfo(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.setWorkflowVars_setVarsSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 405 */       log.error(e.getMessage(), e);
/* 406 */       HttpUtil.showError(response, ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.setWorkflowVars_setVarsFailed") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void templateUpload(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 415 */     CustomProperty cp = CustomProperty.getInstance();
/* 416 */     Timestamp validDate = HttpUtil.getAsDateTime(request, "validDate");
/* 417 */     Timestamp expireDate = HttpUtil.getAsDateTime(request, "expireDate");
/* 418 */     String notes = HttpUtil.getAsString(request, "notes");
/* 419 */     String EngineType = HttpUtil.getAsString(request, "EngineType");
/* 420 */     String templateTag = HttpUtil.getAsString(request, "TEMPLATE_TAG");
/* 421 */     String queueID = HttpUtil.getAsString(request, "QUEUE_ID");
/* 422 */     String staffID = String.valueOf(SessionManager.getUser().getID());
/*     */ 
/* 424 */     Object[] obj = ApacheUploadTool.getUploadFileInfo(request);
/* 425 */     List fileList = (List)obj[0];
/* 426 */     Map paras = (Map)obj[1];
/*     */ 
/* 428 */     List aFileList = (List)ApacheUploadTool.getUploadFileInfo(request)[0];
/* 429 */     if ((aFileList == null) || (aFileList.isEmpty())) {
/* 430 */       cp.set("ERRMSG", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.templateUpload_uploadTemplate"));
/* 431 */       ApacheUploadTool.showFileUploadMsg(response, cp);
/* 432 */       return;
/*     */     }
/* 434 */     String errMsg = null;
/* 435 */     IBOVmTemplateValue[] vmTemplate = new BOVmTemplateBean[aFileList.size()];
/*     */ 
/* 437 */     for (int i = 0; i < aFileList.size(); ++i) {
/* 438 */       vmTemplate[i] = new BOVmTemplateBean();
/* 439 */       vmTemplate[i].setTemplateTag(templateTag);
/* 440 */       vmTemplate[i].setQueueId(queueID);
/* 441 */       vmTemplate[i].setEngineType(EngineType);
/* 442 */       vmTemplate[i].setRemark(notes);
/* 443 */       vmTemplate[i].setPublish("Y");
/* 444 */       FileItem fileItem = (FileItem)aFileList.get(i);
/* 445 */       String fileName = fileItem.getName().trim();
/*     */       try {
/* 447 */         String templateStr = fileItemToString(fileItem);
/*     */ 
/* 449 */         if (EngineType.equalsIgnoreCase("VM")) {
/* 450 */           getConsoleService().publishTemplates(vmTemplate, validDate, expireDate, staffID, templateStr);
/*     */         }
/*     */         else
/*     */         {
/* 454 */           getConsoleService().publishLocalToCommerSingle(templateStr, validDate, notes, EngineType, templateTag);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 458 */         log.error("Template" + fileName + "deploy failed:" + e.getMessage(), e);
/* 459 */         if (errMsg == null) {
/* 460 */           errMsg = ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.templateUpload_deployFailed") + fileName;
/*     */         }
/*     */         else {
/* 463 */           errMsg = errMsg + "," + fileName;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 473 */     if (errMsg == null) {
/* 474 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.templateUpload_deploySuccess"));
/*     */     }
/*     */     else {
/* 477 */       cp.set("ERRMSG", errMsg);
/*     */     }
/* 479 */     ApacheUploadTool.showFileUploadMsg(response, cp);
/*     */   }
/*     */ 
/*     */   private String fileItemToString(FileItem aFileItem) throws Exception {
/* 483 */     BufferedReader br = null;
/*     */     try {
/* 485 */       if (aFileItem == null) {
/* 486 */         String str1 = "";
/*     */         return str1;
/*     */       }
/* 487 */       StringBuffer templateStr = new StringBuffer("");
/* 488 */       br = new BufferedReader(new InputStreamReader(aFileItem.getInputStream()));
/*     */ 
/* 490 */       while (br.ready()) {
/* 491 */         templateStr.append(br.readLine());
/*     */       }
/* 493 */       String str2 = templateStr.toString();
/*     */ 
/* 499 */       return str2;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 497 */       if (br != null)
/* 498 */         br.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deployTemplate(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 506 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try
/*     */     {
/* 509 */       String EngineType = HttpUtil.getAsString(request, "EngineType");
/* 510 */       String PubType = HttpUtil.getAsString(request, "pubType");
/* 511 */       Timestamp validDate = HttpUtil.getAsDateTime(request, "validDate");
/* 512 */       Timestamp expireDate = HttpUtil.getAsDateTime(request, "expireDate");
/*     */ 
/* 514 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), null);
/*     */ 
/* 516 */       DataContainerInterface[] dcs = dcLists[0].getAllDataContainerInterface();
/* 517 */       DataContainerInterface template = dcLists[1].getAllDataContainerInterface()[0];
/* 518 */       IBOVmTemplateValue[] vmTemplate = new BOVmTemplateBean[dcs.length];
/*     */ 
/* 521 */       template.set("VALID_DATE", validDate);
/* 522 */       template.set("EXPIRE_DATE", expireDate);
/* 523 */       String staffID = String.valueOf(SessionManager.getUser().getID());
/* 524 */       for (int i = 0; i < vmTemplate.length; ++i) {
/* 525 */         vmTemplate[i] = new BOVmTemplateBean();
/* 526 */         vmTemplate[i].copy(template);
/* 527 */         vmTemplate[i].setLabel(dcs[i].getAsString("TEMPLATE_TAG"));
/* 528 */         vmTemplate[i].setTemplateTag(dcs[i].getAsString("TEMPLATE_TAG"));
/* 529 */         vmTemplate[i].setCreateStaff(staffID);
/* 530 */         vmTemplate[i].setCreateDate(TimeUtil.getSysTime());
/*     */       }
/*     */ 
/* 533 */       String msg = "";
/* 534 */       if (EngineType.equalsIgnoreCase("VM"))
/* 535 */         msg = getConsoleService().publishTemplates(vmTemplate, validDate, expireDate, staffID, null);
/*     */       else {
/* 537 */         msg = getConsoleService().publishEngineTemplate(vmTemplate, validDate, expireDate, staffID, null);
/*     */       }
/*     */ 
/* 549 */       cp.set("msg", msg);
/*     */     }
/*     */     catch (Exception e) {
/* 552 */       log.error(e.getMessage(), e);
/* 553 */       cp.set("msg", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.fileItemToString_templateDeployFailed") + e.getMessage());
/*     */     } finally {
/* 555 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveVmTemplateVersion(HttpServletRequest req, HttpServletResponse rsp)
/*     */     throws Exception
/*     */   {
/* 578 */     CustomProperty cp = CustomProperty.getInstance();
/* 579 */     String resultMsg = "";
/*     */     try {
/* 581 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(req.getInputStream(), new Class[] { BOVmTemplateVersionBean.class });
/* 582 */       if ((dcLists == null) || (dcLists.length == 0))
/*     */       {
/* 584 */         resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_notModify");
/*     */         return;
/*     */       }
/* 587 */       IBOVmTemplateVersionValue[] templateVersion = (IBOVmTemplateVersionValue[])(IBOVmTemplateVersionValue[])dcLists[0].getColDataContainerInterface(0);
/* 588 */       ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 589 */       templateSv.saveBathVmTemplateVersion(templateVersion);
/*     */ 
/* 591 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_saveSuccess");
/*     */     }
/*     */     catch (Exception e) {
/* 594 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_saveError") + e.getMessage();
/* 595 */       log.error(resultMsg, e);
/*     */     } finally {
/* 597 */       cp.set("MESSAGE", resultMsg);
/* 598 */       HttpUtil.showInfo(rsp, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveVmTemplate(HttpServletRequest req, HttpServletResponse rsp) throws Exception {
/* 603 */     CustomProperty cp = CustomProperty.getInstance();
/* 604 */     String resultMsg = "";
/*     */     try {
/* 606 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(req.getInputStream(), new Class[] { BOVmTemplateBean.class });
/* 607 */       if ((dcLists == null) || (dcLists.length == 0))
/*     */       {
/* 609 */         resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_notModify");
/*     */         return;
/*     */       }
/* 612 */       IBOVmTemplateValue[] template = (IBOVmTemplateValue[])(IBOVmTemplateValue[])dcLists[0].getColDataContainerInterface(0);
/* 613 */       ITemplateSV templateSv = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 614 */       templateSv.saveBathVmTemplate(template);
/*     */ 
/* 616 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_saveSuccess");
/*     */     } catch (Exception e) {
/* 618 */       resultMsg = ComframeLocaleFactory.getResource("com.ai.comframe.config.action.WorkflowAction_saveError") + e.getMessage();
/* 619 */       log.error(resultMsg, e);
/*     */     } finally {
/* 621 */       cp.set("MESSAGE", resultMsg);
/* 622 */       HttpUtil.showInfo(rsp, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void workflowInst2Svg(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 631 */     response.setContentType("text/xml; charset=utf-8");
/* 632 */     String workflowId = HttpUtil.getParameter(request, "workflow_id");
/* 633 */     response.getWriter().print(getConsoleService().toSvg(workflowId));
/*     */   }
/*     */ 
/*     */   public void hisworkflowInst2Svg(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 638 */     response.setContentType("text/xml; charset=utf-8");
/* 639 */     String workflowId = HttpUtil.getParameter(request, "workflow_id");
/* 640 */     String sdate = HttpUtil.getParameter(request, "sdate");
/* 641 */     response.getWriter().print(getConsoleService().toHisSvg(workflowId, sdate));
/*     */   }
/*     */ 
/*     */   public void template2Svg(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 646 */     response.setContentType("text/xml; charset=utf-8");
/* 647 */     String templateIDStr = HttpUtil.getParameter(request, "template_id");
/* 648 */     long templateId = 0L;
/* 649 */     if ((!StringUtils.emptyString(templateIDStr)) && (!"null".equals(templateIDStr)) && (!"-1".equals(templateIDStr))) {
/* 650 */       templateId = Long.parseLong(templateIDStr);
/*     */     }
/*     */ 
/* 653 */     String taskTag = HttpUtil.getParameter(request, "task_tag");
/* 654 */     System.out.println(getConsoleService().toSvg(templateId, taskTag));
/* 655 */     response.getWriter().print(getConsoleService().toSvg(templateId, taskTag));
/*     */   }
/*     */ 
/*     */   public void workflowInst2Dojo(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 663 */     CustomProperty cp = CustomProperty.getInstance();
/* 664 */     response.setContentType("text/xml; charset=utf-8");
/* 665 */     String workflowId = HttpUtil.getParameter(request, "workflow_id");
/* 666 */     String msg = null;
/*     */     try {
/* 668 */       msg = getConsoleService().toDojo(workflowId);
/*     */     } catch (Exception e) {
/* 670 */       log.error(e.getMessage(), e);
/* 671 */       cp.set("error", e.getMessage());
/*     */     } finally {
/* 673 */       cp.set("msg", msg);
/* 674 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void hisworkflowInst2Dojo(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 679 */     CustomProperty cp = CustomProperty.getInstance();
/* 680 */     response.setContentType("text/xml; charset=utf-8");
/* 681 */     String workflowId = HttpUtil.getParameter(request, "workflow_id");
/* 682 */     String sdate = HttpUtil.getParameter(request, "sdate");
/* 683 */     String msg = null;
/*     */     try {
/* 685 */       msg = getConsoleService().toDojoHis(workflowId, sdate);
/*     */     } catch (Exception e) {
/* 687 */       log.error(e.getMessage(), e);
/* 688 */       cp.set("error", e.getMessage());
/*     */     } finally {
/* 690 */       cp.set("msg", msg);
/* 691 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void template2Dojo(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 696 */     CustomProperty cp = CustomProperty.getInstance();
/* 697 */     response.setContentType("text/xml; charset=utf-8");
/* 698 */     String templateIDStr = HttpUtil.getParameter(request, "template_id");
/* 699 */     String msg = null;
/* 700 */     long templateId = 0L;
/* 701 */     if ((!StringUtils.emptyString(templateIDStr)) && (!"null".equals(templateIDStr)) && (!"-1".equals(templateIDStr))) {
/* 702 */       templateId = Long.parseLong(templateIDStr);
/*     */     }
/* 704 */     String taskTag = HttpUtil.getParameter(request, "task_tag");
/*     */     try {
/* 706 */       msg = getConsoleService().toDojo(templateId, taskTag);
/*     */     } catch (Exception e) {
/* 708 */       log.error(e.getMessage(), e);
/* 709 */       cp.set("error", e.getMessage());
/*     */     } finally {
/* 711 */       cp.set("msg", msg);
/* 712 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void getWorkflowPopMenu(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 721 */     String state = HttpUtil.getAsString(request, "flow_state");
/* 722 */     String strJson = getConsoleService().getWorkflowInsPopMenu(state);
/* 723 */     HttpUtil.showInfo(response, strJson);
/*     */   }
/*     */ 
/*     */   public void getHisWorkflowPopMenu(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 728 */     String strJson = "[{id:'menu1',enable:'2',name:'" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_svgMonitor") + "',func:'toSvg'}]";
/* 729 */     HttpUtil.showInfo(response, strJson);
/*     */   }
/*     */ 
/*     */   public void getDojoHisWorkflowPopMenu(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 734 */     String strJson = "[{id:'menu2',enable:'2',name:'" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_dojoMonitor") + "',func:'toDojo'}]";
/* 735 */     HttpUtil.showInfo(response, strJson);
/*     */   }
/*     */ 
/*     */   public void getWorkflowTaskPopMenu(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 739 */     String wokflowstate = HttpUtil.getAsString(request, "flow_state");
/* 740 */     String state = HttpUtil.getAsString(request, "task_state");
/* 741 */     String strJson = getConsoleService().getWorkflowTaskInsPopMenu(wokflowstate, state);
/* 742 */     HttpUtil.showInfo(response, strJson);
/*     */   }
/*     */ 
/*     */   public void getWorkflowTaskTransPopMenu(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 746 */     String wokflowstate = HttpUtil.getAsString(request, "flow_state");
/* 747 */     String state = HttpUtil.getAsString(request, "task_state");
/* 748 */     String strJson = getConsoleService().getWorkflowTaskTransInsPopMenu(wokflowstate, state);
/* 749 */     HttpUtil.showInfo(response, strJson);
/*     */   }
/*     */ 
/*     */   public void saveAlarmConfig(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 755 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 757 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmAlarmConfigBean.class });
/*     */ 
/* 760 */       if (dcLists.length > 0) {
/* 761 */         IBOVmAlarmConfigValue[] beans = (IBOVmAlarmConfigValue[])(IBOVmAlarmConfigValue[])dcLists[0].getColDataContainerInterface(0);
/* 762 */         IVmAlarmConfigSV alarmSv = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 763 */         alarmSv.saveAlarmConfig(beans);
/* 764 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess"));
/*     */       }
/*     */       else {
/* 767 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_noDataInput"));
/*     */       }
/*     */     } catch (Exception e) {
/* 769 */       cp.set("MESSAGE", e.getMessage());
/* 770 */       log.error(e.getMessage(), e);
/*     */     }
/*     */     finally {
/* 773 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveHolidayConfig(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 795 */     CustomProperty cp = CustomProperty.getInstance();
/* 796 */     String msg = "";
/*     */     try {
/* 798 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), new Class[] { BOVmHoliDayBean.class });
/*     */ 
/* 801 */       if (dcLists.length > 0) {
/* 802 */         IBOVmHoliDayValue[] beans = (IBOVmHoliDayValue[])(IBOVmHoliDayValue[])dcLists[0].getColDataContainerInterface(0);
/* 803 */         IVmAlarmConfigSV alarmSv = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 804 */         alarmSv.saveHolidayConfig(beans);
/* 805 */         msg = ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_operSuccess");
/*     */       }
/*     */       else
/*     */       {
/* 809 */         msg = ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_noDataInput");
/*     */       }
/*     */     } catch (Exception e) {
/* 811 */       msg = ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.saveAlarmConfig_dataSaveError");
/* 812 */       log.error(msg, e);
/*     */     }
/*     */     finally {
/* 815 */       cp.set("MESSAGE", msg);
/* 816 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stopWarning(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 820 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 822 */       String taskId = HttpUtil.getParameter(request, "TASK_ID");
/* 823 */       int alarmTimes = Integer.parseInt(HttpUtil.getParameter(request, "WARNING_TIMES"));
/* 824 */       String type = HttpUtil.getAsString(request, "TYPE");
/* 825 */       getConsoleService().updateWarning(taskId, null, alarmTimes, type);
/* 826 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.stopWarning_stopSuccess"));
/*     */     }
/*     */     catch (Exception e) {
/* 829 */       log.error(e.getMessage(), e);
/* 830 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.comframe.console.action.WorkflowAction.stopWarning_stopFailed"));
/*     */     }
/*     */     finally
/*     */     {
/* 834 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void checkBusiTypeAction(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 840 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try
/*     */     {
/* 843 */       String aTaskId = HttpUtil.getAsString(request, "aTaskId").trim();
/* 844 */       String queueID = HttpUtil.getAsString(request, "queueID");
/* 845 */       String condition = "task_id = :aTaskId";
/* 846 */       HashMap param = new HashMap();
/* 847 */       param.put("aTaskId", aTaskId);
/* 848 */       TaskInfo[] taskinfo = ComframeClient.getTaskInfos(queueID, condition, param, -1, -1);
/* 849 */       if ((null == taskinfo) || (0 == taskinfo.length)) {
/* 850 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormTempletAction.checkBusiTypeAction_accTaskID") + aTaskId + ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormTempletAction.checkBusiTypeAction_undefinedTask"));
/*     */       }
/*     */ 
/* 853 */       cp.set("retVal", String.valueOf(taskinfo[0].getState()));
/*     */     } catch (Exception ex) {
/* 855 */       log.error(ex.getLocalizedMessage(), ex);
/* 856 */       cp.set("retVal", "N");
/* 857 */       cp.set("retMsg", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormTempletAction.saveDataAndDoTask_excuteFailedReason") + ex.getMessage());
/*     */     } finally {
/* 859 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void finish(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 864 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 866 */       String staffId = HttpUtil.getAsString(request, "staff_id");
/* 867 */       if ((staffId == null) || (staffId.trim().length() == 0)) {
/* 868 */         UserInfoInterface user = ServiceManager.getUser();
/* 869 */         if (user != null) {
/* 870 */           staffId = Long.toString(user.getID());
/*     */         }
/*     */       }
/* 873 */       String taskId = request.getParameter("taskid");
/* 874 */       String finishResult = request.getParameter("result");
/* 875 */       String reason = HttpUtil.getAsString(request, "reason");
/* 876 */       String xml = HttpUtil.getStringFromBufferedReader(request);
/* 877 */       HashMap vars = null;
/*     */ 
/* 880 */       if (ComframeClient.finishUserTask(taskId, staffId, finishResult, reason, vars)) {
/* 881 */         cp.set("FLAG", "Y");
/* 882 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.web.UserTaskServlet.finish_taskCommitSuccess"));
/*     */       } else {
/* 884 */         cp.set("FLAG", "N");
/* 885 */         cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.web.UserTaskServlet.finish_taskCommitFailed"));
/*     */       }
/*     */     } catch (Exception e) {
/* 888 */       log.error(e.getLocalizedMessage(), e);
/* 889 */       cp.set("FLAG", "N");
/* 890 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.web.UserTaskServlet.finish_commitException") + e.getMessage());
/*     */     }
/* 892 */     response.setContentType(HttpUtil.getXmlContentType());
/* 893 */     response.getWriter().print(HttpUtil.getXmlDeclare());
/* 894 */     response.getWriter().print(cp.toXmlString());
/*     */   }
/*     */ 
/*     */   public void isProcess(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 899 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 901 */       String workflowCode = HttpUtil.getAsString(request, "workflowCode");
/* 902 */       if ((!StringUtils.emptyString(workflowCode)) && (ComframeClient.isProcess(workflowCode)))
/* 903 */         cp.set("FLAG", "Y");
/*     */       else
/* 905 */         cp.set("FLAG", "N");
/*     */     }
/*     */     catch (Exception e) {
/* 908 */       log.error(e.getLocalizedMessage(), e);
/* 909 */       cp.set("FLAG", "N");
/* 910 */       cp.set("MESSAGE", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.web.UserTaskServlet.finish_commitException") + e.getMessage());
/*     */     } finally {
/* 912 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.action.WorkflowAction
 * JD-Core Version:    0.5.4
 */