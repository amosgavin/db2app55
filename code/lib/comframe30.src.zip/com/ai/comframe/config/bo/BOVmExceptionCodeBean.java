/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmExceptionCodeBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmExceptionCodeValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmExceptionCode";
/*     */   public static final String S_ExceptionCode = "EXCEPTION_CODE";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_ExceptionType = "EXCEPTION_TYPE";
/*     */   public static final String S_ExceptionName = "EXCEPTION_NAME";
/*  27 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmExceptionCodeBean()
/*     */     throws AIException
/*     */   {
/*  36 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  40 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  45 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initExceptionCode(String value)
/*     */   {
/*  50 */     initProperty("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCode(String value) {
/*  53 */     set("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCodeNull() {
/*  56 */     set("EXCEPTION_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionCode() {
/*  60 */     return DataType.getAsString(get("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionCodeInitialValue() {
/*  64 */     return DataType.getAsString(getOldObj("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  68 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  71 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  74 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  78 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  82 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowObjectType(String value) {
/*  86 */     initProperty("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectType(String value) {
/*  89 */     set("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectTypeNull() {
/*  92 */     set("WORKFLOW_OBJECT_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectType() {
/*  96 */     return DataType.getAsString(get("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectTypeInitialValue() {
/* 100 */     return DataType.getAsString(getOldObj("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 104 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 107 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 110 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 114 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 118 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 122 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 125 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 128 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 132 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 136 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initExceptionType(String value) {
/* 140 */     initProperty("EXCEPTION_TYPE", value);
/*     */   }
/*     */   public void setExceptionType(String value) {
/* 143 */     set("EXCEPTION_TYPE", value);
/*     */   }
/*     */   public void setExceptionTypeNull() {
/* 146 */     set("EXCEPTION_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionType() {
/* 150 */     return DataType.getAsString(get("EXCEPTION_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionTypeInitialValue() {
/* 154 */     return DataType.getAsString(getOldObj("EXCEPTION_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionName(String value) {
/* 158 */     initProperty("EXCEPTION_NAME", value);
/*     */   }
/*     */   public void setExceptionName(String value) {
/* 161 */     set("EXCEPTION_NAME", value);
/*     */   }
/*     */   public void setExceptionNameNull() {
/* 164 */     set("EXCEPTION_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionName() {
/* 168 */     return DataType.getAsString(get("EXCEPTION_NAME"));
/*     */   }
/*     */ 
/*     */   public String getExceptionNameInitialValue() {
/* 172 */     return DataType.getAsString(getOldObj("EXCEPTION_NAME"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  30 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  32 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmExceptionCodeBean
 * JD-Core Version:    0.5.4
 */