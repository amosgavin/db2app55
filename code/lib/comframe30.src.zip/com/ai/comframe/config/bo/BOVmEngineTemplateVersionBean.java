/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmEngineTemplateVersionBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmEngineTemplateVersionValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmEngineTemplateVersion";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_EngineVerion = "ENGINE_VERION";
/*     */   public static final String S_EngineTemplateId = "ENGINE_TEMPLATE_ID";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*  24 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmEngineTemplateVersionBean()
/*     */     throws AIException
/*     */   {
/*  33 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  37 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  42 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value)
/*     */   {
/*  47 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/*  50 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/*  53 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/*  57 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/*  61 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initEngineVerion(String value) {
/*  65 */     initProperty("ENGINE_VERION", value);
/*     */   }
/*     */   public void setEngineVerion(String value) {
/*  68 */     set("ENGINE_VERION", value);
/*     */   }
/*     */   public void setEngineVerionNull() {
/*  71 */     set("ENGINE_VERION", null);
/*     */   }
/*     */ 
/*     */   public String getEngineVerion() {
/*  75 */     return DataType.getAsString(get("ENGINE_VERION"));
/*     */   }
/*     */ 
/*     */   public String getEngineVerionInitialValue() {
/*  79 */     return DataType.getAsString(getOldObj("ENGINE_VERION"));
/*     */   }
/*     */ 
/*     */   public void initEngineTemplateId(String value) {
/*  83 */     initProperty("ENGINE_TEMPLATE_ID", value);
/*     */   }
/*     */   public void setEngineTemplateId(String value) {
/*  86 */     set("ENGINE_TEMPLATE_ID", value);
/*     */   }
/*     */   public void setEngineTemplateIdNull() {
/*  89 */     set("ENGINE_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineTemplateId() {
/*  93 */     return DataType.getAsString(get("ENGINE_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineTemplateIdInitialValue() {
/*  97 */     return DataType.getAsString(getOldObj("ENGINE_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 101 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 104 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 107 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 111 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 115 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  27 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  29 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmEngineTemplateVersionBean
 * JD-Core Version:    0.5.4
 */