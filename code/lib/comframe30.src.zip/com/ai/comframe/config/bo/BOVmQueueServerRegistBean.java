/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueServerRegistValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmQueueServerRegistBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmQueueServerRegistValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmQueueServerRegist";
/*     */   public static final String S_RegistId = "REGIST_ID";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_HostIp = "HOST_IP";
/*     */   public static final String S_RegistDate = "REGIST_DATE";
/*     */   public static final String S_ProcessId = "PROCESS_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_ModValue = "MOD_VALUE";
/*     */   public static final String S_Remarks = "REMARKS";
/*     */   public static final String S_ModParam = "MOD_PARAM";
/*     */   public static final String S_QueueType = "QUEUE_TYPE";
/*     */   public static final String S_HostName = "HOST_NAME";
/*  32 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmQueueServerRegistBean()
/*     */     throws AIException
/*     */   {
/*  41 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  45 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  50 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initRegistId(long value)
/*     */   {
/*  55 */     initProperty("REGIST_ID", new Long(value));
/*     */   }
/*     */   public void setRegistId(long value) {
/*  58 */     set("REGIST_ID", new Long(value));
/*     */   }
/*     */   public void setRegistIdNull() {
/*  61 */     set("REGIST_ID", null);
/*     */   }
/*     */ 
/*     */   public long getRegistId() {
/*  65 */     return DataType.getAsLong(get("REGIST_ID"));
/*     */   }
/*     */ 
/*     */   public long getRegistIdInitialValue() {
/*  69 */     return DataType.getAsLong(getOldObj("REGIST_ID"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  73 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  76 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  79 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  83 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  87 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/*  91 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/*  94 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/*  97 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 101 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 105 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initHostIp(String value) {
/* 109 */     initProperty("HOST_IP", value);
/*     */   }
/*     */   public void setHostIp(String value) {
/* 112 */     set("HOST_IP", value);
/*     */   }
/*     */   public void setHostIpNull() {
/* 115 */     set("HOST_IP", null);
/*     */   }
/*     */ 
/*     */   public String getHostIp() {
/* 119 */     return DataType.getAsString(get("HOST_IP"));
/*     */   }
/*     */ 
/*     */   public String getHostIpInitialValue() {
/* 123 */     return DataType.getAsString(getOldObj("HOST_IP"));
/*     */   }
/*     */ 
/*     */   public void initRegistDate(Timestamp value) {
/* 127 */     initProperty("REGIST_DATE", value);
/*     */   }
/*     */   public void setRegistDate(Timestamp value) {
/* 130 */     set("REGIST_DATE", value);
/*     */   }
/*     */   public void setRegistDateNull() {
/* 133 */     set("REGIST_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getRegistDate() {
/* 137 */     return DataType.getAsDateTime(get("REGIST_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getRegistDateInitialValue() {
/* 141 */     return DataType.getAsDateTime(getOldObj("REGIST_DATE"));
/*     */   }
/*     */ 
/*     */   public void initProcessId(String value) {
/* 145 */     initProperty("PROCESS_ID", value);
/*     */   }
/*     */   public void setProcessId(String value) {
/* 148 */     set("PROCESS_ID", value);
/*     */   }
/*     */   public void setProcessIdNull() {
/* 151 */     set("PROCESS_ID", null);
/*     */   }
/*     */ 
/*     */   public String getProcessId() {
/* 155 */     return DataType.getAsString(get("PROCESS_ID"));
/*     */   }
/*     */ 
/*     */   public String getProcessIdInitialValue() {
/* 159 */     return DataType.getAsString(getOldObj("PROCESS_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 163 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 166 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 169 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 173 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 177 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initModValue(String value) {
/* 181 */     initProperty("MOD_VALUE", value);
/*     */   }
/*     */   public void setModValue(String value) {
/* 184 */     set("MOD_VALUE", value);
/*     */   }
/*     */   public void setModValueNull() {
/* 187 */     set("MOD_VALUE", null);
/*     */   }
/*     */ 
/*     */   public String getModValue() {
/* 191 */     return DataType.getAsString(get("MOD_VALUE"));
/*     */   }
/*     */ 
/*     */   public String getModValueInitialValue() {
/* 195 */     return DataType.getAsString(getOldObj("MOD_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initRemarks(String value) {
/* 199 */     initProperty("REMARKS", value);
/*     */   }
/*     */   public void setRemarks(String value) {
/* 202 */     set("REMARKS", value);
/*     */   }
/*     */   public void setRemarksNull() {
/* 205 */     set("REMARKS", null);
/*     */   }
/*     */ 
/*     */   public String getRemarks() {
/* 209 */     return DataType.getAsString(get("REMARKS"));
/*     */   }
/*     */ 
/*     */   public String getRemarksInitialValue() {
/* 213 */     return DataType.getAsString(getOldObj("REMARKS"));
/*     */   }
/*     */ 
/*     */   public void initModParam(int value) {
/* 217 */     initProperty("MOD_PARAM", new Integer(value));
/*     */   }
/*     */   public void setModParam(int value) {
/* 220 */     set("MOD_PARAM", new Integer(value));
/*     */   }
/*     */   public void setModParamNull() {
/* 223 */     set("MOD_PARAM", null);
/*     */   }
/*     */ 
/*     */   public int getModParam() {
/* 227 */     return DataType.getAsInt(get("MOD_PARAM"));
/*     */   }
/*     */ 
/*     */   public int getModParamInitialValue() {
/* 231 */     return DataType.getAsInt(getOldObj("MOD_PARAM"));
/*     */   }
/*     */ 
/*     */   public void initQueueType(String value) {
/* 235 */     initProperty("QUEUE_TYPE", value);
/*     */   }
/*     */   public void setQueueType(String value) {
/* 238 */     set("QUEUE_TYPE", value);
/*     */   }
/*     */   public void setQueueTypeNull() {
/* 241 */     set("QUEUE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getQueueType() {
/* 245 */     return DataType.getAsString(get("QUEUE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getQueueTypeInitialValue() {
/* 249 */     return DataType.getAsString(getOldObj("QUEUE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initHostName(String value) {
/* 253 */     initProperty("HOST_NAME", value);
/*     */   }
/*     */   public void setHostName(String value) {
/* 256 */     set("HOST_NAME", value);
/*     */   }
/*     */   public void setHostNameNull() {
/* 259 */     set("HOST_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getHostName() {
/* 263 */     return DataType.getAsString(get("HOST_NAME"));
/*     */   }
/*     */ 
/*     */   public String getHostNameInitialValue() {
/* 267 */     return DataType.getAsString(getOldObj("HOST_NAME"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  35 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  37 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmQueueServerRegistBean
 * JD-Core Version:    0.5.4
 */