/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmTemplateVersionBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmTemplateVersionValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmTemplateVersion";
/*     */   public static final String S_Content10 = "CONTENT10";
/*     */   public static final String S_OrderNum = "ORDER_NUM";
/*     */   public static final String S_Content9 = "CONTENT9";
/*     */   public static final String S_Content5 = "CONTENT5";
/*     */   public static final String S_Content1 = "CONTENT1";
/*     */   public static final String S_CreateStaffId = "CREATE_STAFF_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_Content8 = "CONTENT8";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_Content13 = "CONTENT13";
/*     */   public static final String S_Content4 = "CONTENT4";
/*     */   public static final String S_Content12 = "CONTENT12";
/*     */   public static final String S_ExpireDate = "EXPIRE_DATE";
/*     */   public static final String S_Content3 = "CONTENT3";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*     */   public static final String S_Content7 = "CONTENT7";
/*     */   public static final String S_Content11 = "CONTENT11";
/*     */   public static final String S_Content14 = "CONTENT14";
/*     */   public static final String S_Content15 = "CONTENT15";
/*     */   public static final String S_Content6 = "CONTENT6";
/*     */   public static final String S_Content = "CONTENT";
/*     */   public static final String S_ValidDate = "VALID_DATE";
/*     */   public static final String S_ModifyDesc = "MODIFY_DESC";
/*     */   public static final String S_Content2 = "CONTENT2";
/*  44 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmTemplateVersionBean()
/*     */     throws AIException
/*     */   {
/*  53 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  57 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  62 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initContent10(String value)
/*     */   {
/*  67 */     initProperty("CONTENT10", value);
/*     */   }
/*     */   public void setContent10(String value) {
/*  70 */     set("CONTENT10", value);
/*     */   }
/*     */   public void setContent10Null() {
/*  73 */     set("CONTENT10", null);
/*     */   }
/*     */ 
/*     */   public String getContent10() {
/*  77 */     return DataType.getAsString(get("CONTENT10"));
/*     */   }
/*     */ 
/*     */   public String getContent10InitialValue() {
/*  81 */     return DataType.getAsString(getOldObj("CONTENT10"));
/*     */   }
/*     */ 
/*     */   public void initOrderNum(int value) {
/*  85 */     initProperty("ORDER_NUM", new Integer(value));
/*     */   }
/*     */   public void setOrderNum(int value) {
/*  88 */     set("ORDER_NUM", new Integer(value));
/*     */   }
/*     */   public void setOrderNumNull() {
/*  91 */     set("ORDER_NUM", null);
/*     */   }
/*     */ 
/*     */   public int getOrderNum() {
/*  95 */     return DataType.getAsInt(get("ORDER_NUM"));
/*     */   }
/*     */ 
/*     */   public int getOrderNumInitialValue() {
/*  99 */     return DataType.getAsInt(getOldObj("ORDER_NUM"));
/*     */   }
/*     */ 
/*     */   public void initContent9(String value) {
/* 103 */     initProperty("CONTENT9", value);
/*     */   }
/*     */   public void setContent9(String value) {
/* 106 */     set("CONTENT9", value);
/*     */   }
/*     */   public void setContent9Null() {
/* 109 */     set("CONTENT9", null);
/*     */   }
/*     */ 
/*     */   public String getContent9() {
/* 113 */     return DataType.getAsString(get("CONTENT9"));
/*     */   }
/*     */ 
/*     */   public String getContent9InitialValue() {
/* 117 */     return DataType.getAsString(getOldObj("CONTENT9"));
/*     */   }
/*     */ 
/*     */   public void initContent5(String value) {
/* 121 */     initProperty("CONTENT5", value);
/*     */   }
/*     */   public void setContent5(String value) {
/* 124 */     set("CONTENT5", value);
/*     */   }
/*     */   public void setContent5Null() {
/* 127 */     set("CONTENT5", null);
/*     */   }
/*     */ 
/*     */   public String getContent5() {
/* 131 */     return DataType.getAsString(get("CONTENT5"));
/*     */   }
/*     */ 
/*     */   public String getContent5InitialValue() {
/* 135 */     return DataType.getAsString(getOldObj("CONTENT5"));
/*     */   }
/*     */ 
/*     */   public void initContent1(String value) {
/* 139 */     initProperty("CONTENT1", value);
/*     */   }
/*     */   public void setContent1(String value) {
/* 142 */     set("CONTENT1", value);
/*     */   }
/*     */   public void setContent1Null() {
/* 145 */     set("CONTENT1", null);
/*     */   }
/*     */ 
/*     */   public String getContent1() {
/* 149 */     return DataType.getAsString(get("CONTENT1"));
/*     */   }
/*     */ 
/*     */   public String getContent1InitialValue() {
/* 153 */     return DataType.getAsString(getOldObj("CONTENT1"));
/*     */   }
/*     */ 
/*     */   public void initCreateStaffId(String value) {
/* 157 */     initProperty("CREATE_STAFF_ID", value);
/*     */   }
/*     */   public void setCreateStaffId(String value) {
/* 160 */     set("CREATE_STAFF_ID", value);
/*     */   }
/*     */   public void setCreateStaffIdNull() {
/* 163 */     set("CREATE_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getCreateStaffId() {
/* 167 */     return DataType.getAsString(get("CREATE_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getCreateStaffIdInitialValue() {
/* 171 */     return DataType.getAsString(getOldObj("CREATE_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 175 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 178 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 181 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 185 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 189 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initContent8(String value) {
/* 193 */     initProperty("CONTENT8", value);
/*     */   }
/*     */   public void setContent8(String value) {
/* 196 */     set("CONTENT8", value);
/*     */   }
/*     */   public void setContent8Null() {
/* 199 */     set("CONTENT8", null);
/*     */   }
/*     */ 
/*     */   public String getContent8() {
/* 203 */     return DataType.getAsString(get("CONTENT8"));
/*     */   }
/*     */ 
/*     */   public String getContent8InitialValue() {
/* 207 */     return DataType.getAsString(getOldObj("CONTENT8"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 211 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 214 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 217 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 221 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 225 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initContent13(String value) {
/* 229 */     initProperty("CONTENT13", value);
/*     */   }
/*     */   public void setContent13(String value) {
/* 232 */     set("CONTENT13", value);
/*     */   }
/*     */   public void setContent13Null() {
/* 235 */     set("CONTENT13", null);
/*     */   }
/*     */ 
/*     */   public String getContent13() {
/* 239 */     return DataType.getAsString(get("CONTENT13"));
/*     */   }
/*     */ 
/*     */   public String getContent13InitialValue() {
/* 243 */     return DataType.getAsString(getOldObj("CONTENT13"));
/*     */   }
/*     */ 
/*     */   public void initContent4(String value) {
/* 247 */     initProperty("CONTENT4", value);
/*     */   }
/*     */   public void setContent4(String value) {
/* 250 */     set("CONTENT4", value);
/*     */   }
/*     */   public void setContent4Null() {
/* 253 */     set("CONTENT4", null);
/*     */   }
/*     */ 
/*     */   public String getContent4() {
/* 257 */     return DataType.getAsString(get("CONTENT4"));
/*     */   }
/*     */ 
/*     */   public String getContent4InitialValue() {
/* 261 */     return DataType.getAsString(getOldObj("CONTENT4"));
/*     */   }
/*     */ 
/*     */   public void initContent12(String value) {
/* 265 */     initProperty("CONTENT12", value);
/*     */   }
/*     */   public void setContent12(String value) {
/* 268 */     set("CONTENT12", value);
/*     */   }
/*     */   public void setContent12Null() {
/* 271 */     set("CONTENT12", null);
/*     */   }
/*     */ 
/*     */   public String getContent12() {
/* 275 */     return DataType.getAsString(get("CONTENT12"));
/*     */   }
/*     */ 
/*     */   public String getContent12InitialValue() {
/* 279 */     return DataType.getAsString(getOldObj("CONTENT12"));
/*     */   }
/*     */ 
/*     */   public void initExpireDate(Timestamp value) {
/* 283 */     initProperty("EXPIRE_DATE", value);
/*     */   }
/*     */   public void setExpireDate(Timestamp value) {
/* 286 */     set("EXPIRE_DATE", value);
/*     */   }
/*     */   public void setExpireDateNull() {
/* 289 */     set("EXPIRE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExpireDate() {
/* 293 */     return DataType.getAsDateTime(get("EXPIRE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExpireDateInitialValue() {
/* 297 */     return DataType.getAsDateTime(getOldObj("EXPIRE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initContent3(String value) {
/* 301 */     initProperty("CONTENT3", value);
/*     */   }
/*     */   public void setContent3(String value) {
/* 304 */     set("CONTENT3", value);
/*     */   }
/*     */   public void setContent3Null() {
/* 307 */     set("CONTENT3", null);
/*     */   }
/*     */ 
/*     */   public String getContent3() {
/* 311 */     return DataType.getAsString(get("CONTENT3"));
/*     */   }
/*     */ 
/*     */   public String getContent3InitialValue() {
/* 315 */     return DataType.getAsString(getOldObj("CONTENT3"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 319 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 322 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 325 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 329 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 333 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public void initContent7(String value) {
/* 337 */     initProperty("CONTENT7", value);
/*     */   }
/*     */   public void setContent7(String value) {
/* 340 */     set("CONTENT7", value);
/*     */   }
/*     */   public void setContent7Null() {
/* 343 */     set("CONTENT7", null);
/*     */   }
/*     */ 
/*     */   public String getContent7() {
/* 347 */     return DataType.getAsString(get("CONTENT7"));
/*     */   }
/*     */ 
/*     */   public String getContent7InitialValue() {
/* 351 */     return DataType.getAsString(getOldObj("CONTENT7"));
/*     */   }
/*     */ 
/*     */   public void initContent11(String value) {
/* 355 */     initProperty("CONTENT11", value);
/*     */   }
/*     */   public void setContent11(String value) {
/* 358 */     set("CONTENT11", value);
/*     */   }
/*     */   public void setContent11Null() {
/* 361 */     set("CONTENT11", null);
/*     */   }
/*     */ 
/*     */   public String getContent11() {
/* 365 */     return DataType.getAsString(get("CONTENT11"));
/*     */   }
/*     */ 
/*     */   public String getContent11InitialValue() {
/* 369 */     return DataType.getAsString(getOldObj("CONTENT11"));
/*     */   }
/*     */ 
/*     */   public void initContent14(String value) {
/* 373 */     initProperty("CONTENT14", value);
/*     */   }
/*     */   public void setContent14(String value) {
/* 376 */     set("CONTENT14", value);
/*     */   }
/*     */   public void setContent14Null() {
/* 379 */     set("CONTENT14", null);
/*     */   }
/*     */ 
/*     */   public String getContent14() {
/* 383 */     return DataType.getAsString(get("CONTENT14"));
/*     */   }
/*     */ 
/*     */   public String getContent14InitialValue() {
/* 387 */     return DataType.getAsString(getOldObj("CONTENT14"));
/*     */   }
/*     */ 
/*     */   public void initContent15(String value) {
/* 391 */     initProperty("CONTENT15", value);
/*     */   }
/*     */   public void setContent15(String value) {
/* 394 */     set("CONTENT15", value);
/*     */   }
/*     */   public void setContent15Null() {
/* 397 */     set("CONTENT15", null);
/*     */   }
/*     */ 
/*     */   public String getContent15() {
/* 401 */     return DataType.getAsString(get("CONTENT15"));
/*     */   }
/*     */ 
/*     */   public String getContent15InitialValue() {
/* 405 */     return DataType.getAsString(getOldObj("CONTENT15"));
/*     */   }
/*     */ 
/*     */   public void initContent6(String value) {
/* 409 */     initProperty("CONTENT6", value);
/*     */   }
/*     */   public void setContent6(String value) {
/* 412 */     set("CONTENT6", value);
/*     */   }
/*     */   public void setContent6Null() {
/* 415 */     set("CONTENT6", null);
/*     */   }
/*     */ 
/*     */   public String getContent6() {
/* 419 */     return DataType.getAsString(get("CONTENT6"));
/*     */   }
/*     */ 
/*     */   public String getContent6InitialValue() {
/* 423 */     return DataType.getAsString(getOldObj("CONTENT6"));
/*     */   }
/*     */ 
/*     */   public void initContent(String value) {
/* 427 */     initProperty("CONTENT", value);
/*     */   }
/*     */   public void setContent(String value) {
/* 430 */     set("CONTENT", value);
/*     */   }
/*     */   public void setContentNull() {
/* 433 */     set("CONTENT", null);
/*     */   }
/*     */ 
/*     */   public String getContent() {
/* 437 */     return DataType.getAsString(get("CONTENT"));
/*     */   }
/*     */ 
/*     */   public String getContentInitialValue() {
/* 441 */     return DataType.getAsString(getOldObj("CONTENT"));
/*     */   }
/*     */ 
/*     */   public void initValidDate(Timestamp value) {
/* 445 */     initProperty("VALID_DATE", value);
/*     */   }
/*     */   public void setValidDate(Timestamp value) {
/* 448 */     set("VALID_DATE", value);
/*     */   }
/*     */   public void setValidDateNull() {
/* 451 */     set("VALID_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getValidDate() {
/* 455 */     return DataType.getAsDateTime(get("VALID_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getValidDateInitialValue() {
/* 459 */     return DataType.getAsDateTime(getOldObj("VALID_DATE"));
/*     */   }
/*     */ 
/*     */   public void initModifyDesc(String value) {
/* 463 */     initProperty("MODIFY_DESC", value);
/*     */   }
/*     */   public void setModifyDesc(String value) {
/* 466 */     set("MODIFY_DESC", value);
/*     */   }
/*     */   public void setModifyDescNull() {
/* 469 */     set("MODIFY_DESC", null);
/*     */   }
/*     */ 
/*     */   public String getModifyDesc() {
/* 473 */     return DataType.getAsString(get("MODIFY_DESC"));
/*     */   }
/*     */ 
/*     */   public String getModifyDescInitialValue() {
/* 477 */     return DataType.getAsString(getOldObj("MODIFY_DESC"));
/*     */   }
/*     */ 
/*     */   public void initContent2(String value) {
/* 481 */     initProperty("CONTENT2", value);
/*     */   }
/*     */   public void setContent2(String value) {
/* 484 */     set("CONTENT2", value);
/*     */   }
/*     */   public void setContent2Null() {
/* 487 */     set("CONTENT2", null);
/*     */   }
/*     */ 
/*     */   public String getContent2() {
/* 491 */     return DataType.getAsString(get("CONTENT2"));
/*     */   }
/*     */ 
/*     */   public String getContent2InitialValue() {
/* 495 */     return DataType.getAsString(getOldObj("CONTENT2"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  47 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  49 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmTemplateVersionBean
 * JD-Core Version:    0.5.4
 */