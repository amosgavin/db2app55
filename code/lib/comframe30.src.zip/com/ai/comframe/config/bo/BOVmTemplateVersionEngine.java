/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainerFactory;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.appframe2.util.criteria.UniqueList;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BOVmTemplateVersionEngine
/*     */ {
/*     */   public static BOVmTemplateVersionBean[] getBeans(DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  20 */     Map ps = dc.getProperties();
/*  21 */     StringBuffer buffer = new StringBuffer();
/*  22 */     Map pList = new HashMap();
/*  23 */     for (Iterator cc = ps.entrySet().iterator(); cc.hasNext(); ) {
/*  24 */       e = (Map.Entry)cc.next();
/*  25 */       if (buffer.length() > 0)
/*  26 */         buffer.append(" and ");
/*  27 */       buffer.append(e.getKey().toString() + " = :p_" + e.getKey().toString());
/*  28 */       pList.put("p_" + e.getKey().toString(), e.getValue());
/*     */     }
/*     */     Map.Entry e;
/*  30 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try {
/*  32 */       e = getBeans(buffer.toString(), pList);
/*     */ 
/*  36 */       return e;
/*     */     }
/*     */     finally
/*     */     {
/*  34 */       if (conn != null)
/*  35 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean getBean(int _OrderNum, long _TemplateVersionId) throws Exception
/*     */   {
/*  41 */     String condition = "ORDER_NUM = :S_ORDER_NUM and TEMPLATE_VERSION_ID = :S_TEMPLATE_VERSION_ID";
/*  42 */     Map map = new HashMap();
/*  43 */     map.put("S_ORDER_NUM", new Integer(_OrderNum));
/*  44 */     map.put("S_TEMPLATE_VERSION_ID", new Long(_TemplateVersionId));
/*     */ 
/*  46 */     BOVmTemplateVersionBean[] beans = getBeans(condition, map);
/*  47 */     if ((beans != null) && (beans.length == 1))
/*  48 */       return beans[0];
/*  49 */     if ((beans != null) && (beans.length > 1))
/*     */     {
/*  51 */       throw new Exception("[ERROR]More datas than one queryed by PK");
/*     */     }
/*  53 */     BOVmTemplateVersionBean bean = new BOVmTemplateVersionBean();
/*  54 */     bean.setOrderNum(_OrderNum);
/*  55 */     bean.setTemplateVersionId(_TemplateVersionId);
/*  56 */     return bean;
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeans(Criteria sql) throws Exception
/*     */   {
/*  61 */     return getBeans(sql, -1, -1, false);
/*     */   }
/*     */   public static BOVmTemplateVersionBean[] getBeans(Criteria sql, int startNum, int endNum, boolean isShowFK) throws Exception {
/*  64 */     String[] cols = null;
/*  65 */     String condition = "";
/*  66 */     Map param = null;
/*  67 */     if (sql != null) {
/*  68 */       cols = (String[])(String[])sql.getSelectColumns().toArray(new String[0]);
/*  69 */       condition = sql.toString();
/*  70 */       param = sql.getParameters();
/*     */     }
/*  72 */     return (BOVmTemplateVersionBean[])getBeans(cols, condition, param, startNum, endNum, isShowFK);
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeans(String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  79 */     return getBeans(null, condition, parameter, -1, -1, false);
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK) throws Exception
/*     */   {
/*  84 */     Connection conn = null;
/*     */     try {
/*  86 */       conn = ServiceManager.getSession().getConnection();
/*  87 */       BOVmTemplateVersionBean[] arrayOfBOVmTemplateVersionBean = (BOVmTemplateVersionBean[])(BOVmTemplateVersionBean[])ServiceManager.getDataStore().retrieve(conn, BOVmTemplateVersionBean.class, BOVmTemplateVersionBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, null);
/*     */ 
/*  93 */       return arrayOfBOVmTemplateVersionBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  91 */       if (conn != null)
/*  92 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK, String[] extendBOAttrs) throws Exception
/*     */   {
/*  98 */     Connection conn = null;
/*     */     try {
/* 100 */       conn = ServiceManager.getSession().getConnection();
/* 101 */       BOVmTemplateVersionBean[] arrayOfBOVmTemplateVersionBean = (BOVmTemplateVersionBean[])(BOVmTemplateVersionBean[])ServiceManager.getDataStore().retrieve(conn, BOVmTemplateVersionBean.class, BOVmTemplateVersionBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, extendBOAttrs);
/*     */ 
/* 107 */       return arrayOfBOVmTemplateVersionBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 105 */       if (conn != null)
/* 106 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter) throws Exception
/*     */   {
/* 112 */     Connection conn = null;
/*     */     try {
/* 114 */       conn = ServiceManager.getSession().getConnection();
/* 115 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVmTemplateVersionBean.getObjectTypeStatic(), condition, parameter, null);
/*     */ 
/* 121 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 119 */       if (conn != null)
/* 120 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter, String[] extendBOAttrs) throws Exception {
/* 125 */     Connection conn = null;
/*     */     try {
/* 127 */       conn = ServiceManager.getSession().getConnection();
/* 128 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVmTemplateVersionBean.getObjectTypeStatic(), condition, parameter, extendBOAttrs);
/*     */ 
/* 134 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 132 */       if (conn != null)
/* 133 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVmTemplateVersionBean aBean) throws Exception
/*     */   {
/* 139 */     Connection conn = null;
/*     */     try {
/* 141 */       conn = ServiceManager.getSession().getConnection();
/* 142 */       ServiceManager.getDataStore().save(conn, aBean);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 146 */       if (conn != null)
/* 147 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVmTemplateVersionBean[] aBeans) throws Exception {
/* 152 */     Connection conn = null;
/*     */     try {
/* 154 */       conn = ServiceManager.getSession().getConnection();
/* 155 */       ServiceManager.getDataStore().save(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 159 */       if (conn != null)
/* 160 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveBatch(BOVmTemplateVersionBean[] aBeans) throws Exception {
/* 165 */     Connection conn = null;
/*     */     try {
/* 167 */       conn = ServiceManager.getSession().getConnection();
/* 168 */       ServiceManager.getDataStore().saveBatch(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 172 */       if (conn != null)
/* 173 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeansFromQueryBO(String soureBO, Map parameter) throws Exception
/*     */   {
/* 179 */     Connection conn = null;
/* 180 */     ResultSet resultset = null;
/*     */     try {
/* 182 */       conn = ServiceManager.getSession().getConnection();
/* 183 */       String sql = ServiceManager.getObjectTypeFactory().getInstance(soureBO).getMapingEnty();
/* 184 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 185 */       BOVmTemplateVersionBean[] arrayOfBOVmTemplateVersionBean = (BOVmTemplateVersionBean[])(BOVmTemplateVersionBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVmTemplateVersionBean.class, BOVmTemplateVersionBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 192 */       return arrayOfBOVmTemplateVersionBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 189 */       if (resultset != null) resultset.close();
/* 190 */       if (conn != null)
/* 191 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] getBeansFromSql(String sql, Map parameter) throws Exception {
/* 196 */     Connection conn = null;
/* 197 */     ResultSet resultset = null;
/*     */     try {
/* 199 */       conn = ServiceManager.getSession().getConnection();
/* 200 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 201 */       BOVmTemplateVersionBean[] arrayOfBOVmTemplateVersionBean = (BOVmTemplateVersionBean[])(BOVmTemplateVersionBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVmTemplateVersionBean.class, BOVmTemplateVersionBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 208 */       return arrayOfBOVmTemplateVersionBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 205 */       if (resultset != null) resultset.close();
/* 206 */       if (conn != null)
/* 207 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId() throws Exception {
/* 212 */     return ServiceManager.getIdGenerator().getNewId(BOVmTemplateVersionBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static Timestamp getSysDate() throws Exception
/*     */   {
/* 217 */     return ServiceManager.getIdGenerator().getSysDate(BOVmTemplateVersionBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean wrap(DataContainerInterface source, Map colMatch, boolean canModify)
/*     */   {
/*     */     try {
/* 223 */       return (BOVmTemplateVersionBean)DataContainerFactory.wrap(source, BOVmTemplateVersionBean.class, colMatch, canModify);
/*     */     } catch (Exception e) {
/* 225 */       if (e.getCause() != null) {
/* 226 */         throw new RuntimeException(e.getCause());
/*     */       }
/* 228 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean copy(DataContainerInterface source, Map colMatch, boolean canModify) {
/*     */     try {
/* 233 */       BOVmTemplateVersionBean result = new BOVmTemplateVersionBean();
/* 234 */       DataContainerFactory.copy(source, result, colMatch);
/* 235 */       return result;
/*     */     }
/*     */     catch (AIException ex) {
/* 238 */       if (ex.getCause() != null) {
/* 239 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 241 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean transfer(IBOVmTemplateVersionValue value) {
/* 246 */     if (value == null)
/* 247 */       return null;
/*     */     try {
/* 249 */       if (value instanceof BOVmTemplateVersionBean) {
/* 250 */         return (BOVmTemplateVersionBean)value;
/*     */       }
/* 252 */       BOVmTemplateVersionBean newBean = new BOVmTemplateVersionBean();
/*     */ 
/* 254 */       DataContainerFactory.transfer(value, newBean);
/* 255 */       return newBean;
/*     */     } catch (Exception ex) {
/* 257 */       if (ex.getCause() != null) {
/* 258 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 260 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmTemplateVersionBean[] transfer(IBOVmTemplateVersionValue[] value) {
/* 265 */     if ((value == null) || (value.length == 0))
/* 266 */       return null;
/*     */     try
/*     */     {
/* 269 */       if (value instanceof BOVmTemplateVersionBean[]) {
/* 270 */         return (BOVmTemplateVersionBean[])(BOVmTemplateVersionBean[])value;
/*     */       }
/* 272 */       BOVmTemplateVersionBean[] newBeans = new BOVmTemplateVersionBean[value.length];
/* 273 */       for (int i = 0; i < newBeans.length; ++i) {
/* 274 */         newBeans[i] = new BOVmTemplateVersionBean();
/* 275 */         DataContainerFactory.transfer(value[i], newBeans[i]);
/*     */       }
/* 277 */       return newBeans;
/*     */     } catch (Exception ex) {
/* 279 */       if (ex.getCause() != null) {
/* 280 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 282 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmTemplateVersionValue aValue) throws Exception {
/* 287 */     save(transfer(aValue));
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmTemplateVersionValue[] aValues) throws Exception {
/* 291 */     save(transfer(aValues));
/*     */   }
/*     */ 
/*     */   public static void saveBatch(IBOVmTemplateVersionValue[] aValues) throws Exception {
/* 295 */     saveBatch(transfer(aValues));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmTemplateVersionEngine
 * JD-Core Version:    0.5.4
 */