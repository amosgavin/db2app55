/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmExceptionCodeDescRelatBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmExceptionCodeDescRelatValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmExceptionCodeDescRelat";
/*     */   public static final String S_ExceptionCode = "EXCEPTION_CODE";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";
/*  24 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmExceptionCodeDescRelatBean()
/*     */     throws AIException
/*     */   {
/*  33 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  37 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  42 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initExceptionCode(String value)
/*     */   {
/*  47 */     initProperty("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCode(String value) {
/*  50 */     set("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCodeNull() {
/*  53 */     set("EXCEPTION_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionCode() {
/*  57 */     return DataType.getAsString(get("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionCodeInitialValue() {
/*  61 */     return DataType.getAsString(getOldObj("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  65 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  68 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  71 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  75 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  79 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/*  83 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/*  86 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/*  89 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/*  93 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/*  97 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionDescCode(String value) {
/* 101 */     initProperty("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCode(String value) {
/* 104 */     set("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCodeNull() {
/* 107 */     set("EXCEPTION_DESC_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCode() {
/* 111 */     return DataType.getAsString(get("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCodeInitialValue() {
/* 115 */     return DataType.getAsString(getOldObj("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  27 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  29 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmExceptionCodeDescRelatBean
 * JD-Core Version:    0.5.4
 */