/*    */ package com.ai.comframe.config.bo;
/*    */ 
/*    */ import com.ai.appframe2.bo.DataContainer;
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import com.ai.appframe2.common.ObjectTypeFactory;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class BOVmHoliDayBean extends DataContainer
/*    */   implements DataContainerInterface, IBOVmHoliDayValue
/*    */ {
/* 15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmHoliDay";
/*    */   public static final String S_Holiday = "HOLIDAY";
/* 21 */   public static ObjectType S_TYPE = null;
/*    */ 
/*    */   public BOVmHoliDayBean()
/*    */     throws AIException
/*    */   {
/* 30 */     super(S_TYPE);
/*    */   }
/*    */ 
/*    */   public static ObjectType getObjectTypeStatic() throws AIException {
/* 34 */     return S_TYPE;
/*    */   }
/*    */ 
/*    */   public void setObjectType(ObjectType value) throws AIException
/*    */   {
/* 39 */     throw new AIException("Cannot reset ObjectType");
/*    */   }
/*    */ 
/*    */   public void initHoliday(Timestamp value)
/*    */   {
/* 44 */     initProperty("HOLIDAY", value);
/*    */   }
/*    */   public void setHoliday(Timestamp value) {
/* 47 */     set("HOLIDAY", value);
/*    */   }
/*    */   public void setHolidayNull() {
/* 50 */     set("HOLIDAY", null);
/*    */   }
/*    */ 
/*    */   public Timestamp getHoliday() {
/* 54 */     return DataType.getAsDateTime(get("HOLIDAY"));
/*    */   }
/*    */ 
/*    */   public Timestamp getHolidayInitialValue() {
/* 58 */     return DataType.getAsDateTime(getOldObj("HOLIDAY"));
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 24 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*    */     } catch (Exception e) {
/* 26 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmHoliDayBean
 * JD-Core Version:    0.5.4
 */