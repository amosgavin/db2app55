/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class QBOVmTemplateBean extends DataContainer
/*     */   implements DataContainerInterface, IQBOVmTemplateValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.QBOVmTemplate";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_OrderNum = "ORDER_NUM";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_ExpireDate = "EXPIRE_DATE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*     */   public static final String S_CreateStaff = "CREATE_STAFF";
/*     */   public static final String S_Publish = "PUBLISH";
/*     */   public static final String S_TemplateType = "TEMPLATE_TYPE";
/*     */   public static final String S_ValidDate = "VALID_DATE";
/*     */   public static final String S_ModifyDesc = "MODIFY_DESC";
/*     */   public static final String S_Remark = "REMARK";
/*  36 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public QBOVmTemplateBean()
/*     */     throws AIException
/*     */   {
/*  45 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  49 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  54 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  59 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  62 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  65 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  69 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  73 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initOrderNum(long value) {
/*  77 */     initProperty("ORDER_NUM", new Long(value));
/*     */   }
/*     */   public void setOrderNum(long value) {
/*  80 */     set("ORDER_NUM", new Long(value));
/*     */   }
/*     */   public void setOrderNumNull() {
/*  83 */     set("ORDER_NUM", null);
/*     */   }
/*     */ 
/*     */   public long getOrderNum() {
/*  87 */     return DataType.getAsLong(get("ORDER_NUM"));
/*     */   }
/*     */ 
/*     */   public long getOrderNumInitialValue() {
/*  91 */     return DataType.getAsLong(getOldObj("ORDER_NUM"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/*  95 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/*  98 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 101 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 105 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 109 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 113 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 116 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 119 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 123 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 127 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 131 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 134 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 137 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 141 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 145 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 149 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 152 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 155 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 159 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 163 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initEngineType(String value) {
/* 167 */     initProperty("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineType(String value) {
/* 170 */     set("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineTypeNull() {
/* 173 */     set("ENGINE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/* 177 */     return DataType.getAsString(get("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getEngineTypeInitialValue() {
/* 181 */     return DataType.getAsString(getOldObj("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initExpireDate(Timestamp value) {
/* 185 */     initProperty("EXPIRE_DATE", value);
/*     */   }
/*     */   public void setExpireDate(Timestamp value) {
/* 188 */     set("EXPIRE_DATE", value);
/*     */   }
/*     */   public void setExpireDateNull() {
/* 191 */     set("EXPIRE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExpireDate() {
/* 195 */     return DataType.getAsDateTime(get("EXPIRE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExpireDateInitialValue() {
/* 199 */     return DataType.getAsDateTime(getOldObj("EXPIRE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 203 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 206 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 209 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 213 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 217 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 221 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 224 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 227 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 231 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 235 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateStaff(String value) {
/* 239 */     initProperty("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaff(String value) {
/* 242 */     set("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaffNull() {
/* 245 */     set("CREATE_STAFF", null);
/*     */   }
/*     */ 
/*     */   public String getCreateStaff() {
/* 249 */     return DataType.getAsString(get("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public String getCreateStaffInitialValue() {
/* 253 */     return DataType.getAsString(getOldObj("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public void initPublish(String value) {
/* 257 */     initProperty("PUBLISH", value);
/*     */   }
/*     */   public void setPublish(String value) {
/* 260 */     set("PUBLISH", value);
/*     */   }
/*     */   public void setPublishNull() {
/* 263 */     set("PUBLISH", null);
/*     */   }
/*     */ 
/*     */   public String getPublish() {
/* 267 */     return DataType.getAsString(get("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public String getPublishInitialValue() {
/* 271 */     return DataType.getAsString(getOldObj("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public void initTemplateType(String value) {
/* 275 */     initProperty("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateType(String value) {
/* 278 */     set("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateTypeNull() {
/* 281 */     set("TEMPLATE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateType() {
/* 285 */     return DataType.getAsString(get("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTypeInitialValue() {
/* 289 */     return DataType.getAsString(getOldObj("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initValidDate(Timestamp value) {
/* 293 */     initProperty("VALID_DATE", value);
/*     */   }
/*     */   public void setValidDate(Timestamp value) {
/* 296 */     set("VALID_DATE", value);
/*     */   }
/*     */   public void setValidDateNull() {
/* 299 */     set("VALID_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getValidDate() {
/* 303 */     return DataType.getAsDateTime(get("VALID_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getValidDateInitialValue() {
/* 307 */     return DataType.getAsDateTime(getOldObj("VALID_DATE"));
/*     */   }
/*     */ 
/*     */   public void initModifyDesc(String value) {
/* 311 */     initProperty("MODIFY_DESC", value);
/*     */   }
/*     */   public void setModifyDesc(String value) {
/* 314 */     set("MODIFY_DESC", value);
/*     */   }
/*     */   public void setModifyDescNull() {
/* 317 */     set("MODIFY_DESC", null);
/*     */   }
/*     */ 
/*     */   public String getModifyDesc() {
/* 321 */     return DataType.getAsString(get("MODIFY_DESC"));
/*     */   }
/*     */ 
/*     */   public String getModifyDescInitialValue() {
/* 325 */     return DataType.getAsString(getOldObj("MODIFY_DESC"));
/*     */   }
/*     */ 
/*     */   public void initRemark(String value) {
/* 329 */     initProperty("REMARK", value);
/*     */   }
/*     */   public void setRemark(String value) {
/* 332 */     set("REMARK", value);
/*     */   }
/*     */   public void setRemarkNull() {
/* 335 */     set("REMARK", null);
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 339 */     return DataType.getAsString(get("REMARK"));
/*     */   }
/*     */ 
/*     */   public String getRemarkInitialValue() {
/* 343 */     return DataType.getAsString(getOldObj("REMARK"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  39 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  41 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.QBOVmTemplateBean
 * JD-Core Version:    0.5.4
 */