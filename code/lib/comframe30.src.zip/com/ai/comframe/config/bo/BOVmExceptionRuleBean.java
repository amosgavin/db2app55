/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmExceptionRuleBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmExceptionRuleValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmExceptionRule";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_NextTemplateTag = "NEXT_TEMPLATE_TAG";
/*     */   public static final String S_ExceptionRuleRemarks = "EXCEPTION_RULE_REMARKS";
/*     */   public static final String S_CurrentTemplateTag = "CURRENT_TEMPLATE_TAG";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";
/*     */   public static final String S_ExceptionRuleId = "EXCEPTION_RULE_ID";
/*  27 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmExceptionRuleBean()
/*     */     throws AIException
/*     */   {
/*  36 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  40 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  45 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  50 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  53 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  56 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  60 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  64 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initNextTemplateTag(String value) {
/*  68 */     initProperty("NEXT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setNextTemplateTag(String value) {
/*  71 */     set("NEXT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setNextTemplateTagNull() {
/*  74 */     set("NEXT_TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getNextTemplateTag() {
/*  78 */     return DataType.getAsString(get("NEXT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getNextTemplateTagInitialValue() {
/*  82 */     return DataType.getAsString(getOldObj("NEXT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initExceptionRuleRemarks(String value) {
/*  86 */     initProperty("EXCEPTION_RULE_REMARKS", value);
/*     */   }
/*     */   public void setExceptionRuleRemarks(String value) {
/*  89 */     set("EXCEPTION_RULE_REMARKS", value);
/*     */   }
/*     */   public void setExceptionRuleRemarksNull() {
/*  92 */     set("EXCEPTION_RULE_REMARKS", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionRuleRemarks() {
/*  96 */     return DataType.getAsString(get("EXCEPTION_RULE_REMARKS"));
/*     */   }
/*     */ 
/*     */   public String getExceptionRuleRemarksInitialValue() {
/* 100 */     return DataType.getAsString(getOldObj("EXCEPTION_RULE_REMARKS"));
/*     */   }
/*     */ 
/*     */   public void initCurrentTemplateTag(String value) {
/* 104 */     initProperty("CURRENT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setCurrentTemplateTag(String value) {
/* 107 */     set("CURRENT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setCurrentTemplateTagNull() {
/* 110 */     set("CURRENT_TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getCurrentTemplateTag() {
/* 114 */     return DataType.getAsString(get("CURRENT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getCurrentTemplateTagInitialValue() {
/* 118 */     return DataType.getAsString(getOldObj("CURRENT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 122 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 125 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 128 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 132 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 136 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionDescCode(String value) {
/* 140 */     initProperty("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCode(String value) {
/* 143 */     set("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCodeNull() {
/* 146 */     set("EXCEPTION_DESC_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCode() {
/* 150 */     return DataType.getAsString(get("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCodeInitialValue() {
/* 154 */     return DataType.getAsString(getOldObj("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionRuleId(long value) {
/* 158 */     initProperty("EXCEPTION_RULE_ID", new Long(value));
/*     */   }
/*     */   public void setExceptionRuleId(long value) {
/* 161 */     set("EXCEPTION_RULE_ID", new Long(value));
/*     */   }
/*     */   public void setExceptionRuleIdNull() {
/* 164 */     set("EXCEPTION_RULE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getExceptionRuleId() {
/* 168 */     return DataType.getAsLong(get("EXCEPTION_RULE_ID"));
/*     */   }
/*     */ 
/*     */   public long getExceptionRuleIdInitialValue() {
/* 172 */     return DataType.getAsLong(getOldObj("EXCEPTION_RULE_ID"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  30 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  32 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmExceptionRuleBean
 * JD-Core Version:    0.5.4
 */