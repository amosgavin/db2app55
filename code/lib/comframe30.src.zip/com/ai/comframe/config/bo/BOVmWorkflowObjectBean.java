/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmWorkflowObjectBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmWorkflowObjectValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmWorkflowObject";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_Code = "CODE";
/*     */   public static final String S_Name = "NAME";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_Remark = "REMARK";
/*  25 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmWorkflowObjectBean()
/*     */     throws AIException
/*     */   {
/*  34 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  38 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  43 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  48 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  51 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  54 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  58 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  62 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initCode(String value) {
/*  66 */     initProperty("CODE", value);
/*     */   }
/*     */   public void setCode(String value) {
/*  69 */     set("CODE", value);
/*     */   }
/*     */   public void setCodeNull() {
/*  72 */     set("CODE", null);
/*     */   }
/*     */ 
/*     */   public String getCode() {
/*  76 */     return DataType.getAsString(get("CODE"));
/*     */   }
/*     */ 
/*     */   public String getCodeInitialValue() {
/*  80 */     return DataType.getAsString(getOldObj("CODE"));
/*     */   }
/*     */ 
/*     */   public void initName(String value) {
/*  84 */     initProperty("NAME", value);
/*     */   }
/*     */   public void setName(String value) {
/*  87 */     set("NAME", value);
/*     */   }
/*     */   public void setNameNull() {
/*  90 */     set("NAME", null);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  94 */     return DataType.getAsString(get("NAME"));
/*     */   }
/*     */ 
/*     */   public String getNameInitialValue() {
/*  98 */     return DataType.getAsString(getOldObj("NAME"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 102 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 105 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 108 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 112 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 116 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRemark(String value) {
/* 120 */     initProperty("REMARK", value);
/*     */   }
/*     */   public void setRemark(String value) {
/* 123 */     set("REMARK", value);
/*     */   }
/*     */   public void setRemarkNull() {
/* 126 */     set("REMARK", null);
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 130 */     return DataType.getAsString(get("REMARK"));
/*     */   }
/*     */ 
/*     */   public String getRemarkInitialValue() {
/* 134 */     return DataType.getAsString(getOldObj("REMARK"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  28 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  30 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmWorkflowObjectBean
 * JD-Core Version:    0.5.4
 */