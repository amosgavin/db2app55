/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*     */ 
/*     */ public class BOVmQueueConfigBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmQueueConfigValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmQueueConfig";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_FetchNum = "FETCH_NUM";
/*     */   public static final String S_SplitRegion = "SPLIT_REGION";
/*     */   public static final String S_TimeInterval = "TIME_INTERVAL";
/*     */   public static final String S_QueueType = "QUEUE_TYPE";
/*     */   public static final String S_Datasoure = "DATASOURE";
/*     */   public static final String S_SplitQueue = "SPLIT_QUEUE";
/*     */   public static final String S_Remark = "REMARK";
/*  29 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmQueueConfigBean()
/*     */     throws AIException
/*     */   {
/*  38 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  42 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  47 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  52 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  55 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  58 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  62 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  66 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/*  70 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/*  73 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/*  76 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/*  80 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/*  84 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initFetchNum(int value) {
/*  88 */     initProperty("FETCH_NUM", new Integer(value));
/*     */   }
/*     */   public void setFetchNum(int value) {
/*  91 */     set("FETCH_NUM", new Integer(value));
/*     */   }
/*     */   public void setFetchNumNull() {
/*  94 */     set("FETCH_NUM", null);
/*     */   }
/*     */ 
/*     */   public int getFetchNum() {
/*  98 */     return DataType.getAsInt(get("FETCH_NUM"));
/*     */   }
/*     */ 
/*     */   public int getFetchNumInitialValue() {
/* 102 */     return DataType.getAsInt(getOldObj("FETCH_NUM"));
/*     */   }
/*     */ 
/*     */   public void initSplitRegion(String value) {
/* 106 */     initProperty("SPLIT_REGION", value);
/*     */   }
/*     */   public void setSplitRegion(String value) {
/* 109 */     set("SPLIT_REGION", value);
/*     */   }
/*     */   public void setSplitRegionNull() {
/* 112 */     set("SPLIT_REGION", null);
/*     */   }
/*     */ 
/*     */   public String getSplitRegion() {
/* 116 */     return DataType.getAsString(get("SPLIT_REGION"));
/*     */   }
/*     */ 
/*     */   public String getSplitRegionInitialValue() {
/* 120 */     return DataType.getAsString(getOldObj("SPLIT_REGION"));
/*     */   }
/*     */ 
/*     */   public void initTimeInterval(long value) {
/* 124 */     initProperty("TIME_INTERVAL", new Long(value));
/*     */   }
/*     */   public void setTimeInterval(long value) {
/* 127 */     set("TIME_INTERVAL", new Long(value));
/*     */   }
/*     */   public void setTimeIntervalNull() {
/* 130 */     set("TIME_INTERVAL", null);
/*     */   }
/*     */ 
/*     */   public long getTimeInterval() {
/* 134 */     return DataType.getAsLong(get("TIME_INTERVAL"));
/*     */   }
/*     */ 
/*     */   public long getTimeIntervalInitialValue() {
/* 138 */     return DataType.getAsLong(getOldObj("TIME_INTERVAL"));
/*     */   }
/*     */ 
/*     */   public void initQueueType(String value) {
/* 142 */     initProperty("QUEUE_TYPE", value);
/*     */   }
/*     */   public void setQueueType(String value) {
/* 145 */     set("QUEUE_TYPE", value);
/*     */   }
/*     */   public void setQueueTypeNull() {
/* 148 */     set("QUEUE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getQueueType() {
/* 152 */     return DataType.getAsString(get("QUEUE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getQueueTypeInitialValue() {
/* 156 */     return DataType.getAsString(getOldObj("QUEUE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initDatasoure(String value) {
/* 160 */     initProperty("DATASOURE", value);
/*     */   }
/*     */   public void setDatasoure(String value) {
/* 163 */     set("DATASOURE", value);
/*     */   }
/*     */   public void setDatasoureNull() {
/* 166 */     set("DATASOURE", null);
/*     */   }
/*     */ 
/*     */   public String getDatasoure() {
/* 170 */     return DataType.getAsString(get("DATASOURE"));
/*     */   }
/*     */ 
/*     */   public String getDatasoureInitialValue() {
/* 174 */     return DataType.getAsString(getOldObj("DATASOURE"));
/*     */   }
/*     */ 
/*     */   public void initSplitQueue(String value) {
/* 178 */     initProperty("SPLIT_QUEUE", value);
/*     */   }
/*     */   public void setSplitQueue(String value) {
/* 181 */     set("SPLIT_QUEUE", value);
/*     */   }
/*     */   public void setSplitQueueNull() {
/* 184 */     set("SPLIT_QUEUE", null);
/*     */   }
/*     */ 
/*     */   public String getSplitQueue() {
/* 188 */     return DataType.getAsString(get("SPLIT_QUEUE"));
/*     */   }
/*     */ 
/*     */   public String getSplitQueueInitialValue() {
/* 192 */     return DataType.getAsString(getOldObj("SPLIT_QUEUE"));
/*     */   }
/*     */ 
/*     */   public void initRemark(String value) {
/* 196 */     initProperty("REMARK", value);
/*     */   }
/*     */   public void setRemark(String value) {
/* 199 */     set("REMARK", value);
/*     */   }
/*     */   public void setRemarkNull() {
/* 202 */     set("REMARK", null);
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 206 */     return DataType.getAsString(get("REMARK"));
/*     */   }
/*     */ 
/*     */   public String getRemarkInitialValue() {
/* 210 */     return DataType.getAsString(getOldObj("REMARK"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  34 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmQueueConfigBean
 * JD-Core Version:    0.5.4
 */