/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmTemplateBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmTemplateValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmTemplate";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_CreateStaff = "CREATE_STAFF";
/*     */   public static final String S_Publish = "PUBLISH";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_TemplateType = "TEMPLATE_TYPE";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_Remark = "REMARK";
/*  31 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmTemplateBean()
/*     */     throws AIException
/*     */   {
/*  40 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  44 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  49 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  54 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  57 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  60 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  64 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  68 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initEngineType(String value) {
/*  72 */     initProperty("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineType(String value) {
/*  75 */     set("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineTypeNull() {
/*  78 */     set("ENGINE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/*  82 */     return DataType.getAsString(get("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getEngineTypeInitialValue() {
/*  86 */     return DataType.getAsString(getOldObj("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/*  90 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/*  93 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/*  96 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 100 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 104 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 108 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 111 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 114 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 118 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 122 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 126 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 129 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 132 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 136 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 140 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateStaff(String value) {
/* 144 */     initProperty("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaff(String value) {
/* 147 */     set("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaffNull() {
/* 150 */     set("CREATE_STAFF", null);
/*     */   }
/*     */ 
/*     */   public String getCreateStaff() {
/* 154 */     return DataType.getAsString(get("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public String getCreateStaffInitialValue() {
/* 158 */     return DataType.getAsString(getOldObj("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public void initPublish(String value) {
/* 162 */     initProperty("PUBLISH", value);
/*     */   }
/*     */   public void setPublish(String value) {
/* 165 */     set("PUBLISH", value);
/*     */   }
/*     */   public void setPublishNull() {
/* 168 */     set("PUBLISH", null);
/*     */   }
/*     */ 
/*     */   public String getPublish() {
/* 172 */     return DataType.getAsString(get("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public String getPublishInitialValue() {
/* 176 */     return DataType.getAsString(getOldObj("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 180 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 183 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 186 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 190 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 194 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateType(String value) {
/* 198 */     initProperty("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateType(String value) {
/* 201 */     set("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateTypeNull() {
/* 204 */     set("TEMPLATE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateType() {
/* 208 */     return DataType.getAsString(get("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTypeInitialValue() {
/* 212 */     return DataType.getAsString(getOldObj("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 216 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 219 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 222 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 226 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 230 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initRemark(String value) {
/* 234 */     initProperty("REMARK", value);
/*     */   }
/*     */   public void setRemark(String value) {
/* 237 */     set("REMARK", value);
/*     */   }
/*     */   public void setRemarkNull() {
/* 240 */     set("REMARK", null);
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 244 */     return DataType.getAsString(get("REMARK"));
/*     */   }
/*     */ 
/*     */   public String getRemarkInitialValue() {
/* 248 */     return DataType.getAsString(getOldObj("REMARK"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  34 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  36 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmTemplateBean
 * JD-Core Version:    0.5.4
 */