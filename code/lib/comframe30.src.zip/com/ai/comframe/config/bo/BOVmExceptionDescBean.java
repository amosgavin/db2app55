/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmExceptionDescBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmExceptionDescValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmExceptionDesc";
/*     */   public static final String S_ExceptionDescType = "EXCEPTION_DESC_TYPE";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";
/*     */   public static final String S_ExceptionDescName = "EXCEPTION_DESC_NAME";
/*  25 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmExceptionDescBean()
/*     */     throws AIException
/*     */   {
/*  34 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  38 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  43 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initExceptionDescType(String value)
/*     */   {
/*  48 */     initProperty("EXCEPTION_DESC_TYPE", value);
/*     */   }
/*     */   public void setExceptionDescType(String value) {
/*  51 */     set("EXCEPTION_DESC_TYPE", value);
/*     */   }
/*     */   public void setExceptionDescTypeNull() {
/*  54 */     set("EXCEPTION_DESC_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionDescType() {
/*  58 */     return DataType.getAsString(get("EXCEPTION_DESC_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionDescTypeInitialValue() {
/*  62 */     return DataType.getAsString(getOldObj("EXCEPTION_DESC_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  66 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  69 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  72 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  76 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  80 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/*  84 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/*  87 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/*  90 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/*  94 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/*  98 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionDescCode(String value) {
/* 102 */     initProperty("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCode(String value) {
/* 105 */     set("EXCEPTION_DESC_CODE", value);
/*     */   }
/*     */   public void setExceptionDescCodeNull() {
/* 108 */     set("EXCEPTION_DESC_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCode() {
/* 112 */     return DataType.getAsString(get("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionDescCodeInitialValue() {
/* 116 */     return DataType.getAsString(getOldObj("EXCEPTION_DESC_CODE"));
/*     */   }
/*     */ 
/*     */   public void initExceptionDescName(String value) {
/* 120 */     initProperty("EXCEPTION_DESC_NAME", value);
/*     */   }
/*     */   public void setExceptionDescName(String value) {
/* 123 */     set("EXCEPTION_DESC_NAME", value);
/*     */   }
/*     */   public void setExceptionDescNameNull() {
/* 126 */     set("EXCEPTION_DESC_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionDescName() {
/* 130 */     return DataType.getAsString(get("EXCEPTION_DESC_NAME"));
/*     */   }
/*     */ 
/*     */   public String getExceptionDescNameInitialValue() {
/* 134 */     return DataType.getAsString(getOldObj("EXCEPTION_DESC_NAME"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  28 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  30 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmExceptionDescBean
 * JD-Core Version:    0.5.4
 */