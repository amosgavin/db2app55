/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainerFactory;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.appframe2.util.criteria.UniqueList;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueServerRegistValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BOVmQueueServerRegistEngine
/*     */ {
/*     */   public static BOVmQueueServerRegistBean[] getBeans(DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  19 */     Map ps = dc.getProperties();
/*  20 */     StringBuffer buffer = new StringBuffer();
/*  21 */     Map pList = new HashMap();
/*  22 */     for (Iterator cc = ps.entrySet().iterator(); cc.hasNext(); ) {
/*  23 */       e = (Map.Entry)cc.next();
/*  24 */       if (buffer.length() > 0)
/*  25 */         buffer.append(" and ");
/*  26 */       buffer.append(e.getKey().toString() + " = :p_" + e.getKey().toString());
/*  27 */       pList.put("p_" + e.getKey().toString(), e.getValue());
/*     */     }
/*     */     Map.Entry e;
/*  29 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try {
/*  31 */       e = getBeans(buffer.toString(), pList);
/*     */ 
/*  35 */       return e;
/*     */     }
/*     */     finally
/*     */     {
/*  33 */       if (conn != null)
/*  34 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean getBean(long _RegistId) throws Exception
/*     */   {
/*  40 */     String condition = "REGIST_ID = :S_REGIST_ID";
/*  41 */     Map map = new HashMap();
/*  42 */     map.put("S_REGIST_ID", new Long(_RegistId));
/*     */ 
/*  44 */     BOVmQueueServerRegistBean[] beans = getBeans(condition, map);
/*  45 */     if ((beans != null) && (beans.length == 1))
/*  46 */       return beans[0];
/*  47 */     if ((beans != null) && (beans.length > 1))
/*     */     {
/*  49 */       throw new Exception("[ERROR]More datas than one queryed by PK");
/*     */     }
/*  51 */     BOVmQueueServerRegistBean bean = new BOVmQueueServerRegistBean();
/*  52 */     bean.setRegistId(_RegistId);
/*  53 */     return bean;
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeans(Criteria sql) throws Exception
/*     */   {
/*  58 */     return getBeans(sql, -1, -1, false);
/*     */   }
/*     */   public static BOVmQueueServerRegistBean[] getBeans(Criteria sql, int startNum, int endNum, boolean isShowFK) throws Exception {
/*  61 */     String[] cols = null;
/*  62 */     String condition = "";
/*  63 */     Map param = null;
/*  64 */     if (sql != null) {
/*  65 */       cols = (String[])(String[])sql.getSelectColumns().toArray(new String[0]);
/*  66 */       condition = sql.toString();
/*  67 */       param = sql.getParameters();
/*     */     }
/*  69 */     return (BOVmQueueServerRegistBean[])getBeans(cols, condition, param, startNum, endNum, isShowFK);
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeans(String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  76 */     return getBeans(null, condition, parameter, -1, -1, false);
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK) throws Exception
/*     */   {
/*  81 */     Connection conn = null;
/*     */     try {
/*  83 */       conn = ServiceManager.getSession().getConnection();
/*  84 */       BOVmQueueServerRegistBean[] arrayOfBOVmQueueServerRegistBean = (BOVmQueueServerRegistBean[])(BOVmQueueServerRegistBean[])ServiceManager.getDataStore().retrieve(conn, BOVmQueueServerRegistBean.class, BOVmQueueServerRegistBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, null);
/*     */ 
/*  90 */       return arrayOfBOVmQueueServerRegistBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  88 */       if (conn != null)
/*  89 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK, String[] extendBOAttrs) throws Exception
/*     */   {
/*  95 */     Connection conn = null;
/*     */     try {
/*  97 */       conn = ServiceManager.getSession().getConnection();
/*  98 */       BOVmQueueServerRegistBean[] arrayOfBOVmQueueServerRegistBean = (BOVmQueueServerRegistBean[])(BOVmQueueServerRegistBean[])ServiceManager.getDataStore().retrieve(conn, BOVmQueueServerRegistBean.class, BOVmQueueServerRegistBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, extendBOAttrs);
/*     */ 
/* 104 */       return arrayOfBOVmQueueServerRegistBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 102 */       if (conn != null)
/* 103 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter) throws Exception
/*     */   {
/* 109 */     Connection conn = null;
/*     */     try {
/* 111 */       conn = ServiceManager.getSession().getConnection();
/* 112 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVmQueueServerRegistBean.getObjectTypeStatic(), condition, parameter, null);
/*     */ 
/* 118 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 116 */       if (conn != null)
/* 117 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter, String[] extendBOAttrs) throws Exception {
/* 122 */     Connection conn = null;
/*     */     try {
/* 124 */       conn = ServiceManager.getSession().getConnection();
/* 125 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVmQueueServerRegistBean.getObjectTypeStatic(), condition, parameter, extendBOAttrs);
/*     */ 
/* 131 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 129 */       if (conn != null)
/* 130 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVmQueueServerRegistBean aBean) throws Exception
/*     */   {
/* 136 */     Connection conn = null;
/*     */     try {
/* 138 */       conn = ServiceManager.getSession().getConnection();
/* 139 */       ServiceManager.getDataStore().save(conn, aBean);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 143 */       if (conn != null)
/* 144 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVmQueueServerRegistBean[] aBeans) throws Exception {
/* 149 */     Connection conn = null;
/*     */     try {
/* 151 */       conn = ServiceManager.getSession().getConnection();
/* 152 */       ServiceManager.getDataStore().save(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 156 */       if (conn != null)
/* 157 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveBatch(BOVmQueueServerRegistBean[] aBeans) throws Exception {
/* 162 */     Connection conn = null;
/*     */     try {
/* 164 */       conn = ServiceManager.getSession().getConnection();
/* 165 */       ServiceManager.getDataStore().saveBatch(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 169 */       if (conn != null)
/* 170 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeansFromQueryBO(String soureBO, Map parameter) throws Exception
/*     */   {
/* 176 */     Connection conn = null;
/* 177 */     ResultSet resultset = null;
/*     */     try {
/* 179 */       conn = ServiceManager.getSession().getConnection();
/* 180 */       String sql = ServiceManager.getObjectTypeFactory().getInstance(soureBO).getMapingEnty();
/* 181 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 182 */       BOVmQueueServerRegistBean[] arrayOfBOVmQueueServerRegistBean = (BOVmQueueServerRegistBean[])(BOVmQueueServerRegistBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVmQueueServerRegistBean.class, BOVmQueueServerRegistBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 189 */       return arrayOfBOVmQueueServerRegistBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 186 */       if (resultset != null) resultset.close();
/* 187 */       if (conn != null)
/* 188 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] getBeansFromSql(String sql, Map parameter) throws Exception {
/* 193 */     Connection conn = null;
/* 194 */     ResultSet resultset = null;
/*     */     try {
/* 196 */       conn = ServiceManager.getSession().getConnection();
/* 197 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 198 */       BOVmQueueServerRegistBean[] arrayOfBOVmQueueServerRegistBean = (BOVmQueueServerRegistBean[])(BOVmQueueServerRegistBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVmQueueServerRegistBean.class, BOVmQueueServerRegistBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 205 */       return arrayOfBOVmQueueServerRegistBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 202 */       if (resultset != null) resultset.close();
/* 203 */       if (conn != null)
/* 204 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId() throws Exception {
/* 209 */     return ServiceManager.getIdGenerator().getNewId(BOVmQueueServerRegistBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static Timestamp getSysDate() throws Exception
/*     */   {
/* 214 */     return ServiceManager.getIdGenerator().getSysDate(BOVmQueueServerRegistBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean wrap(DataContainerInterface source, Map colMatch, boolean canModify)
/*     */   {
/*     */     try {
/* 220 */       return (BOVmQueueServerRegistBean)DataContainerFactory.wrap(source, BOVmQueueServerRegistBean.class, colMatch, canModify);
/*     */     } catch (Exception e) {
/* 222 */       if (e.getCause() != null) {
/* 223 */         throw new RuntimeException(e.getCause());
/*     */       }
/* 225 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean copy(DataContainerInterface source, Map colMatch, boolean canModify) {
/*     */     try {
/* 230 */       BOVmQueueServerRegistBean result = new BOVmQueueServerRegistBean();
/* 231 */       DataContainerFactory.copy(source, result, colMatch);
/* 232 */       return result;
/*     */     }
/*     */     catch (AIException ex) {
/* 235 */       if (ex.getCause() != null) {
/* 236 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 238 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean transfer(IBOVmQueueServerRegistValue value) {
/* 243 */     if (value == null)
/* 244 */       return null;
/*     */     try {
/* 246 */       if (value instanceof BOVmQueueServerRegistBean) {
/* 247 */         return (BOVmQueueServerRegistBean)value;
/*     */       }
/* 249 */       BOVmQueueServerRegistBean newBean = new BOVmQueueServerRegistBean();
/*     */ 
/* 251 */       DataContainerFactory.transfer(value, newBean);
/* 252 */       return newBean;
/*     */     } catch (Exception ex) {
/* 254 */       if (ex.getCause() != null) {
/* 255 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 257 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVmQueueServerRegistBean[] transfer(IBOVmQueueServerRegistValue[] value) {
/* 262 */     if ((value == null) || (value.length == 0))
/* 263 */       return null;
/*     */     try
/*     */     {
/* 266 */       if (value instanceof BOVmQueueServerRegistBean[]) {
/* 267 */         return (BOVmQueueServerRegistBean[])(BOVmQueueServerRegistBean[])value;
/*     */       }
/* 269 */       BOVmQueueServerRegistBean[] newBeans = new BOVmQueueServerRegistBean[value.length];
/* 270 */       for (int i = 0; i < newBeans.length; ++i) {
/* 271 */         newBeans[i] = new BOVmQueueServerRegistBean();
/* 272 */         DataContainerFactory.transfer(value[i], newBeans[i]);
/*     */       }
/* 274 */       return newBeans;
/*     */     } catch (Exception ex) {
/* 276 */       if (ex.getCause() != null) {
/* 277 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 279 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmQueueServerRegistValue aValue) throws Exception {
/* 284 */     save(transfer(aValue));
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmQueueServerRegistValue[] aValues) throws Exception {
/* 288 */     save(transfer(aValues));
/*     */   }
/*     */ 
/*     */   public static void saveBatch(IBOVmQueueServerRegistValue[] aValues) throws Exception {
/* 292 */     saveBatch(transfer(aValues));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmQueueServerRegistEngine
 * JD-Core Version:    0.5.4
 */