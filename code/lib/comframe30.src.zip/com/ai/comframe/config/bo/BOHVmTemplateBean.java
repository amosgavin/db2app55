/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOHVmTemplateValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOHVmTemplateBean extends DataContainer
/*     */   implements DataContainerInterface, IBOHVmTemplateValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOHVmTemplate";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_HisId = "HIS_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_CreateStaff = "CREATE_STAFF";
/*     */   public static final String S_Publish = "PUBLISH";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_TemplateType = "TEMPLATE_TYPE";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_Remark = "REMARK";
/*  32 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOHVmTemplateBean()
/*     */     throws AIException
/*     */   {
/*  41 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  45 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  50 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  55 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  58 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  61 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  65 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  69 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initEngineType(String value) {
/*  73 */     initProperty("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineType(String value) {
/*  76 */     set("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineTypeNull() {
/*  79 */     set("ENGINE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/*  83 */     return DataType.getAsString(get("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getEngineTypeInitialValue() {
/*  87 */     return DataType.getAsString(getOldObj("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/*  91 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/*  94 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/*  97 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 101 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 105 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initHisId(long value) {
/* 109 */     initProperty("HIS_ID", new Long(value));
/*     */   }
/*     */   public void setHisId(long value) {
/* 112 */     set("HIS_ID", new Long(value));
/*     */   }
/*     */   public void setHisIdNull() {
/* 115 */     set("HIS_ID", null);
/*     */   }
/*     */ 
/*     */   public long getHisId() {
/* 119 */     return DataType.getAsLong(get("HIS_ID"));
/*     */   }
/*     */ 
/*     */   public long getHisIdInitialValue() {
/* 123 */     return DataType.getAsLong(getOldObj("HIS_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 127 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 130 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 133 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 137 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 141 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 145 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 148 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 151 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 155 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 159 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateStaff(String value) {
/* 163 */     initProperty("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaff(String value) {
/* 166 */     set("CREATE_STAFF", value);
/*     */   }
/*     */   public void setCreateStaffNull() {
/* 169 */     set("CREATE_STAFF", null);
/*     */   }
/*     */ 
/*     */   public String getCreateStaff() {
/* 173 */     return DataType.getAsString(get("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public String getCreateStaffInitialValue() {
/* 177 */     return DataType.getAsString(getOldObj("CREATE_STAFF"));
/*     */   }
/*     */ 
/*     */   public void initPublish(String value) {
/* 181 */     initProperty("PUBLISH", value);
/*     */   }
/*     */   public void setPublish(String value) {
/* 184 */     set("PUBLISH", value);
/*     */   }
/*     */   public void setPublishNull() {
/* 187 */     set("PUBLISH", null);
/*     */   }
/*     */ 
/*     */   public String getPublish() {
/* 191 */     return DataType.getAsString(get("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public String getPublishInitialValue() {
/* 195 */     return DataType.getAsString(getOldObj("PUBLISH"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 199 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 202 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 205 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 209 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 213 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateType(String value) {
/* 217 */     initProperty("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateType(String value) {
/* 220 */     set("TEMPLATE_TYPE", value);
/*     */   }
/*     */   public void setTemplateTypeNull() {
/* 223 */     set("TEMPLATE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateType() {
/* 227 */     return DataType.getAsString(get("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTypeInitialValue() {
/* 231 */     return DataType.getAsString(getOldObj("TEMPLATE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 235 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 238 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 241 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 245 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 249 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initRemark(String value) {
/* 253 */     initProperty("REMARK", value);
/*     */   }
/*     */   public void setRemark(String value) {
/* 256 */     set("REMARK", value);
/*     */   }
/*     */   public void setRemarkNull() {
/* 259 */     set("REMARK", null);
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 263 */     return DataType.getAsString(get("REMARK"));
/*     */   }
/*     */ 
/*     */   public String getRemarkInitialValue() {
/* 267 */     return DataType.getAsString(getOldObj("REMARK"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  35 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  37 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOHVmTemplateBean
 * JD-Core Version:    0.5.4
 */