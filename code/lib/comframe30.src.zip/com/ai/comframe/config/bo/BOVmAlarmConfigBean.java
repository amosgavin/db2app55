/*     */ package com.ai.comframe.config.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ 
/*     */ public class BOVmAlarmConfigBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmAlarmConfigValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.config.bo.BOVmAlarmConfig";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_IsHoliday = "IS_HOLIDAY";
/*     */   public static final String S_DurationTimeMethod = "DURATION_TIME_METHOD";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*     */   public static final String S_AlarmTimeMethod = "ALARM_TIME_METHOD";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_AlarmConfigId = "ALARM_CONFIG_ID";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_AlarmDealMethod = "ALARM_DEAL_METHOD";
/*  29 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmAlarmConfigBean()
/*     */     throws AIException
/*     */   {
/*  38 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  42 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  47 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  52 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  55 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  58 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  62 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  66 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initIsHoliday(int value) {
/*  70 */     initProperty("IS_HOLIDAY", new Integer(value));
/*     */   }
/*     */   public void setIsHoliday(int value) {
/*  73 */     set("IS_HOLIDAY", new Integer(value));
/*     */   }
/*     */   public void setIsHolidayNull() {
/*  76 */     set("IS_HOLIDAY", null);
/*     */   }
/*     */ 
/*     */   public int getIsHoliday() {
/*  80 */     return DataType.getAsInt(get("IS_HOLIDAY"));
/*     */   }
/*     */ 
/*     */   public int getIsHolidayInitialValue() {
/*  84 */     return DataType.getAsInt(getOldObj("IS_HOLIDAY"));
/*     */   }
/*     */ 
/*     */   public void initDurationTimeMethod(String value) {
/*  88 */     initProperty("DURATION_TIME_METHOD", value);
/*     */   }
/*     */   public void setDurationTimeMethod(String value) {
/*  91 */     set("DURATION_TIME_METHOD", value);
/*     */   }
/*     */   public void setDurationTimeMethodNull() {
/*  94 */     set("DURATION_TIME_METHOD", null);
/*     */   }
/*     */ 
/*     */   public String getDurationTimeMethod() {
/*  98 */     return DataType.getAsString(get("DURATION_TIME_METHOD"));
/*     */   }
/*     */ 
/*     */   public String getDurationTimeMethodInitialValue() {
/* 102 */     return DataType.getAsString(getOldObj("DURATION_TIME_METHOD"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 106 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 109 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 112 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 116 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 120 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public void initAlarmTimeMethod(String value) {
/* 124 */     initProperty("ALARM_TIME_METHOD", value);
/*     */   }
/*     */   public void setAlarmTimeMethod(String value) {
/* 127 */     set("ALARM_TIME_METHOD", value);
/*     */   }
/*     */   public void setAlarmTimeMethodNull() {
/* 130 */     set("ALARM_TIME_METHOD", null);
/*     */   }
/*     */ 
/*     */   public String getAlarmTimeMethod() {
/* 134 */     return DataType.getAsString(get("ALARM_TIME_METHOD"));
/*     */   }
/*     */ 
/*     */   public String getAlarmTimeMethodInitialValue() {
/* 138 */     return DataType.getAsString(getOldObj("ALARM_TIME_METHOD"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 142 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 145 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 148 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 152 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 156 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initAlarmConfigId(long value) {
/* 160 */     initProperty("ALARM_CONFIG_ID", new Long(value));
/*     */   }
/*     */   public void setAlarmConfigId(long value) {
/* 163 */     set("ALARM_CONFIG_ID", new Long(value));
/*     */   }
/*     */   public void setAlarmConfigIdNull() {
/* 166 */     set("ALARM_CONFIG_ID", null);
/*     */   }
/*     */ 
/*     */   public long getAlarmConfigId() {
/* 170 */     return DataType.getAsLong(get("ALARM_CONFIG_ID"));
/*     */   }
/*     */ 
/*     */   public long getAlarmConfigIdInitialValue() {
/* 174 */     return DataType.getAsLong(getOldObj("ALARM_CONFIG_ID"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 178 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 181 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 184 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 188 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 192 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initAlarmDealMethod(String value) {
/* 196 */     initProperty("ALARM_DEAL_METHOD", value);
/*     */   }
/*     */   public void setAlarmDealMethod(String value) {
/* 199 */     set("ALARM_DEAL_METHOD", value);
/*     */   }
/*     */   public void setAlarmDealMethodNull() {
/* 202 */     set("ALARM_DEAL_METHOD", null);
/*     */   }
/*     */ 
/*     */   public String getAlarmDealMethod() {
/* 206 */     return DataType.getAsString(get("ALARM_DEAL_METHOD"));
/*     */   }
/*     */ 
/*     */   public String getAlarmDealMethodInitialValue() {
/* 210 */     return DataType.getAsString(getOldObj("ALARM_DEAL_METHOD"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  34 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.bo.BOVmAlarmConfigBean
 * JD-Core Version:    0.5.4
 */