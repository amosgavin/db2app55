package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IBOVmQueueConfigValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_FetchNum = "FETCH_NUM";
  public static final String S_SplitRegion = "SPLIT_REGION";
  public static final String S_TimeInterval = "TIME_INTERVAL";
  public static final String S_QueueType = "QUEUE_TYPE";
  public static final String S_Datasoure = "DATASOURE";
  public static final String S_SplitQueue = "SPLIT_QUEUE";
  public static final String S_Remark = "REMARK";

  public abstract String getState();

  public abstract String getQueueId();

  public abstract int getFetchNum();

  public abstract String getSplitRegion();

  public abstract long getTimeInterval();

  public abstract String getQueueType();

  public abstract String getDatasoure();

  public abstract String getSplitQueue();

  public abstract String getRemark();

  public abstract void setState(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setFetchNum(int paramInt);

  public abstract void setSplitRegion(String paramString);

  public abstract void setTimeInterval(long paramLong);

  public abstract void setQueueType(String paramString);

  public abstract void setDatasoure(String paramString);

  public abstract void setSplitQueue(String paramString);

  public abstract void setRemark(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmQueueConfigValue
 * JD-Core Version:    0.5.4
 */