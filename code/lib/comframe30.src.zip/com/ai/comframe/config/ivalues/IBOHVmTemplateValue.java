package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOHVmTemplateValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_EngineType = "ENGINE_TYPE";
  public static final String S_Label = "LABEL";
  public static final String S_HisId = "HIS_ID";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_StateDate = "STATE_DATE";
  public static final String S_CreateStaff = "CREATE_STAFF";
  public static final String S_Publish = "PUBLISH";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_TemplateType = "TEMPLATE_TYPE";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_Remark = "REMARK";

  public abstract String getState();

  public abstract String getEngineType();

  public abstract String getLabel();

  public abstract long getHisId();

  public abstract String getQueueId();

  public abstract Timestamp getStateDate();

  public abstract String getCreateStaff();

  public abstract String getPublish();

  public abstract Timestamp getCreateDate();

  public abstract String getTemplateType();

  public abstract String getTemplateTag();

  public abstract String getRemark();

  public abstract void setState(String paramString);

  public abstract void setEngineType(String paramString);

  public abstract void setLabel(String paramString);

  public abstract void setHisId(long paramLong);

  public abstract void setQueueId(String paramString);

  public abstract void setStateDate(Timestamp paramTimestamp);

  public abstract void setCreateStaff(String paramString);

  public abstract void setPublish(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setTemplateType(String paramString);

  public abstract void setTemplateTag(String paramString);

  public abstract void setRemark(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOHVmTemplateValue
 * JD-Core Version:    0.5.4
 */