package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmEngineTemplateVersionValue extends DataStructInterface
{
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_EngineVerion = "ENGINE_VERION";
  public static final String S_EngineTemplateId = "ENGINE_TEMPLATE_ID";
  public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";

  public abstract Timestamp getCreateDate();

  public abstract String getEngineVerion();

  public abstract String getEngineTemplateId();

  public abstract long getTemplateVersionId();

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setEngineVerion(String paramString);

  public abstract void setEngineTemplateId(String paramString);

  public abstract void setTemplateVersionId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue
 * JD-Core Version:    0.5.4
 */