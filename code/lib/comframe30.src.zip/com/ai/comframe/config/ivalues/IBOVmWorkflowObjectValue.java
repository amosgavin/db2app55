package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmWorkflowObjectValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_Code = "CODE";
  public static final String S_Name = "NAME";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_Remark = "REMARK";

  public abstract String getState();

  public abstract String getCode();

  public abstract String getName();

  public abstract Timestamp getCreateDate();

  public abstract String getRemark();

  public abstract void setState(String paramString);

  public abstract void setCode(String paramString);

  public abstract void setName(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setRemark(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue
 * JD-Core Version:    0.5.4
 */