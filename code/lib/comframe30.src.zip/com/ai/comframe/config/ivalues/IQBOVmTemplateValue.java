package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IQBOVmTemplateValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_OrderNum = "ORDER_NUM";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_StateDate = "STATE_DATE";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_EngineType = "ENGINE_TYPE";
  public static final String S_ExpireDate = "EXPIRE_DATE";
  public static final String S_Label = "LABEL";
  public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
  public static final String S_CreateStaff = "CREATE_STAFF";
  public static final String S_Publish = "PUBLISH";
  public static final String S_TemplateType = "TEMPLATE_TYPE";
  public static final String S_ValidDate = "VALID_DATE";
  public static final String S_ModifyDesc = "MODIFY_DESC";
  public static final String S_Remark = "REMARK";

  public abstract String getState();

  public abstract long getOrderNum();

  public abstract String getQueueId();

  public abstract Timestamp getStateDate();

  public abstract Timestamp getCreateDate();

  public abstract String getTemplateTag();

  public abstract String getEngineType();

  public abstract Timestamp getExpireDate();

  public abstract String getLabel();

  public abstract long getTemplateVersionId();

  public abstract String getCreateStaff();

  public abstract String getPublish();

  public abstract String getTemplateType();

  public abstract Timestamp getValidDate();

  public abstract String getModifyDesc();

  public abstract String getRemark();

  public abstract void setState(String paramString);

  public abstract void setOrderNum(long paramLong);

  public abstract void setQueueId(String paramString);

  public abstract void setStateDate(Timestamp paramTimestamp);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setTemplateTag(String paramString);

  public abstract void setEngineType(String paramString);

  public abstract void setExpireDate(Timestamp paramTimestamp);

  public abstract void setLabel(String paramString);

  public abstract void setTemplateVersionId(long paramLong);

  public abstract void setCreateStaff(String paramString);

  public abstract void setPublish(String paramString);

  public abstract void setTemplateType(String paramString);

  public abstract void setValidDate(Timestamp paramTimestamp);

  public abstract void setModifyDesc(String paramString);

  public abstract void setRemark(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IQBOVmTemplateValue
 * JD-Core Version:    0.5.4
 */