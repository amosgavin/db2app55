package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmExceptionRuleValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_NextTemplateTag = "NEXT_TEMPLATE_TAG";
  public static final String S_ExceptionRuleRemarks = "EXCEPTION_RULE_REMARKS";
  public static final String S_CurrentTemplateTag = "CURRENT_TEMPLATE_TAG";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";
  public static final String S_ExceptionRuleId = "EXCEPTION_RULE_ID";

  public abstract String getState();

  public abstract String getNextTemplateTag();

  public abstract String getExceptionRuleRemarks();

  public abstract String getCurrentTemplateTag();

  public abstract Timestamp getCreateDate();

  public abstract String getExceptionDescCode();

  public abstract long getExceptionRuleId();

  public abstract void setState(String paramString);

  public abstract void setNextTemplateTag(String paramString);

  public abstract void setExceptionRuleRemarks(String paramString);

  public abstract void setCurrentTemplateTag(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setExceptionDescCode(String paramString);

  public abstract void setExceptionRuleId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue
 * JD-Core Version:    0.5.4
 */