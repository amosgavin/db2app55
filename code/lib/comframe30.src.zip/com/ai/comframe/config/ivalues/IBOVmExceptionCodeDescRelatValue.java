package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmExceptionCodeDescRelatValue extends DataStructInterface
{
  public static final String S_ExceptionCode = "EXCEPTION_CODE";
  public static final String S_State = "STATE";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";

  public abstract String getExceptionCode();

  public abstract String getState();

  public abstract Timestamp getCreateDate();

  public abstract String getExceptionDescCode();

  public abstract void setExceptionCode(String paramString);

  public abstract void setState(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setExceptionDescCode(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue
 * JD-Core Version:    0.5.4
 */