package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmTemplateVersionValue extends DataStructInterface
{
  public static final String S_Content10 = "CONTENT10";
  public static final String S_OrderNum = "ORDER_NUM";
  public static final String S_Content9 = "CONTENT9";
  public static final String S_Content5 = "CONTENT5";
  public static final String S_Content1 = "CONTENT1";
  public static final String S_CreateStaffId = "CREATE_STAFF_ID";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_Content8 = "CONTENT8";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_Content13 = "CONTENT13";
  public static final String S_Content4 = "CONTENT4";
  public static final String S_Content12 = "CONTENT12";
  public static final String S_ExpireDate = "EXPIRE_DATE";
  public static final String S_Content3 = "CONTENT3";
  public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
  public static final String S_Content7 = "CONTENT7";
  public static final String S_Content11 = "CONTENT11";
  public static final String S_Content14 = "CONTENT14";
  public static final String S_Content15 = "CONTENT15";
  public static final String S_Content6 = "CONTENT6";
  public static final String S_Content = "CONTENT";
  public static final String S_ValidDate = "VALID_DATE";
  public static final String S_ModifyDesc = "MODIFY_DESC";
  public static final String S_Content2 = "CONTENT2";

  public abstract String getContent10();

  public abstract int getOrderNum();

  public abstract String getContent9();

  public abstract String getContent5();

  public abstract String getContent1();

  public abstract String getCreateStaffId();

  public abstract Timestamp getCreateDate();

  public abstract String getContent8();

  public abstract String getTemplateTag();

  public abstract String getContent13();

  public abstract String getContent4();

  public abstract String getContent12();

  public abstract Timestamp getExpireDate();

  public abstract String getContent3();

  public abstract long getTemplateVersionId();

  public abstract String getContent7();

  public abstract String getContent11();

  public abstract String getContent14();

  public abstract String getContent15();

  public abstract String getContent6();

  public abstract String getContent();

  public abstract Timestamp getValidDate();

  public abstract String getModifyDesc();

  public abstract String getContent2();

  public abstract void setContent10(String paramString);

  public abstract void setOrderNum(int paramInt);

  public abstract void setContent9(String paramString);

  public abstract void setContent5(String paramString);

  public abstract void setContent1(String paramString);

  public abstract void setCreateStaffId(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setContent8(String paramString);

  public abstract void setTemplateTag(String paramString);

  public abstract void setContent13(String paramString);

  public abstract void setContent4(String paramString);

  public abstract void setContent12(String paramString);

  public abstract void setExpireDate(Timestamp paramTimestamp);

  public abstract void setContent3(String paramString);

  public abstract void setTemplateVersionId(long paramLong);

  public abstract void setContent7(String paramString);

  public abstract void setContent11(String paramString);

  public abstract void setContent14(String paramString);

  public abstract void setContent15(String paramString);

  public abstract void setContent6(String paramString);

  public abstract void setContent(String paramString);

  public abstract void setValidDate(Timestamp paramTimestamp);

  public abstract void setModifyDesc(String paramString);

  public abstract void setContent2(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue
 * JD-Core Version:    0.5.4
 */