package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmExceptionDescValue extends DataStructInterface
{
  public static final String S_ExceptionDescType = "EXCEPTION_DESC_TYPE";
  public static final String S_State = "STATE";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_ExceptionDescCode = "EXCEPTION_DESC_CODE";
  public static final String S_ExceptionDescName = "EXCEPTION_DESC_NAME";

  public abstract String getExceptionDescType();

  public abstract String getState();

  public abstract Timestamp getCreateDate();

  public abstract String getExceptionDescCode();

  public abstract String getExceptionDescName();

  public abstract void setExceptionDescType(String paramString);

  public abstract void setState(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setExceptionDescCode(String paramString);

  public abstract void setExceptionDescName(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmExceptionDescValue
 * JD-Core Version:    0.5.4
 */