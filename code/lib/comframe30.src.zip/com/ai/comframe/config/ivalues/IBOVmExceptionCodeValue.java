package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmExceptionCodeValue extends DataStructInterface
{
  public static final String S_ExceptionCode = "EXCEPTION_CODE";
  public static final String S_State = "STATE";
  public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_TaskTag = "TASK_TAG";
  public static final String S_ExceptionType = "EXCEPTION_TYPE";
  public static final String S_ExceptionName = "EXCEPTION_NAME";

  public abstract String getExceptionCode();

  public abstract String getState();

  public abstract String getWorkflowObjectType();

  public abstract Timestamp getCreateDate();

  public abstract String getTaskTag();

  public abstract String getExceptionType();

  public abstract String getExceptionName();

  public abstract void setExceptionCode(String paramString);

  public abstract void setState(String paramString);

  public abstract void setWorkflowObjectType(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setTaskTag(String paramString);

  public abstract void setExceptionType(String paramString);

  public abstract void setExceptionName(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue
 * JD-Core Version:    0.5.4
 */