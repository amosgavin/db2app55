package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmHoliDayValue extends DataStructInterface
{
  public static final String S_Holiday = "HOLIDAY";

  public abstract Timestamp getHoliday();

  public abstract void setHoliday(Timestamp paramTimestamp);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmHoliDayValue
 * JD-Core Version:    0.5.4
 */