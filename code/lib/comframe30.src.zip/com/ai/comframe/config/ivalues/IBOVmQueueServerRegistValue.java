package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmQueueServerRegistValue extends DataStructInterface
{
  public static final String S_RegistId = "REGIST_ID";
  public static final String S_State = "STATE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_HostIp = "HOST_IP";
  public static final String S_RegistDate = "REGIST_DATE";
  public static final String S_ProcessId = "PROCESS_ID";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_ModValue = "MOD_VALUE";
  public static final String S_Remarks = "REMARKS";
  public static final String S_ModParam = "MOD_PARAM";
  public static final String S_QueueType = "QUEUE_TYPE";
  public static final String S_HostName = "HOST_NAME";

  public abstract long getRegistId();

  public abstract String getState();

  public abstract String getRegionId();

  public abstract String getHostIp();

  public abstract Timestamp getRegistDate();

  public abstract String getProcessId();

  public abstract String getQueueId();

  public abstract String getModValue();

  public abstract String getRemarks();

  public abstract int getModParam();

  public abstract String getQueueType();

  public abstract String getHostName();

  public abstract void setRegistId(long paramLong);

  public abstract void setState(String paramString);

  public abstract void setRegionId(String paramString);

  public abstract void setHostIp(String paramString);

  public abstract void setRegistDate(Timestamp paramTimestamp);

  public abstract void setProcessId(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setModValue(String paramString);

  public abstract void setRemarks(String paramString);

  public abstract void setModParam(int paramInt);

  public abstract void setQueueType(String paramString);

  public abstract void setHostName(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmQueueServerRegistValue
 * JD-Core Version:    0.5.4
 */