package com.ai.comframe.config.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IBOVmAlarmConfigValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_IsHoliday = "IS_HOLIDAY";
  public static final String S_DurationTimeMethod = "DURATION_TIME_METHOD";
  public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
  public static final String S_AlarmTimeMethod = "ALARM_TIME_METHOD";
  public static final String S_TaskTag = "TASK_TAG";
  public static final String S_AlarmConfigId = "ALARM_CONFIG_ID";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_AlarmDealMethod = "ALARM_DEAL_METHOD";

  public abstract String getState();

  public abstract int getIsHoliday();

  public abstract String getDurationTimeMethod();

  public abstract long getTemplateVersionId();

  public abstract String getAlarmTimeMethod();

  public abstract String getTaskTag();

  public abstract long getAlarmConfigId();

  public abstract String getTemplateTag();

  public abstract String getAlarmDealMethod();

  public abstract void setState(String paramString);

  public abstract void setIsHoliday(int paramInt);

  public abstract void setDurationTimeMethod(String paramString);

  public abstract void setTemplateVersionId(long paramLong);

  public abstract void setAlarmTimeMethod(String paramString);

  public abstract void setTaskTag(String paramString);

  public abstract void setAlarmConfigId(long paramLong);

  public abstract void setTemplateTag(String paramString);

  public abstract void setAlarmDealMethod(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue
 * JD-Core Version:    0.5.4
 */