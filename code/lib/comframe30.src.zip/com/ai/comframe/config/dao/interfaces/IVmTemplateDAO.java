package com.ai.comframe.config.dao.interfaces;

import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface IVmTemplateDAO
{
  public abstract IBOVmTemplateValue[] getAllTemplates()
    throws Exception;

  public abstract IBOVmTemplateValue getVmTemplateByTag(String paramString)
    throws Exception;

  public abstract IBOVmTemplateVersionValue[] getAllVmTemplateVersion()
    throws Exception;

  public abstract void saveVmTemplate(IBOVmTemplateValue paramIBOVmTemplateValue)
    throws Exception;

  public abstract void saveVmTemplateVersion(IBOVmTemplateVersionValue[] paramArrayOfIBOVmTemplateVersionValue)
    throws Exception;

  public abstract void saveHVmTemplateVersion(IBOVmTemplateVersionValue[] paramArrayOfIBOVmTemplateVersionValue, Timestamp paramTimestamp)
    throws Exception;

  public abstract void saveBatchVmTemplate(IBOVmTemplateValue[] paramArrayOfIBOVmTemplateValue)
    throws Exception;

  public abstract IBOVmTemplateValue[] getVmTemplates(String paramString, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract int getVmTemplatesCount(String paramString, HashMap paramHashMap)
    throws Exception;

  public abstract IBOVmTemplateVersionValue[] getVmTemplateVersion(String paramString, HashMap paramHashMap)
    throws Exception;

  public abstract IQBOVmTemplateValue[] getPublishedTemplates(String paramString, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract int getPublishedTemplatesCount(String paramString, HashMap paramHashMap)
    throws Exception;

  public abstract void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue[] paramArrayOfIBOVmEngineTemplateVersionValue)
    throws Exception;

  public abstract void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue paramIBOVmEngineTemplateVersionValue)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.interfaces.IVmTemplateDAO
 * JD-Core Version:    0.5.4
 */