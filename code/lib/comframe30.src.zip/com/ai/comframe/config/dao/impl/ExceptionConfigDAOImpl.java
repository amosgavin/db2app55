/*     */ package com.ai.comframe.config.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionCodeDescRelatEngine;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionCodeEngine;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionDescEngine;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionRuleEngine;
/*     */ import com.ai.comframe.config.dao.interfaces.IExceptionConfigDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class ExceptionConfigDAOImpl
/*     */   implements IExceptionConfigDAO
/*     */ {
/*     */   public IBOVmExceptionCodeValue[] queryExceptionCode(String workFlowType, String ExCode, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/*  23 */     Criteria criteria = new Criteria();
/*  24 */     if (!StringUtils.isEmptyString(workFlowType)) {
/*  25 */       criteria.addLIKE("WORKFLOW_OBJECT_TYPE", "%" + workFlowType + "%");
/*     */     }
/*  27 */     if (!StringUtils.isEmptyString(ExCode)) {
/*  28 */       criteria.addLIKE("EXCEPTION_CODE", "%" + ExCode + "%");
/*     */     }
/*  30 */     IBOVmExceptionCodeValue[] value = BOVmExceptionCodeEngine.getBeans(criteria, startIndex, endIndex, false);
/*  31 */     return value;
/*     */   }
/*     */ 
/*     */   public int queryExceptionCodeCount(String workFlowType, String ExCode) throws Exception {
/*  35 */     Criteria criteria = new Criteria();
/*  36 */     if (!StringUtils.isEmptyString(workFlowType)) {
/*  37 */       criteria.addLIKE("WORKFLOW_OBJECT_TYPE", "%" + workFlowType + "%");
/*     */     }
/*  39 */     if (!StringUtils.isEmptyString(ExCode)) {
/*  40 */       criteria.addLIKE("EXCEPTION_CODE", "%" + ExCode + "%");
/*     */     }
/*  42 */     return BOVmExceptionCodeEngine.getBeansCount(criteria.toString(), criteria.getParameters());
/*     */   }
/*     */   public void saveExceptionCode(IBOVmExceptionCodeValue[] aBeans) throws Exception {
/*     */     try {
/*  46 */       BOVmExceptionCodeEngine.save(aBeans);
/*     */     } catch (Exception e) {
/*  48 */       e.printStackTrace();
/*  49 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] queryExcepCodeAndName(String Code, String CodeName) throws Exception
/*     */   {
/*  55 */     String condition = "";
/*  56 */     HashMap map = new HashMap();
/*  57 */     if ((Code.equals("")) && (CodeName.equals("")))
/*  58 */       condition = "";
/*  59 */     if ((!Code.equals("")) && (!CodeName.equals(""))) {
/*  60 */       condition = "EXCEPTION_CODE like :aCode AND EXCEPTION_NAME like :aCodeName";
/*  61 */       map.put("aCodeName", "%" + CodeName + "%");
/*  62 */       map.put("aCode", "%" + Code + "%");
/*     */     }
/*  64 */     if ((Code.equals("")) && (!CodeName.equals(""))) {
/*  65 */       condition = "EXCEPTION_NAME = :aCodeName ";
/*  66 */       map.put("aCodeName", "%" + CodeName + "%");
/*     */     }
/*  68 */     if ((CodeName.equals("")) && (!Code.equals(""))) {
/*  69 */       condition = "EXCEPTION_CODE = :aCode ";
/*  70 */       map.put("aCode", "%" + Code + "%");
/*     */     }
/*  72 */     IBOVmExceptionCodeValue[] value = BOVmExceptionCodeEngine.getBeans(condition, map);
/*  73 */     return value;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionDescValue[] queryExceptionDesc(String description, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/*  79 */     Criteria criteria = new Criteria();
/*  80 */     if (!StringUtils.isEmptyString(description)) {
/*  81 */       criteria.addLIKE("EXCEPTION_DESC_CODE", "%" + description + "%");
/*     */     }
/*  83 */     IBOVmExceptionDescValue[] value = BOVmExceptionDescEngine.getBeans(criteria, startIndex, endIndex, false);
/*     */ 
/*  85 */     return value;
/*     */   }
/*     */ 
/*     */   public int queryExceptionDescCount(String description) throws Exception {
/*  89 */     Criteria criteria = new Criteria();
/*  90 */     if (!StringUtils.isEmptyString(description)) {
/*  91 */       criteria.addLIKE("EXCEPTION_DESC_CODE", "%" + description + "%");
/*     */     }
/*  93 */     return BOVmExceptionDescEngine.getBeansCount(criteria.toString(), criteria.getParameters());
/*     */   }
/*     */ 
/*     */   public void saveExceptionDesc(IBOVmExceptionDescValue[] aBeans) throws Exception
/*     */   {
/*     */     try {
/*  99 */       for (int i = 0; i < aBeans.length; ++i) {
/* 100 */         if (aBeans[i].isNew())
/* 101 */           aBeans[i].setCreateDate(TimeUtil.getSysTime());
/* 102 */         aBeans[i].setState("U");
/*     */       }
/* 104 */       BOVmExceptionDescEngine.save(aBeans);
/*     */     } catch (Exception e) {
/* 106 */       e.printStackTrace();
/* 107 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRuleValue[] queryExceptionRule(String Desc) throws Exception
/*     */   {
/* 113 */     String condition = "";
/* 114 */     HashMap map = new HashMap();
/* 115 */     condition = "EXCEPTION_DESC_CODE = :aDesc ";
/* 116 */     map.put("aDesc", Desc);
/* 117 */     IBOVmExceptionRuleValue[] value = BOVmExceptionRuleEngine.getBeans(condition, map);
/*     */ 
/* 119 */     return value;
/*     */   }
/*     */   public void saveExceptionRule(IBOVmExceptionRuleValue[] aBeans) throws Exception {
/*     */     try {
/* 123 */       for (int i = 0; i < aBeans.length; ++i) {
/* 124 */         if (aBeans[i].isNew())
/* 125 */           aBeans[i].setExceptionRuleId(BOVmExceptionRuleEngine.getNewId().longValue());
/* 126 */         aBeans[i].setState("U");
/* 127 */         aBeans[i].setCreateDate(BOVmExceptionRuleEngine.getSysDate());
/*     */       }
/* 129 */       BOVmExceptionRuleEngine.save(aBeans);
/*     */     } catch (Exception e) {
/* 131 */       e.printStackTrace();
/* 132 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExcepRelation(String Code)
/*     */     throws Exception
/*     */   {
/* 154 */     String condition = "";
/* 155 */     HashMap map = new HashMap();
/* 156 */     if (Code.equals(""))
/*     */     {
/* 158 */       condition = "";
/*     */     }
/*     */     else {
/* 161 */       condition = "EXCEPTION_CODE = :aCode ";
/* 162 */       map.put("aCode", Code);
/*     */     }
/*     */ 
/* 166 */     IBOVmExceptionCodeDescRelatValue[] value = BOVmExceptionCodeDescRelatEngine.getBeans(condition, map);
/*     */ 
/* 168 */     return value;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExcepRelationByDescCode(String DescCode) throws Exception {
/* 172 */     String condition = "";
/* 173 */     HashMap map = new HashMap();
/* 174 */     condition = "EXCEPTION_DESC_CODE = :aDescCode ";
/* 175 */     map.put("aDescCode", DescCode);
/* 176 */     IBOVmExceptionCodeDescRelatValue[] value = BOVmExceptionCodeDescRelatEngine.getBeans(condition, map);
/* 177 */     return value;
/*     */   }
/*     */ 
/*     */   public void saveExceptionRela(IBOVmExceptionCodeDescRelatValue[] aBeans) throws Exception
/*     */   {
/*     */     try {
/* 183 */       for (int i = 0; i < aBeans.length; ++i)
/*     */       {
/* 185 */         if (aBeans[i].isNew())
/* 186 */           aBeans[i].setCreateDate(BOVmExceptionCodeDescRelatEngine.getSysDate());
/*     */       }
/* 188 */       BOVmExceptionCodeDescRelatEngine.save(aBeans);
/*     */     } catch (Exception e) {
/* 190 */       e.printStackTrace();
/* 191 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionDescValue queryExceDesc(String Desc)
/*     */     throws Exception
/*     */   {
/* 198 */     IBOVmExceptionDescValue value = BOVmExceptionDescEngine.getBean(Desc);
/*     */ 
/* 200 */     return value;
/*     */   }
/*     */ 
/*     */   public void saveExceDesc(IBOVmExceptionDescValue aBeans) throws Exception {
/*     */     try {
/* 205 */       BOVmExceptionDescEngine.save(aBeans);
/*     */     } catch (Exception e) {
/* 207 */       e.printStackTrace();
/* 208 */       throw e;
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodebyWokflowObjType(String workflowObjType)
/*     */     throws Exception
/*     */   {
/* 215 */     String conditionExcode = "WORKFLOW_OBJECT_TYPE=:objectTypeId and STATE=:state";
/* 216 */     HashMap parameter = new HashMap();
/* 217 */     parameter.put("objectTypeId", workflowObjType);
/* 218 */     parameter.put("state", "U");
/* 219 */     IBOVmExceptionCodeValue[] exceptionCodes = BOVmExceptionCodeEngine.getBeans(conditionExcode, parameter);
/*     */ 
/* 221 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] getExcepRelation(String condition, HashMap parameter) throws Exception {
/* 225 */     IBOVmExceptionCodeDescRelatValue[] aBeans = BOVmExceptionCodeDescRelatEngine.getBeans(condition, parameter);
/* 226 */     return aBeans;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodeValues(String condition, HashMap parameter) throws Exception {
/* 230 */     IBOVmExceptionCodeValue[] aBeans = BOVmExceptionCodeEngine.getBeans(condition, parameter);
/* 231 */     return aBeans;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodeValuesBySql(String qrySql, HashMap parameter) throws Exception {
/* 235 */     IBOVmExceptionCodeValue[] aBeans = BOVmExceptionCodeEngine.getBeansFromSql(qrySql, parameter);
/* 236 */     return aBeans;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRuleValue[] getExceptionRule(String condition, HashMap parameter) throws Exception {
/* 240 */     IBOVmExceptionRuleValue[] aBeans = BOVmExceptionRuleEngine.getBeans(condition, parameter);
/* 241 */     return aBeans;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionCodeDescRelatValue[] queryExceptionRelation(String condition, HashMap map) throws Exception {
/* 245 */     return BOVmExceptionCodeDescRelatEngine.getBeans(condition, map);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.impl.ExceptionConfigDAOImpl
 * JD-Core Version:    0.5.4
 */