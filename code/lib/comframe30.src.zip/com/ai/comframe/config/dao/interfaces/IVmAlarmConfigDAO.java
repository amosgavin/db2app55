package com.ai.comframe.config.dao.interfaces;

import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
import java.util.HashMap;

public abstract interface IVmAlarmConfigDAO
{
  public abstract IBOVmAlarmConfigValue[] loadAllVmAlarmConfigs()
    throws Exception;

  public abstract IBOVmHoliDayValue[] loadAllHolidays()
    throws Exception;

  public abstract void saveAlarmConfig(IBOVmAlarmConfigValue[] paramArrayOfIBOVmAlarmConfigValue)
    throws Exception;

  public abstract void saveHolidayConfig(IBOVmHoliDayValue[] paramArrayOfIBOVmHoliDayValue)
    throws Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfigs(String paramString, HashMap paramHashMap)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.interfaces.IVmAlarmConfigDAO
 * JD-Core Version:    0.5.4
 */