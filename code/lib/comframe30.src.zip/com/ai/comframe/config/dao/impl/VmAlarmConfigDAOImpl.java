/*    */ package com.ai.comframe.config.dao.impl;
/*    */ 
/*    */ import com.ai.appframe2.util.criteria.Criteria;
/*    */ import com.ai.comframe.config.bo.BOVmAlarmConfigEngine;
/*    */ import com.ai.comframe.config.bo.BOVmHoliDayEngine;
/*    */ import com.ai.comframe.config.dao.interfaces.IVmAlarmConfigDAO;
/*    */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*    */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*    */ import java.math.BigDecimal;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmAlarmConfigDAOImpl
/*    */   implements IVmAlarmConfigDAO
/*    */ {
/*    */   public IBOVmAlarmConfigValue[] loadAllVmAlarmConfigs()
/*    */     throws Exception
/*    */   {
/* 16 */     Criteria criteria = new Criteria();
/* 17 */     criteria.addEqual("STATE", "U");
/* 18 */     IBOVmAlarmConfigValue[] alarmConfigs = BOVmAlarmConfigEngine.getBeans(criteria);
/* 19 */     return alarmConfigs;
/*    */   }
/*    */ 
/*    */   public IBOVmHoliDayValue[] loadAllHolidays() throws Exception {
/* 23 */     return BOVmHoliDayEngine.getBeans(null, null);
/*    */   }
/*    */ 
/*    */   public void saveAlarmConfig(IBOVmAlarmConfigValue[] values)
/*    */     throws Exception
/*    */   {
/* 29 */     for (int i = 0; i < values.length; ++i) {
/* 30 */       if ((values[i].isNew()) && (((values[i].getAlarmConfigId() == 0L) || (values[i].getAlarmConfigId() == -1L)))) {
/* 31 */         values[i].setAlarmConfigId(BOVmAlarmConfigEngine.getNewId().longValue());
/*    */       }
/*    */     }
/* 34 */     BOVmAlarmConfigEngine.saveBatch(values);
/*    */   }
/*    */ 
/*    */   public void saveHolidayConfig(IBOVmHoliDayValue[] beans) throws Exception {
/* 38 */     BOVmHoliDayEngine.save(beans);
/*    */   }
/*    */ 
/*    */   public IBOVmAlarmConfigValue[] getAlarmConfigs(String cond, HashMap param) throws Exception {
/* 42 */     return BOVmAlarmConfigEngine.getBeans(cond, param);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.impl.VmAlarmConfigDAOImpl
 * JD-Core Version:    0.5.4
 */