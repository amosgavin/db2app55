/*    */ package com.ai.comframe.config.dao.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.IdGenerator;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.comframe.config.dao.interfaces.ITimeDAO;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class TimeDAOImpl
/*    */   implements ITimeDAO
/*    */ {
/*    */   public Timestamp getSysdate()
/*    */     throws Exception
/*    */   {
/* 11 */     return ServiceManager.getIdGenerator().getSysDate();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.impl.TimeDAOImpl
 * JD-Core Version:    0.5.4
 */