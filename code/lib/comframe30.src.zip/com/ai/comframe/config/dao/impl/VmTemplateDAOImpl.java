/*     */ package com.ai.comframe.config.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.ICache;
/*     */ import com.ai.comframe.cache.VmTemplateCacheImpl;
/*     */ import com.ai.comframe.cache.VmTemplateVersionCacheImpl;
/*     */ import com.ai.comframe.config.bo.BOHVmTemplateBean;
/*     */ import com.ai.comframe.config.bo.BOHVmTemplateEngine;
/*     */ import com.ai.comframe.config.bo.BOVmEngineTemplateVersionEngine;
/*     */ import com.ai.comframe.config.bo.BOVmTemplateEngine;
/*     */ import com.ai.comframe.config.bo.BOVmTemplateVersionEngine;
/*     */ import com.ai.comframe.config.bo.QBOVmTemplateEngine;
/*     */ import com.ai.comframe.config.dao.interfaces.IVmTemplateDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOHVmTemplateValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmEngineTemplateVersionValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*     */ import com.ai.comframe.config.ivalues.IQBOVmTemplateValue;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class VmTemplateDAOImpl
/*     */   implements IVmTemplateDAO
/*     */ {
/*     */   public IBOVmTemplateValue[] getAllTemplates()
/*     */     throws Exception
/*     */   {
/*  32 */     return BOVmTemplateEngine.getBeans(null, null);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue getVmTemplateByTag(String templateTag) throws Exception
/*     */   {
/*  37 */     return BOVmTemplateEngine.getBean(templateTag);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] getAllVmTemplateVersion()
/*     */     throws Exception
/*     */   {
/*  43 */     return BOVmTemplateVersionEngine.getBeans(null, null);
/*     */   }
/*     */ 
/*     */   public void saveVmTemplate(IBOVmTemplateValue templateBean) throws Exception
/*     */   {
/*  48 */     if ((templateBean.getTemplateTag() == null) || (templateBean.getTemplateTag().length() == 0))
/*     */     {
/*  50 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.dao.impl.VmTemplateDAOImpl_inputTemplateTag"));
/*     */     }
/*  52 */     IBOVmTemplateValue Htemplate = getVmTemplateByTag(templateBean.getTemplateTag());
/*  53 */     templateBean.setStsToNew();
/*  54 */     templateBean.setState("U");
/*  55 */     if ((Htemplate != null) && (Htemplate.getQueueId() != null) && (Htemplate.getQueueId().length() > -1)) {
/*  56 */       moveVmTemplateToHis(Htemplate);
/*  57 */       Htemplate.delete();
/*  58 */       BOVmTemplateEngine.save(Htemplate);
/*     */     }
/*  60 */     BOVmTemplateEngine.save(templateBean);
/*  61 */     ICache vmTemplate = (ICache)CacheFactory._getCacheInstances().get(VmTemplateCacheImpl.class);
/*  62 */     vmTemplate.refresh();
/*     */   }
/*     */ 
/*     */   private void moveVmTemplateToHis(IBOVmTemplateValue htemplate)
/*     */     throws Exception
/*     */   {
/*  68 */     IBOHVmTemplateValue hvmtemplate = new BOHVmTemplateBean();
/*  69 */     hvmtemplate.copy(htemplate);
/*  70 */     hvmtemplate.setHisId(BOHVmTemplateEngine.getNewId().longValue());
/*  71 */     hvmtemplate.setStsToNew();
/*  72 */     BOHVmTemplateEngine.save(hvmtemplate);
/*     */   }
/*     */ 
/*     */   public void saveHVmTemplateVersion(IBOVmTemplateVersionValue[] templateVersion, Timestamp valDate) throws Exception {
/*  76 */     for (int i = 0; i < templateVersion.length; ++i) {
/*  77 */       templateVersion[i].setExpireDate(valDate);
/*     */     }
/*  79 */     BOVmTemplateVersionEngine.saveBatch(templateVersion);
/*     */   }
/*     */ 
/*     */   public void saveVmTemplateVersion(IBOVmTemplateVersionValue[] templateVersion) throws Exception
/*     */   {
/*  84 */     long newID = BOVmTemplateVersionEngine.getNewId().longValue();
/*  85 */     for (int i = 0; i < templateVersion.length; ++i) {
/*  86 */       if ((templateVersion[i].getTemplateVersionId() == 0L) || (templateVersion[i].getTemplateVersionId() == -1L)) {
/*  87 */         templateVersion[i].setTemplateVersionId(newID);
/*     */       }
/*     */     }
/*  90 */     BOVmTemplateVersionEngine.saveBatch(templateVersion);
/*  91 */     ICache vmTemplateVersion = (ICache)CacheFactory._getCacheInstances().get(VmTemplateVersionCacheImpl.class);
/*  92 */     vmTemplateVersion.refresh();
/*     */   }
/*     */ 
/*     */   public void saveBatchVmTemplate(IBOVmTemplateValue[] template)
/*     */     throws Exception
/*     */   {
/*  99 */     BOVmTemplateEngine.saveBatch(template);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateValue[] getVmTemplates(String cond, HashMap param, int $startrowindex, int $endrowindex) throws Exception
/*     */   {
/* 104 */     return BOVmTemplateEngine.getBeans(null, cond, param, $startrowindex, $endrowindex, false);
/*     */   }
/*     */ 
/*     */   public int getVmTemplatesCount(String cond, HashMap param) throws Exception
/*     */   {
/* 109 */     return BOVmTemplateEngine.getBeansCount(cond, param);
/*     */   }
/*     */ 
/*     */   public IBOVmTemplateVersionValue[] getVmTemplateVersion(String cond, HashMap param) throws Exception {
/* 113 */     return BOVmTemplateVersionEngine.getBeans(cond, param);
/*     */   }
/*     */ 
/*     */   public IQBOVmTemplateValue[] getPublishedTemplates(String cond, HashMap param, int $startrowindex, int $endrowindex)
/*     */     throws Exception
/*     */   {
/* 120 */     return QBOVmTemplateEngine.getBeans(null, cond, param, $startrowindex, $endrowindex, false);
/*     */   }
/*     */ 
/*     */   public int getPublishedTemplatesCount(String cond, HashMap param)
/*     */     throws Exception
/*     */   {
/* 126 */     return QBOVmTemplateEngine.getBeansCount(cond, param);
/*     */   }
/*     */ 
/*     */   public void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue[] engineTemplates)
/*     */     throws Exception
/*     */   {
/* 132 */     BOVmEngineTemplateVersionEngine.saveBatch(engineTemplates);
/*     */   }
/*     */ 
/*     */   public void saveVmEngineTemplateVersionValue(IBOVmEngineTemplateVersionValue engineTemplate)
/*     */     throws Exception
/*     */   {
/* 138 */     if (engineTemplate.isNew()) {
/* 139 */       long id = BOVmEngineTemplateVersionEngine.getNewId().longValue();
/* 140 */       engineTemplate.setTemplateVersionId(id);
/*     */     }
/* 142 */     BOVmEngineTemplateVersionEngine.save(engineTemplate);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.impl.VmTemplateDAOImpl
 * JD-Core Version:    0.5.4
 */