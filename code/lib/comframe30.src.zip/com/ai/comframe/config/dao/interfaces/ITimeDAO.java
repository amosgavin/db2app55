package com.ai.comframe.config.dao.interfaces;

import java.sql.Timestamp;

public abstract interface ITimeDAO
{
  public abstract Timestamp getSysdate()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.interfaces.ITimeDAO
 * JD-Core Version:    0.5.4
 */