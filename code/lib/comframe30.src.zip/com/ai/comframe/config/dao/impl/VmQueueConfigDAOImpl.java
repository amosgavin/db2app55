/*    */ package com.ai.comframe.config.dao.impl;
/*    */ 
/*    */ import com.ai.appframe2.util.criteria.Criteria;
/*    */ import com.ai.comframe.config.bo.BOVmQueueConfigEngine;
/*    */ import com.ai.comframe.config.bo.BOVmQueueServerRegistBean;
/*    */ import com.ai.comframe.config.bo.BOVmQueueServerRegistEngine;
/*    */ import com.ai.comframe.config.bo.BOVmWorkflowObjectEngine;
/*    */ import com.ai.comframe.config.dao.interfaces.IVmQueueConfigDAO;
/*    */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*    */ import com.ai.comframe.config.ivalues.IBOVmQueueServerRegistValue;
/*    */ import com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue;
/*    */ import com.ai.comframe.queue.QueueParam;
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.RuntimeMXBean;
/*    */ import java.math.BigDecimal;
/*    */ import java.net.InetAddress;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class VmQueueConfigDAOImpl
/*    */   implements IVmQueueConfigDAO
/*    */ {
/* 23 */   private static final Log logger = LogFactory.getLog(VmQueueConfigDAOImpl.class);
/*    */ 
/*    */   public IBOVmQueueConfigValue[] getAllVmQueueConfigs() throws Exception {
/* 26 */     Criteria sql = new Criteria();
/* 27 */     sql.addEqual("STATE", "U");
/* 28 */     IBOVmQueueConfigValue[] vmQueueConfigs = BOVmQueueConfigEngine.getBeans(sql);
/* 29 */     return vmQueueConfigs;
/*    */   }
/*    */ 
/*    */   public IBOVmQueueConfigValue getVmQueueConfig(String queuId, String queueType) throws Exception {
/* 33 */     IBOVmQueueConfigValue vmQueueConfig = BOVmQueueConfigEngine.getBean(queuId, queueType);
/* 34 */     return vmQueueConfig;
/*    */   }
/*    */ 
/*    */   public IBOVmWorkflowObjectValue[] getAllVmWorkflowObject() throws Exception {
/* 38 */     return BOVmWorkflowObjectEngine.getBeans(null, null);
/*    */   }
/*    */ 
/*    */   public void insertVMQueueServer(QueueParam param) throws Exception {
/* 42 */     String processId = null;
/*    */     try {
/* 44 */       processId = ManagementFactory.getRuntimeMXBean().getName();
/*    */     }
/*    */     catch (Throwable ex) {
/* 47 */       logger.error("get process id error!", ex);
/*    */     }
/*    */ 
/* 50 */     String hostname = null;
/*    */     try {
/* 52 */       hostname = InetAddress.getLocalHost().getCanonicalHostName();
/*    */     }
/*    */     catch (Throwable ex) {
/* 55 */       logger.error("get host name error!", ex);
/*    */     }
/*    */ 
/* 58 */     String ip = null;
/*    */     try {
/* 60 */       ip = InetAddress.getLocalHost().getHostAddress();
/*    */     }
/*    */     catch (Throwable ex) {
/* 63 */       logger.error("get host ip error!", ex);
/*    */     }
/* 65 */     IBOVmQueueServerRegistValue registValue = new BOVmQueueServerRegistBean();
/* 66 */     registValue.setRegistId(BOVmQueueServerRegistEngine.getNewId().longValue());
/* 67 */     registValue.setProcessId(processId);
/* 68 */     registValue.setHostIp(ip);
/* 69 */     registValue.setHostName(hostname);
/* 70 */     registValue.setQueueId(param.getQueueId());
/* 71 */     registValue.setQueueType(param.getQueueType());
/* 72 */     registValue.setModParam(param.getMod());
/* 73 */     registValue.setModValue(param.getModValue());
/* 74 */     registValue.setRegionId(param.getRegionId());
/* 75 */     registValue.setState("U");
/* 76 */     registValue.setRegistDate(BOVmQueueServerRegistEngine.getSysDate());
/* 77 */     BOVmQueueServerRegistEngine.save(registValue);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.impl.VmQueueConfigDAOImpl
 * JD-Core Version:    0.5.4
 */