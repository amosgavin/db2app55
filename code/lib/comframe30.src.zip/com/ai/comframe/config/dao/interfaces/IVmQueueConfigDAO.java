package com.ai.comframe.config.dao.interfaces;

import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
import com.ai.comframe.config.ivalues.IBOVmWorkflowObjectValue;
import com.ai.comframe.queue.QueueParam;

public abstract interface IVmQueueConfigDAO
{
  public abstract IBOVmQueueConfigValue[] getAllVmQueueConfigs()
    throws Exception;

  public abstract IBOVmQueueConfigValue getVmQueueConfig(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmWorkflowObjectValue[] getAllVmWorkflowObject()
    throws Exception;

  public abstract void insertVMQueueServer(QueueParam paramQueueParam)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.config.dao.interfaces.IVmQueueConfigDAO
 * JD-Core Version:    0.5.4
 */