/*     */ package com.ai.comframe.exception.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.config.dao.interfaces.IExceptionConfigDAO;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import com.ai.comframe.config.service.interfaces.IExceptionConfigSV;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.exception.bo.BOVmExceptionRecordBean;
/*     */ import com.ai.comframe.exception.dao.interfaces.IExceptionRecordDAO;
/*     */ import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
/*     */ import com.ai.comframe.exception.service.interfaces.IComframeExceptionHandleSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ComframeExceptionHandleSVImpl
/*     */   implements IComframeExceptionHandleSV
/*     */ {
/*     */   public void exceptionHandle(String workflowId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  42 */     IBOVmExceptionRecordValue[] exRecords = getExceptionRecordsByInstanceId(workflowId);
/*  43 */     String ruleOwner = exRecords[0].getRuleOwner();
/*  44 */     String nextTemlateTag = "";
/*  45 */     if ("02".equals(ruleOwner))
/*  46 */       nextTemlateTag = exRecords[0].getNextTemplateTag();
/*     */     else {
/*  48 */       nextTemlateTag = getNextCodeWorkFlowbyWorkFlowId(workflowId, exRecords);
/*     */     }
/*  50 */     Workflow workflow = WorkflowEngineFactory.getInstance().getWorkflow(workflowId);
/*  51 */     String workflowObjTypeId = workflow.getWorkflowObjectTypeId();
/*  52 */     String workflowObjId = workflow.getWorkflowObjectId();
/*  53 */     Map parameter = workflow.getWorkflowContext().getParameters();
/*  54 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  55 */     String scheduleServerName = templateSV.getEngineType(nextTemlateTag);
/*  56 */     WorkflowEngineFactory.getInstance().createWorkflow(workflow.getQueueId(), workflowId, nextTemlateTag, 2, scheduleServerName, PropertiesUtil.getSystemUserId(), workflowObjTypeId, workflowObjId, parameter, null, null);
/*     */ 
/*  60 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/*  61 */     for (int i = 0; i < exRecords.length; ++i) {
/*  62 */       exRecords[i].setState("E");
/*  63 */       exRecordDAO.saveExceptionRecord(exRecords[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void recordExceptionCode(String workflowId, IBOVmTaskValue[] tasks, String errorCode, String errorMessage)
/*     */     throws RemoteException, Exception
/*     */   {
/*  72 */     for (int i = 0; i < tasks.length; ++i) {
/*  73 */       if (7 == tasks[i].getState())
/*  74 */         return;
/*  75 */       if (("CANCEL".equals(errorCode)) && 
/*  77 */         (4 == tasks[i].getState())) {
/*  78 */         Workflow workflow = WorkflowEngineFactory.getInstance().getWorkflow(workflowId);
/*  79 */         StringBuffer condition = new StringBuffer();
/*  80 */         condition.append(" WORKFLOW_OBJECT_TYPE =:WorkflowObjTypeId");
/*  81 */         condition.append(" and EXCEPTION_TYPE =:ExceptionType");
/*  82 */         condition.append(" and TASK_TAG =:TaskTag and state =:state");
/*  83 */         HashMap parameter = new HashMap();
/*  84 */         String workflowObjTypeId = workflow.getWorkflowObjectTypeId();
/*  85 */         parameter.put("WorkflowObjTypeId", workflowObjTypeId);
/*  86 */         parameter.put("ExceptionType", errorCode);
/*  87 */         parameter.put("TaskTag", tasks[i].getTaskTag());
/*  88 */         parameter.put("state", "U");
/*     */ 
/*  90 */         IExceptionConfigSV exConfigSV = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*  91 */         IBOVmExceptionCodeValue[] exCodes = exConfigSV.getExceptionCodeValues(condition.toString(), parameter);
/*  92 */         if (exCodes.length > 0) {
/*  93 */           errorCode = exCodes[0].getExceptionCode();
/*     */         }
/*     */         else {
/*  96 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.service.impl.ComframeExceptionHandleSVImpl_notfindExceptionReason"));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 101 */       IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/* 102 */       IBOVmExceptionRecordValue exRecord = new BOVmExceptionRecordBean();
/* 103 */       exRecord.setExceptionRecordId(exRecordDAO.getNewRecordId());
/* 104 */       exRecord.setWorkflowId(workflowId);
/* 105 */       exRecord.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 106 */       exRecord.setTaskId(String.valueOf(tasks[i].getTaskId()));
/* 107 */       exRecord.setExceptionCode(errorCode);
/* 108 */       exRecord.setExceptionRemarks(errorMessage);
/* 109 */       exRecord.setRuleOwner("01");
/* 110 */       exRecord.setState("U");
/* 111 */       exRecordDAO.saveExceptionRecord(exRecord);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void recordExceptionCode(String workflowId, IBOVmTaskValue[] tasks, String errorCode, String nextTemplateTag, String errorMessage)
/*     */     throws RemoteException, Exception
/*     */   {
/* 124 */     StringBuilder taskId = new StringBuilder("");
/* 125 */     for (int i = 0; i < tasks.length; ++i) {
/* 126 */       taskId.append(tasks[i].getTaskId());
/*     */     }
/* 128 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/* 129 */     IBOVmExceptionRecordValue exRecord = new BOVmExceptionRecordBean();
/* 130 */     exRecord.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 131 */     exRecord.setWorkflowId(workflowId);
/* 132 */     exRecord.setExceptionRecordId(exRecordDAO.getNewRecordId());
/* 133 */     exRecord.setTaskId(taskId.toString());
/* 134 */     exRecord.setExceptionCode(errorCode);
/* 135 */     exRecord.setNextTemplateTag(nextTemplateTag);
/* 136 */     exRecord.setExceptionRemarks(errorMessage);
/* 137 */     exRecord.setRuleOwner("02");
/* 138 */     exRecord.setState("U");
/* 139 */     exRecordDAO.saveExceptionRecord(exRecord);
/*     */   }
/*     */ 
/*     */   private String getNextCodeWorkFlowbyWorkFlowId(String workflowId, IBOVmExceptionRecordValue[] exRecords) throws Exception
/*     */   {
/* 144 */     String nextWorkFlowCode = null;
/* 145 */     Workflow workflow = WorkflowEngineFactory.getInstance().getWorkflow(workflowId);
/* 146 */     String wfcode = workflow.getDataBean().getAsString("TEMPLATE_TAG");
/*     */ 
/* 150 */     String condition = "exception_code =:ExceptionCode and state=:State ";
/* 151 */     HashMap parameter = new HashMap();
/* 152 */     parameter.put("ExceptionCode", exRecords[0].getExceptionCode());
/* 153 */     parameter.put("State", "U");
/*     */ 
/* 155 */     IExceptionConfigSV exConfigSV = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*     */ 
/* 157 */     IBOVmExceptionCodeDescRelatValue[] exceptionrelates = exConfigSV.getExcepRelation(condition, parameter);
/* 158 */     if ((exceptionrelates == null) || (exceptionrelates.length < 0)) {
/* 159 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_notFindProcessIns") + workflowId + "]");
/*     */     }
/*     */ 
/* 164 */     String exceptionDesc = null;
/* 165 */     boolean isGet = false;
/* 166 */     for (int i = 0; i < exceptionrelates.length; ++i) {
/* 167 */       IExceptionConfigDAO exConfigDAO = (IExceptionConfigDAO)ServiceFactory.getService(IExceptionConfigDAO.class);
/* 168 */       IBOVmExceptionDescValue exDesc = exConfigDAO.queryExceDesc(exceptionrelates[i].getExceptionDescCode());
/* 169 */       IBOVmExceptionCodeDescRelatValue[] tmpExceptionRels = null;
/*     */ 
/* 171 */       if ("A".equals(exDesc.getExceptionDescType())) {
/* 172 */         String tmpRelCondition = "exception_desc_code =:ExceptionDescCode and state=:State";
/* 173 */         HashMap tmpRelParameter = new HashMap();
/* 174 */         tmpRelParameter.put("ExceptionDescCode", exceptionrelates[i].getExceptionDescCode());
/* 175 */         tmpRelParameter.put("State", "U");
/* 176 */         tmpExceptionRels = exConfigSV.getExcepRelation(tmpRelCondition, tmpRelParameter);
/*     */       } else {
/* 178 */         tmpExceptionRels = new IBOVmExceptionCodeDescRelatValue[1];
/* 179 */         tmpExceptionRels[0] = exceptionrelates[i];
/*     */       }
/*     */ 
/* 182 */       if (IsSameExceptionCodes(exRecords, tmpExceptionRels)) {
/* 183 */         exceptionDesc = exceptionrelates[i].getExceptionDescCode();
/* 184 */         if (isGet == true) {
/* 185 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_moreSameDescribe"));
/*     */         }
/* 187 */         isGet = true;
/*     */       }
/*     */     }
/* 190 */     if (!isGet) {
/* 191 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_noFindSuitException") + workflowId + "]");
/*     */     }
/*     */ 
/* 196 */     StringBuffer condRuleBf = new StringBuffer();
/* 197 */     condRuleBf.append(" EXCEPTION_DESC_CODE =:ExceptionDesc ");
/* 198 */     condRuleBf.append(" and CURRENT_TEMPLATE_TAG =:CurrentTemplateTag ");
/* 199 */     condRuleBf.append(" and state=:State ");
/*     */ 
/* 201 */     HashMap paraRule = new HashMap();
/* 202 */     paraRule.put("ExceptionDesc", exceptionDesc);
/* 203 */     paraRule.put("CurrentTemplateTag", wfcode);
/* 204 */     paraRule.put("State", "U");
/* 205 */     IBOVmExceptionRuleValue[] exRules = exConfigSV.getExceptionRule(condRuleBf.toString(), paraRule);
/* 206 */     if (exRules.length > 0)
/* 207 */       nextWorkFlowCode = exRules[0].getNextTemplateTag();
/*     */     else {
/* 209 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_noFindSuitExcepRule") + workflowId + "]");
/*     */     }
/* 211 */     return nextWorkFlowCode;
/*     */   }
/*     */ 
/*     */   private boolean IsSameExceptionCodes(IBOVmExceptionRecordValue[] records, IBOVmExceptionCodeDescRelatValue[] relates)
/*     */   {
/* 222 */     boolean result = true;
/*     */ 
/* 224 */     if (records.length != relates.length) {
/* 225 */       return false;
/*     */     }
/* 227 */     List codeRecords = new ArrayList();
/* 228 */     for (int i = 0; i < records.length; ++i) {
/* 229 */       codeRecords.add(records[i].getExceptionCode());
/*     */     }
/*     */ 
/* 232 */     for (int i = 0; i < relates.length; ++i) {
/* 233 */       if (!codeRecords.contains(relates[i].getExceptionCode())) {
/* 234 */         result = false;
/* 235 */         break;
/*     */       }
/* 237 */       result = true;
/*     */     }
/* 239 */     return result;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String workflowId) throws RemoteException, Exception
/*     */   {
/* 244 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/* 245 */     IBOVmExceptionRecordValue[] exceptionCodes = exRecordDAO.getExceptionRecordsByInstanceId(workflowId);
/* 246 */     return exceptionCodes;
/*     */   }
/*     */   public IBOVmExceptionRecordValue[] getAllExceptionRecordsByInstanceId(String workflowId) throws RemoteException, Exception {
/* 249 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/* 250 */     IBOVmExceptionRecordValue[] exceptionCodes = exRecordDAO.getAllExceptionRecordsByInstanceId(workflowId);
/* 251 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.service.impl.ComframeExceptionHandleSVImpl
 * JD-Core Version:    0.5.4
 */