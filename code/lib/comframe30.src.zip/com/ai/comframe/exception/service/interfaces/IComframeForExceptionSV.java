package com.ai.comframe.exception.service.interfaces;

import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
import com.ai.comframe.vm.template.WorkflowTemplate;
import java.rmi.RemoteException;
import java.util.Map;

public abstract interface IComframeForExceptionSV
{
  public abstract IBOVmExceptionCodeValue[] getExceptionCodeArrayByTaskId(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowTemplate[] getExceptionWorkFlowCodeArrayByTaskId(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String paramString)
    throws RemoteException, Exception;

  public abstract void exceptionHandleManual(String paramString1, String paramString2, boolean paramBoolean, Map paramMap, String paramString3)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.service.interfaces.IComframeForExceptionSV
 * JD-Core Version:    0.5.4
 */