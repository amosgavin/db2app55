/*     */ package com.ai.comframe.exception.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionCodeDescRelatBean;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionDescBean;
/*     */ import com.ai.comframe.config.bo.BOVmExceptionRuleBean;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeDescRelatValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionDescValue;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionRuleValue;
/*     */ import com.ai.comframe.config.service.interfaces.IExceptionConfigSV;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.exception.dao.interfaces.IExceptionRecordDAO;
/*     */ import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
/*     */ import com.ai.comframe.exception.service.interfaces.IComframeForExceptionSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ComframeForExceptionSVImpl
/*     */   implements IComframeForExceptionSV
/*     */ {
/*     */   public IBOVmExceptionCodeValue[] getExceptionCodeArrayByTaskId(String taskId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  35 */     IBOVmExceptionCodeValue[] excptioncodebeans = null;
/*  36 */     String workflowId = WorkflowEngineFactory.getInstance().getWorkflowIdByTaskId(taskId);
/*  37 */     Workflow workflow = WorkflowEngineFactory.getInstance().getWorkflow(workflowId);
/*  38 */     String workflowObjType = workflow.getWorkflowObjectTypeId();
/*  39 */     IExceptionConfigSV exConfigSV = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*  40 */     excptioncodebeans = exConfigSV.getExceptionCodebyWokflowObjType(workflowObjType);
/*  41 */     return excptioncodebeans;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate[] getExceptionWorkFlowCodeArrayByTaskId(long taskId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  49 */     WorkflowTemplate[] workflowTemplates = null;
/*  50 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  51 */     String[] workflownames = templateSV.getAllTemplateTags();
/*  52 */     workflowTemplates = new WorkflowTemplate[workflownames.length];
/*  53 */     for (int i = 0; i < workflownames.length; ++i) {
/*  54 */       workflowTemplates[i] = templateSV.getWorkflowTemplateFromFile(workflownames[i]);
/*     */     }
/*  56 */     return workflowTemplates;
/*     */   }
/*     */ 
/*     */   public IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String workflowId) throws RemoteException, Exception
/*     */   {
/*  61 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/*  62 */     IBOVmExceptionRecordValue[] exceptionCodes = exRecordDAO.getExceptionRecordsByInstanceId(workflowId);
/*  63 */     return exceptionCodes;
/*     */   }
/*     */ 
/*     */   public void exceptionHandleManual(String workflowId, String nextTemplatTag, boolean makeasRule, Map var, String remarks)
/*     */     throws RemoteException, Exception
/*     */   {
/*  69 */     IExceptionRecordDAO exRecordDAO = (IExceptionRecordDAO)ServiceFactory.getService(IExceptionRecordDAO.class);
/*     */ 
/*  71 */     Workflow workflow = WorkflowEngineFactory.getInstance().getWorkflow(workflowId);
/*     */ 
/*  73 */     String workflowObjTypeId = workflow.getWorkflowObjectTypeId();
/*  74 */     String workflowObjId = workflow.getWorkflowObjectId();
/*     */ 
/*  76 */     IBOVmExceptionRecordValue[] exRecords = getExceptionRecordsByInstanceId(workflowId);
/*  77 */     IExceptionConfigSV exConfigSV = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/*  78 */     if (makeasRule) {
/*  79 */       Timestamp sysdate = TimeUtil.getSysTime();
/*  80 */       String descCode = nextTemplatTag + "_E" + workflowId;
/*  81 */       IBOVmExceptionDescValue descBean = new BOVmExceptionDescBean();
/*  82 */       descBean.setExceptionDescCode(descCode);
/*  83 */       descBean.setExceptionDescName(remarks);
/*  84 */       descBean.setCreateDate(sysdate);
/*  85 */       descBean.setState("U");
/*  86 */       exConfigSV.saveExceptionDesc(new IBOVmExceptionDescValue[] { descBean });
/*     */ 
/*  88 */       String currentTemplatTag = workflow.getTemplateTag();
/*  89 */       IBOVmExceptionRuleValue ruleBean = new BOVmExceptionRuleBean();
/*  90 */       ruleBean.setExceptionDescCode(descCode);
/*  91 */       ruleBean.setCurrentTemplateTag(currentTemplatTag);
/*  92 */       ruleBean.setNextTemplateTag(nextTemplatTag);
/*  93 */       ruleBean.setExceptionRuleRemarks(remarks);
/*  94 */       ruleBean.setCreateDate(sysdate);
/*  95 */       ruleBean.setState("U");
/*  96 */       exConfigSV.saveExceptionRule(new IBOVmExceptionRuleValue[] { ruleBean });
/*     */ 
/*  98 */       for (int i = 0; i < exRecords.length; ++i) {
/*  99 */         IBOVmExceptionCodeDescRelatValue relateBean = new BOVmExceptionCodeDescRelatBean();
/* 100 */         relateBean.setExceptionCode(exRecords[i].getExceptionCode());
/* 101 */         relateBean.setExceptionDescCode(descCode);
/* 102 */         relateBean.setCreateDate(sysdate);
/* 103 */         relateBean.setState("U");
/* 104 */         exConfigSV.saveExceptionRela(new IBOVmExceptionCodeDescRelatValue[] { relateBean });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 109 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 110 */     String scheduleServerName = templateSV.getEngineType(nextTemplatTag);
/* 111 */     String nextWfId = WorkflowEngineFactory.getInstance().createWorkflow(workflow.getQueueId(), workflowId, nextTemplatTag, 2, scheduleServerName, PropertiesUtil.getSystemUserId(), workflowObjTypeId, workflowObjId, var, null, null);
/*     */ 
/* 116 */     System.out.println(nextWfId);
/*     */ 
/* 118 */     for (int i = 0; i < exRecords.length; ++i) {
/* 119 */       exRecords[i].setState("E");
/* 120 */       exRecordDAO.saveExceptionRecord(exRecords[i]);
/*     */     }
/* 122 */     workflow.updateState(97, ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeForExcepitonImpl.ExceptionHandleManual_unNormalExcepDeal"));
/*     */ 
/* 124 */     WorkflowEngineFactory.getInstance().save(workflow);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 128 */     ServiceManager.getSession().startTransaction();
/* 129 */     ComframeForExceptionSVImpl impl = new ComframeForExceptionSVImpl();
/* 130 */     IBOVmExceptionCodeValue[] exs = impl.getExceptionCodeArrayByTaskId("1420");
/* 131 */     for (int i = 0; i < exs.length; ++i) {
/* 132 */       System.out.println(exs[i]);
/*     */     }
/* 134 */     WorkflowTemplate[] templates = impl.getExceptionWorkFlowCodeArrayByTaskId(100L);
/*     */ 
/* 136 */     for (int i = 0; i < templates.length; ++i)
/* 137 */       System.out.println(templates[i]);
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate[] getExceptionWorkFlowCodeArrayByTaskId(String taskId)
/*     */     throws RemoteException, Exception
/*     */   {
/* 145 */     WorkflowTemplate[] workflowTemplates = null;
/* 146 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 147 */     String[] workflownames = templateSV.getAllTemplateTags();
/* 148 */     workflowTemplates = new WorkflowTemplate[workflownames.length];
/* 149 */     for (int i = 0; i < workflownames.length; ++i) {
/* 150 */       workflowTemplates[i] = templateSV.getWorkflowTemplateByTag(workflownames[i]);
/*     */     }
/* 152 */     return workflowTemplates;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.service.impl.ComframeForExceptionSVImpl
 * JD-Core Version:    0.5.4
 */