/*    */ package com.ai.comframe.exception.service.impl;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.exception.service.interfaces.IComframeExceptionHandleSV;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ public class BusiExceptionDeal
/*    */ {
/*    */   public static void dealException(String workflowId, IBOVmTaskValue[] tasks, String errorCode, String errorMessage)
/*    */     throws RemoteException, Exception
/*    */   {
/* 36 */     IComframeExceptionHandleSV handle = (IComframeExceptionHandleSV)ServiceFactory.getService(IComframeExceptionHandleSV.class);
/* 37 */     handle.recordExceptionCode(workflowId, tasks, errorCode, errorMessage);
/*    */   }
/*    */ 
/*    */   public static void dealException(String workflowId, IBOVmTaskValue[] tasks, String errorCode, String nextWorkflowCode, String errorMessage)
/*    */     throws RemoteException, Exception
/*    */   {
/* 54 */     IComframeExceptionHandleSV handle = (IComframeExceptionHandleSV)ServiceFactory.getService(IComframeExceptionHandleSV.class);
/* 55 */     handle.recordExceptionCode(workflowId, tasks, errorCode, nextWorkflowCode, errorMessage);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.service.impl.BusiExceptionDeal
 * JD-Core Version:    0.5.4
 */