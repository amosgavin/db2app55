package com.ai.comframe.exception.service.interfaces;

import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
import java.rmi.RemoteException;

public abstract interface IComframeExceptionHandleSV
{
  public static final String EXCEPTION_TYPE_CANCEL = "CANCEL";
  public static final String EXCEPTION_RULE_OWNER_COMFAME = "01";
  public static final String EXCEPTION_RULE_OWNER_BUSINESS = "02";

  public abstract void exceptionHandle(String paramString)
    throws RemoteException, Exception;

  public abstract void recordExceptionCode(String paramString1, IBOVmTaskValue[] paramArrayOfIBOVmTaskValue, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void recordExceptionCode(String paramString1, IBOVmTaskValue[] paramArrayOfIBOVmTaskValue, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmExceptionRecordValue[] getAllExceptionRecordsByInstanceId(String paramString)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.service.interfaces.IComframeExceptionHandleSV
 * JD-Core Version:    0.5.4
 */