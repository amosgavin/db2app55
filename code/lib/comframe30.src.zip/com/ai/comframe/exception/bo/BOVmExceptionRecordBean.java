/*     */ package com.ai.comframe.exception.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmExceptionRecordBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmExceptionRecordValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.exception.bo.BOVmExceptionRecord";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_ExceptionCode = "EXCEPTION_CODE";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_RuleOwner = "RULE_OWNER";
/*     */   public static final String S_NextTemplateTag = "NEXT_TEMPLATE_TAG";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_ExceptionRemarks = "EXCEPTION_REMARKS";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_ExceptionRecordId = "EXCEPTION_RECORD_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*  31 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmExceptionRecordBean()
/*     */     throws AIException
/*     */   {
/*  40 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  44 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  49 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value)
/*     */   {
/*  54 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/*  57 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/*  60 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/*  64 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/*  68 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initExceptionCode(String value) {
/*  72 */     initProperty("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCode(String value) {
/*  75 */     set("EXCEPTION_CODE", value);
/*     */   }
/*     */   public void setExceptionCodeNull() {
/*  78 */     set("EXCEPTION_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionCode() {
/*  82 */     return DataType.getAsString(get("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public String getExceptionCodeInitialValue() {
/*  86 */     return DataType.getAsString(getOldObj("EXCEPTION_CODE"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  90 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  93 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  96 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 100 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/* 104 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 108 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 111 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 114 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 118 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 122 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initRuleOwner(String value) {
/* 126 */     initProperty("RULE_OWNER", value);
/*     */   }
/*     */   public void setRuleOwner(String value) {
/* 129 */     set("RULE_OWNER", value);
/*     */   }
/*     */   public void setRuleOwnerNull() {
/* 132 */     set("RULE_OWNER", null);
/*     */   }
/*     */ 
/*     */   public String getRuleOwner() {
/* 136 */     return DataType.getAsString(get("RULE_OWNER"));
/*     */   }
/*     */ 
/*     */   public String getRuleOwnerInitialValue() {
/* 140 */     return DataType.getAsString(getOldObj("RULE_OWNER"));
/*     */   }
/*     */ 
/*     */   public void initNextTemplateTag(String value) {
/* 144 */     initProperty("NEXT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setNextTemplateTag(String value) {
/* 147 */     set("NEXT_TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setNextTemplateTagNull() {
/* 150 */     set("NEXT_TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getNextTemplateTag() {
/* 154 */     return DataType.getAsString(get("NEXT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getNextTemplateTagInitialValue() {
/* 158 */     return DataType.getAsString(getOldObj("NEXT_TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 162 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 165 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 168 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 172 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 176 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initExceptionRemarks(String value) {
/* 180 */     initProperty("EXCEPTION_REMARKS", value);
/*     */   }
/*     */   public void setExceptionRemarks(String value) {
/* 183 */     set("EXCEPTION_REMARKS", value);
/*     */   }
/*     */   public void setExceptionRemarksNull() {
/* 186 */     set("EXCEPTION_REMARKS", null);
/*     */   }
/*     */ 
/*     */   public String getExceptionRemarks() {
/* 190 */     return DataType.getAsString(get("EXCEPTION_REMARKS"));
/*     */   }
/*     */ 
/*     */   public String getExceptionRemarksInitialValue() {
/* 194 */     return DataType.getAsString(getOldObj("EXCEPTION_REMARKS"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 198 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 201 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 204 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 208 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 212 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initExceptionRecordId(long value) {
/* 216 */     initProperty("EXCEPTION_RECORD_ID", new Long(value));
/*     */   }
/*     */   public void setExceptionRecordId(long value) {
/* 219 */     set("EXCEPTION_RECORD_ID", new Long(value));
/*     */   }
/*     */   public void setExceptionRecordIdNull() {
/* 222 */     set("EXCEPTION_RECORD_ID", null);
/*     */   }
/*     */ 
/*     */   public long getExceptionRecordId() {
/* 226 */     return DataType.getAsLong(get("EXCEPTION_RECORD_ID"));
/*     */   }
/*     */ 
/*     */   public long getExceptionRecordIdInitialValue() {
/* 230 */     return DataType.getAsLong(getOldObj("EXCEPTION_RECORD_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 234 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 237 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 240 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 244 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 248 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  34 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  36 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.bo.BOVmExceptionRecordBean
 * JD-Core Version:    0.5.4
 */