package com.ai.comframe.exception.dao.interfaces;

import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;

public abstract interface IExceptionRecordDAO
{
  public abstract IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String paramString)
    throws Exception;

  public abstract IBOVmExceptionRecordValue[] getAllExceptionRecordsByInstanceId(String paramString)
    throws Exception;

  public abstract void saveExceptionRecord(IBOVmExceptionRecordValue paramIBOVmExceptionRecordValue)
    throws Exception;

  public abstract long getNewRecordId()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.dao.interfaces.IExceptionRecordDAO
 * JD-Core Version:    0.5.4
 */