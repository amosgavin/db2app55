/*    */ package com.ai.comframe.exception.dao.impl;
/*    */ 
/*    */ import com.ai.comframe.exception.bo.BOVmExceptionRecordBean;
/*    */ import com.ai.comframe.exception.bo.BOVmExceptionRecordEngine;
/*    */ import com.ai.comframe.exception.dao.interfaces.IExceptionRecordDAO;
/*    */ import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.utils.AssembleDef;
/*    */ import com.ai.comframe.utils.IDAssembleUtil;
/*    */ import com.ai.comframe.utils.TableAssembleUtil;
/*    */ import java.math.BigDecimal;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ExceptionRecordDAOImpl
/*    */   implements IExceptionRecordDAO
/*    */ {
/*    */   public IBOVmExceptionRecordValue[] getExceptionRecordsByInstanceId(String workflowId)
/*    */     throws Exception
/*    */   {
/* 23 */     String condition = "workflow_id =:workFlowId and state =:state";
/* 24 */     HashMap parameter = new HashMap();
/* 25 */     parameter.put("workFlowId", workflowId);
/* 26 */     parameter.put("state", "U");
/*    */ 
/* 28 */     AssembleDef def = new AssembleDef();
/* 29 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 30 */     BOVmExceptionRecordBean exceptionBean = new BOVmExceptionRecordBean();
/* 31 */     String sql = TableAssembleUtil.createSelectSQL(exceptionBean, def, condition.toString(), -1, -1);
/*    */ 
/* 33 */     IBOVmExceptionRecordValue[] exRecords = BOVmExceptionRecordEngine.getBeansFromSql(sql, parameter);
/* 34 */     if ((exRecords == null) || (exRecords.length < 1))
/* 35 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_nofindProcessExcepReasion") + workflowId + "]");
/* 36 */     return exRecords;
/*    */   }
/*    */ 
/*    */   public IBOVmExceptionRecordValue[] getAllExceptionRecordsByInstanceId(String workflowId)
/*    */     throws Exception
/*    */   {
/* 43 */     String condition = "workflow_id =:workFlowId ";
/* 44 */     HashMap parameter = new HashMap();
/* 45 */     parameter.put("workFlowId", workflowId);
/*    */ 
/* 48 */     AssembleDef def = new AssembleDef();
/* 49 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 50 */     BOVmExceptionRecordBean exceptionBean = new BOVmExceptionRecordBean();
/* 51 */     String sql = TableAssembleUtil.createSelectSQL(exceptionBean, def, condition.toString(), -1, -1);
/*    */ 
/* 53 */     IBOVmExceptionRecordValue[] exRecords = BOVmExceptionRecordEngine.getBeansFromSql(sql, parameter);
/* 54 */     if ((exRecords == null) || (exRecords.length < 1))
/* 55 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.exception.ComframeExceptionHandlerImpl.getNextCodeWorkFlowbyWorkFlowId_nofindProcessExcepReasion") + workflowId + "]");
/* 56 */     return exRecords;
/*    */   }
/*    */   public void saveExceptionRecord(IBOVmExceptionRecordValue exceptionRecordbean) throws Exception {
/* 59 */     BOVmExceptionRecordBean aExRecordBean = (BOVmExceptionRecordBean)exceptionRecordbean;
/* 60 */     TableAssembleUtil.replaceTableName(aExRecordBean);
/* 61 */     BOVmExceptionRecordEngine.save(aExRecordBean);
/*    */   }
/*    */ 
/*    */   public long getNewRecordId() throws Exception
/*    */   {
/* 66 */     long id = BOVmExceptionRecordEngine.getNewId().longValue();
/* 67 */     return id;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.dao.impl.ExceptionRecordDAOImpl
 * JD-Core Version:    0.5.4
 */