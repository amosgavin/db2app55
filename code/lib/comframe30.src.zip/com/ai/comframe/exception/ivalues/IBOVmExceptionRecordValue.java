package com.ai.comframe.exception.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmExceptionRecordValue extends DataStructInterface
{
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_ExceptionCode = "EXCEPTION_CODE";
  public static final String S_State = "STATE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_RuleOwner = "RULE_OWNER";
  public static final String S_NextTemplateTag = "NEXT_TEMPLATE_TAG";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_ExceptionRemarks = "EXCEPTION_REMARKS";
  public static final String S_TaskId = "TASK_ID";
  public static final String S_ExceptionRecordId = "EXCEPTION_RECORD_ID";
  public static final String S_CreateDate = "CREATE_DATE";

  public abstract String getWorkflowId();

  public abstract String getExceptionCode();

  public abstract String getState();

  public abstract String getRegionId();

  public abstract String getRuleOwner();

  public abstract String getNextTemplateTag();

  public abstract String getQueueId();

  public abstract String getExceptionRemarks();

  public abstract String getTaskId();

  public abstract long getExceptionRecordId();

  public abstract Timestamp getCreateDate();

  public abstract void setWorkflowId(String paramString);

  public abstract void setExceptionCode(String paramString);

  public abstract void setState(String paramString);

  public abstract void setRegionId(String paramString);

  public abstract void setRuleOwner(String paramString);

  public abstract void setNextTemplateTag(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setExceptionRemarks(String paramString);

  public abstract void setTaskId(String paramString);

  public abstract void setExceptionRecordId(long paramLong);

  public abstract void setCreateDate(Timestamp paramTimestamp);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue
 * JD-Core Version:    0.5.4
 */