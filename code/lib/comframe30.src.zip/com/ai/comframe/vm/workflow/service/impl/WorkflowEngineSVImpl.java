/*      */ package com.ai.comframe.vm.workflow.service.impl;
/*      */ 
/*      */ import com.ai.appframe2.common.DataContainerInterface;
/*      */ import com.ai.appframe2.common.ServiceManager;
/*      */ import com.ai.appframe2.common.Session;
/*      */ import com.ai.appframe2.complex.center.CenterFactory;
/*      */ import com.ai.appframe2.complex.center.CenterInfo;
/*      */ import com.ai.appframe2.privilege.UserInfoInterface;
/*      */ import com.ai.appframe2.service.ServiceFactory;
/*      */ import com.ai.comframe.client.ComframeBusiException;
/*      */ import com.ai.comframe.client.TaskInfo;
/*      */ import com.ai.comframe.client.WorkflowInfo;
/*      */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*      */ import com.ai.comframe.exception.service.impl.BusiExceptionDeal;
/*      */ import com.ai.comframe.exception.service.interfaces.IComframeExceptionHandleSV;
/*      */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*      */ import com.ai.comframe.utils.IDAssembleUtil;
/*      */ import com.ai.comframe.utils.PropertiesUtil;
/*      */ import com.ai.comframe.utils.TimeUtil;
/*      */ import com.ai.comframe.vm.common.ParameterDefine;
/*      */ import com.ai.comframe.vm.common.TaskConfig;
/*      */ import com.ai.comframe.vm.common.VMException;
/*      */ import com.ai.comframe.vm.common.VMUtil;
/*      */ import com.ai.comframe.vm.common.VMUtilDojo;
/*      */ import com.ai.comframe.vm.engine.FlowFactory;
/*      */ import com.ai.comframe.vm.engine.Task;
/*      */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*      */ import com.ai.comframe.vm.engine.TaskSign;
/*      */ import com.ai.comframe.vm.engine.TaskTimer;
/*      */ import com.ai.comframe.vm.engine.TaskUser;
/*      */ import com.ai.comframe.vm.engine.Workflow;
/*      */ import com.ai.comframe.vm.engine.WorkflowContext;
/*      */ import com.ai.comframe.vm.engine.impl.TaskFinishImpl;
/*      */ import com.ai.comframe.vm.engine.impl.TaskTimerImpl;
/*      */ import com.ai.comframe.vm.engine.impl.TaskWorkflowImpl;
/*      */ import com.ai.comframe.vm.engine.impl.WorkflowImpl;
/*      */ import com.ai.comframe.vm.template.TaskDealBean;
/*      */ import com.ai.comframe.vm.template.TaskTemplate;
/*      */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*      */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*      */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*      */ import com.ai.comframe.vm.workflow.bo.BOVmScheduleBean;
/*      */ import com.ai.comframe.vm.workflow.bo.BOVmTaskTSBean;
/*      */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*      */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskViewDAO;
/*      */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IVmScheduleSV;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*      */ import java.rmi.RemoteException;
/*      */ import java.sql.Date;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class WorkflowEngineSVImpl
/*      */   implements IWorkflowEngineSV
/*      */ {
/*   91 */   private static transient Log log = LogFactory.getLog(WorkflowEngineSVImpl.class);
/*      */   public static final String S_PARAM_NAME_QUEUE_IDS = "$QUEUE_IDS$";
/*      */ 
/*      */   private IVmTaskViewDAO getTaskViewDao()
/*      */   {
/*   95 */     return (IVmTaskViewDAO)ServiceFactory.getService(IVmTaskViewDAO.class);
/*      */   }
/*      */ 
/*      */   private IVmWorkflowDAO getWorkflowDao() {
/*   99 */     return (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*      */   }
/*      */ 
/*      */   private IVmTaskDAO getTaskDao() {
/*  103 */     return (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String parentTaskId, String templateTag, int workflowKind, String staffId, String objectTypeId, String objectId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  112 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  113 */     String queueId = templateSV.getEngineType(templateTag);
/*  114 */     return createWorkflow(queueId, parentTaskId, templateTag, workflowKind, staffId, objectTypeId, objectId, aVars);
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String aQueueId, String parentTaskId, String templateTag, int workflowKind, String staffId, String objectTypeId, String objectId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  121 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  122 */     String scheduleServerName = templateSV.getEngineType(templateTag);
/*  123 */     if (org.apache.commons.lang.StringUtils.isBlank(scheduleServerName))
/*      */     {
/*  125 */       String[] param = new String[1];
/*  126 */       param[0] = templateTag;
/*  127 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.service.impl.WorkflowEngineSVImpl_accordingToTemplateTagFindMoreEngine", param));
/*      */     }
/*  129 */     return createWorkflow(aQueueId, parentTaskId, templateTag, workflowKind, scheduleServerName, staffId, objectTypeId, objectId, aVars, null, null);
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String aQueueId, String parentTaskId, String templateTag, int workflowKind, String scheduleServerName, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/*  138 */     String result = "-1";
/*  139 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  140 */     if ((aQueueId == null) || (aQueueId.length() == 0))
/*      */     {
/*  142 */       aQueueId = templateSV.getQueueId(templateTag);
/*      */     }
/*  144 */     WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(templateTag);
/*  145 */     if (template == null) {
/*  146 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.config.templateNotExist") + templateTag);
/*      */     }
/*  148 */     if (template.getTaskType().equalsIgnoreCase("workflow"))
/*      */     {
/*  151 */       result = createAndNoExecuteWorkflow(aQueueId, parentTaskId, template, workflowKind, scheduleServerName, staffId, objectTypeId, objectId, aVars, startTime, notes);
/*      */     }
/*  155 */     else if (template.getTaskType().equalsIgnoreCase("process"))
/*      */     {
/*  157 */       if (startTime != null) {
/*  158 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.createWorkflow_processNoSetStartTime"));
/*      */       }
/*  160 */       result = createAndExecuteWorkflow(aQueueId, parentTaskId, template, workflowKind, staffId, objectTypeId, objectId, aVars, notes);
/*      */     }
/*      */     else
/*      */     {
/*  166 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.createWorkflow_processTemplate") + template.getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.createWorkflow_taskType") + template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.createWorkflow_unValuableCheckSets"));
/*      */     }
/*      */ 
/*  170 */     return result;
/*      */   }
/*      */ 
/*      */   private String createAndNoExecuteWorkflow(String aQueueId, String parentTaskId, WorkflowTemplate template, int workflowKind, String scheduleServerName, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes)
/*      */     throws Exception
/*      */   {
/*  178 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  179 */     String regionId = "";
/*  180 */     if ((CenterFactory.isSetCenterInfo()) && (CenterFactory.getCenterInfo() != null)) {
/*  181 */       regionId = CenterFactory.getCenterInfo().getRegion();
/*      */     }
/*  183 */     String workflowId = workflowDAO.getNewWorkFlowId(aQueueId, regionId);
/*  184 */     Workflow workflow = new WorkflowImpl(aQueueId, parentTaskId, workflowId, workflowKind, template, aVars, 2, new Date(TimeUtil.getSysTime().getTime()), new Date(TimeUtil.getSysTime().getTime()), staffId, objectTypeId, objectId);
/*      */ 
/*  193 */     workflow.monitor(staffId, null, 11);
/*      */ 
/*  196 */     workflow.getDataBean().set("ENGINE_TYPE", scheduleServerName.toUpperCase());
/*  197 */     if ((notes != null) && (!notes.equals(""))) {
/*  198 */       workflow.getDataBean().set("DESCRIPTION", notes);
/*      */     }
/*  200 */     boolean isStart = true;
/*  201 */     Timestamp time = TimeUtil.getSysTime();
/*  202 */     if ((startTime != null) && (startTime.after(time))) {
/*  203 */       isStart = false;
/*  204 */       workflow.disable(staffId, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.createAndNoExecuteWorkflow_waitStartTime"));
/*  205 */       workflow.getDataBean().set("START_DATE", startTime);
/*      */     }
/*      */ 
/*  208 */     FlowFactory.save(workflow);
/*  209 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/*  210 */     IBOVmScheduleValue schedule = new BOVmScheduleBean();
/*  211 */     schedule.setWorkflowId(workflowId);
/*  212 */     schedule.setQueueId(aQueueId);
/*  213 */     if (PropertiesUtil.isDev()) {
/*  214 */       String devName = PropertiesUtil.getDevId();
/*  215 */       if (org.apache.commons.lang.StringUtils.isEmpty(devName)) {
/*  216 */         String[] param = new String[1];
/*  217 */         param[0] = "comframe.dev.name";
/*  218 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*      */       }
/*  220 */       schedule.setDevId(devName);
/*      */     }
/*  222 */     schedule.setEngineType(scheduleServerName);
/*  223 */     if (!isStart)
/*  224 */       schedule.setState(String.valueOf('F'));
/*      */     else {
/*  226 */       schedule.setState(String.valueOf('W'));
/*      */     }
/*  228 */     schedule.setStateDate(time);
/*  229 */     scheduleSV.saveVmSchedule(schedule);
/*  230 */     if (!isStart) {
/*  231 */       Date runTime = new Date(startTime.getTime());
/*  232 */       TaskTimerImpl.insertTimerRecord(workflow.getCurrentTasks()[0].getTaskId(), workflow.getWorkflowId(), workflow.getQueueId(), workflow.getDistrictId(), "STARTTIME", runTime);
/*      */     }
/*      */ 
/*  238 */     return workflowId;
/*      */   }
/*      */ 
/*      */   private String createAndExecuteWorkflow(String aQueueId, String parentTaskId, WorkflowTemplate template, int workflowKind, String staffId, String objectTypeId, String objectId, Map aVars, String notes)
/*      */     throws Exception
/*      */   {
/*  260 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  261 */     String regionId = "";
/*  262 */     if ((CenterFactory.isSetCenterInfo()) && (CenterFactory.getCenterInfo() != null))
/*  263 */       regionId = CenterFactory.getCenterInfo().getRegion();
/*  264 */     String workflowId = workflowDAO.getNewWorkFlowId(aQueueId, regionId);
/*  265 */     Workflow workflow = new WorkflowImpl(aQueueId, parentTaskId, workflowId, workflowKind, template, aVars, 2, new Date(TimeUtil.getSysTime().getTime()), new Date(TimeUtil.getSysTime().getTime()), staffId, objectTypeId, objectId);
/*      */     try
/*      */     {
/*  275 */       workflow.monitor(staffId, null, 11);
/*  276 */       if ((notes != null) && (!notes.equals(""))) {
/*  277 */         workflow.getDataBean().set("DESCRIPTION", notes);
/*      */       }
/*      */ 
/*  280 */       workflow.executeWorkflowSyn();
/*  281 */       FlowFactory.save(workflow);
/*      */ 
/*  284 */       workflow.monitor(staffId, null, 12);
/*  285 */       return workflowId;
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*  289 */       workflow.monitor(staffId, e, 13);
/*      */ 
/*  291 */       throw new Exception(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stopWorkflow(String workflowId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  304 */     Workflow workflow = getWorkflowForSchedule(workflowId);
/*  305 */     if ((workflow.getState() == 3) || (workflow.getState() == 4) || (workflow.getState() == 11) || (workflow.getState() == 97))
/*      */     {
/*  307 */       log.error("The workflow state is finsh,can't stop! workflowId:" + workflowId);
/*  308 */       return;
/*      */     }
/*  310 */     workflow.disable(staffId, reason);
/*  311 */     FlowFactory.save(workflow);
/*  312 */     removeScheduleWorkflow(workflowId);
/*      */   }
/*      */ 
/*      */   public void stopWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  327 */     String[] workflowIds = getWorkflowsByWorkflowObjectId(queueID, workflowObjectType, workflowObjectId);
/*  328 */     if ((workflowIds == null) || (workflowIds.length == 0)) {
/*  329 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_accdBusiObjType") + workflowObjectType + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_busObjCode") + workflowObjectId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_nofindeProcessIns"));
/*      */     }
/*      */ 
/*  333 */     for (int i = 0; i < workflowIds.length; ++i)
/*      */     {
/*  335 */       stopWorkflow(workflowIds[i], staffId, reason);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void resumeWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  351 */     String[] workflowIds = getWorkflowsByWorkflowObjectId(queueID, workflowObjectType, workflowObjectId);
/*  352 */     if ((workflowIds == null) || (workflowIds.length == 0)) {
/*  353 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_accdBusiObjType") + workflowObjectType + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_busObjCode") + workflowObjectId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.stopWorkflow_nofindeProcessIns"));
/*      */     }
/*      */ 
/*  357 */     for (int i = 0; i < workflowIds.length; ++i)
/*      */     {
/*  359 */       resumeWorkflow(workflowIds[i], staffId, reason);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void resumeWorkflow(String workflowId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  372 */     Workflow workflow = getWorkflowForSchedule(workflowId);
/*  373 */     if ((workflow.getState() == 3) || (workflow.getState() == 4) || (workflow.getState() == 11) || (workflow.getState() == 97))
/*      */     {
/*  375 */       log.error("The workflow state is finsh,can't resume! workflowId:" + workflowId);
/*  376 */       return;
/*      */     }
/*  378 */     workflow.enable(staffId, reason);
/*  379 */     FlowFactory.save(workflow);
/*  380 */     addScheduleWorkflow(workflow);
/*      */   }
/*      */ 
/*      */   public void terminateWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  385 */     Workflow workflow = getWorkflowForSchedule(workflowId);
/*  386 */     if ((workflow == null) || (workflow.getState() == 4)) {
/*  387 */       return;
/*      */     }
/*  389 */     if (workflow.getState() == 97) {
/*  390 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.terminateWorkflow_startUnnormalNoEnd"));
/*      */     }
/*      */ 
/*  393 */     ITaskSV taskSV = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*  394 */     IVmWorkflowSV wfSV = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/*      */ 
/*  396 */     IBOVmWFValue workflowbean = wfSV.getVmWorkflowBeanbyId(workflow.getWorkflowId());
/*  397 */     Timestamp sysdate = TimeUtil.getSysTime();
/*  398 */     workflowbean.setStateDate(sysdate);
/*  399 */     workflowbean.setFinishDate(sysdate);
/*  400 */     workflowbean.setState(4);
/*  401 */     workflowbean.setOpStaffId(staffId);
/*  402 */     workflowbean.setDescription(reason);
/*  403 */     wfSV.saveVmWorkflowInstacne(workflowbean);
/*      */ 
/*  405 */     Task[] tasks = workflow.getCurrentTasks();
/*  406 */     if ((null != tasks) && (tasks.length > 0)) {
/*  407 */       for (int i = 0; i < tasks.length; ++i) {
/*  408 */         Task task = tasks[i];
/*  409 */         String taskID = task.getTaskId();
/*  410 */         IBOVmTaskValue vmTask = taskSV.getVmTaskByID(taskID);
/*  411 */         vmTask.setState(4);
/*  412 */         vmTask.setFinishDate(sysdate);
/*  413 */         vmTask.setStateDate(sysdate);
/*  414 */         taskSV.saveVmTaskInstance(vmTask);
/*      */       }
/*      */     }
/*  417 */     addScheduleWorkflow(workflow);
/*      */   }
/*      */ 
/*      */   public void terminateWorkflowInQueue(Workflow workflow)
/*      */     throws RemoteException, Exception
/*      */   {
/*  435 */     TaskFinishImpl.dealWhenWorkflowFinish(workflow, "-1", 4);
/*  436 */     FlowFactory.save(workflow);
/*  437 */     deleteVMSchedule(workflow.getWorkflowId());
/*      */   }
/*      */ 
/*      */   public void terminateWorkflowInner(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*      */   {
/*  442 */     Workflow workflow = getWorkflowForSchedule(workflowId);
/*  443 */     if ((workflow == null) || (workflow.getState() == 4)) {
/*  444 */       return;
/*      */     }
/*      */ 
/*  447 */     TaskFinishImpl.dealWhenWorkflowFinish(workflow, "-1", 4);
/*  448 */     workflow.terminate(staffId, reason);
/*  449 */     FlowFactory.save(workflow);
/*  450 */     deleteVMSchedule(workflowId);
/*      */   }
/*      */ 
/*      */   public void dropWorkflow(String workflowId) throws RemoteException, Exception {
/*  454 */     IBOVmWFValue wfBean = getWorkflowDao().getVmWorkflowBeanbyId(workflowId);
/*  455 */     if (wfBean != null) {
/*  456 */       wfBean.delete();
/*  457 */       getWorkflowDao().saveVmWorkflowInstacne(wfBean);
/*  458 */       IBOVmTaskValue[] taskBeans = getTaskDao().getVmTaskbeanByWorkflowId(workflowId);
/*  459 */       for (int i = 0; i < taskBeans.length; ++i) {
/*  460 */         taskBeans[i].delete();
/*  461 */         getTaskDao().saveVmtaskInstacne(taskBeans[i]);
/*      */       }
/*  463 */       IBOVmTaskTSValue[] taskTSBeans = getTaskDao().getVmTaskTransBeans(workflowId, null);
/*  464 */       for (int i = 0; i < taskTSBeans.length; ++i) {
/*  465 */         taskTSBeans[i].delete();
/*  466 */         getTaskDao().saveVmtaskTransInstacne(taskTSBeans[i]);
/*      */       }
/*      */     } else {
/*  469 */       IBOHVmWFValue hisWFBean = getWorkflowDao().getHisVmWorkflowBeanbyId(workflowId);
/*  470 */       hisWFBean.delete();
/*  471 */       getWorkflowDao().saveHVmWorkflowInstacne(hisWFBean);
/*  472 */       IBOHVmTaskValue[] hisTaskBeans = getTaskDao().getHVmTaskbeanByWorkflowId(workflowId);
/*  473 */       for (int i = 0; i < hisTaskBeans.length; ++i) {
/*  474 */         hisTaskBeans[i].delete();
/*  475 */         getTaskDao().saveHVmtaskInstacne(hisTaskBeans[i]);
/*      */       }
/*  477 */       IBOHVmTaskTSValue[] hisTaskTSBeans = getTaskDao().getHVmTaskTransBeans(workflowId);
/*  478 */       for (int i = 0; i < hisTaskTSBeans.length; ++i) {
/*  479 */         hisTaskTSBeans[i].delete();
/*  480 */         getTaskDao().saveHVmtaskTransInstacne(hisTaskTSBeans[i]);
/*      */       }
/*      */     }
/*      */ 
/*  484 */     deleteVMSchedule(workflowId);
/*      */   }
/*      */ 
/*      */   public void dropWorkflow(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  489 */     String[] ids = getWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*  490 */     for (int i = 0; i < ids.length; ++i)
/*  491 */       dropWorkflow(ids[i]);
/*      */   }
/*      */ 
/*      */   public void cancelWorkflowByWorkflowObject(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/*  497 */     String[] ids = getWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*  498 */     for (int i = 0; i < ids.length; ++i)
/*  499 */       cancelWorkflow(ids[i], staffId, errorCode, errorMessage);
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String nextWorkflow, String errorMessage)
/*      */     throws Exception
/*      */   {
/*  505 */     String[] ids = getWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*  506 */     for (int i = 0; i < ids.length; ++i)
/*  507 */       cancelWorkflow(ids[i], staffId, errorCode, nextWorkflow, errorMessage);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksByStationId(String queueID, long stationId, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/*  529 */     return getTaskViewDao().getTasksByStationId(queueID, stationId, workflowTemplateCode, taskTag);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksByStationId(String queueID, long[] stations, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/*  552 */     return getTaskViewDao().getTasksByStationId(queueID, stations, workflowTemplateCode, taskTag);
/*      */   }
/*      */ 
/*      */   public boolean canExecuteTask(String taskId, long[] stations, String staffId) throws Exception
/*      */   {
/*      */     try {
/*  558 */       String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  559 */       StringBuilder stationCondition = new StringBuilder("");
/*  560 */       HashMap params = new HashMap();
/*  561 */       if ((stations == null) || (stations.length == 0)) {
/*  562 */         stationCondition = null;
/*      */       } else {
/*  564 */         stationCondition.append(" in ( ");
/*  565 */         for (int i = 0; i < stations.length; ++i) {
/*  566 */           stationCondition.append(":station").append(i);
/*  567 */           if (i != stations.length - 1)
/*  568 */             stationCondition.append(" , ");
/*  569 */           params.put("station" + i, String.valueOf(stations[i]));
/*      */         }
/*  571 */         stationCondition.append(" ) ");
/*      */       }
/*      */ 
/*  574 */       StringBuilder condition = new StringBuilder("");
/*  575 */       if (stationCondition == null)
/*      */       {
/*  577 */         condition.append("TASK_ID").append(" = ").append(":taskId");
/*  578 */         condition.append(" AND ").append("TASK_STAFF_ID").append(" = ").append(":staffId ");
/*  579 */         condition.append(" AND ").append("STATE").append(" in (").append(":activeState").append(" , ").append(":printState").append(" )");
/*  580 */         condition.append(" AND ").append("WORKFLOW_STATE").append(" in (").append(":wActiveState").append(" , ").append(":enabledState").append(" )");
/*  581 */         params.put("taskId", taskId);
/*  582 */         params.put("staffId", staffId);
/*  583 */         params.put("activeState", new Integer(5));
/*  584 */         params.put("printState", new Integer(9));
/*  585 */         params.put("wActiveState", new Integer(5));
/*  586 */         params.put("enabledState", new Integer(2));
/*      */       }
/*      */       else {
/*  589 */         condition.append("TASK_ID").append(" = ").append(":taskId");
/*  590 */         condition.append(" AND (").append("STATION_ID").append(stationCondition);
/*  591 */         condition.append(" OR ").append("TASK_STAFF_ID").append(" = :staffId ").append(" )");
/*  592 */         condition.append(" AND ").append("STATE").append(" in (").append(":activeState").append(" , ").append(":printState").append(" )");
/*  593 */         condition.append(" AND ").append("WORKFLOW_STATE").append(" in (").append(":wActiveState").append(" , ").append(":enabledState").append(" )");
/*  594 */         params.put("taskId", taskId);
/*  595 */         params.put("staffId", staffId);
/*  596 */         params.put("activeState", new Integer(5));
/*  597 */         params.put("printState", new Integer(9));
/*  598 */         params.put("wActiveState", new Integer(5));
/*  599 */         params.put("enabledState", new Integer(2));
/*      */       }
/*  601 */       TaskInfo[] beans = getTaskInfos(queueID, condition.toString(), params, -1, -1);
/*      */ 
/*  603 */       return (beans != null) && (beans.length > 0);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  610 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.canExecuteTask_testStaff") + staffId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.canExecuteTask_canExcuteTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.canExecuteTask_failed") + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksByStationIdAndStaffId(String queueID, long[] stations, String staffId, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/*  619 */     return getTaskViewDao().getTasksByStationIdAndStaffId(queueID, stations, staffId, workflowTemplateCode, taskTag);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksCanBeDragged(String queueID, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  632 */     String cond = " workflow_id in (  select workflow_id from vm_task_view where finish_staff_id = :staffId  ) and workflow_state = 2 ";
/*      */ 
/*  635 */     HashMap param = new HashMap();
/*  636 */     param.put("staffId", staffId);
/*  637 */     TaskInfo[] allBeans = getTaskInfos(queueID, cond, param, -1, -1);
/*      */ 
/*  639 */     if ((allBeans == null) || (allBeans.length == 0)) {
/*  640 */       return new TaskInfo[0];
/*      */     }
/*      */ 
/*  643 */     List tmpList = new ArrayList();
/*      */ 
/*  645 */     for (int i = 0; i < allBeans.length; ++i) {
/*  646 */       if ((allBeans[i].getFinishStaffId() == null) || (!allBeans[i].getFinishStaffId().equals(staffId)))
/*      */         continue;
/*  648 */       tmpList.add(allBeans[i]);
/*      */     }
/*  650 */     if (tmpList.size() == 0) {
/*  651 */       return new TaskInfo[0];
/*      */     }
/*  653 */     TaskInfo[] myTasks = (TaskInfo[])(TaskInfo[])tmpList.toArray(new TaskInfo[0]);
/*  654 */     tmpList.clear();
/*  655 */     for (int i = 0; i < myTasks.length; ++i) {
/*  656 */       _getUserTaskAfterMine(myTasks[i], allBeans, tmpList);
/*      */     }
/*      */ 
/*  659 */     return (TaskInfo[])(TaskInfo[])tmpList.toArray(new TaskInfo[0]);
/*      */   }
/*      */ 
/*      */   private void _getUserTaskAfterMine(TaskInfo myTask, TaskInfo[] allBeans, List taskList) throws RemoteException, Exception {
/*  663 */     for (int j = 0; j < allBeans.length; ++j) {
/*  664 */       if (org.apache.commons.lang.StringUtils.isBlank(allBeans[j].getLastTaskId())) {
/*      */         continue;
/*      */       }
/*  667 */       if (!org.apache.commons.lang.StringUtils.isNumeric(allBeans[j].getLastTaskId()))
/*      */         continue;
/*  669 */       String taskId = allBeans[j].getLastTaskId();
/*      */ 
/*  671 */       if (myTask.getTaskId().equals(taskId)) {
/*  672 */         String type = TaskConfig.getInstance().getBasalType(allBeans[j].getTasktype());
/*  673 */         if (type.equals("user")) {
/*  674 */           if (allBeans[j].getState() == 3) {
/*      */             continue;
/*      */           }
/*      */ 
/*  678 */           if (allBeans[j].getState() == 9) {
/*  679 */             taskList.add(allBeans[j]);
/*      */           }
/*      */           else {
/*  682 */             if ((allBeans[j].getState() != 5) || (!org.apache.commons.lang.StringUtils.isBlank(allBeans[j].getFinishStaffId())))
/*      */               continue;
/*  684 */             taskList.add(allBeans[j]);
/*      */           }
/*      */         }
/*  687 */         else if (type.equals("sign")) {
/*  688 */           if (allBeans[j].getState() == 3) {
/*      */             continue;
/*      */           }
/*      */ 
/*  692 */           IBOVmTaskTSValue[] children = getTaskTransInfoByParentTaskId(allBeans[j].getTaskId(), allBeans[j].getWorkflowId());
/*  693 */           if (children == null) continue; if (children.length == 0) {
/*      */             continue;
/*      */           }
/*  696 */           boolean hasActive = false;
/*  697 */           boolean hasFinished = false;
/*  698 */           for (int k = 0; k < children.length; ++k) {
/*  699 */             if (children[k].getState() == 3) {
/*  700 */               hasFinished = true;
/*  701 */               break;
/*      */             }
/*  703 */             if (children[k].getState() == 5) {
/*  704 */               hasActive = true;
/*      */             }
/*      */           }
/*      */ 
/*  708 */           if (hasFinished == true) {
/*      */             continue;
/*      */           }
/*      */ 
/*  712 */           if ((allBeans[j].getState() == 9) && (hasActive == true))
/*      */           {
/*      */             continue;
/*      */           }
/*      */ 
/*  717 */           taskList.add(allBeans[j]);
/*      */         }
/*  720 */         else if (allBeans[j].getState() == 3) {
/*  721 */           _getUserTaskAfterMine(allBeans[j], allBeans, taskList);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception {
/*  728 */     return getTaskViewDao().getTaskInfos(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/*  733 */     return getTaskViewDao().getTaskInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHis(String queueID, String acctPeriod, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/*  738 */     return getTaskViewDao().getTaskInfosHis(queueID, acctPeriod, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public int getTaskCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/*  744 */     return getTaskViewDao().getTaskCount(queueID, condition, parameter);
/*      */   }
/*      */ 
/*      */   public int getTaskHisCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception
/*      */   {
/*  749 */     return getTaskViewDao().getTaskHisCount(queueID, condition, parameter);
/*      */   }
/*      */ 
/*      */   public int getTaskHisCount(String queueID, String acctPeriod, String condition, HashMap parameter) throws RemoteException, Exception
/*      */   {
/*  754 */     return getTaskViewDao().getTaskHisCount(queueID, acctPeriod, condition, parameter);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*      */     try {
/*  760 */       if (org.apache.commons.lang.StringUtils.isBlank(objectId)) {
/*  761 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */       }
/*  763 */       StringBuffer cond = new StringBuffer();
/*  764 */       cond.append("WORKFLOW_OBJECT_ID").append(" = :objId ");
/*  765 */       HashMap param = new HashMap();
/*  766 */       param.put("objId", objectId);
/*  767 */       if (org.apache.commons.lang.StringUtils.isNotBlank(objectTypeId)) {
/*  768 */         cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append(" = :objTypeId ");
/*  769 */         param.put("objTypeId", objectTypeId);
/*      */       }
/*  771 */       return getTaskInfos(queueID, cond.toString(), param, -1, -1);
/*      */     }
/*      */     catch (Exception e) {
/*  774 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByWorkflowObjectId_accdObjCodeReadTaskF") + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception {
/*      */     try {
/*  780 */       if (org.apache.commons.lang.StringUtils.isBlank(objectId)) {
/*  781 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */       }
/*  783 */       StringBuffer cond = new StringBuffer();
/*  784 */       cond.append("WORKFLOW_OBJECT_ID").append(" = :objId ");
/*  785 */       HashMap param = new HashMap();
/*  786 */       param.put("objId", objectId);
/*  787 */       if (org.apache.commons.lang.StringUtils.isNotBlank(objectTypeId)) {
/*  788 */         cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append(" = :objTypeId ");
/*  789 */         param.put("objTypeId", objectTypeId);
/*      */       }
/*  791 */       return getTaskInfosHis(queueID, cond.toString(), param, -1, -1);
/*      */     }
/*      */     catch (Exception e) {
/*  794 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByWorkflowObjectId_accdObjCodeReadTaskF") + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception {
/*      */     try {
/*  800 */       if (org.apache.commons.lang.StringUtils.isBlank(objectId)) {
/*  801 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */       }
/*  803 */       StringBuffer cond = new StringBuffer();
/*  804 */       cond.append("WORKFLOW_OBJECT_ID").append(" = :objId ");
/*  805 */       HashMap param = new HashMap();
/*  806 */       param.put("objId", objectId);
/*  807 */       if (org.apache.commons.lang.StringUtils.isNotBlank(objectTypeId)) {
/*  808 */         cond.append(" and ").append("WORKFLOW_OBJECT_TYPE").append(" = :objTypeId ");
/*  809 */         param.put("objTypeId", objectTypeId);
/*      */       }
/*  811 */       return getTaskInfosHis(queueID, acctPeriod, cond.toString(), param, -1, -1);
/*      */     }
/*      */     catch (Exception e) {
/*  814 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByWorkflowObjectId_accdObjCodeReadTaskF") + e.getMessage());
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getTaskId(String workflowId, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/*  826 */     String cond = " WORKFLOW_ID =:workflowID and TASK_TAG =:taskTag ";
/*  827 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/*  828 */     HashMap p = new HashMap();
/*  829 */     p.put("workflowID", workflowId);
/*  830 */     p.put("taskTag", taskTag);
/*  831 */     TaskInfo[] tasks = getTaskInfos(queueID, cond, p, -1, -1);
/*  832 */     if ((tasks == null) || (tasks.length == 0))
/*  833 */       return "";
/*  834 */     return tasks[0].getTaskId();
/*      */   }
/*      */ 
/*      */   public IBOVmTaskValue getTaskBean(String taskId) throws Exception {
/*  838 */     return FlowFactory.getTaskBean(taskId);
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfo(String taskId) throws RemoteException, Exception {
/*  842 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  843 */     String cond = "TASK_ID = :taskID ";
/*  844 */     HashMap p = new HashMap();
/*  845 */     p.put("taskID", taskId);
/*  846 */     TaskInfo[] tasks = getTaskInfos(queueID, cond, p, -1, -1);
/*  847 */     if ((tasks == null) || (tasks.length == 0))
/*  848 */       return null;
/*  849 */     return tasks[0];
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfoHis(String taskId) throws RemoteException, Exception {
/*  853 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  854 */     String cond = "TASK_ID = :taskID ";
/*  855 */     HashMap p = new HashMap();
/*  856 */     p.put("taskID", taskId);
/*  857 */     TaskInfo[] tasks = getTaskInfosHis(queueID, cond, p, -1, -1);
/*  858 */     if ((tasks == null) || (tasks.length == 0))
/*  859 */       return null;
/*  860 */     return tasks[0];
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfoHis(String taskId, String acctPeriod) throws RemoteException, Exception {
/*  864 */     String queueID = IDAssembleUtil.unwrapPrefix(taskId);
/*  865 */     String cond = "TASK_ID = :taskID ";
/*  866 */     HashMap p = new HashMap();
/*  867 */     p.put("taskID", taskId);
/*  868 */     TaskInfo[] tasks = getTaskInfosHis(queueID, acctPeriod, cond, p, -1, -1);
/*  869 */     if ((tasks == null) || (tasks.length == 0))
/*  870 */       return null;
/*  871 */     return tasks[0];
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getWorkflowInfoHis(String workflowId) throws RemoteException, Exception {
/*  875 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/*  876 */     StringBuffer cond = new StringBuffer(" ");
/*  877 */     cond.append("WORKFLOW_ID");
/*  878 */     cond.append(" = ").append(":wfID");
/*  879 */     HashMap p = new HashMap();
/*  880 */     p.put("wfID", workflowId);
/*  881 */     WorkflowInfo[] wfs = getTaskViewDao().getWorkflowInfoHis(queueID, cond.toString(), p, -1, -1);
/*  882 */     if ((wfs == null) || (wfs.length == 0))
/*  883 */       return null;
/*  884 */     return wfs[0];
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getWorkflowInfoHis(String workflowId, String acctPeriod) throws RemoteException, Exception {
/*  888 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/*  889 */     StringBuffer cond = new StringBuffer(" ");
/*  890 */     cond.append("WORKFLOW_ID");
/*  891 */     cond.append(" = ").append(":wfID");
/*  892 */     HashMap p = new HashMap();
/*  893 */     p.put("wfID", workflowId);
/*  894 */     WorkflowInfo[] wfs = getTaskViewDao().getWorkflowInfoHis(queueID, acctPeriod, cond.toString(), p, -1, -1);
/*  895 */     if ((wfs == null) || (wfs.length == 0))
/*  896 */       return null;
/*  897 */     return wfs[0];
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception {
/*  901 */     if (objectId == null) {
/*  902 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/*  904 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/*  905 */     HashMap map = new HashMap();
/*  906 */     map.put("objectId", objectId);
/*  907 */     if (objectTypeId != null) {
/*  908 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/*  909 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/*      */ 
/*  912 */     WorkflowInfo[] wfs = getWorkflowInfos(queueID, cond.toString(), map, -1, -1);
/*  913 */     if ((wfs == null) || (wfs.length == 0))
/*  914 */       return null;
/*  915 */     String[] ids = new String[wfs.length];
/*  916 */     for (int j = 0; j < wfs.length; ++j) {
/*  917 */       ids[j] = wfs[j].getWorkflowId();
/*      */     }
/*  919 */     return ids;
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  924 */     if (objectId == null) {
/*  925 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/*  927 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/*  928 */     HashMap map = new HashMap();
/*  929 */     map.put("objectId", objectId);
/*  930 */     if (objectTypeId != null) {
/*  931 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/*  932 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/*  934 */     WorkflowInfo[] wfs = getWorkflowInfosHis(queueID, cond.toString(), map, -1, -1);
/*  935 */     if ((wfs == null) || (wfs.length == 0))
/*  936 */       return null;
/*  937 */     String[] ids = new String[wfs.length];
/*  938 */     for (int j = 0; j < wfs.length; ++j) {
/*  939 */       ids[j] = wfs[j].getWorkflowId();
/*      */     }
/*  941 */     return ids;
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  946 */     if (objectId == null) {
/*  947 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/*  949 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/*  950 */     HashMap map = new HashMap();
/*  951 */     map.put("objectId", objectId);
/*  952 */     if (objectTypeId != null) {
/*  953 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/*  954 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/*  956 */     WorkflowInfo[] wfs = getWorkflowInfosHis(queueID, acctPreiod, cond.toString(), map, -1, -1);
/*  957 */     if ((wfs == null) || (wfs.length == 0))
/*  958 */       return null;
/*  959 */     String[] ids = new String[wfs.length];
/*  960 */     for (int j = 0; j < wfs.length; ++j) {
/*  961 */       ids[j] = wfs[j].getWorkflowId();
/*      */     }
/*  963 */     return ids;
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowsByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception {
/*  967 */     if (objectId == null) {
/*  968 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/*  970 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/*  971 */     HashMap map = new HashMap();
/*  972 */     map.put("objectId", objectId);
/*  973 */     if (objectTypeId != null) {
/*  974 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/*  975 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/*      */ 
/*  978 */     WorkflowInfo[] wfs = getWorkflowInfos(queueID, cond.toString(), map, -1, -1);
/*  979 */     if ((wfs == null) || (wfs.length == 0))
/*  980 */       return null;
/*  981 */     for (int j = 0; j < wfs.length; ++j) {
/*  982 */       WorkflowInfo wf = wfs[j];
/*  983 */       if (("-1".equals(wf.getParentTaskId())) && (-1 == wf.getWorkflowKind())) {
/*  984 */         return wf;
/*      */       }
/*      */     }
/*  987 */     return null;
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowsHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  992 */     if (objectId == null) {
/*  993 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/*  995 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/*  996 */     HashMap map = new HashMap();
/*  997 */     map.put("objectId", objectId);
/*  998 */     if (objectTypeId != null) {
/*  999 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/* 1000 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/* 1002 */     WorkflowInfo[] wfs = getWorkflowInfosHis(queueID, cond.toString(), map, -1, -1);
/* 1003 */     if ((wfs == null) || (wfs.length == 0))
/* 1004 */       return null;
/* 1005 */     for (int j = 0; j < wfs.length; ++j) {
/* 1006 */       WorkflowInfo wf = wfs[j];
/* 1007 */       if (("-1".equals(wf.getParentTaskId())) && (-1 == wf.getWorkflowKind())) {
/* 1008 */         return wf;
/*      */       }
/*      */     }
/* 1011 */     return null;
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowsHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/* 1016 */     if (objectId == null) {
/* 1017 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getWorkflowsByWorkflowObjectId_enterObjId"));
/*      */     }
/* 1019 */     StringBuffer cond = new StringBuffer(" WORKFLOW_OBJECT_ID = :objectId ");
/* 1020 */     HashMap map = new HashMap();
/* 1021 */     map.put("objectId", objectId);
/* 1022 */     if (objectTypeId != null) {
/* 1023 */       cond.append(" and WORKFLOW_OBJECT_TYPE = :objectTypeId ");
/* 1024 */       map.put("objectTypeId", objectTypeId);
/*      */     }
/* 1026 */     WorkflowInfo[] wfs = getWorkflowInfosHis(queueID, acctPreiod, cond.toString(), map, -1, -1);
/* 1027 */     if ((wfs == null) || (wfs.length == 0))
/* 1028 */       return null;
/* 1029 */     for (int j = 0; j < wfs.length; ++j) {
/* 1030 */       WorkflowInfo wf = wfs[j];
/* 1031 */       if (("-1".equals(wf.getParentTaskId())) && (-1 == wf.getWorkflowKind())) {
/* 1032 */         return wf;
/*      */       }
/*      */     }
/* 1035 */     return null;
/*      */   }
/*      */ 
/*      */   public synchronized void lockTask(String taskId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1045 */     ServiceManager.getSession().suspend();
/*      */     try {
/* 1047 */       ServiceManager.getSession().startTransaction();
/* 1048 */       IBOVmTaskValue task = null;
/*      */       try {
/* 1050 */         task = FlowFactory.getTaskBean(taskId);
/*      */       }
/*      */       catch (VMException e) {
/* 1053 */         task = null;
/*      */       }
/* 1055 */       if (task == null) {
/* 1056 */         lockTaskTrans(taskId, staffId);
/*      */       }
/*      */       else {
/* 1059 */         int oldState = task.getState();
/* 1060 */         if ((oldState != 5) && (oldState != 9) && (oldState != 2))
/*      */         {
/* 1062 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_noExcute"));
/* 1063 */         }if ((task.getLockStaffId() == null) || (task.getLockStaffId().trim().length() == 0)) {
/* 1064 */           task.setLockStaffId(staffId);
/* 1065 */           task.setLockDate(TimeUtil.getSysTime());
/* 1066 */           FlowFactory.save(task);
/*      */         }
/* 1068 */         else if ((task.getLockStaffId() != null) && (!task.getLockStaffId().equalsIgnoreCase(staffId)))
/*      */         {
/* 1070 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_taskAlready") + task.getLockStaffId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_lock"));
/*      */         }
/*      */       }
/*      */ 
/* 1074 */       ServiceManager.getSession().commitTransaction();
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/* 1078 */       throw new Exception(e);
/*      */     }
/*      */     finally {
/* 1081 */       ServiceManager.getSession().resume();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void realseTask(String taskId) throws RemoteException, Exception {
/* 1086 */     IBOVmTaskValue task = null;
/*      */     try {
/* 1088 */       task = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1091 */       task = null;
/*      */     }
/* 1093 */     if (task == null) {
/* 1094 */       realseTaskTrans(taskId);
/*      */     }
/*      */     else {
/* 1097 */       task.setLockStaffId(null);
/* 1098 */       task.setLockDate(null);
/* 1099 */       FlowFactory.save(task);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean finishUserTask(String taskId, String staffId, String result, Map aVars, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1121 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1123 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1126 */       taskBean = null;
/*      */     }
/* 1128 */     if (taskBean == null) {
/* 1129 */       return finishTaskTrans(taskId, staffId, result, aVars, reason);
/*      */     }
/*      */ 
/* 1133 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1134 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 1136 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_cannotReturn"));
/*      */     }
/*      */ 
/* 1140 */     if (aVars != null) {
/* 1141 */       WorkflowContext context = workflow.getWorkflowContext();
/* 1142 */       Iterator it = aVars.entrySet().iterator();
/* 1143 */       while (it.hasNext()) {
/* 1144 */         Map.Entry e = (Map.Entry)it.next();
/* 1145 */         ParameterDefine p = workflow.getWorkflowTemplate().getVars(e.getKey().toString());
/*      */ 
/* 1148 */         if (p != null) {
/* 1149 */           context.set(p.name, e.getValue());
/*      */         }
/*      */         else {
/* 1152 */           log.error("Please note that in the process" + workflow.getWorkflowTemplate().getTaskTag() + "Process variable is not defined：" + e.getKey());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1157 */     Task tmpTask = workflow.getTask(taskId);
/* 1158 */     if (tmpTask == null) {
/* 1159 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1161 */     if (!tmpTask instanceof TaskUser) {
/* 1162 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_task") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_notManTaskNoReturn"));
/*      */     }
/*      */ 
/* 1165 */     TaskUser task = (TaskUser)tmpTask;
/* 1166 */     task.finish(result, staffId, reason, workflow.getWorkflowContext());
/*      */ 
/* 1168 */     TaskTimerImpl.deleteTimerRecord(taskId);
/* 1169 */     FlowFactory.save(workflow);
/* 1170 */     addScheduleWorkflow(workflow);
/* 1171 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean printUserTaskBySystemAuto(String taskId, String staffId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1183 */     boolean result = _printUserTask(taskId, staffId, aVars, true);
/* 1184 */     TaskTimerImpl.deleteTimerRecord(taskId);
/* 1185 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean finishTaskByStarttime(String workflowId, String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1197 */     resumeWorkflow(workflowId, PropertiesUtil.getSystemUserId(), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishTaskByStarttime_startTimeOver"));
/* 1198 */     TaskTimerImpl.deleteTimerRecord(taskId);
/* 1199 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean finishUserTaskOvertime(String taskId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1212 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1214 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     } catch (VMException e) {
/* 1216 */       taskBean = null;
/*      */     }
/* 1218 */     if (taskBean == null) {
/* 1219 */       return true;
/*      */     }
/* 1221 */     if (taskBean.getState() == 3) {
/* 1222 */       return true;
/*      */     }
/*      */ 
/* 1225 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/*      */ 
/* 1227 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 1229 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_cannotReturn"));
/*      */     }
/*      */ 
/* 1234 */     boolean isTaskTrans = false;
/* 1235 */     if (taskBean.getState() == 10) {
/* 1236 */       isTaskTrans = true;
/*      */     } else {
/* 1238 */       String taskType = TaskConfig.getInstance().getBasalType(taskBean.getTaskType());
/*      */ 
/* 1240 */       if (taskType.equalsIgnoreCase("sign")) {
/* 1241 */         isTaskTrans = true;
/*      */       }
/*      */     }
/*      */ 
/* 1245 */     if (isTaskTrans) {
/* 1246 */       dealTransTaskDown(taskId, taskBean.getWorkflowId(), 4);
/*      */ 
/* 1248 */       taskBean.setState(5);
/* 1249 */       FlowFactory.save(taskBean);
/*      */     }
/*      */ 
/* 1253 */     TaskUser task = (TaskUser)workflow.getTask(taskId);
/* 1254 */     if (task == null) {
/* 1255 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1257 */     task.finishOverTime("overtime", staffId, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTaskOvertime_overtiome"), workflow.getWorkflowContext());
/*      */ 
/* 1261 */     TaskTimerImpl.deleteTimerRecord(taskId);
/* 1262 */     FlowFactory.save(workflow);
/* 1263 */     addScheduleWorkflow(workflow);
/* 1264 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean printUserTask(String taskId, String staffId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1282 */     return _printUserTask(taskId, staffId, aVars, false);
/*      */   }
/*      */ 
/*      */   private boolean _printUserTask(String taskId, String staffId, Map aVars, boolean autoPrint) throws Exception {
/* 1286 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1288 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     } catch (VMException e) {
/* 1290 */       taskBean = null;
/*      */     }
/* 1292 */     if (taskBean == null) {
/* 1293 */       return printTaskTrans(taskId, staffId, aVars, autoPrint);
/*      */     }
/*      */ 
/* 1300 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1301 */     if ((workflow.getState() != 2) && (workflow.getState() != 5)) {
/* 1302 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printUserTask_cannotPrint"));
/*      */     }
/*      */ 
/* 1310 */     WorkflowContext context = workflow.getWorkflowContext();
/*      */     Iterator it;
/* 1311 */     if (aVars != null) {
/* 1312 */       for (it = aVars.entrySet().iterator(); it.hasNext(); ) {
/* 1313 */         Map.Entry e = (Map.Entry)it.next();
/* 1314 */         ParameterDefine p = workflow.getWorkflowTemplate().getVars(e.getKey().toString());
/*      */ 
/* 1316 */         if (p != null)
/* 1317 */           context.set(p.name, e.getValue());
/*      */         else {
/* 1319 */           log.error("Please notice that in the process" + workflow.getWorkflowTemplate().getTaskTag() + "Process variable is not defined：" + e.getKey());
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1324 */     Task tmpTask = workflow.getTask(taskId);
/* 1325 */     if (tmpTask == null) {
/* 1326 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/*      */ 
/* 1332 */     if (!tmpTask instanceof TaskUser) {
/* 1333 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_task") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printUserTask_notManTaskNoPrint"));
/*      */     }
/*      */ 
/* 1339 */     TaskUser task = (TaskUser)tmpTask;
/* 1340 */     boolean isWait = task.print(staffId, workflow.getWorkflowContext());
/*      */ 
/* 1342 */     if (!autoPrint) {
/* 1343 */       task.getDataBean().set("TASK_STAFF_ID", staffId);
/*      */     }
/* 1345 */     FlowFactory.save(workflow);
/* 1346 */     if (!isWait) {
/* 1347 */       addScheduleWorkflow(workflow);
/*      */     }
/* 1349 */     return true;
/*      */   }
/*      */ 
/*      */   public void claimTask(String taskId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1365 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1367 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     } catch (VMException e) {
/* 1369 */       taskBean = null;
/*      */     }
/* 1371 */     if (taskBean == null) {
/* 1372 */       IBOVmTaskTSValue task = FlowFactory.getTaskTransBean(taskId);
/* 1373 */       if (task == null) {
/* 1374 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_transTask"));
/*      */       }
/* 1376 */       int oldState = task.getState();
/* 1377 */       if ((oldState != 5) && (oldState != 9) && (oldState != 2))
/*      */       {
/* 1380 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noExcuteNoOper"));
/*      */       }
/* 1382 */       task.setTaskStaffId(staffId);
/* 1383 */       FlowFactory.saveTaskTrans(task);
/*      */     } else {
/* 1385 */       int oldState = taskBean.getState();
/* 1386 */       if ((oldState != 5) && (oldState != 9) && (oldState != 2))
/*      */       {
/* 1389 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noExcuteNoOper"));
/*      */       }
/*      */ 
/* 1392 */       taskBean.setTaskStaffId(staffId);
/* 1393 */       FlowFactory.save(taskBean);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unClaimTask(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1406 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1408 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     } catch (VMException e) {
/* 1410 */       taskBean = null;
/*      */     }
/* 1412 */     if (taskBean == null) {
/* 1413 */       IBOVmTaskTSValue task = FlowFactory.getTaskTransBean(taskId);
/* 1414 */       if (task == null) {
/* 1415 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_task"));
/*      */       }
/*      */ 
/* 1419 */       FlowFactory.saveTaskTrans(task);
/*      */     } else {
/* 1421 */       taskBean.setTaskStaffId(null);
/* 1422 */       FlowFactory.save(taskBean);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String errorMessage) throws RemoteException, Exception
/*      */   {
/* 1428 */     IBOVmTaskValue task = getTaskBean(taskId);
/* 1429 */     InnerfireWorkflowExceptionByTaskId(task, staffId, errorCode, errorMessage);
/* 1430 */     BusiExceptionDeal.dealException(task.getWorkflowId(), new IBOVmTaskValue[] { task }, errorCode, errorMessage);
/*      */   }
/*      */ 
/*      */   public void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage) throws RemoteException, Exception
/*      */   {
/* 1435 */     IBOVmTaskValue task = getTaskBean(taskId);
/* 1436 */     InnerfireWorkflowExceptionByTaskId(task, staffId, errorCode, errorMessage);
/* 1437 */     BusiExceptionDeal.dealException(task.getWorkflowId(), new IBOVmTaskValue[] { task }, errorCode, nextWorkflowCode, errorMessage);
/*      */   }
/*      */ 
/*      */   private void InnerfireWorkflowExceptionByTaskId(IBOVmTaskValue task, String staffId, String errorCode, String errorMessage)
/*      */     throws Exception
/*      */   {
/* 1443 */     String message = errorCode + ":" + errorMessage;
/* 1444 */     Timestamp current = TimeUtil.getSysTime();
/* 1445 */     fireWorkflowBusinessException(task.getWorkflowId(), staffId, errorCode, errorMessage);
/* 1446 */     task.setState(98);
/* 1447 */     task.setErrorMessage(message);
/* 1448 */     task.setStateDate(current);
/* 1449 */     task.setFinishStaffId(staffId);
/* 1450 */     FlowFactory.save(task);
/*      */ 
/* 1452 */     IBOVmTaskTSValue[] transBeans = getTaskTransInfoByParentTaskId(null, task.getWorkflowId());
/* 1453 */     if ((transBeans != null) && (transBeans.length > 0)) {
/* 1454 */       for (int i = 0; i < transBeans.length; ++i) {
/* 1455 */         if ((transBeans[i].getState() != 9) && (transBeans[i].getState() != 5))
/*      */           continue;
/* 1457 */         transBeans[i].setState(98);
/* 1458 */         transBeans[i].setErrorMessage(message);
/* 1459 */         transBeans[i].setStateDate(current);
/* 1460 */         transBeans[i].setFinishStaffId(staffId);
/*      */       }
/*      */ 
/* 1463 */       FlowFactory.saveTaskTrans(transBeans);
/*      */     }
/*      */ 
/* 1466 */     IVmScheduleSV vmScheduleSv = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 1467 */     IBOVmScheduleValue schedule = vmScheduleSv.getVmScheduleByWorkflowId(task.getWorkflowId());
/* 1468 */     schedule.setState(String.valueOf('A'));
/* 1469 */     vmScheduleSv.saveVmSchedule(schedule);
/*      */   }
/*      */ 
/*      */   public void dealTaskError(String taskId, String staffId, String errorCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1477 */     IBOVmTaskValue taskBean = FlowFactory.getTaskBean(taskId);
/* 1478 */     IBOVmWFValue workflow = FlowFactory.getWorkflowBean(taskBean.getWorkflowId());
/* 1479 */     workflow.setState(99);
/* 1480 */     workflow.setStateDate(TimeUtil.getSysTime());
/* 1481 */     workflow.setOpStaffId(staffId);
/* 1482 */     workflow.setErrorMessage(errorCode + ":" + errorMessage);
/* 1483 */     FlowFactory.save(workflow);
/* 1484 */     TaskTimerImpl.updateTimerRecordState(taskId, 99, errorMessage);
/* 1485 */     removeScheduleWorkflow(taskBean.getWorkflowId());
/*      */   }
/*      */ 
/*      */   public void dealWorkflowError(String workflowId, String staffId, String errorCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1491 */     IBOVmWFValue workflow = FlowFactory.getWorkflowBean(workflowId);
/* 1492 */     workflow.setState(99);
/* 1493 */     workflow.setStateDate(TimeUtil.getSysTime());
/* 1494 */     workflow.setOpStaffId(staffId);
/* 1495 */     workflow.setErrorMessage(errorCode + ":" + errorMessage);
/* 1496 */     FlowFactory.save(workflow);
/* 1497 */     removeScheduleWorkflow(workflowId);
/*      */   }
/*      */ 
/*      */   private void fireWorkflowBusinessException(String workflowId, String staffId, String errorCode, String errorMessage)
/*      */     throws Exception
/*      */   {
/* 1503 */     IBOVmWFValue workflow = FlowFactory.getWorkflowBean(workflowId);
/* 1504 */     workflow.setState(98);
/* 1505 */     workflow.setStateDate(TimeUtil.getSysTime());
/* 1506 */     workflow.setOpStaffId(staffId);
/* 1507 */     workflow.setErrorMessage(errorCode + ":" + errorMessage);
/* 1508 */     FlowFactory.save(workflow);
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String workflowId, String staffId, String errorCode, String errorMessage) throws RemoteException, Exception
/*      */   {
/* 1513 */     innerCancelWorkflow(workflowId, staffId, errorCode, null, errorMessage);
/*      */   }
/*      */ 
/*      */   public boolean innerCancelWorkflow(String workflowId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage)
/*      */     throws Exception
/*      */   {
/* 1519 */     Workflow workflow = getWorkflow(workflowId);
/* 1520 */     Task[] tasks = workflow.getCurrentTasks();
/* 1521 */     boolean isNeedWait = false;
/* 1522 */     List currentTaskIds = new ArrayList();
/* 1523 */     Timestamp current = TimeUtil.getSysTime();
/* 1524 */     for (int i = 0; i < tasks.length; ++i) {
/* 1525 */       int state = tasks[i].getState();
/*      */ 
/* 1527 */       if ((state == 2) || (state == 9)) {
/* 1528 */         tasks[i].terminate(staffId, errorCode + ":" + errorMessage);
/* 1529 */         currentTaskIds.add(tasks[i].getDataBean());
/* 1530 */       } else if (state == 5)
/*      */       {
/* 1532 */         if (tasks[i].getTaskTemplate() instanceof TaskUserTemplate) {
/* 1533 */           if ((org.apache.commons.lang.StringUtils.isBlank(nextWorkflowCode)) && (((TaskUserTemplate)tasks[i].getTaskTemplate()).isNeedPrint() == true))
/*      */           {
/* 1535 */             ((IBOVmTaskValue)tasks[i].getDataBean()).setState(7);
/* 1536 */             ((IBOVmTaskValue)tasks[i].getDataBean()).setFinishStaffId(staffId);
/* 1537 */             ((IBOVmTaskValue)tasks[i].getDataBean()).setErrorMessage(errorCode + ":" + errorMessage);
/* 1538 */             ((IBOVmTaskValue)tasks[i].getDataBean()).setStateDate(current);
/* 1539 */             isNeedWait = true;
/*      */           } else {
/* 1541 */             tasks[i].terminate(staffId, errorCode + ":" + errorMessage);
/*      */           }
/*      */ 
/* 1544 */           IBOVmTaskTSValue[] transBeans = getTaskTransInfoByParentTaskId(tasks[i].getTaskId(), workflow.getWorkflowId());
/* 1545 */           if ((transBeans != null) && (transBeans.length > 0)) {
/* 1546 */             for (int j = 0; j < transBeans.length; ++j) {
/* 1547 */               if ((transBeans[j].getState() == 9) || (transBeans[j].getState() == 5))
/*      */               {
/* 1549 */                 transBeans[j].setState(4);
/* 1550 */                 transBeans[j].setErrorMessage(errorMessage);
/* 1551 */                 transBeans[j].setStateDate(current);
/* 1552 */                 transBeans[j].setFinishStaffId(staffId);
/*      */               } else {
/* 1554 */                 transBeans[j].setState(7);
/* 1555 */                 transBeans[j].setErrorMessage(errorMessage);
/* 1556 */                 transBeans[j].setStateDate(current);
/* 1557 */                 transBeans[j].setFinishStaffId(staffId);
/*      */               }
/*      */             }
/* 1560 */             FlowFactory.saveTaskTrans(transBeans);
/*      */           }
/* 1562 */         } else if (tasks[i] instanceof TaskTimer) {
/* 1563 */           TaskTimerImpl.deleteTimerRecord(tasks[i].getTaskId());
/* 1564 */           tasks[i].terminate(staffId, errorCode + ":" + errorMessage);
/* 1565 */         } else if (tasks[i] instanceof TaskWorkflowImpl) {
/* 1566 */           IBOVmWFValue[] beans = TaskWorkflowImpl.getChildWorkflows(tasks[i].getTaskId());
/* 1567 */           for (int j = 0; j < beans.length; ++j) {
/* 1568 */             String childWorkflowId = beans[j].getWorkflowId();
/* 1569 */             if (innerCancelWorkflow(childWorkflowId, staffId, errorCode, nextWorkflowCode, errorMessage) == true) {
/* 1570 */               isNeedWait = true;
/*      */             } else {
/* 1572 */               TaskWorkflowImpl.finish(tasks[i].getTaskId(), staffId, 4);
/* 1573 */               tasks[i].terminate(staffId, errorCode + ":" + errorMessage);
/*      */             }
/*      */           }
/*      */         } else {
/* 1577 */           throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.innerCancelWorkflow_taskKind") + tasks[i].getTaskTemplate().getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.innerCancelWorkflow_shouldNotState") + 5);
/*      */         }
/* 1579 */         currentTaskIds.add(tasks[i].getDataBean());
/*      */       } else {
/* 1581 */         currentTaskIds.add(tasks[i].getDataBean());
/*      */       }
/*      */     }
/*      */ 
/* 1585 */     if (org.apache.commons.lang.StringUtils.isBlank(nextWorkflowCode)) {
/* 1586 */       BusiExceptionDeal.dealException(workflowId, (IBOVmTaskValue[])(IBOVmTaskValue[])currentTaskIds.toArray(new IBOVmTaskValue[0]), errorCode, errorMessage);
/*      */     }
/*      */     else
/*      */     {
/* 1592 */       BusiExceptionDeal.dealException(workflowId, (IBOVmTaskValue[])(IBOVmTaskValue[])currentTaskIds.toArray(new IBOVmTaskValue[0]), errorCode, nextWorkflowCode, errorMessage);
/*      */     }
/*      */ 
/* 1595 */     if (isNeedWait == true) {
/* 1596 */       workflow.disable(staffId, errorCode + ":" + errorMessage);
/* 1597 */       FlowFactory.save(workflow);
/* 1598 */       removeScheduleWorkflow(workflowId);
/*      */     } else {
/* 1600 */       FlowFactory.save(workflow);
/* 1601 */       fireWorkflowBusinessException(workflowId, staffId, errorCode, errorMessage);
/* 1602 */       IVmScheduleSV vmScheduleSv = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 1603 */       IBOVmScheduleValue schedule = vmScheduleSv.getVmScheduleByWorkflowId(workflowId);
/* 1604 */       schedule.setState(String.valueOf('A'));
/* 1605 */       vmScheduleSv.saveVmSchedule(schedule);
/* 1606 */       delDealTask(workflowId);
/*      */     }
/* 1608 */     return isNeedWait;
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String workflowId, String staffId, String errorCode, String nextWorkflow, String errorMessage) throws RemoteException, Exception
/*      */   {
/* 1613 */     innerCancelWorkflow(workflowId, staffId, errorCode, nextWorkflow, errorMessage);
/*      */   }
/*      */ 
/*      */   public void delDealTask(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1622 */     ITaskSV taskSV = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 1623 */     IBOVmDealTaskValue[] dealTasks = taskSV.getVmDealTaskbeanByWorkflowId(workflowId);
/* 1624 */     if ((null != dealTasks) && (dealTasks.length > 0))
/* 1625 */       for (int i = 0; i < dealTasks.length; ++i) {
/* 1626 */         dealTasks[i].delete();
/* 1627 */         taskSV.saveVmDealTask(dealTasks[i]);
/*      */       }
/*      */   }
/*      */ 
/*      */   public boolean finishTimerTask(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1641 */     TaskTimerImpl.finish(taskId, "-1");
/* 1642 */     IBOVmTaskValue taskBean = FlowFactory.getTaskBean(taskId);
/* 1643 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1644 */     addScheduleWorkflow(workflow);
/* 1645 */     return true;
/*      */   }
/*      */   public boolean finishChildWorkflowTask(String taskId, String childWorkflowId, Map paramters, int childWorkflowState) throws RemoteException, Exception {
/* 1648 */     IBOVmTaskValue bean = getTaskBean(taskId);
/* 1649 */     Workflow workflow = getWorkflowForSchedule(bean.getWorkflowId());
/* 1650 */     Task task = workflow.getTask(taskId);
/* 1651 */     if (task == null) {
/* 1652 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1654 */     TaskWorkflowTemplate taskTemplate = (TaskWorkflowTemplate)task.getTaskTemplate();
/*      */ 
/* 1656 */     ParameterDefine[] outparameters = taskTemplate.getOutParameterDefine();
/* 1657 */     for (int i = 0; i < outparameters.length; ++i) {
/* 1658 */       if (com.ai.appframe2.util.StringUtils.isEmptyString(outparameters[i].contextVarName)) {
/*      */         continue;
/*      */       }
/*      */ 
/* 1662 */       if (bean.getChildWorkflowCount() > 1L) {
/* 1663 */         String uniteValues = VMUtil.uniteChildWorkflowOutValues(outparameters[i].contextVarName, workflow.getWorkflowContext(), paramters.get(outparameters[i].name), taskId, String.valueOf(childWorkflowId));
/*      */ 
/* 1667 */         workflow.getWorkflowContext().set(outparameters[i].contextVarName, uniteValues);
/*      */       } else {
/* 1669 */         workflow.getWorkflowContext().set(outparameters[i].contextVarName, paramters.get(outparameters[i].name));
/*      */       }
/*      */     }
/*      */ 
/* 1673 */     FlowFactory.save(workflow);
/* 1674 */     boolean isFinished = TaskWorkflowImpl.finish(taskId, PropertiesUtil.getSystemUserId(), childWorkflowState);
/* 1675 */     if (isFinished == true)
/* 1676 */       addScheduleWorkflow(workflow);
/* 1677 */     return isFinished;
/*      */   }
/*      */ 
/*      */   public void resumExceptionWorkflow(String workflowId) throws RemoteException, Exception
/*      */   {
/* 1682 */     Workflow workflow = FlowFactory.reload(workflowId, true);
/* 1683 */     workflow.updateState(2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.resumExceptionWorkflow_recoverFromException"));
/* 1684 */     workflow.setErrorMessage("");
/* 1685 */     TaskTimerImpl.updateTimerRecordStateByWorkflowId(workflowId, 2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.resumExceptionWorkflow_recoverFromException"));
/* 1686 */     FlowFactory.save(workflow);
/* 1687 */     addScheduleWorkflow(workflow);
/* 1688 */     log.debug("Process：" + workflowId + "Normal");
/*      */   }
/*      */ 
/*      */   public int resumeExceptionWorkflows(String[] workflowIds)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1694 */     int count = 0;
/* 1695 */     if ((null != workflowIds) && (workflowIds.length > 0)) {
/* 1696 */       for (int i = 0; i < workflowIds.length; ++i) {
/* 1697 */         Workflow workflow = FlowFactory.reload(workflowIds[i], true);
/* 1698 */         if (workflow.getState() == 99) {
/* 1699 */           workflow.updateState(2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.resumExceptionWorkflow_recoverFromException"));
/*      */ 
/* 1703 */           workflow.setErrorMessage("");
/* 1704 */           TaskTimerImpl.updateTimerRecordStateByWorkflowId(workflowIds[i], 2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.resumExceptionWorkflow_recoverFromException"));
/*      */ 
/* 1710 */           FlowFactory.save(workflow);
/* 1711 */           addScheduleWorkflow(workflow);
/* 1712 */           log.debug("Process：" + workflowIds[i] + "Normal");
/*      */ 
/* 1714 */           ++count;
/*      */         }
/*      */       }
/*      */     }
/* 1718 */     return count;
/*      */   }
/*      */ 
/*      */   public boolean jumpToTask(String taskId, long taskTemplateId, Map vars, String staffId, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1731 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1733 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1736 */       taskBean = null;
/*      */     }
/* 1738 */     if (taskBean == null)
/*      */     {
/* 1740 */       IBOVmTaskTSValue ttb = FlowFactory.getTaskTransBean(taskId);
/* 1741 */       if (ttb == null) {
/* 1742 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */       }
/*      */ 
/* 1745 */       taskId = ttb.getParentTaskId();
/* 1746 */       IBOVmTaskTSValue parentBean = FlowFactory.getTaskTransBean(taskId);
/* 1747 */       while (parentBean != null) {
/* 1748 */         taskId = parentBean.getParentTaskId();
/* 1749 */         parentBean = FlowFactory.getTaskTransBean(taskId);
/*      */       }
/* 1751 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/* 1753 */     if (taskBean.getTaskTemplateId() == taskTemplateId) {
/* 1754 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.jumpToTask_notJumpToSelf"));
/*      */     }
/* 1756 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1757 */     Task task = workflow.getTask(taskId);
/* 1758 */     if (task == null) {
/* 1759 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1761 */     if ((workflow.getState() != 2) && (workflow.getState() != 5) && (workflow.getState() != 99))
/*      */     {
/* 1764 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.jumpToTask_noJump"));
/*      */     }
/*      */ 
/* 1767 */     Task[] tasks = workflow.getCurrentTasks();
/* 1768 */     if (tasks.length > 1) {
/* 1769 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.jumpToTask_noBackParell"));
/*      */     }
/*      */ 
/* 1772 */     setWorkflowVars(workflow, (HashMap)vars);
/* 1773 */     workflow.jumpToTask(task, taskTemplateId, staffId, notes);
/* 1774 */     dealTransTaskDown(task.getTaskId(), workflow.getWorkflowId(), 6);
/* 1775 */     addScheduleWorkflow(workflow);
/* 1776 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String taskId, long taskTemplateId, Map vars, String staffId, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1788 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1790 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1793 */       taskBean = null;
/*      */     }
/* 1795 */     if (taskBean == null)
/*      */     {
/* 1797 */       IBOVmTaskTSValue ttb = FlowFactory.getTaskTransBean(taskId);
/* 1798 */       if (ttb == null) {
/* 1799 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */       }
/*      */ 
/* 1802 */       taskId = ttb.getParentTaskId();
/* 1803 */       IBOVmTaskTSValue parentBean = FlowFactory.getTaskTransBean(taskId);
/* 1804 */       while (parentBean != null) {
/* 1805 */         taskId = parentBean.getParentTaskId();
/* 1806 */         parentBean = FlowFactory.getTaskTransBean(taskId);
/*      */       }
/* 1808 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/* 1810 */     if (taskBean.getTaskTemplateId() == taskTemplateId) {
/* 1811 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_notBackToSelf"));
/*      */     }
/* 1813 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1814 */     Task task = workflow.getTask(taskId);
/* 1815 */     if (task == null) {
/* 1816 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1818 */     if ((workflow.getState() != 2) && (workflow.getState() != 5) && (workflow.getState() != 99))
/*      */     {
/* 1821 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.jumpToTask_noBack"));
/*      */     }
/*      */ 
/* 1829 */     setWorkflowVars(workflow, (HashMap)vars);
/*      */ 
/* 1838 */     workflow.goBackTask(task, taskTemplateId, staffId, notes);
/* 1839 */     dealTransTaskDown(task.getTaskId(), workflow.getWorkflowId(), 6);
/* 1840 */     addScheduleWorkflow(workflow);
/* 1841 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String taskId, Map vars, String staffId, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1853 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1855 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1858 */       taskBean = null;
/*      */     }
/* 1860 */     if (taskBean == null)
/*      */     {
/* 1862 */       IBOVmTaskTSValue ttb = FlowFactory.getTaskTransBean(taskId);
/* 1863 */       if (ttb == null) {
/* 1864 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */       }
/*      */ 
/* 1867 */       taskId = ttb.getParentTaskId();
/* 1868 */       IBOVmTaskTSValue parentBean = FlowFactory.getTaskTransBean(taskId);
/* 1869 */       while (parentBean != null) {
/* 1870 */         taskId = parentBean.getParentTaskId();
/* 1871 */         parentBean = FlowFactory.getTaskTransBean(taskId);
/*      */       }
/* 1873 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/* 1875 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1876 */     Task task = workflow.getTask(taskId);
/* 1877 */     if (task == null) {
/* 1878 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1880 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 1882 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.jumpToTask_noBack"));
/*      */     }
/*      */ 
/* 1891 */     setWorkflowVars(workflow, (HashMap)vars);
/*      */ 
/* 1900 */     workflow.goBackTask(task, staffId, notes);
/* 1901 */     dealTransTaskDown(task.getTaskId(), workflow.getWorkflowId(), 6);
/* 1902 */     addScheduleWorkflow(workflow);
/* 1903 */     return true;
/*      */   }
/*      */ 
/*      */   public String reAuthorizeTask(String taskId, String authorizeStaffId, String authorizeStationId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1918 */     IBOVmTaskValue taskBean = null;
/*      */     try {
/* 1920 */       taskBean = FlowFactory.getTaskBean(taskId);
/*      */     }
/*      */     catch (VMException e) {
/* 1923 */       taskBean = null;
/*      */     }
/* 1925 */     if (taskBean == null) {
/* 1926 */       return reAuthorizeTaskTrans(taskId, authorizeStaffId, authorizeStationId, staffId);
/*      */     }
/*      */ 
/* 1929 */     Workflow workflow = getWorkflowForSchedule(taskBean.getWorkflowId());
/* 1930 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 1932 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.reAuthorizeTask_noAuthor"));
/*      */     }
/*      */ 
/* 1935 */     TaskUser task = (TaskUser)workflow.getTask(taskId);
/* 1936 */     if (task == null) {
/* 1937 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 1939 */     if ((task.getState() != 9) && (task.getState() != 5))
/*      */     {
/* 1941 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + task.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.reAuthorizeTask_noAuthor"));
/*      */     }
/*      */ 
/* 1945 */     String newTaskId = task.reAuthorize(authorizeStaffId, authorizeStationId, staffId);
/* 1946 */     FlowFactory.save(workflow);
/*      */ 
/* 1948 */     return newTaskId;
/*      */   }
/*      */ 
/*      */   public Map getWorkflowVars(String workflowId) throws RemoteException, Exception
/*      */   {
/* 1953 */     Workflow workflow = getWorkflow(workflowId);
/* 1954 */     return workflow.getWorkflowContext().getParameters();
/*      */   }
/*      */ 
/*      */   public Map getChildWorkflowReturnVar(String workflowId, String aVarName)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1960 */     Workflow workflow = getWorkflow(workflowId);
/* 1961 */     return VMUtil.getChildWorkflowReturnVar(workflow.getWorkflowContext(), aVarName);
/*      */   }
/*      */ 
/*      */   public void setWorkflowVars(String workflowId, HashMap aVars) throws RemoteException, Exception {
/* 1965 */     if (aVars == null) {
/* 1966 */       return;
/*      */     }
/* 1968 */     Workflow workflow = getWorkflow(workflowId);
/* 1969 */     setWorkflowVars(workflow, aVars);
/*      */   }
/*      */ 
/*      */   public void setWorkflowVars(Workflow workflow, HashMap aVars) throws RemoteException, Exception {
/* 1973 */     if (aVars == null)
/* 1974 */       return;
/* 1975 */     for (Iterator it = aVars.entrySet().iterator(); it.hasNext(); ) {
/* 1976 */       Map.Entry e = (Map.Entry)it.next();
/* 1977 */       String param = e.getKey().toString();
/* 1978 */       ParameterDefine p = workflow.getWorkflowTemplate().getVars(param);
/* 1979 */       if (p != null)
/* 1980 */         workflow.getWorkflowContext().set(param, e.getValue());
/*      */       else
/* 1982 */         log.warn("Process template" + workflow.getTemplateTag() + "Variable is not defined:" + param);
/*      */     }
/* 1984 */     FlowFactory.save(workflow);
/*      */   }
/*      */ 
/*      */   public String toSvg(String workflowId) throws RemoteException, Exception {
/* 1988 */     Workflow workflow = getWorkflow(workflowId);
/* 1989 */     return VMUtil.toSvg(workflow);
/*      */   }
/*      */ 
/*      */   public String toDojo(String workflowId, String imagePath) throws RemoteException, Exception {
/* 1993 */     Workflow workflow = getWorkflow(workflowId);
/* 1994 */     return VMUtilDojo.toDojo(workflow, imagePath);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] queryTaskByWorkflowId(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2004 */     HashMap p = new HashMap();
/* 2005 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/* 2006 */     p.put("aWorkflowId", workflowId);
/* 2007 */     String cond = " WORKFLOW_ID = :aWorkflowId order by create_date,task_id ";
/* 2008 */     return getTaskViewDao().getTaskInfos(queueID, cond, p, -1, -1);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] queryTaskHisByWorkflowId(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2014 */     HashMap p = new HashMap();
/* 2015 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/* 2016 */     p.put("aWorkflowId", workflowId);
/* 2017 */     String cond = " WORKFLOW_ID = :aWorkflowId order by create_date,task_id ";
/* 2018 */     return getTaskViewDao().getTaskInfosHis(queueID, cond, p, -1, -1);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] queryTaskHisByWorkflowId(String workflowId, String acctPeriod)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2024 */     HashMap p = new HashMap();
/* 2025 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/* 2026 */     p.put("aWorkflowId", workflowId);
/* 2027 */     String cond = " WORKFLOW_ID = :aWorkflowId order by create_date,task_id ";
/* 2028 */     return getTaskViewDao().getTaskInfosHis(queueID, acctPeriod, cond, p, -1, -1);
/*      */   }
/*      */ 
/*      */   public IBOVmWFValue[] getWorkflowBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2035 */     if (parameter == null)
/* 2036 */       parameter = new HashMap();
/* 2037 */     return getWorkflowDao().getWorkflowBeans(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowHisBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2050 */     if (parameter == null)
/* 2051 */       parameter = new HashMap();
/* 2052 */     return getTaskViewDao().getWorkflowInfoHis(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public TaskInfo getRootBean(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2061 */     TaskInfo taskInfo = getTaskInfo(String.valueOf(taskId));
/* 2062 */     if (taskInfo == null) {
/* 2063 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getRootBean_getTaskByID") + taskId);
/*      */     }
/* 2065 */     TaskInfo rootTaskView = null;
/*      */ 
/* 2067 */     if (taskInfo.getWorkflowKind() == 1) {
/* 2068 */       rootTaskView = getRootByChild(taskInfo.getWorkflowParentTaskId());
/*      */     }
/* 2071 */     else if (taskInfo.getWorkflowKind() == 2) {
/* 2072 */       rootTaskView = getRootByExceptionWorkflow(taskInfo.getWorkflowParentTaskId());
/*      */     }
/* 2074 */     if (rootTaskView == null) {
/* 2075 */       rootTaskView = taskInfo;
/*      */     }
/* 2077 */     return rootTaskView;
/*      */   }
/*      */ 
/*      */   public TaskInfo getRootByChild(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2088 */     TaskInfo taskInfo = getTaskInfo(String.valueOf(taskId));
/* 2089 */     if (taskInfo == null) {
/* 2090 */       return null;
/*      */     }
/* 2092 */     TaskInfo tmp = null;
/* 2093 */     if (taskInfo.getWorkflowKind() == 1) {
/* 2094 */       if ((taskInfo.getWorkflowParentTaskId() == null) || (taskInfo.getWorkflowParentTaskId().length() == 0) || ("-1".equals(taskInfo.getWorkflowParentTaskId()))) {
/* 2095 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_childProcess") + taskInfo.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getRootBean_noFatherProcessID"));
/*      */       }
/*      */ 
/* 2098 */       tmp = getRootByChild(taskInfo.getWorkflowParentTaskId());
/*      */     }
/* 2100 */     if (tmp == null) {
/* 2101 */       tmp = taskInfo;
/*      */     }
/* 2103 */     return tmp;
/*      */   }
/*      */ 
/*      */   public TaskInfo getRootByExceptionWorkflow(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2113 */     String queueID = IDAssembleUtil.unwrapPrefix(workflowId);
/* 2114 */     String cond = " WORKFLOW_ID = :WORKFLOW_ID";
/* 2115 */     HashMap map = new HashMap();
/* 2116 */     map.put("WORKFLOW_ID", workflowId);
/* 2117 */     TaskInfo[] taskInfo = getTaskInfos(queueID, cond, map, -1, -1);
/* 2118 */     if ((taskInfo == null) || (taskInfo.length == 0)) {
/* 2119 */       return null;
/*      */     }
/* 2121 */     TaskInfo info = null;
/* 2122 */     if (taskInfo[0].getWorkflowKind() == 2) {
/* 2123 */       if ((taskInfo[0].getWorkflowParentTaskId() == null) || (taskInfo[0].getWorkflowParentTaskId().length() == 0) || ("-1".equals(taskInfo[0].getWorkflowParentTaskId()))) {
/* 2124 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getRootByExceptionWorkflow_unnormalProcess") + taskInfo[0].getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getRootByExceptionWorkflow_unRecordProcessID"));
/*      */       }
/*      */ 
/* 2127 */       info = getRootByExceptionWorkflow(taskInfo[0].getWorkflowParentTaskId());
/*      */     }
/* 2129 */     if (info == null)
/*      */     {
/* 2131 */       for (int i = 0; i < taskInfo.length; ++i) {
/* 2132 */         if ((taskInfo[i].getState() != 4) && (taskInfo[i].getState() != 1))
/*      */           continue;
/* 2134 */         info = taskInfo[i];
/* 2135 */         break;
/*      */       }
/*      */ 
/* 2138 */       if (info == null)
/* 2139 */         info = taskInfo[0];
/*      */     }
/* 2141 */     return info;
/*      */   }
/*      */ 
/*      */   public int getWorkflowCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2148 */     if (parameter == null) parameter = new HashMap();
/* 2149 */     return getTaskViewDao().getWorkflowCount(queueID, condition, parameter);
/*      */   }
/*      */ 
/*      */   public int getWorkflowHisCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2160 */     if (parameter == null) parameter = new HashMap();
/* 2161 */     return getTaskViewDao().getWorkflowHisCount(queueID, condition, parameter);
/*      */   }
/*      */ 
/*      */   public int getWorkflowHisCount(String queueID, String acctPreiod, String condition, HashMap parameter) throws RemoteException, Exception {
/* 2165 */     if (parameter == null) parameter = new HashMap();
/* 2166 */     return getTaskViewDao().getWorkflowHisCount(queueID, acctPreiod, condition, parameter);
/*      */   }
/*      */ 
/*      */   public Workflow getWorkflow(String workflowId) throws RemoteException, Exception
/*      */   {
/* 2171 */     return FlowFactory.reload(workflowId);
/*      */   }
/*      */ 
/*      */   public IBOVmWFValue getWorkflowBean(String workflowId) throws RemoteException, Exception {
/* 2175 */     return getWorkflowDao().getVmWorkflowBeanbyId(workflowId);
/*      */   }
/*      */ 
/*      */   public String getWorkflowIdByTaskId(String taskId) throws RemoteException, Exception {
/* 2179 */     IBOVmTaskValue bean = FlowFactory.getTaskBean(taskId);
/* 2180 */     return bean.getWorkflowId();
/*      */   }
/*      */ 
/*      */   public Workflow getWorkflowForSchedule(String workflowId) throws RemoteException, Exception {
/* 2184 */     return FlowFactory.reload(workflowId, true);
/*      */   }
/*      */ 
/*      */   public void save(Workflow workflow) throws RemoteException, Exception {
/* 2188 */     FlowFactory.save(workflow);
/*      */   }
/*      */ 
/*      */   public List executeWorkflow(Workflow workflow)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2197 */     if (workflow == null)
/* 2198 */       throw new Exception("workflow is null,can't schedule!");
/*      */     try
/*      */     {
/* 2201 */       List finishTaskList = (List)workflow.executeWorkflow();
/* 2202 */       if (log.isDebugEnabled()) {
/* 2203 */         log.debug(" scheduling Successful  release process:" + workflow.getWorkflowId());
/*      */       }
/* 2205 */       return finishTaskList;
/*      */     } catch (Exception ex) {
/* 2207 */       log.error(" Scheduling failed the release process:" + workflow.getWorkflowId(), ex);
/* 2208 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void excuteFinishTask(Workflow workflow, List finishTaskList)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2220 */     if (workflow == null)
/* 2221 */       throw new Exception("workflow is null,can't schedule!");
/* 2222 */     workflow.excuteFinishTask(finishTaskList);
/*      */   }
/*      */ 
/*      */   public void endWorkflowSchedule(Workflow workflow)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2233 */     if (workflow == null)
/* 2234 */       throw new Exception("workflow is null,can't schedule!");
/* 2235 */     if (workflow.getState() == 3) {
/* 2236 */       deleteVMSchedule(workflow.getWorkflowId());
/* 2237 */       workflow.monitor(PropertiesUtil.getSystemUserId(), null, 12);
/*      */     } else {
/* 2239 */       removeScheduleWorkflow(workflow.getWorkflowId());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void workflowExceptionProcess(String workflowId, Workflow workflow, Throwable ex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2255 */     if (workflow != null) {
/* 2256 */       workflow.monitor(PropertiesUtil.getSystemUserId(), ex, 13);
/*      */     }
/* 2258 */     IVmWorkflowDAO workflowDao = getWorkflowDao();
/* 2259 */     if ((workflow != null) && (workflow.isNeedRetry()))
/*      */     {
/* 2261 */       suspendScheduleWorkflow(workflowId);
/* 2262 */     } else if ((workflow != null) && (((workflow.getState() == 99) || (workflow.getState() == 98) || (workflow.getState() == 1))))
/*      */     {
/* 2266 */       removeScheduleWorkflow(workflowId);
/* 2267 */     } else if ((workflow != null) && (workflow.getState() == 3)) {
/* 2268 */       deleteVMSchedule(workflowId);
/* 2269 */     } else if (workflow != null) {
/* 2270 */       addScheduleWorkflow(workflow);
/*      */     } else {
/* 2272 */       IBOVmWFValue wfBean = workflowDao.getVmWorkflowBeanbyId(workflowId);
/* 2273 */       if ((wfBean == null) || (wfBean.isNew())) {
/* 2274 */         deleteVMSchedule(workflowId);
/*      */       } else {
/* 2276 */         wfBean.setState(99);
/* 2277 */         wfBean.setStateDate(TimeUtil.getSysTime());
/* 2278 */         wfBean.setErrorMessage(VMUtil.getErrorMessageFromException(ex));
/* 2279 */         workflowDao.saveVmWorkflowInstacne(wfBean);
/* 2280 */         removeScheduleWorkflow(workflowId);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void taskExceptionProcess(String workflowId, Workflow workflow, Throwable ex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2293 */     if (workflow == null) {
/* 2294 */       throw new Exception("workflow is null,can't schedule!");
/*      */     }
/* 2296 */     workflow.fireExceptionIndependence(PropertiesUtil.getSystemUserId(), VMUtil.getErrorMessageFromException(ex));
/*      */   }
/*      */ 
/*      */   public boolean busiExceptionProcess(String workflowId, Workflow workflow, ComframeBusiException ex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2309 */     return workflow.busiExceptionProcess(ex);
/*      */   }
/*      */ 
/*      */   public void executeExceptionWorkflow(Workflow workflow)
/*      */     throws Exception, RemoteException
/*      */   {
/* 2319 */     if (workflow == null)
/* 2320 */       throw new Exception("workflow is null !");
/* 2321 */     workflow.updateState(97, ComframeLocaleFactory.getResource("com.ai.comframe.exception.ScanWorkflowForExceptionHandle.execute_exceptionDealState"));
/*      */ 
/* 2323 */     save(workflow);
/* 2324 */     IComframeExceptionHandleSV handler = (IComframeExceptionHandleSV)ServiceFactory.getService(IComframeExceptionHandleSV.class);
/*      */ 
/* 2326 */     handler.exceptionHandle(workflow.getWorkflowId());
/* 2327 */     removeScheduleWorkflow(workflow.getWorkflowId());
/*      */   }
/*      */ 
/*      */   public void executeExceptionWfError(Workflow workflow, Exception ex) throws RemoteException, Exception
/*      */   {
/* 2332 */     if (workflow == null)
/* 2333 */       throw new Exception("workflow is null !");
/* 2334 */     workflow.updateState(5, ComframeLocaleFactory.getResource("com.ai.comframe.exception.ScanWorkflowForExceptionHandle.execute_exceptionDealAutoFailed") + ":[" + workflow.getWorkflowId() + "]" + ex.getMessage());
/*      */ 
/* 2337 */     save(workflow);
/* 2338 */     removeScheduleWorkflow(workflow.getWorkflowId());
/*      */   }
/*      */ 
/*      */   public void addScheduleWorkflow(Workflow workflow)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2347 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 2348 */     IBOVmScheduleValue schedule = scheduleSV.getVmScheduleByWorkflowId(workflow.getWorkflowId());
/* 2349 */     schedule.setStateDate(TimeUtil.getSysTime());
/* 2350 */     schedule.setState(String.valueOf('W'));
/* 2351 */     scheduleSV.saveVmSchedule(schedule);
/*      */   }
/*      */ 
/*      */   public void deleteVMSchedule(String workflowId) throws RemoteException, Exception {
/* 2355 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 2356 */     IBOVmScheduleValue schedule = scheduleSV.getVmScheduleByWorkflowId(workflowId);
/* 2357 */     schedule.delete();
/* 2358 */     scheduleSV.saveVmSchedule(schedule);
/*      */   }
/*      */ 
/*      */   public void removeScheduleWorkflow(String workflowId) throws RemoteException, Exception {
/* 2362 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 2363 */     IBOVmScheduleValue schedule = scheduleSV.getVmScheduleByWorkflowId(workflowId);
/* 2364 */     schedule.setStateDate(TimeUtil.getSysTime());
/* 2365 */     schedule.setState(String.valueOf('F'));
/* 2366 */     scheduleSV.saveVmSchedule(schedule);
/*      */   }
/*      */ 
/*      */   private void suspendScheduleWorkflow(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2372 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 2373 */     IBOVmScheduleValue schedule = scheduleSV.getVmScheduleByWorkflowId(workflowId);
/* 2374 */     schedule.setStateDate(TimeUtil.getSysTime());
/* 2375 */     schedule.setState(String.valueOf('T'));
/* 2376 */     scheduleSV.saveVmSchedule(schedule);
/*      */   }
/*      */ 
/*      */   public IBOVmTaskTSValue[] getTaskTransInfoByParentTaskId(String parentTaskId, String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2387 */     return getTaskDao().getVmTaskTransBeans(workflowId, parentTaskId);
/*      */   }
/*      */ 
/*      */   private boolean printTaskTrans(String taskId, String staffId, Map aVars, boolean autoPrint) throws RemoteException, Exception {
/* 2391 */     IBOVmTaskTSValue bean = FlowFactory.getTaskTransBean(taskId);
/* 2392 */     if (bean == null) {
/* 2393 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printTaskTrans_task"));
/*      */     }
/* 2395 */     if (bean.getState() != 9) {
/* 2396 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + bean.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printUserTask_cannotPrint"));
/*      */     }
/*      */ 
/* 2399 */     Workflow workflow = getWorkflowForSchedule(bean.getWorkflowId());
/* 2400 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 2402 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printUserTask_cannotPrint"));
/*      */     }
/*      */ 
/* 2406 */     if (aVars != null) {
/* 2407 */       WorkflowContext context = workflow.getWorkflowContext();
/* 2408 */       Iterator it = aVars.entrySet().iterator();
/* 2409 */       while (it.hasNext()) {
/* 2410 */         Map.Entry e = (Map.Entry)it.next();
/* 2411 */         ParameterDefine p = workflow.getWorkflowTemplate().getVars(e.getKey().toString());
/*      */ 
/* 2414 */         if (p != null) {
/* 2415 */           context.set(p.name, e.getValue());
/*      */         }
/*      */         else {
/* 2418 */           log.warn("Please note that in the process" + workflow.getWorkflowTemplate().getTaskTag() + "Process variable is not defined：" + e.getKey());
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2424 */     String taskType = TaskConfig.getInstance().getBasalType(bean.getTaskType());
/* 2425 */     if (taskType.equalsIgnoreCase("sign")) {
/* 2426 */       bean.setState(5);
/* 2427 */       if (!autoPrint) {
/* 2428 */         bean.setTaskStaffId(staffId);
/*      */       }
/* 2430 */       bean.setFinishStaffId(staffId);
/* 2431 */       bean.setFinishDate(TimeUtil.getSysTime());
/* 2432 */       FlowFactory.saveTaskTrans(bean);
/* 2433 */       return true;
/*      */     }
/*      */ 
/* 2436 */     BOVmTaskTSBean aBean = (BOVmTaskTSBean)bean;
/* 2437 */     Task tt = FlowFactory.createTask(workflow, aBean);
/* 2438 */     TaskBaseImpl.executeDealInner(tt, workflow.getWorkflowContext(), ((TaskUserTemplate)tt.getTaskTemplate()).getPrintDealBean());
/*      */ 
/* 2441 */     boolean isWaitUser = true;
/* 2442 */     Object isWait = TaskBaseImpl.getContextValue(tt, workflow.getWorkflowContext(), "$IS_WAIT_USER");
/*      */ 
/* 2444 */     if ((isWait != null) && (isWait instanceof Boolean) && (!((Boolean)isWait).booleanValue())) {
/* 2445 */       isWaitUser = false;
/* 2446 */       bean.setState(3);
/* 2447 */       bean.setIsCurrentTask("N");
/* 2448 */       workflow.getWorkflowContext().remvoe("$IS_WAIT_USER");
/*      */     } else {
/* 2450 */       bean.setState(5);
/* 2451 */       if (!autoPrint) {
/* 2452 */         bean.setTaskStaffId(staffId);
/*      */       }
/*      */     }
/* 2455 */     bean.setFinishStaffId(staffId);
/* 2456 */     bean.setFinishDate(TimeUtil.getSysTime());
/* 2457 */     FlowFactory.saveTaskTrans(bean);
/* 2458 */     FlowFactory.save(workflow);
/*      */ 
/* 2461 */     if (!isWaitUser) {
/* 2462 */       Timestamp current = TimeUtil.getSysTime();
/*      */ 
/* 2464 */       String parentTaskId = bean.getParentTaskId();
/* 2465 */       IBOVmTaskTSValue parentBean = FlowFactory.getTaskTransBean(parentTaskId);
/* 2466 */       while (parentBean != null) {
/* 2467 */         if (!parentBean.getWorkflowId().equals(workflow.getWorkflowId())) {
/*      */           break;
/*      */         }
/* 2470 */         parentTaskId = parentBean.getParentTaskId();
/* 2471 */         parentBean.setState(3);
/* 2472 */         parentBean.setFinishStaffId(staffId);
/* 2473 */         parentBean.setFinishDate(current);
/* 2474 */         parentBean.setIsCurrentTask("N");
/* 2475 */         FlowFactory.saveTaskTrans(parentBean);
/*      */ 
/* 2477 */         parentBean = FlowFactory.getTaskTransBean(parentTaskId);
/*      */       }
/*      */ 
/* 2480 */       boolean isAllFinished = true;
/* 2481 */       int taskState = 10;
/*      */ 
/* 2491 */       if (isAllFinished == true) {
/* 2492 */         Task task = workflow.getTask(parentTaskId);
/* 2493 */         if (task == null) {
/* 2494 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + bean.getParentTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */         }
/*      */ 
/* 2500 */         finishParentTask(task, workflow, staffId, taskState);
/*      */       }
/*      */     }
/*      */ 
/* 2504 */     return true;
/*      */   }
/*      */ 
/*      */   private void finishParentTask(Task task, Workflow workflow, String staffId, int taskState) throws Exception
/*      */   {
/* 2509 */     IBOVmTaskValue taskBean = getTaskDao().getVmTaskbeanById(task.getTaskId(), new int[] { taskState });
/*      */ 
/* 2511 */     if (taskBean == null) {
/* 2512 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + task.getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */     }
/* 2514 */     Timestamp time = TimeUtil.getSysTime();
/* 2515 */     taskBean.setFinishStaffId(staffId);
/* 2516 */     taskBean.setExeFinishDate(taskBean.getStateDate());
/* 2517 */     taskBean.setFinishDate(time);
/* 2518 */     taskBean.setState(3);
/* 2519 */     taskBean.setStateDate(time);
/* 2520 */     taskBean.setDecisionResult("");
/* 2521 */     taskBean.setErrorMessage("");
/* 2522 */     getTaskDao().saveVmtaskInstacne(taskBean);
/*      */ 
/* 2524 */     IBOVmWFValue wfBean = getWorkflowDao().getVmWorkflowBeanbyId(workflow.getWorkflowId());
/* 2525 */     wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 2526 */     getWorkflowDao().saveVmWorkflowInstacne(wfBean);
/* 2527 */     addScheduleWorkflow(workflow);
/*      */   }
/*      */ 
/*      */   private boolean finishTaskTrans(String taskId, String staffId, String result, Map aVars, String reason) throws Exception
/*      */   {
/* 2532 */     IBOVmTaskTSValue bean = FlowFactory.getTaskTransBean(taskId);
/* 2533 */     if (bean == null) {
/* 2534 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.printTaskTrans_task"));
/*      */     }
/* 2536 */     if ((bean.getState() != 5) && (bean.getState() != 9))
/*      */     {
/* 2538 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + bean.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_cannotReturn"));
/*      */     }
/*      */ 
/* 2541 */     Workflow workflow = getWorkflowForSchedule(bean.getWorkflowId());
/* 2542 */     if ((workflow.getState() != 2) && (workflow.getState() != 5))
/*      */     {
/* 2544 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + workflow.getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + workflow.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_cannotReturn"));
/*      */     }
/*      */ 
/* 2547 */     Timestamp current = TimeUtil.getSysTime();
/* 2548 */     String workflowId = workflow.getWorkflowId();
/*      */ 
/* 2550 */     if (aVars != null) {
/* 2551 */       WorkflowContext context = workflow.getWorkflowContext();
/* 2552 */       Iterator it = aVars.entrySet().iterator();
/* 2553 */       while (it.hasNext()) {
/* 2554 */         Map.Entry e = (Map.Entry)it.next();
/* 2555 */         ParameterDefine p = workflow.getWorkflowTemplate().getVars(e.getKey().toString());
/*      */ 
/* 2557 */         if (p != null) {
/* 2558 */           context.set(p.name, e.getValue());
/*      */         }
/*      */         else {
/* 2561 */           log.warn("Please note that in the process" + workflow.getWorkflowTemplate().getTaskTag() + "Process variable is not defined：" + e.getKey());
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2567 */     bean.setDecisionResult(result);
/* 2568 */     bean.setErrorMessage(reason);
/* 2569 */     bean.setState(3);
/* 2570 */     bean.setFinishStaffId(staffId);
/* 2571 */     bean.setFinishDate(current);
/* 2572 */     bean.setStateDate(current);
/* 2573 */     bean.setIsCurrentTask("N");
/* 2574 */     FlowFactory.saveTaskTrans(bean);
/*      */ 
/* 2576 */     String parentTaskId = bean.getParentTaskId();
/* 2577 */     IBOVmTaskTSValue parentBean = FlowFactory.getTaskTransBean(parentTaskId);
/* 2578 */     while (parentBean != null) {
/* 2579 */       if (!parentBean.getWorkflowId().equals(workflow.getWorkflowId())) {
/*      */         break;
/*      */       }
/* 2582 */       parentTaskId = parentBean.getParentTaskId();
/*      */ 
/* 2584 */       parentBean.setDecisionResult(result);
/* 2585 */       parentBean.setErrorMessage(reason);
/* 2586 */       parentBean.setState(3);
/* 2587 */       parentBean.setFinishStaffId(staffId);
/* 2588 */       parentBean.setFinishDate(current);
/* 2589 */       parentBean.setIsCurrentTask("N");
/* 2590 */       FlowFactory.saveTaskTrans(parentBean);
/*      */ 
/* 2592 */       parentBean = FlowFactory.getTaskTransBean(parentTaskId);
/*      */     }
/*      */ 
/* 2595 */     String taskType = TaskConfig.getInstance().getBasalType(bean.getTaskType());
/*      */ 
/* 2597 */     if (taskType.equalsIgnoreCase("sign")) {
/* 2598 */       boolean isAllFinished = true;
/* 2599 */       IBOVmTaskTSValue[] transBeans = getTaskTransInfoByParentTaskId(parentTaskId, workflowId);
/* 2600 */       for (int i = 0; i < transBeans.length; ++i)
/*      */       {
/* 2602 */         if (transBeans[i].getTaskId().equals(bean.getTaskId())) {
/*      */           continue;
/*      */         }
/* 2605 */         if (transBeans[i].getState() != 3) {
/* 2606 */           isAllFinished = false;
/* 2607 */           break;
/*      */         }
/*      */       }
/*      */ 
/* 2611 */       if (isAllFinished == true) {
/* 2612 */         TaskSign task = (TaskSign)workflow.getTask(parentTaskId);
/* 2613 */         if (task == null)
/*      */         {
/* 2615 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + bean.getParentTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */         }
/* 2617 */         task.updateState(5, "");
/* 2618 */         FlowFactory.save((IBOVmTaskValue)task.getDataBean());
/*      */ 
/* 2620 */         task.finish(result, staffId, reason, workflow.getWorkflowContext());
/*      */ 
/* 2622 */         TaskTimerImpl.deleteTimerRecord(parentTaskId);
/* 2623 */         FlowFactory.save(workflow);
/* 2624 */         addScheduleWorkflow(workflow);
/*      */       }
/*      */       else {
/* 2627 */         workflow.realseUserTaskCount();
/* 2628 */         FlowFactory.save(workflow);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2633 */       TaskUser task = (TaskUser)workflow.getTask(parentTaskId);
/* 2634 */       if (task == null)
/*      */       {
/* 2636 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + bean.getParentTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*      */       }
/* 2638 */       task.updateState(5, "");
/* 2639 */       FlowFactory.save((IBOVmTaskValue)task.getDataBean());
/* 2640 */       task.finish(result, staffId, reason, workflow.getWorkflowContext());
/*      */ 
/* 2642 */       TaskTimerImpl.deleteTimerRecord(parentTaskId);
/* 2643 */       FlowFactory.save(workflow);
/* 2644 */       addScheduleWorkflow(workflow);
/*      */     }
/* 2646 */     return true;
/*      */   }
/*      */ 
/*      */   private void lockTaskTrans(String taskId, String staffId) throws Exception {
/* 2650 */     IBOVmTaskTSValue task = FlowFactory.getTaskTransBean(taskId);
/* 2651 */     if (task == null) {
/* 2652 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_transTask"));
/*      */     }
/* 2654 */     int oldState = task.getState();
/* 2655 */     if ((oldState != 5) && (oldState != 9) && (oldState != 2))
/*      */     {
/* 2657 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_noExcute"));
/* 2658 */     }if (task.getLockStaffId() == null) {
/* 2659 */       task.setLockStaffId(staffId);
/* 2660 */       task.setLockDate(TimeUtil.getSysTime());
/* 2661 */       FlowFactory.saveTaskTrans(task);
/*      */     } else {
/* 2663 */       if ((task.getLockStaffId() == null) || (task.getLockStaffId().equalsIgnoreCase(staffId)))
/*      */         return;
/* 2665 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_taskAlready") + task.getLockStaffId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.lockTask_lock"));
/*      */     }
/*      */   }
/*      */ 
/*      */   private void realseTaskTrans(String taskId) throws Exception {
/* 2670 */     IBOVmTaskTSValue task = FlowFactory.getTaskTransBean(taskId);
/* 2671 */     if (task == null) {
/* 2672 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_transTask"));
/*      */     }
/* 2674 */     task.setLockStaffId(null);
/* 2675 */     task.setLockDate(null);
/* 2676 */     FlowFactory.saveTaskTrans(task);
/*      */   }
/*      */ 
/*      */   private String reAuthorizeTaskTrans(String taskId, String authorizeStaffId, String authorizeStationId, String staffId) throws Exception
/*      */   {
/* 2681 */     IBOVmTaskTSValue task = FlowFactory.getTaskTransBean(taskId);
/* 2682 */     if (task == null) {
/* 2683 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_noFindID") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.claimTask_transTask"));
/*      */     }
/*      */ 
/* 2686 */     if ((task.getState() != 9) && (task.getState() != 5)) {
/* 2687 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.finishUserTask_stateIs") + task.getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.reAuthorizeTask_noAuthor"));
/*      */     }
/*      */ 
/* 2691 */     Timestamp current = TimeUtil.getSysTime();
/*      */ 
/* 2693 */     IBOVmTaskTSValue transBean = new BOVmTaskTSBean();
/* 2694 */     transBean.copy(task);
/* 2695 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 2696 */     String newTaskId = taskDAO.getNewTaskTransId(IDAssembleUtil.unwrapPrefix(taskId), IDAssembleUtil.unwrapRegionId(task.getWorkflowId()));
/* 2697 */     transBean.setTaskId(newTaskId);
/* 2698 */     transBean.setParentTaskId(task.getTaskId());
/* 2699 */     transBean.setTaskStaffId(authorizeStaffId);
/* 2700 */     transBean.setStationId(authorizeStationId);
/* 2701 */     transBean.setDuration(task.getDuration());
/* 2702 */     transBean.setWarningDate(task.getWarningDate());
/* 2703 */     transBean.setWarningTimes(0);
/* 2704 */     transBean.setCreateDate(current);
/* 2705 */     transBean.setStateDate(current);
/* 2706 */     transBean.setStsToNew();
/* 2707 */     FlowFactory.saveTaskTrans(transBean);
/*      */ 
/* 2709 */     if ((task.getTaskStaffId() == null) && (task.getStationId() != null)) {
/* 2710 */       task.setTaskStaffId(staffId);
/*      */     }
/* 2712 */     task.setFinishStaffId(staffId);
/* 2713 */     task.setState(10);
/* 2714 */     task.setStateDate(current);
/* 2715 */     task.setFinishDate(current);
/* 2716 */     FlowFactory.saveTaskTrans(task);
/* 2717 */     return newTaskId;
/*      */   }
/*      */ 
/*      */   public void dealTransTaskDown(String parentTaskId, String workflowId, int state)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2724 */     IBOVmTaskTSValue[] transTasks = FlowFactory.getTaskTransBeansParentOrWorkflowId(parentTaskId, workflowId);
/* 2725 */     if ((transTasks == null) || (transTasks.length <= 0) || (org.apache.commons.lang.StringUtils.isEmpty(transTasks[0].getTaskId()))) {
/* 2726 */       return;
/*      */     }
/* 2728 */     for (int i = 0; i < transTasks.length; ++i) {
/* 2729 */       if ((transTasks[i].getState() == 3) || (transTasks[i].getState() == 4) || (transTasks[i].getState() == 8)) {
/*      */         continue;
/*      */       }
/* 2732 */       dealTransTaskDown(transTasks[i].getTaskId(), workflowId, state);
/* 2733 */       transTasks[i].setIsCurrentTask("N");
/* 2734 */       transTasks[i].setState(state);
/* 2735 */       transTasks[i].setStateDate(TimeUtil.getSysTime());
/*      */     }
/*      */ 
/* 2738 */     FlowFactory.saveTaskTrans(transTasks);
/*      */   }
/*      */ 
/*      */   public UserInfoInterface getWorkflowSysUserInfo(String workflowId) throws RemoteException, Exception {
/* 2742 */     Workflow workflow = getWorkflowForSchedule(workflowId);
/* 2743 */     return getWorkflowSysUserInfo(workflow);
/*      */   }
/*      */   public UserInfoInterface getWorkflowSysUserInfo(Workflow workflow) throws RemoteException, Exception {
/* 2746 */     TaskDealBean dealBean = workflow.getWorkflowTemplate().getGetUserInfoDealBean();
/* 2747 */     if ((dealBean == null) || (org.apache.commons.lang.StringUtils.isBlank(dealBean.getRunClassName()))) {
/* 2748 */       return null;
/*      */     }
/* 2750 */     Object result = TaskBaseImpl.executeDealInner(workflow, workflow.getWorkflowContext(), dealBean);
/* 2751 */     if (result == null) {
/* 2752 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getWorkflowSysUserInfo_method") + dealBean.getRunClassName() + "." + dealBean.getRunFunctionName() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getWorkflowSysUserInfo_returnNotNull"));
/*      */     }
/* 2754 */     if (!result instanceof UserInfoInterface) {
/* 2755 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getWorkflowSysUserInfo_method") + dealBean.getRunClassName() + "." + dealBean.getRunFunctionName() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getWorkflowSysUserInfo_returnNotUserInfo"));
/*      */     }
/*      */ 
/* 2758 */     return (UserInfoInterface)result;
/*      */   }
/*      */ 
/*      */   private IBOVmWFAttrValue[] getVmWorkflowAttrAllBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws Exception
/*      */   {
/* 2772 */     return getWorkflowDao().getVmWorkflowAttrAllBeans(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2787 */     if ((org.apache.commons.lang.StringUtils.isEmpty(attrCode)) || (org.apache.commons.lang.StringUtils.isEmpty(attrValue))) {
/* 2788 */       return getTaskInfos(queueID, condition, parameter, startIndex, endIndex);
/*      */     }
/*      */ 
/* 2791 */     StringBuffer attrCond = new StringBuffer("");
/* 2792 */     attrCond.append("ATTR_CODE").append(" =:attrCode").append(" and ");
/* 2793 */     attrCond.append("ATTR_VALUE").append("=:attrValue");
/* 2794 */     HashMap map = new HashMap();
/* 2795 */     map.put("attrCode", attrCode);
/* 2796 */     map.put("attrValue", attrValue);
/* 2797 */     IBOVmWFAttrValue[] wfAttrs = getWorkflowDao().getVmWorkflowAttrAllBeans(queueID, attrCond.toString(), map, -1, -1);
/* 2798 */     StringBuffer sb = new StringBuffer();
/* 2799 */     if (!org.apache.commons.lang.StringUtils.isEmpty(condition))
/* 2800 */       sb = new StringBuffer(condition);
/* 2801 */     if (wfAttrs.length > 0) {
/* 2802 */       if (!org.apache.commons.lang.StringUtils.isEmpty(condition))
/* 2803 */         sb.append(" and ");
/* 2804 */       sb.append("WORKFLOW_ID");
/* 2805 */       sb.append(" in ").append("(");
/* 2806 */       for (int i = 0; i < wfAttrs.length; ++i) {
/* 2807 */         if (i == wfAttrs.length - 1)
/* 2808 */           sb.append("'").append(wfAttrs[i].getWorkflowId()).append("'");
/*      */         else
/* 2810 */           sb.append("'").append(wfAttrs[i].getWorkflowId()).append("'").append(",");
/*      */       }
/* 2812 */       sb.append(")");
/*      */     }
/* 2814 */     return getTaskInfos(queueID, sb.toString(), parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public int getTaskCountByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2829 */     if ((org.apache.commons.lang.StringUtils.isEmpty(attrCode)) || (org.apache.commons.lang.StringUtils.isEmpty(attrValue))) {
/* 2830 */       return getTaskCount(queueID, condition, parameter);
/*      */     }
/*      */ 
/* 2833 */     StringBuffer attrCond = new StringBuffer("");
/* 2834 */     attrCond.append("ATTR_CODE").append(" =:attrCode").append(" and ");
/* 2835 */     attrCond.append("ATTR_VALUE").append("=:attrValue");
/* 2836 */     HashMap map = new HashMap();
/* 2837 */     map.put("attrCode", attrCode);
/* 2838 */     map.put("attrValue", attrValue);
/* 2839 */     IBOVmWFAttrValue[] wfAttrs = getWorkflowDao().getVmWorkflowAttrAllBeans(queueID, attrCond.toString(), map, -1, -1);
/* 2840 */     StringBuffer sb = new StringBuffer();
/* 2841 */     if (!org.apache.commons.lang.StringUtils.isEmpty(condition))
/* 2842 */       sb = new StringBuffer(condition);
/* 2843 */     if (wfAttrs.length > 0) {
/* 2844 */       if (!org.apache.commons.lang.StringUtils.isEmpty(condition))
/* 2845 */         sb.append(" and ");
/* 2846 */       sb.append("WORKFLOW_ID");
/* 2847 */       sb.append(" in ").append("(");
/* 2848 */       for (int i = 0; i < wfAttrs.length; ++i) {
/* 2849 */         if (i == wfAttrs.length - 1)
/* 2850 */           sb.append("'").append(wfAttrs[i].getWorkflowId()).append("'");
/*      */         else
/* 2852 */           sb.append("'").append(wfAttrs[i].getWorkflowId()).append("'").append(",");
/*      */       }
/* 2854 */       sb.append(")");
/*      */     }
/*      */ 
/* 2857 */     return getTaskCount(queueID, sb.toString(), parameter);
/*      */   }
/*      */ 
/*      */   public IBOVmWFAttrValue[] getVmWorkflowAttrsByWorkflowId(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2869 */     return getWorkflowDao().getVmWorkflowAttrsByWorkflowId(workflowId);
/*      */   }
/*      */ 
/*      */   public String[][] getExceptionCode(String workflowObjectType, String currentWorkflowCode, String taskTag)
/*      */     throws Exception, RemoteException
/*      */   {
/* 2883 */     StringBuffer sql = new StringBuffer("");
/* 2884 */     HashMap parameter = new HashMap();
/* 2885 */     sql.append("select distinct a.exception_code, a.exception_name from ");
/* 2886 */     sql.append(" vm_exception_code a,vm_exception_desc b,");
/* 2887 */     sql.append(" vm_exception_code_desc_relat c,vm_exception_rule d ");
/* 2888 */     sql.append(" where b.exception_desc_code = c.exception_desc_code ");
/* 2889 */     sql.append(" and a.exception_code = c.exception_code ");
/* 2890 */     sql.append(" and c.exception_desc_code = d.exception_desc_code ");
/* 2891 */     sql.append(" and a.state = 'U' and b.state = 'U' and c.state = 'U' and d.state = 'U'");
/* 2892 */     if (org.apache.commons.lang.StringUtils.isNotEmpty(currentWorkflowCode))
/*      */     {
/* 2894 */       sql.append(" and d.current_template_tag =:workflowCode ");
/* 2895 */       parameter.put("workflowCode", currentWorkflowCode);
/*      */     }
/* 2897 */     if (org.apache.commons.lang.StringUtils.isNotEmpty(workflowObjectType))
/*      */     {
/* 2899 */       sql.append(" and workflow_object_type =:objectTypeId ");
/* 2900 */       parameter.put("objectTypeId", workflowObjectType);
/*      */     }
/* 2902 */     if (org.apache.commons.lang.StringUtils.isNotEmpty(taskTag))
/*      */     {
/* 2904 */       sql.append(" and a.task_tag =:taskTag ");
/* 2905 */       parameter.put("taskTag", taskTag);
/*      */     }
/*      */ 
/* 2908 */     return FlowFactory.getExceptionCode(sql.toString(), parameter);
/*      */   }
/*      */ 
/*      */   public List getWorkflowStat(String dataSource, String statType, String startTime, String endTime, String taskTag, String objectTypeId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2916 */     return null;
/*      */   }
/*      */ 
/*      */   public List getWorkflowStateStat(String dataSource, String startTime, String endTime, String taskTag, String objectTypeId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2922 */     return null;
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2928 */     return getTaskViewDao().getWorkflowInfoHis(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfosHis(String queueID, String acctPreiod, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2934 */     return getTaskViewDao().getWorkflowInfoHis(queueID, acctPreiod, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public int getHisWorkflowInfosCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/* 2940 */     return getTaskViewDao().getWorkflowHisCount(queueID, condition, parameter);
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/* 2945 */     return getTaskViewDao().getWorkflowInfo(queueID, condition, parameter, startIndex, endIndex);
/*      */   }
/*      */ 
/*      */   public String toSvgByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/* 2950 */     StringBuilder condition = new StringBuilder("");
/* 2951 */     HashMap map = new HashMap();
/*      */ 
/* 2953 */     condition.append("WORKFLOW_OBJECT_TYPE").append(" = :objectTypeId ");
/* 2954 */     condition.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :objectId ");
/* 2955 */     map.put("objectTypeId", objectTypeId);
/* 2956 */     map.put("objectId", objectId);
/* 2957 */     WorkflowInfo[] beans = getWorkflowInfos(queueID, condition.toString(), map, -1, -1);
/* 2958 */     if (beans.length == 1) {
/* 2959 */       return toSvg(beans[0].getWorkflowId());
/*      */     }
/* 2961 */     for (int i = 0; i < beans.length; ++i) {
/* 2962 */       if ((beans[i].getWorkflowKind() != 2) && 
/* 2963 */         ("-1".equals(beans[i].getParentTaskId()))) {
/* 2964 */         return toSvg(beans[i].getWorkflowId());
/*      */       }
/*      */     }
/*      */ 
/* 2968 */     return "";
/*      */   }
/*      */ 
/*      */   public String toDojoByWorkflowObjectId(String queueID, String objectTypeId, String objectId, String imagePath) throws RemoteException, Exception
/*      */   {
/* 2973 */     StringBuilder condition = new StringBuilder("");
/* 2974 */     HashMap map = new HashMap();
/*      */ 
/* 2976 */     condition.append("WORKFLOW_OBJECT_TYPE").append(" = :objectTypeId ");
/* 2977 */     condition.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :objectId ");
/* 2978 */     map.put("objectTypeId", objectTypeId);
/* 2979 */     map.put("objectId", objectId);
/* 2980 */     WorkflowInfo[] beans = getWorkflowInfos(queueID, condition.toString(), map, -1, -1);
/* 2981 */     if (beans.length == 1) {
/* 2982 */       return toDojo(beans[0].getWorkflowId(), imagePath);
/*      */     }
/* 2984 */     for (int i = 0; i < beans.length; ++i) {
/* 2985 */       if ((beans[i].getWorkflowKind() != 2) && 
/* 2986 */         ("-1".equals(beans[i].getParentTaskId()))) {
/* 2987 */         return toDojo(beans[i].getWorkflowId(), imagePath);
/*      */       }
/*      */     }
/*      */ 
/* 2991 */     return "";
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String currentTaskId, String goBackTaskTag, String staffId, String reason, Map aVars) throws RemoteException, Exception
/*      */   {
/* 2996 */     if ((goBackTaskTag == null) || (goBackTaskTag.trim().length() == 0)) {
/* 2997 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.core.ComframeWorkflowImpl.goBackToTask_setTaskCode"));
/*      */     }
/*      */ 
/* 3000 */     String workflowId = getWorkflowIdByTaskId(currentTaskId);
/* 3001 */     Workflow workflow = getWorkflow(workflowId);
/* 3002 */     TaskTemplate[] templates = workflow.getWorkflowTemplate().getTaskTemplates();
/* 3003 */     long taskTemplateId = -1L;
/* 3004 */     for (int i = 0; i < templates.length; ++i) {
/* 3005 */       if ((templates[i].getTaskTag() != null) && (templates[i].getTaskTag().equalsIgnoreCase(goBackTaskTag))) {
/* 3006 */         taskTemplateId = templates[i].getTaskTemplateId();
/* 3007 */         break;
/*      */       }
/*      */     }
/* 3010 */     if (taskTemplateId == -1L) {
/* 3011 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.core.ComframeWorkflowImpl.goBackToTask_notFindTemplateByTaskCode") + goBackTaskTag);
/*      */     }
/*      */ 
/* 3017 */     return goBackToTask(currentTaskId, taskTemplateId, aVars, staffId, reason);
/*      */   }
/*      */ 
/*      */   public String toSvgHis(String workflowId, String acctPreiod) throws RemoteException, Exception
/*      */   {
/* 3022 */     Workflow workflow = FlowFactory.reloadWorkflowHis(workflowId, acctPreiod);
/* 3023 */     return VMUtil.toSvg(workflow);
/*      */   }
/*      */ 
/*      */   public String toSvgHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/* 3028 */     StringBuilder condition = new StringBuilder("");
/* 3029 */     HashMap map = new HashMap();
/*      */ 
/* 3031 */     condition.append("WORKFLOW_OBJECT_TYPE").append(" = :objectTypeId ");
/* 3032 */     condition.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :objectId ");
/* 3033 */     map.put("objectTypeId", objectTypeId);
/* 3034 */     map.put("objectId", objectId);
/* 3035 */     WorkflowInfo[] beans = getWorkflowInfosHis(queueID, acctPreiod, condition.toString(), map, -1, -1);
/* 3036 */     if (beans.length == 1) {
/* 3037 */       return toSvg(beans[0].getWorkflowId());
/*      */     }
/* 3039 */     for (int i = 0; i < beans.length; ++i) {
/* 3040 */       if (beans[i].getWorkflowKind() != 2) {
/* 3041 */         return toSvg(beans[0].getWorkflowId());
/*      */       }
/*      */     }
/* 3044 */     return "";
/*      */   }
/*      */ 
/*      */   public String toDojoHis(String workflowId, String acctPreiod, String imagePath) throws RemoteException, Exception
/*      */   {
/* 3049 */     Workflow workflow = FlowFactory.reloadWorkflowHis(workflowId, acctPreiod);
/* 3050 */     return VMUtilDojo.toDojoHis(workflow, acctPreiod, imagePath);
/*      */   }
/*      */ 
/*      */   public String toDojoHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId, String imagePath) throws RemoteException, Exception
/*      */   {
/* 3055 */     StringBuilder condition = new StringBuilder("");
/* 3056 */     HashMap map = new HashMap();
/*      */ 
/* 3058 */     condition.append("WORKFLOW_OBJECT_TYPE").append(" = :objectTypeId ");
/* 3059 */     condition.append(" and ").append("WORKFLOW_OBJECT_ID").append(" = :objectId ");
/* 3060 */     map.put("objectTypeId", objectTypeId);
/* 3061 */     map.put("objectId", objectId);
/* 3062 */     WorkflowInfo[] beans = getWorkflowInfosHis(queueID, acctPreiod, condition.toString(), map, -1, -1);
/* 3063 */     if (beans.length == 1) {
/* 3064 */       return toDojoHis(beans[0].getWorkflowId(), acctPreiod, imagePath);
/*      */     }
/* 3066 */     for (int i = 0; i < beans.length; ++i) {
/* 3067 */       if (beans[i].getWorkflowKind() != 2) {
/* 3068 */         return toDojoHis(beans[0].getWorkflowId(), acctPreiod, imagePath);
/*      */       }
/*      */     }
/* 3071 */     return "";
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfos(String queuID, String stations, String staffId, String state, String orderId, int startIndex, int endIndex)
/*      */     throws Exception, RemoteException
/*      */   {
/* 3078 */     String condition = "";
/* 3079 */     HashMap parameter = new HashMap();
/* 3080 */     condition = "(TASK_STAFF_ID = '" + staffId + "'";
/* 3081 */     if ((!org.apache.commons.lang.StringUtils.isEmpty(stations)) && (!"null".equals(stations))) {
/* 3082 */       condition = condition + " or " + "STATION_ID" + " = '" + stations + "'";
/*      */     }
/*      */ 
/* 3085 */     condition = condition + ")";
/* 3086 */     if (!org.apache.commons.lang.StringUtils.isEmpty(state)) {
/* 3087 */       condition = condition + " and  STATE = :state ";
/* 3088 */       parameter.put("state", state);
/*      */     } else {
/* 3090 */       condition = condition + " AND (" + "STATE" + " = " + 5 + " OR " + "STATE" + " = " + 9 + ")" + " AND " + "WORKFLOW_STATE" + " IN (" + 5 + "," + 2 + ")";
/*      */     }
/*      */ 
/* 3096 */     if (!org.apache.commons.lang.StringUtils.isEmpty(orderId)) {
/* 3097 */       condition = condition + " and  " + "WORKFLOW_OBJECT_ID" + " = '" + orderId + "' ";
/*      */     }
/*      */ 
/* 3100 */     TaskInfo[] infos = getTaskInfos(queuID, condition, parameter, startIndex, endIndex);
/*      */ 
/* 3103 */     return infos;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.impl.WorkflowEngineSVImpl
 * JD-Core Version:    0.5.4
 */