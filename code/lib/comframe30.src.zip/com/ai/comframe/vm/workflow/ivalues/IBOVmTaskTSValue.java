package com.ai.comframe.vm.workflow.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmTaskTSValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_WarningTimes = "WARNING_TIMES";
  public static final String S_StateDate = "STATE_DATE";
  public static final String S_ParentTaskId = "PARENT_TASK_ID";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_DestType = "DEST_TYPE";
  public static final String S_TaskTag = "TASK_TAG";
  public static final String S_WarningDate = "WARNING_DATE";
  public static final String S_LockDate = "LOCK_DATE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_Label = "LABEL";
  public static final String S_DestTaskTemplateId = "DEST_TASK_TEMPLATE_ID";
  public static final String S_TaskBaseType = "TASK_BASE_TYPE";
  public static final String S_TaskStaffId = "TASK_STAFF_ID";
  public static final String S_LockStaffId = "LOCK_STAFF_ID";
  public static final String S_FinishDate = "FINISH_DATE";
  public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_StationId = "STATION_ID";
  public static final String S_Duration = "DURATION";
  public static final String S_TaskType = "TASK_TYPE";
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_ErrorMessage = "ERROR_MESSAGE";
  public static final String S_Description = "DESCRIPTION";
  public static final String S_TaskId = "TASK_ID";
  public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
  public static final String S_FinishStaffId = "FINISH_STAFF_ID";
  public static final String S_DecisionResult = "DECISION_RESULT";

  public abstract int getState();

  public abstract int getWarningTimes();

  public abstract Timestamp getStateDate();

  public abstract String getParentTaskId();

  public abstract Timestamp getCreateDate();

  public abstract String getDestType();

  public abstract String getTaskTag();

  public abstract Timestamp getWarningDate();

  public abstract Timestamp getLockDate();

  public abstract String getRegionId();

  public abstract String getLabel();

  public abstract long getDestTaskTemplateId();

  public abstract String getTaskBaseType();

  public abstract String getTaskStaffId();

  public abstract String getLockStaffId();

  public abstract Timestamp getFinishDate();

  public abstract long getTaskTemplateId();

  public abstract String getQueueId();

  public abstract String getStationId();

  public abstract long getDuration();

  public abstract String getTaskType();

  public abstract String getWorkflowId();

  public abstract String getErrorMessage();

  public abstract String getDescription();

  public abstract String getTaskId();

  public abstract String getIsCurrentTask();

  public abstract String getFinishStaffId();

  public abstract String getDecisionResult();

  public abstract void setState(int paramInt);

  public abstract void setWarningTimes(int paramInt);

  public abstract void setStateDate(Timestamp paramTimestamp);

  public abstract void setParentTaskId(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setDestType(String paramString);

  public abstract void setTaskTag(String paramString);

  public abstract void setWarningDate(Timestamp paramTimestamp);

  public abstract void setLockDate(Timestamp paramTimestamp);

  public abstract void setRegionId(String paramString);

  public abstract void setLabel(String paramString);

  public abstract void setDestTaskTemplateId(long paramLong);

  public abstract void setTaskBaseType(String paramString);

  public abstract void setTaskStaffId(String paramString);

  public abstract void setLockStaffId(String paramString);

  public abstract void setFinishDate(Timestamp paramTimestamp);

  public abstract void setTaskTemplateId(long paramLong);

  public abstract void setQueueId(String paramString);

  public abstract void setStationId(String paramString);

  public abstract void setDuration(long paramLong);

  public abstract void setTaskType(String paramString);

  public abstract void setWorkflowId(String paramString);

  public abstract void setErrorMessage(String paramString);

  public abstract void setDescription(String paramString);

  public abstract void setTaskId(String paramString);

  public abstract void setIsCurrentTask(String paramString);

  public abstract void setFinishStaffId(String paramString);

  public abstract void setDecisionResult(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue
 * JD-Core Version:    0.5.4
 */