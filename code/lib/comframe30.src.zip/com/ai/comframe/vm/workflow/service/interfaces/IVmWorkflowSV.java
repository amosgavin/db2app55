package com.ai.comframe.vm.workflow.service.interfaces;

import com.ai.comframe.queue.WarningTaskBean;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
import java.rmi.RemoteException;
import java.util.HashMap;

public abstract interface IVmWorkflowSV
{
  public abstract void saveVmWorkflowInstacne(IBOVmWFValue paramIBOVmWFValue)
    throws RemoteException, Exception;

  public abstract String getNewWorkFlowId(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract String getNewWorkFlowAttrId(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract IBOVmWFValue getVmWorkflowBeanbyId(String paramString)
    throws RemoteException, Exception;

  public abstract void saveVmWorkflowAttrBeans(IBOVmWFAttrValue[] paramArrayOfIBOVmWFAttrValue)
    throws RemoteException, Exception;

  public abstract IBOVmWFValue[] getWorkflowBeans(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getWorkflowBeansCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract IBOHVmWFValue[] getHisWorkflowBeans(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws RemoteException, Exception;

  public abstract int getHisWorkflowBeansCount(String paramString1, String paramString2, HashMap paramHashMap, String paramString3)
    throws RemoteException, Exception;

  public abstract IBOVmWFAttrValue[] getVmWorkflowAttrsByWorkflowId(String paramString)
    throws RemoteException, Exception;

  public abstract WarningTaskBean[] getWarningWorkflowData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV
 * JD-Core Version:    0.5.4
 */