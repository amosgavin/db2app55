/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFAttrValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOHVmWFAttrBean extends DataContainer
/*     */   implements DataContainerInterface, IBOHVmWFAttrValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOHVmWFAttr";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_AttrName = "ATTR_NAME";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_TransferDate = "TRANSFER_DATE";
/*     */   public static final String S_AttrCode = "ATTR_CODE";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_AttrId = "ATTR_ID";
/*     */   public static final String S_AttrValue = "ATTR_VALUE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*  29 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOHVmWFAttrBean()
/*     */     throws AIException
/*     */   {
/*  38 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  42 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  47 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value)
/*     */   {
/*  52 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/*  55 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/*  58 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/*  62 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/*  66 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrName(String value) {
/*  70 */     initProperty("ATTR_NAME", value);
/*     */   }
/*     */   public void setAttrName(String value) {
/*  73 */     set("ATTR_NAME", value);
/*     */   }
/*     */   public void setAttrNameNull() {
/*  76 */     set("ATTR_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getAttrName() {
/*  80 */     return DataType.getAsString(get("ATTR_NAME"));
/*     */   }
/*     */ 
/*     */   public String getAttrNameInitialValue() {
/*  84 */     return DataType.getAsString(getOldObj("ATTR_NAME"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/*  88 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/*  91 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/*  94 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/*  98 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 102 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initTransferDate(Timestamp value) {
/* 106 */     initProperty("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDate(Timestamp value) {
/* 109 */     set("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDateNull() {
/* 112 */     set("TRANSFER_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDate() {
/* 116 */     return DataType.getAsDateTime(get("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDateInitialValue() {
/* 120 */     return DataType.getAsDateTime(getOldObj("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public void initAttrCode(String value) {
/* 124 */     initProperty("ATTR_CODE", value);
/*     */   }
/*     */   public void setAttrCode(String value) {
/* 127 */     set("ATTR_CODE", value);
/*     */   }
/*     */   public void setAttrCodeNull() {
/* 130 */     set("ATTR_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getAttrCode() {
/* 134 */     return DataType.getAsString(get("ATTR_CODE"));
/*     */   }
/*     */ 
/*     */   public String getAttrCodeInitialValue() {
/* 138 */     return DataType.getAsString(getOldObj("ATTR_CODE"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 142 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 145 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 148 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 152 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 156 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrId(long value) {
/* 160 */     initProperty("ATTR_ID", new Long(value));
/*     */   }
/*     */   public void setAttrId(long value) {
/* 163 */     set("ATTR_ID", new Long(value));
/*     */   }
/*     */   public void setAttrIdNull() {
/* 166 */     set("ATTR_ID", null);
/*     */   }
/*     */ 
/*     */   public long getAttrId() {
/* 170 */     return DataType.getAsLong(get("ATTR_ID"));
/*     */   }
/*     */ 
/*     */   public long getAttrIdInitialValue() {
/* 174 */     return DataType.getAsLong(getOldObj("ATTR_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrValue(String value) {
/* 178 */     initProperty("ATTR_VALUE", value);
/*     */   }
/*     */   public void setAttrValue(String value) {
/* 181 */     set("ATTR_VALUE", value);
/*     */   }
/*     */   public void setAttrValueNull() {
/* 184 */     set("ATTR_VALUE", null);
/*     */   }
/*     */ 
/*     */   public String getAttrValue() {
/* 188 */     return DataType.getAsString(get("ATTR_VALUE"));
/*     */   }
/*     */ 
/*     */   public String getAttrValueInitialValue() {
/* 192 */     return DataType.getAsString(getOldObj("ATTR_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 196 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 199 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 202 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 206 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 210 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  34 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOHVmWFAttrBean
 * JD-Core Version:    0.5.4
 */