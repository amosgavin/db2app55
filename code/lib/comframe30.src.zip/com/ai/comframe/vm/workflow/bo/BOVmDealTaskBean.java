/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmDealTaskBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmDealTaskValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOVmDealTask";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_Runtime = "RUNTIME";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_DealTaskId = "DEAL_TASK_ID";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_DevId = "DEV_ID";
/*     */   public static final String S_DealType = "DEAL_TYPE";
/*  31 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmDealTaskBean()
/*     */     throws AIException
/*     */   {
/*  40 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  44 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  49 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value)
/*     */   {
/*  54 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/*  57 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/*  60 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/*  64 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/*  68 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initState(int value) {
/*  72 */     initProperty("STATE", new Integer(value));
/*     */   }
/*     */   public void setState(int value) {
/*  75 */     set("STATE", new Integer(value));
/*     */   }
/*     */   public void setStateNull() {
/*  78 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public int getState() {
/*  82 */     return DataType.getAsInt(get("STATE"));
/*     */   }
/*     */ 
/*     */   public int getStateInitialValue() {
/*  86 */     return DataType.getAsInt(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/*  90 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/*  93 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/*  96 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 100 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 104 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initRuntime(Timestamp value) {
/* 108 */     initProperty("RUNTIME", value);
/*     */   }
/*     */   public void setRuntime(Timestamp value) {
/* 111 */     set("RUNTIME", value);
/*     */   }
/*     */   public void setRuntimeNull() {
/* 114 */     set("RUNTIME", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getRuntime() {
/* 118 */     return DataType.getAsDateTime(get("RUNTIME"));
/*     */   }
/*     */ 
/*     */   public Timestamp getRuntimeInitialValue() {
/* 122 */     return DataType.getAsDateTime(getOldObj("RUNTIME"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 126 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 129 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 132 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 136 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 140 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 144 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 147 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 150 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 154 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 158 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initDealTaskId(String value) {
/* 162 */     initProperty("DEAL_TASK_ID", value);
/*     */   }
/*     */   public void setDealTaskId(String value) {
/* 165 */     set("DEAL_TASK_ID", value);
/*     */   }
/*     */   public void setDealTaskIdNull() {
/* 168 */     set("DEAL_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getDealTaskId() {
/* 172 */     return DataType.getAsString(get("DEAL_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getDealTaskIdInitialValue() {
/* 176 */     return DataType.getAsString(getOldObj("DEAL_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 180 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 183 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 186 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 190 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 194 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 198 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 201 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 204 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 208 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 212 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initDevId(String value) {
/* 216 */     initProperty("DEV_ID", value);
/*     */   }
/*     */   public void setDevId(String value) {
/* 219 */     set("DEV_ID", value);
/*     */   }
/*     */   public void setDevIdNull() {
/* 222 */     set("DEV_ID", null);
/*     */   }
/*     */ 
/*     */   public String getDevId() {
/* 226 */     return DataType.getAsString(get("DEV_ID"));
/*     */   }
/*     */ 
/*     */   public String getDevIdInitialValue() {
/* 230 */     return DataType.getAsString(getOldObj("DEV_ID"));
/*     */   }
/*     */ 
/*     */   public void initDealType(String value) {
/* 234 */     initProperty("DEAL_TYPE", value);
/*     */   }
/*     */   public void setDealType(String value) {
/* 237 */     set("DEAL_TYPE", value);
/*     */   }
/*     */   public void setDealTypeNull() {
/* 240 */     set("DEAL_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getDealType() {
/* 244 */     return DataType.getAsString(get("DEAL_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getDealTypeInitialValue() {
/* 248 */     return DataType.getAsString(getOldObj("DEAL_TYPE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  34 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  36 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOVmDealTaskBean
 * JD-Core Version:    0.5.4
 */