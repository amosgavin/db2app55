/*     */ package com.ai.comframe.vm.workflow.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TableAssembleUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmWFAttrBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmWFAttrEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmWFEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmScheduleBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFAttrBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFAttrEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFEngine;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class VmWorkflowDAOImpl
/*     */   implements IVmWorkflowDAO
/*     */ {
/*     */   public String getNewWorkFlowAttrId(String queueId, String regionId)
/*     */     throws Exception
/*     */   {
/*  35 */     long lWFAttrID = BOVmWFAttrEngine.getNewId().longValue();
/*  36 */     String wfAttrID = IDAssembleUtil.wrapPrefix(lWFAttrID, queueId, regionId);
/*  37 */     return wfAttrID;
/*     */   }
/*     */ 
/*     */   public String getNewWorkFlowId(String queueId, String regionId) throws Exception {
/*  41 */     long lWorkflowId = BOVmWFEngine.getNewId().longValue();
/*  42 */     String sWorkflowId = IDAssembleUtil.wrapPrefix(lWorkflowId, queueId, regionId);
/*  43 */     return sWorkflowId;
/*     */   }
/*     */ 
/*     */   public IBOVmWFAttrValue[] getVmWorkflowAttrBeans(String workflowId) throws Exception {
/*  47 */     AssembleDef ad = new AssembleDef();
/*  48 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  49 */     BOVmWFAttrBean vab = new BOVmWFAttrBean();
/*  50 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/*  51 */     HashMap map = new HashMap();
/*  52 */     map.put("WORKFLOW_ID", workflowId);
/*  53 */     String sql = TableAssembleUtil.createSelectSQL(vab, ad, cond, -1, -1);
/*  54 */     return BOVmWFAttrEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public IBOVmWFAttrValue[] getVmWorkflowAttrsByWorkflowId(String workflowId) throws Exception {
/*  58 */     AssembleDef ad = new AssembleDef();
/*  59 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  60 */     BOVmWFAttrBean vab = new BOVmWFAttrBean();
/*  61 */     String cond = "WORKFLOW_ID=:WORKFLOW_ID";
/*  62 */     HashMap param = new HashMap();
/*  63 */     param.put("WORKFLOW_ID", workflowId);
/*  64 */     String sql = TableAssembleUtil.createSelectSQL(vab, ad, cond, -1, -1);
/*  65 */     return BOVmWFAttrEngine.getBeansFromSql(sql, param);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue getVmWorkflowBeanbyId(String workflowId) throws Exception {
/*  69 */     AssembleDef ad = new AssembleDef();
/*  70 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  71 */     BOVmWFBean vf = new BOVmWFBean();
/*  72 */     String cond = "WORKFLOW_ID=:WORKFLOW_ID";
/*  73 */     HashMap param = new HashMap();
/*  74 */     param.put("WORKFLOW_ID", workflowId);
/*  75 */     String sql = TableAssembleUtil.createSelectSQL(vf, ad, cond, -1, -1);
/*  76 */     IBOVmWFValue[] ret = BOVmWFEngine.getBeansFromSql(sql, param);
/*  77 */     if ((ret != null) && (ret.length == 1))
/*  78 */       return BOVmWFEngine.getBeansFromSql(sql, param)[0];
/*  79 */     if ((ret != null) && (ret.length > 1))
/*     */     {
/*  81 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_getWorkflowMore") + ret.length);
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue[] getWorkflowBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/*  91 */     AssembleDef ad = new AssembleDef();
/*  92 */     ad.setQueueId(queueID);
/*  93 */     BOVmWFBean vf = new BOVmWFBean();
/*  94 */     String sql = TableAssembleUtil.createSelectSQL(vf, ad, condition, startIndex, endIndex);
/*  95 */     return BOVmWFEngine.getBeansFromSql(sql, parameter);
/*     */   }
/*     */ 
/*     */   public int getWorkflowBeansCount(String queueID, String condition, HashMap parameter) throws Exception {
/*  99 */     AssembleDef ad = new AssembleDef();
/* 100 */     ad.setQueueId(queueID);
/* 101 */     BOVmWFBean vf = new BOVmWFBean();
/* 102 */     String sql = TableAssembleUtil.createSelectSQL(vf, ad, condition, -1, -1);
/* 103 */     return BOVmWFEngine.getBeansFromSql(sql, parameter).length;
/*     */   }
/*     */ 
/*     */   public void saveVmWorkflowAttrBeans(IBOVmWFAttrValue[] attrs) throws Exception {
/* 107 */     if ((attrs == null) || (attrs.length == 0)) {
/* 108 */       return;
/*     */     }
/* 110 */     for (int i = 0; i < attrs.length; ++i) {
/* 111 */       TableAssembleUtil.replaceTableName((BOVmWFAttrBean)attrs[i]);
/* 112 */       if (attrs[i].isNew())
/* 113 */         attrs[i].setAttrId(BOVmWFAttrEngine.getNewId().longValue());
/*     */     }
/* 115 */     BOVmWFAttrEngine.saveBatch(attrs);
/*     */   }
/*     */ 
/*     */   public void saveVmWorkflowInstacne(IBOVmWFValue workflowbean) throws Exception
/*     */   {
/* 120 */     BOVmWFBean aWorkflowBean = (BOVmWFBean)workflowbean;
/* 121 */     TableAssembleUtil.replaceTableName(aWorkflowBean);
/* 122 */     BOVmWFEngine.save(aWorkflowBean);
/*     */   }
/*     */ 
/*     */   public void saveHVmWorkflowInstacne(IBOHVmWFValue hisWFBean) throws Exception
/*     */   {
/* 127 */     if (hisWFBean == null) {
/* 128 */       return;
/*     */     }
/* 130 */     TableAssembleUtil.replaceHisTableName((BOHVmWFBean)hisWFBean);
/* 131 */     BOHVmWFEngine.save(hisWFBean);
/*     */   }
/*     */ 
/*     */   public IBOVmWFAttrValue[] getVmWorkflowAttrAllBeans(String queuId, String condition, HashMap parameter, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/* 137 */     IBOVmWFAttrValue[] ret = null;
/* 138 */     AssembleDef ad = new AssembleDef();
/* 139 */     ad.setQueueId(queuId);
/* 140 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmWFAttrBean(), ad, condition, -1, -1);
/* 141 */     ret = BOVmWFAttrEngine.getBeansFromSql(sql, parameter);
/* 142 */     return ret;
/*     */   }
/*     */ 
/*     */   public IBOHVmWFValue getHisVmWorkflowBeanbyId(String workflowId) throws Exception
/*     */   {
/* 147 */     IBOHVmWFValue[] ret = null;
/* 148 */     AssembleDef ad = new AssembleDef();
/* 149 */     String[] date = AssembleDef.getDefautTimePeriod();
/* 150 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 151 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 152 */     HashMap map = new HashMap();
/* 153 */     map.put("WORKFLOW_ID", workflowId);
/*     */ 
/* 155 */     for (int i = 0; i < date.length; ++i) {
/* 156 */       ad.setSdate(date[i]);
/* 157 */       String sql = TableAssembleUtil.createHisSelectSQL(new BOHVmWFBean(), ad, cond.toString(), -1, -1);
/* 158 */       ret = BOHVmWFEngine.getBeansFromSql(sql, map);
/* 159 */       if ((ret != null) && (ret.length == 1))
/* 160 */         return ret[0];
/* 161 */       if ((ret == null) || (ret.length <= 1))
/*     */         continue;
/* 163 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_getWorkflowMore") + ret.length);
/*     */     }
/*     */ 
/* 166 */     return null;
/*     */   }
/*     */ 
/*     */   public IBOHVmWFValue getHisVmWorkflowBeanbyId(String workflowId, String acctPeriod) throws Exception
/*     */   {
/* 171 */     IBOHVmWFValue ret = null;
/* 172 */     AssembleDef ad = new AssembleDef();
/* 173 */     ad.setSdate(acctPeriod);
/* 174 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 175 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/*     */ 
/* 177 */     HashMap map = new HashMap();
/* 178 */     map.put("WORKFLOW_ID", workflowId);
/* 179 */     String sql = TableAssembleUtil.createSelectSQL(new BOHVmWFBean(), ad, cond.toString(), -1, -1);
/*     */ 
/* 181 */     IBOHVmWFValue[] rets = BOHVmWFEngine.getBeansFromSql(sql, map);
/* 182 */     if ((rets != null) && (rets.length == 1))
/* 183 */       ret = rets[0];
/* 184 */     else if ((rets != null) && (rets.length > 1))
/*     */     {
/* 186 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_getWorkflowMore") + rets.length);
/*     */     }
/* 188 */     return ret;
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue[] getWarningWorkflowData(String queueId, int mod, int value, int fetchNum) throws Exception {
/* 192 */     if (StringUtils.isBlank(queueId))
/*     */     {
/* 194 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_queueIDnotEmpty"));
/* 195 */     }if (mod <= 0)
/*     */     {
/* 197 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modeNotBelowZero"));
/* 198 */     }if (value < 0)
/*     */     {
/* 200 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modValueNotBelowZero"));
/*     */     }
/* 202 */     StringBuilder condition = new StringBuilder("");
/* 203 */     HashMap parameter = new HashMap();
/* 204 */     AssembleDef assemDef = new AssembleDef();
/* 205 */     assemDef.setQueueId(queueId);
/*     */ 
/* 207 */     condition.append(" 1 = 1 ");
/* 208 */     condition.append(" and ").append("QUEUE_ID").append(" = :qid ");
/* 209 */     condition.append(" and ").append("WARNING_DATE").append(" <= :curTime ");
/* 210 */     condition.append(" and ").append("STATE").append(" = :pstate ");
/* 211 */     parameter.put("qid", queueId);
/* 212 */     parameter.put("curTime", TimeUtil.getSysTime());
/* 213 */     parameter.put("pstate", String.valueOf(2));
/* 214 */     if (CenterFactory.isSetCenterInfo()) {
/* 215 */       CenterInfo center = CenterFactory.getCenterInfo();
/* 216 */       if ((center != null) && (StringUtils.isNotBlank(center.getRegion()))) {
/* 217 */         condition.append(" and ").append("REGION_ID").append(" = :regionId ");
/* 218 */         parameter.put("regionId", center.getRegion());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 223 */     if (PropertiesUtil.isDev()) {
/* 224 */       String devName = PropertiesUtil.getDevId();
/* 225 */       if (StringUtils.isBlank(devName)) {
/* 226 */         String[] param = new String[1];
/* 227 */         param[0] = "comframe.dev.name";
/* 228 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */       }
/*     */ 
/* 231 */       BOVmScheduleBean scheduleBean = new BOVmScheduleBean();
/* 232 */       String tableName = TableAssembleUtil.getTableName(scheduleBean.fetchTableName(), assemDef);
/* 233 */       condition.append(" and exists ( select 1 from ").append(tableName).append(" where ").append("WORKFLOW_ID").append(" = ").append("WORKFLOW_ID").append(" and ").append("DEV_ID").append(" = :devId )");
/*     */ 
/* 235 */       parameter.put("devId", devName);
/*     */     }
/*     */     else {
/* 238 */       BOVmScheduleBean scheduleBean = new BOVmScheduleBean();
/* 239 */       String tableName = TableAssembleUtil.getTableName(scheduleBean.fetchTableName(), assemDef);
/* 240 */       condition.append(" and exists ( select 1 from ").append(tableName).append(" where ").append("WORKFLOW_ID").append(" = ").append("WORKFLOW_ID").append(" and ").append("DEV_ID").append(" is null )");
/*     */     }
/*     */ 
/* 244 */     condition.append(" and mod(").append(IDAssembleUtil.wrappedIdColToNumFunc("WORKFLOW_ID")).append(",:mod ) = :value ");
/*     */ 
/* 246 */     parameter.put("mod", String.valueOf(mod));
/* 247 */     parameter.put("value", String.valueOf(value));
/*     */ 
/* 249 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmWFBean(), assemDef, condition.toString(), 1, fetchNum);
/* 250 */     return BOVmWFEngine.getBeansFromSql(sql, parameter);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue[] getChildWorkflows(String workflowId) throws Exception {
/* 254 */     AssembleDef def = new AssembleDef();
/* 255 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 256 */     BOVmWFBean wfBean = new BOVmWFBean();
/* 257 */     StringBuffer cond = new StringBuffer(" ");
/* 258 */     cond.append("PARENT_TASK_ID").append(" =:WorkflowID");
/* 259 */     cond.append(" and ").append("WORKFLOW_KIND").append(" =:IsExWorkflow");
/* 260 */     HashMap map = new HashMap();
/* 261 */     map.put("WorkflowID", workflowId);
/* 262 */     map.put("IsExWorkflow", new Integer(1));
/* 263 */     String sql = TableAssembleUtil.createSelectSQL(wfBean, def, cond.toString(), -1, -1);
/* 264 */     return BOVmWFEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue getExceptionChildWorkflow(String workflowId) throws Exception {
/* 268 */     AssembleDef def = new AssembleDef();
/* 269 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 270 */     BOVmWFBean wfBean = new BOVmWFBean();
/* 271 */     StringBuffer cond = new StringBuffer(" ");
/* 272 */     cond.append("PARENT_TASK_ID").append(" =:WorkflowID");
/* 273 */     cond.append(" and ").append("WORKFLOW_KIND").append(" =:IsExWorkflow");
/* 274 */     HashMap map = new HashMap();
/* 275 */     map.put("WorkflowID", workflowId);
/* 276 */     map.put("IsExWorkflow", new Integer(2));
/* 277 */     String sql = TableAssembleUtil.createSelectSQL(wfBean, def, cond.toString(), -1, -1);
/* 278 */     IBOVmWFValue[] wfs = BOVmWFEngine.getBeansFromSql(sql, map);
/* 279 */     if ((wfs == null) || (wfs.length == 0))
/* 280 */       return null;
/* 281 */     return wfs[0];
/*     */   }
/*     */ 
/*     */   public void workflowToHis(String workflowId, Timestamp transferDate) throws Exception
/*     */   {
/* 286 */     IBOVmWFValue wfBean = getVmWorkflowBeanbyId(workflowId);
/* 287 */     if ((wfBean != null) && (!wfBean.isNew())) {
/* 288 */       BOHVmWFBean hisWfBean = new BOHVmWFBean();
/* 289 */       hisWfBean.setWorkflowId(wfBean.getWorkflowId());
/* 290 */       hisWfBean.setCreateDate(wfBean.getCreateDate());
/* 291 */       hisWfBean.setCreateStaffId(wfBean.getCreateStaffId());
/* 292 */       hisWfBean.setCurrentTaskId(wfBean.getCurrentTaskId());
/* 293 */       hisWfBean.setDescription(wfBean.getDescription());
/* 294 */       hisWfBean.setDuration(wfBean.getDuration());
/* 295 */       hisWfBean.setEngineType(wfBean.getEngineType());
/* 296 */       hisWfBean.setEngineWorkflowId(wfBean.getEngineWorkflowId());
/* 297 */       hisWfBean.setErrorCount(wfBean.getErrorCount());
/* 298 */       hisWfBean.setErrorMessage(wfBean.getErrorMessage());
/* 299 */       hisWfBean.setFinishDate(wfBean.getFinishDate());
/* 300 */       hisWfBean.setWorkflowKind(wfBean.getWorkflowKind());
/* 301 */       hisWfBean.setLabel(wfBean.getLabel());
/* 302 */       hisWfBean.setOpStaffId(wfBean.getOpStaffId());
/* 303 */       hisWfBean.setParentTaskId(wfBean.getParentTaskId());
/* 304 */       hisWfBean.setQueueId(wfBean.getQueueId());
/* 305 */       hisWfBean.setRegionId(wfBean.getRegionId());
/* 306 */       hisWfBean.setStartDate(wfBean.getStartDate());
/* 307 */       hisWfBean.setState(wfBean.getState());
/* 308 */       hisWfBean.setStateDate(wfBean.getStateDate());
/* 309 */       hisWfBean.setTemplateTag(wfBean.getTemplateTag());
/* 310 */       hisWfBean.setTransferDate(transferDate);
/* 311 */       hisWfBean.setUserTaskCount(wfBean.getUserTaskCount());
/* 312 */       hisWfBean.setVars(wfBean.getVars());
/* 313 */       hisWfBean.setWarningDate(wfBean.getWarningDate());
/* 314 */       hisWfBean.setWarningTimes(wfBean.getWarningTimes());
/* 315 */       hisWfBean.setWorkflowObjectId(wfBean.getWorkflowObjectId());
/* 316 */       hisWfBean.setWorkflowObjectType(wfBean.getWorkflowObjectType());
/* 317 */       hisWfBean.setTemplateVersionId(wfBean.getTemplateVersionId());
/* 318 */       hisWfBean.setWorkflowType(wfBean.getWorkflowType());
/* 319 */       hisWfBean.setSuspendState(wfBean.getSuspendState());
/* 320 */       saveHVmWorkflowInstacne(hisWfBean);
/* 321 */       wfBean.delete();
/* 322 */       saveVmWorkflowInstacne(wfBean);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void workflowAttrToHis(String workflowId, Timestamp transferDate) throws Exception
/*     */   {
/* 328 */     IBOVmWFAttrValue[] wfAttrBeans = getVmWorkflowAttrsByWorkflowId(workflowId);
/* 329 */     if ((wfAttrBeans == null) || (wfAttrBeans.length == 0)) {
/* 330 */       return;
/*     */     }
/* 332 */     BOHVmWFAttrBean[] hisWfAttrBeans = new BOHVmWFAttrBean[wfAttrBeans.length];
/* 333 */     BOHVmWFAttrBean hisWfAttrBean = null;
/* 334 */     for (int i = 0; (wfAttrBeans != null) && (i < wfAttrBeans.length); ++i) {
/* 335 */       hisWfAttrBean = new BOHVmWFAttrBean();
/* 336 */       hisWfAttrBean.setAttrId(wfAttrBeans[i].getAttrId());
/* 337 */       hisWfAttrBean.setAttrCode(wfAttrBeans[i].getAttrCode());
/* 338 */       hisWfAttrBean.setAttrName(wfAttrBeans[i].getAttrName());
/* 339 */       hisWfAttrBean.setAttrValue(wfAttrBeans[i].getAttrValue());
/* 340 */       hisWfAttrBean.setCreateDate(wfAttrBeans[i].getCreateDate());
/* 341 */       hisWfAttrBean.setQueueId(wfAttrBeans[i].getQueueId());
/* 342 */       hisWfAttrBean.setRegionId(wfAttrBeans[i].getRegionId());
/* 343 */       hisWfAttrBean.setTransferDate(transferDate);
/* 344 */       hisWfAttrBean.setWorkflowId(wfAttrBeans[i].getWorkflowId());
/* 345 */       TableAssembleUtil.replaceHisTableName(hisWfAttrBean);
/* 346 */       hisWfAttrBeans[i] = hisWfAttrBean;
/* 347 */       wfAttrBeans[i].delete();
/*     */     }
/* 349 */     BOHVmWFAttrEngine.saveBatch(hisWfAttrBeans);
/* 350 */     saveVmWorkflowAttrBeans(wfAttrBeans);
/*     */   }
/*     */ 
/*     */   public IBOHVmWFValue[] getHisWorkflowBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex, String date) throws Exception {
/* 354 */     AssembleDef ad = new AssembleDef();
/* 355 */     ad.setQueueId(queueID);
/* 356 */     ad.setSdate(date);
/* 357 */     BOHVmWFBean vf = new BOHVmWFBean();
/* 358 */     String sql = TableAssembleUtil.createHisSelectSQL(vf, ad, condition, startIndex, endIndex);
/* 359 */     return BOHVmWFEngine.getBeansFromSql(sql, parameter);
/*     */   }
/*     */ 
/*     */   public int getHisWorkflowBeansCount(String queueID, String condition, HashMap parameter, String date) throws Exception {
/* 363 */     AssembleDef ad = new AssembleDef();
/* 364 */     ad.setQueueId(queueID);
/* 365 */     ad.setSdate(date);
/* 366 */     BOHVmWFBean vf = new BOHVmWFBean();
/* 367 */     String sql = TableAssembleUtil.createHisSelectSQL(vf, ad, condition, -1, -1);
/* 368 */     return BOHVmWFEngine.getBeansFromSql(sql, parameter).length;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl
 * JD-Core Version:    0.5.4
 */