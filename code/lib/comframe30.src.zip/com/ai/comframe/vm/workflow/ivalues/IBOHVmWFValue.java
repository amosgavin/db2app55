package com.ai.comframe.vm.workflow.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOHVmWFValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_OpStaffId = "OP_STAFF_ID";
  public static final String S_WorkflowType = "WORKFLOW_TYPE";
  public static final String S_WarningTimes = "WARNING_TIMES";
  public static final String S_StateDate = "STATE_DATE";
  public static final String S_ParentTaskId = "PARENT_TASK_ID";
  public static final String S_CreateStaffId = "CREATE_STAFF_ID";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_WarningDate = "WARNING_DATE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_TransferDate = "TRANSFER_DATE";
  public static final String S_Label = "LABEL";
  public static final String S_WorkflowObjectId = "WORKFLOW_OBJECT_ID";
  public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
  public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
  public static final String S_WorkflowKind = "WORKFLOW_KIND";
  public static final String S_FinishDate = "FINISH_DATE";
  public static final String S_CurrentTaskId = "CURRENT_TASK_ID";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_Duration = "DURATION";
  public static final String S_SuspendState = "SUSPEND_STATE";
  public static final String S_Vars = "VARS";
  public static final String S_ErrorCount = "ERROR_COUNT";
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_EngineType = "ENGINE_TYPE";
  public static final String S_UserTaskCount = "USER_TASK_COUNT";
  public static final String S_ErrorMessage = "ERROR_MESSAGE";
  public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
  public static final String S_Description = "DESCRIPTION";
  public static final String S_StartDate = "START_DATE";

  public abstract int getState();

  public abstract String getOpStaffId();

  public abstract String getWorkflowType();

  public abstract int getWarningTimes();

  public abstract Timestamp getStateDate();

  public abstract String getParentTaskId();

  public abstract String getCreateStaffId();

  public abstract Timestamp getCreateDate();

  public abstract String getTemplateTag();

  public abstract Timestamp getWarningDate();

  public abstract String getRegionId();

  public abstract Timestamp getTransferDate();

  public abstract String getLabel();

  public abstract String getWorkflowObjectId();

  public abstract long getTemplateVersionId();

  public abstract String getWorkflowObjectType();

  public abstract int getWorkflowKind();

  public abstract Timestamp getFinishDate();

  public abstract String getCurrentTaskId();

  public abstract String getQueueId();

  public abstract long getDuration();

  public abstract int getSuspendState();

  public abstract String getVars();

  public abstract int getErrorCount();

  public abstract String getWorkflowId();

  public abstract String getEngineType();

  public abstract long getUserTaskCount();

  public abstract String getErrorMessage();

  public abstract String getEngineWorkflowId();

  public abstract String getDescription();

  public abstract Timestamp getStartDate();

  public abstract void setState(int paramInt);

  public abstract void setOpStaffId(String paramString);

  public abstract void setWorkflowType(String paramString);

  public abstract void setWarningTimes(int paramInt);

  public abstract void setStateDate(Timestamp paramTimestamp);

  public abstract void setParentTaskId(String paramString);

  public abstract void setCreateStaffId(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setTemplateTag(String paramString);

  public abstract void setWarningDate(Timestamp paramTimestamp);

  public abstract void setRegionId(String paramString);

  public abstract void setTransferDate(Timestamp paramTimestamp);

  public abstract void setLabel(String paramString);

  public abstract void setWorkflowObjectId(String paramString);

  public abstract void setTemplateVersionId(long paramLong);

  public abstract void setWorkflowObjectType(String paramString);

  public abstract void setWorkflowKind(int paramInt);

  public abstract void setFinishDate(Timestamp paramTimestamp);

  public abstract void setCurrentTaskId(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setDuration(long paramLong);

  public abstract void setSuspendState(int paramInt);

  public abstract void setVars(String paramString);

  public abstract void setErrorCount(int paramInt);

  public abstract void setWorkflowId(String paramString);

  public abstract void setEngineType(String paramString);

  public abstract void setUserTaskCount(long paramLong);

  public abstract void setErrorMessage(String paramString);

  public abstract void setEngineWorkflowId(String paramString);

  public abstract void setDescription(String paramString);

  public abstract void setStartDate(Timestamp paramTimestamp);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue
 * JD-Core Version:    0.5.4
 */