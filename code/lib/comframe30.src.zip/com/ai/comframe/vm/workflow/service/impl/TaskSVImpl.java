/*     */ package com.ai.comframe.vm.workflow.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.queue.WarningTaskBean;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class TaskSVImpl
/*     */   implements ITaskSV
/*     */ {
/*     */   public void saveVmtaskInstacne(IBOVmTaskValue taskbean)
/*     */     throws RemoteException, Exception
/*     */   {
/*  23 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  24 */     taskDAO.saveVmtaskInstacne(taskbean);
/*     */   }
/*     */ 
/*     */   public IBOVmDealTaskValue[] getVmDealTaskData(String queueId, int mod, int value, int fetchNum, int state)
/*     */     throws RemoteException, Exception
/*     */   {
/*  37 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  38 */     return taskDao.getVmDealTaskData(queueId, mod, value, fetchNum, state);
/*     */   }
/*     */ 
/*     */   public void saveVmDealTask(IBOVmDealTaskValue dealTask)
/*     */     throws RemoteException, Exception
/*     */   {
/*  49 */     if (dealTask == null)
/*     */     {
/*  51 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_saveObjEmpty"));
/*  52 */     }IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  53 */     taskDao.saveVmDealTaskInstance(dealTask);
/*     */   }
/*     */ 
/*     */   public WarningTaskBean[] getWarningTaskData(String queueId, int mod, int value, int fetchNum) throws RemoteException, Exception {
/*  57 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  58 */     return taskDao.getWarningTaskData(queueId, mod, value, fetchNum);
/*     */   }
/*     */ 
/*     */   public WarningTaskBean[] getWarningTaskTsData(String queueId, int mod, int value, int fetchNum) throws RemoteException, Exception {
/*  62 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  63 */     return taskDao.getWarningTaskTsData(queueId, mod, value, fetchNum);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/*  67 */     BOVmTaskBean aTaskbean = new BOVmTaskBean();
/*  68 */     aTaskbean.setTaskId("jxf_0001");
/*  69 */     aTaskbean.setQueueId("jxf");
/*  70 */     aTaskbean.setStsToOld();
/*  71 */     aTaskbean.setDescription("ddddddddddddddd");
/*  72 */     ITaskSV taskSV = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*  73 */     taskSV.saveVmtaskInstacne(aTaskbean);
/*     */   }
/*     */ 
/*     */   public IBOVmDealTaskValue[] getVmDealTask(String taskId) throws RemoteException, Exception {
/*  77 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  78 */     return taskDao.getVmDealTask(taskId);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue getVmTaskByID(String taskID) throws RemoteException, Exception {
/*  82 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  83 */     return taskDAO.getVmTaskbeanById(taskID);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue getVmTaskTSByID(String taskId) throws RemoteException, Exception
/*     */   {
/*  88 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  89 */     return taskDAO.getVmTaskTransBeanById(taskId);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue getVmWFByID(String workflowID) throws RemoteException, Exception {
/*  93 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  94 */     return taskDAO.getVmWFInByID(workflowID);
/*     */   }
/*     */ 
/*     */   public void saveVmTaskInstance(IBOVmTaskValue task) throws RemoteException, Exception {
/*  98 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  99 */     taskDAO.saveVmtaskInstacne(task);
/*     */   }
/*     */ 
/*     */   public void saveVmTaskTSInstance(IBOVmTaskTSValue taskTS) throws RemoteException, Exception {
/* 103 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 104 */     taskDAO.saveVmtaskTransInstacne(taskTS);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue[] getVmTaskBean(String queueID, String cond, HashMap param, int start, int end) throws RemoteException, Exception {
/* 108 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 109 */     return taskDAO.getVmTaskBean(queueID, cond, param, start, end);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue[] getVmTaskTSBean(String queueID, String cond, HashMap param, int start, int end) throws RemoteException, Exception
/*     */   {
/* 114 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 115 */     return taskDAO.getVmTaskTSBean(queueID, cond, param, start, end);
/*     */   }
/*     */   public IBOVmDealTaskValue[] getVmDealTaskbeanByWorkflowId(String workflowId) throws RemoteException, Exception {
/* 118 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 119 */     return taskDAO.getVmDealTaskbeanByWorkflowId(workflowId);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskValue[] getHisVmTaskBean(String queueID, String cond, HashMap param, int start, int end, String date)
/*     */     throws RemoteException, Exception
/*     */   {
/* 131 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*     */ 
/* 133 */     return taskDAO.getHisVmTaskBean(queueID, cond, param, start, end, date);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskTSValue[] getHisVmTaskTSBean(String queueID, String cond, HashMap param, int start, int end, String date) throws RemoteException, Exception {
/* 137 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*     */ 
/* 139 */     return taskDAO.getHisVmTaskTSBean(queueID, cond, param, start, end, date);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue[] getTaskBeans(String workflowId, String taskBaseType) throws RemoteException, Exception {
/* 143 */     StringBuilder cond = new StringBuilder("");
/* 144 */     HashMap param = new HashMap();
/* 145 */     cond.append("WORKFLOW_ID").append(" = :workflowId ");
/* 146 */     cond.append(" and ").append("TASK_BASE_TYPE").append(" = :taskBaseType ");
/* 147 */     param.put("workflowId", workflowId);
/* 148 */     param.put("taskBaseType", taskBaseType);
/* 149 */     return getVmTaskBean(IDAssembleUtil.unwrapPrefix(workflowId), cond.toString(), param, -1, -1);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.impl.TaskSVImpl
 * JD-Core Version:    0.5.4
 */