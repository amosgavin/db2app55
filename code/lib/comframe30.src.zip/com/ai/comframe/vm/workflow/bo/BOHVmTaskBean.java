/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOHVmTaskBean extends DataContainer
/*     */   implements DataContainerInterface, IBOHVmTaskValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOHVmTask";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_ExeFinishDate = "EXE_FINISH_DATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_DestType = "DEST_TYPE";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_LockDate = "LOCK_DATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_TransferDate = "TRANSFER_DATE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_EngineTaskId = "ENGINE_TASK_ID";
/*     */   public static final String S_DestTaskTemplateId = "DEST_TASK_TEMPLATE_ID";
/*     */   public static final String S_TaskStaffId = "TASK_STAFF_ID";
/*     */   public static final String S_TaskBaseType = "TASK_BASE_TYPE";
/*     */   public static final String S_LockStaffId = "LOCK_STAFF_ID";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_ChildWorkflowCount = "CHILD_WORKFLOW_COUNT";
/*     */   public static final String S_RemanentWorkflowCount = "REMANENT_WORKFLOW_COUNT";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StationId = "STATION_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_LastTaskId = "LAST_TASK_ID";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
/*     */   public static final String S_FinishStaffId = "FINISH_STAFF_ID";
/*     */   public static final String S_DecisionResult = "DECISION_RESULT";
/*  54 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOHVmTaskBean()
/*     */     throws AIException
/*     */   {
/*  63 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  67 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  72 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(int value)
/*     */   {
/*  77 */     initProperty("STATE", new Integer(value));
/*     */   }
/*     */   public void setState(int value) {
/*  80 */     set("STATE", new Integer(value));
/*     */   }
/*     */   public void setStateNull() {
/*  83 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public int getState() {
/*  87 */     return DataType.getAsInt(get("STATE"));
/*     */   }
/*     */ 
/*     */   public int getStateInitialValue() {
/*  91 */     return DataType.getAsInt(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initExeFinishDate(Timestamp value) {
/*  95 */     initProperty("EXE_FINISH_DATE", value);
/*     */   }
/*     */   public void setExeFinishDate(Timestamp value) {
/*  98 */     set("EXE_FINISH_DATE", value);
/*     */   }
/*     */   public void setExeFinishDateNull() {
/* 101 */     set("EXE_FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExeFinishDate() {
/* 105 */     return DataType.getAsDateTime(get("EXE_FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExeFinishDateInitialValue() {
/* 109 */     return DataType.getAsDateTime(getOldObj("EXE_FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initWarningTimes(int value) {
/* 113 */     initProperty("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimes(int value) {
/* 116 */     set("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimesNull() {
/* 119 */     set("WARNING_TIMES", null);
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/* 123 */     return DataType.getAsInt(get("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public int getWarningTimesInitialValue() {
/* 127 */     return DataType.getAsInt(getOldObj("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 131 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 134 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 137 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 141 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 145 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 149 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 152 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 155 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 159 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 163 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initDestType(String value) {
/* 167 */     initProperty("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestType(String value) {
/* 170 */     set("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestTypeNull() {
/* 173 */     set("DEST_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getDestType() {
/* 177 */     return DataType.getAsString(get("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getDestTypeInitialValue() {
/* 181 */     return DataType.getAsString(getOldObj("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 185 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 188 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 191 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 195 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 199 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initWarningDate(Timestamp value) {
/* 203 */     initProperty("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDate(Timestamp value) {
/* 206 */     set("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDateNull() {
/* 209 */     set("WARNING_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 213 */     return DataType.getAsDateTime(get("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDateInitialValue() {
/* 217 */     return DataType.getAsDateTime(getOldObj("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLockDate(Timestamp value) {
/* 221 */     initProperty("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDate(Timestamp value) {
/* 224 */     set("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDateNull() {
/* 227 */     set("LOCK_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDate() {
/* 231 */     return DataType.getAsDateTime(get("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDateInitialValue() {
/* 235 */     return DataType.getAsDateTime(getOldObj("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 239 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 242 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 245 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 249 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 253 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initTransferDate(Timestamp value) {
/* 257 */     initProperty("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDate(Timestamp value) {
/* 260 */     set("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDateNull() {
/* 263 */     set("TRANSFER_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDate() {
/* 267 */     return DataType.getAsDateTime(get("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDateInitialValue() {
/* 271 */     return DataType.getAsDateTime(getOldObj("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 275 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 278 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 281 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 285 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 289 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initEngineTaskId(String value) {
/* 293 */     initProperty("ENGINE_TASK_ID", value);
/*     */   }
/*     */   public void setEngineTaskId(String value) {
/* 296 */     set("ENGINE_TASK_ID", value);
/*     */   }
/*     */   public void setEngineTaskIdNull() {
/* 299 */     set("ENGINE_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineTaskId() {
/* 303 */     return DataType.getAsString(get("ENGINE_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineTaskIdInitialValue() {
/* 307 */     return DataType.getAsString(getOldObj("ENGINE_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initDestTaskTemplateId(long value) {
/* 311 */     initProperty("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateId(long value) {
/* 314 */     set("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateIdNull() {
/* 317 */     set("DEST_TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateId() {
/* 321 */     return DataType.getAsLong(get("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateIdInitialValue() {
/* 325 */     return DataType.getAsLong(getOldObj("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskStaffId(String value) {
/* 329 */     initProperty("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffId(String value) {
/* 332 */     set("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffIdNull() {
/* 335 */     set("TASK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskStaffId() {
/* 339 */     return DataType.getAsString(get("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskStaffIdInitialValue() {
/* 343 */     return DataType.getAsString(getOldObj("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskBaseType(String value) {
/* 347 */     initProperty("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseType(String value) {
/* 350 */     set("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseTypeNull() {
/* 353 */     set("TASK_BASE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskBaseType() {
/* 357 */     return DataType.getAsString(get("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskBaseTypeInitialValue() {
/* 361 */     return DataType.getAsString(getOldObj("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initLockStaffId(String value) {
/* 365 */     initProperty("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffId(String value) {
/* 368 */     set("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffIdNull() {
/* 371 */     set("LOCK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLockStaffId() {
/* 375 */     return DataType.getAsString(get("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getLockStaffIdInitialValue() {
/* 379 */     return DataType.getAsString(getOldObj("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initFinishDate(Timestamp value) {
/* 383 */     initProperty("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDate(Timestamp value) {
/* 386 */     set("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDateNull() {
/* 389 */     set("FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 393 */     return DataType.getAsDateTime(get("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDateInitialValue() {
/* 397 */     return DataType.getAsDateTime(getOldObj("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initChildWorkflowCount(long value) {
/* 401 */     initProperty("CHILD_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setChildWorkflowCount(long value) {
/* 404 */     set("CHILD_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setChildWorkflowCountNull() {
/* 407 */     set("CHILD_WORKFLOW_COUNT", null);
/*     */   }
/*     */ 
/*     */   public long getChildWorkflowCount() {
/* 411 */     return DataType.getAsLong(get("CHILD_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public long getChildWorkflowCountInitialValue() {
/* 415 */     return DataType.getAsLong(getOldObj("CHILD_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initRemanentWorkflowCount(long value) {
/* 419 */     initProperty("REMANENT_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setRemanentWorkflowCount(long value) {
/* 422 */     set("REMANENT_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setRemanentWorkflowCountNull() {
/* 425 */     set("REMANENT_WORKFLOW_COUNT", null);
/*     */   }
/*     */ 
/*     */   public long getRemanentWorkflowCount() {
/* 429 */     return DataType.getAsLong(get("REMANENT_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public long getRemanentWorkflowCountInitialValue() {
/* 433 */     return DataType.getAsLong(getOldObj("REMANENT_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initTaskTemplateId(long value) {
/* 437 */     initProperty("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateId(long value) {
/* 440 */     set("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateIdNull() {
/* 443 */     set("TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 447 */     return DataType.getAsLong(get("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateIdInitialValue() {
/* 451 */     return DataType.getAsLong(getOldObj("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 455 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 458 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 461 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 465 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 469 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStationId(String value) {
/* 473 */     initProperty("STATION_ID", value);
/*     */   }
/*     */   public void setStationId(String value) {
/* 476 */     set("STATION_ID", value);
/*     */   }
/*     */   public void setStationIdNull() {
/* 479 */     set("STATION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/* 483 */     return DataType.getAsString(get("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public String getStationIdInitialValue() {
/* 487 */     return DataType.getAsString(getOldObj("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public void initDuration(long value) {
/* 491 */     initProperty("DURATION", new Long(value));
/*     */   }
/*     */   public void setDuration(long value) {
/* 494 */     set("DURATION", new Long(value));
/*     */   }
/*     */   public void setDurationNull() {
/* 497 */     set("DURATION", null);
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 501 */     return DataType.getAsLong(get("DURATION"));
/*     */   }
/*     */ 
/*     */   public long getDurationInitialValue() {
/* 505 */     return DataType.getAsLong(getOldObj("DURATION"));
/*     */   }
/*     */ 
/*     */   public void initTaskType(String value) {
/* 509 */     initProperty("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskType(String value) {
/* 512 */     set("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskTypeNull() {
/* 515 */     set("TASK_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 519 */     return DataType.getAsString(get("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskTypeInitialValue() {
/* 523 */     return DataType.getAsString(getOldObj("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value) {
/* 527 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/* 530 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/* 533 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 537 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/* 541 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 545 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 548 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 551 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 555 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 559 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initEngineWorkflowId(String value) {
/* 563 */     initProperty("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowId(String value) {
/* 566 */     set("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowIdNull() {
/* 569 */     set("ENGINE_WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 573 */     return DataType.getAsString(get("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowIdInitialValue() {
/* 577 */     return DataType.getAsString(getOldObj("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initLastTaskId(String value) {
/* 581 */     initProperty("LAST_TASK_ID", value);
/*     */   }
/*     */   public void setLastTaskId(String value) {
/* 584 */     set("LAST_TASK_ID", value);
/*     */   }
/*     */   public void setLastTaskIdNull() {
/* 587 */     set("LAST_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLastTaskId() {
/* 591 */     return DataType.getAsString(get("LAST_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getLastTaskIdInitialValue() {
/* 595 */     return DataType.getAsString(getOldObj("LAST_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 599 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 602 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 605 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 609 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 613 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 617 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 620 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 623 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 627 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 631 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initIsCurrentTask(String value) {
/* 635 */     initProperty("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTask(String value) {
/* 638 */     set("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTaskNull() {
/* 641 */     set("IS_CURRENT_TASK", null);
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTask() {
/* 645 */     return DataType.getAsString(get("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTaskInitialValue() {
/* 649 */     return DataType.getAsString(getOldObj("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public void initFinishStaffId(String value) {
/* 653 */     initProperty("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffId(String value) {
/* 656 */     set("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffIdNull() {
/* 659 */     set("FINISH_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getFinishStaffId() {
/* 663 */     return DataType.getAsString(get("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getFinishStaffIdInitialValue() {
/* 667 */     return DataType.getAsString(getOldObj("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initDecisionResult(String value) {
/* 671 */     initProperty("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResult(String value) {
/* 674 */     set("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResultNull() {
/* 677 */     set("DECISION_RESULT", null);
/*     */   }
/*     */ 
/*     */   public String getDecisionResult() {
/* 681 */     return DataType.getAsString(get("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   public String getDecisionResultInitialValue() {
/* 685 */     return DataType.getAsString(getOldObj("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  57 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  59 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOHVmTaskBean
 * JD-Core Version:    0.5.4
 */