/*     */ package com.ai.comframe.vm.workflow.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.queue.WarningTaskBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class VmWorkflowSVImpl
/*     */   implements IVmWorkflowSV
/*     */ {
/*     */   public String getNewWorkFlowAttrId(String queueId, String regionId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  28 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  29 */     return wfDao.getNewWorkFlowAttrId(queueId, regionId);
/*     */   }
/*     */ 
/*     */   public String getNewWorkFlowId(String queueId, String regionId) throws RemoteException, Exception {
/*  33 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  34 */     return wfDao.getNewWorkFlowId(queueId, regionId);
/*     */   }
/*     */ 
/*     */   public IBOVmWFAttrValue[] getVmWorkflowAttrsByWorkflowId(String workflowId)
/*     */     throws RemoteException, Exception
/*     */   {
/*  44 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  45 */     return wfDao.getVmWorkflowAttrsByWorkflowId(workflowId);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue getVmWorkflowBeanbyId(String workflowId) throws RemoteException, Exception {
/*  49 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  50 */     return wfDao.getVmWorkflowBeanbyId(workflowId);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue[] getWorkflowBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*     */     throws RemoteException, Exception
/*     */   {
/*  61 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  62 */     return wfDao.getWorkflowBeans(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public int getWorkflowBeansCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/*  66 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  67 */     return wfDao.getWorkflowBeansCount(queueID, condition, parameter);
/*     */   }
/*     */ 
/*     */   public IBOHVmWFValue[] getHisWorkflowBeans(String queueID, String condition, HashMap parameter, int startIndex, int endIndex, String date) throws RemoteException, Exception {
/*  71 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  72 */     return wfDao.getHisWorkflowBeans(queueID, condition, parameter, startIndex, endIndex, date);
/*     */   }
/*     */ 
/*     */   public int getHisWorkflowBeansCount(String queueID, String condition, HashMap parameter, String date) throws RemoteException, Exception {
/*  76 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  77 */     return wfDao.getHisWorkflowBeansCount(queueID, condition, parameter, date);
/*     */   }
/*     */ 
/*     */   public void saveVmWorkflowAttrBeans(IBOVmWFAttrValue[] attrs)
/*     */     throws RemoteException, Exception
/*     */   {
/*  87 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  88 */     wfDao.saveVmWorkflowAttrBeans(attrs);
/*     */   }
/*     */ 
/*     */   public void saveVmWorkflowInstacne(IBOVmWFValue workflowbean) throws RemoteException, Exception
/*     */   {
/*  93 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  94 */     wfDao.saveVmWorkflowInstacne(workflowbean);
/*     */   }
/*     */ 
/*     */   public WarningTaskBean[] getWarningWorkflowData(String queueId, int mod, int value, int fetchNum)
/*     */     throws RemoteException, Exception
/*     */   {
/* 107 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 108 */     IBOVmWFValue[] values = wfDao.getWarningWorkflowData(queueId, mod, value, fetchNum);
/* 109 */     WarningTaskBean[] result = null;
/* 110 */     if ((values != null) && (values.length > 0)) {
/* 111 */       result = new WarningTaskBean[values.length];
/* 112 */       for (int i = 0; i < result.length; ++i) {
/* 113 */         result[i] = new WarningTaskBean();
/* 114 */         result[i].setTaskId(values[i].getWorkflowId());
/* 115 */         result[i].setStaffId(values[i].getCreateStaffId());
/* 116 */         result[i].setWorkflowObjId(values[i].getWorkflowObjectId());
/* 117 */         result[i].setWorkflowObjTypeId(values[i].getWorkflowObjectId());
/* 118 */         result[i].setAlarmtimes(values[i].getWarningTimes());
/* 119 */         result[i].setDuration(values[i].getDuration());
/* 120 */         result[i].setTemplateTag(values[i].getTemplateTag());
/* 121 */         result[i].setRegionId(values[i].getRegionId());
/* 122 */         result[i].setType("workflow");
/*     */       }
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.impl.VmWorkflowSVImpl
 * JD-Core Version:    0.5.4
 */