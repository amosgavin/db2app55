package com.ai.comframe.vm.workflow.dao.interfaces;

import com.ai.comframe.queue.WarningTaskBean;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface IVmTaskDAO
{
  public abstract void saveVmtaskInstacne(IBOVmTaskValue paramIBOVmTaskValue)
    throws Exception;

  public abstract void saveVmDealTaskInstance(IBOVmDealTaskValue paramIBOVmDealTaskValue)
    throws Exception;

  public abstract void saveVmtaskTransInstacne(IBOVmTaskTSValue paramIBOVmTaskTSValue)
    throws Exception;

  public abstract void saveHVmtaskInstacne(IBOHVmTaskValue paramIBOHVmTaskValue)
    throws Exception;

  public abstract void saveVmtaskTransInstacnes(IBOVmTaskTSValue[] paramArrayOfIBOVmTaskTSValue)
    throws Exception;

  public abstract void saveHVmtaskTransInstacne(IBOHVmTaskTSValue paramIBOHVmTaskTSValue)
    throws Exception;

  public abstract String getNewTaskId(String paramString1, String paramString2)
    throws Exception;

  public abstract String getNewTaskTransId(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmTaskValue getVmTaskbeanById(String paramString)
    throws Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTaskbeanByWorkflowId(String paramString)
    throws Exception;

  public abstract IBOVmTaskValue getVmTaskbeanById(String paramString, int[] paramArrayOfInt)
    throws Exception;

  public abstract IBOVmTaskTSValue getVmTaskTransBeanById(String paramString)
    throws Exception;

  public abstract IBOVmTaskTSValue[] getVmTaskTransBeans(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOHVmTaskTSValue[] getHVmTaskTransBeans(String paramString)
    throws Exception;

  public abstract IBOVmTaskValue[] getVmTaskbeanByWorkflowId(String paramString)
    throws Exception;

  public abstract IBOHVmTaskValue[] getHVmTaskbeanByWorkflowId(String paramString)
    throws Exception;

  public abstract IBOHVmTaskValue[] getHVmTaskbeanByWorkflowId(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTaskData(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws Exception;

  public abstract WarningTaskBean[] getWarningTaskData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws Exception;

  public abstract WarningTaskBean[] getWarningTaskTsData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTask(String paramString)
    throws Exception;

  public abstract void taskToHis(String paramString, Timestamp paramTimestamp)
    throws Exception;

  public abstract void taskTSToHis(String paramString, Timestamp paramTimestamp)
    throws Exception;

  public abstract IBOVmWFValue getVmWFInByID(String paramString)
    throws Exception;

  public abstract IBOVmTaskTSValue[] getTaskTransBeansParentOrWorkflowId(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmTaskValue[] getAllChildWorkflowTasks(String paramString)
    throws Exception;

  public abstract IBOVmTaskValue[] getVmTaskBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract IBOVmTaskTSValue[] getVmTaskTSBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract IBOHVmTaskValue[] getHisVmTaskBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws Exception;

  public abstract IBOHVmTaskTSValue[] getHisVmTaskTSBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO
 * JD-Core Version:    0.5.4
 */