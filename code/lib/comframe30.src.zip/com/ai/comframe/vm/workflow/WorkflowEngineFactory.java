/*   */ package com.ai.comframe.vm.workflow;
/*   */ 
/*   */ import com.ai.appframe2.service.ServiceFactory;
/*   */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*   */ 
/*   */ public class WorkflowEngineFactory
/*   */ {
/*   */   public static IWorkflowEngineSV getInstance()
/*   */     throws Exception
/*   */   {
/* 9 */     return (IWorkflowEngineSV)ServiceFactory.getService(IWorkflowEngineSV.class);
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.WorkflowEngineFactory
 * JD-Core Version:    0.5.4
 */