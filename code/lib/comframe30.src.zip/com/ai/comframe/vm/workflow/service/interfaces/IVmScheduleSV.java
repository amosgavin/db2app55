package com.ai.comframe.vm.workflow.service.interfaces;

import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
import java.rmi.RemoteException;

public abstract interface IVmScheduleSV
{
  public abstract IBOVmScheduleValue[] getVmScheduleData(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, String paramString3)
    throws RemoteException, Exception;

  public abstract void saveVmSchedule(IBOVmScheduleValue paramIBOVmScheduleValue)
    throws RemoteException, Exception;

  public abstract void saveVmSchedule(IBOVmScheduleValue[] paramArrayOfIBOVmScheduleValue)
    throws RemoteException, Exception;

  public abstract IBOVmScheduleValue getVmScheduleByWorkflowId(String paramString)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.interfaces.IVmScheduleSV
 * JD-Core Version:    0.5.4
 */