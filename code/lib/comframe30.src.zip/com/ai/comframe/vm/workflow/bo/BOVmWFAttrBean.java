/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmWFAttrBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmWFAttrValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOVmWFAttr";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_AttrName = "ATTR_NAME";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_AttrCode = "ATTR_CODE";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_AttrId = "ATTR_ID";
/*     */   public static final String S_AttrValue = "ATTR_VALUE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*  28 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmWFAttrBean()
/*     */     throws AIException
/*     */   {
/*  37 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  41 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  46 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value)
/*     */   {
/*  51 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/*  54 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/*  57 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/*  61 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/*  65 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrName(String value) {
/*  69 */     initProperty("ATTR_NAME", value);
/*     */   }
/*     */   public void setAttrName(String value) {
/*  72 */     set("ATTR_NAME", value);
/*     */   }
/*     */   public void setAttrNameNull() {
/*  75 */     set("ATTR_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getAttrName() {
/*  79 */     return DataType.getAsString(get("ATTR_NAME"));
/*     */   }
/*     */ 
/*     */   public String getAttrNameInitialValue() {
/*  83 */     return DataType.getAsString(getOldObj("ATTR_NAME"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/*  87 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/*  90 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/*  93 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/*  97 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 101 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrCode(String value) {
/* 105 */     initProperty("ATTR_CODE", value);
/*     */   }
/*     */   public void setAttrCode(String value) {
/* 108 */     set("ATTR_CODE", value);
/*     */   }
/*     */   public void setAttrCodeNull() {
/* 111 */     set("ATTR_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getAttrCode() {
/* 115 */     return DataType.getAsString(get("ATTR_CODE"));
/*     */   }
/*     */ 
/*     */   public String getAttrCodeInitialValue() {
/* 119 */     return DataType.getAsString(getOldObj("ATTR_CODE"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 123 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 126 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 129 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 133 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 137 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrId(long value) {
/* 141 */     initProperty("ATTR_ID", new Long(value));
/*     */   }
/*     */   public void setAttrId(long value) {
/* 144 */     set("ATTR_ID", new Long(value));
/*     */   }
/*     */   public void setAttrIdNull() {
/* 147 */     set("ATTR_ID", null);
/*     */   }
/*     */ 
/*     */   public long getAttrId() {
/* 151 */     return DataType.getAsLong(get("ATTR_ID"));
/*     */   }
/*     */ 
/*     */   public long getAttrIdInitialValue() {
/* 155 */     return DataType.getAsLong(getOldObj("ATTR_ID"));
/*     */   }
/*     */ 
/*     */   public void initAttrValue(String value) {
/* 159 */     initProperty("ATTR_VALUE", value);
/*     */   }
/*     */   public void setAttrValue(String value) {
/* 162 */     set("ATTR_VALUE", value);
/*     */   }
/*     */   public void setAttrValueNull() {
/* 165 */     set("ATTR_VALUE", null);
/*     */   }
/*     */ 
/*     */   public String getAttrValue() {
/* 169 */     return DataType.getAsString(get("ATTR_VALUE"));
/*     */   }
/*     */ 
/*     */   public String getAttrValueInitialValue() {
/* 173 */     return DataType.getAsString(getOldObj("ATTR_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 177 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 180 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 183 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 187 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 191 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  31 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  33 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOVmWFAttrBean
 * JD-Core Version:    0.5.4
 */