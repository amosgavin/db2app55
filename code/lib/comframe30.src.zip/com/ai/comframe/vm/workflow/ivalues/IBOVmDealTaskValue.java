package com.ai.comframe.vm.workflow.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmDealTaskValue extends DataStructInterface
{
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_State = "STATE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_Runtime = "RUNTIME";
  public static final String S_ErrorMessage = "ERROR_MESSAGE";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_DealTaskId = "DEAL_TASK_ID";
  public static final String S_TaskId = "TASK_ID";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_DevId = "DEV_ID";
  public static final String S_DealType = "DEAL_TYPE";

  public abstract String getWorkflowId();

  public abstract int getState();

  public abstract String getRegionId();

  public abstract Timestamp getRuntime();

  public abstract String getErrorMessage();

  public abstract String getQueueId();

  public abstract String getDealTaskId();

  public abstract String getTaskId();

  public abstract Timestamp getCreateDate();

  public abstract String getDevId();

  public abstract String getDealType();

  public abstract void setWorkflowId(String paramString);

  public abstract void setState(int paramInt);

  public abstract void setRegionId(String paramString);

  public abstract void setRuntime(Timestamp paramTimestamp);

  public abstract void setErrorMessage(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setDealTaskId(String paramString);

  public abstract void setTaskId(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setDevId(String paramString);

  public abstract void setDealType(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue
 * JD-Core Version:    0.5.4
 */