package com.ai.comframe.vm.workflow.dao.interfaces;

import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;

public abstract interface IVmScheduleDAO
{
  public abstract IBOVmScheduleValue[] getVmScheduleData(String paramString1, String paramString2, int paramInt1, int paramInt2, int paramInt3, String paramString3)
    throws Exception;

  public abstract void saveVmSchedule(IBOVmScheduleValue paramIBOVmScheduleValue)
    throws Exception;

  public abstract void saveVmSchedule(IBOVmScheduleValue[] paramArrayOfIBOVmScheduleValue)
    throws Exception;

  public abstract IBOVmScheduleValue getVmScheduleByWorkflowId(String paramString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.interfaces.IVmScheduleDAO
 * JD-Core Version:    0.5.4
 */