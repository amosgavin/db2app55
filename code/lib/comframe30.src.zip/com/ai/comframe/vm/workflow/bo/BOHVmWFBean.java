/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOHVmWFBean extends DataContainer
/*     */   implements DataContainerInterface, IBOHVmWFValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOHVmWF";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_OpStaffId = "OP_STAFF_ID";
/*     */   public static final String S_WorkflowType = "WORKFLOW_TYPE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateStaffId = "CREATE_STAFF_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_TransferDate = "TRANSFER_DATE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_WorkflowObjectId = "WORKFLOW_OBJECT_ID";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*     */   public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
/*     */   public static final String S_WorkflowKind = "WORKFLOW_KIND";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_CurrentTaskId = "CURRENT_TASK_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_SuspendState = "SUSPEND_STATE";
/*     */   public static final String S_Vars = "VARS";
/*     */   public static final String S_ErrorCount = "ERROR_COUNT";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_UserTaskCount = "USER_TASK_COUNT";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_StartDate = "START_DATE";
/*  51 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOHVmWFBean()
/*     */     throws AIException
/*     */   {
/*  60 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  64 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  69 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(int value)
/*     */   {
/*  74 */     initProperty("STATE", new Integer(value));
/*     */   }
/*     */   public void setState(int value) {
/*  77 */     set("STATE", new Integer(value));
/*     */   }
/*     */   public void setStateNull() {
/*  80 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public int getState() {
/*  84 */     return DataType.getAsInt(get("STATE"));
/*     */   }
/*     */ 
/*     */   public int getStateInitialValue() {
/*  88 */     return DataType.getAsInt(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initOpStaffId(String value) {
/*  92 */     initProperty("OP_STAFF_ID", value);
/*     */   }
/*     */   public void setOpStaffId(String value) {
/*  95 */     set("OP_STAFF_ID", value);
/*     */   }
/*     */   public void setOpStaffIdNull() {
/*  98 */     set("OP_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getOpStaffId() {
/* 102 */     return DataType.getAsString(get("OP_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getOpStaffIdInitialValue() {
/* 106 */     return DataType.getAsString(getOldObj("OP_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowType(String value) {
/* 110 */     initProperty("WORKFLOW_TYPE", value);
/*     */   }
/*     */   public void setWorkflowType(String value) {
/* 113 */     set("WORKFLOW_TYPE", value);
/*     */   }
/*     */   public void setWorkflowTypeNull() {
/* 116 */     set("WORKFLOW_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowType() {
/* 120 */     return DataType.getAsString(get("WORKFLOW_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowTypeInitialValue() {
/* 124 */     return DataType.getAsString(getOldObj("WORKFLOW_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWarningTimes(int value) {
/* 128 */     initProperty("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimes(int value) {
/* 131 */     set("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimesNull() {
/* 134 */     set("WARNING_TIMES", null);
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/* 138 */     return DataType.getAsInt(get("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public int getWarningTimesInitialValue() {
/* 142 */     return DataType.getAsInt(getOldObj("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 146 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 149 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 152 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 156 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 160 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initParentTaskId(String value) {
/* 164 */     initProperty("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskId(String value) {
/* 167 */     set("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskIdNull() {
/* 170 */     set("PARENT_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 174 */     return DataType.getAsString(get("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getParentTaskIdInitialValue() {
/* 178 */     return DataType.getAsString(getOldObj("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateStaffId(String value) {
/* 182 */     initProperty("CREATE_STAFF_ID", value);
/*     */   }
/*     */   public void setCreateStaffId(String value) {
/* 185 */     set("CREATE_STAFF_ID", value);
/*     */   }
/*     */   public void setCreateStaffIdNull() {
/* 188 */     set("CREATE_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getCreateStaffId() {
/* 192 */     return DataType.getAsString(get("CREATE_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getCreateStaffIdInitialValue() {
/* 196 */     return DataType.getAsString(getOldObj("CREATE_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 200 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 203 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 206 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 210 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 214 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 218 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 221 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 224 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 228 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 232 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initWarningDate(Timestamp value) {
/* 236 */     initProperty("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDate(Timestamp value) {
/* 239 */     set("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDateNull() {
/* 242 */     set("WARNING_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 246 */     return DataType.getAsDateTime(get("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDateInitialValue() {
/* 250 */     return DataType.getAsDateTime(getOldObj("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 254 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 257 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 260 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 264 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 268 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initTransferDate(Timestamp value) {
/* 272 */     initProperty("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDate(Timestamp value) {
/* 275 */     set("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDateNull() {
/* 278 */     set("TRANSFER_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDate() {
/* 282 */     return DataType.getAsDateTime(get("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDateInitialValue() {
/* 286 */     return DataType.getAsDateTime(getOldObj("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 290 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 293 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 296 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 300 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 304 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowObjectId(String value) {
/* 308 */     initProperty("WORKFLOW_OBJECT_ID", value);
/*     */   }
/*     */   public void setWorkflowObjectId(String value) {
/* 311 */     set("WORKFLOW_OBJECT_ID", value);
/*     */   }
/*     */   public void setWorkflowObjectIdNull() {
/* 314 */     set("WORKFLOW_OBJECT_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectId() {
/* 318 */     return DataType.getAsString(get("WORKFLOW_OBJECT_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectIdInitialValue() {
/* 322 */     return DataType.getAsString(getOldObj("WORKFLOW_OBJECT_ID"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 326 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 329 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 332 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 336 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 340 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowObjectType(String value) {
/* 344 */     initProperty("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectType(String value) {
/* 347 */     set("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectTypeNull() {
/* 350 */     set("WORKFLOW_OBJECT_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectType() {
/* 354 */     return DataType.getAsString(get("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectTypeInitialValue() {
/* 358 */     return DataType.getAsString(getOldObj("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowKind(int value) {
/* 362 */     initProperty("WORKFLOW_KIND", new Integer(value));
/*     */   }
/*     */   public void setWorkflowKind(int value) {
/* 365 */     set("WORKFLOW_KIND", new Integer(value));
/*     */   }
/*     */   public void setWorkflowKindNull() {
/* 368 */     set("WORKFLOW_KIND", null);
/*     */   }
/*     */ 
/*     */   public int getWorkflowKind() {
/* 372 */     return DataType.getAsInt(get("WORKFLOW_KIND"));
/*     */   }
/*     */ 
/*     */   public int getWorkflowKindInitialValue() {
/* 376 */     return DataType.getAsInt(getOldObj("WORKFLOW_KIND"));
/*     */   }
/*     */ 
/*     */   public void initFinishDate(Timestamp value) {
/* 380 */     initProperty("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDate(Timestamp value) {
/* 383 */     set("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDateNull() {
/* 386 */     set("FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 390 */     return DataType.getAsDateTime(get("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDateInitialValue() {
/* 394 */     return DataType.getAsDateTime(getOldObj("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCurrentTaskId(String value) {
/* 398 */     initProperty("CURRENT_TASK_ID", value);
/*     */   }
/*     */   public void setCurrentTaskId(String value) {
/* 401 */     set("CURRENT_TASK_ID", value);
/*     */   }
/*     */   public void setCurrentTaskIdNull() {
/* 404 */     set("CURRENT_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getCurrentTaskId() {
/* 408 */     return DataType.getAsString(get("CURRENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getCurrentTaskIdInitialValue() {
/* 412 */     return DataType.getAsString(getOldObj("CURRENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 416 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 419 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 422 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 426 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 430 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initDuration(long value) {
/* 434 */     initProperty("DURATION", new Long(value));
/*     */   }
/*     */   public void setDuration(long value) {
/* 437 */     set("DURATION", new Long(value));
/*     */   }
/*     */   public void setDurationNull() {
/* 440 */     set("DURATION", null);
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 444 */     return DataType.getAsLong(get("DURATION"));
/*     */   }
/*     */ 
/*     */   public long getDurationInitialValue() {
/* 448 */     return DataType.getAsLong(getOldObj("DURATION"));
/*     */   }
/*     */ 
/*     */   public void initSuspendState(int value) {
/* 452 */     initProperty("SUSPEND_STATE", new Integer(value));
/*     */   }
/*     */   public void setSuspendState(int value) {
/* 455 */     set("SUSPEND_STATE", new Integer(value));
/*     */   }
/*     */   public void setSuspendStateNull() {
/* 458 */     set("SUSPEND_STATE", null);
/*     */   }
/*     */ 
/*     */   public int getSuspendState() {
/* 462 */     return DataType.getAsInt(get("SUSPEND_STATE"));
/*     */   }
/*     */ 
/*     */   public int getSuspendStateInitialValue() {
/* 466 */     return DataType.getAsInt(getOldObj("SUSPEND_STATE"));
/*     */   }
/*     */ 
/*     */   public void initVars(String value) {
/* 470 */     initProperty("VARS", value);
/*     */   }
/*     */   public void setVars(String value) {
/* 473 */     set("VARS", value);
/*     */   }
/*     */   public void setVarsNull() {
/* 476 */     set("VARS", null);
/*     */   }
/*     */ 
/*     */   public String getVars() {
/* 480 */     return DataType.getAsString(get("VARS"));
/*     */   }
/*     */ 
/*     */   public String getVarsInitialValue() {
/* 484 */     return DataType.getAsString(getOldObj("VARS"));
/*     */   }
/*     */ 
/*     */   public void initErrorCount(int value) {
/* 488 */     initProperty("ERROR_COUNT", new Integer(value));
/*     */   }
/*     */   public void setErrorCount(int value) {
/* 491 */     set("ERROR_COUNT", new Integer(value));
/*     */   }
/*     */   public void setErrorCountNull() {
/* 494 */     set("ERROR_COUNT", null);
/*     */   }
/*     */ 
/*     */   public int getErrorCount() {
/* 498 */     return DataType.getAsInt(get("ERROR_COUNT"));
/*     */   }
/*     */ 
/*     */   public int getErrorCountInitialValue() {
/* 502 */     return DataType.getAsInt(getOldObj("ERROR_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value) {
/* 506 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/* 509 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/* 512 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 516 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/* 520 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initEngineType(String value) {
/* 524 */     initProperty("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineType(String value) {
/* 527 */     set("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineTypeNull() {
/* 530 */     set("ENGINE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/* 534 */     return DataType.getAsString(get("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getEngineTypeInitialValue() {
/* 538 */     return DataType.getAsString(getOldObj("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initUserTaskCount(long value) {
/* 542 */     initProperty("USER_TASK_COUNT", new Long(value));
/*     */   }
/*     */   public void setUserTaskCount(long value) {
/* 545 */     set("USER_TASK_COUNT", new Long(value));
/*     */   }
/*     */   public void setUserTaskCountNull() {
/* 548 */     set("USER_TASK_COUNT", null);
/*     */   }
/*     */ 
/*     */   public long getUserTaskCount() {
/* 552 */     return DataType.getAsLong(get("USER_TASK_COUNT"));
/*     */   }
/*     */ 
/*     */   public long getUserTaskCountInitialValue() {
/* 556 */     return DataType.getAsLong(getOldObj("USER_TASK_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 560 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 563 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 566 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 570 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 574 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initEngineWorkflowId(String value) {
/* 578 */     initProperty("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowId(String value) {
/* 581 */     set("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowIdNull() {
/* 584 */     set("ENGINE_WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 588 */     return DataType.getAsString(get("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowIdInitialValue() {
/* 592 */     return DataType.getAsString(getOldObj("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 596 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 599 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 602 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 606 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 610 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initStartDate(Timestamp value) {
/* 614 */     initProperty("START_DATE", value);
/*     */   }
/*     */   public void setStartDate(Timestamp value) {
/* 617 */     set("START_DATE", value);
/*     */   }
/*     */   public void setStartDateNull() {
/* 620 */     set("START_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStartDate() {
/* 624 */     return DataType.getAsDateTime(get("START_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStartDateInitialValue() {
/* 628 */     return DataType.getAsDateTime(getOldObj("START_DATE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  54 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  56 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOHVmWFBean
 * JD-Core Version:    0.5.4
 */