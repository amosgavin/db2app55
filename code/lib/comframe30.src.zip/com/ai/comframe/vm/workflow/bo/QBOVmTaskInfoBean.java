/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IQBOVmTaskInfoValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class QBOVmTaskInfoBean extends DataContainer
/*     */   implements DataContainerInterface, IQBOVmTaskInfoValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.QBOVmTaskInfo";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_ExeFinishDate = "EXE_FINISH_DATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_WorkflowName = "WORKFLOW_NAME";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_LockDate = "LOCK_DATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_WorkflowObjectId = "WORKFLOW_OBJECT_ID";
/*     */   public static final String S_TemplateVersionId = "TEMPLATE_VERSION_ID";
/*     */   public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
/*     */   public static final String S_EngineTaskId = "ENGINE_TASK_ID";
/*     */   public static final String S_TaskStaffId = "TASK_STAFF_ID";
/*     */   public static final String S_TaskBaseType = "TASK_BASE_TYPE";
/*     */   public static final String S_LockStaffId = "LOCK_STAFF_ID";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_ChildWorkflowCount = "CHILD_WORKFLOW_COUNT";
/*     */   public static final String S_RemanentWorkflowCount = "REMANENT_WORKFLOW_COUNT";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StationId = "STATION_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_LastTaskId = "LAST_TASK_ID";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_WorkflowState = "WORKFLOW_STATE";
/*     */   public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
/*     */   public static final String S_FinishStaffId = "FINISH_STAFF_ID";
/*     */   public static final String S_DecisionResult = "DECISION_RESULT";
/*  58 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public QBOVmTaskInfoBean()
/*     */     throws AIException
/*     */   {
/*  67 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  71 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  76 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(long value)
/*     */   {
/*  81 */     initProperty("STATE", new Long(value));
/*     */   }
/*     */   public void setState(long value) {
/*  84 */     set("STATE", new Long(value));
/*     */   }
/*     */   public void setStateNull() {
/*  87 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public long getState() {
/*  91 */     return DataType.getAsLong(get("STATE"));
/*     */   }
/*     */ 
/*     */   public long getStateInitialValue() {
/*  95 */     return DataType.getAsLong(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initExeFinishDate(Timestamp value) {
/*  99 */     initProperty("EXE_FINISH_DATE", value);
/*     */   }
/*     */   public void setExeFinishDate(Timestamp value) {
/* 102 */     set("EXE_FINISH_DATE", value);
/*     */   }
/*     */   public void setExeFinishDateNull() {
/* 105 */     set("EXE_FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExeFinishDate() {
/* 109 */     return DataType.getAsDateTime(get("EXE_FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExeFinishDateInitialValue() {
/* 113 */     return DataType.getAsDateTime(getOldObj("EXE_FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initWarningTimes(long value) {
/* 117 */     initProperty("WARNING_TIMES", new Long(value));
/*     */   }
/*     */   public void setWarningTimes(long value) {
/* 120 */     set("WARNING_TIMES", new Long(value));
/*     */   }
/*     */   public void setWarningTimesNull() {
/* 123 */     set("WARNING_TIMES", null);
/*     */   }
/*     */ 
/*     */   public long getWarningTimes() {
/* 127 */     return DataType.getAsLong(get("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public long getWarningTimesInitialValue() {
/* 131 */     return DataType.getAsLong(getOldObj("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 135 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 138 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 141 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 145 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 149 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initParentTaskId(String value) {
/* 153 */     initProperty("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskId(String value) {
/* 156 */     set("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskIdNull() {
/* 159 */     set("PARENT_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 163 */     return DataType.getAsString(get("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getParentTaskIdInitialValue() {
/* 167 */     return DataType.getAsString(getOldObj("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 171 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 174 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 177 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 181 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 185 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowName(String value) {
/* 189 */     initProperty("WORKFLOW_NAME", value);
/*     */   }
/*     */   public void setWorkflowName(String value) {
/* 192 */     set("WORKFLOW_NAME", value);
/*     */   }
/*     */   public void setWorkflowNameNull() {
/* 195 */     set("WORKFLOW_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowName() {
/* 199 */     return DataType.getAsString(get("WORKFLOW_NAME"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowNameInitialValue() {
/* 203 */     return DataType.getAsString(getOldObj("WORKFLOW_NAME"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 207 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 210 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 213 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 217 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 221 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 225 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 228 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 231 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 235 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 239 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initWarningDate(Timestamp value) {
/* 243 */     initProperty("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDate(Timestamp value) {
/* 246 */     set("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDateNull() {
/* 249 */     set("WARNING_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 253 */     return DataType.getAsDateTime(get("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDateInitialValue() {
/* 257 */     return DataType.getAsDateTime(getOldObj("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLockDate(Timestamp value) {
/* 261 */     initProperty("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDate(Timestamp value) {
/* 264 */     set("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDateNull() {
/* 267 */     set("LOCK_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDate() {
/* 271 */     return DataType.getAsDateTime(get("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDateInitialValue() {
/* 275 */     return DataType.getAsDateTime(getOldObj("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 279 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 282 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 285 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 289 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 293 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 297 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 300 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 303 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 307 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 311 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowObjectId(String value) {
/* 315 */     initProperty("WORKFLOW_OBJECT_ID", value);
/*     */   }
/*     */   public void setWorkflowObjectId(String value) {
/* 318 */     set("WORKFLOW_OBJECT_ID", value);
/*     */   }
/*     */   public void setWorkflowObjectIdNull() {
/* 321 */     set("WORKFLOW_OBJECT_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectId() {
/* 325 */     return DataType.getAsString(get("WORKFLOW_OBJECT_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectIdInitialValue() {
/* 329 */     return DataType.getAsString(getOldObj("WORKFLOW_OBJECT_ID"));
/*     */   }
/*     */ 
/*     */   public void initTemplateVersionId(long value) {
/* 333 */     initProperty("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionId(long value) {
/* 336 */     set("TEMPLATE_VERSION_ID", new Long(value));
/*     */   }
/*     */   public void setTemplateVersionIdNull() {
/* 339 */     set("TEMPLATE_VERSION_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionId() {
/* 343 */     return DataType.getAsLong(get("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public long getTemplateVersionIdInitialValue() {
/* 347 */     return DataType.getAsLong(getOldObj("TEMPLATE_VERSION_ID"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowObjectType(String value) {
/* 351 */     initProperty("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectType(String value) {
/* 354 */     set("WORKFLOW_OBJECT_TYPE", value);
/*     */   }
/*     */   public void setWorkflowObjectTypeNull() {
/* 357 */     set("WORKFLOW_OBJECT_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectType() {
/* 361 */     return DataType.getAsString(get("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectTypeInitialValue() {
/* 365 */     return DataType.getAsString(getOldObj("WORKFLOW_OBJECT_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initEngineTaskId(String value) {
/* 369 */     initProperty("ENGINE_TASK_ID", value);
/*     */   }
/*     */   public void setEngineTaskId(String value) {
/* 372 */     set("ENGINE_TASK_ID", value);
/*     */   }
/*     */   public void setEngineTaskIdNull() {
/* 375 */     set("ENGINE_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineTaskId() {
/* 379 */     return DataType.getAsString(get("ENGINE_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineTaskIdInitialValue() {
/* 383 */     return DataType.getAsString(getOldObj("ENGINE_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskStaffId(String value) {
/* 387 */     initProperty("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffId(String value) {
/* 390 */     set("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffIdNull() {
/* 393 */     set("TASK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskStaffId() {
/* 397 */     return DataType.getAsString(get("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskStaffIdInitialValue() {
/* 401 */     return DataType.getAsString(getOldObj("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskBaseType(String value) {
/* 405 */     initProperty("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseType(String value) {
/* 408 */     set("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseTypeNull() {
/* 411 */     set("TASK_BASE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskBaseType() {
/* 415 */     return DataType.getAsString(get("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskBaseTypeInitialValue() {
/* 419 */     return DataType.getAsString(getOldObj("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initLockStaffId(String value) {
/* 423 */     initProperty("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffId(String value) {
/* 426 */     set("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffIdNull() {
/* 429 */     set("LOCK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLockStaffId() {
/* 433 */     return DataType.getAsString(get("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getLockStaffIdInitialValue() {
/* 437 */     return DataType.getAsString(getOldObj("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initFinishDate(Timestamp value) {
/* 441 */     initProperty("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDate(Timestamp value) {
/* 444 */     set("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDateNull() {
/* 447 */     set("FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 451 */     return DataType.getAsDateTime(get("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDateInitialValue() {
/* 455 */     return DataType.getAsDateTime(getOldObj("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initChildWorkflowCount(long value) {
/* 459 */     initProperty("CHILD_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setChildWorkflowCount(long value) {
/* 462 */     set("CHILD_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setChildWorkflowCountNull() {
/* 465 */     set("CHILD_WORKFLOW_COUNT", null);
/*     */   }
/*     */ 
/*     */   public long getChildWorkflowCount() {
/* 469 */     return DataType.getAsLong(get("CHILD_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public long getChildWorkflowCountInitialValue() {
/* 473 */     return DataType.getAsLong(getOldObj("CHILD_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initRemanentWorkflowCount(long value) {
/* 477 */     initProperty("REMANENT_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setRemanentWorkflowCount(long value) {
/* 480 */     set("REMANENT_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */   public void setRemanentWorkflowCountNull() {
/* 483 */     set("REMANENT_WORKFLOW_COUNT", null);
/*     */   }
/*     */ 
/*     */   public long getRemanentWorkflowCount() {
/* 487 */     return DataType.getAsLong(get("REMANENT_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public long getRemanentWorkflowCountInitialValue() {
/* 491 */     return DataType.getAsLong(getOldObj("REMANENT_WORKFLOW_COUNT"));
/*     */   }
/*     */ 
/*     */   public void initTaskTemplateId(long value) {
/* 495 */     initProperty("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateId(long value) {
/* 498 */     set("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateIdNull() {
/* 501 */     set("TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 505 */     return DataType.getAsLong(get("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateIdInitialValue() {
/* 509 */     return DataType.getAsLong(getOldObj("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 513 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 516 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 519 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 523 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 527 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStationId(String value) {
/* 531 */     initProperty("STATION_ID", value);
/*     */   }
/*     */   public void setStationId(String value) {
/* 534 */     set("STATION_ID", value);
/*     */   }
/*     */   public void setStationIdNull() {
/* 537 */     set("STATION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/* 541 */     return DataType.getAsString(get("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public String getStationIdInitialValue() {
/* 545 */     return DataType.getAsString(getOldObj("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public void initDuration(long value) {
/* 549 */     initProperty("DURATION", new Long(value));
/*     */   }
/*     */   public void setDuration(long value) {
/* 552 */     set("DURATION", new Long(value));
/*     */   }
/*     */   public void setDurationNull() {
/* 555 */     set("DURATION", null);
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 559 */     return DataType.getAsLong(get("DURATION"));
/*     */   }
/*     */ 
/*     */   public long getDurationInitialValue() {
/* 563 */     return DataType.getAsLong(getOldObj("DURATION"));
/*     */   }
/*     */ 
/*     */   public void initTaskType(String value) {
/* 567 */     initProperty("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskType(String value) {
/* 570 */     set("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskTypeNull() {
/* 573 */     set("TASK_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 577 */     return DataType.getAsString(get("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskTypeInitialValue() {
/* 581 */     return DataType.getAsString(getOldObj("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value) {
/* 585 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/* 588 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/* 591 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 595 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/* 599 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 603 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 606 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 609 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 613 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 617 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initEngineWorkflowId(String value) {
/* 621 */     initProperty("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowId(String value) {
/* 624 */     set("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowIdNull() {
/* 627 */     set("ENGINE_WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 631 */     return DataType.getAsString(get("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowIdInitialValue() {
/* 635 */     return DataType.getAsString(getOldObj("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initLastTaskId(String value) {
/* 639 */     initProperty("LAST_TASK_ID", value);
/*     */   }
/*     */   public void setLastTaskId(String value) {
/* 642 */     set("LAST_TASK_ID", value);
/*     */   }
/*     */   public void setLastTaskIdNull() {
/* 645 */     set("LAST_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLastTaskId() {
/* 649 */     return DataType.getAsString(get("LAST_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getLastTaskIdInitialValue() {
/* 653 */     return DataType.getAsString(getOldObj("LAST_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 657 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 660 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 663 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 667 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 671 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 675 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 678 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 681 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 685 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 689 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowState(long value) {
/* 693 */     initProperty("WORKFLOW_STATE", new Long(value));
/*     */   }
/*     */   public void setWorkflowState(long value) {
/* 696 */     set("WORKFLOW_STATE", new Long(value));
/*     */   }
/*     */   public void setWorkflowStateNull() {
/* 699 */     set("WORKFLOW_STATE", null);
/*     */   }
/*     */ 
/*     */   public long getWorkflowState() {
/* 703 */     return DataType.getAsLong(get("WORKFLOW_STATE"));
/*     */   }
/*     */ 
/*     */   public long getWorkflowStateInitialValue() {
/* 707 */     return DataType.getAsLong(getOldObj("WORKFLOW_STATE"));
/*     */   }
/*     */ 
/*     */   public void initIsCurrentTask(String value) {
/* 711 */     initProperty("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTask(String value) {
/* 714 */     set("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTaskNull() {
/* 717 */     set("IS_CURRENT_TASK", null);
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTask() {
/* 721 */     return DataType.getAsString(get("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTaskInitialValue() {
/* 725 */     return DataType.getAsString(getOldObj("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public void initFinishStaffId(String value) {
/* 729 */     initProperty("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffId(String value) {
/* 732 */     set("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffIdNull() {
/* 735 */     set("FINISH_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getFinishStaffId() {
/* 739 */     return DataType.getAsString(get("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getFinishStaffIdInitialValue() {
/* 743 */     return DataType.getAsString(getOldObj("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initDecisionResult(String value) {
/* 747 */     initProperty("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResult(String value) {
/* 750 */     set("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResultNull() {
/* 753 */     set("DECISION_RESULT", null);
/*     */   }
/*     */ 
/*     */   public String getDecisionResult() {
/* 757 */     return DataType.getAsString(get("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   public String getDecisionResultInitialValue() {
/* 761 */     return DataType.getAsString(getOldObj("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  61 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  63 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.QBOVmTaskInfoBean
 * JD-Core Version:    0.5.4
 */