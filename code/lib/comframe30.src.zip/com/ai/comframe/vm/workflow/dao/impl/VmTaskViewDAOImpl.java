/*     */ package com.ai.comframe.vm.workflow.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.comframe.client.TaskInfo;
/*     */ import com.ai.comframe.client.WorkflowInfo;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.query.QueryObjectTypeImpl;
/*     */ import com.ai.comframe.query.TaskInfoHelper;
/*     */ import com.ai.comframe.query.WorkflowInfoHelper;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskViewDAO;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class VmTaskViewDAOImpl
/*     */   implements IVmTaskViewDAO
/*     */ {
/*     */   public TaskInfo[] getTasksByStationId(String queueID, long stationId, String workflowTemplateCode, String taskTag)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  25 */       StringBuffer cond = new StringBuffer();
/*  26 */       cond.append("STATION_ID").append(" = '").append(stationId).append("' and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") and ").append("WORKFLOW_STATE").append(" in (").append(5).append(",").append(2).append(")");
/*     */ 
/*  31 */       HashMap parameters = new HashMap();
/*  32 */       if ((workflowTemplateCode != null) && (workflowTemplateCode.trim().length() > 0)) {
/*  33 */         cond.append(" and  WORKFLOW_CODE = :aWorkflowCode ");
/*  34 */         parameters.put("aWorkflowCode", workflowTemplateCode);
/*     */       }
/*  36 */       if ((taskTag != null) && (taskTag.trim().length() > 0)) {
/*  37 */         cond.append(" and  TASK_TAG = :aTaskTag ");
/*  38 */         parameters.put("aTaskTag", taskTag);
/*     */       }
/*  40 */       return getTaskInfos(queueID, cond.toString(), parameters, -1, -1);
/*     */     } catch (Exception e) {
/*  42 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByStationId_accdStationReadTaskF") + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTasksByStationId(String queueID, long[] stations, String workflowTemplateCode, String taskTag) throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  50 */       if ((stations == null) || (stations.length == 0))
/*  51 */         return new TaskInfo[0];
/*  52 */       StringBuffer stationCondition = new StringBuffer("");
/*  53 */       if (stations.length == 1) {
/*  54 */         stationCondition.append(" = ").append(stations[0]);
/*     */       } else {
/*  56 */         stationCondition.append(" in ('");
/*  57 */         for (int i = 0; i < stations.length; ++i) {
/*  58 */           if (i != 0)
/*  59 */             stationCondition.append("','").append(String.valueOf(stations[i]));
/*     */         }
/*  61 */         stationCondition.append("') ");
/*     */       }
/*  63 */       StringBuffer cond = new StringBuffer();
/*  64 */       cond.append("STATION_ID").append(stationCondition).append(" and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") and ").append("WORKFLOW_STATE").append(" in (").append(5).append(",").append(2).append(")");
/*     */ 
/*  69 */       HashMap parameters = new HashMap();
/*  70 */       if ((workflowTemplateCode != null) && (workflowTemplateCode.trim().length() > 0)) {
/*  71 */         cond.append(" and  WORKFLOW_CODE = :aWorkflowCode ");
/*  72 */         parameters.put("aWorkflowCode", workflowTemplateCode);
/*     */       }
/*     */ 
/*  75 */       if ((taskTag != null) && (taskTag.trim().length() > 0)) {
/*  76 */         cond.append(" and  TASK_TAG = :aTaskTag ");
/*  77 */         parameters.put("aTaskTag", taskTag);
/*     */       }
/*  79 */       return getTaskInfos(queueID, cond.toString(), parameters, -1, -1);
/*     */     }
/*     */     catch (Exception e) {
/*  82 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByStationId_accdStationReadTaskF") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTasksByStationIdAndStaffId(String queueID, long[] stations, String staffId, String workflowTemplateCode, String taskTag) throws Exception {
/*     */     try {
/*  88 */       StringBuffer stationCondition = new StringBuffer("");
/*  89 */       if ((stations == null) || (stations.length == 0)) {
/*  90 */         stationCondition = null;
/*  91 */       } else if (stations.length == 1) {
/*  92 */         stationCondition.append(" = ").append(stations[0]);
/*     */       } else {
/*  94 */         stationCondition.append(" in (");
/*  95 */         for (int i = 0; i < stations.length; ++i) {
/*  96 */           if (i > 0)
/*  97 */             stationCondition.append(",");
/*  98 */           stationCondition.append(stations[i]);
/*     */         }
/* 100 */         stationCondition.append(") ");
/*     */       }
/*     */ 
/* 103 */       StringBuffer cond = new StringBuffer();
/* 104 */       if (stationCondition == null) {
/* 105 */         cond.append("TASK_STAFF_ID").append(" = '").append(staffId).append(" and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") and ").append("WORKFLOW_STATE").append(" in (").append(5).append(",").append(2).append(")");
/*     */       }
/*     */       else
/*     */       {
/* 111 */         cond.append(" ( ").append("STATION_ID").append(stationCondition).append(" or ").append("TASK_STAFF_ID").append("  = ' ").append(staffId).append("') ").append(" and ").append("STATE").append(" in (").append(5).append(",").append(9).append(") and ").append("WORKFLOW_STATE").append(" in (").append(5).append(",").append(2).append(")");
/*     */       }
/*     */ 
/* 118 */       HashMap parameters = new HashMap();
/* 119 */       if ((workflowTemplateCode != null) && (workflowTemplateCode.trim().length() > 0)) {
/* 120 */         cond.append(" and  WORKFLOW_CODE = :aWorkflowCode ");
/* 121 */         parameters.put("aWorkflowCode", workflowTemplateCode);
/*     */       }
/*     */ 
/* 124 */       if ((taskTag != null) && (taskTag.trim().length() > 0)) {
/* 125 */         cond.append(" and  TASK_TAG = :aTaskTag ");
/* 126 */         parameters.put("aTaskTag", taskTag);
/*     */       }
/* 128 */       return getTaskInfos(queueID, cond.toString(), parameters, -1, -1);
/*     */     }
/*     */     catch (Exception e) {
/* 131 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.getTasksByStationId_accdStationReadTaskF") + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getWorkflowHisCount(String queueID, String condition, HashMap parameters) throws Exception {
/* 136 */     AssembleDef assenble = new AssembleDef();
/* 137 */     assenble.setQueueId(queueID);
/*     */ 
/* 140 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflowHisCount(assenble, AssembleDef.getDefautTimePeriod()));
/* 141 */     if (parameters == null) {
/* 142 */       parameters = new HashMap();
/*     */     }
/* 144 */     parameters.put("queueId", queueID);
/* 145 */     if ((condition != null) && (condition.length() > 0))
/* 146 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 148 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 150 */     sql.append(" where ").append(condition);
/*     */ 
/* 152 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   public int getWorkflowHisCount(String queueID, String acctPeriod, String condition, HashMap parameters) throws Exception {
/* 156 */     if (StringUtils.isEmpty(acctPeriod))
/*     */     {
/* 158 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskViewDAOImpl_noInputDate"));
/* 159 */     }AssembleDef assenble = new AssembleDef();
/* 160 */     assenble.setQueueId(queueID);
/* 161 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflowHisCount(assenble, new String[] { acctPeriod }));
/* 162 */     if (parameters == null) {
/* 163 */       parameters = new HashMap();
/*     */     }
/* 165 */     parameters.put("queueId", queueID);
/* 166 */     if ((condition != null) && (condition.length() > 0))
/* 167 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 169 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 171 */     sql.append(" where ").append(condition);
/*     */ 
/* 173 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   private int retrieveCount(String sql, HashMap parameters) throws Exception {
/* 177 */     Connection conn = null;
/* 178 */     ResultSet rs = null;
/*     */     try {
/* 180 */       conn = ServiceManager.getSession().getConnection();
/* 181 */       rs = ServiceManager.getDataStore().retrieve(conn, sql, parameters);
/* 182 */       int i = WorkflowInfoHelper.getCount(rs);
/*     */ 
/* 192 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 186 */       if (rs != null) {
/* 187 */         rs.close();
/*     */       }
/* 189 */       if (conn != null)
/* 190 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private TaskInfo[] retrieveTaskInfos(String sql, HashMap parameters, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/* 197 */     Connection conn = null;
/* 198 */     ResultSet rs = null;
/*     */     try {
/* 200 */       conn = ServiceManager.getSession().getConnection();
/* 201 */       QueryObjectTypeImpl objectType = new QueryObjectTypeImpl();
/* 202 */       objectType.setMapingEnty(sql.toString());
/* 203 */       rs = ServiceManager.getDataStore().retrieve(conn, objectType, null, null, parameters, startIndex, endIndex, false, false, null);
/* 204 */       TaskInfo[] arrayOfTaskInfo = TaskInfoHelper.transer(rs);
/*     */ 
/* 214 */       return arrayOfTaskInfo;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 208 */       if (rs != null) {
/* 209 */         rs.close();
/*     */       }
/* 211 */       if (conn != null)
/* 212 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private WorkflowInfo[] retrieveWorkflowInfos(String sql, HashMap parameters, int startIndex, int endIndex) throws Exception
/*     */   {
/* 218 */     Connection conn = null;
/* 219 */     ResultSet rs = null;
/*     */     try {
/* 221 */       conn = ServiceManager.getSession().getConnection();
/* 222 */       QueryObjectTypeImpl objectType = new QueryObjectTypeImpl();
/* 223 */       objectType.setMapingEnty(sql.toString());
/* 224 */       rs = ServiceManager.getDataStore().retrieve(conn, objectType, null, null, parameters, startIndex, endIndex, false, false, null);
/* 225 */       WorkflowInfo[] arrayOfWorkflowInfo = WorkflowInfoHelper.transer(rs);
/*     */ 
/* 235 */       return arrayOfWorkflowInfo;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 229 */       if (rs != null) {
/* 230 */         rs.close();
/*     */       }
/* 232 */       if (conn != null)
/* 233 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getWorkflowCount(String queueID, String condition, HashMap parameters)
/*     */     throws Exception
/*     */   {
/* 241 */     AssembleDef assenble = new AssembleDef();
/* 242 */     assenble.setQueueId(queueID);
/* 243 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflowCount(assenble));
/* 244 */     if (parameters == null) {
/* 245 */       parameters = new HashMap();
/*     */     }
/* 247 */     parameters.put("queueId", queueID);
/* 248 */     if ((condition != null) && (condition.length() > 0))
/* 249 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 251 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 253 */     sql.append(" where ").append(condition);
/* 254 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   public WorkflowInfo[] getWorkflowInfoHis(String queueID, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception {
/* 258 */     AssembleDef assenble = new AssembleDef();
/* 259 */     assenble.setQueueId(queueID);
/* 260 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflowHis(assenble, AssembleDef.getDefautTimePeriod()));
/* 261 */     if (parameters == null) {
/* 262 */       parameters = new HashMap();
/*     */     }
/* 264 */     parameters.put("queueId", queueID);
/* 265 */     if ((condition != null) && (condition.length() > 0))
/* 266 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 268 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 270 */     sql.append(" where ").append(condition);
/* 271 */     return retrieveWorkflowInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public WorkflowInfo[] getWorkflowInfoHis(String queueID, String acctPeriod, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception {
/* 275 */     if (StringUtils.isEmpty(acctPeriod))
/*     */     {
/* 277 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskViewDAOImpl_noInputDate"));
/* 278 */     }AssembleDef assenble = new AssembleDef();
/* 279 */     assenble.setQueueId(queueID);
/* 280 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflowHis(assenble, new String[] { acctPeriod }));
/* 281 */     if (parameters == null) {
/* 282 */       parameters = new HashMap();
/*     */     }
/* 284 */     parameters.put("queueId", queueID);
/* 285 */     if ((condition != null) && (condition.length() > 0))
/* 286 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 288 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 290 */     sql.append(" where ").append(condition);
/* 291 */     return retrieveWorkflowInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public WorkflowInfo[] getWorkflowInfo(String queueID, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception {
/* 295 */     AssembleDef def = new AssembleDef();
/* 296 */     def.setQueueId(queueID);
/* 297 */     StringBuffer sql = new StringBuffer(WorkflowInfoHelper.createSQLWorkflow(def));
/* 298 */     if (parameters == null) {
/* 299 */       parameters = new HashMap();
/*     */     }
/* 301 */     parameters.put("queueId", queueID);
/* 302 */     if ((condition != null) && (condition.length() > 0))
/* 303 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 305 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 307 */     sql.append(" where ").append(condition);
/* 308 */     return retrieveWorkflowInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public int getTaskCount(String queueID, String condition, HashMap parameters) throws Exception
/*     */   {
/* 313 */     AssembleDef def = new AssembleDef();
/* 314 */     def.setQueueId(queueID);
/* 315 */     StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLAllTaskCount(def));
/* 316 */     if (parameters == null) {
/* 317 */       parameters = new HashMap();
/*     */     }
/* 319 */     parameters.put("queueId", queueID);
/* 320 */     if ((condition != null) && (condition.length() > 0))
/* 321 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 323 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 325 */     sql.append(" where ").append(condition);
/* 326 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   public int getTaskHisCount(String queueID, String condition, HashMap parameters) throws Exception
/*     */   {
/* 331 */     AssembleDef def = new AssembleDef();
/* 332 */     def.setQueueId(queueID);
/* 333 */     StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLHisAllTaskCount(def, AssembleDef.getDefautTimePeriod()));
/* 334 */     if (parameters == null) {
/* 335 */       parameters = new HashMap();
/*     */     }
/* 337 */     parameters.put("queueId", queueID);
/* 338 */     if ((condition != null) && (condition.length() > 0))
/* 339 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 341 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 343 */     sql.append(" where ").append(condition);
/* 344 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   public int getTaskHisCount(String queueID, String acctPeriod, String condition, HashMap parameters) throws Exception
/*     */   {
/* 349 */     AssembleDef def = new AssembleDef();
/* 350 */     def.setQueueId(queueID);
/*     */ 
/* 352 */     if (StringUtils.isEmpty(acctPeriod))
/*     */     {
/* 354 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskViewDAOImpl_noInputDate"));
/* 355 */     }StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLHisTaskCount(def, new String[] { acctPeriod }));
/* 356 */     if (parameters == null) {
/* 357 */       parameters = new HashMap();
/*     */     }
/* 359 */     parameters.put("queueId", queueID);
/* 360 */     if ((condition != null) && (condition.length() > 0))
/* 361 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 363 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 365 */     sql.append(" where ").append(condition);
/* 366 */     return retrieveCount(sql.toString(), parameters);
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTaskInfos(String queueID, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception {
/* 370 */     AssembleDef assemble = new AssembleDef();
/* 371 */     assemble.setQueueId(queueID);
/* 372 */     StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLAllTask(assemble));
/* 373 */     if (parameters == null) {
/* 374 */       parameters = new HashMap();
/*     */     }
/* 376 */     parameters.put("queueId", queueID);
/* 377 */     if ((condition != null) && (condition.length() > 0))
/* 378 */       condition = " QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 380 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 382 */     sql.append(" where ").append(condition);
/* 383 */     return retrieveTaskInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTaskInfosHis(String queueID, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception
/*     */   {
/* 388 */     AssembleDef assenble = new AssembleDef();
/* 389 */     assenble.setQueueId(queueID);
/* 390 */     StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLHisAllTask(assenble, AssembleDef.getDefautTimePeriod()));
/* 391 */     if (parameters == null) {
/* 392 */       parameters = new HashMap();
/*     */     }
/* 394 */     parameters.put("queueId", queueID);
/* 395 */     if ((condition != null) && (condition.length() > 0))
/* 396 */       condition = "  QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 398 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 400 */     sql.append(" where ").append(condition);
/* 401 */     return retrieveTaskInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public TaskInfo[] getTaskInfosHis(String queueID, String acctPeriod, String condition, HashMap parameters, int startIndex, int endIndex) throws Exception
/*     */   {
/* 406 */     AssembleDef assenble = new AssembleDef();
/* 407 */     assenble.setQueueId(queueID);
/* 408 */     if (StringUtils.isEmpty(acctPeriod))
/*     */     {
/* 410 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskViewDAOImpl_noInputDate"));
/* 411 */     }StringBuffer sql = new StringBuffer(TaskInfoHelper.createSQLHisAllTask(assenble, new String[] { acctPeriod }));
/* 412 */     if (parameters == null) {
/* 413 */       parameters = new HashMap();
/*     */     }
/* 415 */     parameters.put("queueId", queueID);
/* 416 */     if ((condition != null) && (condition.length() > 0))
/* 417 */       condition = " QUEUE_ID = :queueId and " + condition;
/*     */     else {
/* 419 */       condition = " QUEUE_ID = :queueId ";
/*     */     }
/* 421 */     sql.append(" where ").append(condition);
/* 422 */     return retrieveTaskInfos(sql.toString(), parameters, startIndex, endIndex);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.impl.VmTaskViewDAOImpl
 * JD-Core Version:    0.5.4
 */