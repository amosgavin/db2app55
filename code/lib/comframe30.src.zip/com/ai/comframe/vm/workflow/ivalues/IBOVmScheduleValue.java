package com.ai.comframe.vm.workflow.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmScheduleValue extends DataStructInterface
{
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_State = "STATE";
  public static final String S_EngineType = "ENGINE_TYPE";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_StateDate = "STATE_DATE";
  public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
  public static final String S_ScheduleDate = "SCHEDULE_DATE";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_StartDate = "START_DATE";
  public static final String S_DevId = "DEV_ID";

  public abstract String getWorkflowId();

  public abstract String getState();

  public abstract String getEngineType();

  public abstract String getRegionId();

  public abstract String getQueueId();

  public abstract Timestamp getStateDate();

  public abstract String getEngineWorkflowId();

  public abstract Timestamp getScheduleDate();

  public abstract Timestamp getCreateDate();

  public abstract Timestamp getStartDate();

  public abstract String getDevId();

  public abstract void setWorkflowId(String paramString);

  public abstract void setState(String paramString);

  public abstract void setEngineType(String paramString);

  public abstract void setRegionId(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setStateDate(Timestamp paramTimestamp);

  public abstract void setEngineWorkflowId(String paramString);

  public abstract void setScheduleDate(Timestamp paramTimestamp);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setStartDate(Timestamp paramTimestamp);

  public abstract void setDevId(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue
 * JD-Core Version:    0.5.4
 */