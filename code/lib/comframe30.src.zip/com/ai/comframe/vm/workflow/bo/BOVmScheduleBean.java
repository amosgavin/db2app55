/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmScheduleBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmScheduleValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOVmSchedule";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_ScheduleDate = "SCHEDULE_DATE";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_StartDate = "START_DATE";
/*     */   public static final String S_DevId = "DEV_ID";
/*  31 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmScheduleBean()
/*     */     throws AIException
/*     */   {
/*  40 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  44 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  49 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value)
/*     */   {
/*  54 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/*  57 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/*  60 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/*  64 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/*  68 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/*  72 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  75 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  78 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  82 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  86 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initEngineType(String value) {
/*  90 */     initProperty("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineType(String value) {
/*  93 */     set("ENGINE_TYPE", value);
/*     */   }
/*     */   public void setEngineTypeNull() {
/*  96 */     set("ENGINE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/* 100 */     return DataType.getAsString(get("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getEngineTypeInitialValue() {
/* 104 */     return DataType.getAsString(getOldObj("ENGINE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 108 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 111 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 114 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 118 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 122 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 126 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 129 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 132 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 136 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 140 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 144 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 147 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 150 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 154 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 158 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initEngineWorkflowId(String value) {
/* 162 */     initProperty("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowId(String value) {
/* 165 */     set("ENGINE_WORKFLOW_ID", value);
/*     */   }
/*     */   public void setEngineWorkflowIdNull() {
/* 168 */     set("ENGINE_WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 172 */     return DataType.getAsString(get("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowIdInitialValue() {
/* 176 */     return DataType.getAsString(getOldObj("ENGINE_WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initScheduleDate(Timestamp value) {
/* 180 */     initProperty("SCHEDULE_DATE", value);
/*     */   }
/*     */   public void setScheduleDate(Timestamp value) {
/* 183 */     set("SCHEDULE_DATE", value);
/*     */   }
/*     */   public void setScheduleDateNull() {
/* 186 */     set("SCHEDULE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getScheduleDate() {
/* 190 */     return DataType.getAsDateTime(get("SCHEDULE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getScheduleDateInitialValue() {
/* 194 */     return DataType.getAsDateTime(getOldObj("SCHEDULE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 198 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 201 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 204 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 208 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 212 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initStartDate(Timestamp value) {
/* 216 */     initProperty("START_DATE", value);
/*     */   }
/*     */   public void setStartDate(Timestamp value) {
/* 219 */     set("START_DATE", value);
/*     */   }
/*     */   public void setStartDateNull() {
/* 222 */     set("START_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStartDate() {
/* 226 */     return DataType.getAsDateTime(get("START_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStartDateInitialValue() {
/* 230 */     return DataType.getAsDateTime(getOldObj("START_DATE"));
/*     */   }
/*     */ 
/*     */   public void initDevId(String value) {
/* 234 */     initProperty("DEV_ID", value);
/*     */   }
/*     */   public void setDevId(String value) {
/* 237 */     set("DEV_ID", value);
/*     */   }
/*     */   public void setDevIdNull() {
/* 240 */     set("DEV_ID", null);
/*     */   }
/*     */ 
/*     */   public String getDevId() {
/* 244 */     return DataType.getAsString(get("DEV_ID"));
/*     */   }
/*     */ 
/*     */   public String getDevIdInitialValue() {
/* 248 */     return DataType.getAsString(getOldObj("DEV_ID"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  34 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  36 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOVmScheduleBean
 * JD-Core Version:    0.5.4
 */