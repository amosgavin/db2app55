/*     */ package com.ai.comframe.vm.workflow.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TableAssembleUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmScheduleBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmScheduleEngine;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmScheduleDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmScheduleDAOImpl
/*     */   implements IVmScheduleDAO
/*     */ {
/*  30 */   private static transient Log logger = LogFactory.getLog(VmScheduleDAOImpl.class);
/*     */ 
/*     */   public IBOVmScheduleValue[] getVmScheduleData(String queueId, String engineType, int mod, int value, int fetchNum, String state)
/*     */     throws Exception
/*     */   {
/*  41 */     if (StringUtils.isBlank(queueId))
/*     */     {
/*  43 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_getScheduleTaskIDNull"));
/*  44 */     }if (StringUtils.isBlank(state))
/*     */     {
/*  46 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_stateNull"));
/*  47 */     }if (mod <= 0)
/*     */     {
/*  49 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_modeBelowZero"));
/*  50 */     }if (value < 0)
/*     */     {
/*  52 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_modValueBelowZero"));
/*     */     }
/*     */ 
/*  55 */     StringBuilder condition = new StringBuilder("");
/*  56 */     HashMap parameter = new HashMap();
/*  57 */     condition.append(" 1 = 1 ");
/*  58 */     condition.append(" and ").append("QUEUE_ID").append(" = :qid ");
/*  59 */     condition.append(" and ").append("STATE").append(" = :pstate ");
/*  60 */     parameter.put("qid", queueId);
/*  61 */     parameter.put("pstate", state);
/*  62 */     if (CenterFactory.isSetCenterInfo()) {
/*  63 */       CenterInfo center = CenterFactory.getCenterInfo();
/*  64 */       if ((center != null) && (StringUtils.isNotBlank(center.getRegion()))) {
/*  65 */         condition.append(" and ").append("REGION_ID").append(" = :regionId ");
/*  66 */         parameter.put("regionId", center.getRegion());
/*     */       }
/*     */     }
/*     */ 
/*  70 */     if ("VM".equalsIgnoreCase(engineType)) {
/*  71 */       condition.append(" and (UPPER(").append("ENGINE_TYPE").append(") = :engineType or ").append("ENGINE_TYPE").append(" is null )");
/*     */ 
/*  73 */       parameter.put("engineType", engineType);
/*  74 */     } else if (StringUtils.isNotBlank(engineType)) {
/*  75 */       condition.append(" and UPPER(").append("ENGINE_TYPE").append(") = :engineType ");
/*  76 */       parameter.put("engineType", engineType);
/*     */     }
/*     */ 
/*  80 */     if (PropertiesUtil.isDev()) {
/*  81 */       String devName = PropertiesUtil.getDevId();
/*  82 */       if (StringUtils.isBlank(devName))
/*     */       {
/*  84 */         String[] param = new String[1];
/*  85 */         param[0] = "comframe.dev.name";
/*  86 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */       }
/*  88 */       if (logger.isDebugEnabled())
/*     */       {
/*  90 */         logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_developMode") + devName);
/*  91 */       }condition.append(" and ").append("DEV_ID").append(" = :devId ");
/*  92 */       parameter.put("devId", devName);
/*     */     } else {
/*  94 */       condition.append(" and ").append("DEV_ID").append(" is null ");
/*     */     }
/*     */ 
/*  97 */     condition.append(" and mod (").append(IDAssembleUtil.wrappedIdColToNumFunc("WORKFLOW_ID")).append(",:mod ) = :value ");
/*     */ 
/*  99 */     parameter.put("mod", String.valueOf(mod));
/* 100 */     parameter.put("value", String.valueOf(value));
/*     */ 
/* 104 */     BOVmScheduleBean scheduleBean = new BOVmScheduleBean();
/* 105 */     AssembleDef def = new AssembleDef();
/* 106 */     def.setQueueId(queueId);
/*     */ 
/* 109 */     String sql = TableAssembleUtil.createSelectSQL(scheduleBean, def, condition.toString(), 1, fetchNum);
/*     */ 
/* 111 */     return BOVmScheduleEngine.getBeansFromSql(sql, parameter);
/*     */   }
/*     */ 
/*     */   public void saveVmSchedule(IBOVmScheduleValue schedule)
/*     */     throws Exception
/*     */   {
/* 122 */     if (schedule == null)
/*     */     {
/* 124 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_saveObjEmpty"));
/* 125 */     }TableAssembleUtil.replaceTableName((BOVmScheduleBean)schedule);
/* 126 */     BOVmScheduleEngine.save(schedule);
/*     */   }
/*     */ 
/*     */   public void saveVmSchedule(IBOVmScheduleValue[] schedules) throws Exception
/*     */   {
/* 131 */     for (int i = 0; i < schedules.length; ++i) {
/* 132 */       TableAssembleUtil.replaceTableName((BOVmScheduleBean)schedules[i]);
/*     */     }
/* 134 */     BOVmScheduleEngine.saveBatch(schedules);
/*     */   }
/*     */ 
/*     */   public IBOVmScheduleValue getVmScheduleByWorkflowId(String workflowId)
/*     */     throws Exception
/*     */   {
/* 144 */     BOVmScheduleBean scheduleBean = new BOVmScheduleBean();
/* 145 */     AssembleDef def = new AssembleDef();
/* 146 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*     */ 
/* 148 */     StringBuilder condition = new StringBuilder("");
/* 149 */     condition.append("workflow_id=:workflowId");
/* 150 */     HashMap parameter = new HashMap();
/* 151 */     parameter.put("workflowId", workflowId);
/*     */ 
/* 154 */     String sql = TableAssembleUtil.createSelectSQL(scheduleBean, def, condition.toString(), -1, -1);
/*     */ 
/* 156 */     IBOVmScheduleValue[] aBeans = BOVmScheduleEngine.getBeansFromSql(sql, parameter);
/* 157 */     if (aBeans.length > 0) {
/* 158 */       return aBeans[0];
/*     */     }
/*     */ 
/* 161 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_scheduleNotFind"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl
 * JD-Core Version:    0.5.4
 */