package com.ai.comframe.vm.workflow.dao.interfaces;

import com.ai.comframe.client.TaskInfo;
import com.ai.comframe.client.WorkflowInfo;
import java.util.HashMap;

public abstract interface IVmTaskViewDAO
{
  public abstract TaskInfo[] getTasksByStationId(String paramString1, long paramLong, String paramString2, String paramString3)
    throws Exception;

  public abstract TaskInfo[] getTasksByStationId(String paramString1, long[] paramArrayOfLong, String paramString2, String paramString3)
    throws Exception;

  public abstract TaskInfo[] getTasksByStationIdAndStaffId(String paramString1, long[] paramArrayOfLong, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract TaskInfo[] getTaskInfos(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract TaskInfo[] getTaskInfosHis(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract TaskInfo[] getTaskInfosHis(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract int getWorkflowCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws Exception;

  public abstract int getWorkflowHisCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws Exception;

  public abstract int getWorkflowHisCount(String paramString1, String paramString2, String paramString3, HashMap paramHashMap)
    throws Exception;

  public abstract WorkflowInfo[] getWorkflowInfoHis(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract WorkflowInfo[] getWorkflowInfoHis(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract WorkflowInfo[] getWorkflowInfo(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract int getTaskCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws Exception;

  public abstract int getTaskHisCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws Exception;

  public abstract int getTaskHisCount(String paramString1, String paramString2, String paramString3, HashMap paramHashMap)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskViewDAO
 * JD-Core Version:    0.5.4
 */