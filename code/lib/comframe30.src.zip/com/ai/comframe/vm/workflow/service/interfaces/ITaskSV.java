package com.ai.comframe.vm.workflow.service.interfaces;

import com.ai.comframe.queue.WarningTaskBean;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
import java.rmi.RemoteException;
import java.util.HashMap;

public abstract interface ITaskSV
{
  public abstract void saveVmtaskInstacne(IBOVmTaskValue paramIBOVmTaskValue)
    throws RemoteException, Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTaskData(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
    throws RemoteException, Exception;

  public abstract void saveVmDealTask(IBOVmDealTaskValue paramIBOVmDealTaskValue)
    throws RemoteException, Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTask(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmDealTaskValue[] getVmDealTaskbeanByWorkflowId(String paramString)
    throws RemoteException, Exception;

  public abstract WarningTaskBean[] getWarningTaskData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException, Exception;

  public abstract WarningTaskBean[] getWarningTaskTsData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws RemoteException, Exception;

  public abstract IBOVmTaskValue getVmTaskByID(String paramString)
    throws RemoteException, Exception;

  public abstract void saveVmTaskInstance(IBOVmTaskValue paramIBOVmTaskValue)
    throws RemoteException, Exception;

  public abstract IBOVmTaskTSValue getVmTaskTSByID(String paramString)
    throws RemoteException, Exception;

  public abstract void saveVmTaskTSInstance(IBOVmTaskTSValue paramIBOVmTaskTSValue)
    throws RemoteException, Exception;

  public abstract IBOVmWFValue getVmWFByID(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmTaskValue[] getVmTaskBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract IBOVmTaskTSValue[] getVmTaskTSBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract IBOHVmTaskValue[] getHisVmTaskBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws RemoteException, Exception;

  public abstract IBOHVmTaskTSValue[] getHisVmTaskTSBean(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws RemoteException, Exception;

  public abstract IBOVmTaskValue[] getTaskBeans(String paramString1, String paramString2)
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.interfaces.ITaskSV
 * JD-Core Version:    0.5.4
 */