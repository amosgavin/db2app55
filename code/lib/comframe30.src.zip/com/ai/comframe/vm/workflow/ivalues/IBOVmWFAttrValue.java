package com.ai.comframe.vm.workflow.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVmWFAttrValue extends DataStructInterface
{
  public static final String S_WorkflowId = "WORKFLOW_ID";
  public static final String S_AttrName = "ATTR_NAME";
  public static final String S_RegionId = "REGION_ID";
  public static final String S_AttrCode = "ATTR_CODE";
  public static final String S_QueueId = "QUEUE_ID";
  public static final String S_AttrId = "ATTR_ID";
  public static final String S_AttrValue = "ATTR_VALUE";
  public static final String S_CreateDate = "CREATE_DATE";

  public abstract String getWorkflowId();

  public abstract String getAttrName();

  public abstract String getRegionId();

  public abstract String getAttrCode();

  public abstract String getQueueId();

  public abstract long getAttrId();

  public abstract String getAttrValue();

  public abstract Timestamp getCreateDate();

  public abstract void setWorkflowId(String paramString);

  public abstract void setAttrName(String paramString);

  public abstract void setRegionId(String paramString);

  public abstract void setAttrCode(String paramString);

  public abstract void setQueueId(String paramString);

  public abstract void setAttrId(long paramLong);

  public abstract void setAttrValue(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue
 * JD-Core Version:    0.5.4
 */