/*    */ package com.ai.comframe.vm.workflow.service.impl;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmScheduleDAO;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IVmScheduleSV;
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ public class VmScheduleSVImpl
/*    */   implements IVmScheduleSV
/*    */ {
/*    */   public IBOVmScheduleValue[] getVmScheduleData(String queueId, String engineType, int mod, int value, int fetchNum, String state)
/*    */     throws RemoteException, Exception
/*    */   {
/* 29 */     IVmScheduleDAO scheduleDao = (IVmScheduleDAO)ServiceFactory.getService(IVmScheduleDAO.class);
/* 30 */     return scheduleDao.getVmScheduleData(queueId, engineType, mod, value, fetchNum, state);
/*    */   }
/*    */ 
/*    */   public void saveVmSchedule(IBOVmScheduleValue schedule)
/*    */     throws RemoteException, Exception
/*    */   {
/* 41 */     IVmScheduleDAO scheduleDao = (IVmScheduleDAO)ServiceFactory.getService(IVmScheduleDAO.class);
/* 42 */     scheduleDao.saveVmSchedule(schedule);
/*    */   }
/*    */ 
/*    */   public void saveVmSchedule(IBOVmScheduleValue[] schedules)
/*    */     throws RemoteException, Exception
/*    */   {
/* 52 */     if ((schedules == null) || (schedules.length == 0))
/*    */     {
/* 54 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_saveObjEmpty"));
/* 55 */     }IVmScheduleDAO scheduleDao = (IVmScheduleDAO)ServiceFactory.getService(IVmScheduleDAO.class);
/* 56 */     scheduleDao.saveVmSchedule(schedules);
/*    */   }
/*    */ 
/*    */   public IBOVmScheduleValue getVmScheduleByWorkflowId(String workflowId) throws RemoteException, Exception {
/* 60 */     IVmScheduleDAO scheduleDao = (IVmScheduleDAO)ServiceFactory.getService(IVmScheduleDAO.class);
/* 61 */     return scheduleDao.getVmScheduleByWorkflowId(workflowId);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.service.impl.VmScheduleSVImpl
 * JD-Core Version:    0.5.4
 */