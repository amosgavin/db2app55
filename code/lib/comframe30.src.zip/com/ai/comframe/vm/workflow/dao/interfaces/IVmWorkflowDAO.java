package com.ai.comframe.vm.workflow.dao.interfaces;

import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface IVmWorkflowDAO
{
  public abstract void saveVmWorkflowInstacne(IBOVmWFValue paramIBOVmWFValue)
    throws Exception;

  public abstract String getNewWorkFlowId(String paramString1, String paramString2)
    throws Exception;

  public abstract void saveHVmWorkflowInstacne(IBOHVmWFValue paramIBOHVmWFValue)
    throws Exception;

  public abstract String getNewWorkFlowAttrId(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmWFAttrValue[] getVmWorkflowAttrBeans(String paramString)
    throws Exception;

  public abstract void saveVmWorkflowAttrBeans(IBOVmWFAttrValue[] paramArrayOfIBOVmWFAttrValue)
    throws Exception;

  public abstract IBOVmWFValue getVmWorkflowBeanbyId(String paramString)
    throws Exception;

  public abstract IBOVmWFValue[] getWorkflowBeans(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract IBOVmWFAttrValue[] getVmWorkflowAttrsByWorkflowId(String paramString)
    throws Exception;

  public abstract IBOVmWFAttrValue[] getVmWorkflowAttrAllBeans(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws Exception;

  public abstract IBOHVmWFValue getHisVmWorkflowBeanbyId(String paramString)
    throws Exception;

  public abstract IBOHVmWFValue getHisVmWorkflowBeanbyId(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmWFValue[] getWarningWorkflowData(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws Exception;

  public abstract IBOVmWFValue[] getChildWorkflows(String paramString)
    throws Exception;

  public abstract void workflowToHis(String paramString, Timestamp paramTimestamp)
    throws Exception;

  public abstract void workflowAttrToHis(String paramString, Timestamp paramTimestamp)
    throws Exception;

  public abstract int getWorkflowBeansCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws Exception;

  public abstract IBOHVmWFValue[] getHisWorkflowBeans(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2, String paramString3)
    throws Exception;

  public abstract int getHisWorkflowBeansCount(String paramString1, String paramString2, HashMap paramHashMap, String paramString3)
    throws Exception;

  public abstract IBOVmWFValue getExceptionChildWorkflow(String paramString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO
 * JD-Core Version:    0.5.4
 */