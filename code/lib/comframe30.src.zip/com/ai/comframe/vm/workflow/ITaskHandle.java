package com.ai.comframe.vm.workflow;

import com.ai.comframe.vm.engine.WorkflowContext;

public abstract interface ITaskHandle
{
  public abstract void onCreateInstance(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, WorkflowContext paramWorkflowContext, String paramString7, long paramLong);

  public abstract void onAssignUserTask(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, WorkflowContext paramWorkflowContext, String paramString7, long paramLong1, long paramLong2);

  public abstract void onPrintTask(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, WorkflowContext paramWorkflowContext, String paramString7, long paramLong1, long paramLong2);

  public abstract void onFinishInstance(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, WorkflowContext paramWorkflowContext, String paramString7, long paramLong1, long paramLong2);

  public abstract void onInstanceException(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, WorkflowContext paramWorkflowContext, String paramString7, Throwable paramThrowable, long paramLong1, long paramLong2);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.ITaskHandle
 * JD-Core Version:    0.5.4
 */