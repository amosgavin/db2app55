/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainerFactory;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.appframe2.util.criteria.UniqueList;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IQBOVmTaskInfoValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class QBOVmTaskInfoEngine
/*     */ {
/*     */   public static QBOVmTaskInfoBean[] getBeans(DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  20 */     Map ps = dc.getProperties();
/*  21 */     StringBuffer buffer = new StringBuffer();
/*  22 */     Map pList = new HashMap();
/*  23 */     for (Iterator cc = ps.entrySet().iterator(); cc.hasNext(); ) {
/*  24 */       e = (Map.Entry)cc.next();
/*  25 */       if (buffer.length() > 0)
/*  26 */         buffer.append(" and ");
/*  27 */       buffer.append(e.getKey().toString() + " = :p_" + e.getKey().toString());
/*  28 */       pList.put("p_" + e.getKey().toString(), e.getValue());
/*     */     }
/*     */     Map.Entry e;
/*  30 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try {
/*  32 */       e = getBeans(buffer.toString(), pList);
/*     */ 
/*  36 */       return e;
/*     */     }
/*     */     finally
/*     */     {
/*  34 */       if (conn != null)
/*  35 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeans(Criteria sql) throws Exception
/*     */   {
/*  41 */     return getBeans(sql, -1, -1, false);
/*     */   }
/*     */   public static QBOVmTaskInfoBean[] getBeans(Criteria sql, int startNum, int endNum, boolean isShowFK) throws Exception {
/*  44 */     String[] cols = null;
/*  45 */     String condition = "";
/*  46 */     Map param = null;
/*  47 */     if (sql != null) {
/*  48 */       cols = (String[])(String[])sql.getSelectColumns().toArray(new String[0]);
/*  49 */       condition = sql.toString();
/*  50 */       param = sql.getParameters();
/*     */     }
/*  52 */     return (QBOVmTaskInfoBean[])getBeans(cols, condition, param, startNum, endNum, isShowFK);
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeans(String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  59 */     return getBeans(null, condition, parameter, -1, -1, false);
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK) throws Exception
/*     */   {
/*  64 */     Connection conn = null;
/*     */     try {
/*  66 */       conn = ServiceManager.getSession().getConnection();
/*  67 */       QBOVmTaskInfoBean[] arrayOfQBOVmTaskInfoBean = (QBOVmTaskInfoBean[])(QBOVmTaskInfoBean[])ServiceManager.getDataStore().retrieve(conn, QBOVmTaskInfoBean.class, QBOVmTaskInfoBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, null);
/*     */ 
/*  73 */       return arrayOfQBOVmTaskInfoBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  71 */       if (conn != null)
/*  72 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK, String[] extendBOAttrs) throws Exception
/*     */   {
/*  78 */     Connection conn = null;
/*     */     try {
/*  80 */       conn = ServiceManager.getSession().getConnection();
/*  81 */       QBOVmTaskInfoBean[] arrayOfQBOVmTaskInfoBean = (QBOVmTaskInfoBean[])(QBOVmTaskInfoBean[])ServiceManager.getDataStore().retrieve(conn, QBOVmTaskInfoBean.class, QBOVmTaskInfoBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, extendBOAttrs);
/*     */ 
/*  87 */       return arrayOfQBOVmTaskInfoBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  85 */       if (conn != null)
/*  86 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter) throws Exception
/*     */   {
/*  92 */     Connection conn = null;
/*     */     try {
/*  94 */       conn = ServiceManager.getSession().getConnection();
/*  95 */       int i = ServiceManager.getDataStore().retrieveCount(conn, QBOVmTaskInfoBean.getObjectTypeStatic(), condition, parameter, null);
/*     */ 
/* 101 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  99 */       if (conn != null)
/* 100 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter, String[] extendBOAttrs) throws Exception {
/* 105 */     Connection conn = null;
/*     */     try {
/* 107 */       conn = ServiceManager.getSession().getConnection();
/* 108 */       int i = ServiceManager.getDataStore().retrieveCount(conn, QBOVmTaskInfoBean.getObjectTypeStatic(), condition, parameter, extendBOAttrs);
/*     */ 
/* 114 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 112 */       if (conn != null)
/* 113 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(QBOVmTaskInfoBean aBean) throws Exception
/*     */   {
/* 119 */     Connection conn = null;
/*     */     try {
/* 121 */       conn = ServiceManager.getSession().getConnection();
/* 122 */       ServiceManager.getDataStore().save(conn, aBean);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 126 */       if (conn != null)
/* 127 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(QBOVmTaskInfoBean[] aBeans) throws Exception {
/* 132 */     Connection conn = null;
/*     */     try {
/* 134 */       conn = ServiceManager.getSession().getConnection();
/* 135 */       ServiceManager.getDataStore().save(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 139 */       if (conn != null)
/* 140 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveBatch(QBOVmTaskInfoBean[] aBeans) throws Exception {
/* 145 */     Connection conn = null;
/*     */     try {
/* 147 */       conn = ServiceManager.getSession().getConnection();
/* 148 */       ServiceManager.getDataStore().saveBatch(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 152 */       if (conn != null)
/* 153 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeansFromQueryBO(String soureBO, Map parameter) throws Exception
/*     */   {
/* 159 */     Connection conn = null;
/* 160 */     ResultSet resultset = null;
/*     */     try {
/* 162 */       conn = ServiceManager.getSession().getConnection();
/* 163 */       String sql = ServiceManager.getObjectTypeFactory().getInstance(soureBO).getMapingEnty();
/* 164 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 165 */       QBOVmTaskInfoBean[] arrayOfQBOVmTaskInfoBean = (QBOVmTaskInfoBean[])(QBOVmTaskInfoBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(QBOVmTaskInfoBean.class, QBOVmTaskInfoBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 172 */       return arrayOfQBOVmTaskInfoBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 169 */       if (resultset != null) resultset.close();
/* 170 */       if (conn != null)
/* 171 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] getBeansFromSql(String sql, Map parameter) throws Exception {
/* 176 */     Connection conn = null;
/* 177 */     ResultSet resultset = null;
/*     */     try {
/* 179 */       conn = ServiceManager.getSession().getConnection();
/* 180 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 181 */       QBOVmTaskInfoBean[] arrayOfQBOVmTaskInfoBean = (QBOVmTaskInfoBean[])(QBOVmTaskInfoBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(QBOVmTaskInfoBean.class, QBOVmTaskInfoBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 188 */       return arrayOfQBOVmTaskInfoBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 185 */       if (resultset != null) resultset.close();
/* 186 */       if (conn != null)
/* 187 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId() throws Exception {
/* 192 */     return ServiceManager.getIdGenerator().getNewId(QBOVmTaskInfoBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static Timestamp getSysDate() throws Exception
/*     */   {
/* 197 */     return ServiceManager.getIdGenerator().getSysDate(QBOVmTaskInfoBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean wrap(DataContainerInterface source, Map colMatch, boolean canModify)
/*     */   {
/*     */     try {
/* 203 */       return (QBOVmTaskInfoBean)DataContainerFactory.wrap(source, QBOVmTaskInfoBean.class, colMatch, canModify);
/*     */     } catch (Exception e) {
/* 205 */       if (e.getCause() != null) {
/* 206 */         throw new RuntimeException(e.getCause());
/*     */       }
/* 208 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean copy(DataContainerInterface source, Map colMatch, boolean canModify) {
/*     */     try {
/* 213 */       QBOVmTaskInfoBean result = new QBOVmTaskInfoBean();
/* 214 */       DataContainerFactory.copy(source, result, colMatch);
/* 215 */       return result;
/*     */     }
/*     */     catch (AIException ex) {
/* 218 */       if (ex.getCause() != null) {
/* 219 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 221 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean transfer(IQBOVmTaskInfoValue value) {
/* 226 */     if (value == null)
/* 227 */       return null;
/*     */     try {
/* 229 */       if (value instanceof QBOVmTaskInfoBean) {
/* 230 */         return (QBOVmTaskInfoBean)value;
/*     */       }
/* 232 */       QBOVmTaskInfoBean newBean = new QBOVmTaskInfoBean();
/*     */ 
/* 234 */       DataContainerFactory.transfer(value, newBean);
/* 235 */       return newBean;
/*     */     } catch (Exception ex) {
/* 237 */       if (ex.getCause() != null) {
/* 238 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 240 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static QBOVmTaskInfoBean[] transfer(IQBOVmTaskInfoValue[] value) {
/* 245 */     if ((value == null) || (value.length == 0))
/* 246 */       return null;
/*     */     try
/*     */     {
/* 249 */       if (value instanceof QBOVmTaskInfoBean[]) {
/* 250 */         return (QBOVmTaskInfoBean[])(QBOVmTaskInfoBean[])value;
/*     */       }
/* 252 */       QBOVmTaskInfoBean[] newBeans = new QBOVmTaskInfoBean[value.length];
/* 253 */       for (int i = 0; i < newBeans.length; ++i) {
/* 254 */         newBeans[i] = new QBOVmTaskInfoBean();
/* 255 */         DataContainerFactory.transfer(value[i], newBeans[i]);
/*     */       }
/* 257 */       return newBeans;
/*     */     } catch (Exception ex) {
/* 259 */       if (ex.getCause() != null) {
/* 260 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 262 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(IQBOVmTaskInfoValue aValue) throws Exception {
/* 267 */     save(transfer(aValue));
/*     */   }
/*     */ 
/*     */   public static void save(IQBOVmTaskInfoValue[] aValues) throws Exception {
/* 271 */     save(transfer(aValues));
/*     */   }
/*     */ 
/*     */   public static void saveBatch(IQBOVmTaskInfoValue[] aValues) throws Exception {
/* 275 */     saveBatch(transfer(aValues));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.QBOVmTaskInfoEngine
 * JD-Core Version:    0.5.4
 */