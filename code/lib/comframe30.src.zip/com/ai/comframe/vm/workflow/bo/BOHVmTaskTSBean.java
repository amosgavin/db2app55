/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOHVmTaskTSBean extends DataContainer
/*     */   implements DataContainerInterface, IBOHVmTaskTSValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOHVmTaskTS";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_DestType = "DEST_TYPE";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_LockDate = "LOCK_DATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_TransferDate = "TRANSFER_DATE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_DestTaskTemplateId = "DEST_TASK_TEMPLATE_ID";
/*     */   public static final String S_TaskBaseType = "TASK_BASE_TYPE";
/*     */   public static final String S_TaskStaffId = "TASK_STAFF_ID";
/*     */   public static final String S_LockStaffId = "LOCK_STAFF_ID";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StationId = "STATION_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
/*     */   public static final String S_FinishStaffId = "FINISH_STAFF_ID";
/*     */   public static final String S_DecisionResult = "DECISION_RESULT";
/*  49 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOHVmTaskTSBean()
/*     */     throws AIException
/*     */   {
/*  58 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  62 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  67 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(int value)
/*     */   {
/*  72 */     initProperty("STATE", new Integer(value));
/*     */   }
/*     */   public void setState(int value) {
/*  75 */     set("STATE", new Integer(value));
/*     */   }
/*     */   public void setStateNull() {
/*  78 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public int getState() {
/*  82 */     return DataType.getAsInt(get("STATE"));
/*     */   }
/*     */ 
/*     */   public int getStateInitialValue() {
/*  86 */     return DataType.getAsInt(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initWarningTimes(int value) {
/*  90 */     initProperty("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimes(int value) {
/*  93 */     set("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimesNull() {
/*  96 */     set("WARNING_TIMES", null);
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/* 100 */     return DataType.getAsInt(get("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public int getWarningTimesInitialValue() {
/* 104 */     return DataType.getAsInt(getOldObj("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 108 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 111 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 114 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 118 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 122 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initParentTaskId(String value) {
/* 126 */     initProperty("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskId(String value) {
/* 129 */     set("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskIdNull() {
/* 132 */     set("PARENT_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 136 */     return DataType.getAsString(get("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getParentTaskIdInitialValue() {
/* 140 */     return DataType.getAsString(getOldObj("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 144 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 147 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 150 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 154 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 158 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initDestType(String value) {
/* 162 */     initProperty("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestType(String value) {
/* 165 */     set("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestTypeNull() {
/* 168 */     set("DEST_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getDestType() {
/* 172 */     return DataType.getAsString(get("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getDestTypeInitialValue() {
/* 176 */     return DataType.getAsString(getOldObj("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 180 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 183 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 186 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 190 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 194 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initWarningDate(Timestamp value) {
/* 198 */     initProperty("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDate(Timestamp value) {
/* 201 */     set("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDateNull() {
/* 204 */     set("WARNING_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 208 */     return DataType.getAsDateTime(get("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDateInitialValue() {
/* 212 */     return DataType.getAsDateTime(getOldObj("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLockDate(Timestamp value) {
/* 216 */     initProperty("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDate(Timestamp value) {
/* 219 */     set("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDateNull() {
/* 222 */     set("LOCK_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDate() {
/* 226 */     return DataType.getAsDateTime(get("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDateInitialValue() {
/* 230 */     return DataType.getAsDateTime(getOldObj("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 234 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 237 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 240 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 244 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 248 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initTransferDate(Timestamp value) {
/* 252 */     initProperty("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDate(Timestamp value) {
/* 255 */     set("TRANSFER_DATE", value);
/*     */   }
/*     */   public void setTransferDateNull() {
/* 258 */     set("TRANSFER_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDate() {
/* 262 */     return DataType.getAsDateTime(get("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getTransferDateInitialValue() {
/* 266 */     return DataType.getAsDateTime(getOldObj("TRANSFER_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 270 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 273 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 276 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 280 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 284 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initDestTaskTemplateId(long value) {
/* 288 */     initProperty("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateId(long value) {
/* 291 */     set("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateIdNull() {
/* 294 */     set("DEST_TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateId() {
/* 298 */     return DataType.getAsLong(get("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateIdInitialValue() {
/* 302 */     return DataType.getAsLong(getOldObj("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskBaseType(String value) {
/* 306 */     initProperty("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseType(String value) {
/* 309 */     set("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseTypeNull() {
/* 312 */     set("TASK_BASE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskBaseType() {
/* 316 */     return DataType.getAsString(get("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskBaseTypeInitialValue() {
/* 320 */     return DataType.getAsString(getOldObj("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTaskStaffId(String value) {
/* 324 */     initProperty("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffId(String value) {
/* 327 */     set("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffIdNull() {
/* 330 */     set("TASK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskStaffId() {
/* 334 */     return DataType.getAsString(get("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskStaffIdInitialValue() {
/* 338 */     return DataType.getAsString(getOldObj("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initLockStaffId(String value) {
/* 342 */     initProperty("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffId(String value) {
/* 345 */     set("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffIdNull() {
/* 348 */     set("LOCK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLockStaffId() {
/* 352 */     return DataType.getAsString(get("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getLockStaffIdInitialValue() {
/* 356 */     return DataType.getAsString(getOldObj("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initFinishDate(Timestamp value) {
/* 360 */     initProperty("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDate(Timestamp value) {
/* 363 */     set("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDateNull() {
/* 366 */     set("FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 370 */     return DataType.getAsDateTime(get("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDateInitialValue() {
/* 374 */     return DataType.getAsDateTime(getOldObj("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTemplateId(long value) {
/* 378 */     initProperty("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateId(long value) {
/* 381 */     set("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateIdNull() {
/* 384 */     set("TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 388 */     return DataType.getAsLong(get("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateIdInitialValue() {
/* 392 */     return DataType.getAsLong(getOldObj("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 396 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 399 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 402 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 406 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 410 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStationId(String value) {
/* 414 */     initProperty("STATION_ID", value);
/*     */   }
/*     */   public void setStationId(String value) {
/* 417 */     set("STATION_ID", value);
/*     */   }
/*     */   public void setStationIdNull() {
/* 420 */     set("STATION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/* 424 */     return DataType.getAsString(get("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public String getStationIdInitialValue() {
/* 428 */     return DataType.getAsString(getOldObj("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public void initDuration(long value) {
/* 432 */     initProperty("DURATION", new Long(value));
/*     */   }
/*     */   public void setDuration(long value) {
/* 435 */     set("DURATION", new Long(value));
/*     */   }
/*     */   public void setDurationNull() {
/* 438 */     set("DURATION", null);
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 442 */     return DataType.getAsLong(get("DURATION"));
/*     */   }
/*     */ 
/*     */   public long getDurationInitialValue() {
/* 446 */     return DataType.getAsLong(getOldObj("DURATION"));
/*     */   }
/*     */ 
/*     */   public void initTaskType(String value) {
/* 450 */     initProperty("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskType(String value) {
/* 453 */     set("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskTypeNull() {
/* 456 */     set("TASK_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 460 */     return DataType.getAsString(get("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskTypeInitialValue() {
/* 464 */     return DataType.getAsString(getOldObj("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value) {
/* 468 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/* 471 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/* 474 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 478 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/* 482 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 486 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 489 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 492 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 496 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 500 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 504 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 507 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 510 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 514 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 518 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 522 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 525 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 528 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 532 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 536 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initIsCurrentTask(String value) {
/* 540 */     initProperty("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTask(String value) {
/* 543 */     set("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTaskNull() {
/* 546 */     set("IS_CURRENT_TASK", null);
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTask() {
/* 550 */     return DataType.getAsString(get("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTaskInitialValue() {
/* 554 */     return DataType.getAsString(getOldObj("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public void initFinishStaffId(String value) {
/* 558 */     initProperty("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffId(String value) {
/* 561 */     set("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffIdNull() {
/* 564 */     set("FINISH_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getFinishStaffId() {
/* 568 */     return DataType.getAsString(get("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getFinishStaffIdInitialValue() {
/* 572 */     return DataType.getAsString(getOldObj("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initDecisionResult(String value) {
/* 576 */     initProperty("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResult(String value) {
/* 579 */     set("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResultNull() {
/* 582 */     set("DECISION_RESULT", null);
/*     */   }
/*     */ 
/*     */   public String getDecisionResult() {
/* 586 */     return DataType.getAsString(get("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   public String getDecisionResultInitialValue() {
/* 590 */     return DataType.getAsString(getOldObj("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  52 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  54 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOHVmTaskTSBean
 * JD-Core Version:    0.5.4
 */