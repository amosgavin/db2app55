/*     */ package com.ai.comframe.vm.workflow.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVmTaskTSBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVmTaskTSValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.vm.workflow.bo.BOVmTaskTS";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_DestType = "DEST_TYPE";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_LockDate = "LOCK_DATE";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_DestTaskTemplateId = "DEST_TASK_TEMPLATE_ID";
/*     */   public static final String S_TaskBaseType = "TASK_BASE_TYPE";
/*     */   public static final String S_TaskStaffId = "TASK_STAFF_ID";
/*     */   public static final String S_LockStaffId = "LOCK_STAFF_ID";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_StationId = "STATION_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
/*     */   public static final String S_FinishStaffId = "FINISH_STAFF_ID";
/*     */   public static final String S_DecisionResult = "DECISION_RESULT";
/*  48 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVmTaskTSBean()
/*     */     throws AIException
/*     */   {
/*  57 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  61 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  66 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(int value)
/*     */   {
/*  71 */     initProperty("STATE", new Integer(value));
/*     */   }
/*     */   public void setState(int value) {
/*  74 */     set("STATE", new Integer(value));
/*     */   }
/*     */   public void setStateNull() {
/*  77 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public int getState() {
/*  81 */     return DataType.getAsInt(get("STATE"));
/*     */   }
/*     */ 
/*     */   public int getStateInitialValue() {
/*  85 */     return DataType.getAsInt(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initWarningTimes(int value) {
/*  89 */     initProperty("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimes(int value) {
/*  92 */     set("WARNING_TIMES", new Integer(value));
/*     */   }
/*     */   public void setWarningTimesNull() {
/*  95 */     set("WARNING_TIMES", null);
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/*  99 */     return DataType.getAsInt(get("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public int getWarningTimesInitialValue() {
/* 103 */     return DataType.getAsInt(getOldObj("WARNING_TIMES"));
/*     */   }
/*     */ 
/*     */   public void initStateDate(Timestamp value) {
/* 107 */     initProperty("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDate(Timestamp value) {
/* 110 */     set("STATE_DATE", value);
/*     */   }
/*     */   public void setStateDateNull() {
/* 113 */     set("STATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 117 */     return DataType.getAsDateTime(get("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDateInitialValue() {
/* 121 */     return DataType.getAsDateTime(getOldObj("STATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initParentTaskId(String value) {
/* 125 */     initProperty("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskId(String value) {
/* 128 */     set("PARENT_TASK_ID", value);
/*     */   }
/*     */   public void setParentTaskIdNull() {
/* 131 */     set("PARENT_TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 135 */     return DataType.getAsString(get("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getParentTaskIdInitialValue() {
/* 139 */     return DataType.getAsString(getOldObj("PARENT_TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 143 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 146 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 149 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 153 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 157 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initDestType(String value) {
/* 161 */     initProperty("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestType(String value) {
/* 164 */     set("DEST_TYPE", value);
/*     */   }
/*     */   public void setDestTypeNull() {
/* 167 */     set("DEST_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getDestType() {
/* 171 */     return DataType.getAsString(get("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getDestTypeInitialValue() {
/* 175 */     return DataType.getAsString(getOldObj("DEST_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTag(String value) {
/* 179 */     initProperty("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTag(String value) {
/* 182 */     set("TASK_TAG", value);
/*     */   }
/*     */   public void setTaskTagNull() {
/* 185 */     set("TASK_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 189 */     return DataType.getAsString(get("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTaskTagInitialValue() {
/* 193 */     return DataType.getAsString(getOldObj("TASK_TAG"));
/*     */   }
/*     */ 
/*     */   public void initWarningDate(Timestamp value) {
/* 197 */     initProperty("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDate(Timestamp value) {
/* 200 */     set("WARNING_DATE", value);
/*     */   }
/*     */   public void setWarningDateNull() {
/* 203 */     set("WARNING_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 207 */     return DataType.getAsDateTime(get("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDateInitialValue() {
/* 211 */     return DataType.getAsDateTime(getOldObj("WARNING_DATE"));
/*     */   }
/*     */ 
/*     */   public void initLockDate(Timestamp value) {
/* 215 */     initProperty("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDate(Timestamp value) {
/* 218 */     set("LOCK_DATE", value);
/*     */   }
/*     */   public void setLockDateNull() {
/* 221 */     set("LOCK_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDate() {
/* 225 */     return DataType.getAsDateTime(get("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDateInitialValue() {
/* 229 */     return DataType.getAsDateTime(getOldObj("LOCK_DATE"));
/*     */   }
/*     */ 
/*     */   public void initRegionId(String value) {
/* 233 */     initProperty("REGION_ID", value);
/*     */   }
/*     */   public void setRegionId(String value) {
/* 236 */     set("REGION_ID", value);
/*     */   }
/*     */   public void setRegionIdNull() {
/* 239 */     set("REGION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 243 */     return DataType.getAsString(get("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public String getRegionIdInitialValue() {
/* 247 */     return DataType.getAsString(getOldObj("REGION_ID"));
/*     */   }
/*     */ 
/*     */   public void initLabel(String value) {
/* 251 */     initProperty("LABEL", value);
/*     */   }
/*     */   public void setLabel(String value) {
/* 254 */     set("LABEL", value);
/*     */   }
/*     */   public void setLabelNull() {
/* 257 */     set("LABEL", null);
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 261 */     return DataType.getAsString(get("LABEL"));
/*     */   }
/*     */ 
/*     */   public String getLabelInitialValue() {
/* 265 */     return DataType.getAsString(getOldObj("LABEL"));
/*     */   }
/*     */ 
/*     */   public void initDestTaskTemplateId(long value) {
/* 269 */     initProperty("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateId(long value) {
/* 272 */     set("DEST_TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setDestTaskTemplateIdNull() {
/* 275 */     set("DEST_TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateId() {
/* 279 */     return DataType.getAsLong(get("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getDestTaskTemplateIdInitialValue() {
/* 283 */     return DataType.getAsLong(getOldObj("DEST_TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskBaseType(String value) {
/* 287 */     initProperty("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseType(String value) {
/* 290 */     set("TASK_BASE_TYPE", value);
/*     */   }
/*     */   public void setTaskBaseTypeNull() {
/* 293 */     set("TASK_BASE_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskBaseType() {
/* 297 */     return DataType.getAsString(get("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskBaseTypeInitialValue() {
/* 301 */     return DataType.getAsString(getOldObj("TASK_BASE_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initTaskStaffId(String value) {
/* 305 */     initProperty("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffId(String value) {
/* 308 */     set("TASK_STAFF_ID", value);
/*     */   }
/*     */   public void setTaskStaffIdNull() {
/* 311 */     set("TASK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskStaffId() {
/* 315 */     return DataType.getAsString(get("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskStaffIdInitialValue() {
/* 319 */     return DataType.getAsString(getOldObj("TASK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initLockStaffId(String value) {
/* 323 */     initProperty("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffId(String value) {
/* 326 */     set("LOCK_STAFF_ID", value);
/*     */   }
/*     */   public void setLockStaffIdNull() {
/* 329 */     set("LOCK_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getLockStaffId() {
/* 333 */     return DataType.getAsString(get("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getLockStaffIdInitialValue() {
/* 337 */     return DataType.getAsString(getOldObj("LOCK_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initFinishDate(Timestamp value) {
/* 341 */     initProperty("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDate(Timestamp value) {
/* 344 */     set("FINISH_DATE", value);
/*     */   }
/*     */   public void setFinishDateNull() {
/* 347 */     set("FINISH_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 351 */     return DataType.getAsDateTime(get("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDateInitialValue() {
/* 355 */     return DataType.getAsDateTime(getOldObj("FINISH_DATE"));
/*     */   }
/*     */ 
/*     */   public void initTaskTemplateId(long value) {
/* 359 */     initProperty("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateId(long value) {
/* 362 */     set("TASK_TEMPLATE_ID", new Long(value));
/*     */   }
/*     */   public void setTaskTemplateIdNull() {
/* 365 */     set("TASK_TEMPLATE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 369 */     return DataType.getAsLong(get("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateIdInitialValue() {
/* 373 */     return DataType.getAsLong(getOldObj("TASK_TEMPLATE_ID"));
/*     */   }
/*     */ 
/*     */   public void initQueueId(String value) {
/* 377 */     initProperty("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueId(String value) {
/* 380 */     set("QUEUE_ID", value);
/*     */   }
/*     */   public void setQueueIdNull() {
/* 383 */     set("QUEUE_ID", null);
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 387 */     return DataType.getAsString(get("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public String getQueueIdInitialValue() {
/* 391 */     return DataType.getAsString(getOldObj("QUEUE_ID"));
/*     */   }
/*     */ 
/*     */   public void initStationId(String value) {
/* 395 */     initProperty("STATION_ID", value);
/*     */   }
/*     */   public void setStationId(String value) {
/* 398 */     set("STATION_ID", value);
/*     */   }
/*     */   public void setStationIdNull() {
/* 401 */     set("STATION_ID", null);
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/* 405 */     return DataType.getAsString(get("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public String getStationIdInitialValue() {
/* 409 */     return DataType.getAsString(getOldObj("STATION_ID"));
/*     */   }
/*     */ 
/*     */   public void initDuration(long value) {
/* 413 */     initProperty("DURATION", new Long(value));
/*     */   }
/*     */   public void setDuration(long value) {
/* 416 */     set("DURATION", new Long(value));
/*     */   }
/*     */   public void setDurationNull() {
/* 419 */     set("DURATION", null);
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 423 */     return DataType.getAsLong(get("DURATION"));
/*     */   }
/*     */ 
/*     */   public long getDurationInitialValue() {
/* 427 */     return DataType.getAsLong(getOldObj("DURATION"));
/*     */   }
/*     */ 
/*     */   public void initTaskType(String value) {
/* 431 */     initProperty("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskType(String value) {
/* 434 */     set("TASK_TYPE", value);
/*     */   }
/*     */   public void setTaskTypeNull() {
/* 437 */     set("TASK_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 441 */     return DataType.getAsString(get("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getTaskTypeInitialValue() {
/* 445 */     return DataType.getAsString(getOldObj("TASK_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initWorkflowId(String value) {
/* 449 */     initProperty("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowId(String value) {
/* 452 */     set("WORKFLOW_ID", value);
/*     */   }
/*     */   public void setWorkflowIdNull() {
/* 455 */     set("WORKFLOW_ID", null);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 459 */     return DataType.getAsString(get("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public String getWorkflowIdInitialValue() {
/* 463 */     return DataType.getAsString(getOldObj("WORKFLOW_ID"));
/*     */   }
/*     */ 
/*     */   public void initErrorMessage(String value) {
/* 467 */     initProperty("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessage(String value) {
/* 470 */     set("ERROR_MESSAGE", value);
/*     */   }
/*     */   public void setErrorMessageNull() {
/* 473 */     set("ERROR_MESSAGE", null);
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 477 */     return DataType.getAsString(get("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public String getErrorMessageInitialValue() {
/* 481 */     return DataType.getAsString(getOldObj("ERROR_MESSAGE"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 485 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 488 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 491 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 495 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 499 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initTaskId(String value) {
/* 503 */     initProperty("TASK_ID", value);
/*     */   }
/*     */   public void setTaskId(String value) {
/* 506 */     set("TASK_ID", value);
/*     */   }
/*     */   public void setTaskIdNull() {
/* 509 */     set("TASK_ID", null);
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 513 */     return DataType.getAsString(get("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public String getTaskIdInitialValue() {
/* 517 */     return DataType.getAsString(getOldObj("TASK_ID"));
/*     */   }
/*     */ 
/*     */   public void initIsCurrentTask(String value) {
/* 521 */     initProperty("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTask(String value) {
/* 524 */     set("IS_CURRENT_TASK", value);
/*     */   }
/*     */   public void setIsCurrentTaskNull() {
/* 527 */     set("IS_CURRENT_TASK", null);
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTask() {
/* 531 */     return DataType.getAsString(get("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTaskInitialValue() {
/* 535 */     return DataType.getAsString(getOldObj("IS_CURRENT_TASK"));
/*     */   }
/*     */ 
/*     */   public void initFinishStaffId(String value) {
/* 539 */     initProperty("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffId(String value) {
/* 542 */     set("FINISH_STAFF_ID", value);
/*     */   }
/*     */   public void setFinishStaffIdNull() {
/* 545 */     set("FINISH_STAFF_ID", null);
/*     */   }
/*     */ 
/*     */   public String getFinishStaffId() {
/* 549 */     return DataType.getAsString(get("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public String getFinishStaffIdInitialValue() {
/* 553 */     return DataType.getAsString(getOldObj("FINISH_STAFF_ID"));
/*     */   }
/*     */ 
/*     */   public void initDecisionResult(String value) {
/* 557 */     initProperty("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResult(String value) {
/* 560 */     set("DECISION_RESULT", value);
/*     */   }
/*     */   public void setDecisionResultNull() {
/* 563 */     set("DECISION_RESULT", null);
/*     */   }
/*     */ 
/*     */   public String getDecisionResult() {
/* 567 */     return DataType.getAsString(get("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   public String getDecisionResultInitialValue() {
/* 571 */     return DataType.getAsString(getOldObj("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  51 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  53 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.bo.BOVmTaskTSBean
 * JD-Core Version:    0.5.4
 */