package com.ai.comframe.vm.workflow;

import com.ai.comframe.vm.engine.WorkflowContext;

public abstract interface IWorkflowHandle
{
  public abstract void onCreateInstance(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, WorkflowContext paramWorkflowContext, String paramString6, long paramLong);

  public abstract void onFinishInstance(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, WorkflowContext paramWorkflowContext, long paramLong1, long paramLong2);

  public abstract void onInstanceException(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, WorkflowContext paramWorkflowContext, Throwable paramThrowable, long paramLong1, long paramLong2);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.IWorkflowHandle
 * JD-Core Version:    0.5.4
 */