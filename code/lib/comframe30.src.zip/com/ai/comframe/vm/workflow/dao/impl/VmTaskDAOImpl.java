/*     */ package com.ai.comframe.vm.workflow.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.queue.WarningTaskBean;
/*     */ import com.ai.comframe.utils.AssembleDef;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TableAssembleUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmTaskEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmTaskTSBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmTaskTSEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmDealTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmDealTaskEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmScheduleBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskTSBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskTSEngine;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFEngine;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmTaskDAOImpl
/*     */   implements IVmTaskDAO
/*     */ {
/*  48 */   private static transient Log logger = LogFactory.getLog(VmTaskDAOImpl.class);
/*     */ 
/*     */   public void saveVmtaskInstacne(IBOVmTaskValue taskbean) throws Exception {
/*  51 */     BOVmTaskBean aTaskbean = (BOVmTaskBean)taskbean;
/*  52 */     TableAssembleUtil.replaceTableName(aTaskbean);
/*  53 */     BOVmTaskEngine.save(aTaskbean);
/*     */   }
/*     */ 
/*     */   public void saveVmtaskTransInstacne(IBOVmTaskTSValue taskbean) throws Exception {
/*  57 */     TableAssembleUtil.replaceTableName((BOVmTaskTSBean)taskbean);
/*  58 */     BOVmTaskTSEngine.save(taskbean);
/*     */   }
/*     */ 
/*     */   public void saveVmtaskTransInstacnes(IBOVmTaskTSValue[] taskbeans) throws Exception {
/*  62 */     if ((taskbeans == null) || (taskbeans.length == 0)) {
/*  63 */       return;
/*     */     }
/*  65 */     for (int i = 0; i < taskbeans.length; ++i) {
/*  66 */       TableAssembleUtil.replaceTableName((BOVmTaskTSBean)taskbeans[i]);
/*     */     }
/*  68 */     BOVmTaskTSEngine.save(taskbeans);
/*     */   }
/*     */ 
/*     */   public String getNewTaskId(String queueId, String regionId) throws Exception {
/*  72 */     long lTaskId = BOVmTaskEngine.getNewId().longValue();
/*  73 */     String sTaskId = IDAssembleUtil.wrapPrefix(lTaskId, queueId, regionId);
/*  74 */     return sTaskId;
/*     */   }
/*     */ 
/*     */   public void saveVmDealTaskInstance(IBOVmDealTaskValue dealTaskbean) throws Exception {
/*  78 */     TableAssembleUtil.replaceTableName((BOVmDealTaskBean)dealTaskbean);
/*  79 */     if (dealTaskbean.isNew()) {
/*  80 */       long dtaskId = BOVmDealTaskEngine.getNewId().longValue();
/*  81 */       dealTaskbean.setDealTaskId(IDAssembleUtil.wrapPrefix(dtaskId, dealTaskbean.getQueueId(), dealTaskbean.getRegionId()));
/*     */     }
/*  83 */     BOVmDealTaskEngine.save(dealTaskbean);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue getVmTaskTransBeanById(String taskId) throws Exception {
/*  87 */     String cond = "TASK_ID=:TASK_ID";
/*  88 */     HashMap map = new HashMap();
/*  89 */     map.put("TASK_ID", taskId);
/*  90 */     AssembleDef ad = new AssembleDef();
/*  91 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  92 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmTaskTSBean(), ad, cond, -1, -1);
/*  93 */     IBOVmTaskTSValue[] taskTs = BOVmTaskTSEngine.getBeansFromSql(sql, map);
/*  94 */     if ((taskTs == null) || (taskTs.length == 0))
/*  95 */       return null;
/*  96 */     if (taskTs.length == 1) {
/*  97 */       return taskTs[0];
/*     */     }
/*     */ 
/* 100 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getMoreTsIns") + taskTs.length);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue[] getVmTaskTransBeans(String workflowId, String parentTaskId) throws Exception
/*     */   {
/* 105 */     if (workflowId == null)
/*     */     {
/* 107 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_queryCondworkflowID"));
/*     */     }
/* 109 */     AssembleDef ad = new AssembleDef();
/* 110 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 111 */     BOVmTaskTSBean bts = new BOVmTaskTSBean();
/* 112 */     HashMap map = new HashMap();
/* 113 */     StringBuffer cond = new StringBuffer();
/* 114 */     cond.append("WORKFLOW_ID").append(" =:").append("WORKFLOW_ID");
/* 115 */     map.put("WORKFLOW_ID", workflowId);
/* 116 */     if ((parentTaskId != null) && (parentTaskId.length() > 0)) {
/* 117 */       cond.append(" and ").append("PARENT_TASK_ID").append(" =:").append("PARENT_TASK_ID");
/* 118 */       map.put("PARENT_TASK_ID", parentTaskId);
/*     */     }
/* 120 */     String sql = TableAssembleUtil.createSelectSQL(bts, ad, cond.toString(), -1, -1);
/* 121 */     return BOVmTaskTSEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue getVmTaskbeanById(String taskId) throws Exception {
/* 125 */     String cond = "TASK_ID=:TASK_ID";
/* 126 */     HashMap map = new HashMap();
/* 127 */     map.put("TASK_ID", taskId);
/* 128 */     AssembleDef ad = new AssembleDef();
/* 129 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 130 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmTaskBean(), ad, cond, -1, -1);
/* 131 */     IBOVmTaskValue[] tasks = BOVmTaskEngine.getBeansFromSql(sql, map);
/* 132 */     if ((tasks == null) || (tasks.length == 0))
/* 133 */       return null;
/* 134 */     if (tasks.length == 1) {
/* 135 */       return tasks[0];
/*     */     }
/*     */ 
/* 138 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getMoreByID") + tasks.length);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue[] getVmTaskbeanByWorkflowId(String workflowId) throws Exception
/*     */   {
/* 143 */     AssembleDef def = new AssembleDef();
/* 144 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 145 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 146 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 147 */     HashMap map = new HashMap();
/* 148 */     map.put("WORKFLOW_ID", workflowId);
/* 149 */     String sql = TableAssembleUtil.createSelectSQL(taskBean, def, cond, -1, -1);
/* 150 */     return BOVmTaskEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskValue[] getHVmTaskbeanByWorkflowId(String workflowId) throws Exception {
/* 154 */     IBOHVmTaskValue[] hisTasks = null;
/* 155 */     AssembleDef def = new AssembleDef();
/* 156 */     String[] date = AssembleDef.getDefautTimePeriod();
/* 157 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 158 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 159 */     HashMap map = new HashMap();
/* 160 */     map.put("WORKFLOW_ID", workflowId);
/* 161 */     String sql = null;
/* 162 */     for (int i = 0; i < date.length; ++i) {
/* 163 */       def.setSdate(date[i]);
/* 164 */       sql = TableAssembleUtil.createHisSelectSQL(new BOHVmTaskBean(), def, cond.toString(), -1, -1);
/* 165 */       hisTasks = BOHVmTaskEngine.getBeansFromSql(sql, map);
/* 166 */       if ((hisTasks != null) && (hisTasks.length > 0)) {
/*     */         break;
/*     */       }
/*     */     }
/* 170 */     return hisTasks;
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskValue[] getHVmTaskbeanByWorkflowId(String workflowId, String acctPeriod) throws Exception {
/* 174 */     IBOHVmTaskValue[] hisTasks = null;
/* 175 */     AssembleDef def = new AssembleDef();
/* 176 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 177 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 178 */     HashMap map = new HashMap();
/* 179 */     map.put("WORKFLOW_ID", workflowId);
/* 180 */     String sql = null;
/* 181 */     def.setSdate(acctPeriod);
/* 182 */     sql = TableAssembleUtil.createHisSelectSQL(new BOHVmTaskBean(), def, cond.toString(), -1, -1);
/* 183 */     hisTasks = BOHVmTaskEngine.getBeansFromSql(sql, map);
/* 184 */     return hisTasks;
/*     */   }
/*     */ 
/*     */   public String getNewTaskTransId(String queueId, String regionId) throws Exception {
/* 188 */     long lTaskTransId = BOVmTaskTSEngine.getNewId().longValue();
/* 189 */     String sTaskTransId = IDAssembleUtil.wrapPrefix(lTaskTransId, queueId, regionId);
/* 190 */     return sTaskTransId;
/*     */   }
/*     */ 
/*     */   public void saveHVmtaskInstacne(IBOHVmTaskValue hisTaskbean) throws Exception {
/* 194 */     if (hisTaskbean == null) {
/* 195 */       return;
/*     */     }
/* 197 */     TableAssembleUtil.replaceTableName((BOHVmTaskBean)hisTaskbean);
/* 198 */     BOHVmTaskEngine.save(hisTaskbean);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskTSValue[] getHVmTaskTransBeans(String workflowId) throws Exception
/*     */   {
/* 203 */     IBOHVmTaskTSValue[] hisTaskTrans = null;
/* 204 */     AssembleDef ad = new AssembleDef();
/* 205 */     String[] date = AssembleDef.getDefautTimePeriod();
/* 206 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 207 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 208 */     HashMap map = new HashMap();
/* 209 */     map.put("WORKFLOW_ID", workflowId);
/* 210 */     String sql = null;
/* 211 */     for (int i = 0; i < date.length; ++i) {
/* 212 */       ad.setSdate(date[i]);
/* 213 */       sql = TableAssembleUtil.createHisSelectSQL(new BOHVmTaskTSBean(), ad, cond.toString(), -1, -1);
/* 214 */       hisTaskTrans = BOHVmTaskTSEngine.getBeansFromSql(sql, map);
/* 215 */       if ((hisTaskTrans != null) && (hisTaskTrans.length > 0)) {
/*     */         break;
/*     */       }
/*     */     }
/* 219 */     return hisTaskTrans;
/*     */   }
/*     */ 
/*     */   public void saveHVmtaskTransInstacne(IBOHVmTaskTSValue taskbean) throws Exception {
/* 223 */     if (taskbean == null)
/*     */     {
/* 225 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmScheduleDAOImpl_saveObjEmpty"));
/*     */     }
/* 227 */     TableAssembleUtil.replaceTableName((BOHVmTaskTSBean)taskbean);
/* 228 */     BOHVmTaskTSEngine.save(taskbean);
/*     */   }
/*     */ 
/*     */   public IBOVmDealTaskValue[] getVmDealTaskData(String queueId, int mod, int value, int fetchNum, int state)
/*     */     throws Exception
/*     */   {
/* 236 */     if (StringUtils.isBlank(queueId))
/*     */     {
/* 238 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getTimeTaskQueueEmpty"));
/* 239 */     }if (mod <= 0)
/*     */     {
/* 241 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_ModeNotBelowZero"));
/* 242 */     }if (value < 0)
/*     */     {
/* 244 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_modValueNotBelowZero"));
/* 245 */     }StringBuilder condition = new StringBuilder("");
/* 246 */     HashMap parameter = new HashMap();
/* 247 */     condition.append(" 1 = 1 ");
/*     */ 
/* 249 */     condition.append(" and ").append("QUEUE_ID").append(" = :qid ");
/* 250 */     condition.append(" and ").append("STATE").append(" = :pstate ");
/*     */ 
/* 252 */     condition.append(" and ( ").append("RUNTIME").append(" is null ");
/* 253 */     condition.append(" or ").append("RUNTIME").append(" <= :curTime )");
/*     */ 
/* 255 */     parameter.put("qid", queueId);
/* 256 */     parameter.put("pstate", state + "");
/* 257 */     parameter.put("curTime", TimeUtil.getSysTime());
/*     */ 
/* 259 */     if (CenterFactory.isSetCenterInfo()) {
/* 260 */       CenterInfo center = CenterFactory.getCenterInfo();
/* 261 */       if ((center != null) && (StringUtils.isNotBlank(center.getRegion()))) {
/* 262 */         condition.append(" and ").append("REGION_ID").append(" = :regionId ");
/* 263 */         parameter.put("regionId", center.getRegion());
/*     */       }
/*     */     }
/*     */ 
/* 267 */     if (PropertiesUtil.isDev()) {
/* 268 */       String devName = PropertiesUtil.getDevId();
/* 269 */       if (StringUtils.isBlank(devName))
/*     */       {
/* 271 */         String[] param = new String[1];
/* 272 */         param[0] = "comframe.dev.name";
/* 273 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */       }
/* 275 */       condition.append(" and ").append("DEV_ID").append(" = :devId ");
/* 276 */       parameter.put("devId", devName);
/*     */     } else {
/* 278 */       condition.append(" and ").append("DEV_ID").append(" is null ");
/*     */     }
/*     */ 
/* 281 */     condition.append(" and mod (").append(IDAssembleUtil.wrappedIdColToNumFunc("TASK_ID")).append(",:mod ) = :value ");
/* 282 */     parameter.put("mod", String.valueOf(mod));
/* 283 */     parameter.put("value", String.valueOf(value));
/*     */ 
/* 286 */     BOVmDealTaskBean dealTaskBean = new BOVmDealTaskBean();
/* 287 */     AssembleDef def = new AssembleDef();
/* 288 */     def.setQueueId(queueId);
/*     */ 
/* 291 */     String sql = TableAssembleUtil.createSelectSQL(dealTaskBean, def, condition.toString(), 1, fetchNum);
/* 292 */     return BOVmDealTaskEngine.getBeansFromSql(sql, parameter);
/*     */   }
/*     */ 
/*     */   public WarningTaskBean[] getWarningTaskData(String queueId, int mod, int value, int fetchNum)
/*     */     throws Exception
/*     */   {
/* 303 */     if (StringUtils.isBlank(queueId))
/*     */     {
/* 305 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_queueIDnotEmpty"));
/*     */     }
/* 307 */     if (mod <= 0)
/*     */     {
/* 309 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modeNotBelowZero"));
/*     */     }
/* 311 */     if (value < 0)
/*     */     {
/* 313 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modValueNotBelowZero"));
/*     */     }
/*     */ 
/* 316 */     Connection conn = null;
/* 317 */     ResultSet set = null;
/*     */     try {
/* 319 */       conn = ServiceManager.getSession().getConnection();
/* 320 */       StringBuilder sqlStr = new StringBuilder("");
/* 321 */       HashMap paramMap = new HashMap();
/* 322 */       BOVmWFBean wfBean = new BOVmWFBean();
/* 323 */       BOVmTaskBean taskBean = new BOVmTaskBean();
/* 324 */       BOVmScheduleBean scheBean = new BOVmScheduleBean();
/*     */ 
/* 326 */       AssembleDef def = new AssembleDef();
/* 327 */       def.setQueueId(queueId);
/*     */ 
/* 329 */       String wfTableName = TableAssembleUtil.getTableName(wfBean.fetchTableName(), def);
/* 330 */       String taskTableName = TableAssembleUtil.getTableName(taskBean.fetchTableName(), def);
/* 331 */       String scheTableName = TableAssembleUtil.getTableName(scheBean.fetchTableName(), def);
/* 332 */       if ((StringUtils.isBlank(wfTableName)) || (StringUtils.isBlank(taskTableName)) || (StringUtils.isBlank(scheTableName)))
/*     */       {
/* 334 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getRealTableNameNotEmpty"));
/*     */       }
/*     */ 
/* 338 */       sqlStr.append(" select b.*,a.").append("TEMPLATE_TAG").append(",a.").append("WORKFLOW_OBJECT_ID").append(",a.").append("WORKFLOW_OBJECT_TYPE").append(" from ");
/*     */ 
/* 340 */       sqlStr.append(wfTableName).append(" a, ").append(taskTableName).append(" b, ").append(scheTableName).append(" c where 1 = 1 ");
/*     */ 
/* 343 */       sqlStr.append(" and b.").append("QUEUE_ID").append(" = :qid ");
/* 344 */       sqlStr.append(" and b.").append("WARNING_DATE").append(" <= :curTime ");
/* 345 */       sqlStr.append(" and b.").append("TASK_BASE_TYPE").append(" = :taskBaseType ");
/* 346 */       sqlStr.append(" and a.").append("STATE").append(" = :aState ");
/* 347 */       sqlStr.append(" and (b.").append("STATE").append(" = :bState or b.").append("STATE").append(" = :cState )");
/*     */ 
/* 349 */       sqlStr.append(" and a.").append("WORKFLOW_ID").append(" = b.").append("WORKFLOW_ID");
/* 350 */       sqlStr.append(" and a.").append("WORKFLOW_ID").append(" = c.").append("WORKFLOW_ID");
/* 351 */       sqlStr.append(" and mod(").append(IDAssembleUtil.wrappedIdColToNumFunc("TASK_ID")).append(",:mod ) = :value ");
/*     */ 
/* 353 */       paramMap.put("mod", String.valueOf(mod));
/* 354 */       paramMap.put("value", String.valueOf(value));
/* 355 */       paramMap.put("qid", queueId);
/* 356 */       paramMap.put("taskBaseType", "user");
/* 357 */       paramMap.put("aState", String.valueOf(2));
/* 358 */       paramMap.put("bState", String.valueOf(5));
/* 359 */       paramMap.put("cState", String.valueOf(9));
/* 360 */       paramMap.put("curTime", TimeUtil.getSysTime());
/*     */ 
/* 362 */       if (CenterFactory.isSetCenterInfo()) {
/* 363 */         CenterInfo center = CenterFactory.getCenterInfo();
/* 364 */         if ((center != null) && (StringUtils.isNotBlank(center.getRegion()))) {
/* 365 */           sqlStr.append(" and b.").append("REGION_ID").append(" = :regionId ");
/* 366 */           paramMap.put("regionId", center.getRegion());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 371 */       if (PropertiesUtil.isDev()) {
/* 372 */         String devName = PropertiesUtil.getDevId();
/* 373 */         if (StringUtils.isBlank(devName)) {
/* 374 */           String[] param = new String[1];
/* 375 */           param[0] = "comframe.dev.name";
/*     */ 
/* 377 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */         }
/* 379 */         sqlStr.append(" and c.").append("DEV_ID").append(" = :devId ");
/* 380 */         paramMap.put("devId", devName);
/*     */       } else {
/* 382 */         sqlStr.append(" and c.").append("DEV_ID").append(" is null ");
/*     */       }
/*     */ 
/* 385 */       if (logger.isDebugEnabled())
/* 386 */         logger.debug("get warning task sql :" + sqlStr.toString());
/* 387 */       set = ServiceManager.getDataStore().retrieve(conn, sqlStr.toString(), paramMap);
/* 388 */       WarningTaskBean bean = null;
/* 389 */       List result = new ArrayList();
/* 390 */       while ((set != null) && (set.next())) {
/* 391 */         bean = new WarningTaskBean();
/* 392 */         bean.setTaskId(set.getString("TASK_ID"));
/* 393 */         bean.setStaffId(set.getString("TASK_STAFF_ID"));
/* 394 */         bean.setStationId(set.getString("STATION_ID"));
/* 395 */         bean.setWorkflowObjId(set.getString("WORKFLOW_OBJECT_ID"));
/* 396 */         bean.setWorkflowObjTypeId(set.getString("WORKFLOW_OBJECT_TYPE"));
/* 397 */         bean.setAlarmtimes(set.getInt("WARNING_TIMES"));
/* 398 */         bean.setDuration(set.getInt("DURATION"));
/* 399 */         bean.setTaskTag(set.getString("TASK_TAG"));
/* 400 */         bean.setTemplateTag(set.getString("TEMPLATE_TAG"));
/* 401 */         bean.setRegionId(set.getString("REGION_ID"));
/* 402 */         bean.setType("task");
/* 403 */         result.add(bean);
/*     */       }
/* 405 */       WarningTaskBean[] arrayOfWarningTaskBean = (WarningTaskBean[])(WarningTaskBean[])result.toArray(new WarningTaskBean[0]);
/*     */ 
/* 418 */       return arrayOfWarningTaskBean;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 414 */       if (set != null)
/* 415 */         set.close();
/* 416 */       if (conn != null)
/* 417 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public WarningTaskBean[] getWarningTaskTsData(String queueId, int mod, int value, int fetchNum)
/*     */     throws Exception
/*     */   {
/* 429 */     if (StringUtils.isBlank(queueId))
/*     */     {
/* 431 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_queueIDnotEmpty"));
/*     */     }
/* 433 */     if (mod <= 0)
/*     */     {
/* 435 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modeNotBelowZero"));
/*     */     }
/* 437 */     if (value < 0)
/*     */     {
/* 439 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmWorkflowDAOImpl_modValueNotBelowZero"));
/*     */     }
/*     */ 
/* 442 */     Connection conn = null;
/* 443 */     ResultSet set = null;
/*     */     try {
/* 445 */       conn = ServiceManager.getSession().getConnection();
/* 446 */       StringBuilder sqlStr = new StringBuilder("");
/* 447 */       HashMap paramMap = new HashMap();
/* 448 */       BOVmWFBean wfBean = new BOVmWFBean();
/* 449 */       BOVmTaskTSBean taskTsBean = new BOVmTaskTSBean();
/* 450 */       BOVmScheduleBean scheBean = new BOVmScheduleBean();
/*     */ 
/* 452 */       AssembleDef def = new AssembleDef();
/* 453 */       def.setQueueId(queueId);
/*     */ 
/* 455 */       String wfTableName = TableAssembleUtil.getTableName(wfBean.fetchTableName(), def);
/* 456 */       String taskTsTableName = TableAssembleUtil.getTableName(taskTsBean.fetchTableName(), def);
/* 457 */       String scheTableName = TableAssembleUtil.getTableName(scheBean.fetchTableName(), def);
/* 458 */       if ((StringUtils.isBlank(wfTableName)) || (StringUtils.isBlank(taskTsTableName)) || (StringUtils.isBlank(scheTableName)))
/*     */       {
/* 461 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getRealTableNameNotEmpty"));
/*     */       }
/*     */ 
/* 465 */       sqlStr.append(" select b.*,a.").append("TEMPLATE_TAG").append(",a.").append("WORKFLOW_OBJECT_ID").append(",a.").append("WORKFLOW_OBJECT_TYPE").append(" from ");
/*     */ 
/* 467 */       sqlStr.append(wfTableName).append(" a, ").append(taskTsTableName).append(" b, ").append(scheTableName).append(" c where 1 = 1 ");
/*     */ 
/* 470 */       sqlStr.append(" and b.").append("QUEUE_ID").append(" = :qid ");
/* 471 */       sqlStr.append(" and b.").append("WARNING_DATE").append(" <= :curTime ");
/* 472 */       sqlStr.append(" and b.").append("TASK_BASE_TYPE").append(" = :taskBaseType ");
/* 473 */       sqlStr.append(" and a.").append("STATE").append(" = :aState ");
/* 474 */       sqlStr.append(" and (b.").append("STATE").append(" = :bState or b.").append("STATE").append(" = :cState )");
/*     */ 
/* 476 */       sqlStr.append(" and a.").append("WORKFLOW_ID").append(" = b.").append("WORKFLOW_ID");
/* 477 */       sqlStr.append(" and a.").append("WORKFLOW_ID").append(" = c.").append("WORKFLOW_ID");
/* 478 */       sqlStr.append(" and mod(").append(IDAssembleUtil.wrappedIdColToNumFunc("TASK_ID")).append(",:mod ) = :value ");
/*     */ 
/* 481 */       paramMap.put("mod", String.valueOf(mod));
/* 482 */       paramMap.put("value", String.valueOf(value));
/* 483 */       paramMap.put("qid", queueId);
/* 484 */       paramMap.put("taskBaseType", "user");
/* 485 */       paramMap.put("aState", String.valueOf(2));
/* 486 */       paramMap.put("bState", String.valueOf(5));
/* 487 */       paramMap.put("cState", String.valueOf(9));
/* 488 */       paramMap.put("curTime", TimeUtil.getSysTime());
/*     */ 
/* 490 */       if (CenterFactory.isSetCenterInfo()) {
/* 491 */         CenterInfo center = CenterFactory.getCenterInfo();
/* 492 */         if ((center != null) && (StringUtils.isNotBlank(center.getRegion()))) {
/* 493 */           sqlStr.append(" and b.").append("REGION_ID").append(" = :regionId ");
/* 494 */           paramMap.put("regionId", center.getRegion());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 499 */       if (PropertiesUtil.isDev()) {
/* 500 */         String devName = PropertiesUtil.getDevId();
/* 501 */         if (StringUtils.isBlank(devName)) {
/* 502 */           String[] param = new String[1];
/* 503 */           param[0] = "comframe.dev.name";
/*     */ 
/* 505 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */         }
/* 507 */         sqlStr.append(" and c.").append("DEV_ID").append(" = :devId ");
/* 508 */         paramMap.put("devId", devName);
/*     */       } else {
/* 510 */         sqlStr.append(" and c.").append("DEV_ID").append(" is null ");
/*     */       }
/*     */ 
/* 513 */       if (logger.isDebugEnabled())
/* 514 */         logger.debug("get warning task sql :" + sqlStr.toString());
/* 515 */       set = ServiceManager.getDataStore().retrieve(conn, sqlStr.toString(), paramMap);
/* 516 */       WarningTaskBean bean = null;
/* 517 */       List result = new ArrayList();
/* 518 */       while ((set != null) && (set.next())) {
/* 519 */         bean = new WarningTaskBean();
/* 520 */         bean.setTaskId(set.getString("TASK_ID"));
/* 521 */         bean.setStaffId(set.getString("TASK_STAFF_ID"));
/* 522 */         bean.setStationId(set.getString("STATION_ID"));
/* 523 */         bean.setWorkflowObjId(set.getString("WORKFLOW_OBJECT_ID"));
/* 524 */         bean.setWorkflowObjTypeId(set.getString("WORKFLOW_OBJECT_TYPE"));
/* 525 */         bean.setAlarmtimes(set.getInt("WARNING_TIMES"));
/* 526 */         bean.setDuration(set.getInt("DURATION"));
/* 527 */         bean.setTaskTag(set.getString("TASK_TAG"));
/* 528 */         bean.setTemplateTag(set.getString("TEMPLATE_TAG"));
/* 529 */         bean.setRegionId(set.getString("REGION_ID"));
/* 530 */         bean.setType("taskTrans");
/* 531 */         result.add(bean);
/*     */       }
/* 533 */       WarningTaskBean[] arrayOfWarningTaskBean = (WarningTaskBean[])(WarningTaskBean[])result.toArray(new WarningTaskBean[0]);
/*     */ 
/* 546 */       return arrayOfWarningTaskBean;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 542 */       if (set != null)
/* 543 */         set.close();
/* 544 */       if (conn != null)
/* 545 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue getVmTaskbeanById(String taskId, int[] taskstate) throws Exception {
/* 550 */     if (StringUtils.isBlank(taskId))
/*     */     {
/* 552 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_taskNotEmpty"));
/*     */     }
/* 554 */     AssembleDef ad = new AssembleDef();
/* 555 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 556 */     BOVmTaskBean vtb = new BOVmTaskBean();
/* 557 */     StringBuffer cond = new StringBuffer();
/* 558 */     HashMap paramMap = new HashMap();
/* 559 */     cond.append("TASK_ID").append(" =:").append("TASK_ID");
/*     */ 
/* 561 */     if ((taskstate != null) && (taskstate.length > 0)) {
/* 562 */       if (taskstate.length == 1) {
/* 563 */         cond.append(" and ").append("STATE").append(" = :pstate ");
/* 564 */         paramMap.put("pstate", String.valueOf(taskstate[0]));
/*     */       }
/*     */       else {
/* 567 */         cond.append(" and ").append("STATE").append(" in (");
/* 568 */         for (int i = 0; i < taskstate.length; ++i) {
/* 569 */           cond.append(" :state").append(i);
/* 570 */           paramMap.put("state" + i, String.valueOf(taskstate[i]));
/* 571 */           if (i < taskstate.length - 1) {
/* 572 */             cond.append(",");
/*     */           }
/*     */         }
/* 575 */         cond.append(")");
/*     */       }
/*     */     }
/*     */ 
/* 579 */     paramMap.put("TASK_ID", taskId);
/* 580 */     String sql = TableAssembleUtil.createSelectSQL(vtb, ad, cond.toString(), -1, -1);
/* 581 */     IBOVmTaskValue[] tasks = BOVmTaskEngine.getBeansFromSql(sql, paramMap);
/*     */ 
/* 583 */     if ((tasks == null) || (tasks.length == 0))
/* 584 */       return null;
/* 585 */     if (tasks.length > 1)
/*     */     {
/* 587 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getMoreTsIns") + tasks.length);
/* 588 */     }return tasks[0];
/*     */   }
/*     */ 
/*     */   public IBOVmDealTaskValue[] getVmDealTask(String taskId) throws Exception {
/* 592 */     String cond = "TASK_ID=:TASK_ID";
/* 593 */     HashMap map = new HashMap();
/* 594 */     map.put("TASK_ID", taskId);
/* 595 */     AssembleDef ad = new AssembleDef();
/* 596 */     ad.setQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 597 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmDealTaskBean(), ad, cond, -1, -1);
/* 598 */     IBOVmDealTaskValue[] taskValues = BOVmDealTaskEngine.getBeansFromSql(sql, map);
/* 599 */     if ((taskValues == null) || (taskValues.length == 0)) {
/* 600 */       return null;
/*     */     }
/*     */ 
/* 604 */     return taskValues;
/*     */   }
/*     */ 
/*     */   public IBOVmDealTaskValue[] getVmDealTaskbeanByWorkflowId(String workflowId) throws Exception {
/* 608 */     AssembleDef def = new AssembleDef();
/* 609 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 610 */     BOVmDealTaskBean dealTaskBean = new BOVmDealTaskBean();
/* 611 */     String cond = "WORKFLOW_ID =:WORKFLOW_ID";
/* 612 */     HashMap map = new HashMap();
/* 613 */     map.put("WORKFLOW_ID", workflowId);
/* 614 */     String sql = TableAssembleUtil.createSelectSQL(dealTaskBean, def, cond, -1, -1);
/* 615 */     return BOVmDealTaskEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public void taskTSToHis(String workflowId, Timestamp transferDate) throws Exception
/*     */   {
/* 620 */     IBOVmTaskTSValue[] taskTs = getVmTaskTransBeans(workflowId, null);
/* 621 */     if ((taskTs == null) || (taskTs.length == 0)) {
/* 622 */       return;
/*     */     }
/* 624 */     BOHVmTaskTSBean[] hTaskTs = new BOHVmTaskTSBean[taskTs.length];
/* 625 */     for (int i = 0; i < taskTs.length; ++i) {
/* 626 */       hTaskTs[i] = new BOHVmTaskTSBean();
/* 627 */       hTaskTs[i].copy(taskTs[i]);
/* 628 */       hTaskTs[i].setStsToNew();
/* 629 */       hTaskTs[i].setTransferDate(transferDate);
/* 630 */       TableAssembleUtil.replaceHisTableName(hTaskTs[i]);
/* 631 */       taskTs[i].delete();
/* 632 */       TableAssembleUtil.replaceTableName((BOVmTaskTSBean)taskTs[i]);
/*     */     }
/* 634 */     BOHVmTaskTSEngine.saveBatch(hTaskTs);
/* 635 */     BOVmTaskTSEngine.saveBatch(taskTs);
/*     */   }
/*     */ 
/*     */   public void taskToHis(String workflowId, Timestamp transferDate) throws Exception
/*     */   {
/* 640 */     IBOVmTaskValue[] task = getVmTaskbeanByWorkflowId(workflowId);
/* 641 */     if ((task == null) || (task.length == 0)) {
/* 642 */       return;
/*     */     }
/* 644 */     BOHVmTaskBean[] hTask = new BOHVmTaskBean[task.length];
/* 645 */     for (int i = 0; i < task.length; ++i) {
/* 646 */       hTask[i] = new BOHVmTaskBean();
/* 647 */       hTask[i].copy(task[i]);
/* 648 */       hTask[i].setStsToNew();
/* 649 */       hTask[i].setTransferDate(transferDate);
/* 650 */       TableAssembleUtil.replaceHisTableName(hTask[i]);
/* 651 */       task[i].delete();
/* 652 */       TableAssembleUtil.replaceTableName((BOVmTaskBean)task[i]);
/*     */     }
/*     */ 
/* 655 */     BOHVmTaskEngine.saveBatch(hTask);
/* 656 */     BOVmTaskEngine.saveBatch(task);
/*     */   }
/*     */ 
/*     */   public IBOVmWFValue getVmWFInByID(String workflowID) throws Exception {
/* 660 */     if (StringUtils.isBlank(workflowID))
/*     */     {
/* 662 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_workflowIDNotEmpty"));
/*     */     }
/* 664 */     AssembleDef assemble = new AssembleDef();
/* 665 */     assemble.setQueueId(IDAssembleUtil.unwrapPrefix(workflowID));
/* 666 */     BOVmWFBean vtb = new BOVmWFBean();
/* 667 */     StringBuffer cond = new StringBuffer();
/* 668 */     HashMap paramMap = new HashMap();
/* 669 */     cond.append("WORKFLOW_ID").append(" =:").append("WORKFLOW_ID");
/* 670 */     paramMap.put("WORKFLOW_ID", workflowID);
/* 671 */     String sql = TableAssembleUtil.createSelectSQL(vtb, assemble, cond.toString(), -1, -1);
/* 672 */     IBOVmWFValue[] workflows = BOVmWFEngine.getBeansFromSql(sql, paramMap);
/* 673 */     if ((workflows == null) || (workflows.length == 0))
/* 674 */       return null;
/* 675 */     if (workflows.length > 1)
/*     */     {
/* 677 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl_getMoreByWorkflowID") + workflowID);
/* 678 */     }return workflows[0];
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue[] getTaskTransBeansParentOrWorkflowId(String parentTaskId, String workflowId) throws Exception {
/* 682 */     String id = parentTaskId;
/* 683 */     if ((StringUtils.isEmpty(parentTaskId)) || ("-1".equals(parentTaskId))) {
/* 684 */       id = workflowId;
/*     */     }
/* 686 */     if ((StringUtils.isEmpty(id)) || ("-1".equals(id))) {
/* 687 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.getTaskTransBeansParentOrWorkflowId_cannotTogether"));
/*     */     }
/* 689 */     StringBuffer cond = new StringBuffer();
/* 690 */     HashMap parameter = new HashMap();
/* 691 */     if ((!StringUtils.isEmpty(parentTaskId)) && (!"-1".equals(parentTaskId))) {
/* 692 */       cond.append(" PARENT_TASK_ID").append(" =:parentTaskId ");
/* 693 */       parameter.put("parentTaskId", parentTaskId);
/* 694 */       if ((!StringUtils.isEmpty(workflowId)) && (!"-1".equals(workflowId))) {
/* 695 */         cond.append(" and ").append("WORKFLOW_ID").append(" = :workflowId");
/* 696 */         parameter.put("workflowId", workflowId);
/*     */       }
/* 698 */     } else if ((!StringUtils.isEmpty(workflowId)) && (!"-1".equals(workflowId))) {
/* 699 */       cond.append("WORKFLOW_ID").append(" = :workflowId");
/* 700 */       parameter.put("workflowId", workflowId);
/*     */     }
/*     */ 
/* 703 */     AssembleDef def = new AssembleDef();
/* 704 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 705 */     String sql = TableAssembleUtil.createSelectSQL(new BOVmTaskTSBean(), def, cond.toString(), -1, -1);
/* 706 */     IBOVmTaskTSValue[] taskTs = BOVmTaskTSEngine.getBeansFromSql(sql, parameter);
/* 707 */     return taskTs;
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue[] getAllChildWorkflowTasks(String workflowId) throws Exception {
/* 711 */     AssembleDef def = new AssembleDef();
/* 712 */     def.setQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 713 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 714 */     StringBuilder cond = new StringBuilder("");
/* 715 */     HashMap map = new HashMap();
/* 716 */     cond.append("WORKFLOW_ID").append(" =:").append("WORKFLOW_ID");
/* 717 */     map.put("WORKFLOW_ID", workflowId);
/* 718 */     cond.append(" and ").append("TASK_BASE_TYPE").append(" =:").append("TASK_BASE_TYPE");
/* 719 */     map.put("TASK_BASE_TYPE", "childworkflow");
/* 720 */     String sql = TableAssembleUtil.createSelectSQL(taskBean, def, cond.toString(), -1, -1);
/* 721 */     return BOVmTaskEngine.getBeansFromSql(sql, map);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskValue[] getVmTaskBean(String queueID, String cond, HashMap param, int start, int end) throws Exception {
/* 725 */     AssembleDef assembleDef = new AssembleDef();
/* 726 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 727 */     assembleDef.setQueueId(queueID);
/* 728 */     String sql = TableAssembleUtil.createSelectSQL(taskBean, assembleDef, cond, start, end);
/* 729 */     return BOVmTaskEngine.getBeansFromSql(sql, param);
/*     */   }
/*     */ 
/*     */   public IBOVmTaskTSValue[] getVmTaskTSBean(String queueID, String cond, HashMap param, int start, int end) throws Exception {
/* 733 */     AssembleDef assembleDef = new AssembleDef();
/* 734 */     BOVmTaskTSBean taskBean = new BOVmTaskTSBean();
/* 735 */     assembleDef.setQueueId(queueID);
/* 736 */     String sql = TableAssembleUtil.createSelectSQL(taskBean, assembleDef, cond, start, end);
/* 737 */     return BOVmTaskTSEngine.getBeansFromSql(sql, param);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskValue[] getHisVmTaskBean(String queueID, String cond, HashMap param, int start, int end, String date) throws Exception {
/* 741 */     AssembleDef assembleDef = new AssembleDef();
/* 742 */     BOHVmTaskBean taskBean = new BOHVmTaskBean();
/* 743 */     assembleDef.setQueueId(queueID);
/* 744 */     assembleDef.setSdate(date);
/* 745 */     String sql = TableAssembleUtil.createHisSelectSQL(taskBean, assembleDef, cond, start, end);
/* 746 */     return BOHVmTaskEngine.getBeansFromSql(sql, param);
/*     */   }
/*     */ 
/*     */   public IBOHVmTaskTSValue[] getHisVmTaskTSBean(String queueID, String cond, HashMap param, int start, int end, String date) throws Exception {
/* 750 */     AssembleDef assembleDef = new AssembleDef();
/* 751 */     BOHVmTaskTSBean taskBean = new BOHVmTaskTSBean();
/* 752 */     assembleDef.setQueueId(queueID);
/* 753 */     assembleDef.setSdate(date);
/* 754 */     String sql = TableAssembleUtil.createHisSelectSQL(taskBean, assembleDef, cond, start, end);
/* 755 */     return BOHVmTaskTSEngine.getBeansFromSql(sql, param);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.workflow.dao.impl.VmTaskDAOImpl
 * JD-Core Version:    0.5.4
 */