/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.GridLayout;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JSplitPane;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.JViewport;
/*    */ 
/*    */ public class StaffOrStationSelectPanel extends JPanel
/*    */ {
/* 12 */   public static String TYPE_STAFF = "staff";
/* 13 */   public static String TYPE_STATION = "station";
/* 14 */   public static String TYPE_STATION_TYPE = "station_type";
/*    */ 
/* 17 */   JSplitPane jSplitPane1 = new JSplitPane();
/* 18 */   GridLayout gridLayout1 = new GridLayout();
/* 19 */   JTree jTree1 = new JTree();
/* 20 */   JScrollPane jScrollPane1 = new JScrollPane();
/* 21 */   JTable jTable1 = new JTable();
/*    */ 
/* 23 */   String m_type = TYPE_STAFF;
/* 24 */   boolean m_isIncludChildOrganize = false;
/*    */ 
/* 26 */   public StaffOrStationSelectPanel(String type) throws Exception { this.m_type = type;
/* 27 */     this.jTable1 = new JTable();
/* 28 */     this.jTable1.setSelectionMode(0);
/* 29 */     refreshGrid(-1);
/* 30 */     this.jTree1 = new OrganizeTree(-1, new OrganizeTreeValueChangeListener(this));
/* 31 */     jbInit(); }
/*    */ 
/*    */   public int getResultOrganizeId() {
/* 34 */     int rowIndex = this.jTable1.getSelectedRow();
/* 35 */     int result = -1;
/* 36 */     if (rowIndex >= 0)
/* 37 */       result = ((Integer)this.jTable1.getValueAt(rowIndex, 3)).intValue();
/* 38 */     return result;
/*    */   }
/*    */   public String getResultOrganizeName() {
/* 41 */     int rowIndex = this.jTable1.getSelectedRow();
/* 42 */     String result = "";
/* 43 */     if ((rowIndex >= 0) && 
/* 44 */       (this.jTable1.getValueAt(rowIndex, 4) != null)) {
/* 45 */       result = this.jTable1.getValueAt(rowIndex, 4).toString();
/*    */     }
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public int getResultId() {
/* 51 */     int rowIndex = this.jTable1.getSelectedRow();
/* 52 */     int result = -1;
/* 53 */     if (rowIndex >= 0)
/* 54 */       result = ((Integer)this.jTable1.getValueAt(rowIndex, 0)).intValue();
/* 55 */     return result;
/*    */   }
/*    */   public String getResultName() {
/* 58 */     int rowIndex = this.jTable1.getSelectedRow();
/* 59 */     String result = "";
/* 60 */     if ((rowIndex >= 0) && 
/* 61 */       (this.jTable1.getValueAt(rowIndex, 2) != null)) {
/* 62 */       result = this.jTable1.getValueAt(rowIndex, 2).toString();
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */   public void refreshGrid(int aId)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   private void jbInit()
/*    */     throws Exception
/*    */   {
/* 81 */     setLayout(this.gridLayout1);
/* 82 */     add(this.jSplitPane1, null);
/* 83 */     this.jSplitPane1.add(this.jTree1, "left");
/* 84 */     this.jSplitPane1.add(this.jScrollPane1, "right");
/* 85 */     this.jScrollPane1.getViewport().add(this.jTable1, null);
/* 86 */     this.jSplitPane1.setDividerLocation(200);
/*    */   }
/*    */   public static void main(String[] args) throws Exception {
/* 89 */     JFrame frame = new JFrame("workflow");
/* 90 */     frame.getContentPane().add(new StaffOrStationSelectPanel("staff"));
/* 91 */     frame.pack();
/* 92 */     frame.setVisible(true);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.StaffOrStationSelectPanel
 * JD-Core Version:    0.5.4
 */