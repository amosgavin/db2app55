/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ class DataRecoder
/*    */ {
/*    */   public int m_id;
/*    */   public String m_code;
/*    */   public String m_name;
/*    */   public int m_organizeId;
/*    */   public String m_organizeName;
/*    */ 
/*    */   public DataRecoder(String[] aStaff)
/*    */   {
/* 57 */     this.m_id = Integer.parseInt(aStaff[0]);
/* 58 */     this.m_code = aStaff[1];
/* 59 */     this.m_name = aStaff[2];
/* 60 */     this.m_organizeId = ((aStaff[3] == null) ? -1 : Integer.parseInt(aStaff[3]));
/* 61 */     this.m_organizeName = aStaff[4];
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.DataRecoder
 * JD-Core Version:    0.5.4
 */