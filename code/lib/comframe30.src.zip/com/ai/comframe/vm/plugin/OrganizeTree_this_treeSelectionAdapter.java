/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import javax.swing.event.TreeSelectionEvent;
/*    */ import javax.swing.event.TreeSelectionListener;
/*    */ 
/*    */ class OrganizeTree_this_treeSelectionAdapter
/*    */   implements TreeSelectionListener
/*    */ {
/*    */   OrganizeTree adaptee;
/*    */ 
/*    */   OrganizeTree_this_treeSelectionAdapter(OrganizeTree adaptee)
/*    */   {
/* 57 */     this.adaptee = adaptee;
/*    */   }
/*    */   public void valueChanged(TreeSelectionEvent e) {
/* 60 */     this.adaptee.this_valueChanged(e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.OrganizeTree_this_treeSelectionAdapter
 * JD-Core Version:    0.5.4
 */