/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import com.ai.appframe2.util.TreeNodeObject;
/*    */ import com.ai.appframe2.util.TreeRootNodeObject;
/*    */ import javax.swing.tree.DefaultMutableTreeNode;
/*    */ 
/*    */ public class OrganizeTreeMode extends DefaultMutableTreeNode
/*    */ {
/*    */   public OrganizeTreeMode(String aName, String[][] aOrganizes)
/*    */   {
/* 10 */     super(aName);
/* 11 */     TreeRootNodeObject root = new TreeRootNodeObject();
/* 12 */     for (int i = 0; i < aOrganizes.length; ++i) {
/* 13 */       TreeNodeObject tempObj = new TreeNodeObject(Integer.parseInt(aOrganizes[i][0]), (aOrganizes[i][2] == null) ? -1 : Integer.parseInt(aOrganizes[i][2]), aOrganizes[i][1]);
/*    */ 
/* 17 */       root.addNode(tempObj);
/*    */     }
/* 19 */     TreeNodeObject[] childs = root.getRootChilds();
/* 20 */     for (int i = 0; i < childs.length; ++i)
/* 21 */       addTreeNode(this, childs[i]); 
/*    */   }
/*    */ 
/*    */   static void addTreeNode(DefaultMutableTreeNode aTreeNode, TreeNodeObject aNodeObject) {
/* 24 */     DefaultMutableTreeNode node = new DefaultMutableTreeNode(aNodeObject);
/* 25 */     aTreeNode.add(node);
/* 26 */     TreeNodeObject[] childs = aNodeObject.getChilds();
/* 27 */     for (int i = 0; i < childs.length; ++i)
/* 28 */       addTreeNode(node, childs[i]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.OrganizeTreeMode
 * JD-Core Version:    0.5.4
 */