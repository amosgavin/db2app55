/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.awt.event.MouseEvent;
/*    */ 
/*    */ class OrganizeTree_this_mouseAdapter extends MouseAdapter
/*    */ {
/*    */   OrganizeTree adaptee;
/*    */ 
/*    */   OrganizeTree_this_mouseAdapter(OrganizeTree adaptee)
/*    */   {
/* 68 */     this.adaptee = adaptee;
/*    */   }
/*    */   public void mouseClicked(MouseEvent e) {
/* 71 */     this.adaptee.this_mouseClicked(e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.OrganizeTree_this_mouseAdapter
 * JD-Core Version:    0.5.4
 */