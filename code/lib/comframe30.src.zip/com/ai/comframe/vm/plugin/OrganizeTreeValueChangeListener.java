/*     */ package com.ai.comframe.vm.plugin;
/*     */ 
/*     */ import com.ai.appframe2.util.TreeNodeObject;
/*     */ import com.ai.appframe2.util.TreeValueChangeListener;
/*     */ 
/*     */ class OrganizeTreeValueChangeListener
/*     */   implements TreeValueChangeListener
/*     */ {
/*     */   StaffOrStationSelectPanel m_panel;
/*     */ 
/*     */   public OrganizeTreeValueChangeListener(StaffOrStationSelectPanel panel)
/*     */   {
/*  99 */     this.m_panel = panel;
/*     */   }
/*     */   public void execute(TreeNodeObject eventObj) throws Exception {
/* 102 */     this.m_panel.refreshGrid(eventObj.getId());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.OrganizeTreeValueChangeListener
 * JD-Core Version:    0.5.4
 */