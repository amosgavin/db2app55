/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import javax.swing.event.TableModelListener;
/*    */ import javax.swing.table.TableModel;
/*    */ 
/*    */ public class StaffOrStationGridModel
/*    */   implements TableModel
/*    */ {
/*  8 */   String[] m_names = { ComframeLocaleFactory.getResource("com.ai.appframe2.vm.plugin.StaffOrStationGridModel.m_names_code"), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.plugin.StaffOrStationGridModel.m_names_daima"), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.plugin.StaffOrStationGridModel.m_names_name"), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.plugin.StaffOrStationGridModel.m_names_orgCode"), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.plugin.StaffOrStationGridModel.m_names_orgName") };
/*  9 */   Class[] m_classes = { Integer.class, String.class, String.class, Integer.class, String.class };
/*    */   DataRecoder[] m_list;
/*    */ 
/*    */   public StaffOrStationGridModel(String[][] aRecoders)
/*    */   {
/* 12 */     this.m_list = new DataRecoder[aRecoders.length];
/* 13 */     for (int i = 0; i < aRecoders.length; ++i)
/* 14 */       this.m_list[i] = new DataRecoder(aRecoders[i]); 
/*    */   }
/*    */ 
/*    */   public int getRowCount() {
/* 17 */     return this.m_list.length;
/*    */   }
/*    */   public int getColumnCount() {
/* 20 */     return this.m_names.length;
/*    */   }
/*    */   public String getColumnName(int columnIndex) {
/* 23 */     return this.m_names[columnIndex];
/*    */   }
/*    */   public Class getColumnClass(int columnIndex) {
/* 26 */     return this.m_classes[columnIndex];
/*    */   }
/*    */   public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 29 */     return false;
/*    */   }
/*    */   public Object getValueAt(int rowIndex, int columnIndex) {
/* 32 */     switch (columnIndex)
/*    */     {
/*    */     case 0:
/* 33 */       return new Integer(this.m_list[rowIndex].m_id);
/*    */     case 1:
/* 34 */       return this.m_list[rowIndex].m_code;
/*    */     case 2:
/* 35 */       return this.m_list[rowIndex].m_name;
/*    */     case 3:
/* 36 */       return new Integer(this.m_list[rowIndex].m_organizeId);
/*    */     case 4:
/* 37 */       return this.m_list[rowIndex].m_organizeName;
/*    */     }
/* 39 */     return "";
/*    */   }
/*    */ 
/*    */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void addTableModelListener(TableModelListener l)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void removeTableModelListener(TableModelListener l)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.StaffOrStationGridModel
 * JD-Core Version:    0.5.4
 */