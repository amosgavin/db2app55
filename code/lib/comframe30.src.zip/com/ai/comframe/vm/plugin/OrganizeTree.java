/*    */ package com.ai.comframe.vm.plugin;
/*    */ 
/*    */ import com.ai.appframe2.util.DefaultTreeValueChangeListener;
/*    */ import com.ai.appframe2.util.TreeNodeObject;
/*    */ import com.ai.appframe2.util.TreeValueChangeListener;
/*    */ import java.awt.Container;
/*    */ import java.awt.event.MouseEvent;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JTree;
/*    */ import javax.swing.event.TreeSelectionEvent;
/*    */ import javax.swing.tree.DefaultMutableTreeNode;
/*    */ import javax.swing.tree.TreePath;
/*    */ 
/*    */ public class OrganizeTree extends JTree
/*    */ {
/*    */   TreeValueChangeListener m_listener;
/*    */ 
/*    */   public OrganizeTree(int aOrganizeId, TreeValueChangeListener aListener)
/*    */     throws Exception
/*    */   {
/* 15 */     this.m_listener = aListener;
/*    */ 
/* 18 */     jbInit();
/*    */   }
/*    */ 
/*    */   private void jbInit() throws Exception {
/* 22 */     addMouseListener(new OrganizeTree_this_mouseAdapter(this));
/* 23 */     addTreeSelectionListener(new OrganizeTree_this_treeSelectionAdapter(this));
/*    */   }
/*    */ 
/*    */   void this_valueChanged(TreeSelectionEvent e) {
/* 27 */     Object[] list = e.getPath().getPath();
/* 28 */     if ((list == null) || (list.length == 0))
/* 29 */       return;
/* 30 */     Object node = ((DefaultMutableTreeNode)list[(list.length - 1)]).getUserObject();
/* 31 */     if ((!node instanceof TreeNodeObject) || (this.m_listener == null)) return;
/*    */     try {
/* 33 */       this.m_listener.execute((TreeNodeObject)node);
/*    */     } catch (Exception ex) {
/* 35 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 40 */     JFrame frame = new JFrame("workflow");
/* 41 */     frame.getContentPane().add(new OrganizeTree(-1, new DefaultTreeValueChangeListener()));
/* 42 */     frame.pack();
/* 43 */     frame.setVisible(true);
/*    */   }
/*    */ 
/*    */   void this_mouseClicked(MouseEvent e)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.plugin.OrganizeTree
 * JD-Core Version:    0.5.4
 */