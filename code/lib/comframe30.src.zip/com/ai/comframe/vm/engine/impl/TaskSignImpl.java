/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.FlowFactory;
/*     */ import com.ai.comframe.vm.engine.TaskSign;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.engine.WorkflowExpress;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskSignTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskTSBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import java.sql.Date;
/*     */ 
/*     */ public class TaskSignImpl extends TaskUserImpl
/*     */   implements TaskSign
/*     */ {
/*     */   public TaskSignImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*     */     throws Exception
/*     */   {
/*  39 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*     */   }
/*     */ 
/*     */   public TaskSignImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*     */   {
/*  44 */     super(aWorkflow, aTaskTemplate, inBean);
/*     */   }
/*     */ 
/*     */   public Object executeInner(WorkflowContext context) throws Exception {
/*  48 */     TaskUserTemplate task = (TaskUserTemplate)getTaskTemplate();
/*     */ 
/*  50 */     TaskDealBean dealBean = task.getAutoDealBean();
/*     */ 
/*  52 */     if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/*  53 */       executeDealInner(this, context, dealBean);
/*     */     }
/*     */ 
/*  56 */     Object isWait = getContextValue(this, context, "$IS_WAIT_USER");
/*  57 */     if ((isWait != null) && (isWait instanceof Boolean) && (!((Boolean)isWait).booleanValue()))
/*     */     {
/*  59 */       updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.executeInner_noNeedEnterHandNode"));
/*  60 */       context.remvoe("$IS_WAIT_USER");
/*     */     }
/*     */     else
/*     */     {
/*  65 */       setDuration();
/*     */ 
/*  67 */       if (!task.isNeedPrint()) {
/*  68 */         updateState(5, "");
/*     */       }
/*     */       else
/*     */       {
/*  72 */         updateState(9, "");
/*     */       }
/*     */ 
/*  75 */       dispatch(context);
/*     */ 
/*  77 */       updateState(5, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.executeInner_taskWaitEnd"));
/*     */ 
/*  79 */       if (task.isOverTime() == true)
/*     */       {
/*  81 */         TaskTimerImpl.insertTimerRecord(getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "OVERTIME", getRuntime(context));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  90 */     return new Boolean(true);
/*     */   }
/*     */ 
/*     */   private void dispatch(WorkflowContext context) throws Exception {
/*  94 */     TaskSignTemplate template = (TaskSignTemplate)getTaskTemplate();
/*  95 */     String type = template.getTaskUserType();
/*  96 */     String userIdStr = template.getTaskUserId();
/*  97 */     String organizeIdStr = template.getOrganizeId();
/*     */ 
/*  99 */     if (StringUtils.isEmptyString(userIdStr)) {
/* 100 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_noTaskID") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_dealManInfo"));
/*     */     }
/*     */ 
/* 104 */     if (userIdStr.charAt(0) == ':') {
/* 105 */       userIdStr = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(userIdStr.substring(1)));
/*     */     }
/* 107 */     String[] userIds = userIdStr.split(";");
/* 108 */     if ((userIds == null) || (userIds.length == 0)) {
/* 109 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_noTaskID") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_dealManInfo"));
/*     */     }
/*     */ 
/* 113 */     String[] orgIds = null;
/* 114 */     if ((organizeIdStr != null) && (organizeIdStr.charAt(0) == ':')) {
/* 115 */       organizeIdStr = (String)getWorkflow().getWorkflowExpress().execute(organizeIdStr.substring(1));
/*     */     }
/*     */ 
/* 118 */     if (organizeIdStr != null) {
/* 119 */       orgIds = organizeIdStr.split(";");
/*     */     }
/*     */ 
/* 122 */     if ((orgIds != null) && (userIds.length > 1) && (orgIds.length != userIds.length)) {
/* 123 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_postTypeOrgNoMatch"));
/*     */     }
/*     */ 
/* 126 */     if (type.charAt(0) == ':') {
/* 127 */       type = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(type.substring(1)));
/*     */     }
/*     */ 
/* 130 */     IBOVmTaskTSValue[] beans = null;
/* 131 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 132 */     if (!type.equalsIgnoreCase("stationType")) {
/* 133 */       beans = new IBOVmTaskTSValue[userIds.length];
/*     */ 
/* 135 */       for (int i = 0; i < userIds.length; ++i) {
/* 136 */         String userId = userIds[i];
/*     */ 
/* 138 */         beans[i] = new BOVmTaskTSBean();
/* 139 */         beans[i].copy(getDataBean());
/* 140 */         beans[i].setTaskId(taskDao.getNewTaskTransId(beans[i].getQueueId(), getWorkflow().getDistrictId()));
/* 141 */         beans[i].setParentTaskId(getTaskId());
/* 142 */         if (type.equalsIgnoreCase("staff") == true)
/* 143 */           beans[i].setTaskStaffId(userId);
/* 144 */         else if (type.equalsIgnoreCase("station") == true)
/* 145 */           beans[i].setStationId(userId);
/* 146 */         beans[i].setDuration(this.m_dc.getAsInt(S_DURATION));
/* 147 */         beans[i].setWarningDate(this.m_dc.getAsDateTime(S_WARNING_DATE));
/* 148 */         beans[i].setWarningTimes(this.m_dc.getAsInt(S_WARNING_TIMES));
/* 149 */         beans[i].setCreateDate(TimeUtil.getSysTime());
/* 150 */         beans[i].setStateDate(TimeUtil.getSysTime());
/* 151 */         beans[i].setStsToNew();
/*     */ 
/* 153 */         ((Workflow)getWorkflow()).addUserTaskCount();
/* 154 */         FlowFactory.saveTaskTrans(beans[i]);
/*     */ 
/* 156 */         if (template.isAutoPrint() == true)
/*     */         {
/* 158 */           TaskTimerImpl.insertTimerRecord(beans[i].getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "PRINT", null);
/*     */         }
/*     */ 
/* 166 */         TaskDealBean dealBean = template.getChildDealBean();
/*     */ 
/* 168 */         if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/* 169 */           String taskId = this.m_dc.getAsString(S_TASK_ID);
/*     */ 
/* 171 */           this.m_dc.set(S_TASK_ID, beans[i].getTaskId());
/*     */           try
/*     */           {
/* 174 */             context.set("$DEAL_STAFF_TYPE", type);
/* 175 */             context.set("$DEAL_STAFF_ID", userId);
/* 176 */             executeDealInner(this, context, dealBean);
/*     */           }
/*     */           finally {
/* 179 */             this.m_dc.set(S_TASK_ID, taskId);
/* 180 */             context.set("$DEAL_STAFF_TYPE", null);
/* 181 */             context.set("$DEAL_STAFF_ID", null);
/*     */           }
/*     */         }
/*     */       }
/*     */     } else {
/* 186 */       if ((orgIds == null) || (orgIds.length == 0)) {
/* 187 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_noTaskID") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.dispatch_taskPeiOrginfo"));
/*     */       }
/*     */ 
/* 191 */       beans = new BOVmTaskTSBean[orgIds.length];
/* 192 */       for (int i = 0; i < orgIds.length; ++i) {
/* 193 */         String orgId = orgIds[i];
/* 194 */         String userId = "";
/* 195 */         if (userIds.length == orgIds.length) {
/* 196 */           userId = userIds[i];
/*     */         }
/*     */         else {
/* 199 */           userId = userIds[0];
/*     */         }
/*     */ 
/* 202 */         beans[i] = new BOVmTaskTSBean();
/* 203 */         beans[i].copy(getDataBean());
/*     */ 
/* 205 */         beans[i].setParentTaskId(getTaskId());
/* 206 */         beans[i].setStationId(FlowFactory.getStationId(orgId, userId));
/* 207 */         beans[i].setDuration(this.m_dc.getAsInt(S_DURATION));
/* 208 */         beans[i].setWarningDate(this.m_dc.getAsDateTime(S_WARNING_DATE));
/* 209 */         beans[i].setWarningTimes(this.m_dc.getAsInt(S_WARNING_TIMES));
/* 210 */         beans[i].setCreateDate(TimeUtil.getSysTime());
/* 211 */         beans[i].setStateDate(TimeUtil.getSysTime());
/* 212 */         beans[i].setStsToNew();
/*     */ 
/* 214 */         ((Workflow)getWorkflow()).addUserTaskCount();
/* 215 */         FlowFactory.saveTaskTrans(beans[i]);
/*     */ 
/* 217 */         if (template.isAutoPrint() == true)
/*     */         {
/* 219 */           TaskTimerImpl.insertTimerRecord(beans[i].getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "PRINT", null);
/*     */         }
/*     */ 
/* 227 */         TaskDealBean dealBean = template.getChildDealBean();
/*     */ 
/* 229 */         if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/* 230 */           String taskId = this.m_dc.getAsString(S_TASK_ID);
/*     */ 
/* 232 */           this.m_dc.set(S_TASK_ID, beans[i].getTaskId());
/*     */           try
/*     */           {
/* 235 */             context.set("$DEAL_STAFF_TYPE", type);
/* 236 */             context.set("$DEAL_STAFF_ID", userId);
/* 237 */             executeDealInner(this, context, dealBean);
/*     */           }
/*     */           finally {
/* 240 */             this.m_dc.set(S_TASK_ID, taskId);
/* 241 */             context.set("$DEAL_STAFF_TYPE", null);
/* 242 */             context.set("$DEAL_STAFF_ID", null);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskSignImpl
 * JD-Core Version:    0.5.4
 */