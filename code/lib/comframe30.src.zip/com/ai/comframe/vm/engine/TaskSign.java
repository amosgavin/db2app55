package com.ai.comframe.vm.engine;

public abstract interface TaskSign extends Task
{
  public abstract void finish(String paramString1, String paramString2, String paramString3, WorkflowContext paramWorkflowContext)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskSign
 * JD-Core Version:    0.5.4
 */