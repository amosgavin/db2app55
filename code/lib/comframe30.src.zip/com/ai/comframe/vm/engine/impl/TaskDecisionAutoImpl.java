/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import com.ai.comframe.vm.common.VMDataType;
/*    */ import com.ai.comframe.vm.common.VMException;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.TaskDecision;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskDealBean;
/*    */ import com.ai.comframe.vm.template.TaskDecisionAutoTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ 
/*    */ public class TaskDecisionAutoImpl extends TaskAutoImpl
/*    */   implements TaskDecision
/*    */ {
/* 22 */   protected static String S_DECISION_RESULT = "DECISION_RESULT";
/*    */ 
/*    */   public TaskDecisionAutoImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 27 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskDecisionAutoImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */     throws Exception
/*    */   {
/* 33 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object getDecision()
/*    */   {
/* 40 */     return VMDataType.getAsString(this.m_dc.get(S_DECISION_RESULT));
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 44 */     TaskDecisionAutoTemplate task = (TaskDecisionAutoTemplate)getTaskTemplate();
/* 45 */     TaskDealBean dealBean = task.getAutoDealBean();
/*    */ 
/* 47 */     if ((dealBean == null) || (StringUtils.isEmptyString(dealBean.getRunClassName())))
/*    */     {
/* 49 */       updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete"));
/* 50 */       return Boolean.TRUE;
/*    */     }
/*    */ 
/* 53 */     ParameterDefine returnDefine = dealBean.getReturnParameterDefine();
/*    */ 
/* 55 */     if (returnDefine == null) {
/* 56 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskDecisionAutoImpl.executeInner_checkAutoDefinedResult"));
/*    */     }
/*    */ 
/* 59 */     Object returnObj = null;
/*    */ 
/* 61 */     if ("service".equalsIgnoreCase(dealBean.getRunType()) == true) {
/* 62 */       returnObj = invokeService(this, dealBean, context);
/*    */     }
/*    */     else {
/* 65 */       returnObj = invokePojo(this, dealBean, context);
/*    */     }
/* 67 */     this.m_dc.set(S_DECISION_RESULT, returnObj);
/* 68 */     context.set("_TASK_JUGE_RESULT", returnObj);
/* 69 */     if ((returnDefine.contextVarName != null) && (returnDefine.contextVarName.length() != 0))
/*    */     {
/* 71 */       context.set(returnDefine.contextVarName, returnObj);
/*    */     }
/*    */ 
/* 75 */     updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete"));
/* 76 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskDecisionAutoImpl
 * JD-Core Version:    0.5.4
 */