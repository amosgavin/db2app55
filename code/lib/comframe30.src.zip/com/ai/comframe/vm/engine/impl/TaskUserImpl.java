/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.FlowFactory;
/*     */ import com.ai.comframe.vm.engine.TaskDecision;
/*     */ import com.ai.comframe.vm.engine.TaskUser;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.engine.WorkflowExpress;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskTSBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TaskUserImpl extends TaskAutoImpl
/*     */   implements TaskUser, TaskDecision
/*     */ {
/*  43 */   private static transient Log log = LogFactory.getLog(TaskUserImpl.class);
/*     */   public static final String S_LOCK_DATE = "LOCK_DATE";
/*     */   public static final String S_LOCK_STAFF_ID = "LOCK_STAFF_ID";
/*     */   public static final String S_TASK_STAFF_ID = "TASK_STAFF_ID";
/*     */   public static final String S_STATION_ID = "STATION_ID";
/*     */   public static final String S_FINISH_STAFF_ID = "FINISH_STAFF_ID";
/*     */   public static final String S_FINISH_DATE = "FINISH_DATE";
/*     */   public static final String S_DECISION_RESULT = "DECISION_RESULT";
/*     */ 
/*     */   public TaskUserImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*     */     throws Exception
/*     */   {
/*  56 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*     */   }
/*     */ 
/*     */   public TaskUserImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*     */   {
/*  61 */     super(aWorkflow, aTaskTemplate, inBean);
/*     */   }
/*     */ 
/*     */   public Object getDecision() {
/*  65 */     return VMDataType.getAsString(this.m_dc.get("DECISION_RESULT"));
/*     */   }
/*     */ 
/*     */   public Object execute(WorkflowContext context) throws Exception
/*     */   {
/*     */     try {
/*  71 */       monitor(PropertiesUtil.getSystemUserId(), null, 1);
/*  72 */       return executeInner(context);
/*     */     }
/*     */     catch (Throwable t) {
/*  75 */       monitor(PropertiesUtil.getSystemUserId(), t, 5);
/*  76 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object executeInner(WorkflowContext context) throws Exception {
/*  81 */     TaskUserTemplate task = (TaskUserTemplate)getTaskTemplate();
/*     */ 
/*  84 */     TaskDealBean dealBean = task.getAutoDealBean();
/*     */ 
/*  86 */     if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/*  87 */       executeDealInner(this, context, dealBean);
/*     */     }
/*     */ 
/*  91 */     Object isWait = getContextValue(this, context, "$IS_WAIT_USER");
/*  92 */     if ((isWait != null) && (isWait instanceof Boolean) && (!((Boolean)isWait).booleanValue()))
/*     */     {
/*  95 */       updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskSignImpl.executeInner_noNeedEnterHandNode"));
/*  96 */       context.remvoe("$IS_WAIT_USER");
/*     */     }
/*     */     else
/*     */     {
/* 100 */       setDuration();
/*     */ 
/* 103 */       findAndSetStationId();
/*     */ 
/* 105 */       if (!task.isNeedPrint()) {
/* 106 */         updateState(5, "");
/*     */       }
/*     */       else {
/* 109 */         if (task.isAutoPrint() == true)
/*     */         {
/* 111 */           TaskTimerImpl.insertTimerRecord(getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "PRINT", null);
/*     */         }
/*     */ 
/* 118 */         updateState(9, "");
/*     */       }
/*     */ 
/* 121 */       ((Workflow)getWorkflow()).addUserTaskCount();
/*     */ 
/* 123 */       if (task.isOverTime() == true)
/*     */       {
/* 125 */         TaskTimerImpl.insertTimerRecord(getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "OVERTIME", getRuntime(context));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 134 */     return new Boolean(true);
/*     */   }
/*     */ 
/*     */   public void finishOverTime(String result, String staffId, String reason, WorkflowContext context)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 142 */       Timestamp time = TimeUtil.getSysTime();
/* 143 */       IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 144 */       IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(getTaskId(), new int[] { 5, 9 });
/* 145 */       if (taskBean == null) {
/* 146 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*     */       }
/*     */ 
/* 149 */       taskBean.setFinishStaffId(staffId);
/* 150 */       taskBean.setExeFinishDate(taskBean.getStateDate());
/* 151 */       taskBean.setFinishDate(time);
/* 152 */       taskBean.setState(4);
/* 153 */       taskBean.setStateDate(time);
/* 154 */       taskBean.setDecisionResult(result);
/* 155 */       taskBean.setDescription(reason);
/* 156 */       taskDAO.saveVmtaskInstacne(taskBean);
/* 157 */       IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 158 */       IBOVmWFValue wfBean = workflowDAO.getVmWorkflowBeanbyId(this.workflow.getWorkflowId());
/* 159 */       wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 160 */       workflowDAO.saveVmWorkflowInstacne(wfBean);
/* 161 */       context.set("_TASK_JUGE_RESULT", result);
/*     */ 
/* 163 */       if (this instanceof TaskSignImpl) {
/* 164 */         IBOVmTaskTSValue[] transTasks = FlowFactory.getTaskTransBeansParentOrWorkflowId(getTaskId(), this.workflow.getWorkflowId());
/*     */ 
/* 166 */         for (int j = 0; j < transTasks.length; ++j) {
/* 167 */           transTasks[j].setFinishDate(time);
/* 168 */           ((Workflow)getWorkflow()).realseUserTaskCount();
/*     */           try {
/* 170 */             TaskTimerImpl.deleteTimerRecord(transTasks[j].getTaskId());
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */           }
/*     */         }
/* 176 */         FlowFactory.saveTaskTrans(transTasks);
/*     */       }
/*     */ 
/* 180 */       monitor(staffId, null, 4);
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 184 */       monitor(staffId, t, 5);
/* 185 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void finish(String result, String staffId, String reason, WorkflowContext context)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 196 */       Timestamp time = TimeUtil.getSysTime();
/* 197 */       IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 198 */       IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(getTaskId(), new int[] { 5, 9 });
/* 199 */       if (taskBean == null) {
/* 200 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*     */       }
/*     */ 
/* 203 */       taskBean.setFinishStaffId(staffId);
/* 204 */       taskBean.setExeFinishDate(taskBean.getStateDate());
/* 205 */       taskBean.setFinishDate(time);
/* 206 */       taskBean.setState(3);
/* 207 */       taskBean.setStateDate(time);
/* 208 */       taskBean.setDecisionResult(result);
/* 209 */       taskBean.setDescription(reason);
/* 210 */       taskDAO.saveVmtaskInstacne(taskBean);
/*     */ 
/* 212 */       IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 213 */       IBOVmWFValue wfBean = workflowDAO.getVmWorkflowBeanbyId(this.workflow.getWorkflowId());
/* 214 */       wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 215 */       workflowDAO.saveVmWorkflowInstacne(wfBean);
/*     */ 
/* 217 */       context.set("_TASK_JUGE_RESULT", result);
/*     */ 
/* 220 */       executeDealInner(this, context, ((TaskUserTemplate)getTaskTemplate()).getPostDealBean());
/*     */ 
/* 224 */       monitor(staffId, null, 4);
/*     */     }
/*     */     catch (Throwable t) {
/* 227 */       monitor(staffId, t, 5);
/* 228 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean print(String staffId, WorkflowContext context) throws Exception {
/* 232 */     boolean isWaitUser = true;
/*     */     try
/*     */     {
/* 235 */       executeDealInner(this, context, ((TaskUserTemplate)getTaskTemplate()).getPrintDealBean());
/*     */ 
/* 241 */       IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 242 */       IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(getTaskId(), new int[] { 9 });
/* 243 */       if (taskBean == null) {
/* 244 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*     */       }
/*     */ 
/* 248 */       taskBean.setFinishStaffId(staffId);
/*     */ 
/* 250 */       Object isWait = getContextValue(this, context, "$IS_WAIT_USER");
/* 251 */       if ((isWait != null) && (isWait instanceof Boolean) && (!((Boolean)isWait).booleanValue()))
/*     */       {
/* 253 */         isWaitUser = false;
/* 254 */         taskBean.setState(3);
/* 255 */         context.remvoe("$IS_WAIT_USER");
/*     */       }
/*     */       else {
/* 258 */         taskBean.setState(5);
/*     */       }
/* 260 */       taskBean.setDecisionResult("");
/* 261 */       taskBean.setErrorMessage("");
/* 262 */       taskDAO.saveVmtaskInstacne(taskBean);
/*     */ 
/* 264 */       if (!isWaitUser) {
/* 265 */         IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 266 */         IBOVmWFValue wfBean = workflowDAO.getVmWorkflowBeanbyId(this.workflow.getWorkflowId());
/* 267 */         wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 268 */         workflowDAO.saveVmWorkflowInstacne(wfBean);
/*     */       }
/*     */ 
/* 271 */       monitor(staffId, null, 3);
/*     */     }
/*     */     catch (Throwable t) {
/* 274 */       monitor(staffId, t, 5);
/* 275 */       throw new Exception(t);
/*     */     }
/* 277 */     return isWaitUser;
/*     */   }
/*     */ 
/*     */   public String reAuthorize(String authorizeStaffId, String authorizeStationId, String staffId) throws Exception {
/* 281 */     int state = getState();
/* 282 */     if ((state != 5) && (state != 9)) {
/* 283 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*     */     }
/* 285 */     Timestamp time = TimeUtil.getSysTime();
/*     */ 
/* 287 */     IVmTaskDAO taskDao = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 288 */     IBOVmTaskTSValue transBean = new BOVmTaskTSBean();
/* 289 */     transBean.copy(getDataBean());
/* 290 */     String newTaskId = taskDao.getNewTaskTransId(IDAssembleUtil.unwrapPrefix(getTaskId()), getWorkflow().getDistrictId());
/* 291 */     transBean.setTaskId(newTaskId);
/* 292 */     transBean.setParentTaskId(getTaskId());
/* 293 */     transBean.setTaskStaffId(authorizeStaffId);
/* 294 */     transBean.setStationId(authorizeStationId);
/* 295 */     transBean.setDuration(getDataBean().getAsLong(S_DURATION));
/* 296 */     transBean.setWarningDate(getDataBean().getAsDateTime(S_WARNING_DATE));
/* 297 */     transBean.setWarningTimes(0);
/* 298 */     transBean.setCreateDate(time);
/* 299 */     transBean.setStateDate(time);
/* 300 */     transBean.setStsToNew();
/* 301 */     FlowFactory.saveTaskTrans(transBean);
/*     */ 
/* 303 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 304 */     IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(getTaskId(), new int[] { state });
/* 305 */     if (taskBean == null) {
/* 306 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_processTask") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finishOverTime_endOrStateError"));
/*     */     }
/*     */ 
/* 309 */     taskBean.setFinishStaffId(staffId);
/* 310 */     taskBean.setExeFinishDate(taskBean.getStateDate());
/* 311 */     taskBean.setFinishDate(time);
/* 312 */     taskBean.setState(10);
/* 313 */     taskBean.setStateDate(time);
/* 314 */     taskBean.setDecisionResult("");
/* 315 */     taskBean.setErrorMessage("");
/* 316 */     taskDAO.saveVmtaskInstacne(taskBean);
/*     */ 
/* 319 */     DataContainerInterface dc = getDataBean();
/* 320 */     if ((dc.get("TASK_STAFF_ID") == null) || (dc.get("STATION_ID") != null)) {
/* 321 */       dc.set("TASK_STAFF_ID", staffId);
/* 322 */       FlowFactory.save((BOVmTaskBean)dc);
/*     */     }
/* 324 */     return newTaskId;
/*     */   }
/*     */ 
/*     */   public void findAndSetStationId()
/*     */     throws Exception
/*     */   {
/* 331 */     if ((!StringUtils.isEmptyString(getDataBean().getAsString("TASK_STAFF_ID"))) || (!StringUtils.isEmptyString(getDataBean().getAsString("STATION_ID"))))
/*     */     {
/* 333 */       return;
/*     */     }
/* 335 */     TaskUserTemplate template = (TaskUserTemplate)getTaskTemplate();
/* 336 */     String type = template.getTaskUserType();
/* 337 */     String userIdStr = template.getTaskUserId();
/* 338 */     String organizeIdStr = template.getOrganizeId();
/*     */ 
/* 340 */     String userId = "";
/* 341 */     if (StringUtils.isEmptyString(userIdStr)) {
/* 342 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.findAndSetStationId_noTaskID") + getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.findAndSetStationId_configDealManInfo"));
/*     */     }
/* 344 */     if (userIdStr.charAt(0) == ':')
/* 345 */       userId = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(userIdStr.substring(1)));
/*     */     else {
/* 347 */       userId = userIdStr;
/*     */     }
/* 349 */     if (type.charAt(0) == ':') {
/* 350 */       type = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(type.substring(1)));
/*     */     }
/*     */ 
/* 353 */     if (type.equalsIgnoreCase("staff") == true) {
/* 354 */       this.m_dc.set("TASK_STAFF_ID", userId);
/* 355 */     } else if (type.equalsIgnoreCase("station") == true) {
/* 356 */       this.m_dc.set("STATION_ID", userId);
/* 357 */     } else if (type.equalsIgnoreCase("stationType") == true) {
/* 358 */       String organizeId = "";
/* 359 */       if (organizeIdStr.charAt(0) == ':')
/* 360 */         organizeId = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(organizeIdStr.substring(1)));
/*     */       else
/* 362 */         organizeId = organizeIdStr;
/* 363 */       String stationId = FlowFactory.getStationId(organizeId, userId);
/* 364 */       this.m_dc.set("STATION_ID", stationId);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Date getRuntime(WorkflowContext context)
/*     */     throws Exception
/*     */   {
/* 372 */     TaskUserTemplate task = (TaskUserTemplate)getTaskTemplate();
/* 373 */     String type = task.getOvertimeType();
/* 374 */     String strTime = task.getOvertimeValue();
/*     */ 
/* 376 */     if (strTime.startsWith(":"))
/* 377 */       strTime = getContextValue(this, context, strTime.substring(1)).toString();
/*     */     Date runTime;
/*     */     Date runTime;
/* 379 */     if ((strTime.indexOf(":") > 0) && (strTime.indexOf("-") > 0)) {
/* 380 */       Timestamp tem = (Timestamp)DataType.transfer(strTime, "DateTime");
/*     */ 
/* 382 */       runTime = new Date(tem.getTime());
/*     */     }
/*     */     else
/*     */     {
/*     */       Date runTime;
/* 384 */       if (strTime.indexOf(":") > 0) {
/* 385 */         Time tem = (Time)DataType.transfer(strTime, "Time");
/*     */ 
/* 387 */         runTime = new Date(tem.getTime());
/*     */       }
/*     */       else {
/* 390 */         runTime = (Date)DataType.transfer(strTime, "Date");
/*     */       }
/*     */     }
/* 393 */     if (type.equalsIgnoreCase("R")) {
/* 394 */       runTime = new Date(TimeUtil.getSysTime().getTime() + runTime.getTime() - ((Date)DataType.transfer("1970-01-01", "Date")).getTime());
/*     */     }
/*     */ 
/* 397 */     return runTime;
/*     */   }
/*     */ 
/*     */   public void setDuration() throws Exception {
/* 401 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 402 */     IBOVmAlarmConfigValue[] alarm = alarmConfigSV.getAlarmConfig(getTaskTag(), getWorkflow().getDataBean().getAsString(S_TEMPLATE_TAG));
/* 403 */     if (alarm.length > 1) {
/* 404 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.setDuration_codeByModel") + getWorkflow().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.oneMoreResult"));
/*     */     }
/*     */ 
/* 407 */     boolean isDuration = false;
/* 408 */     if (!StringUtils.isEmptyString(this.taskTemplate.getDuration()))
/*     */     {
/* 410 */       String Duration = this.taskTemplate.getDuration();
/* 411 */       if (!this.taskTemplate instanceof WorkflowTemplate) {
/* 412 */         if (Duration.charAt(0) == ':') {
/* 413 */           Duration = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(Duration.substring(1)));
/*     */         }
/* 415 */         if ((!StringUtils.isEmptyString(Duration)) && 
/* 416 */           (Long.parseLong(Duration) > 0L)) {
/* 417 */           this.m_dc.set(S_DURATION, new Long(Duration));
/* 418 */           isDuration = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/* 424 */     else if (alarm.length == 1) {
/* 425 */       int duration = alarmConfigSV.calculateDuration(alarm[0].getDurationTimeMethod(), alarm[0].getTemplateVersionId(), alarm[0].getTemplateTag(), alarm[0].getTaskTag(), getWorkflow().getWorkflowObjectId(), getWorkflow().getWorkflowObjectTypeId());
/*     */ 
/* 428 */       if (duration > 0) {
/* 429 */         this.m_dc.set(S_DURATION, new Long(duration));
/* 430 */         isDuration = true;
/*     */       }
/*     */     }
/*     */ 
/* 434 */     if (isDuration != true)
/*     */       return;
/*     */     try {
/* 437 */       Timestamp date = null;
/* 438 */       if (alarm.length == 1) {
/* 439 */         date = alarmConfigSV.calculateAlarmTime(alarm[0].getAlarmTimeMethod(), alarm[0].getTemplateVersionId(), alarm[0].getTemplateTag(), alarm[0].getTaskTag(), getWorkflow().getWorkflowObjectId(), getWorkflow().getWorkflowObjectTypeId(), this.m_dc.getAsInt(S_DURATION), 0, alarm[0].getIsHoliday());
/*     */       }
/*     */       else
/*     */       {
/* 444 */         date = alarmConfigSV.calculateAlarmTime(null, getWorkflow().getTaskTemplateId(), getWorkflow().getTaskTag(), getTaskTag(), getWorkflow().getWorkflowObjectId(), getWorkflow().getWorkflowObjectTypeId(), this.m_dc.getAsInt(S_DURATION), 0, 0);
/*     */       }
/*     */ 
/* 448 */       if (date != null) {
/* 449 */         this.m_dc.set(S_WARNING_DATE, date);
/* 450 */         this.m_dc.set(S_WARNING_TIMES, new Long(0L));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 455 */       log.error("Failure alarm time calculation:" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskUserImpl
 * JD-Core Version:    0.5.4
 */