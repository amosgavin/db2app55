/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.engine.WorkflowExpress;
/*    */ import com.ai.comframe.vm.template.TaskShellTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskShellImpl extends TaskBaseImpl
/*    */   implements Task
/*    */ {
/* 12 */   private static transient Log log = LogFactory.getLog(TaskShellImpl.class);
/*    */   private transient Object[][] m_opList;
/*    */ 
/*    */   public TaskShellImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 17 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskShellImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 22 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 26 */     String condition = ((TaskShellTemplate)getTaskTemplate()).getCondition();
/*    */ 
/* 28 */     if ((condition != null) && (condition.length() > 0)) {
/* 29 */       if (this.m_opList == null) {
/* 30 */         String[] conds = condition.split(";");
/* 31 */         this.m_opList = new Object[conds.length][];
/* 32 */         for (int i = 0; i < conds.length; ++i) {
/* 33 */           this.m_opList[i] = this.workflow.getWorkflowExpress().getOpObjectList(conds[i]);
/*    */         }
/*    */       }
/* 36 */       if (this.m_opList != null) {
/* 37 */         for (int i = 0; i < this.m_opList.length; ++i) {
/* 38 */           if (this.m_opList[i] != null) {
/* 39 */             this.workflow.getWorkflowExpress().executeByCResult(this.m_opList[i]);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 44 */     updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete"));
/* 45 */     log.debug("Execute Shell：" + condition);
/* 46 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskShellImpl
 * JD-Core Version:    0.5.4
 */