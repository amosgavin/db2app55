/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*     */ import com.ai.comframe.vm.engine.TaskTimer;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTimerTemplate;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmDealTaskBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TaskTimerImpl extends TaskBaseImpl
/*     */   implements TaskTimer
/*     */ {
/*  35 */   private static transient Log log = LogFactory.getLog(TaskTimerImpl.class);
/*  36 */   protected static String S_DECISION_RESULT = "DECISION_RESULT";
/*  37 */   protected static String S_DISTRICT_ID = "DISTRICT_ID";
/*     */ 
/*     */   public TaskTimerImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*     */     throws Exception
/*     */   {
/*  43 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*     */   }
/*     */ 
/*     */   public TaskTimerImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*     */   {
/*  49 */     super(aWorkflow, aTaskTemplate, inBean);
/*     */   }
/*     */ 
/*     */   public Object executeInner(WorkflowContext context) throws Exception
/*     */   {
/*  54 */     TaskTimerTemplate task = (TaskTimerTemplate)getTaskTemplate();
/*  55 */     String type = task.getTimerType();
/*  56 */     String strTime = task.getRuntime();
/*     */ 
/*  58 */     if (strTime.startsWith(":"))
/*  59 */       strTime = getContextValue(this, context, strTime.substring(1)).toString();
/*     */     Date runTime;
/*     */     Date runTime;
/*  61 */     if ((strTime.indexOf(":") > 0) && (strTime.indexOf("-") > 0)) {
/*  62 */       Timestamp tem = (Timestamp)DataType.transfer(strTime, "DateTime");
/*     */ 
/*  64 */       runTime = new Date(tem.getTime());
/*     */     }
/*     */     else
/*     */     {
/*     */       Date runTime;
/*  66 */       if (strTime.indexOf(":") > 0) {
/*  67 */         Time tem = (Time)DataType.transfer(strTime, "Time");
/*     */ 
/*  69 */         runTime = new Date(tem.getTime());
/*     */       }
/*     */       else {
/*  72 */         runTime = (Date)DataType.transfer(strTime, "Date");
/*     */       }
/*     */     }
/*  75 */     if (type.equalsIgnoreCase("R")) {
/*  76 */       runTime = new Date(TimeUtil.getSysTime().getTime() + runTime.getTime() - ((Date)DataType.transfer("1970-01-01", "Date")).getTime());
/*     */     }
/*     */ 
/*  79 */     this.m_dc.set(S_DECISION_RESULT, DataType.transferToString(runTime, "DateTime"));
/*  80 */     if (runTime.getTime() < TimeUtil.getSysTime().getTime()) {
/*  81 */       updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.executeInner_timerReaches"));
/*     */     } else {
/*  83 */       insertTimerRecord(getTaskId(), getWorkflow().getWorkflowId(), getWorkflow().getQueueId(), getWorkflow().getDistrictId(), "TIMER", runTime);
/*     */ 
/*  86 */       updateState(5, "");
/*  87 */       ((Workflow)getWorkflow()).addUserTaskCount();
/*     */     }
/*  89 */     return new Boolean(true);
/*     */   }
/*     */ 
/*     */   public static void finish(String taskId, String staffId)
/*     */     throws Exception
/*     */   {
/* 100 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 101 */     IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(taskId, new int[] { 5 });
/* 102 */     if ((taskBean == null) || (taskBean.isNew())) {
/* 103 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_taskTimer") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_finishedOrStateError") + 5 + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_1"));
/*     */     }
/*     */ 
/* 107 */     taskBean.setFinishStaffId(staffId);
/* 108 */     taskBean.setState(3);
/* 109 */     taskDAO.saveVmtaskInstacne(taskBean);
/*     */ 
/* 113 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 114 */     IBOVmWFValue wfBean = workflowDAO.getVmWorkflowBeanbyId(taskBean.getWorkflowId());
/* 115 */     wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 116 */     workflowDAO.saveVmWorkflowInstacne(wfBean);
/* 117 */     deleteTimerRecord(taskId);
/*     */   }
/*     */ 
/*     */   public static void deleteTimerRecord(String taskId) throws Exception {
/* 121 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 122 */     IBOVmDealTaskValue[] dealTaskbeans = taskDAO.getVmDealTask(taskId);
/* 123 */     if ((dealTaskbeans == null) || (dealTaskbeans.length == 0))
/* 124 */       return;
/* 125 */     for (int i = 0; i < dealTaskbeans.length; ++i) {
/* 126 */       dealTaskbeans[i].delete();
/* 127 */       taskDAO.saveVmDealTaskInstance(dealTaskbeans[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void updateTimerRecordState(String taskId, int state, String reason) throws Exception
/*     */   {
/* 133 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 134 */     IBOVmDealTaskValue[] dealTaskbeans = taskDAO.getVmDealTask(taskId);
/* 135 */     if ((dealTaskbeans == null) || (dealTaskbeans.length == 0))
/* 136 */       return;
/* 137 */     for (int i = 0; i < dealTaskbeans.length; ++i) {
/* 138 */       dealTaskbeans[i].setState(state);
/* 139 */       dealTaskbeans[i].setErrorMessage(reason);
/* 140 */       taskDAO.saveVmDealTaskInstance(dealTaskbeans[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void updateTimerRecordStateByWorkflowId(String workflowId, int state, String reason) throws Exception
/*     */   {
/* 146 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 147 */     IBOVmDealTaskValue[] vmDealTaskBeans = taskDAO.getVmDealTaskbeanByWorkflowId(workflowId);
/* 148 */     for (int i = 0; i < vmDealTaskBeans.length; ++i) {
/* 149 */       vmDealTaskBeans[i].setState(state);
/* 150 */       vmDealTaskBeans[i].setErrorMessage(reason);
/* 151 */       taskDAO.saveVmDealTaskInstance(vmDealTaskBeans[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void insertTimerRecord(String taskId, String workflowId, String queueId, String districtId, String dealType, Date runTime)
/*     */     throws Exception
/*     */   {
/* 158 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 159 */     IBOVmDealTaskValue vmDealTaskBean = new BOVmDealTaskBean();
/* 160 */     vmDealTaskBean.setWorkflowId(workflowId);
/* 161 */     vmDealTaskBean.setTaskId(taskId);
/* 162 */     vmDealTaskBean.setQueueId(queueId);
/* 163 */     vmDealTaskBean.setRegionId(districtId);
/* 164 */     vmDealTaskBean.setDealType(dealType);
/* 165 */     if (runTime == null)
/* 166 */       vmDealTaskBean.setRuntime(null);
/*     */     else {
/* 168 */       vmDealTaskBean.setRuntime(new Timestamp(runTime.getTime()));
/*     */     }
/*     */ 
/* 171 */     if (PropertiesUtil.isDev()) {
/* 172 */       String devName = PropertiesUtil.getDevId();
/* 173 */       if (StringUtils.isEmpty(devName)) {
/* 174 */         String[] param = new String[1];
/* 175 */         param[0] = "comframe.dev.name";
/* 176 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", param));
/*     */       }
/* 178 */       vmDealTaskBean.setDevId(devName);
/*     */     }
/* 180 */     vmDealTaskBean.setState(2);
/* 181 */     vmDealTaskBean.setCreateDate(TimeUtil.getSysTime());
/* 182 */     taskDAO.saveVmDealTaskInstance(vmDealTaskBean);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskTimerImpl
 * JD-Core Version:    0.5.4
 */