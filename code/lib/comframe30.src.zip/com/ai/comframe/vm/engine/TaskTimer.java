package com.ai.comframe.vm.engine;

public abstract interface TaskTimer extends Task
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskTimer
 * JD-Core Version:    0.5.4
 */