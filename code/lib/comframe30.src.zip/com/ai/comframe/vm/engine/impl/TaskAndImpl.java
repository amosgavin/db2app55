/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.VMDataType;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.TaskAnd;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.sql.Date;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskAndImpl extends TaskBaseImpl
/*    */   implements TaskAnd
/*    */ {
/* 17 */   private static transient Log log = LogFactory.getLog(TaskAndImpl.class);
/* 18 */   protected static String S_FINISH_TASK = "DECISION_RESULT";
/*    */ 
/* 22 */   protected List m_finishTask = new ArrayList();
/*    */ 
/*    */   public TaskAndImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate) throws Exception
/*    */   {
/* 26 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskAndImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 31 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */ 
/* 33 */     String[] l = StringUtils.split(VMDataType.getAsString(inBean.get(S_FINISH_TASK)), ',');
/* 34 */     for (int i = 0; (l != null) && (i < l.length); ++i)
/* 35 */       this.m_finishTask.add(new Long(l[i]));
/*    */   }
/*    */ 
/*    */   public DataContainerInterface getDataBean()
/*    */     throws Exception
/*    */   {
/* 41 */     if (this.m_finishTask.size() > 0) {
/* 42 */       String str = "";
/* 43 */       for (int i = 0; i < this.m_finishTask.size(); ++i) {
/* 44 */         if (i > 0)
/* 45 */           str = str + ",";
/* 46 */         str = str + this.m_finishTask.get(i).toString();
/*    */       }
/* 48 */       this.m_dc.set(S_FINISH_TASK, str);
/*    */     }
/* 50 */     return this.m_dc;
/*    */   }
/*    */ 
/*    */   public void addFinishTaskTemplateId(long aTaskTemplateId) {
/* 54 */     this.m_finishTask.add(new Long(aTaskTemplateId));
/* 55 */     updateState(2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAndImpl.addFinishTaskTemplateId_taskArrive"));
/*    */   }
/*    */ 
/*    */   protected Object executeInner(WorkflowContext context) throws Exception
/*    */   {
/* 60 */     if (log.isDebugEnabled()) {
/* 61 */       log.debug("Excute " + getTaskTemplate().getTaskType() + " Task nodes:" + this.taskTemplate.getDescription());
/*    */ 
/* 63 */       for (int i = 0; i < this.m_finishTask.size(); ++i) {
/* 64 */         log.debug("m_finishTask.get(" + i + "):" + this.m_finishTask.get(i));
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 70 */     JoinTemplate[] joinTemplates = getWorkflow().getWorkflowTemplate().getJoinsByTaskB(getTaskTemplate());
/*    */ 
/* 72 */     for (int i = 0; i < joinTemplates.length; ++i) {
/* 73 */       if (log.isDebugEnabled())
/* 74 */         log.debug("joinTemplates[" + i + "]getTaskTemplateAId:" + joinTemplates[i].getTaskTemplateAId() + ";getTaskTemplateBId" + joinTemplates[i].getTaskTemplateBId());
/* 75 */       if (this.m_finishTask.contains(new Long(joinTemplates[i].getTaskTemplateAId())))
/*    */         continue;
/* 77 */       updateState(7, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAndImpl.executeInner_waitUnendTask"));
/* 78 */       return Boolean.TRUE;
/*    */     }
/*    */ 
/* 81 */     updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAndImpl.executeInner_allTaskComplete"));
/* 82 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskAndImpl
 * JD-Core Version:    0.5.4
 */