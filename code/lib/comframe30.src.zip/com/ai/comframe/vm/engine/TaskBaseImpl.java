/*     */ package com.ai.comframe.vm.engine;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.ServiceUtil;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.common.VMException;
/*     */ import com.ai.comframe.vm.engine.impl.WorkflowImpl;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.ITaskHandle;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TaskBaseImpl
/*     */ {
/*  33 */   private static transient Log log = LogFactory.getLog(TaskBaseImpl.class);
/*  34 */   public static String S_TASK_ID = "TASK_ID";
/*  35 */   public static String S_QUEUE_ID = "QUEUE_ID";
/*  36 */   public static String S_TASK_TAG = "TASK_TAG";
/*  37 */   public static String S_TEMPLATE_TAG = "TEMPLATE_TAG";
/*  38 */   public static String S_TASK_TYPE = "TASK_TYPE";
/*  39 */   public static String S_WORKFLOW_TYPE = "WORKFLOW_TYPE";
/*  40 */   public static String S_TASK_BASE_TYPE = "TASK_BASE_TYPE";
/*  41 */   public static String S_LABEL = "LABEL";
/*  42 */   public static String S_WORKFLOW_ID = "WORKFLOW_ID";
/*  43 */   public static String S_TASK_TEMPLATE_ID = "TASK_TEMPLATE_ID";
/*  44 */   public static String S_TEMPLATE_VERSION_ID = "TEMPLATE_VERSION_ID";
/*  45 */   public static String S_STATE = "STATE";
/*  46 */   public static String S_REASON = "ERROR_MESSAGE";
/*  47 */   public static String S_DESCRIPTION = "DESCRIPTION";
/*  48 */   public static String S_STATE_DATE = "STATE_DATE";
/*  49 */   public static String S_CREATE_DATE = "CREATE_DATE";
/*  50 */   public static String S_FINISH_DATE = "FINISH_DATE";
/*     */   public static final String S_ENGINE_WORKFLOW_ID = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_ENGINE_TASK_ID = "ENGINE_TASK_ID";
/*  53 */   public static String S_DURATION = "DURATION";
/*  54 */   public static String S_IS_CURRENT_TASK = "IS_CURRENT_TASK";
/*  55 */   public static String S_LAST_TASK_ID = "LAST_TASK_ID";
/*  56 */   public static String S_WARNING_DATE = "WARNING_DATE";
/*  57 */   public static String S_WARNING_TIMES = "WARNING_TIMES";
/*     */ 
/*  59 */   public static String S_DEST_TYPE = "DEST_TYPE";
/*  60 */   public static String S_DEST_TASK_TEMPLATE_ID = "DEST_TASK_TEMPLATE_ID";
/*     */   protected DataContainerInterface m_dc;
/*     */   protected FlowBase workflow;
/*     */   protected TaskTemplate taskTemplate;
/*     */ 
/*     */   public TaskBaseImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplate, int aState, Date aStateDate, Date aCreateDate)
/*     */     throws Exception
/*     */   {
/*  68 */     this.workflow = aWorkflow;
/*  69 */     this.taskTemplate = aTaskTemplate;
/*  70 */     if (this.taskTemplate instanceof WorkflowTemplate)
/*  71 */       this.m_dc = new BOVmWFBean();
/*     */     else
/*  73 */       this.m_dc = new BOVmTaskBean();
/*  74 */     if (this.taskTemplate instanceof WorkflowTemplate) {
/*  75 */       this.m_dc.set(S_WORKFLOW_ID, aTaskId);
/*  76 */       this.m_dc.set(S_TEMPLATE_TAG, this.taskTemplate.getTaskTag());
/*  77 */       this.m_dc.set(S_WORKFLOW_TYPE, this.taskTemplate.getTaskType());
/*  78 */       this.m_dc.set(S_TEMPLATE_VERSION_ID, new Long(this.taskTemplate.getTaskTemplateId()));
/*     */     } else {
/*  80 */       this.m_dc.set(S_TASK_ID, aTaskId);
/*  81 */       this.m_dc.set(S_QUEUE_ID, IDAssembleUtil.unwrapPrefix(aTaskId));
/*  82 */       this.m_dc.set(S_TASK_TAG, this.taskTemplate.getTaskTag());
/*  83 */       this.m_dc.set(S_TASK_TYPE, this.taskTemplate.getTaskType());
/*  84 */       this.m_dc.set(S_TASK_TEMPLATE_ID, new Long(this.taskTemplate.getTaskTemplateId()));
/*     */     }
/*     */ 
/*  87 */     if (!this.taskTemplate instanceof WorkflowTemplate) {
/*  88 */       this.m_dc.set(S_TASK_BASE_TYPE, TaskConfig.getInstance().getBasalType(this.taskTemplate.getTaskType()));
/*     */     }
/*  90 */     this.m_dc.set(S_LABEL, this.taskTemplate.getLabel());
/*  91 */     this.m_dc.set(S_DESCRIPTION, this.taskTemplate.getDescription());
/*  92 */     if (!StringUtils.isEmptyString(this.taskTemplate.getDuration())) {
/*  93 */       String Duration = this.taskTemplate.getDuration();
/*  94 */       if (!this.taskTemplate instanceof WorkflowTemplate) {
/*  95 */         if (Duration.charAt(0) == ':')
/*     */         {
/*  97 */           Duration = VMDataType.getAsString(getWorkflow().getWorkflowExpress().execute(Duration.substring(1)));
/*     */         }
/*  99 */         if (!StringUtils.isEmptyString(Duration)) {
/* 100 */           this.m_dc.set(S_DURATION, new Long(Duration));
/*     */         }
/*     */       }
/*     */     }
/* 104 */     if (this.workflow != null) {
/* 105 */       if (this instanceof WorkflowImpl)
/* 106 */         this.m_dc.set("PARENT_TASK_ID", this.workflow.getWorkflowId());
/*     */       else {
/* 108 */         this.m_dc.set(S_WORKFLOW_ID, this.workflow.getWorkflowId());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 115 */     this.m_dc.set(S_STATE, new Integer(aState));
/* 116 */     this.m_dc.set(S_STATE_DATE, aStateDate);
/* 117 */     this.m_dc.set(S_CREATE_DATE, aCreateDate);
/*     */   }
/*     */ 
/*     */   public TaskBaseImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*     */   {
/* 122 */     this.workflow = aWorkflow;
/* 123 */     this.taskTemplate = aTaskTemplate;
/* 124 */     this.m_dc = inBean;
/*     */   }
/*     */   protected Object executeInner(WorkflowContext context) throws Exception {
/* 127 */     throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.TaskBaseImpl.executeInner_notFindMethod"));
/*     */   }
/*     */ 
/*     */   public Object execute(WorkflowContext context) throws Exception
/*     */   {
/*     */     try {
/* 133 */       monitor(PropertiesUtil.getSystemUserId(), null, 1);
/* 134 */       return executeInner(context);
/*     */     }
/*     */     catch (Throwable t) {
/* 137 */       monitor(PropertiesUtil.getSystemUserId(), t, 5);
/* 138 */       throw new Exception(t);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataContainerInterface getDataBean() throws Exception
/*     */   {
/* 144 */     return this.m_dc;
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 148 */     return this.taskTemplate.getTaskTemplateId();
/*     */   }
/*     */   public TaskTemplate getTaskTemplate() {
/* 151 */     return this.taskTemplate;
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 155 */     return this.m_dc.getAsString(S_TASK_ID);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 159 */     return this.m_dc.getAsString(S_WORKFLOW_ID);
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 163 */     return this.m_dc.getAsString(S_TASK_TAG);
/*     */   }
/*     */ 
/*     */   public String getLastTaskId() {
/* 167 */     return this.m_dc.getAsString(S_LAST_TASK_ID);
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 171 */     return this.m_dc.getAsString(S_TASK_TYPE);
/*     */   }
/*     */ 
/*     */   public String getTaskBaseType() {
/* 175 */     return this.m_dc.getAsString(S_TASK_BASE_TYPE);
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 179 */     return this.m_dc.getAsString("ENGINE_WORKFLOW_ID");
/*     */   }
/*     */   public String getEngineTaskId() {
/* 182 */     return this.m_dc.getAsString("ENGINE_TASK_ID");
/*     */   }
/*     */ 
/*     */   public String getDestType() {
/* 186 */     return this.m_dc.getAsString(S_DEST_TYPE);
/*     */   }
/*     */   public long getDestTaskTemplateId() {
/* 189 */     return this.m_dc.getAsLong(S_DEST_TASK_TEMPLATE_ID);
/*     */   }
/*     */ 
/*     */   public FlowBase getWorkflow() {
/* 193 */     return this.workflow;
/*     */   }
/*     */ 
/*     */   public int getState() {
/* 197 */     return this.m_dc.getAsInt(S_STATE);
/*     */   }
/*     */   public Date getStateDate() {
/* 200 */     return this.m_dc.getAsDate(S_STATE_DATE);
/*     */   }
/*     */   public String getLabel() {
/* 203 */     return this.m_dc.getAsString(S_LABEL);
/*     */   }
/*     */ 
/*     */   public String getReason() {
/* 207 */     return this.m_dc.getAsString(S_REASON);
/*     */   }
/*     */   public void setReason(String reason) {
/* 210 */     this.m_dc.set(S_REASON, reason);
/*     */   }
/*     */   public void setLastTaskId(String lastTaskId) {
/* 213 */     this.m_dc.set(S_LAST_TASK_ID, lastTaskId);
/*     */   }
/*     */   public Date getCreateDate() {
/* 216 */     return this.m_dc.getAsDate(S_CREATE_DATE);
/*     */   }
/*     */ 
/*     */   public String getDuration() {
/* 220 */     return getTaskTemplate().getDuration();
/*     */   }
/*     */ 
/*     */   public Date getDuerationDate()
/*     */   {
/* 226 */     return new Date(getCreateDate().getTime() + Long.parseLong(getDuration()) * 60L * 1000L);
/*     */   }
/*     */ 
/*     */   public boolean isOverDuration() {
/*     */     try {
/* 231 */       Date curr_date = new Date(TimeUtil.getSysTime().getTime());
/* 232 */       return curr_date.after(getDuerationDate());
/*     */     }
/*     */     catch (Exception ex) {
/* 235 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isOverDuration(Date date) {
/* 239 */     return date.after(getDuerationDate());
/*     */   }
/*     */ 
/*     */   public void updateState(int aState, String aReason) {
/*     */     try {
/* 244 */       this.m_dc.set(S_STATE, new Integer(aState));
/* 245 */       this.m_dc.set(S_DESCRIPTION, aReason);
/* 246 */       this.m_dc.set(S_STATE_DATE, TimeUtil.getSysTime());
/* 247 */       if ((aState == 3) || (aState == 11))
/* 248 */         this.m_dc.set(S_FINISH_DATE, TimeUtil.getSysTime());
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 252 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCurrentTask() throws Exception {
/* 256 */     return this.m_dc.getAsChar(S_IS_CURRENT_TASK) != 'N';
/*     */   }
/*     */   public void setIsCurrentTask(boolean value) throws Exception {
/* 259 */     if (value == true)
/* 260 */       this.m_dc.set(S_IS_CURRENT_TASK, new Character('Y'));
/*     */     else
/* 262 */       this.m_dc.set(S_IS_CURRENT_TASK, new Character('N'));
/*     */   }
/*     */ 
/*     */   public static Object getContextValue(Task task, WorkflowContext context, String name) throws Exception {
/* 266 */     if (name.equalsIgnoreCase("$WORKFLOW_ID")) {
/* 267 */       if (task instanceof FlowBase) {
/* 268 */         return ((FlowBase)task).getWorkflowId();
/*     */       }
/* 270 */       return task.getWorkflow().getWorkflowId();
/*     */     }
/*     */ 
/* 273 */     if (name.equalsIgnoreCase("$TASK_ID")) {
/* 274 */       return task.getTaskId();
/*     */     }
/* 276 */     if (name.equalsIgnoreCase("$WORKFLOW_TAG")) {
/* 277 */       if (task instanceof FlowBase) {
/* 278 */         return ((FlowBase)task).getTemplateTag();
/*     */       }
/* 280 */       return task.getWorkflow().getTemplateTag();
/*     */     }
/*     */ 
/* 283 */     if (name.equalsIgnoreCase("$TASK_TAG")) {
/* 284 */       return task.getTaskTag();
/*     */     }
/* 286 */     if (name.equalsIgnoreCase("$QUEUE_ID")) {
/* 287 */       if (task instanceof FlowBase) {
/* 288 */         return ((FlowBase)task).getQueueId();
/*     */       }
/* 290 */       return task.getWorkflow().getQueueId();
/*     */     }
/*     */ 
/* 293 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_ID")) {
/* 294 */       if (task instanceof FlowBase) {
/* 295 */         return ((FlowBase)task).getWorkflowObjectId();
/*     */       }
/* 297 */       return task.getWorkflow().getWorkflowObjectId();
/*     */     }
/*     */ 
/* 300 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_TYPE_ID")) {
/* 301 */       if (task instanceof FlowBase) {
/* 302 */         return ((FlowBase)task).getWorkflowObjectTypeId();
/*     */       }
/* 304 */       return task.getWorkflow().getWorkflowObjectTypeId();
/*     */     }
/*     */ 
/* 307 */     if (name.equalsIgnoreCase("$CONTEXT_MAP")) {
/* 308 */       return context.getParameters();
/*     */     }
/*     */ 
/* 311 */     return context.get(name);
/*     */   }
/*     */ 
/*     */   public static Object executeDealInner(Task task, WorkflowContext context, TaskDealBean dealBean) throws Exception {
/* 315 */     if ((dealBean == null) || (StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/* 316 */       return Boolean.TRUE;
/*     */     }
/*     */ 
/* 319 */     ParameterDefine returnDefine = dealBean.getReturnParameterDefine();
/* 320 */     Object returnObj = Boolean.TRUE;
/*     */ 
/* 322 */     if ("service".equalsIgnoreCase(dealBean.getRunType()) == true) {
/* 323 */       returnObj = invokeService(task, dealBean, context);
/*     */     }
/*     */     else {
/* 326 */       returnObj = invokePojo(task, dealBean, context);
/*     */     }
/*     */ 
/* 329 */     if ((returnDefine != null) && (!StringUtils.isEmptyString(returnDefine.contextVarName))) {
/* 330 */       if (!returnDefine.contextVarName.equalsIgnoreCase("$CONTEXT_MAP")) {
/* 331 */         context.set(returnDefine.contextVarName, returnObj);
/*     */       }
/*     */       else
/*     */       {
/*     */         WorkflowTemplate wt;
/*     */         String workflowCode;
/*     */         Iterator it;
/* 334 */         if (returnObj instanceof Map) {
/* 335 */           wt = null;
/* 336 */           workflowCode = null;
/* 337 */           if (task instanceof FlowBase) {
/* 338 */             wt = ((FlowBase)task).getWorkflowTemplate();
/* 339 */             workflowCode = ((FlowBase)task).getTaskTag();
/*     */           }
/*     */           else {
/* 342 */             wt = task.getWorkflow().getWorkflowTemplate();
/* 343 */             workflowCode = task.getWorkflow().getTaskTag();
/*     */           }
/* 345 */           Map aVars = (Map)returnObj;
/* 346 */           for (it = aVars.entrySet().iterator(); it.hasNext(); ) {
/* 347 */             Map.Entry e = (Map.Entry)it.next();
/* 348 */             String param = e.getKey().toString();
/* 349 */             ParameterDefine p = wt.getVars(param);
/* 350 */             if (p != null) {
/* 351 */               context.set(e.getKey().toString(), e.getValue());
/*     */             }
/*     */             else
/* 354 */               log.warn("Process template" + workflowCode + "Not defined in the variables:" + param);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 359 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.TaskBaseImpl.executeDealInner_backNotMap") + "$CONTEXT_MAP");
/*     */         }
/*     */       }
/*     */     }
/* 363 */     return returnObj;
/*     */   }
/*     */   public static boolean isNumberClass(Class aClass) {
/* 366 */     if (aClass == null) {
/* 367 */       return false;
/*     */     }
/*     */ 
/* 376 */     return (aClass.equals(Short.TYPE)) || (aClass.equals(Integer.TYPE)) || (aClass.equals(Long.TYPE)) || (aClass.equals(Float.TYPE)) || (aClass.equals(Double.TYPE)) || (aClass.equals(Byte.TYPE));
/*     */   }
/*     */ 
/*     */   public static Object invokePojo(Task task, TaskDealBean dealBean, WorkflowContext context)
/*     */     throws Exception
/*     */   {
/* 383 */     ParameterDefine[] parameters = dealBean.getFunctionParameterDefine();
/*     */ 
/* 386 */     String[] pNames = new String[parameters.length];
/*     */ 
/* 388 */     Class[] pClasses = new Class[parameters.length];
/*     */ 
/* 390 */     Object[] pObjects = new Object[parameters.length];
/* 391 */     for (int i = 0; i < parameters.length; ++i)
/*     */     {
/* 393 */       pNames[i] = parameters[i].dataType;
/* 394 */       pClasses[i] = parameters[i].getDataTypeClass();
/*     */ 
/* 397 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 398 */         pObjects[i] = VMDataType.transfer(getContextValue(task, context, parameters[i].contextVarName), parameters[i].getDataTypeClass());
/*     */       }
/*     */       else {
/* 401 */         pObjects[i] = VMDataType.transfer(parameters[i].defaultValue, parameters[i].getDataTypeClass());
/*     */       }
/*     */ 
/* 404 */       if ((pObjects[i] == null) && (isNumberClass(parameters[i].getDataTypeClass()))) {
/* 405 */         pObjects[i] = new Integer(0);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 410 */     Object returnObj = null;
/* 411 */     CenterInfo ci = null;
/*     */     try {
/* 413 */       if (CenterFactory.isSetCenterInfo()) {
/* 414 */         ci = CenterFactory.getCenterInfo();
/*     */       }
/* 416 */       Class runClass = dealBean.getRunClass();
/* 417 */       Method runFunction = runClass.getMethod(dealBean.getRunFunctionName(), pClasses);
/* 418 */       returnObj = runFunction.invoke(runClass.newInstance(), pObjects);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 425 */       if (ci != null)
/*     */       {
/* 427 */         CenterFactory.setDirectCenterInfo(ci);
/*     */ 
/* 429 */         if (log.isDebugEnabled())
/* 430 */           log.debug("current center is:" + CenterFactory.getCenterInfo());
/*     */       } else {
/* 432 */         CenterFactory.setCenterInfoEmpty();
/*     */       }
/*     */     }
/* 434 */     return returnObj;
/*     */   }
/*     */ 
/*     */   public static Object invokeService(Task task, TaskDealBean dealBean, WorkflowContext context) throws Exception {
/* 438 */     Object objInstance = ServiceUtil.getService(dealBean.getServiceName());
/*     */ 
/* 440 */     ParameterDefine[] parameters = dealBean.getFunctionParameterDefine();
/*     */ 
/* 443 */     String[] pNames = new String[parameters.length];
/*     */ 
/* 445 */     Class[] pClasses = new Class[parameters.length];
/*     */ 
/* 447 */     Object[] pObjects = new Object[parameters.length];
/* 448 */     for (int i = 0; i < parameters.length; ++i)
/*     */     {
/* 450 */       pNames[i] = parameters[i].dataType;
/* 451 */       pClasses[i] = parameters[i].getDataTypeClass();
/*     */ 
/* 454 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 455 */         pObjects[i] = VMDataType.transfer(getContextValue(task, context, parameters[i].contextVarName), parameters[i].getDataTypeClass());
/*     */       }
/*     */       else {
/* 458 */         pObjects[i] = VMDataType.transfer(parameters[i].defaultValue, parameters[i].getDataTypeClass());
/*     */       }
/*     */ 
/* 461 */       if ((pObjects[i] == null) && (isNumberClass(parameters[i].getDataTypeClass()))) {
/* 462 */         pObjects[i] = new Integer(0);
/*     */       }
/*     */     }
/*     */ 
/* 466 */     Object returnObj = null;
/* 467 */     CenterInfo ci = null;
/*     */     try {
/* 469 */       if (CenterFactory.isSetCenterInfo()) {
/* 470 */         ci = CenterFactory.getCenterInfo();
/*     */       }
/* 472 */       if (log.isDebugEnabled()) {
/* 473 */         log.debug("before invoke service the center is:" + ci);
/*     */       }
/* 475 */       Class runClass = objInstance.getClass();
/* 476 */       Method runFunction = runClass.getMethod(dealBean.getRunFunctionName(), pClasses);
/* 477 */       returnObj = runFunction.invoke(objInstance, pObjects);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 484 */       if (ci != null) {
/* 485 */         CenterFactory.setDirectCenterInfo(ci);
/*     */ 
/* 488 */         if (log.isDebugEnabled())
/* 489 */           log.debug("current center is:" + CenterFactory.getCenterInfo());
/*     */       } else {
/* 491 */         CenterFactory.setCenterInfoEmpty();
/*     */       }
/*     */     }
/*     */ 
/* 495 */     return returnObj;
/*     */   }
/*     */ 
/*     */   public void monitor(String staffId, Throwable ex, int trigger) {
/* 499 */     CenterInfo ci = null;
/*     */     try
/*     */     {
/* 502 */       if (CenterFactory.isSetCenterInfo()) {
/* 503 */         ci = CenterFactory.getCenterInfo();
/*     */       }
/* 505 */       String monitorType = this.taskTemplate.getMonitorType();
/* 506 */       String monitorService = this.taskTemplate.getMonitorService();
/* 507 */       if ((!StringUtils.isEmptyString(monitorType)) && (!StringUtils.isEmptyString(monitorService)))
/*     */       {
/* 510 */         Object monitorObj = null;
/* 511 */         if (monitorType.equalsIgnoreCase("pojo")) {
/* 512 */           monitorObj = VMDataType.getJavaClass(monitorService).newInstance();
/*     */         }
/*     */         else {
/* 515 */           monitorObj = ServiceUtil.getService(monitorService);
/*     */         }
/*     */ 
/* 518 */         long currentTime = TimeUtil.getSysTime().getTime();
/*     */ 
/* 520 */         if (trigger == 1) {
/* 521 */           ITaskHandle handle = (ITaskHandle)monitorObj;
/* 522 */           handle.onCreateInstance(getTaskId(), getTaskType(), getTaskTag(), getLabel(), this.workflow.getWorkflowId(), this.workflow.getTemplateTag(), this.workflow.getWorkflowContext(), staffId, getCreateDate().getTime());
/*     */         }
/* 525 */         else if (trigger == 2) {
/* 526 */           ITaskHandle handle = (ITaskHandle)monitorObj;
/* 527 */           handle.onAssignUserTask(getTaskId(), getTaskType(), getTaskTag(), getLabel(), this.workflow.getWorkflowId(), this.workflow.getTemplateTag(), this.workflow.getWorkflowContext(), staffId, getCreateDate().getTime(), currentTime);
/*     */         }
/* 530 */         else if (trigger == 3) {
/* 531 */           ITaskHandle handle = (ITaskHandle)monitorObj;
/* 532 */           handle.onPrintTask(getTaskId(), getTaskType(), getTaskTag(), getLabel(), this.workflow.getWorkflowId(), this.workflow.getTemplateTag(), this.workflow.getWorkflowContext(), staffId, getCreateDate().getTime(), currentTime);
/*     */         }
/* 535 */         else if (trigger == 4) {
/* 536 */           ITaskHandle handle = (ITaskHandle)monitorObj;
/* 537 */           handle.onFinishInstance(getTaskId(), getTaskType(), getTaskTag(), getLabel(), this.workflow.getWorkflowId(), this.workflow.getTemplateTag(), this.workflow.getWorkflowContext(), staffId, getCreateDate().getTime(), currentTime);
/*     */         }
/* 540 */         else if (trigger == 5) {
/* 541 */           ITaskHandle handle = (ITaskHandle)monitorObj;
/* 542 */           handle.onInstanceException(getTaskId(), getTaskType(), getTaskTag(), getLabel(), this.workflow.getWorkflowId(), this.workflow.getTemplateTag(), this.workflow.getWorkflowContext(), staffId, ex, getCreateDate().getTime(), currentTime);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 548 */       log.info("Abnormal flow monitoring：" + t.getMessage(), t);
/*     */     } finally {
/* 550 */       if (ci != null)
/* 551 */         CenterFactory.setDirectCenterInfo(ci);
/*     */       else
/* 553 */         CenterFactory.setCenterInfoEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void terminate(String staffId, String reason) throws Exception {
/* 558 */     updateState(4, reason);
/* 559 */     this.m_dc.set("FINISH_STAFF_ID", staffId);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskBaseImpl
 * JD-Core Version:    0.5.4
 */