/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import com.ai.comframe.vm.common.ServiceUtil;
/*    */ import com.ai.comframe.vm.common.VMDataType;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskServiceTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.lang.reflect.Method;
/*    */ import java.sql.Date;
/*    */ 
/*    */ public class TaskServiceImpl extends TaskBaseImpl
/*    */   implements Task
/*    */ {
/*    */   public TaskServiceImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 26 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskServiceImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 31 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 35 */     TaskServiceTemplate task = (TaskServiceTemplate)getTaskTemplate();
/*    */ 
/* 37 */     Object objInstance = ServiceUtil.getService(task.getServiceName());
/*    */ 
/* 39 */     ParameterDefine[] parameters = task.getFunctionParameterDefine();
/*    */ 
/* 42 */     String[] pNames = new String[parameters.length];
/*    */ 
/* 44 */     Class[] pClasses = new Class[parameters.length];
/*    */ 
/* 46 */     Object[] pObjects = new Object[parameters.length];
/* 47 */     for (int i = 0; i < parameters.length; ++i)
/*    */     {
/* 49 */       pNames[i] = parameters[i].dataType;
/* 50 */       pClasses[i] = parameters[i].getDataTypeClass();
/*    */ 
/* 53 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 54 */         pObjects[i] = VMDataType.transfer(getContextValue(this, context, parameters[i].contextVarName), parameters[i].getDataTypeClass());
/*    */       }
/*    */       else {
/* 57 */         pObjects[i] = VMDataType.transfer(parameters[i].defaultValue, parameters[i].getDataTypeClass());
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 62 */     ParameterDefine returnDefine = task.getReturnParameterDefine();
/* 63 */     Object returnObj = null;
/*    */ 
/* 65 */     Class runClass = objInstance.getClass();
/* 66 */     Method runFunction = runClass.getMethod(task.getFunctionName(), pClasses);
/* 67 */     returnObj = runFunction.invoke(objInstance, pObjects);
/*    */ 
/* 70 */     if ((returnDefine != null) && (!StringUtils.isEmptyString(returnDefine.contextVarName))) {
/* 71 */       context.set(returnDefine.contextVarName, returnObj);
/*    */     }
/*    */ 
/* 75 */     updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete"));
/* 76 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskServiceImpl
 * JD-Core Version:    0.5.4
 */