/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.VMDataType;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.FlowFactory;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.TaskOr;
/*    */ import com.ai.comframe.vm.engine.Workflow;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*    */ import java.sql.Date;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskOrImpl extends TaskBaseImpl
/*    */   implements TaskOr
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(TaskOrImpl.class);
/* 20 */   protected static String S_FINISH_TASK = "DECISION_RESULT";
/*    */ 
/* 24 */   private List m_finishTask = new ArrayList();
/*    */ 
/*    */   public TaskOrImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate) throws Exception
/*    */   {
/* 28 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskOrImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 34 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */ 
/* 36 */     String[] l = StringUtils.split(VMDataType.getAsString(inBean.get(S_FINISH_TASK)), ',');
/* 37 */     for (int i = 0; (l != null) && (i < l.length); ++i)
/* 38 */       this.m_finishTask.add(l[i]);
/*    */   }
/*    */ 
/*    */   public DataContainerInterface getDataBean()
/*    */     throws Exception
/*    */   {
/* 44 */     if (this.m_finishTask.size() > 0) {
/* 45 */       String str = "";
/* 46 */       for (int i = 0; i < this.m_finishTask.size(); ++i) {
/* 47 */         if (i > 0)
/* 48 */           str = str + ",";
/* 49 */         str = str + this.m_finishTask.get(i).toString();
/*    */       }
/* 51 */       this.m_dc.set(S_FINISH_TASK, str);
/*    */     }
/* 53 */     return this.m_dc;
/*    */   }
/*    */ 
/*    */   public void addFinishTaskTemplateId(long aTaskTemplateId)
/*    */   {
/* 58 */     this.m_finishTask.add(new Long(aTaskTemplateId));
/* 59 */     updateState(2, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAndImpl.addFinishTaskTemplateId_taskArrive"));
/*    */   }
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 62 */     log.debug("Excute " + getTaskTemplate().getTaskType() + "Task nodes:" + this.taskTemplate.getDescription());
/*    */ 
/* 64 */     if (this.m_finishTask.size() > 0)
/*    */     {
/* 66 */       Task[] tasks = this.workflow.getCurrentTasks();
/* 67 */       for (int i = 0; i < tasks.length; ++i) {
/* 68 */         if ((tasks[i] == this) || ((tasks[i].getState() != 5) && (tasks[i].getState() != 2) && (tasks[i].getState() != 99) && (tasks[i].getState() != 7) && (tasks[i].getState() != 9)) || 
/* 75 */           (this.workflow.getWorkflowTemplate().isBeforTask(tasks[i].getTaskTemplateId(), getTaskTemplateId()) != true))
/*    */           continue;
/* 77 */         tasks[i].updateState(8, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskOrImpl.executeInner_orNodeCompleteOtherTask"));
/*    */ 
/* 79 */         if (tasks[i] instanceof TaskSignImpl) {
/* 80 */           WorkflowEngineFactory.getInstance().dealTransTaskDown(tasks[i].getTaskId(), this.workflow.getWorkflowId(), 8);
/* 81 */           IBOVmTaskTSValue[] transTasks = FlowFactory.getTaskTransBeansParentOrWorkflowId(tasks[i].getTaskId(), this.workflow.getWorkflowId());
/* 82 */           for (int j = 0; j < transTasks.length; ++j) {
/* 83 */             ((Workflow)getWorkflow()).realseUserTaskCount();
/*    */           }
/*    */         }
/* 86 */         else if (tasks[i] instanceof TaskUserImpl) {
/* 87 */           ((Workflow)getWorkflow()).realseUserTaskCount();
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 95 */       updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskOrImpl.executeInner_hasTaskPreComplete"));
/*    */     }
/*    */ 
/* 98 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskOrImpl
 * JD-Core Version:    0.5.4
 */