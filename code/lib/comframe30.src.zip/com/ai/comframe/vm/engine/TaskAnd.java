package com.ai.comframe.vm.engine;

public abstract interface TaskAnd extends Task
{
  public abstract void addFinishTaskTemplateId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskAnd
 * JD-Core Version:    0.5.4
 */