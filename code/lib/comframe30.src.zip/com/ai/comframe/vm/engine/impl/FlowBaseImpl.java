/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.ServiceUtil;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.common.VMException;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.FlowFactory;
/*     */ import com.ai.comframe.vm.engine.Task;
/*     */ import com.ai.comframe.vm.engine.TaskAnd;
/*     */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*     */ import com.ai.comframe.vm.engine.TaskDecision;
/*     */ import com.ai.comframe.vm.engine.TaskOr;
/*     */ import com.ai.comframe.vm.engine.TaskUser;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.engine.WorkflowContextImpl;
/*     */ import com.ai.comframe.vm.engine.WorkflowExpress;
/*     */ import com.ai.comframe.vm.template.GoToItem;
/*     */ import com.ai.comframe.vm.template.TaskAndTemplate;
/*     */ import com.ai.comframe.vm.template.TaskCaseTemplate;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskOrTemplate;
/*     */ import com.ai.comframe.vm.template.TaskStartTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.IWorkflowHandle;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentHelper;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class FlowBaseImpl extends TaskBaseImpl
/*     */   implements FlowBase
/*     */ {
/*     */   private static final long serialVersionUID = -1779447384554495529L;
/*  60 */   private static transient Log log = LogFactory.getLog(FlowBaseImpl.class);
/*     */ 
/*  62 */   public static String S_QUEUE_ID = "QUEUE_ID";
/*  63 */   public static String S_DISTRICT_ID = "REGION_ID";
/*  64 */   public static String S_VARS = "VARS";
/*  65 */   public static String S_CURRENT_TASK_ID = "CURRENT_TASK_ID";
/*  66 */   public static String S_PARENT_TASK_ID = "PARENT_TASK_ID";
/*  67 */   public static String S_USER_TASK_COUNT = "USER_TASK_COUNT";
/*  68 */   public static String S_CREATE_STAFF_ID = "CREATE_STAFF_ID";
/*  69 */   public static String S_OP_STAFF_ID = "OP_STAFF_ID";
/*  70 */   public static String S_WORKFLOW_OBJECT_ID = "WORKFLOW_OBJECT_ID";
/*  71 */   public static String S_WORKFLOW_OBJECT_TYPE = "WORKFLOW_OBJECT_TYPE";
/*  72 */   public static String S_ERROR_COUNT = "ERROR_COUNT";
/*  73 */   public static String S_ERROR_MESSAGE = "ERROR_MESSAGE";
/*  74 */   public static String S_ENGINE_TYPE = "ENGINE_TYPE";
/*     */   public static final String S_WORKFLOW_KIND = "WORKFLOW_KIND";
/*     */   public static final String S_SUSPEND_STATE = "SUSPEND_STATE";
/*     */   public static final String S_TEMPLATE_TAG = "TEMPLATE_TAG";
/*     */   protected WorkflowContext workflowContext;
/*  82 */   protected List m_currentTasks = new ArrayList();
/*  83 */   protected List m_historyTasks = new ArrayList();
/*     */   protected WorkflowExpress m_workflowExpress;
/*  85 */   protected boolean is_needRetry = false;
/*  86 */   protected String GOBACK_FLAG = "";
/*  87 */   protected Task nowScheduleTask = null;
/*     */ 
/*     */   public FlowBaseImpl(String aQueueId, String aParentTaskId, String aWorkflowId, int workflowKind, WorkflowTemplate aWorkflowTemplate, Map aVars, int aState, Date aStateDate, Date aCreateDate, String aCreateStaffId, String aObjectTypeId, String aObjectId)
/*     */     throws Exception
/*     */   {
/*  95 */     super(null, aWorkflowId, aWorkflowTemplate, aState, aStateDate, aCreateDate);
/*     */ 
/*  97 */     setQueueId(aQueueId);
/*     */ 
/* 100 */     if (CenterFactory.isSetCenterInfo() == true) {
/* 101 */       CenterInfo info = CenterFactory.getCenterInfo();
/* 102 */       String districtId = null;
/* 103 */       if (info != null) {
/* 104 */         districtId = info.getRegion();
/*     */       }
/* 106 */       setDistrictId(districtId);
/*     */     }
/*     */ 
/* 109 */     this.workflowContext = new WorkflowContextImpl();
/* 110 */     initialContext(this.workflowContext);
/*     */     Iterator it;
/* 112 */     if (aVars != null) {
/* 113 */       for (it = aVars.entrySet().iterator(); it.hasNext(); ) {
/* 114 */         Map.Entry e = (Map.Entry)it.next();
/* 115 */         String var = e.getKey().toString();
/*     */ 
/* 117 */         if (aWorkflowTemplate.getVars(var) != null) {
/* 118 */           this.workflowContext.set(var, e.getValue());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 123 */     this.m_dc.set("WORKFLOW_KIND", new Integer(workflowKind));
/*     */ 
/* 125 */     this.m_dc.set("PARENT_TASK_ID", aParentTaskId);
/* 126 */     this.m_dc.set(S_WORKFLOW_OBJECT_TYPE, aObjectTypeId);
/* 127 */     this.m_dc.set(S_WORKFLOW_OBJECT_ID, aObjectId);
/* 128 */     this.m_dc.set(S_CREATE_STAFF_ID, aCreateStaffId);
/*     */ 
/* 130 */     setDuration(aWorkflowTemplate.getTaskTag(), aObjectTypeId, aObjectId);
/*     */ 
/* 133 */     TaskTemplate[] taskTemplates = getWorkflowTemplate().getStartTaskTemplates();
/*     */ 
/* 136 */     for (int i = 0; i < taskTemplates.length; ++i) {
/* 137 */       Task task = FlowFactory.createTask(aQueueId, this, taskTemplates[i]);
/*     */ 
/* 139 */       if ((taskTemplates[i] instanceof TaskStartTemplate) && (((((TaskStartTemplate)taskTemplates[i]).getAutoDealBean() == null) || (StringUtils.isEmptyString(((TaskStartTemplate)taskTemplates[i]).getAutoDealBean().getRunClassName())))))
/*     */       {
/* 143 */         task.updateState(3, "");
/*     */       }
/*     */       else
/*     */       {
/* 147 */         task.updateState(2, "");
/*     */       }
/*     */ 
/* 150 */       this.m_currentTasks.add(task);
/*     */     }
/*     */   }
/*     */ 
/*     */   public FlowBaseImpl(WorkflowTemplate aWorkflowTemplate, DataContainerInterface workflowBean, DataContainerInterface[] taskBeans)
/*     */     throws Exception
/*     */   {
/* 157 */     super(null, aWorkflowTemplate, workflowBean);
/*     */ 
/* 159 */     this.workflowContext = new WorkflowContextImpl();
/* 160 */     stringToContext(workflowBean.getAsString(S_VARS), this.workflowContext);
/*     */ 
/* 162 */     for (int i = 0; (taskBeans != null) && (i < taskBeans.length); ++i) {
/* 163 */       Task task = FlowFactory.createTask(this, taskBeans[i]);
/* 164 */       if (!task.isCurrentTask())
/* 165 */         this.m_historyTasks.add(task);
/*     */       else
/* 167 */         this.m_currentTasks.add(task);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initialContext(WorkflowContext context) throws Exception {
/* 172 */     for (Iterator it = getWorkflowTemplate().getVars().iterator(); it.hasNext(); ) {
/* 173 */       ParameterDefine p = (ParameterDefine)it.next();
/* 174 */       if (!StringUtils.isEmptyString(p.defaultValue))
/* 175 */         context.set(p.name, VMDataType.transfer(p.defaultValue, p.getDataTypeClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void setDuration(String taskTag, String aObjectTypeId, String aObjectId) throws Exception
/*     */   {
/* 181 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 182 */     IBOVmAlarmConfigValue[] alarm = alarmConfigSV.getAlarmConfigs(taskTag);
/* 183 */     if ((alarm == null) || (alarm.length == 0))
/* 184 */       return;
/* 185 */     if (alarm.length > 1) {
/* 186 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.setDuration_codeByModel") + getWorkflow().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.oneMoreResult"));
/*     */     }
/*     */ 
/* 191 */     boolean isDuration = false;
/* 192 */     if (!StringUtils.isEmptyString(this.taskTemplate.getDuration()))
/*     */     {
/* 194 */       String Duration = this.taskTemplate.getDuration();
/* 195 */       if (Duration.charAt(0) == ':') {
/* 196 */         Duration = VMDataType.getAsString(getWorkflowExpress().execute(Duration.substring(1)));
/*     */       }
/* 198 */       if ((!StringUtils.isEmptyString(Duration)) && 
/* 199 */         (Long.parseLong(Duration) > 0L)) {
/* 200 */         this.m_dc.set(S_DURATION, new Long(Duration));
/* 201 */         isDuration = true;
/*     */       }
/*     */ 
/*     */     }
/* 206 */     else if (alarm.length == 1) {
/* 207 */       int duration = alarmConfigSV.calculateDuration(alarm[0].getDurationTimeMethod(), alarm[0].getTemplateVersionId(), alarm[0].getTemplateTag(), alarm[0].getTaskTag(), aObjectId, aObjectTypeId);
/*     */ 
/* 209 */       if (duration > 0) {
/* 210 */         this.m_dc.set(S_DURATION, new Long(duration));
/* 211 */         isDuration = true;
/*     */       }
/*     */     }
/*     */ 
/* 215 */     if (isDuration != true)
/*     */       return;
/*     */     try {
/* 218 */       Timestamp date = null;
/* 219 */       if (alarm.length == 1) {
/* 220 */         date = alarmConfigSV.calculateAlarmTime(alarm[0].getAlarmTimeMethod(), alarm[0].getTemplateVersionId(), alarm[0].getTemplateTag(), alarm[0].getTaskTag(), aObjectId, aObjectTypeId, this.m_dc.getAsInt(S_DURATION), 0, alarm[0].getIsHoliday());
/*     */       }
/*     */       else
/*     */       {
/* 225 */         date = alarmConfigSV.calculateAlarmTime(null, getTaskTemplateId(), taskTag, "", aObjectId, aObjectTypeId, this.m_dc.getAsInt(S_DURATION), 0, 0);
/*     */       }
/*     */ 
/* 228 */       if (date != null) {
/* 229 */         this.m_dc.set(S_WARNING_DATE, date);
/* 230 */         this.m_dc.set(S_WARNING_TIMES, new Long(0L));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 235 */       log.error("Failure alarm time calculation:" + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public WorkflowContext getWorkflowContext()
/*     */   {
/* 241 */     return this.workflowContext;
/*     */   }
/*     */ 
/*     */   public void setWorkflowContext(WorkflowContext context)
/*     */   {
/* 246 */     this.workflowContext = context;
/*     */   }
/*     */   public String getEngineType() {
/* 249 */     return this.m_dc.getAsString(S_ENGINE_TYPE);
/*     */   }
/*     */   public String getCreateStaffId() {
/* 252 */     return this.m_dc.getAsString(S_CREATE_STAFF_ID);
/*     */   }
/*     */   public void setCreateStaffId(String createStaffId) {
/* 255 */     this.m_dc.set(S_CREATE_STAFF_ID, createStaffId);
/*     */   }
/*     */   public String getQueueId() {
/* 258 */     return this.m_dc.getAsString(S_QUEUE_ID);
/*     */   }
/*     */   public void setQueueId(String queueId) {
/* 261 */     this.m_dc.set(S_QUEUE_ID, queueId);
/*     */   }
/*     */   public String getDistrictId() {
/* 264 */     return this.m_dc.getAsString(S_DISTRICT_ID);
/*     */   }
/*     */   public void setDistrictId(String districtId) {
/* 267 */     this.m_dc.set(S_DISTRICT_ID, districtId);
/*     */   }
/*     */   public String getWorkflowObjectTypeId() {
/* 270 */     return this.m_dc.getAsString(S_WORKFLOW_OBJECT_TYPE);
/*     */   }
/*     */   public String getWorkflowObjectId() {
/* 273 */     return this.m_dc.getAsString(S_WORKFLOW_OBJECT_ID);
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 277 */     return this.m_dc.getAsString(S_PARENT_TASK_ID);
/*     */   }
/*     */ 
/*     */   public int getWorkflowKind() {
/* 281 */     return this.m_dc.getAsInt("WORKFLOW_KIND");
/*     */   }
/*     */ 
/*     */   public Task getTask(String taskId)
/*     */   {
/* 288 */     for (Iterator it = this.m_currentTasks.iterator(); it.hasNext(); ) {
/* 289 */       task = (Task)it.next();
/* 290 */       if (task.getTaskId().equals(taskId))
/* 291 */         return task;
/*     */     }
/*     */     Task task;
/* 295 */     for (Iterator it = this.m_historyTasks.iterator(); it.hasNext(); ) {
/* 296 */       task = (Task)it.next();
/* 297 */       if (task.getTaskId().equals(taskId))
/* 298 */         return task;
/*     */     }
/*     */     Task task;
/* 300 */     return null;
/*     */   }
/*     */ 
/*     */   public Task getTaskByTemplateId(long templateId)
/*     */   {
/* 305 */     for (Iterator it = this.m_currentTasks.iterator(); it.hasNext(); ) {
/* 306 */       task = (Task)it.next();
/* 307 */       if (task.getTaskTemplateId() == templateId)
/* 308 */         return task;
/*     */     }
/*     */     Task task;
/* 312 */     for (Iterator it = this.m_historyTasks.iterator(); it.hasNext(); ) {
/* 313 */       task = (Task)it.next();
/* 314 */       if (task.getTaskTemplateId() == templateId)
/* 315 */         return task;
/*     */     }
/*     */     Task task;
/* 317 */     return null;
/*     */   }
/*     */ 
/*     */   public Task[] getCurrentTasks()
/*     */   {
/* 322 */     return (Task[])(Task[])this.m_currentTasks.toArray(new Task[0]);
/*     */   }
/*     */   public List getCurrentTaskList() {
/* 325 */     return this.m_currentTasks;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplate() {
/* 329 */     return (WorkflowTemplate)this.taskTemplate;
/*     */   }
/*     */   public Object execute(WorkflowContext context) throws Exception {
/* 332 */     throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.getWorkflowTemplate_cannotUseMethod"));
/*     */   }
/*     */ 
/*     */   public boolean executeCondition(Object[] operatorList) throws Exception {
/* 336 */     Object obj = null;
/* 337 */     if (operatorList.length == 0) {
/* 338 */       return true;
/*     */     }
/* 340 */     obj = getWorkflowExpress().executeByCResult(operatorList);
/* 341 */     if (obj instanceof Boolean) {
/* 342 */       return ((Boolean)obj).booleanValue();
/*     */     }
/* 344 */     throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.executeCondition_judgeBoolean"));
/*     */   }
/*     */ 
/*     */   protected void dealTask(Task task)
/*     */     throws Exception
/*     */   {
/* 358 */     if (task.getState() == 6)
/*     */     {
/* 360 */       if ((StringUtils.isEmptyString(task.getDestType())) || (task.getDestTaskTemplateId() <= 0L))
/* 361 */         throw new Exception("the state is back(6),but dest_type and dest_task_template_id is null !");
/* 362 */       String lastTaskId = "";
/* 363 */       TaskTemplate destTemlate = getWorkflowTemplate().getTaskTemplate(task.getDestTaskTemplateId());
/* 364 */       if (destTemlate == null) {
/* 365 */         throw new Exception("dest task template id is not exists:" + task.getDestTaskTemplateId());
/*     */       }
/*     */ 
/* 368 */       if (task.getDestType().equals("J"))
/*     */       {
/* 370 */         lastTaskId = task.getTaskId();
/*     */       }
/*     */       else
/*     */       {
/* 374 */         Task destTask = null;
/* 375 */         Task[] tasks = (Task[])(Task[])this.m_historyTasks.toArray(new Task[0]);
/* 376 */         for (int i = 0; i < tasks.length; ++i) {
/* 377 */           if ((tasks[i].getTaskTemplateId() != task.getDestTaskTemplateId()) || (
/* 378 */             (destTask != null) && (IDAssembleUtil.unwrapID(tasks[i].getTaskId()) <= IDAssembleUtil.unwrapID(destTask.getTaskId())))) continue;
/* 379 */           destTask = tasks[i];
/*     */         }
/*     */ 
/* 382 */         if (destTask == null) {
/* 383 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_notBackToUndo"));
/*     */         }
/*     */ 
/* 386 */         if (destTask.getState() != 6)
/* 387 */           throw new Exception("dest task state is wrong !" + destTask.getTaskId() + "....state:" + destTask.getState());
/* 388 */         lastTaskId = destTask.getDataBean().getAsString(TaskBaseImpl.S_LAST_TASK_ID);
/*     */       }
/* 390 */       Task newTask = FlowFactory.createTask(getQueueId(), this, destTemlate);
/*     */ 
/* 392 */       newTask.getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, lastTaskId);
/* 393 */       this.m_currentTasks.add(newTask);
/*     */ 
/* 395 */       return;
/*     */     }
/*     */ 
/* 399 */     if (task.getState() == 11) {
/* 400 */       boolean hasExceptionNode = false;
/* 401 */       for (Iterator it = task.getTaskTemplate().getGoToItems().iterator(); it.hasNext(); ) {
/* 402 */         GoToItem gotoItem = (GoToItem)it.next();
/* 403 */         if ((gotoItem.getCondition() == null) || (!gotoItem.getCondition().equalsIgnoreCase("exception")))
/*     */           continue;
/* 405 */         TaskTemplate taskTemplate = getWorkflowTemplate().getTaskTemplate(gotoItem.getNextTaskTemplateId());
/*     */ 
/* 407 */         if (taskTemplate == null)
/*     */           continue;
/* 409 */         createNewTask(task, taskTemplate);
/* 410 */         hasExceptionNode = true;
/*     */       }
/*     */ 
/* 413 */       if (hasExceptionNode == true) {
/* 414 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 418 */     if (task.getTaskTemplate() instanceof TaskCaseTemplate) {
/* 419 */       dealCaseTask(task);
/* 420 */       return;
/*     */     }
/*     */ 
/* 423 */     if (task instanceof TaskDecision) {
/* 424 */       dealDecisionTask(task);
/* 425 */       return;
/*     */     }
/*     */ 
/* 428 */     for (Iterator it = task.getTaskTemplate().getGoToItems().iterator(); it.hasNext(); ) {
/* 429 */       GoToItem gotoItem = (GoToItem)it.next();
/* 430 */       if ((gotoItem.getCondition() != null) && (gotoItem.getCondition().equalsIgnoreCase("exception"))) {
/*     */         continue;
/*     */       }
/*     */ 
/* 434 */       TaskTemplate taskTemplate = getWorkflowTemplate().getTaskTemplate(gotoItem.getNextTaskTemplateId());
/*     */ 
/* 436 */       if (taskTemplate == null)
/*     */         continue;
/* 438 */       createNewTask(task, taskTemplate);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean hasExceptionCondition(Task task) throws Exception {
/* 443 */     for (Iterator it = task.getTaskTemplate().getGoToItems().iterator(); it.hasNext(); ) {
/* 444 */       GoToItem gotoItem = (GoToItem)it.next();
/* 445 */       if ((gotoItem.getCondition() != null) && (gotoItem.getCondition().equalsIgnoreCase("exception")))
/*     */       {
/* 447 */         return true;
/*     */       }
/*     */     }
/* 450 */     return false;
/*     */   }
/*     */ 
/*     */   private void dealCaseTask(Task task) throws Exception {
/* 454 */     GoToItem gotoItem = null;
/* 455 */     TaskTemplate taskTemplate = null;
/* 456 */     GoToItem defaultGoToItem = null;
/* 457 */     List trueItem = new ArrayList();
/* 458 */     for (Iterator it = task.getTaskTemplate().getGoToItems().iterator(); it.hasNext(); ) {
/* 459 */       gotoItem = (GoToItem)it.next();
/* 460 */       if ("default".equalsIgnoreCase(gotoItem.getCondition()) == true) {
/* 461 */         defaultGoToItem = gotoItem;
/*     */       }
/* 463 */       Object[] opList = gotoItem.getOperatorList();
/* 464 */       if (opList == null) {
/* 465 */         synchronized (gotoItem) {
/* 466 */           opList = gotoItem.getOperatorList();
/* 467 */           if (opList == null) {
/* 468 */             String condition = gotoItem.getCondition();
/* 469 */             if ((condition == null) || (condition.length() == 0)) {
/* 470 */               opList = new Object[0];
/*     */             }
/*     */             else {
/* 473 */               opList = getWorkflowExpress().getOpObjectList(condition + ";");
/*     */             }
/*     */ 
/* 477 */             gotoItem.setOperatorList(opList);
/*     */           }
/*     */         }
/*     */       }
/* 481 */       if (executeCondition(opList) == true) {
/* 482 */         trueItem.add(gotoItem);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 487 */     if ((trueItem.size() == 0) && (defaultGoToItem == null))
/* 488 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_caseNoCondNoBranch"));
/* 489 */     if (trueItem.size() > 1) {
/* 490 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_caseSupportBranch"));
/*     */     }
/*     */ 
/* 493 */     if (trueItem.size() == 0)
/* 494 */       gotoItem = defaultGoToItem;
/*     */     else {
/* 496 */       gotoItem = (GoToItem)trueItem.get(0);
/*     */     }
/*     */ 
/* 499 */     taskTemplate = getWorkflowTemplate().getTaskTemplate(gotoItem.getNextTaskTemplateId());
/* 500 */     createNewTask(task, taskTemplate);
/*     */   }
/*     */ 
/*     */   private void dealDecisionTask(Task task) throws Exception {
/* 504 */     GoToItem gotoItem = null;
/* 505 */     TaskTemplate taskTemplate = null;
/* 506 */     GoToItem defaultGoToItem = null;
/* 507 */     List trueItem = new ArrayList();
/* 508 */     for (Iterator it = task.getTaskTemplate().getGoToItems().iterator(); it.hasNext(); ) {
/* 509 */       gotoItem = (GoToItem)it.next();
/*     */ 
/* 511 */       if ((task instanceof TaskUser) && (task.getTaskTemplate().getGoToItems().size() == 1))
/*     */       {
/* 513 */         trueItem.add(gotoItem);
/*     */       }
/* 515 */       if ("default".equalsIgnoreCase(gotoItem.getCondition()) == true) {
/* 516 */         defaultGoToItem = gotoItem;
/*     */       }
/*     */ 
/* 519 */       Object r = ((TaskDecision)task).getDecision();
/* 520 */       if ((r != null) && (r.toString().equalsIgnoreCase(gotoItem.getCondition()) == true)) {
/* 521 */         trueItem.add(gotoItem);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 526 */     if ((trueItem.size() == 0) && (defaultGoToItem == null)) {
/* 527 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_node") + task.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_noCondNoBranch"));
/*     */     }
/*     */ 
/* 532 */     if (trueItem.size() > 1) {
/* 533 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_node") + task.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_supportBranch"));
/*     */     }
/*     */ 
/* 538 */     if (trueItem.size() == 0)
/* 539 */       gotoItem = defaultGoToItem;
/*     */     else {
/* 541 */       gotoItem = (GoToItem)trueItem.get(0);
/*     */     }
/*     */ 
/* 544 */     taskTemplate = getWorkflowTemplate().getTaskTemplate(gotoItem.getNextTaskTemplateId());
/* 545 */     createNewTask(task, taskTemplate);
/*     */   }
/*     */ 
/*     */   private void createNewTask(Task task, TaskTemplate taskTemplate)
/*     */     throws Exception
/*     */   {
/* 551 */     if (taskTemplate instanceof TaskAndTemplate) {
/* 552 */       boolean isFind = false;
/*     */ 
/* 554 */       for (int k = 0; k < this.m_currentTasks.size(); ++k) {
/* 555 */         if (((Task)this.m_currentTasks.get(k)).getTaskTemplateId() != taskTemplate.getTaskTemplateId())
/*     */           continue;
/* 557 */         ((TaskAnd)this.m_currentTasks.get(k)).addFinishTaskTemplateId(task.getTaskTemplate().getTaskTemplateId());
/*     */ 
/* 560 */         String str = ((TaskAnd)this.m_currentTasks.get(k)).getDataBean().getAsString(TaskBaseImpl.S_LAST_TASK_ID);
/* 561 */         if (!StringUtils.isEmptyString(str)) {
/* 562 */           str = str + "," + String.valueOf(task.getTaskId());
/* 563 */           ((TaskAnd)this.m_currentTasks.get(k)).getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, str);
/*     */         }
/* 565 */         isFind = true;
/* 566 */         break;
/*     */       }
/*     */ 
/* 569 */       if (!isFind) {
/* 570 */         Task newTask = FlowFactory.createTask(getQueueId(), this, taskTemplate);
/* 571 */         ((TaskAnd)newTask).addFinishTaskTemplateId(task.getTaskTemplate().getTaskTemplateId());
/*     */ 
/* 573 */         newTask.getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, String.valueOf(task.getTaskId()));
/* 574 */         this.m_currentTasks.add(newTask);
/*     */       }
/*     */     }
/* 577 */     else if (taskTemplate instanceof TaskOrTemplate) {
/* 578 */       boolean isFind = false;
/*     */ 
/* 580 */       for (int k = 0; k < this.m_currentTasks.size(); ++k) {
/* 581 */         if (((Task)this.m_currentTasks.get(k)).getTaskTemplateId() != taskTemplate.getTaskTemplateId())
/*     */           continue;
/* 583 */         ((TaskOr)this.m_currentTasks.get(k)).addFinishTaskTemplateId(task.getTaskTemplate().getTaskTemplateId());
/*     */ 
/* 586 */         String str = ((TaskOr)this.m_currentTasks.get(k)).getDataBean().getAsString(TaskBaseImpl.S_LAST_TASK_ID);
/* 587 */         if (!StringUtils.isEmptyString(str)) {
/* 588 */           str = str + "," + String.valueOf(task.getTaskId());
/* 589 */           ((TaskOr)this.m_currentTasks.get(k)).getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, str);
/*     */         }
/* 591 */         isFind = true;
/* 592 */         break;
/*     */       }
/*     */ 
/* 595 */       if (!isFind) {
/* 596 */         Task newTask = FlowFactory.createTask(getQueueId(), this, taskTemplate);
/* 597 */         ((TaskOr)newTask).addFinishTaskTemplateId(task.getTaskTemplate().getTaskTemplateId());
/*     */ 
/* 599 */         newTask.getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, String.valueOf(task.getTaskId()));
/* 600 */         this.m_currentTasks.add(newTask);
/*     */       }
/*     */     } else {
/* 603 */       Task newTask = FlowFactory.createTask(getQueueId(), this, taskTemplate);
/* 604 */       newTask.getDataBean().set(TaskBaseImpl.S_LAST_TASK_ID, String.valueOf(task.getTaskId()));
/* 605 */       this.m_currentTasks.add(newTask);
/*     */     }
/*     */   }
/*     */ 
/*     */   public WorkflowExpress getWorkflowExpress() {
/* 610 */     if (this.m_workflowExpress == null)
/* 611 */       this.m_workflowExpress = new WorkflowExpress(this);
/* 612 */     return this.m_workflowExpress;
/*     */   }
/*     */ 
/*     */   public void fillBack() throws Exception {
/* 616 */     String str = "";
/*     */ 
/* 629 */     str = contextToString();
/* 630 */     if (!str.equals(this.m_dc.getAsString(S_VARS)))
/* 631 */       this.m_dc.set(S_VARS, str);
/*     */   }
/*     */ 
/*     */   protected void stringToContext(String str, WorkflowContext context) throws Exception {
/* 635 */     Element e = DocumentHelper.parseText(str).getRootElement();
/* 636 */     List tmpList = e.elements("var");
/*     */ 
/* 640 */     for (int i = 0; i < tmpList.size(); ++i) {
/* 641 */       Element tmpNode = (Element)tmpList.get(i);
/* 642 */       String name = tmpNode.attributeValue("name");
/* 643 */       if (name.equals("$TASK_EXCEPTION_CODE")) {
/* 644 */         context.set("$TASK_EXCEPTION_CODE", tmpNode.getTextTrim());
/*     */       }
/* 647 */       else if (name.equals("$TASK_EXCEPTION_MSG")) {
/* 648 */         context.set("$TASK_EXCEPTION_MSG", tmpNode.getTextTrim());
/*     */       }
/* 651 */       else if (name.equals("_ENGINE_LAST_TASK_ID")) {
/* 652 */         context.set("_ENGINE_LAST_TASK_ID", tmpNode.getTextTrim());
/*     */       }
/*     */       else {
/* 655 */         ParameterDefine p = getWorkflowTemplate().getVars(name);
/* 656 */         if (p == null) {
/* 657 */           log.error("Process instance" + getWorkflowId() + "Variables and templates" + getTaskTag() + "Variable definition is inconsistent: " + name + " Undefined");
/*     */ 
/* 661 */           context.set(name, tmpNode.getTextTrim());
/*     */         }
/*     */         else {
/* 664 */           context.set(p.name, VMDataType.transfer(tmpNode.getTextTrim(), p.getDataTypeClass()));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String contextToString() throws Exception {
/* 669 */     Element e = XmlUtil.createElement("vars", "");
/* 670 */     List vars = getWorkflowTemplate().getVars();
/*     */ 
/* 674 */     for (int i = 0; i < vars.size(); ++i) {
/* 675 */       ParameterDefine p = (ParameterDefine)vars.get(i);
/* 676 */       Object obj = this.workflowContext.get(p.name);
/* 677 */       if (obj != null) {
/* 678 */         Element node = e.addElement("var");
/* 679 */         node.addAttribute("name", p.name);
/* 680 */         node.setText(VMDataType.transferToString(obj, p.dataType));
/*     */       }
/*     */     }
/* 683 */     if ((getState() != 3) && (getState() != 4) && (getState() != 8))
/*     */     {
/* 685 */       Object obj = this.workflowContext.get("$TASK_EXCEPTION_CODE");
/* 686 */       if (obj != null) {
/* 687 */         Element node = e.addElement("var");
/* 688 */         node.addAttribute("name", "$TASK_EXCEPTION_CODE");
/* 689 */         node.setText(obj.toString());
/*     */       }
/* 691 */       obj = this.workflowContext.get("$TASK_EXCEPTION_MSG");
/* 692 */       if (obj != null) {
/* 693 */         Element node = e.addElement("var");
/* 694 */         node.addAttribute("name", "$TASK_EXCEPTION_MSG");
/* 695 */         node.setText(obj.toString());
/*     */       }
/* 697 */       obj = this.workflowContext.get("_ENGINE_LAST_TASK_ID");
/* 698 */       if (obj != null) {
/* 699 */         Element node = e.addElement("var");
/* 700 */         node.addAttribute("name", "_ENGINE_LAST_TASK_ID");
/* 701 */         node.setText(obj.toString());
/*     */       }
/*     */     }
/* 704 */     return XmlUtil.formatElement(e);
/*     */   }
/*     */   public DataContainerInterface[] getTaskBeans() throws Exception {
/* 707 */     DataContainerInterface[] result = new DataContainerInterface[this.m_historyTasks.size() + this.m_currentTasks.size()];
/*     */ 
/* 709 */     int hCount = this.m_historyTasks.size();
/* 710 */     for (int i = 0; i < hCount; ++i) {
/* 711 */       result[i] = ((Task)this.m_historyTasks.get(i)).getDataBean();
/*     */     }
/* 713 */     for (int i = 0; i < this.m_currentTasks.size(); ++i) {
/* 714 */       result[(i + hCount)] = ((Task)this.m_currentTasks.get(i)).getDataBean();
/*     */     }
/* 716 */     return result;
/*     */   }
/*     */ 
/*     */   public long getUserTaskCount() throws Exception {
/* 720 */     return this.m_dc.getAsLong(S_USER_TASK_COUNT);
/*     */   }
/*     */   public void addUserTaskCount() throws Exception {
/* 723 */     this.m_dc.set(S_USER_TASK_COUNT, new Long(this.m_dc.getAsLong(S_USER_TASK_COUNT) + 1L));
/*     */   }
/*     */   public void realseUserTaskCount() throws Exception {
/* 726 */     this.m_dc.set(S_USER_TASK_COUNT, new Long(this.m_dc.getAsLong(S_USER_TASK_COUNT) - 1L));
/*     */   }
/*     */ 
/*     */   public void disable(String staffId, String reason) throws Exception {
/* 730 */     updateState(1, reason);
/* 731 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/*     */   }
/*     */ 
/*     */   public void enable(String staffId, String reason) throws Exception
/*     */   {
/* 736 */     updateState(2, reason);
/* 737 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/*     */   }
/*     */ 
/*     */   public void suspend(String staffId, String reason) throws Exception {
/* 741 */     this.m_dc.set("SUSPEND_STATE", Integer.valueOf(1));
/* 742 */     this.m_dc.set(S_DESCRIPTION, reason);
/* 743 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/*     */   }
/*     */ 
/*     */   public void resume(String staffId, String reason) throws Exception {
/* 747 */     this.m_dc.set("SUSPEND_STATE", Integer.valueOf(2));
/* 748 */     this.m_dc.set(S_DESCRIPTION, reason);
/* 749 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/*     */   }
/*     */ 
/*     */   public void terminate(String staffId, String reason) throws Exception
/*     */   {
/* 754 */     updateState(4, reason);
/* 755 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/* 756 */     this.m_dc.set(S_FINISH_DATE, TimeUtil.getSysTime());
/*     */   }
/*     */ 
/*     */   public void updateState(int aState, String aReason) {
/* 760 */     super.updateState(aState, aReason);
/*     */ 
/* 762 */     if (aState == 99) {
/* 763 */       WorkflowTemplate t = getWorkflowTemplate();
/* 764 */       TaskDealBean ed = t.getExceptionDealBean();
/* 765 */       if (ed == null) return;
/*     */       try {
/* 767 */         executeDealInner(this, this.workflowContext, ed);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 771 */         log.error("Error trigger business systems approach. ", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void fireException(String staffId, String reason) throws Exception
/*     */   {
/* 778 */     updateState(99, reason);
/* 779 */     this.m_dc.set(S_OP_STAFF_ID, staffId);
/*     */   }
/*     */   public int getErrorCount() {
/* 782 */     return this.m_dc.getAsInt(S_ERROR_COUNT);
/*     */   }
/*     */   public void setErrorCount(long errorCount) {
/* 785 */     this.m_dc.set(S_ERROR_COUNT, new Long(errorCount));
/*     */   }
/*     */   public void setErrorMessage(String errorMessage) {
/* 788 */     this.m_dc.set(S_ERROR_MESSAGE, errorMessage);
/*     */   }
/*     */ 
/*     */   public boolean isNeedRetry() {
/* 792 */     return this.is_needRetry;
/*     */   }
/*     */   public void setIsNeedRetry(boolean isNeedRetry) {
/* 795 */     this.is_needRetry = isNeedRetry;
/*     */   }
/*     */ 
/*     */   public void monitor(String staffId, Throwable ex, int trigger) {
/* 799 */     CenterInfo ci = null;
/*     */     try
/*     */     {
/* 802 */       if (CenterFactory.isSetCenterInfo())
/* 803 */         ci = CenterFactory.getCenterInfo();
/* 804 */       String monitorType = this.taskTemplate.getMonitorType();
/* 805 */       String monitorService = this.taskTemplate.getMonitorService();
/* 806 */       if ((!StringUtils.isEmptyString(monitorType)) && (!StringUtils.isEmptyString(monitorService)))
/*     */       {
/* 808 */         Object monitorObj = null;
/* 809 */         if (monitorType.equalsIgnoreCase("pojo")) {
/* 810 */           monitorObj = VMDataType.getJavaClass(monitorService).newInstance();
/*     */         }
/*     */         else {
/* 813 */           monitorObj = ServiceUtil.getService(monitorService);
/*     */         }
/*     */ 
/* 816 */         long currentTime = TimeUtil.getSysTime().getTime();
/*     */ 
/* 818 */         if (trigger == 11) {
/* 819 */           IWorkflowHandle handle = (IWorkflowHandle)monitorObj;
/* 820 */           handle.onCreateInstance(getWorkflowId(), getTaskTag(), getLabel(), getWorkflowObjectTypeId(), getWorkflowObjectId(), getWorkflowContext(), staffId, getCreateDate().getTime());
/*     */         }
/* 823 */         else if (trigger == 12) {
/* 824 */           IWorkflowHandle handle = (IWorkflowHandle)monitorObj;
/* 825 */           handle.onFinishInstance(getWorkflowId(), getTaskTag(), getLabel(), getWorkflowObjectTypeId(), getWorkflowObjectId(), getWorkflowContext(), getCreateDate().getTime(), currentTime);
/*     */         }
/* 828 */         else if (trigger == 13) {
/* 829 */           IWorkflowHandle handle = (IWorkflowHandle)monitorObj;
/* 830 */           handle.onInstanceException(getWorkflowId(), getTaskTag(), getLabel(), getWorkflowObjectTypeId(), getWorkflowObjectId(), getWorkflowContext(), ex, getCreateDate().getTime(), currentTime);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable t)
/*     */     {
/* 836 */       log.info("workflow monitoring abnormal：" + t.getMessage(), t);
/*     */     } finally {
/* 838 */       if (ci != null)
/* 839 */         CenterFactory.setDirectCenterInfo(ci);
/*     */       else
/* 841 */         CenterFactory.setCenterInfoEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setGobackFlag(String gobackFlag) {
/* 846 */     this.GOBACK_FLAG = gobackFlag;
/*     */   }
/*     */ 
/*     */   public void setWorkflowId(String workflowId) {
/* 850 */     this.m_dc.set(S_WORKFLOW_ID, workflowId);
/*     */   }
/*     */ 
/*     */   public String getWorkflowId(String workflowId)
/*     */   {
/* 855 */     return this.m_dc.getAsString(S_WORKFLOW_ID);
/*     */   }
/*     */ 
/*     */   public Task getNowScheduleTask()
/*     */   {
/* 860 */     return this.nowScheduleTask;
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 864 */     return this.m_dc.getAsString("TEMPLATE_TAG");
/*     */   }
/*     */ 
/*     */   public int getSuspendState() {
/* 868 */     return this.m_dc.getAsInt("SUSPEND_STATE");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.FlowBaseImpl
 * JD-Core Version:    0.5.4
 */