/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskNullImpl extends TaskBaseImpl
/*    */   implements Task
/*    */ {
/* 10 */   private static transient Log log = LogFactory.getLog(TaskStartImpl.class);
/*    */ 
/*    */   public TaskNullImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 16 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskNullImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 21 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 25 */     log.debug("Placeholder tasks" + getTaskTemplate().getTaskType() + "(" + getTaskTemplate().getLabel() + ")" + "Stage, does not perform the task Affairs");
/* 26 */     updateState(3, "");
/* 27 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskNullImpl
 * JD-Core Version:    0.5.4
 */