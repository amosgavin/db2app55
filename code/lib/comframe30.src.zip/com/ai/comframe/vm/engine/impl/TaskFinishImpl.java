/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.utils.PropertiesUtil;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.FlowFactory;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*    */ import java.sql.Date;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskFinishImpl extends TaskAutoImpl
/*    */   implements Task
/*    */ {
/*    */   private static final long serialVersionUID = -7810650128366329062L;
/* 25 */   private static transient Log log = LogFactory.getLog(TaskFinishImpl.class);
/*    */ 
/*    */   public TaskFinishImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 31 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskFinishImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 36 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception
/*    */   {
/* 41 */     super.executeInner(context);
/* 42 */     setIsCurrentTask(false);
/* 43 */     this.workflow.updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskFinishImpl.executeInner_excuteFinishNode"));
/* 44 */     if ((this.workflow.getParentTaskId() != null) && (!"-1".equals(this.workflow.getParentTaskId())) && (this.workflow.getWorkflowKind() == 2))
/*    */     {
/* 48 */       FlowFactory.save(this.workflow);
/*    */     }
/* 50 */     dealWhenWorkflowFinish(getWorkflow(), getTaskId(), 3);
/*    */ 
/* 52 */     return Boolean.TRUE;
/*    */   }
/*    */   public static void dealWhenWorkflowFinish(FlowBase workflow, String finishTaskId, int workflowState) throws Exception {
/* 55 */     if ((workflow.getParentTaskId() != null) && (!"-1".equals(workflow.getParentTaskId())) && (workflow.getWorkflowKind() == 2))
/*    */     {
/* 58 */       WorkflowEngineFactory.getInstance().terminateWorkflowInner(workflow.getParentTaskId(), PropertiesUtil.getSystemUserId(), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskFinishImpl.dealWhenWorkflowFinish_endProcessAfterChildException"));
/*    */     }
/* 61 */     else if ((workflow.getParentTaskId() != null) && (!"-1".equals(workflow.getParentTaskId())) && (workflow.getWorkflowKind() == 1))
/*    */     {
/* 64 */       WorkflowEngineFactory.getInstance().finishChildWorkflowTask(workflow.getParentTaskId(), workflow.getWorkflowId(), workflow.getWorkflowContext().getParameters(), workflowState);
/*    */     }
/*    */ 
/* 70 */     log.debug("Workflow end: all the current task queue did not complete the task set to expire！");
/* 71 */     Task[] tasks = workflow.getCurrentTasks();
/* 72 */     for (int i = 0; i < tasks.length; ++i) {
/* 73 */       if ((tasks[i].getTaskId().equals(finishTaskId)) || ((tasks[i].getState() != 5) && (tasks[i].getState() != 2) && (tasks[i].getState() != 99) && (tasks[i].getState() != 7) && (tasks[i].getState() != 9) && (tasks[i].getState() != 10)))
/*    */       {
/*    */         continue;
/*    */       }
/*    */ 
/* 82 */       if (tasks[i] instanceof TaskSignImpl) {
/* 83 */         if (log.isDebugEnabled())
/* 84 */           log.debug("terminate sign:" + tasks[i].getTaskId());
/* 85 */         WorkflowEngineFactory.getInstance().dealTransTaskDown(tasks[i].getTaskId(), workflow.getWorkflowId(), 4);
/*    */       }
/* 87 */       else if ((tasks[i] instanceof TaskTimerImpl) || (tasks[i] instanceof TaskUserImpl))
/*    */       {
/* 89 */         if (log.isDebugEnabled())
/* 90 */           log.debug("delete timer record:" + tasks[i].getTaskId());
/* 91 */         TaskTimerImpl.deleteTimerRecord(tasks[i].getTaskId());
/*    */       }
/* 93 */       else if (tasks[i] instanceof TaskWorkflowImpl) {
/* 94 */         IBOVmWFValue[] beans = TaskWorkflowImpl.getChildWorkflows(tasks[i].getTaskId());
/* 95 */         for (int j = 0; j < beans.length; ++j) {
/* 96 */           if ((beans[j].getState() == 3) || (beans[j].getState() == 4))
/*    */             continue;
/* 98 */           if (log.isDebugEnabled()) {
/* 99 */             log.debug("terminate child work flow :" + beans[j].getWorkflowId());
/*    */           }
/* 101 */           WorkflowEngineFactory.getInstance().terminateWorkflow(beans[j].getWorkflowId(), PropertiesUtil.getSystemUserId(), ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskFinishImpl.dealWhenWorkflowFinish_endProcessCauseByFatherEndUnnormal"));
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 107 */       if (tasks[i].getState() == 10) {
/* 108 */         if (log.isDebugEnabled())
/* 109 */           log.debug("terminate task ts :" + tasks[i].getTaskId());
/* 110 */         WorkflowEngineFactory.getInstance().dealTransTaskDown(tasks[i].getTaskId(), workflow.getWorkflowId(), 4);
/*    */       }
/* 112 */       tasks[i].setIsCurrentTask(false);
/* 113 */       tasks[i].updateState(4, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskFinishImpl.dealWhenWorkflowFinish_processEnd"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskFinishImpl
 * JD-Core Version:    0.5.4
 */