/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.TaskLoop;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ 
/*    */ public class TaskLoopImpl extends TaskDecisionConditionImpl
/*    */   implements TaskLoop
/*    */ {
/*    */   public TaskLoopImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 13 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskLoopImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 18 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskLoopImpl
 * JD-Core Version:    0.5.4
 */