package com.ai.comframe.vm.engine;

public abstract interface Processflow extends FlowBase
{
  public abstract Object executeProcess()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.Processflow
 * JD-Core Version:    0.5.4
 */