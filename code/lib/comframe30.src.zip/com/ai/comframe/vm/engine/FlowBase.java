package com.ai.comframe.vm.engine;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.comframe.vm.template.WorkflowTemplate;
import java.util.List;

public abstract interface FlowBase extends Task
{
  public static final long S_ERROR_REDO_COUNT = 3L;

  public abstract void fillBack()
    throws Exception;

  public abstract DataContainerInterface[] getTaskBeans()
    throws Exception;

  public abstract WorkflowTemplate getWorkflowTemplate();

  public abstract WorkflowContext getWorkflowContext();

  public abstract Task getTask(String paramString);

  public abstract Task getTaskByTemplateId(long paramLong);

  public abstract List getCurrentTaskList();

  public abstract Task[] getCurrentTasks();

  public abstract WorkflowExpress getWorkflowExpress();

  public abstract int getErrorCount();

  public abstract void setErrorCount(long paramLong);

  public abstract void setErrorMessage(String paramString);

  public abstract String getEngineType();

  public abstract String getQueueId();

  public abstract String getWorkflowObjectTypeId();

  public abstract String getWorkflowObjectId();

  public abstract String getParentTaskId();

  public abstract int getWorkflowKind();

  public abstract void setQueueId(String paramString);

  public abstract void setWorkflowId(String paramString);

  public abstract String getWorkflowId();

  public abstract String getDistrictId();

  public abstract String getCreateStaffId();

  public abstract void setCreateStaffId(String paramString);

  public abstract boolean isNeedRetry();

  public abstract void setIsNeedRetry(boolean paramBoolean);

  public abstract void setGobackFlag(String paramString);

  public abstract Task getNowScheduleTask();

  public abstract String getTemplateTag();

  public abstract int getSuspendState();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.FlowBase
 * JD-Core Version:    0.5.4
 */