/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.client.ComframeBusiException;
/*     */ import com.ai.comframe.exception.service.impl.BusiExceptionDeal;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.engine.FlowFactory;
/*     */ import com.ai.comframe.vm.engine.Task;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.template.TaskAutoTemplate;
/*     */ import com.ai.comframe.vm.template.TaskSignTemplate;
/*     */ import com.ai.comframe.vm.template.TaskStartTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*     */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.sql.Date;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class WorkflowImpl extends FlowBaseImpl
/*     */   implements Workflow
/*     */ {
/*  40 */   private static transient Log log = LogFactory.getLog(WorkflowImpl.class);
/*     */ 
/*     */   public WorkflowImpl(String aQueueId, String aParentTaskId, String aWorkflowId, int workflowKind, WorkflowTemplate aWorkflowTemplate, Map aVars, int aState, Date aStateDate, Date aCreateDate, String aCreateStaffId, String aObjectTypeId, String aObjectId)
/*     */     throws Exception
/*     */   {
/*  47 */     super(aQueueId, aParentTaskId, aWorkflowId, workflowKind, aWorkflowTemplate, aVars, aState, aStateDate, aCreateDate, aCreateStaffId, aObjectTypeId, aObjectId);
/*     */   }
/*     */ 
/*     */   public WorkflowImpl(WorkflowTemplate aWorkflowTemplate, DataContainerInterface workflowBean, DataContainerInterface[] taskBeans)
/*     */     throws Exception
/*     */   {
/*  54 */     super(aWorkflowTemplate, workflowBean, taskBeans);
/*     */   }
/*     */ 
/*     */   public Object executeWorkflowSyn()
/*     */     throws Exception
/*     */   {
/*  67 */     boolean result = true;
/*  68 */     while (result == true) {
/*  69 */       List finishTaskList = new ArrayList();
/*  70 */       for (int i = 0; i < this.m_currentTasks.size(); ++i) {
/*  71 */         Task task = (Task)this.m_currentTasks.get(i);
/*  72 */         int tmpState = task.getState();
/*  73 */         if (tmpState == 2) {
/*  74 */           task.execute(this.workflowContext);
/*  75 */           tmpState = task.getState();
/*     */         }
/*     */ 
/*  78 */         if ((tmpState == 7) || (tmpState == 5) || (tmpState == 9))
/*  79 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_synProcess") + getTaskTemplate().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_noTimerTaskAndHandTask"));
/*  80 */         if ((tmpState == 3) || (tmpState == 4) || (tmpState == 98)) {
/*  81 */           this.m_currentTasks.remove(i);
/*  82 */           this.m_historyTasks.add(task);
/*  83 */           finishTaskList.add(task);
/*  84 */         } else if (tmpState == 8) {
/*  85 */           this.m_currentTasks.remove(i);
/*  86 */           task.setIsCurrentTask(false);
/*  87 */           this.m_historyTasks.add(task);
/*     */         }
/*     */         else {
/*  90 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_taskStateException"));
/*     */         }
/*     */       }
/*  93 */       if (finishTaskList.size() > 0) {
/*  94 */         for (int i = 0; i < finishTaskList.size(); ++i) {
/*  95 */           Task task = (Task)finishTaskList.get(i);
/*  96 */           dealTask(task);
/*  97 */           task.setIsCurrentTask(false);
/*     */         }
/*  99 */         if ((this.m_currentTasks.size() == 0) && (getState() != 3))
/*     */         {
/* 101 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_sysException") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_noEndNoTask"));
/*     */         }
/*     */       }
/*     */ 
/* 105 */       result = finishTaskList.size() > 0;
/*     */     }
/* 107 */     if (getState() != 3) {
/* 108 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_synProcess") + getTaskTemplate().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_excuteCompleteState") + getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_checkProcessConfig"));
/*     */     }
/*     */ 
/* 111 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */   public Object executeWorkflow() throws Exception {
/* 115 */     if (getState() != 2) {
/* 116 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_stateIS") + getState() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_notExcute"));
/*     */     }
/* 118 */     this.nowScheduleTask = null;
/*     */ 
/* 120 */     List finishTaskList = new ArrayList();
/* 121 */     boolean hasExecuteTask = false;
/*     */ 
/* 123 */     for (int i = this.m_currentTasks.size() - 1; i >= 0; --i) {
/* 124 */       this.nowScheduleTask = ((Task)this.m_currentTasks.get(i));
/* 125 */       int tmpState = this.nowScheduleTask.getState();
/* 126 */       if (tmpState == 2)
/*     */       {
/* 128 */         this.nowScheduleTask.execute(this.workflowContext);
/*     */ 
/* 130 */         tmpState = this.nowScheduleTask.getState();
/* 131 */         hasExecuteTask = true;
/*     */       }
/*     */ 
/* 134 */       if ((tmpState == 7) || (tmpState == 5) || (tmpState == 9)) continue; if (tmpState == 10) {
/*     */         continue;
/*     */       }
/* 137 */       if ((tmpState == 3) || (tmpState == 21) || (tmpState == 4) || (tmpState == 98) || (tmpState == 6))
/*     */       {
/* 139 */         this.m_currentTasks.remove(i);
/* 140 */         this.m_historyTasks.add(this.nowScheduleTask);
/* 141 */         finishTaskList.add(this.nowScheduleTask);
/* 142 */       } else if (tmpState == 11) {
/* 143 */         this.m_currentTasks.remove(i);
/* 144 */         this.m_historyTasks.add(this.nowScheduleTask);
/* 145 */         finishTaskList.add(this.nowScheduleTask);
/* 146 */       } else if (tmpState == 8) {
/* 147 */         this.m_currentTasks.remove(i);
/* 148 */         this.nowScheduleTask.setIsCurrentTask(false);
/* 149 */         this.m_historyTasks.add(this.nowScheduleTask);
/*     */       } else {
/* 151 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_taskStateException"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 156 */     FlowFactory.save(this);
/* 157 */     return finishTaskList;
/*     */   }
/*     */ 
/*     */   public void excuteFinishTask(List finishTaskList)
/*     */     throws Exception
/*     */   {
/* 167 */     if ((finishTaskList == null) || (finishTaskList.size() == 0) || (getState() == 3))
/* 168 */       return;
/* 169 */     this.nowScheduleTask = null;
/*     */ 
/* 172 */     for (int i = 0; i < finishTaskList.size(); ++i) {
/* 173 */       this.nowScheduleTask = ((Task)finishTaskList.get(i));
/* 174 */       dealTask(this.nowScheduleTask);
/* 175 */       this.nowScheduleTask.setIsCurrentTask(false);
/*     */     }
/* 177 */     if ((this.m_currentTasks.size() == 0) && (getState() != 3)) {
/* 178 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_sysException") + getWorkflowId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.executeWorkflowSyn_noEndNoTask"));
/*     */     }
/*     */ 
/* 185 */     FlowFactory.save(this);
/*     */   }
/*     */ 
/*     */   public boolean busiExceptionProcess(ComframeBusiException ex) throws Exception {
/* 189 */     boolean addFinsh = true;
/* 190 */     if (getState() == 3) {
/* 191 */       updateState(2, "");
/*     */     }
/* 193 */     this.workflowContext.remvoe("$TASK_EXCEPTION_CODE");
/* 194 */     this.workflowContext.remvoe("$TASK_EXCEPTION_MSG");
/* 195 */     Task task = getNowScheduleTask();
/*     */ 
/* 197 */     if (hasExceptionCondition(task) == true) {
/* 198 */       this.m_currentTasks.remove(task);
/* 199 */       task.updateState(11, ex.toString());
/* 200 */       this.m_historyTasks.add(task);
/*     */ 
/* 203 */       this.workflowContext.set("$TASK_EXCEPTION_CODE", ex.getCode());
/* 204 */       this.workflowContext.set("$TASK_EXCEPTION_MSG", ex.getMessage());
/*     */     }
/*     */     else {
/* 207 */       fireBusinessExceptionIndependence(task, PropertiesUtil.getSystemUserId(), ex);
/* 208 */       addFinsh = false;
/*     */     }
/* 210 */     return addFinsh;
/*     */   }
/*     */ 
/*     */   public void fireExceptionIndependence(String staffId, String reason)
/*     */     throws Exception
/*     */   {
/* 221 */     BOVmWFBean bean = new BOVmWFBean();
/* 222 */     bean.initWorkflowId(getWorkflowId());
/* 223 */     bean.setQueueId(IDAssembleUtil.unwrapPrefix(getWorkflowId()));
/*     */ 
/* 225 */     int retryCount = PropertiesUtil.getRetryCount();
/* 226 */     if ((retryCount <= 0) || (retryCount <= getErrorCount() + 1))
/*     */     {
/* 229 */       setIsNeedRetry(false);
/* 230 */       bean.setState(99);
/* 231 */       bean.setErrorCount(getErrorCount() + 1);
/* 232 */       updateState(99, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.fireExceptionIndependence_scheduleTimesFull:") + retryCount + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.fireExceptionIndependence_setProcessException"));
/*     */     } else {
/* 234 */       setIsNeedRetry(true);
/* 235 */       bean.setErrorCount(getErrorCount() + 1);
/*     */     }
/* 237 */     bean.setErrorMessage(reason);
/* 238 */     bean.setStateDate(TimeUtil.getSysTime());
/* 239 */     bean.setOpStaffId(staffId);
/* 240 */     FlowFactory.save(bean);
/*     */   }
/*     */ 
/*     */   public void fireBusinessExceptionIndependence(Task task, String staffId, ComframeBusiException ex) throws Exception {
/* 244 */     BusiExceptionDeal.dealException(getWorkflowId(), new BOVmTaskBean[] { (BOVmTaskBean)task.getDataBean() }, ex.getCode(), ex.getMessage());
/*     */ 
/* 246 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 247 */     taskBean.initTaskId(task.getTaskId());
/* 248 */     taskBean.initQueueId(IDAssembleUtil.unwrapPrefix(task.getTaskId()));
/* 249 */     taskBean.setState(98);
/* 250 */     taskBean.setErrorMessage(ex.getCode() + ":" + ex.getMessage());
/* 251 */     taskBean.setStateDate(TimeUtil.getSysTime());
/* 252 */     taskBean.setFinishStaffId(PropertiesUtil.getSystemUserId());
/* 253 */     FlowFactory.save(taskBean);
/*     */ 
/* 255 */     BOVmWFBean workflow = new BOVmWFBean();
/* 256 */     workflow.initWorkflowId(getWorkflowId());
/* 257 */     workflow.initQueueId(IDAssembleUtil.unwrapPrefix(getWorkflowId()));
/* 258 */     workflow.setState(98);
/* 259 */     workflow.setStateDate(TimeUtil.getSysTime());
/* 260 */     workflow.setOpStaffId(staffId);
/* 261 */     workflow.setErrorMessage(ex.getCode() + ":" + ex.getMessage());
/* 262 */     FlowFactory.save(workflow);
/*     */ 
/* 264 */     task.updateState(98, ex.getCode() + ":" + ex.getMessage());
/* 265 */     updateState(98, ex.getCode() + ":" + ex.getMessage());
/*     */   }
/*     */ 
/*     */   public void jumpToTask(Task task, long taskTemplateId, String staffId, String notes)
/*     */     throws Exception
/*     */   {
/* 273 */     if (log.isDebugEnabled())
/* 274 */       log.debug("jump to task..destTaskTemplateId:" + taskTemplateId + "...current task id:" + task.getTaskId());
/* 275 */     TaskTemplate ct = task.getTaskTemplate();
/* 276 */     if (ct instanceof TaskWorkflowTemplate) {
/* 277 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_childcannotJump"));
/*     */     }
/* 279 */     if (ct instanceof TaskSignTemplate) {
/* 280 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_nodCannotJump"));
/*     */     }
/* 282 */     TaskTemplate backTaskTemplate = getWorkflowTemplate().getTaskTemplate(taskTemplateId);
/* 283 */     if (backTaskTemplate == null) {
/* 284 */       throw new Exception(getWorkflowTemplate().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_cannotFindID") + taskTemplateId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_taskModel"));
/*     */     }
/*     */ 
/* 287 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 288 */     taskBean.initTaskId(task.getTaskId());
/* 289 */     taskBean.setQueueId(IDAssembleUtil.unwrapPrefix(task.getTaskId()));
/* 290 */     taskBean.setState(6);
/* 291 */     taskBean.setErrorMessage(notes);
/* 292 */     taskBean.setExeFinishDate(taskBean.getStateDate());
/* 293 */     taskBean.setStateDate(TimeUtil.getSysTime());
/* 294 */     taskBean.setFinishStaffId(staffId);
/* 295 */     taskBean.setFinishDate(TimeUtil.getSysTime());
/* 296 */     taskBean.setDestType("J");
/* 297 */     taskBean.setDestTaskTemplateId(taskTemplateId);
/*     */ 
/* 299 */     FlowFactory.save(taskBean);
/*     */ 
/* 309 */     if (getErrorCount() > 0) {
/* 310 */       setErrorCount(0L);
/* 311 */       setReason("");
/* 312 */       updateState(2, "");
/*     */     }
/* 314 */     FlowFactory.save(this);
/*     */ 
/* 316 */     TaskTimerImpl.deleteTimerRecord(task.getTaskId());
/*     */   }
/*     */ 
/*     */   public void goBackTask(Task task, long taskTemplateId, String staffId, String notes)
/*     */     throws Exception
/*     */   {
/* 322 */     if (task.getTaskTemplateId() == taskTemplateId) {
/* 323 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_notBackToSelf"));
/*     */     }
/*     */ 
/* 326 */     TaskTemplate ct = task.getTaskTemplate();
/*     */ 
/* 328 */     if (ct instanceof TaskStartTemplate) {
/* 329 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_currNotStartNode"));
/*     */     }
/* 331 */     if (ct instanceof TaskSignTemplate) {
/* 332 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_notBackHuiqian"));
/*     */     }
/*     */ 
/* 335 */     IBOVmTaskValue[] tasks = FlowFactory.getTaskBeansByWorkflowId(getWorkflowId(), false);
/*     */ 
/* 337 */     IBOVmTaskValue currentTaskBean = null;
/* 338 */     for (int i = 0; i < tasks.length; ++i) {
/* 339 */       if (tasks[i].getTaskId().equals(task.getTaskId())) {
/* 340 */         currentTaskBean = tasks[i];
/* 341 */         break;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 346 */     if (!judgePreorder(currentTaskBean, taskTemplateId, tasks)) {
/* 347 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_nodenotTaskPre"));
/*     */     }
/*     */ 
/* 352 */     if (isContainFork(currentTaskBean, taskTemplateId, tasks) == true) {
/* 353 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_inForknotBack"));
/*     */     }
/*     */ 
/* 356 */     WorkflowTemplate temp = getWorkflowTemplate();
/* 357 */     TaskTemplate destinationTemlate = temp.getTaskTemplate(taskTemplateId);
/* 358 */     _goback(tasks, task, currentTaskBean, taskTemplateId, destinationTemlate, staffId, notes);
/*     */ 
/* 360 */     TaskTimerImpl.deleteTimerRecord(task.getTaskId());
/*     */   }
/*     */ 
/*     */   private void _goback(IBOVmTaskValue[] allTasks, Task currentTask, IBOVmTaskValue currentTaskBean, long destTaskTemplateId, TaskTemplate destTemlate, String staffId, String notes) throws Exception
/*     */   {
/* 365 */     if (log.isDebugEnabled()) {
/* 366 */       log.debug("task go back..destTaskTemplateId:" + destTaskTemplateId + "...current task id:" + currentTask.getTaskId());
/*     */     }
/* 368 */     List backedTasks = new ArrayList();
/* 369 */     exeRevertDeal(currentTaskBean, allTasks, destTaskTemplateId, getWorkflowContext(), backedTasks, notes, staffId);
/*     */ 
/* 372 */     BOVmTaskBean taskBean = new BOVmTaskBean();
/* 373 */     taskBean.initTaskId(currentTask.getTaskId());
/* 374 */     taskBean.setQueueId(IDAssembleUtil.unwrapPrefix(currentTask.getTaskId()));
/* 375 */     taskBean.setState(6);
/* 376 */     taskBean.setErrorMessage(notes);
/* 377 */     taskBean.setExeFinishDate(taskBean.getStateDate());
/* 378 */     taskBean.setStateDate(TimeUtil.getSysTime());
/* 379 */     taskBean.setFinishDate(TimeUtil.getSysTime());
/* 380 */     taskBean.setFinishStaffId(staffId);
/*     */ 
/* 382 */     taskBean.setDestType("B");
/* 383 */     taskBean.setDestTaskTemplateId(destTaskTemplateId);
/* 384 */     FlowFactory.save(taskBean);
/*     */ 
/* 423 */     if (getErrorCount() > 0) {
/* 424 */       setErrorCount(0L);
/* 425 */       setReason("");
/* 426 */       updateState(2, "");
/*     */     }
/* 428 */     FlowFactory.save(this);
/*     */   }
/*     */ 
/*     */   private void goBackWorkflowVars(TaskTemplate destTemlate, String taskStaffId, String stationid)
/*     */     throws Exception
/*     */   {
/* 434 */     if ((StringUtils.isEmptyString(taskStaffId)) && (StringUtils.isEmptyString(stationid)))
/* 435 */       return;
/* 436 */     Element element = destTemlate.getElement().element("user");
/* 437 */     if (element == null)
/* 438 */       return;
/* 439 */     String taskUserType = element.attributeValue("taskusertype");
/* 440 */     String taskUserTypeVal = "";
/* 441 */     String taskUserId = element.attributeValue("taskuserid");
/* 442 */     String taskUserIdVal = "";
/*     */ 
/* 445 */     log.info("Rollback processing, determine the employees or the fall back position. GOBACK_FLAG：" + this.GOBACK_FLAG + ",taskStaffId:" + taskStaffId + ",stationid:" + stationid);
/* 446 */     if (("staff".equals(this.GOBACK_FLAG)) && (!StringUtils.isEmptyString(taskStaffId)))
/*     */     {
/* 448 */       taskUserTypeVal = "staff";
/* 449 */       taskUserIdVal = taskStaffId;
/*     */     }
/* 451 */     else if (("station".equals(this.GOBACK_FLAG)) && (!StringUtils.isEmptyString(stationid)))
/*     */     {
/* 453 */       taskUserTypeVal = "station";
/* 454 */       taskUserIdVal = stationid;
/*     */     }
/* 456 */     else if (!StringUtils.isEmptyString(taskStaffId))
/*     */     {
/* 458 */       taskUserTypeVal = "staff";
/* 459 */       taskUserIdVal = taskStaffId;
/*     */     }
/*     */     else
/*     */     {
/* 463 */       taskUserTypeVal = "station";
/* 464 */       taskUserIdVal = stationid;
/*     */     }
/*     */ 
/* 467 */     if ((!StringUtils.isEmptyString(taskUserType)) && (taskUserType.charAt(0) == ':'))
/*     */     {
/* 469 */       taskUserType = taskUserType.substring(1);
/* 470 */       getWorkflowContext().set(taskUserType, taskUserTypeVal);
/*     */     }
/* 472 */     if ((StringUtils.isEmptyString(taskUserId)) || (taskUserId.charAt(0) != ':'))
/*     */       return;
/* 474 */     taskUserId = taskUserId.substring(1);
/* 475 */     getWorkflowContext().set(taskUserId, taskUserIdVal);
/*     */   }
/*     */ 
/*     */   private boolean judgePreorder(IBOVmTaskValue task, long taskTemplateId, IBOVmTaskValue[] allTasks)
/*     */     throws Exception
/*     */   {
/* 481 */     if (StringUtils.isEmptyString(task.getLastTaskId())) {
/* 482 */       return false;
/*     */     }
/* 484 */     String[] lastTaskIds = task.getLastTaskId().split(",");
/*     */ 
/* 486 */     for (int i = 0; i < lastTaskIds.length; ++i) {
/* 487 */       for (int j = 0; j < allTasks.length; ++j) {
/* 488 */         if (allTasks[j].getTaskId().equals(lastTaskIds[i])) {
/* 489 */           if (allTasks[j].getTaskTemplateId() == taskTemplateId) {
/* 490 */             return true;
/*     */           }
/* 492 */           if (judgePreorder(allTasks[j], taskTemplateId, allTasks) == true) {
/* 493 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 498 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean isContainFork(IBOVmTaskValue task, long taskTemplateId, IBOVmTaskValue[] allTasks) throws Exception
/*     */   {
/* 503 */     if (StringUtils.isEmptyString(task.getLastTaskId())) {
/* 504 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_lastTaskIDEmpty"));
/*     */     }
/* 506 */     String[] lastTaskIds = task.getLastTaskId().split(",");
/* 507 */     String lastTaskId = lastTaskIds[0];
/* 508 */     int countFork = 0;
/* 509 */     String lastType = "fork";
/* 510 */     long tempId = 0L;
/* 511 */     while (tempId != taskTemplateId) {
/* 512 */       for (int j = 0; j < allTasks.length; ++j) {
/* 513 */         if (allTasks[j].getTaskId().equals(lastTaskId)) {
/* 514 */           if (allTasks[j].getTaskType().equalsIgnoreCase("fork")) {
/* 515 */             ++countFork;
/* 516 */             lastType = allTasks[j].getTaskType();
/*     */           }
/* 518 */           else if ((allTasks[j].getTaskType().equalsIgnoreCase("and")) || (allTasks[j].getTaskType().equalsIgnoreCase("or")))
/*     */           {
/* 520 */             --countFork;
/* 521 */             lastType = allTasks[j].getTaskType();
/*     */           }
/*     */ 
/* 524 */           tempId = allTasks[j].getTaskTemplateId();
/* 525 */           if (tempId != taskTemplateId) {
/* 526 */             if (StringUtils.isEmptyString(allTasks[j].getLastTaskId())) {
/* 527 */               String type = TaskConfig.getInstance().getBasalType(allTasks[j].getTaskType());
/* 528 */               if (type.equalsIgnoreCase("start")) {
/* 529 */                 return true;
/*     */               }
/* 531 */               throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_lastTaskIDEmpty"));
/*     */             }
/* 533 */             lastTaskIds = allTasks[j].getLastTaskId().split(",");
/* 534 */             lastTaskId = lastTaskIds[0];
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 543 */     return (countFork != 0) || ((countFork == 0) && (!lastType.equalsIgnoreCase("fork")));
/*     */   }
/*     */ 
/*     */   private void exeRevertDeal(IBOVmTaskValue currentTask, IBOVmTaskValue[] tasks, long taskTemplateId, WorkflowContext context, List backedTasks, String notes, String staffId)
/*     */     throws Exception
/*     */   {
/* 551 */     String lastTaskIds = currentTask.getLastTaskId();
/* 552 */     if (StringUtils.isEmptyString(lastTaskIds) == true) {
/* 553 */       return;
/*     */     }
/* 555 */     String[] taskIds = StringUtils.splitString(lastTaskIds, ",");
/*     */ 
/* 557 */     for (int i = 0; i < taskIds.length; ++i) {
/* 558 */       String taskId = taskIds[i];
/*     */ 
/* 560 */       if (backedTasks.contains(taskId)) {
/* 561 */         return;
/*     */       }
/*     */ 
/* 564 */       long lastTemplateId = 0L;
/* 565 */       IBOVmTaskValue lastTask = null;
/* 566 */       for (int j = 0; j < tasks.length; ++j) {
/* 567 */         if (tasks[j].getTaskId().equals(taskId)) {
/* 568 */           lastTemplateId = tasks[j].getTaskTemplateId();
/* 569 */           lastTask = tasks[j];
/* 570 */           break;
/*     */         }
/*     */       }
/* 573 */       if (lastTemplateId == 0L) {
/* 574 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.exeRevertDeal_cannotFindTask") + currentTask.getTaskId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.exeRevertDeal_upperTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.exeRevertDeal_modelID"));
/*     */       }
/*     */ 
/* 578 */       TaskTemplate backTaskTemplate = getWorkflowTemplate().getTaskTemplate(lastTemplateId);
/*     */ 
/* 580 */       if (backTaskTemplate == null) {
/* 581 */         throw new Exception(getWorkflowTemplate().getTaskTag() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_cannotFindID") + taskTemplateId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.jumpToTask_taskModel"));
/*     */       }
/*     */ 
/* 586 */       BOVmTaskBean taskBean = new BOVmTaskBean();
/* 587 */       taskBean.initTaskId(taskId);
/* 588 */       taskBean.setQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 589 */       taskBean.setState(6);
/* 590 */       taskBean.setErrorMessage(notes);
/* 591 */       taskBean.setStateDate(TimeUtil.getSysTime());
/* 592 */       currentTask.setFinishStaffId(staffId);
/* 593 */       currentTask.setIsCurrentTask("N");
/* 594 */       FlowFactory.save(taskBean);
/*     */ 
/* 596 */       if (backTaskTemplate instanceof TaskUserTemplate) {
/* 597 */         if (((TaskUserTemplate)backTaskTemplate).getRevertDealBean() != null) {
/* 598 */           ((TaskUserImpl)getTask(taskId)); TaskUserImpl.executeDealInner(getTask(taskId), context, ((TaskUserTemplate)backTaskTemplate).getRevertDealBean());
/*     */ 
/* 601 */           WorkflowEngineFactory.getInstance().dealTransTaskDown(taskId, getWorkflowId(), 6);
/*     */         }
/*     */       }
/* 604 */       else if (backTaskTemplate instanceof TaskWorkflowTemplate) {
/* 605 */         if (((TaskWorkflowTemplate)backTaskTemplate).getRevertDealBean() != null) {
/* 606 */           ((TaskWorkflowImpl)getTask(taskId)); TaskWorkflowImpl.executeDealInner(getTask(taskId), context, ((TaskWorkflowTemplate)backTaskTemplate).getRevertDealBean());
/*     */         }
/*     */ 
/*     */       }
/* 611 */       else if ((backTaskTemplate instanceof TaskAutoTemplate) && 
/* 612 */         (((TaskAutoTemplate)backTaskTemplate).getRevertDealBean() != null)) {
/* 613 */         ((TaskAutoImpl)getTask(taskId)); TaskAutoImpl.executeDealInner(getTask(taskId), context, ((TaskAutoTemplate)backTaskTemplate).getRevertDealBean());
/*     */       }
/*     */ 
/* 619 */       backedTasks.add(lastTask.getTaskId());
/*     */ 
/* 622 */       if (lastTemplateId == taskTemplateId) {
/* 623 */         return;
/*     */       }
/* 625 */       exeRevertDeal(lastTask, tasks, taskTemplateId, context, backedTasks, notes, staffId);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void goBackTask(Task task, String staffId, String notes)
/*     */     throws Exception
/*     */   {
/* 633 */     TaskTemplate ct = task.getTaskTemplate();
/* 634 */     if ((!ct instanceof TaskUserTemplate) || (ct instanceof TaskSignTemplate)) {
/* 635 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_onlyHandle"));
/*     */     }
/*     */ 
/* 638 */     IBOVmTaskValue[] tasks = FlowFactory.getTaskBeansByWorkflowId(getWorkflowId(), false);
/*     */ 
/* 640 */     IBOVmTaskValue currentTaskBean = null;
/* 641 */     for (int i = 0; i < tasks.length; ++i) {
/* 642 */       if (tasks[i].getTaskId().equals(task.getTaskId())) {
/* 643 */         currentTaskBean = tasks[i];
/* 644 */         break;
/*     */       }
/*     */     }
/* 647 */     if (currentTaskBean == null)
/*     */     {
/* 649 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.vm.engine.impl.WorkflowImpl_notFindTaskIns"));
/*     */     }
/* 651 */     TaskTemplate lastUserTask = null;
/*     */ 
/* 654 */     String lastTaskId = currentTaskBean.getLastTaskId();
/* 655 */     if (StringUtils.isEmptyString(lastTaskId)) {
/* 656 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_cannotFindTaskHandle"));
/*     */     }
/* 658 */     while (!StringUtils.isEmptyString(lastTaskId)) {
/* 659 */       String[] lastTaskIds = lastTaskId.split(",");
/* 660 */       String taskId = lastTaskIds[0];
/* 661 */       IBOVmTaskValue tmp = null;
/* 662 */       for (int i = 0; i < tasks.length; ++i) {
/* 663 */         if (tasks[i].getTaskId().equals(taskId)) {
/* 664 */           tmp = tasks[i];
/*     */         }
/*     */       }
/* 667 */       if (tmp == null) {
/* 668 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_cannotFindUpperTask"));
/*     */       }
/*     */ 
/* 671 */       TaskTemplate tt = getWorkflowTemplate().getTaskTemplate(tmp.getTaskTemplateId());
/* 672 */       if ((tt instanceof TaskUserTemplate) && 
/* 673 */         (!isContainFork(currentTaskBean, tmp.getTaskTemplateId(), tasks))) {
/* 674 */         lastUserTask = tt;
/* 675 */         break;
/*     */       }
/*     */ 
/* 678 */       lastTaskId = tmp.getLastTaskId();
/*     */     }
/*     */ 
/* 681 */     if (lastUserTask == null) {
/* 682 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.WorkflowImpl.goBackTask_cannotFindTaskHandle"));
/*     */     }
/*     */ 
/* 686 */     long taskTemplateId = lastUserTask.getTaskTemplateId();
/* 687 */     _goback(tasks, task, currentTaskBean, taskTemplateId, lastUserTask, staffId, notes);
/*     */ 
/* 690 */     TaskTimerImpl.deleteTimerRecord(task.getTaskId());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.WorkflowImpl
 * JD-Core Version:    0.5.4
 */