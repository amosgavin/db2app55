package com.ai.comframe.vm.engine;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.comframe.vm.template.TaskTemplate;
import java.io.Serializable;
import java.sql.Date;

public abstract interface Task extends Serializable
{
  public static final int S_STATE_DISABLED = 1;
  public static final int S_STATE_ENABLED = 2;
  public static final int S_STATE_WAIT = 7;
  public static final int S_STATE_ACTIVE = 5;
  public static final int S_STATE_WAIT_PRINT = 9;
  public static final int S_STATE_BACK = 6;
  public static final int S_STATE_FINISHED = 3;
  public static final int S_STATE_TERMINATE = 4;
  public static final int S_STATE_REAUTHORIZE = 10;
  public static final int S_STATE_ABEND = 11;
  public static final int S_STATE_BUSIEXCEPTION = 98;
  public static final int S_STATE_EXCEPTION = 99;
  public static final int S_STATE_WAIT_EXCEPTION_FINISH = 97;
  public static final int S_STATE_EXPIRED = 8;
  public static final int S_STATE_WAIT_CREATE_SCHEDULE_INSTANCE = 20;
  public static final int S_STATE_HAS_FINISH_SCHEDULESERVER_TASK = 21;
  public static final int WORKFLOW_MONITOR_CREATE = 11;
  public static final int WORKFLOW_MONITOR_FINISH = 12;
  public static final int WORKFLOW_MONITOR_EXCEPTION = 13;
  public static final int TASK_MONITOR_CREATE = 1;
  public static final int TASK_MONITOR_ASSIGN = 2;
  public static final int TASK_MONITOR_PRINT = 3;
  public static final int TASK_MONITOR_FINISH = 4;
  public static final int TASK_MONITOR_EXCEPTION = 5;

  public abstract long getTaskTemplateId();

  public abstract String getTaskId();

  public abstract String getTaskType();

  public abstract String getTaskTag();

  public abstract String getEngineWorkflowId();

  public abstract String getEngineTaskId();

  public abstract TaskTemplate getTaskTemplate();

  public abstract FlowBase getWorkflow();

  public abstract void updateState(int paramInt, String paramString);

  public abstract String getLabel();

  public abstract int getState();

  public abstract Date getStateDate();

  public abstract String getReason();

  public abstract void setReason(String paramString);

  public abstract String getDuration();

  public abstract String getDestType();

  public abstract long getDestTaskTemplateId();

  public abstract boolean isCurrentTask()
    throws Exception;

  public abstract void setIsCurrentTask(boolean paramBoolean)
    throws Exception;

  public abstract Date getCreateDate();

  public abstract boolean isOverDuration();

  public abstract boolean isOverDuration(Date paramDate);

  public abstract Date getDuerationDate();

  public abstract Object execute(WorkflowContext paramWorkflowContext)
    throws Exception;

  public abstract DataContainerInterface getDataBean()
    throws Exception;

  public abstract void monitor(String paramString, Throwable paramThrowable, int paramInt);

  public abstract void terminate(String paramString1, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.Task
 * JD-Core Version:    0.5.4
 */