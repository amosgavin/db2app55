/*    */ package com.ai.comframe.vm.engine;
/*    */ 
/*    */ import com.ai.appframe2.express.Operation;
/*    */ import com.ai.appframe2.express.OperatorManager;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ 
/*    */ public class WorkflowExpress extends Operation
/*    */ {
/*    */   FlowBase workflow;
/*    */ 
/*    */   public WorkflowExpress(FlowBase aWorkflow)
/*    */   {
/*  9 */     super(new OperatorManager());
/* 10 */     this.workflow = aWorkflow;
/*    */   }
/*    */ 
/*    */   public Object getParameterValue(String name)
/*    */     throws Exception
/*    */   {
/* 17 */     return this.workflow.getWorkflowContext().get(name);
/*    */   }
/*    */ 
/*    */   public Object getAttrValue(String name)
/*    */     throws Exception
/*    */   {
/* 24 */     return this.workflow.getWorkflowContext().get(name);
/*    */   }
/*    */   public void setParameterValue(String name, Object object) throws Exception {
/* 27 */     this.workflow.getWorkflowContext().set(name, object);
/*    */   }
/*    */   public void setAttrValue(String name, Object object) throws Exception {
/* 30 */     this.workflow.getWorkflowContext().set(name, object);
/*    */   }
/*    */ 
/*    */   public Class getAttrValueClassType(String name) throws Exception {
/* 34 */     return this.workflow.getWorkflowTemplate().getVars(name).getDataTypeClass();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.WorkflowExpress
 * JD-Core Version:    0.5.4
 */