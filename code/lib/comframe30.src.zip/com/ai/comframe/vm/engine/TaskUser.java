package com.ai.comframe.vm.engine;

public abstract interface TaskUser extends Task
{
  public static final char TASK_RESULT_SUCESS = 'S';
  public static final char TASK_RESULT_FAIL = 'F';
  public static final char TASK_RESULT_PAUSE = 'P';
  public static final char TASK_RESULT_DELETE = 'D';

  public abstract void finish(String paramString1, String paramString2, String paramString3, WorkflowContext paramWorkflowContext)
    throws Exception;

  public abstract void finishOverTime(String paramString1, String paramString2, String paramString3, WorkflowContext paramWorkflowContext)
    throws Exception;

  public abstract boolean print(String paramString, WorkflowContext paramWorkflowContext)
    throws Exception;

  public abstract String reAuthorize(String paramString1, String paramString2, String paramString3)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskUser
 * JD-Core Version:    0.5.4
 */