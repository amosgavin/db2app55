package com.ai.comframe.vm.engine;

public abstract interface WorkflowContext extends TaskContext
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.WorkflowContext
 * JD-Core Version:    0.5.4
 */