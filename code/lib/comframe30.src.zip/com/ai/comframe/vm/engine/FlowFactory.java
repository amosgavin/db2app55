/*     */ package com.ai.comframe.vm.engine;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.ComframeWorkflowFactory;
/*     */ import com.ai.comframe.client.service.interfaces.IComframeCallBusiDefaultSV;
/*     */ import com.ai.comframe.config.ivalues.IBOVmExceptionCodeValue;
/*     */ import com.ai.comframe.config.service.interfaces.IExceptionConfigSV;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.Constant;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.engine.impl.ProcessflowImpl;
/*     */ import com.ai.comframe.vm.engine.impl.WorkflowImpl;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOHVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmTaskBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFAttrBean;
/*     */ import com.ai.comframe.vm.workflow.bo.BOVmWFBean;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskTSValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class FlowFactory
/*     */ {
/*     */   public static void save(FlowBase workflow)
/*     */     throws Exception
/*     */   {
/*  45 */     saveFlowBase(workflow);
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmTaskValue task) throws Exception {
/*  49 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  50 */     taskDAO.saveVmtaskInstacne(task);
/*     */   }
/*     */ 
/*     */   public static void save(IBOVmWFValue workflow) throws Exception
/*     */   {
/*  55 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  56 */     workflowDAO.saveVmWorkflowInstacne(workflow);
/*     */ 
/*  59 */     if (((workflow.getWorkflowKind() == 1) && (workflow.getParentTaskId() != null) && (!"-1".equals(workflow.getParentTaskId()))) || (workflow.getWorkflowKind() == 2))
/*     */     {
/*  62 */       return;
/*     */     }
/*     */ 
/*  65 */     _move2His(workflow.getWorkflowId(), workflow.getState(), workflow.getFinishDate());
/*     */   }
/*     */ 
/*     */   public static void saveFlowBase(FlowBase workflow) throws Exception
/*     */   {
/*  70 */     workflow.fillBack();
/*  71 */     DataContainerInterface[] taskdatas = workflow.getTaskBeans();
/*  72 */     DataContainerInterface workflowdata = workflow.getDataBean();
/*     */ 
/*  74 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  75 */     BOVmWFBean workflowbean = new BOVmWFBean();
/*  76 */     workflowbean.copy(workflowdata);
/*  77 */     workflowDAO.saveVmWorkflowInstacne(workflowbean);
/*  78 */     saveVmWorkflowAttr(workflow);
/*     */ 
/*  80 */     for (int i = 0; i < taskdatas.length; ++i) {
/*  81 */       IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*  82 */       BOVmTaskBean taskbean = new BOVmTaskBean();
/*  83 */       taskbean.copy(taskdatas[i]);
/*  84 */       taskDAO.saveVmtaskInstacne(taskbean);
/*  85 */       taskdatas[i].setStsToOld();
/*     */     }
/*     */ 
/*  88 */     if (((workflow.getWorkflowKind() == 1) && (workflow.getParentTaskId() != null) && (!"-1".equals(workflow.getParentTaskId()))) || (workflow.getWorkflowKind() == 2))
/*     */     {
/*  91 */       return;
/*     */     }
/*  93 */     _move2His(workflow.getWorkflowId(), workflow.getState(), workflowbean.getFinishDate());
/*     */   }
/*     */ 
/*     */   private static void _move2His(String workflowId, int workflowState, Timestamp transferDate) throws Exception {
/*  97 */     boolean isHisState = false;
/*     */ 
/*  99 */     for (int i = 0; i < Constant.WORKFLOW_HIS_STATE.length; ++i) {
/* 100 */       if (workflowState == Constant.WORKFLOW_HIS_STATE[i]) {
/* 101 */         isHisState = true;
/* 102 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 106 */     if (!isHisState)
/*     */       return;
/* 108 */     List workflowIds = getAllChildWorkflows(workflowId);
/*     */ 
/* 110 */     if ((workflowIds != null) && (workflowIds.size() > 0)) {
/* 111 */       IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 112 */       IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/*     */ 
/* 114 */       for (int i = 0; i < workflowIds.size(); ++i) {
/* 115 */         String temp = (String)workflowIds.get(i);
/* 116 */         workflowDAO.workflowToHis(temp, transferDate);
/* 117 */         workflowDAO.workflowAttrToHis(temp, transferDate);
/* 118 */         taskDAO.taskToHis(temp, transferDate);
/* 119 */         taskDAO.taskTSToHis(temp, transferDate);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static List getAllChildWorkflows(String workflowId)
/*     */     throws Exception
/*     */   {
/* 134 */     List wfList = new ArrayList();
/* 135 */     wfList.add(workflowId);
/*     */ 
/* 137 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 138 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*     */ 
/* 141 */     IBOVmTaskValue[] tasks = taskDAO.getAllChildWorkflowTasks(workflowId);
/* 142 */     IBOVmWFValue[] wfValues = null;
/*     */ 
/* 144 */     IBOVmWFValue exwf = workflowDAO.getExceptionChildWorkflow(workflowId);
/* 145 */     if (exwf != null) {
/* 146 */       wfList.addAll(getAllChildWorkflows(exwf.getWorkflowId()));
/*     */     }
/*     */ 
/* 149 */     if ((tasks != null) && (tasks.length > 0)) {
/* 150 */       for (int i = 0; i < tasks.length; ++i)
/*     */       {
/* 152 */         wfValues = workflowDAO.getChildWorkflows(tasks[i].getTaskId());
/* 153 */         if (wfValues == null) continue; if (wfValues.length == 0) {
/*     */           continue;
/*     */         }
/*     */ 
/* 157 */         for (int j = 0; j < wfValues.length; ++j) {
/* 158 */           exwf = workflowDAO.getExceptionChildWorkflow(wfValues[j].getWorkflowId());
/* 159 */           if (exwf != null) {
/* 160 */             wfList.addAll(getAllChildWorkflows(exwf.getWorkflowId()));
/*     */           }
/* 162 */           wfList.addAll(getAllChildWorkflows(wfValues[j].getWorkflowId()));
/*     */         }
/*     */       }
/*     */     }
/* 166 */     return wfList;
/*     */   }
/*     */ 
/*     */   private static Collection getExceptionWorkflows(String workflowId) throws Exception {
/* 170 */     List wfList = new ArrayList();
/* 171 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 172 */     IBOVmWFValue exwf = workflowDAO.getExceptionChildWorkflow(workflowId);
/* 173 */     if (exwf != null) {
/* 174 */       wfList.addAll(getAllChildWorkflows(exwf.getWorkflowId()));
/*     */     }
/* 176 */     return wfList;
/*     */   }
/*     */ 
/*     */   public static WorkflowImpl reload(String workflowId)
/*     */     throws Exception
/*     */   {
/* 186 */     return reload(workflowId, false);
/*     */   }
/*     */   public static WorkflowImpl reload(String workflowId, boolean isSchedule) throws Exception {
/* 189 */     if (isSchedule == true) {
/* 190 */       return reloadForSchedule(workflowId);
/*     */     }
/* 192 */     return reloadForAll(workflowId);
/*     */   }
/*     */ 
/*     */   protected static WorkflowImpl reloadForSchedule(String workflowId) throws Exception {
/* 196 */     DataContainerInterface workflowBean = null;
/* 197 */     DataContainerInterface[] taskBeans = null;
/* 198 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 199 */     workflowBean = (BOVmWFBean)workflowDAO.getVmWorkflowBeanbyId(workflowId);
/* 200 */     if (workflowBean == null) {
/* 201 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.reloadForAll_notFoundProcessIns") + workflowId);
/*     */     }
/* 203 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 204 */     taskBeans = (BOVmTaskBean[])(BOVmTaskBean[])taskDAO.getVmTaskbeanByWorkflowId(workflowId);
/* 205 */     WorkflowTemplate aWorkflowTemplate = null;
/* 206 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 207 */     boolean publish = templateSV.isPublish(workflowBean.getAsString("TEMPLATE_TAG"));
/* 208 */     if (!publish)
/* 209 */       aWorkflowTemplate = templateSV.getWorkflowTemplateFromFile(workflowBean.getAsString("TEMPLATE_TAG"));
/*     */     else {
/* 211 */       aWorkflowTemplate = templateSV.getWorkflowTemplateByID(workflowBean.getAsLong("TEMPLATE_VERSION_ID"));
/*     */     }
/* 213 */     return new WorkflowImpl(aWorkflowTemplate, workflowBean, taskBeans);
/*     */   }
/*     */ 
/*     */   protected static WorkflowImpl reloadForAll(String workflowId)
/*     */     throws Exception
/*     */   {
/* 222 */     DataContainerInterface workflowBean = null;
/* 223 */     DataContainerInterface[] taskBeans = null;
/* 224 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 225 */     boolean isHis = false;
/* 226 */     workflowBean = (BOVmWFBean)workflowDAO.getVmWorkflowBeanbyId(workflowId);
/* 227 */     if (workflowBean != null) {
/* 228 */       isHis = false;
/*     */     } else {
/* 230 */       workflowBean = (BOHVmWFBean)workflowDAO.getHisVmWorkflowBeanbyId(workflowId);
/* 231 */       if (workflowBean == null)
/* 232 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.reloadForAll_notFoundProcessIns") + workflowId);
/* 233 */       isHis = true;
/*     */     }
/* 235 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 236 */     if (!isHis)
/* 237 */       taskBeans = (BOVmTaskBean[])(BOVmTaskBean[])taskDAO.getVmTaskbeanByWorkflowId(workflowId);
/*     */     else {
/* 239 */       taskBeans = (BOHVmTaskBean[])(BOHVmTaskBean[])taskDAO.getHVmTaskbeanByWorkflowId(workflowId);
/*     */     }
/* 241 */     WorkflowTemplate aWorkflowTemplate = null;
/* 242 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 243 */     boolean publish = templateSV.isPublish(workflowBean.getAsString("TEMPLATE_TAG"));
/* 244 */     if (!publish)
/* 245 */       aWorkflowTemplate = templateSV.getWorkflowTemplateFromFile(workflowBean.getAsString("TEMPLATE_TAG"));
/*     */     else {
/* 247 */       aWorkflowTemplate = templateSV.getWorkflowTemplateByID(workflowBean.getAsLong("TEMPLATE_VERSION_ID"));
/*     */     }
/* 249 */     return new WorkflowImpl(aWorkflowTemplate, workflowBean, taskBeans);
/*     */   }
/*     */ 
/*     */   public static WorkflowImpl reloadWorkflowHis(String workflowId, String acctPeriod) throws Exception {
/* 253 */     DataContainerInterface workflowBean = null;
/* 254 */     DataContainerInterface[] taskBeans = null;
/* 255 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 256 */     workflowBean = (BOHVmWFBean)workflowDAO.getHisVmWorkflowBeanbyId(workflowId, acctPeriod);
/* 257 */     if (workflowBean == null)
/* 258 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.FlowFactory.reloadForAll_notFoundProcessIns") + workflowId);
/* 259 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 260 */     taskBeans = (BOHVmTaskBean[])(BOHVmTaskBean[])taskDAO.getHVmTaskbeanByWorkflowId(workflowId, acctPeriod);
/* 261 */     WorkflowTemplate aWorkflowTemplate = null;
/* 262 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 263 */     boolean publish = templateSV.isPublish(workflowBean.getAsString("TEMPLATE_TAG"));
/* 264 */     if (!publish)
/* 265 */       aWorkflowTemplate = templateSV.getWorkflowTemplateFromFile(workflowBean.getAsString("TEMPLATE_TAG"));
/*     */     else {
/* 267 */       aWorkflowTemplate = templateSV.getWorkflowTemplateByID(workflowBean.getAsLong("TEMPLATE_VERSION_ID"));
/*     */     }
/* 269 */     return new WorkflowImpl(aWorkflowTemplate, workflowBean, taskBeans);
/*     */   }
/*     */ 
/*     */   public static Task createTask(FlowBase workflow, DataContainerInterface taskBean)
/*     */     throws Exception
/*     */   {
/* 275 */     long taskTemplateId = taskBean.getAsLong(TaskBaseImpl.S_TASK_TEMPLATE_ID);
/* 276 */     TaskTemplate aTaskTemplate = workflow.getWorkflowTemplate().getTaskTemplate(taskTemplateId);
/* 277 */     Class tmpClass = Class.forName(TaskConfig.getInstance().getExecuteClass(aTaskTemplate.getTaskType()));
/* 278 */     Constructor constructor = tmpClass.getConstructor(new Class[] { FlowBase.class, TaskTemplate.class, DataContainerInterface.class });
/*     */ 
/* 280 */     return (Task)constructor.newInstance(new Object[] { workflow, aTaskTemplate, taskBean });
/*     */   }
/*     */ 
/*     */   public static Task createTask(String aQueueId, FlowBase workflow, TaskTemplate aTaskTemplate) throws Exception {
/* 284 */     Class tmpClass = Class.forName(TaskConfig.getInstance().getExecuteClass(aTaskTemplate.getTaskType()));
/* 285 */     Constructor constructor = tmpClass.getConstructor(new Class[] { FlowBase.class, String.class, TaskTemplate.class, Integer.TYPE, Date.class, Date.class });
/*     */ 
/* 288 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 289 */     String taskId = taskDAO.getNewTaskId(aQueueId, workflow.getDistrictId());
/*     */ 
/* 291 */     return (Task)constructor.newInstance(new Object[] { workflow, taskId, aTaskTemplate, new Integer(2), new Date(TimeUtil.getSysTime().getTime()), new Date(TimeUtil.getSysTime().getTime()) });
/*     */   }
/*     */ 
/*     */   public static Processflow createProcess(String aQueueId, FlowBase parentFlow, String workflowCode, Map aVars)
/*     */     throws Exception
/*     */   {
/* 301 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 302 */     WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(workflowCode);
/* 303 */     return createProcess(aQueueId, parentFlow, template, aVars);
/*     */   }
/*     */ 
/*     */   public static Processflow createProcess(String aQueueId, FlowBase parentFlow, WorkflowTemplate aFlowTemplate, Map aVars) throws Exception {
/* 307 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 308 */     String workflowId = workflowDAO.getNewWorkFlowId(aQueueId, parentFlow.getDistrictId());
/* 309 */     Processflow flow = new ProcessflowImpl(aQueueId, parentFlow, workflowId, aFlowTemplate, aVars);
/* 310 */     return flow;
/*     */   }
/*     */ 
/*     */   public static Workflow createWorkflow(String aQueueId, String parentTaskId, String workflowCode, int isExceptionWorkflow, String staffId, String objectTypeId, String objectId, Map aVars)
/*     */     throws Exception
/*     */   {
/* 318 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 319 */     WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(workflowCode);
/* 320 */     return createWorkflow(aQueueId, parentTaskId, template, isExceptionWorkflow, staffId, objectTypeId, objectId, aVars);
/*     */   }
/*     */ 
/*     */   public static Workflow createWorkflow(String aQueueId, String parentTaskId, WorkflowTemplate template, int isExceptionWorkflow, String staffId, String objectTypeId, String objectId, Map aVars)
/*     */     throws Exception
/*     */   {
/* 327 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 328 */     String regionId = "";
/*     */ 
/* 330 */     if ((CenterFactory.isSetCenterInfo()) && (CenterFactory.getCenterInfo() != null))
/* 331 */       regionId = CenterFactory.getCenterInfo().getRegion();
/* 332 */     String workflowId = workflowDAO.getNewWorkFlowId(aQueueId, regionId);
/* 333 */     Workflow workflow = new WorkflowImpl(aQueueId, parentTaskId, workflowId, isExceptionWorkflow, template, aVars, 2, new Date(TimeUtil.getSysTime().getTime()), new Date(TimeUtil.getSysTime().getTime()), staffId, objectTypeId, objectId);
/*     */ 
/* 341 */     save(workflow);
/* 342 */     return workflow;
/*     */   }
/*     */ 
/*     */   public static IBOVmWFValue getWorkflowBean(String workflowId) throws Exception {
/* 346 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 347 */     IBOVmWFValue workflowbean = null;
/* 348 */     workflowbean = workflowDAO.getVmWorkflowBeanbyId(workflowId);
/* 349 */     return workflowbean;
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskValue getTaskBean(String taskId) throws Exception
/*     */   {
/* 354 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 355 */     IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(taskId);
/* 356 */     return taskBean;
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskValue[] getTaskBeansByWorkflowId(String workflowId, boolean isWorkflowFinished) throws Exception
/*     */   {
/* 361 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 362 */     IBOVmTaskValue[] taskBeans = null;
/* 363 */     if (!isWorkflowFinished)
/* 364 */       taskBeans = taskDAO.getVmTaskbeanByWorkflowId(workflowId);
/* 365 */     return taskBeans;
/*     */   }
/*     */ 
/*     */   public static String getStationId(String organizeId, String stationTypeId) throws Exception {
/* 369 */     return ComframeWorkflowFactory.getComframeCallBusiInstance().getStationIdByStationTypeIdAndOrgId(stationTypeId, organizeId);
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskTSValue getTaskTransBean(String taskId) throws Exception {
/* 373 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 374 */     IBOVmTaskTSValue taskBean = taskDAO.getVmTaskTransBeanById(taskId);
/* 375 */     return taskBean;
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskTSValue[] getTaskTransBeans(String workflowId, String parentTaskId) throws Exception {
/* 379 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 380 */     IBOVmTaskTSValue[] taskBeans = taskDAO.getVmTaskTransBeans(workflowId, parentTaskId);
/* 381 */     return taskBeans;
/*     */   }
/*     */ 
/*     */   public static void saveTaskTrans(IBOVmTaskTSValue task) throws Exception {
/* 385 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 386 */     taskDAO.saveVmtaskTransInstacne(task);
/*     */   }
/*     */ 
/*     */   public static void saveTaskTrans(IBOVmTaskTSValue[] tasks) throws Exception
/*     */   {
/* 391 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 392 */     taskDAO.saveVmtaskTransInstacnes(tasks);
/*     */   }
/*     */ 
/*     */   public static void saveVmWorkflowAttr(FlowBase workflow) throws Exception {
/* 396 */     if (!PropertiesUtil.isAttrRecord())
/* 397 */       return;
/* 398 */     Map vmVars = workflow.getWorkflowContext().getParameters();
/* 399 */     String workflowId = workflow.getWorkflowId();
/* 400 */     if ((vmVars.isEmpty()) || (workflowId == null)) {
/* 401 */       return;
/*     */     }
/* 403 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 404 */     IBOVmWFAttrValue[] attrBeans = workflowDAO.getVmWorkflowAttrsByWorkflowId(workflowId);
/* 405 */     if ((attrBeans != null) && (attrBeans.length > 0)) {
/* 406 */       for (int i = 0; i < attrBeans.length; ++i) {
/* 407 */         if (vmVars.containsKey(attrBeans[i].getAttrCode())) {
/* 408 */           String value = String.valueOf(vmVars.get(attrBeans[i].getAttrCode()));
/* 409 */           if ((!StringUtils.isEmptyString(value)) && 
/* 410 */             (value.length() > 90)) {
/* 411 */             value = value.substring(0, 90);
/*     */           }
/*     */ 
/* 414 */           attrBeans[i].setAttrValue(value);
/* 415 */           attrBeans[i].setCreateDate(TimeUtil.getSysTime());
/*     */         }
/*     */       }
/* 418 */       workflowDAO.saveVmWorkflowAttrBeans(attrBeans);
/*     */     } else {
/* 420 */       BOVmWFAttrBean[] attrs = new BOVmWFAttrBean[vmVars.size()];
/* 421 */       int i = 0;
/* 422 */       for (Iterator iter = vmVars.entrySet().iterator(); iter.hasNext(); ++i) {
/* 423 */         Map.Entry entry = (Map.Entry)iter.next();
/* 424 */         attrs[i] = new BOVmWFAttrBean();
/* 425 */         attrs[i].setQueueId(workflow.getQueueId());
/* 426 */         attrs[i].setWorkflowId(workflowId);
/* 427 */         attrs[i].setAttrCode(String.valueOf(entry.getKey()));
/* 428 */         String value = String.valueOf(entry.getValue());
/* 429 */         if ((!StringUtils.isEmptyString(value)) && 
/* 430 */           (value.length() > 90)) {
/* 431 */           value = value.substring(0, 90);
/*     */         }
/*     */ 
/* 434 */         attrs[i].setCreateDate(TimeUtil.getSysTime());
/* 435 */         attrs[i].setAttrValue(value);
/*     */       }
/* 437 */       workflowDAO.saveVmWorkflowAttrBeans(attrs);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static IBOVmTaskTSValue[] getTaskTransBeansParentOrWorkflowId(String parentTaskId, String workflowId) throws Exception
/*     */   {
/* 443 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 444 */     IBOVmTaskTSValue[] taskts = taskDAO.getTaskTransBeansParentOrWorkflowId(parentTaskId, workflowId);
/* 445 */     return taskts;
/*     */   }
/*     */ 
/*     */   public static String[][] getExceptionCode(String sqlStr, HashMap parameter)
/*     */     throws Exception
/*     */   {
/* 451 */     IExceptionConfigSV exConfigSV = (IExceptionConfigSV)ServiceFactory.getService(IExceptionConfigSV.class);
/* 452 */     IBOVmExceptionCodeValue[] exCodes = exConfigSV.getExceptionCodeValuesBySql(sqlStr, parameter);
/*     */ 
/* 454 */     String[][] result = new String[exCodes.length][2];
/*     */ 
/* 456 */     for (int i = 0; i < exCodes.length; ++i)
/*     */     {
/* 458 */       result[i][0] = exCodes[i].getExceptionCode();
/* 459 */       result[i][1] = exCodes[i].getExceptionName();
/*     */     }
/*     */ 
/* 462 */     return result;
/*     */   }
/*     */   public static void main(String[] args) throws Exception {
/* 465 */     List list = new ArrayList();
/* 466 */     IBOVmWFValue wf = new BOVmWFBean();
/* 467 */     wf.setWorkflowId("test");
/* 468 */     list.add(wf);
/* 469 */     wf = new BOVmWFBean();
/* 470 */     list.add(wf);
/* 471 */     System.out.println(((IBOVmWFValue)list.get(1)).getWorkflowId());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.FlowFactory
 * JD-Core Version:    0.5.4
 */