/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.VMDataType;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.TaskDecision;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.engine.WorkflowExpress;
/*    */ import com.ai.comframe.vm.template.TaskDecisionConditionTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TaskDecisionConditionImpl extends TaskBaseImpl
/*    */   implements TaskDecision
/*    */ {
/* 16 */   private static transient Log log = LogFactory.getLog(TaskDecisionConditionImpl.class);
/*    */ 
/* 18 */   protected static String S_DECISION_RESULT = "DECISION_RESULT";
/*    */ 
/*    */   public TaskDecisionConditionImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 23 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskDecisionConditionImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 28 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object getDecision()
/*    */   {
/* 35 */     return VMDataType.getAsString(this.m_dc.get(S_DECISION_RESULT));
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception {
/* 39 */     Object[] opList = ((TaskDecisionConditionTemplate)getTaskTemplate()).getOperatorList();
/* 40 */     if (opList == null) {
/* 41 */       synchronized (getTaskTemplate()) {
/* 42 */         opList = ((TaskDecisionConditionTemplate)getTaskTemplate()).getOperatorList();
/*    */ 
/* 44 */         if (opList == null) {
/* 45 */           String condition = ((TaskDecisionConditionTemplate)getTaskTemplate()).getCondition();
/*    */ 
/* 47 */           if ((condition == null) || (condition.length() == 0)) {
/* 48 */             opList = new Object[0];
/*    */           }
/*    */           else {
/* 51 */             opList = this.workflow.getWorkflowExpress().getOpObjectList(condition + ";");
/*    */           }
/*    */ 
/* 54 */           ((TaskDecisionConditionTemplate)getTaskTemplate()).setOperatorList(opList);
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 59 */     Object obj = null;
/* 60 */     if (opList.length == 0) {
/* 61 */       this.m_dc.set(S_DECISION_RESULT, Boolean.TRUE);
/* 62 */       context.set("_TASK_JUGE_RESULT", Boolean.TRUE);
/*    */     } else {
/* 64 */       obj = this.workflow.getWorkflowExpress().executeByCResult(opList);
/*    */ 
/* 66 */       this.m_dc.set(S_DECISION_RESULT, obj);
/* 67 */       context.set("_TASK_JUGE_RESULT", obj);
/*    */     }
/*    */ 
/* 73 */     log.debug("Determine conditions for the implementation of(Task" + getTaskTemplate().getLabel() + ")：" + ((TaskDecisionConditionTemplate)getTaskTemplate()).getCondition() + " Implementation of the results：" + obj);
/*    */ 
/* 78 */     updateState(3, ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete"));
/* 79 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskDecisionConditionImpl
 * JD-Core Version:    0.5.4
 */