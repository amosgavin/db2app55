/*     */ package com.ai.comframe.vm.engine.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import com.ai.comframe.vm.common.Constant;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.common.VMException;
/*     */ import com.ai.comframe.vm.common.VMUtil;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.Task;
/*     */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.processflow.ProcessEngine;
/*     */ import com.ai.comframe.vm.processflow.ProcessEngineFactory;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmTaskDAO;
/*     */ import com.ai.comframe.vm.workflow.dao.interfaces.IVmWorkflowDAO;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TaskWorkflowImpl extends TaskBaseImpl
/*     */   implements Task
/*     */ {
/*  41 */   private static transient Log log = LogFactory.getLog(TaskWorkflowImpl.class);
/*     */ 
/*     */   public TaskWorkflowImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*     */     throws Exception
/*     */   {
/*  46 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*     */   }
/*     */ 
/*     */   public TaskWorkflowImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*     */   {
/*  52 */     super(aWorkflow, aTaskTemplate, inBean);
/*     */   }
/*     */ 
/*     */   public void setChildWorkflowCount(long childWorkflowCount) {
/*  56 */     this.m_dc.set("CHILD_WORKFLOW_COUNT", new Long(childWorkflowCount));
/*     */   }
/*     */   public long getChildWorkflowCount() {
/*  59 */     return Long.parseLong(this.m_dc.get("CHILD_WORKFLOW_COUNT").toString());
/*     */   }
/*     */   public void setRemanentWorkflowCount(long value) {
/*  62 */     this.m_dc.set("REMANENT_WORKFLOW_COUNT", new Long(value));
/*     */   }
/*     */ 
/*     */   public static IBOVmWFValue[] getChildWorkflows(String workflowId) throws Exception {
/*  66 */     IVmWorkflowDAO wfDao = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/*  67 */     IBOVmWFValue[] childWfs = wfDao.getChildWorkflows(workflowId);
/*  68 */     return childWfs;
/*     */   }
/*     */ 
/*     */   public long getRemanentWorkflowCount() {
/*  72 */     return this.m_dc.getAsInt("REMANENT_WORKFLOW_COUNT");
/*     */   }
/*     */ 
/*     */   protected Object getLoopArray(WorkflowContext context)
/*     */     throws Exception
/*     */   {
/*  80 */     TaskDealBean dealBean = ((TaskWorkflowTemplate)getTaskTemplate()).getAutoDealBean();
/*     */ 
/*  82 */     Object result = null;
/*  83 */     if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/*  84 */       result = executeDealInner(this, context, ((TaskWorkflowTemplate)getTaskTemplate()).getAutoDealBean());
/*     */ 
/*  87 */       if (result == null)
/*  88 */         result = new Object[0];
/*     */     }
/*     */     else {
/*  91 */       result = new Object[] { null };
/*     */     }
/*  93 */     return result;
/*     */   }
/*     */ 
/*     */   public Object executeInner(WorkflowContext context) throws Exception {
/*  97 */     TaskWorkflowTemplate task = (TaskWorkflowTemplate)getTaskTemplate();
/*  98 */     int childCount = 0;
/*  99 */     Object loopObject = getLoopArray(context);
/* 100 */     if (loopObject instanceof List)
/* 101 */       childCount = ((List)loopObject).size();
/* 102 */     else if (loopObject.getClass().isArray())
/* 103 */       childCount = ((Object[])(Object[])loopObject).length;
/*     */     else {
/* 105 */       throw new VMException(loopObject + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.getObjectByIndex_notBandle"));
/*     */     }
/*     */ 
/* 108 */     if (task.getWorkflowType().equalsIgnoreCase("workflow")) {
/* 109 */       String[] childWorkflowId = new String[childCount];
/* 110 */       for (int i = 0; i < childCount; ++i) {
/* 111 */         childWorkflowId[i] = createOneChild(task, VMUtil.getObjectByIndex(loopObject, i), context);
/*     */       }
/* 113 */       setChildWorkflowCount(childCount);
/* 114 */       setRemanentWorkflowCount(childCount);
/* 115 */       if (childCount > 0)
/* 116 */         updateState(5, Constant.S_STATE_ACTIVE_I18N);
/*     */       else {
/* 118 */         updateState(3, Constant.S_STATE_noChildProcessEnd_I18N);
/*     */       }
/* 120 */       ((Workflow)getWorkflow()).addUserTaskCount();
/* 121 */     } else if (task.getWorkflowType().equalsIgnoreCase("process")) {
/* 122 */       setChildWorkflowCount(childCount);
/* 123 */       for (int i = 0; i < childCount; ++i) {
/* 124 */         createOneChild(task, VMUtil.getObjectByIndex(loopObject, i), context);
/*     */       }
/* 126 */       updateState(3, Constant.S_STATE_childBusinessProcess_I18N);
/*     */     } else {
/* 128 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_childProcess") + task.getWorkflowCode() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_defineProcessType") + task.getWorkflowType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_unlegal"));
/*     */     }
/* 130 */     return Boolean.TRUE;
/*     */   }
/*     */ 
/*     */   public String createOneChild(TaskWorkflowTemplate task, Object loopObject, WorkflowContext context)
/*     */     throws Exception
/*     */   {
/* 142 */     ParameterDefine[] inparameters = task.getInParameterDefine();
/*     */ 
/* 144 */     Map map = new HashMap();
/* 145 */     String objectType = "";
/* 146 */     String objectId = "";
/*     */ 
/* 148 */     String createStaff = getWorkflow().getCreateStaffId();
/* 149 */     Object obj = null;
/* 150 */     String workflowCode = task.getWorkflowCode();
/* 151 */     for (int i = 0; i < inparameters.length; ++i) {
/* 152 */       if (!StringUtils.isEmptyString(inparameters[i].contextVarName)) {
/* 153 */         if (!inparameters[i].contextVarName.startsWith("$LOOP.")) {
/* 154 */           obj = VMDataType.transfer(getContextValue(this, context, inparameters[i].contextVarName), inparameters[i].getDataTypeClass());
/*     */         }
/*     */         else
/*     */         {
/* 158 */           obj = VMDataType.transfer(VMUtil.getObjectProperty(loopObject, inparameters[i].contextVarName.substring("$LOOP.".length())), inparameters[i].getDataTypeClass());
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 164 */         obj = inparameters[i].getValue();
/*     */       }
/* 166 */       if (inparameters[i].name.equalsIgnoreCase("FLOWOBJECT_TYPE") == true)
/*     */       {
/* 168 */         if (obj != null)
/* 169 */           objectType = obj.toString();
/*     */       }
/* 171 */       else if (inparameters[i].name.equalsIgnoreCase("FLOWOBJECT_ID") == true)
/*     */       {
/* 173 */         if (obj != null)
/* 174 */           objectId = obj.toString();
/*     */       }
/* 176 */       else if (inparameters[i].name.equalsIgnoreCase("CREATE_STAFF") == true)
/*     */       {
/* 178 */         if (obj != null)
/* 179 */           createStaff = obj.toString();
/*     */       }
/* 181 */       else if (inparameters[i].name.equalsIgnoreCase("FLOWOBJECT_CHILD_TASK_CODE") == true)
/*     */       {
/* 183 */         if (obj != null)
/* 184 */           workflowCode = obj.toString();
/*     */       }
/*     */       else {
/* 187 */         map.put(inparameters[i].name, obj);
/*     */       }
/*     */     }
/*     */ 
/* 191 */     String childWorkflowId = "-1";
/*     */ 
/* 193 */     if (task.getWorkflowType().equalsIgnoreCase("workflow")) {
/* 194 */       childWorkflowId = WorkflowEngineFactory.getInstance().createWorkflow(getWorkflow().getQueueId(), getTaskId(), workflowCode, 1, createStaff, objectType, objectId, map);
/*     */     }
/* 200 */     else if (task.getWorkflowType().equalsIgnoreCase("process"))
/*     */     {
/* 202 */       Map returnMap = ProcessEngineFactory.getProcessEngine().executeProcess(workflowCode, map);
/*     */ 
/* 204 */       if (returnMap != null)
/*     */       {
/* 206 */         ParameterDefine[] outparameters = task.getOutParameterDefine();
/* 207 */         for (int i = 0; i < outparameters.length; ++i) {
/* 208 */           if ((StringUtils.isEmptyString(outparameters[i].contextVarName)) || 
/* 210 */             (outparameters[i].contextVarName.startsWith("$LOOP.")))
/*     */             continue;
/* 212 */           if (getChildWorkflowCount() > 1L)
/*     */           {
/* 214 */             String uniteValues = VMUtil.uniteChildWorkflowOutValues(outparameters[i].contextVarName, this.workflow.getWorkflowContext(), returnMap.get(outparameters[i].name), getTaskId(), "process" + i);
/*     */ 
/* 218 */             this.workflow.getWorkflowContext().set(outparameters[i].contextVarName, uniteValues);
/*     */           } else {
/* 220 */             this.workflow.getWorkflowContext().set(outparameters[i].contextVarName, returnMap.get(outparameters[i].name));
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 229 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_childProcess") + workflowCode + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_defineProcessType") + task.getWorkflowType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_unlegal"));
/*     */     }
/* 231 */     return childWorkflowId;
/*     */   }
/*     */ 
/*     */   public static boolean finish(String taskId, String staffId, int childWorkflowState) throws Exception
/*     */   {
/* 236 */     IVmTaskDAO taskDAO = (IVmTaskDAO)ServiceFactory.getService(IVmTaskDAO.class);
/* 237 */     IBOVmTaskValue taskBean = taskDAO.getVmTaskbeanById(taskId, new int[] { 5 });
/* 238 */     if ((taskBean == null) || (taskBean.isNew())) {
/* 239 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.finish_childWorkflowTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_finishedOrStateError") + 5 + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskTimerImpl.finish_1"));
/*     */     }
/*     */ 
/* 242 */     long childCount = taskBean.getChildWorkflowCount();
/* 243 */     long remantCount = taskBean.getRemanentWorkflowCount();
/* 244 */     long leaveChildCount = remantCount - 1L;
/* 245 */     if (leaveChildCount > 0L) {
/* 246 */       taskBean.setRemanentWorkflowCount(leaveChildCount);
/* 247 */       taskDAO.saveVmtaskInstacne(taskBean);
/* 248 */       return false;
/*     */     }
/* 250 */     Timestamp time = TimeUtil.getSysTime();
/* 251 */     taskBean.setFinishStaffId(staffId);
/* 252 */     taskBean.setExeFinishDate(taskBean.getStateDate());
/* 253 */     taskBean.setFinishDate(time);
/* 254 */     taskBean.setRemanentWorkflowCount(leaveChildCount);
/* 255 */     taskBean.setStateDate(time);
/* 256 */     taskBean.setDecisionResult("");
/* 257 */     taskBean.setErrorMessage("");
/*     */ 
/* 261 */     if (childWorkflowState != 3) {
/* 262 */       if (childCount == 1L)
/* 263 */         taskBean.setState(childWorkflowState);
/*     */       else
/* 265 */         taskBean.setState(3);
/*     */     }
/*     */     else {
/* 268 */       taskBean.setState(childWorkflowState);
/*     */     }
/* 270 */     taskDAO.saveVmtaskInstacne(taskBean);
/*     */ 
/* 272 */     IVmWorkflowDAO workflowDAO = (IVmWorkflowDAO)ServiceFactory.getService(IVmWorkflowDAO.class);
/* 273 */     IBOVmWFValue wfBean = workflowDAO.getVmWorkflowBeanbyId(taskBean.getWorkflowId());
/* 274 */     wfBean.setUserTaskCount(wfBean.getUserTaskCount() - 1L);
/* 275 */     workflowDAO.saveVmWorkflowInstacne(wfBean);
/* 276 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskWorkflowImpl
 * JD-Core Version:    0.5.4
 */