/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.utils.PropertiesUtil;
/*    */ import com.ai.comframe.utils.TimeUtil;
/*    */ import com.ai.comframe.vm.common.VMException;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.Processflow;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.sql.Date;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ProcessflowImpl extends FlowBaseImpl
/*    */   implements Processflow
/*    */ {
/*    */   public ProcessflowImpl(String aQueueId, FlowBase aParentWorkflow, String aWorkflowId, WorkflowTemplate aWorkflowTemplate, Map aVars)
/*    */     throws Exception
/*    */   {
/* 23 */     super(aQueueId, aParentWorkflow.getTaskId(), aWorkflowId, -1, aWorkflowTemplate, aVars, 2, new Date(TimeUtil.getSysTime().getTime()), new Date(TimeUtil.getSysTime().getTime()), PropertiesUtil.getSystemUserId(), null, null);
/*    */   }
/*    */ 
/*    */   public Object executeProcess()
/*    */     throws Exception
/*    */   {
/* 32 */     List finishTaskList = new ArrayList();
/*    */     do {
/* 34 */       finishTaskList.clear();
/* 35 */       for (int i = 0; i < this.m_currentTasks.size(); ++i) {
/* 36 */         Task task = (Task)this.m_currentTasks.get(i);
/* 37 */         int tmpState = task.getState();
/* 38 */         if (tmpState == 7) continue; if (tmpState == 5) {
/*    */           continue;
/*    */         }
/*    */ 
/* 42 */         if (tmpState == 2) {
/* 43 */           task.execute(this.workflowContext);
/* 44 */           tmpState = task.getState();
/*    */         }
/*    */ 
/* 48 */         if (tmpState == 99) {
/*    */           continue;
/*    */         }
/* 51 */         if (tmpState == 3) {
/* 52 */           this.m_currentTasks.remove(i);
/* 53 */           task.setIsCurrentTask(false);
/* 54 */           this.m_historyTasks.add(task);
/* 55 */           finishTaskList.add(task);
/*    */         }
/* 57 */         else if (tmpState == 8) {
/* 58 */           this.m_currentTasks.remove(i);
/* 59 */           task.setIsCurrentTask(false);
/* 60 */           this.m_historyTasks.add(task);
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 65 */       for (int i = 0; i < finishTaskList.size(); ++i)
/* 66 */         dealTask((Task)finishTaskList.get(i));
/*    */     }
/* 68 */     while (finishTaskList.size() > 0);
/*    */ 
/* 70 */     if ((this.m_currentTasks.size() == 0) && (getState() != 3)) {
/* 71 */       throw new VMException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.ProcessflowImpl.executeProcess_notEndNoTask"));
/*    */     }
/* 73 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.ProcessflowImpl
 * JD-Core Version:    0.5.4
 */