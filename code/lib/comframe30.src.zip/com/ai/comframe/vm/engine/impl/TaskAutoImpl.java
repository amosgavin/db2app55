/*    */ package com.ai.comframe.vm.engine.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.comframe.utils.PropertiesUtil;
/*    */ import com.ai.comframe.vm.common.Constant;
/*    */ import com.ai.comframe.vm.engine.FlowBase;
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import com.ai.comframe.vm.engine.TaskBaseImpl;
/*    */ import com.ai.comframe.vm.engine.WorkflowContext;
/*    */ import com.ai.comframe.vm.template.TaskAutoTemplate;
/*    */ import com.ai.comframe.vm.template.TaskDealBean;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.sql.Date;
/*    */ 
/*    */ public class TaskAutoImpl extends TaskBaseImpl
/*    */   implements Task
/*    */ {
/*    */   public TaskAutoImpl(FlowBase aWorkflow, String aTaskId, TaskTemplate aTaskTemplated, int aState, Date aStateDate, Date aCreateDate)
/*    */     throws Exception
/*    */   {
/* 22 */     super(aWorkflow, aTaskId, aTaskTemplated, aState, aStateDate, aCreateDate);
/*    */   }
/*    */ 
/*    */   public TaskAutoImpl(FlowBase aWorkflow, TaskTemplate aTaskTemplate, DataContainerInterface inBean)
/*    */   {
/* 27 */     super(aWorkflow, aTaskTemplate, inBean);
/*    */   }
/*    */ 
/*    */   public Object execute(WorkflowContext context) throws Exception {
/* 31 */     Object obj = super.execute(context);
/*    */ 
/* 34 */     monitor(PropertiesUtil.getSystemUserId(), null, 4);
/* 35 */     return obj;
/*    */   }
/*    */ 
/*    */   public Object executeInner(WorkflowContext context) throws Exception
/*    */   {
/* 40 */     TaskAutoTemplate task = (TaskAutoTemplate)getTaskTemplate();
/* 41 */     TaskDealBean dealBean = task.getAutoDealBean();
/*    */ 
/* 43 */     if ((dealBean != null) && (!StringUtils.isEmptyString(dealBean.getRunClassName()))) {
/* 44 */       executeDealInner(this, context, dealBean);
/*    */     }
/* 46 */     updateState(3, Constant.S_STATE_FINISHED_I18N);
/* 47 */     return Boolean.TRUE;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.TaskAutoImpl
 * JD-Core Version:    0.5.4
 */