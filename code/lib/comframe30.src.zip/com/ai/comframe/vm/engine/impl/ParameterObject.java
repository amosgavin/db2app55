package com.ai.comframe.vm.engine.impl;

import com.ai.comframe.vm.common.ParameterDefine;

class ParameterObject
{
  public ParameterDefine p;
  public Class pClass;
  public Object pValue;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.impl.ParameterObject
 * JD-Core Version:    0.5.4
 */