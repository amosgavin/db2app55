package com.ai.comframe.vm.engine;

public abstract interface TaskOr extends Task
{
  public abstract void addFinishTaskTemplateId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskOr
 * JD-Core Version:    0.5.4
 */