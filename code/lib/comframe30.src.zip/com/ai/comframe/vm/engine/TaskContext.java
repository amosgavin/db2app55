package com.ai.comframe.vm.engine;

import com.ai.comframe.vm.common.ParameterDefine;
import java.util.Map;

public abstract interface TaskContext
{
  public static final String USERTASK_IS_WAIT_VAR_NAME = "$IS_WAIT_USER";
  public static final String TASK_COMFRAME_EXCEPTION_CODE = "$TASK_EXCEPTION_CODE";
  public static final String TASK_COMFRAME_EXCEPTION_MSG = "$TASK_EXCEPTION_MSG";
  public static final String ENGINE_LAST_TASK_ID = "_ENGINE_LAST_TASK_ID";

  public abstract ParameterDefine[] getInParameters();

  public abstract ParameterDefine[] getOutParameters();

  public abstract void remvoe(String paramString);

  public abstract Object get(String paramString);

  public abstract void set(String paramString, Object paramObject);

  public abstract void clear();

  public abstract Map getParameters();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskContext
 * JD-Core Version:    0.5.4
 */