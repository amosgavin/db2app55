/*    */ package com.ai.comframe.vm.engine;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class WorkflowContextImpl
/*    */   implements WorkflowContext
/*    */ {
/*    */   Map m_list;
/*    */ 
/*    */   public WorkflowContextImpl()
/*    */   {
/* 12 */     this.m_list = new HashMap();
/*    */   }
/* 14 */   public ParameterDefine[] getInParameters() { return null; }
/*    */ 
/*    */   public ParameterDefine[] getOutParameters() {
/* 17 */     return null;
/*    */   }
/*    */   public void remvoe(String name) {
/* 20 */     this.m_list.remove(name);
/*    */   }
/*    */   public Object get(String name) {
/* 23 */     if ((name.equalsIgnoreCase("$WORKFLOW_ID")) || (name.equalsIgnoreCase("$WORKFLOW_TAG")) || (name.equalsIgnoreCase("$TASK_TAG")) || (name.equalsIgnoreCase("$TASK_ID")) || (name.equalsIgnoreCase("$QUEUE_ID")) || (name.equals("$WORKFLOW_OBJ_ID")) || (name.equals("$WORKFLOW_OBJ_TYPE_ID")))
/*    */     {
/* 27 */       throw new RuntimeException("$WORKFLOW_ID " + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.WorkflowContextImpl.get_add") + "$TASK_ID" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.getValue_cannotGetValueThisWay"));
/*    */     }
/*    */ 
/* 30 */     if (!this.m_list.containsKey(name));
/* 33 */     return this.m_list.get(name);
/*    */   }
/*    */   public void set(String name, Object obj) {
/* 36 */     this.m_list.put(name, obj);
/*    */   }
/*    */   public void clear() {
/* 39 */     this.m_list.clear();
/*    */   }
/*    */ 
/*    */   public Map getParameters() {
/* 43 */     return this.m_list;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 47 */     StringBuffer buffer = new StringBuffer();
/* 48 */     for (Iterator it = this.m_list.entrySet().iterator(); it.hasNext(); ) {
/* 49 */       Map.Entry e = (Map.Entry)it.next();
/* 50 */       buffer.append(e.getKey().toString()).append(" = ").append((e.getValue() == null) ? "" : e.getValue().toString()).append("\n");
/*    */     }
/*    */ 
/* 53 */     return buffer.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.WorkflowContextImpl
 * JD-Core Version:    0.5.4
 */