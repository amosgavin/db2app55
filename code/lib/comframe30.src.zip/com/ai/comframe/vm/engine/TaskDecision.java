package com.ai.comframe.vm.engine;

public abstract interface TaskDecision extends Task
{
  public abstract Object getDecision();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.TaskDecision
 * JD-Core Version:    0.5.4
 */