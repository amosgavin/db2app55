package com.ai.comframe.vm.engine;

import com.ai.comframe.client.ComframeBusiException;
import java.util.List;

public abstract interface Workflow extends FlowBase
{
  public abstract long getUserTaskCount()
    throws Exception;

  public abstract void addUserTaskCount()
    throws Exception;

  public abstract void realseUserTaskCount()
    throws Exception;

  public abstract void disable(String paramString1, String paramString2)
    throws Exception;

  public abstract void enable(String paramString1, String paramString2)
    throws Exception;

  public abstract void suspend(String paramString1, String paramString2)
    throws Exception;

  public abstract void resume(String paramString1, String paramString2)
    throws Exception;

  public abstract void fireException(String paramString1, String paramString2)
    throws Exception;

  public abstract Object executeWorkflow()
    throws Exception;

  public abstract void excuteFinishTask(List paramList)
    throws Exception;

  public abstract Object executeWorkflowSyn()
    throws Exception;

  public abstract void goBackTask(Task paramTask, long paramLong, String paramString1, String paramString2)
    throws Exception;

  public abstract void jumpToTask(Task paramTask, long paramLong, String paramString1, String paramString2)
    throws Exception;

  public abstract void goBackTask(Task paramTask, String paramString1, String paramString2)
    throws Exception;

  public abstract boolean busiExceptionProcess(ComframeBusiException paramComframeBusiException)
    throws Exception;

  public abstract void fireExceptionIndependence(String paramString1, String paramString2)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.engine.Workflow
 * JD-Core Version:    0.5.4
 */