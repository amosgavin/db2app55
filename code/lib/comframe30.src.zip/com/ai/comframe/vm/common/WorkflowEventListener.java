package com.ai.comframe.vm.common;

import com.ai.comframe.vm.engine.Task;

public abstract interface WorkflowEventListener
{
  public static final long EVENT_TASKUSER_CREATE = 100L;
  public static final long EVENT_TASKUSER_LOCK = 101L;

  public abstract void execute(Task paramTask);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.WorkflowEventListener
 * JD-Core Version:    0.5.4
 */