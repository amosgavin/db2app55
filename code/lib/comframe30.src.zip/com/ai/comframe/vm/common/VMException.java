/*   */ package com.ai.comframe.vm.common;
/*   */ 
/*   */ public class VMException extends Exception
/*   */ {
/*   */   public VMException(String message)
/*   */   {
/* 5 */     super(message);
/*   */   }
/*   */   public VMException(Throwable cause) {
/* 8 */     super(cause);
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.VMException
 * JD-Core Version:    0.5.4
 */