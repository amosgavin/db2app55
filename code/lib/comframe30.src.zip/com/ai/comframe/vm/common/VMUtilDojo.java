/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.client.TaskInfo;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.config.service.interfaces.IWorkflowConsoleSV;
/*     */ import com.ai.comframe.exception.ivalues.IBOVmExceptionRecordValue;
/*     */ import com.ai.comframe.exception.service.interfaces.IComframeExceptionHandleSV;
/*     */ import com.ai.comframe.utils.IDAssembleUtil;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.Task;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.RoleTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOHVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.PrintStream;
/*     */ import java.rmi.RemoteException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class VMUtilDojo
/*     */ {
/*     */   public static int faceWidth;
/*     */   public static int faceHeight;
/*  38 */   public static String Dojo_PATH_LIGHT_ICON32 = "images/light_icon_32/";
/*     */ 
/*  40 */   public static String Dojo_PATH_GRAY_ICON32 = "images/gray_icon_32/";
/*     */ 
/*  42 */   public static String Dojo_PATH_WARNING_ICON32 = "images/warning_icon_32/";
/*     */ 
/*  44 */   public static String Dojo_PATH_ACTIVE_ICON32 = "images/active_icon_32/";
/*     */ 
/*     */   public static List getAllTaskType() {
/*  47 */     List ret = new ArrayList();
/*  48 */     ret.add("and");
/*  49 */     ret.add("auto");
/*  50 */     ret.add("autodecision");
/*  51 */     ret.add("decision");
/*  52 */     ret.add("finish");
/*  53 */     ret.add("fork");
/*  54 */     ret.add("or");
/*  55 */     ret.add("sendmail");
/*  56 */     ret.add("sign");
/*  57 */     ret.add("start");
/*  58 */     ret.add("timer");
/*  59 */     ret.add("user");
/*  60 */     ret.add("workflow");
/*  61 */     ret.add("enddecision");
/*  62 */     ret.add("loop");
/*  63 */     ret.add("endloop");
/*  64 */     ret.add("shell");
/*  65 */     ret.add("break");
/*  66 */     ret.add("continue");
/*  67 */     ret.add("isOverTime");
/*  68 */     ret.add("childWofFlow");
/*  69 */     return ret;
/*     */   }
/*     */ 
/*     */   public static String getLightTypeImg(String type) {
/*  73 */     return Dojo_PATH_LIGHT_ICON32 + TaskConfig.getInstance().getStudioPic(type);
/*     */   }
/*     */   public static String getGrayTypeImg(String type) {
/*  76 */     return Dojo_PATH_GRAY_ICON32 + TaskConfig.getInstance().getStudioPic(type);
/*     */   }
/*     */   public static String getWarningTypeImg(String type) {
/*  79 */     return Dojo_PATH_WARNING_ICON32 + TaskConfig.getInstance().getStudioPic(type);
/*     */   }
/*     */   public static String getActiveTypeImg(String type) {
/*  82 */     return Dojo_PATH_ACTIVE_ICON32 + TaskConfig.getInstance().getStudioPic(type);
/*     */   }
/*     */ 
/*     */   public static String getBackgroudImg(TaskTemplate task, int state, Task taskInstance) throws Exception
/*     */   {
/*  87 */     List typeList = getAllTaskType();
/*     */ 
/*  90 */     if (!typeList.contains(task.getTaskType())) {
/*  91 */       String type = TaskConfig.getInstance().getBasalType(task.getTaskType());
/*  92 */       if ((state == 99) || (state == 98) || (state == 97) || (state == 11)) {
/*  93 */         String result = getWarningTypeImg(type);
/*  94 */         return result;
/*     */       }
/*  96 */       if ((null != taskInstance) && 
/*  97 */         (taskInstance.isCurrentTask())) {
/*  98 */         String result = getActiveTypeImg(type);
/*  99 */         return result;
/*     */       }
/*     */ 
/* 102 */       if ((state == 3) || (state == 6) || (state == 21) || (state == 4)) {
/* 103 */         String result = getGrayTypeImg(type);
/* 104 */         return result;
/*     */       }
/* 106 */       String result = getLightTypeImg(type);
/* 107 */       return result;
/*     */     }
/*     */ 
/* 110 */     if ((state == 99) || (state == 98) || (state == 97) || (state == 11)) {
/* 111 */       String result = getWarningTypeImg(task.getTaskType());
/* 112 */       return result;
/*     */     }
/* 114 */     if ((null != taskInstance) && 
/* 115 */       (taskInstance.isCurrentTask())) {
/* 116 */       String result = getActiveTypeImg(task.getTaskType());
/* 117 */       return result;
/*     */     }
/*     */ 
/* 120 */     if ((state == 3) || (state == 6) || (state == 21) || (state == 4)) {
/* 121 */       String result = getGrayTypeImg(task.getTaskType());
/* 122 */       return result;
/*     */     }
/* 124 */     String result = getLightTypeImg(task.getTaskType());
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */   private static String toDojoLineEnd(Point src, Point dst)
/*     */   {
/* 132 */     src = new Point(src);
/* 133 */     dst = new Point(dst);
/* 134 */     int size = 10;
/* 135 */     int d = (int)Math.max(1.0D, dst.distance(src));
/* 136 */     int ax = -(size * (dst.x - src.x) / d);
/* 137 */     int ay = -(size * (dst.y - src.y) / d);
/* 138 */     String result = "surface.createLine({x1:" + dst.x + ", y1:" + dst.y + ", x2: " + (dst.x + ax + ay / 2) + " , y2: " + (dst.y + ay - ax / 2) + "}).setStroke( '#0f90da' );";
/* 139 */     Point last = new Point(dst);
/* 140 */     result = result + "surface.createLine({x1:" + dst.x + ", y1:" + dst.y + ", x2: " + (last.x + ax - ay / 2) + " , y2: " + (last.y + ay + ax / 2) + "}).setStroke( '#0f90da' );";
/* 141 */     return result;
/*     */   }
/*     */ 
/*     */   private static String toDojoLineEnd(Point src, Point dst, String color) {
/* 145 */     src = new Point(src);
/* 146 */     dst = new Point(dst);
/* 147 */     int size = 10;
/* 148 */     int d = (int)Math.max(1.0D, dst.distance(src));
/* 149 */     int ax = -(size * (dst.x - src.x) / d);
/* 150 */     int ay = -(size * (dst.y - src.y) / d);
/* 151 */     String result = "surface.createLine({x1:" + dst.x + ", y1:" + dst.y + ", x2: " + (dst.x + ax + ay / 2) + " , y2: " + (dst.y + ay - ax / 2) + "}).setStroke( '" + color + "' );";
/* 152 */     Point last = new Point(dst);
/* 153 */     result = result + "surface.createLine({x1:" + dst.x + ", y1:" + dst.y + ", x2: " + (last.x + ax - ay / 2) + " , y2: " + (last.y + ay + ax / 2) + "}).setStroke( '" + color + "' );";
/* 154 */     return result;
/*     */   }
/*     */ 
/*     */   private static String toDojo(Point aLabelPosition, String aLabel, ArrayList aPoints)
/*     */   {
/* 159 */     StringBuffer _str = new StringBuffer();
/*     */ 
/* 161 */     if (aLabel == null) {
/* 162 */       aLabel = "";
/*     */     }
/*     */ 
/* 165 */     if (aPoints.size() == 2)
/* 166 */       for (int i = 0; i < aPoints.size() - 1; ++i) {
/* 167 */         Point p1 = (Point)aPoints.get(i);
/* 168 */         Point p2 = (Point)aPoints.get(i + 1);
/* 169 */         _str.append("surface.createLine({x1: " + p1.x + ", y1: " + p1.y + ", x2: " + p2.x + " , y2: " + p2.y + "}).setStroke( '#86b4e4' );");
/* 170 */         _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'" + aLabel + "',align:'middle'});");
/* 171 */         _str.append("t.setFill ('#0c469e');");
/* 172 */         _str.append("t.setFont ({family:'Arial',size:12});");
/*     */       }
/* 174 */     else if (aPoints.size() > 2) {
/* 175 */       for (int i = 0; i < aPoints.size() - 1; ++i) {
/* 176 */         Point p1 = (Point)aPoints.get(i);
/* 177 */         Point p2 = (Point)aPoints.get(i + 1);
/* 178 */         _str.append("surface.createLine({x1: " + p1.x + ", y1: " + p1.y + ", x2: " + p2.x + " , y2: " + p2.y + "}).setStroke( '#86b4e4' );");
/* 179 */         if (i == 1)
/* 180 */           _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'" + aLabel + "',align:'middle'});");
/*     */         else {
/* 182 */           _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'',align:'middle'});");
/*     */         }
/* 184 */         _str.append("t.setFill ('#0c469e');");
/* 185 */         _str.append("t.setFont ({family:'Arial',size:12});");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 192 */     int n = aPoints.size();
/* 193 */     _str.append(toDojoLineEnd((Point)aPoints.get(n - 2), (Point)aPoints.get(n - 1)));
/* 194 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toDojo(Point aLabelPosition, String aLabel, ArrayList aPoints, String color, String arrowcolor)
/*     */   {
/* 199 */     StringBuffer _str = new StringBuffer();
/*     */ 
/* 201 */     if (aLabel == null) {
/* 202 */       aLabel = "";
/*     */     }
/*     */ 
/* 205 */     if (aPoints.size() == 2)
/* 206 */       for (int i = 0; i < aPoints.size() - 1; ++i) {
/* 207 */         Point p1 = (Point)aPoints.get(i);
/* 208 */         Point p2 = (Point)aPoints.get(i + 1);
/* 209 */         _str.append("surface.createLine({x1: " + p1.x + ", y1: " + p1.y + ", x2: " + p2.x + " , y2: " + p2.y + "}).setStroke( '" + color + "' );");
/* 210 */         _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'" + aLabel + "',align:'middle'});");
/* 211 */         _str.append("t.setFill ('#0c469e');");
/* 212 */         _str.append("t.setFont ({family:'Arial',size:12});");
/*     */       }
/* 214 */     else if (aPoints.size() > 2) {
/* 215 */       for (int i = 0; i < aPoints.size() - 1; ++i) {
/* 216 */         Point p1 = (Point)aPoints.get(i);
/* 217 */         Point p2 = (Point)aPoints.get(i + 1);
/* 218 */         _str.append("surface.createLine({x1: " + p1.x + ", y1: " + p1.y + ", x2: " + p2.x + " , y2: " + p2.y + "}).setStroke( '" + color + "' );");
/* 219 */         if (i == 1)
/* 220 */           _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'" + aLabel + "',align:'middle'});");
/*     */         else {
/* 222 */           _str.append("var t=surface.createText ({x:" + (p1.x + p2.x) / 2 + ",y:" + (p1.y + p2.y) / 2 + ",text:'',align:'middle'});");
/*     */         }
/* 224 */         _str.append("t.setFill ('#0c469e');");
/* 225 */         _str.append("t.setFont ({family:'Arial',size:12});");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 232 */     int n = aPoints.size();
/* 233 */     _str.append(toDojoLineEnd((Point)aPoints.get(n - 2), (Point)aPoints.get(n - 1), arrowcolor));
/* 234 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toDojoOfTaskImageCell(Rectangle rect, String image, long templateId, String taskId, String childCode, String aText, String taskType, int state, String taskTag, String exceptionPiid)
/*     */   {
/* 240 */     StringBuffer _str = new StringBuffer();
/* 241 */     _str.append("var image = surface.createImage({");
/* 242 */     _str.append("height: iconHeight,");
/* 243 */     _str.append("width: iconWidth,");
/*     */ 
/* 246 */     _str.append("src: '" + image + "'});");
/*     */ 
/* 249 */     _str.append("image.setTransform(dojox.gfx.matrix.translate(" + rect.getX() + "," + rect.getY() + "));");
/* 250 */     _str.append("image.connect('ondblclick',function as(){ondbDojoClick(" + templateId + ",'" + aText + "','" + taskId + "','" + childCode + "','" + taskType + "','" + state + "','" + taskTag + "','" + exceptionPiid + "');});");
/* 251 */     _str.append("image.connect('onclick',function extonclick(){onDojoClick(" + templateId + ",'" + aText + "','" + taskId + "','" + childCode + "','" + taskType + "','" + state + "','" + taskTag + "','" + exceptionPiid + "');});");
/*     */ 
/* 253 */     _str.append("var t=surface.createText ({x:" + rect.getX() + "+iconWidth/2,y:" + rect.getY() + "+iconHeight+12,text:'" + aText + "',align:'middle'});");
/* 254 */     if ((state == 2) || (state == 5) || (state == 9) || (state == 10)) {
/* 255 */       _str.append("t.setFill ('#172c7d');");
/* 256 */     } else if ((state == 3) || (state == 6) || (state == 21)) {
/* 257 */       _str.append("t.setFill ('gray');");
/* 258 */       _str.append("t.setFont ({weight:'bolder'});");
/* 259 */     } else if ((state == 99) || (state == 98) || (state == 97) || (state == 11)) {
/* 260 */       _str.append("t.setFill ('red');");
/*     */     } else {
/* 262 */       _str.append("t.setFill ('black');");
/*     */     }
/* 264 */     _str.append("t.setFont ({family:'Arial',size:12});");
/* 265 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toDojoOfRole(Rectangle rect, String label)
/*     */   {
/* 270 */     StringBuffer _str = new StringBuffer();
/* 271 */     if (rect.height > rect.width) {
/* 272 */       _str.append("surface.createLine({x1: " + rect.x + ", y1: " + rect.y + ", x2: " + rect.x + " , y2: " + (rect.y + rect.height) + "})" + ".setStroke( 'gray' );");
/*     */ 
/* 275 */       _str.append("surface.createLine({x1: " + (rect.x + rect.width) + ", y1: " + rect.y + ", x2: " + (rect.x + rect.width) + " , y2: " + (rect.y + rect.height) + "})" + ".setStroke( 'gray' );");
/*     */ 
/* 279 */       _str.append("var rect_1=surface.createRect({x:").append(rect.x).append(", y:").append(rect.y).append(", width:").append(rect.width).append(", height:").append(25).append(" });");
/*     */ 
/* 281 */       _str.append("rect_1.setFill('gray');");
/* 282 */       _str.append("rect_1.setStroke({color:　'black',　width:　1,　join:　'round'　});");
/* 283 */       _str.append("var text_t=surface.createText ({x:" + rect.getX() + "+iconWidth/2,y:" + rect.getY() + "+iconHeight-12,text:'" + label + "',align:'middle'});");
/* 284 */       _str.append("text_t.setFill ('black');");
/* 285 */       _str.append("text_t.setFont ({family:'Arial',size:12});");
/*     */     }
/*     */     else {
/* 288 */       _str.append("surface.createLine({x1: " + rect.x + ", y1: " + rect.y + ", x2: " + (rect.x + rect.width) + " , y2: " + rect.y + "}).setStroke( 'gray' );");
/* 289 */       _str.append("surface.createLine({x1: " + rect.x + ", y1: " + (rect.y + rect.height) + ", x2: " + (rect.x + rect.width) + " , y2: " + (rect.y + rect.height) + "}).setStroke( 'gray' );");
/*     */ 
/* 292 */       _str.append("var rect_1=surface.createRect({x:").append(rect.x).append(", y:").append(rect.y).append(", width:").append(25).append(", height:").append(rect.height).append(" });");
/*     */ 
/* 294 */       _str.append("rect_1.setFill('gray');");
/* 295 */       _str.append("rect_1.setStroke({color:　'black',　width:　1,　join:　'round'　});");
/*     */ 
/* 297 */       _str.append("var text_t=surface.createText ({x:" + rect.getX() + "+iconWidth-12,y:" + rect.getY() + "+iconHeight/2,text:'" + label + "',align:'middle'});");
/* 298 */       _str.append("text_t.setFill ('black');");
/* 299 */       _str.append("text_t.setFont ({family:'Arial',size:12});");
/*     */     }
/*     */ 
/* 303 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   public static String toDojo(String workflowId, TaskTemplate task, int state, Task taskInstance, XYScale xyScale, String imagePath, boolean isHis, String acctPreiod) throws RemoteException, Exception
/*     */   {
/* 308 */     String[] list = StringUtils.split(task.getUIInfo(), ',');
/* 309 */     String taskId = null;
/* 310 */     if (null != taskInstance)
/* 311 */       taskId = taskInstance.getTaskId();
/*     */     Rectangle rect;
/*     */     Rectangle rect;
/* 315 */     if (list.length >= 4)
/* 316 */       rect = new Rectangle((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]), (int)Double.parseDouble(list[2]), (int)Double.parseDouble(list[3]));
/*     */     else {
/* 318 */       rect = new Rectangle(10, 10, 60, 30);
/*     */     }
/* 320 */     xyScale.minX = ((xyScale.minX < rect.getMinX()) ? xyScale.minX : rect.getMinX());
/* 321 */     xyScale.minY = ((xyScale.minY < rect.getMinY()) ? xyScale.minY : rect.getMinY());
/* 322 */     xyScale.maxX = ((xyScale.maxX > rect.getMaxX()) ? xyScale.maxX : rect.getMaxX());
/* 323 */     xyScale.maxY = ((xyScale.maxY > rect.getMaxY()) ? xyScale.maxY : rect.getMaxY());
/*     */ 
/* 325 */     faceWidth = (faceWidth > (int)rect.getMaxX()) ? faceWidth : (int)rect.getMaxX();
/* 326 */     faceHeight = (faceHeight > (int)rect.getMaxY()) ? faceHeight : (int)rect.getMaxY();
/*     */ 
/* 328 */     String childWorkflowCode = "";
/* 329 */     if (task instanceof TaskWorkflowTemplate) {
/* 330 */       childWorkflowCode = ((TaskWorkflowTemplate)task).getWorkflowCode();
/*     */     }
/*     */ 
/* 333 */     String exceptionPiid = null;
/* 334 */     if ((null != workflowId) && (!"".equals(workflowId)) && (state == 98)) {
/* 335 */       IComframeExceptionHandleSV exceptionSV = (IComframeExceptionHandleSV)ServiceFactory.getService(IComframeExceptionHandleSV.class);
/*     */ 
/* 337 */       IBOVmExceptionRecordValue[] recordValues = exceptionSV.getAllExceptionRecordsByInstanceId(workflowId);
/*     */ 
/* 340 */       if ((recordValues != null) && (recordValues.length > 0)) {
/* 341 */         for (int i = 0; i < recordValues.length; ++i) {
/* 342 */           IBOVmExceptionRecordValue record = recordValues[i];
/* 343 */           if (taskId.equals(record.getTaskId())) {
/* 344 */             childWorkflowCode = record.getNextTemplateTag();
/* 345 */             IWorkflowConsoleSV conSV = (IWorkflowConsoleSV)ServiceFactory.getService(IWorkflowConsoleSV.class);
/* 346 */             if (isHis) {
/* 347 */               IBOHVmWFValue wfValue = conSV.getHWorkflowByParentTaskId(workflowId, acctPreiod);
/*     */ 
/* 350 */               if (null != wfValue) {
/* 351 */                 exceptionPiid = wfValue.getWorkflowId();
/*     */               }
/* 353 */               break;
/* 354 */             }IBOVmWFValue wfValue = conSV.getWorkflowByParentTaskId(workflowId);
/* 355 */             if (null != wfValue) {
/* 356 */               exceptionPiid = wfValue.getWorkflowId();
/*     */             }
/*     */ 
/* 359 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 365 */     String taskType = TaskConfig.getInstance().getBasalType(task.getTaskType());
/* 366 */     String taskTag = task.getTaskTag();
/* 367 */     return toDojoOfTaskImageCell(rect, getBackgroudImg(task, state, taskInstance), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag, exceptionPiid);
/*     */   }
/*     */ 
/*     */   public static String toDojo(JoinTemplate join, XYScale xyScale, FlowBase workflow) throws RemoteException, Exception {
/* 371 */     Point labelPosition = null;
/* 372 */     ArrayList points = new ArrayList();
/* 373 */     long ida = join.getTaskTemplateAId();
/* 374 */     long idb = join.getTaskTemplateBId();
/* 375 */     Task taska = workflow.getTaskByTemplateId(ida);
/* 376 */     Task taskb = workflow.getTaskByTemplateId(idb);
/* 377 */     String color = "#86b4e4";
/* 378 */     String arrowcolor = "#0f90da";
/* 379 */     if ((taska != null) && (!taska.equals("")) && (taskb != null) && (!taskb.equals(""))) {
/* 380 */       long sa = taska.getState();
/* 381 */       long sb = taskb.getState();
/* 382 */       ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*     */ 
/* 385 */       IBOVmTaskValue taskB = taskSv.getVmTaskByID(taskb.getTaskId());
/* 386 */       if ((null != taskB) && (taska.getTaskId().equals(taskB.getLastTaskId()))) {
/* 387 */         color = "gray";
/* 388 */         arrowcolor = "gray";
/*     */       }
/*     */       else
/*     */       {
/* 401 */         String cond = "TASK_ID=:TASK_ID";
/* 402 */         HashMap param = new HashMap();
/* 403 */         param.put("TASK_ID", taskb.getTaskId());
/* 404 */         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/* 405 */         String queueID = IDAssembleUtil.unwrapPrefix(taskb.getTaskId());
/* 406 */         String date = dateFormat.format(taskb.getCreateDate());
/* 407 */         IBOHVmTaskValue[] hTaskBs = taskSv.getHisVmTaskBean(queueID, cond, param, -1, -1, date);
/* 408 */         IBOHVmTaskValue hTaskB = null;
/* 409 */         if ((null != hTaskBs) && (hTaskBs.length > 0)) {
/* 410 */           hTaskB = hTaskBs[0];
/*     */         }
/*     */ 
/* 413 */         if ((null != hTaskB) && (taska.getTaskId().equals(hTaskB.getLastTaskId()))) {
/* 414 */           color = "gray";
/* 415 */           arrowcolor = "gray";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 424 */     String[] list = StringUtils.split(join.getUIInfo(), ',');
/* 425 */     if (list.length > 0) {
/* 426 */       labelPosition = new Point((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]));
/* 427 */       labelPosition.x = Math.abs(labelPosition.x - 500);
/* 428 */       labelPosition.y = Math.abs(labelPosition.y - 500);
/*     */ 
/* 430 */       int length = list.length / 2;
/* 431 */       for (int i = 2; i < length; ++i) {
/* 432 */         double x = Double.parseDouble(list[(i * 2)]);
/* 433 */         double y = Double.parseDouble(list[(i * 2 + 1)]);
/* 434 */         points.add(new Point((int)x, (int)y));
/* 435 */         xyScale.minX = ((xyScale.minX < x) ? xyScale.minX : x);
/* 436 */         xyScale.minY = ((xyScale.minY < y) ? xyScale.minY : y);
/* 437 */         xyScale.maxX = ((xyScale.maxX > x) ? xyScale.maxX : x);
/* 438 */         xyScale.maxY = ((xyScale.maxY > y) ? xyScale.maxY : y);
/* 439 */         faceWidth = (faceWidth > (int)x) ? faceWidth : (int)x;
/* 440 */         faceHeight = (faceHeight > (int)y) ? faceHeight : (int)y;
/*     */       }
/*     */     }
/* 443 */     if (points.size() > 2) {
/* 444 */       labelPosition = (Point)points.get(1);
/*     */     }
/* 446 */     else if (points.size() == 2) {
/* 447 */       Point p1 = (Point)points.get(0);
/* 448 */       Point p2 = (Point)points.get(1);
/* 449 */       labelPosition.x = ((int)(p1.getX() + p2.getX()) / 2);
/* 450 */       labelPosition.y = ((int)(p1.getY() + p2.getY()) / 2);
/*     */     }
/*     */     else {
/* 453 */       return "";
/*     */     }
/* 455 */     return toDojo(labelPosition, join.getCondition(), points, color, arrowcolor);
/*     */   }
/*     */ 
/*     */   public static String toDojo(JoinTemplate join, XYScale xyScale) {
/* 459 */     Point labelPosition = null;
/* 460 */     ArrayList points = new ArrayList();
/* 461 */     String[] list = StringUtils.split(join.getUIInfo(), ',');
/* 462 */     if (list.length > 0) {
/* 463 */       labelPosition = new Point((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]));
/* 464 */       labelPosition.x = Math.abs(labelPosition.x - 500);
/* 465 */       labelPosition.y = Math.abs(labelPosition.y - 500);
/*     */ 
/* 467 */       int length = list.length / 2;
/* 468 */       for (int i = 2; i < length; ++i) {
/* 469 */         double x = Double.parseDouble(list[(i * 2)]);
/* 470 */         double y = Double.parseDouble(list[(i * 2 + 1)]);
/* 471 */         points.add(new Point((int)x, (int)y));
/* 472 */         xyScale.minX = ((xyScale.minX < x) ? xyScale.minX : x);
/* 473 */         xyScale.minY = ((xyScale.minY < y) ? xyScale.minY : y);
/* 474 */         xyScale.maxX = ((xyScale.maxX > x) ? xyScale.maxX : x);
/* 475 */         xyScale.maxY = ((xyScale.maxY > y) ? xyScale.maxY : y);
/* 476 */         faceWidth = (faceWidth > (int)x) ? faceWidth : (int)x;
/* 477 */         faceHeight = (faceHeight > (int)y) ? faceHeight : (int)y;
/*     */       }
/*     */     }
/* 480 */     if (points.size() > 2) {
/* 481 */       labelPosition = (Point)points.get(1);
/*     */     }
/* 483 */     else if (points.size() == 2) {
/* 484 */       Point p1 = (Point)points.get(0);
/* 485 */       Point p2 = (Point)points.get(1);
/* 486 */       labelPosition.x = ((int)(p1.getX() + p2.getX()) / 2);
/* 487 */       labelPosition.y = ((int)(p1.getY() + p2.getY()) / 2);
/*     */     }
/*     */     else {
/* 490 */       return "";
/*     */     }
/* 492 */     return toDojo(labelPosition, join.getCondition(), points);
/*     */   }
/*     */ 
/*     */   public static String toDojo(RoleTemplate task, XYScale xyScale) {
/* 496 */     String[] list = StringUtils.split(task.getUIInfo(), ',');
/*     */     Rectangle rect;
/*     */     Rectangle rect;
/* 498 */     if (list.length >= 4) {
/* 499 */       rect = new Rectangle((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]), (int)Double.parseDouble(list[2]), (int)Double.parseDouble(list[3]));
/*     */     }
/*     */     else
/*     */     {
/* 504 */       rect = new Rectangle(10, 10, 150, 500);
/*     */     }
/* 506 */     xyScale.minX = ((xyScale.minX < rect.getMinX()) ? xyScale.minX : rect.getMinX());
/* 507 */     xyScale.minY = ((xyScale.minY < rect.getMinY()) ? xyScale.minY : rect.getMinY());
/* 508 */     xyScale.maxX = ((xyScale.maxX > rect.getMaxX()) ? xyScale.maxX : rect.getMaxX());
/* 509 */     xyScale.maxY = ((xyScale.maxY > rect.getMaxY()) ? xyScale.maxY : rect.getMaxY());
/*     */ 
/* 511 */     return toDojoOfRole(rect, task.getLabel());
/*     */   }
/*     */ 
/*     */   public static String toDojo(WorkflowTemplate workflow, String encoding, String imagePath) throws RemoteException, Exception
/*     */   {
/* 516 */     setImagePath(imagePath);
/* 517 */     if ((encoding == null) || (StringUtils.isEmptyString(encoding))) {
/* 518 */       encoding = "utf-8";
/*     */     }
/* 520 */     StringBuffer tmp = new StringBuffer();
/*     */      tmp37_34 = new VMUtilDojo(); tmp37_34.getClass(); XYScale xyScale = new XYScale();
/* 522 */     xyScale.minX = 500.0D;
/* 523 */     xyScale.minY = 500.0D;
/* 524 */     JoinTemplate[] joins = workflow.getJoinTemplates();
/* 525 */     for (int i = 0; i < joins.length; ++i) {
/* 526 */       tmp.append(toDojo(joins[i], xyScale));
/*     */     }
/* 528 */     TaskTemplate[] tasks = workflow.getTaskTemplates();
/* 529 */     for (int i = 0; i < tasks.length; ++i) {
/* 530 */       tmp.append(toDojo(null, tasks[i], -1, null, xyScale, imagePath, false, null));
/*     */     }
/* 532 */     RoleTemplate[] roles = workflow.getRoleTemplates();
/* 533 */     for (int i = 0; i < roles.length; ++i) {
/* 534 */       tmp.append(toDojo(roles[i], xyScale));
/*     */     }
/*     */ 
/* 537 */     if (xyScale.maxX < 500.0D) {
/* 538 */       xyScale.minX -= 100.0D;
/* 539 */       xyScale.maxX += 100.0D;
/*     */     }
/* 541 */     if (xyScale.maxY < 500.0D) {
/* 542 */       xyScale.minY -= 50.0D;
/* 543 */       xyScale.maxY += 100.0D;
/*     */     }
/* 545 */     StringBuffer dojohtml = new StringBuffer();
/* 546 */     dojohtml.append("dojo.require('dojox.gfx');");
/* 547 */     dojohtml.append("dojo.require('dojox.data.dom');");
/* 548 */     dojohtml.append("var surfaceHeight = document.getElementById('container').offsetHeight ;");
/* 549 */     dojohtml.append("var surfaceWidth = document.getElementById('container').offsetWidth;");
/* 550 */     dojohtml.append("var iconHeight =32;");
/* 551 */     dojohtml.append("var iconWidth =32;");
/* 552 */     dojohtml.append("function drawGraph(){");
/* 553 */     dojohtml.append("dojox.data.dom.removeChildren(dojo.byId('container'));");
/* 554 */     dojohtml.append("var surface = dojox.gfx.createSurface('container', surfaceWidth, surfaceHeight);");
/* 555 */     dojohtml.append("var image = surface.createImage({");
/* 556 */     dojohtml.append("height: surfaceHeight,");
/* 557 */     dojohtml.append("width: surfaceWidth,");
/* 558 */     dojohtml.append("src: '" + Dojo_PATH_LIGHT_ICON32 + "bg.png" + "'});");
/* 559 */     faceHeight = 0;
/* 560 */     faceWidth = 0;
/* 561 */     dojohtml.append(tmp);
/* 562 */     dojohtml.append("}");
/* 563 */     dojohtml.append("dojo.addOnLoad(drawGraph);");
/* 564 */     return dojohtml.toString();
/*     */   }
/*     */   public static void setImagePath(String imagePath) {
/* 567 */     if ((imagePath != null) && (!"".equals(imagePath))) {
/* 568 */       if (!imagePath.endsWith("/")) {
/* 569 */         imagePath = imagePath + "/";
/*     */       }
/* 571 */       Dojo_PATH_GRAY_ICON32 = imagePath + Dojo_PATH_GRAY_ICON32;
/* 572 */       Dojo_PATH_LIGHT_ICON32 = imagePath + Dojo_PATH_LIGHT_ICON32;
/* 573 */       Dojo_PATH_WARNING_ICON32 = imagePath + Dojo_PATH_WARNING_ICON32;
/* 574 */       Dojo_PATH_ACTIVE_ICON32 = imagePath + Dojo_PATH_ACTIVE_ICON32;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String toDojo(FlowBase workflow, String imagePath) throws RemoteException, Exception {
/* 579 */     setImagePath(imagePath);
/* 580 */     StringBuffer tmp = new StringBuffer();
/*     */      tmp23_20 = new VMUtilDojo(); tmp23_20.getClass(); XYScale xyScale = new XYScale();
/* 582 */     xyScale.minX = 500.0D;
/* 583 */     xyScale.minY = 500.0D;
/* 584 */     JoinTemplate[] joins = workflow.getWorkflowTemplate().getJoinTemplates();
/* 585 */     for (int i = 0; i < joins.length; ++i) {
/* 586 */       tmp.append(toDojo(joins[i], xyScale, workflow));
/*     */     }
/* 588 */     TaskTemplate[] tasks = workflow.getWorkflowTemplate().getTaskTemplates();
/* 589 */     for (int i = 0; i < tasks.length; ++i) {
/* 590 */       Task taskInstance = workflow.getTaskByTemplateId(tasks[i].getTaskTemplateId());
/* 591 */       if (taskInstance == null)
/* 592 */         tmp.append(toDojo(null, tasks[i], tasks[i].getState(), null, xyScale, imagePath, false, null));
/*     */       else {
/* 594 */         tmp.append(toDojo(workflow.getWorkflowId(), tasks[i], taskInstance.getState(), taskInstance, xyScale, imagePath, false, null));
/*     */       }
/*     */     }
/* 597 */     RoleTemplate[] roles = workflow.getWorkflowTemplate().getRoleTemplates();
/* 598 */     for (int i = 0; i < roles.length; ++i) {
/* 599 */       tmp.append(toDojo(roles[i], xyScale));
/*     */     }
/*     */ 
/* 602 */     String parentTaskId = workflow.getParentTaskId();
/* 603 */     int workflowType = workflow.getWorkflowKind();
/* 604 */     String parentWorkflowId = null;
/*     */     try {
/* 606 */       if (workflowType == 1) {
/* 607 */         IBOVmTaskValue parentTaskBean = WorkflowEngineFactory.getInstance().getTaskBean(parentTaskId);
/* 608 */         if (parentTaskBean != null) {
/* 609 */           parentWorkflowId = parentTaskBean.getWorkflowId();
/*     */         }
/*     */       }
/* 612 */       else if (workflowType == 2) {
/* 613 */         parentWorkflowId = parentTaskId;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 617 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 620 */     if (xyScale.maxX < 500.0D) {
/* 621 */       xyScale.minX -= 100.0D;
/* 622 */       xyScale.maxX += 100.0D;
/*     */     }
/* 624 */     if (xyScale.maxY < 500.0D) {
/* 625 */       xyScale.minY -= 50.0D;
/* 626 */       xyScale.maxY += 100.0D;
/*     */     }
/*     */ 
/* 629 */     StringBuffer dojohtml = new StringBuffer();
/* 630 */     dojohtml.append("dojo.require('dojox.gfx');");
/* 631 */     dojohtml.append("dojo.require('dojox.data.dom');");
/* 632 */     dojohtml.append("var surfaceHeight = document.getElementById('container').offsetHeight ;");
/* 633 */     dojohtml.append("var surfaceWidth = document.getElementById('container').offsetWidth;");
/* 634 */     dojohtml.append("var iconHeight =32;");
/* 635 */     dojohtml.append("var iconWidth =32;");
/* 636 */     dojohtml.append("function drawGraph(){");
/* 637 */     dojohtml.append("dojox.data.dom.removeChildren(dojo.byId('container'));");
/* 638 */     dojohtml.append("var surface = dojox.gfx.createSurface('container', surfaceWidth, surfaceHeight);");
/* 639 */     dojohtml.append("var image = surface.createImage({");
/* 640 */     dojohtml.append("height: surfaceHeight,");
/* 641 */     dojohtml.append("width: surfaceWidth,");
/* 642 */     dojohtml.append("src: '" + Dojo_PATH_LIGHT_ICON32 + "bg.png" + "'});");
/* 643 */     faceHeight = 0;
/* 644 */     faceWidth = 0;
/* 645 */     dojohtml.append(tmp);
/*     */ 
/* 647 */     if (parentWorkflowId != null) {
/* 648 */       StringBuffer _str = new StringBuffer();
/* 649 */       _str.append("var image = surface.createImage({");
/* 650 */       _str.append("height: 28,");
/* 651 */       _str.append("width: 86,");
/* 652 */       _str.append("src: '" + Dojo_PATH_LIGHT_ICON32 + "button1_hover.png" + "'});");
/* 653 */       _str.append("image.setTransform(dojox.gfx.matrix.translate(" + (xyScale.maxX - 100.0D) + "," + xyScale.maxY + "));");
/* 654 */       _str.append("image.connect('onclick',function cl(){showParentDOJO('" + parentWorkflowId + "')});");
/* 655 */       dojohtml.append(_str);
/*     */     }
/* 657 */     dojohtml.append("}");
/* 658 */     dojohtml.append("dojo.addOnLoad(drawGraph);");
/* 659 */     return dojohtml.toString();
/*     */   }
/*     */ 
/*     */   public static String toDojoHis(FlowBase workflow, String acctPreiod, String imagePath) throws RemoteException, Exception
/*     */   {
/* 664 */     setImagePath(imagePath);
/* 665 */     StringBuffer tmp = new StringBuffer();
/*     */      tmp23_20 = new VMUtilDojo(); tmp23_20.getClass(); XYScale xyScale = new XYScale();
/* 667 */     xyScale.minX = 500.0D;
/* 668 */     xyScale.minY = 500.0D;
/* 669 */     JoinTemplate[] joins = workflow.getWorkflowTemplate().getJoinTemplates();
/* 670 */     for (int i = 0; i < joins.length; ++i) {
/* 671 */       tmp.append(toDojo(joins[i], xyScale, workflow));
/*     */     }
/* 673 */     TaskTemplate[] tasks = workflow.getWorkflowTemplate().getTaskTemplates();
/* 674 */     for (int i = 0; i < tasks.length; ++i) {
/* 675 */       Task taskInstance = workflow.getTaskByTemplateId(tasks[i].getTaskTemplateId());
/* 676 */       if (taskInstance == null)
/* 677 */         tmp.append(toDojo(null, tasks[i], tasks[i].getState(), null, xyScale, imagePath, true, acctPreiod));
/*     */       else {
/* 679 */         tmp.append(toDojo(taskInstance.getWorkflow().getWorkflowId(), tasks[i], taskInstance.getState(), taskInstance, xyScale, imagePath, true, acctPreiod));
/*     */       }
/*     */     }
/* 682 */     RoleTemplate[] roles = workflow.getWorkflowTemplate().getRoleTemplates();
/* 683 */     for (int i = 0; i < roles.length; ++i) {
/* 684 */       tmp.append(toDojo(roles[i], xyScale));
/*     */     }
/*     */ 
/* 687 */     String parentTaskId = workflow.getParentTaskId();
/* 688 */     int workflowType = workflow.getWorkflowKind();
/* 689 */     String parentWorkflowId = null;
/*     */     try {
/* 691 */       if (workflowType == 1)
/*     */       {
/* 694 */         TaskInfo task = WorkflowEngineFactory.getInstance().getTaskInfoHis(workflow.getParentTaskId(), acctPreiod);
/* 695 */         parentWorkflowId = task.getWorkflowId();
/*     */       }
/* 698 */       else if (workflowType == 2) {
/* 699 */         parentWorkflowId = parentTaskId;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 703 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 706 */     if (xyScale.maxX < 500.0D) {
/* 707 */       xyScale.minX -= 100.0D;
/* 708 */       xyScale.maxX += 100.0D;
/*     */     }
/* 710 */     if (xyScale.maxY < 500.0D) {
/* 711 */       xyScale.minY -= 50.0D;
/* 712 */       xyScale.maxY += 100.0D;
/*     */     }
/*     */ 
/* 715 */     StringBuffer dojohtml = new StringBuffer();
/* 716 */     dojohtml.append("dojo.require('dojox.gfx');");
/* 717 */     dojohtml.append("dojo.require('dojox.data.dom');");
/* 718 */     dojohtml.append("var surfaceHeight = document.getElementById('container').offsetHeight ;");
/* 719 */     dojohtml.append("var surfaceWidth = document.getElementById('container').offsetWidth;");
/* 720 */     dojohtml.append("var iconHeight =32;");
/* 721 */     dojohtml.append("var iconWidth =32;");
/* 722 */     dojohtml.append("function drawGraph(){");
/* 723 */     dojohtml.append("dojox.data.dom.removeChildren(dojo.byId('container'));");
/* 724 */     dojohtml.append("var surface = dojox.gfx.createSurface('container', surfaceWidth, surfaceHeight);");
/* 725 */     dojohtml.append("var image = surface.createImage({");
/* 726 */     dojohtml.append("height:surfaceHeight, ");
/* 727 */     dojohtml.append("width:surfaceWidth, ");
/* 728 */     dojohtml.append("src: '" + Dojo_PATH_LIGHT_ICON32 + "bg.png" + "'});");
/* 729 */     faceHeight = 0;
/* 730 */     faceWidth = 0;
/* 731 */     dojohtml.append(tmp);
/*     */ 
/* 733 */     if (parentWorkflowId != null) {
/* 734 */       StringBuffer _str = new StringBuffer();
/* 735 */       _str.append("var image = surface.createImage({");
/* 736 */       _str.append("height: 28,");
/* 737 */       _str.append("width: 86,");
/* 738 */       _str.append("src: '" + Dojo_PATH_LIGHT_ICON32 + "button1_hover.png" + "'});");
/* 739 */       _str.append("image.setTransform(dojox.gfx.matrix.translate(" + (xyScale.maxX - 100.0D) + "," + xyScale.maxY + "));");
/* 740 */       _str.append("image.connect('onclick',function cl(){showParentDOJO('" + parentWorkflowId + "')});");
/* 741 */       dojohtml.append(_str);
/*     */     }
/* 743 */     dojohtml.append("}");
/* 744 */     dojohtml.append("dojo.addOnLoad(drawGraph);");
/* 745 */     return dojohtml.toString();
/*     */   }
/*     */ 
/*     */   private static String getParentTaskId(String oldValue) throws Exception {
/* 749 */     String result = "";
/* 750 */     String[] oldValues = oldValue.split(";");
/* 751 */     if (oldValues.length > 0) {
/* 752 */       String key = oldValues[0];
/* 753 */       if ((key.indexOf("_") > 0) && (key.indexOf(":") > 0))
/* 754 */         result = key.substring(0, key.indexOf("_"));
/*     */     }
/* 756 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 767 */     ITemplateSV tmplateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*     */     try {
/* 769 */       WorkflowTemplate templat = tmplateSV.getWorkflowTemplateFromFile("template.TaskAllTest");
/* 770 */       String html = toDojo(templat, "GBK", "abc/afeaa");
/* 771 */       System.out.println(html);
/*     */     } catch (RemoteException e) {
/* 773 */       e.printStackTrace();
/*     */     } catch (Exception e) {
/* 775 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   class XYScale
/*     */   {
/*     */     double minX;
/*     */     double maxX;
/*     */     double minY;
/*     */     double maxY;
/*     */ 
/*     */     XYScale()
/*     */     {
/* 760 */       this.minX = 0.0D;
/* 761 */       this.maxX = 0.0D;
/* 762 */       this.minY = 0.0D;
/* 763 */       this.maxY = 0.0D;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.VMUtilDojo
 * JD-Core Version:    0.5.4
 */