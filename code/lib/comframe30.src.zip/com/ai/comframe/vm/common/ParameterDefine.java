/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ 
/*     */ public class ParameterDefine
/*     */ {
/*   9 */   public static String PARAMETER_TYPE_IN = "in";
/*  10 */   public static String PARAMETER_TYPE_OUT = "out";
/*  11 */   public static String PARAMETER_TYPE_INOUT = "inout";
/*  12 */   public static String PARAMETER_TYPE_INNER = "inner";
/*  13 */   public static String PARAMETER_TYPE_RETURN = "return";
/*     */ 
/*  15 */   public static String PARAMETER_ACCESS_PUBLIC = "public";
/*  16 */   public static String PARAMETER_ACCESS_PROTECTED = "protected";
/*  17 */   public static String PARAMETER_ACCESS_PRIVATE = "private";
/*     */   public String name;
/*     */   public String description;
/*     */   public String dataType;
/*     */   public String contextVarName;
/*     */   public String defaultValue;
/*     */   public String inOutType;
/*     */   public String accessType;
/*     */   private Object value;
/*  53 */   public static ParameterDefine S_WORKFLOW_ID = new ParameterDefine();
/*  54 */   public static ParameterDefine S_WORKFLOW_TAG = new ParameterDefine();
/*  55 */   public static ParameterDefine S_TASK_TAG = new ParameterDefine();
/*  56 */   public static ParameterDefine S_TASK_ID = new ParameterDefine();
/*  57 */   public static ParameterDefine S_QUEUE_ID = new ParameterDefine();
/*  58 */   public static ParameterDefine S_USERTASK_IS_WAIT = new ParameterDefine();
/*  59 */   public static ParameterDefine S_CONTEXT_MAP = new ParameterDefine();
/*  60 */   public static ParameterDefine S_WORKFLOW_OBJ_ID = new ParameterDefine();
/*  61 */   public static ParameterDefine S_WORKFLOW_OBJ_TYPE_ID = new ParameterDefine();
/*  62 */   public static ParameterDefine S_TASK_EXCEPTION_CODE = new ParameterDefine();
/*  63 */   public static ParameterDefine S_TASK_EXCEPTION_MSG = new ParameterDefine();
/*     */ 
/*     */   public Class getDataTypeClass()
/*     */   {
/* 121 */     return VMDataType.getJavaClass(this.dataType);
/*     */   }
/*     */   public Object getValue() {
/* 124 */     if ((super.equals(S_WORKFLOW_ID)) || (super.equals(S_TASK_ID)) || (super.equals(S_QUEUE_ID)) || (super.equals(S_USERTASK_IS_WAIT)) || (super.equals(S_WORKFLOW_OBJ_ID)) || (super.equals(S_WORKFLOW_OBJ_TYPE_ID)) || (super.equals(S_TASK_EXCEPTION_CODE)) || (super.equals(S_TASK_EXCEPTION_MSG)))
/*     */     {
/* 127 */       throw new RuntimeException("$WORKFLOW_ID,$TASK_ID,$QUEUE_ID,$IS_WAIT_USER,$WORKFLOW_OBJ_ID,$WORKFLOW_OBJ_TYPE_ID" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.getValue_cannotGetValueThisWay"));
/*     */     }
/* 129 */     return this.value;
/*     */   }
/*     */   public void setValue(Object obj) {
/* 132 */     if ((super.equals(S_WORKFLOW_ID)) || (super.equals(S_TASK_ID)) || (super.equals(S_QUEUE_ID)) || (super.equals(S_USERTASK_IS_WAIT)) || (super.equals(S_WORKFLOW_OBJ_ID)) || (super.equals(S_WORKFLOW_OBJ_TYPE_ID)) || (super.equals(S_TASK_EXCEPTION_CODE)) || (super.equals(S_TASK_EXCEPTION_MSG)))
/*     */     {
/* 135 */       throw new RuntimeException("$WORKFLOW_ID,$TASK_ID,$QUEUE_ID,$IS_WAIT_USER,$WORKFLOW_OBJ_ID,$WORKFLOW_OBJ_TYPE_ID" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.getValue_cannotSetValue"));
/*     */     }
/* 137 */     this.value = obj;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  65 */     S_WORKFLOW_ID.name = "$WORKFLOW_ID";
/*  66 */     S_WORKFLOW_ID.dataType = "long";
/*  67 */     S_WORKFLOW_ID.inOutType = PARAMETER_TYPE_INNER;
/*  68 */     S_WORKFLOW_ID.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_WORKFLOW_ID_description");
/*     */ 
/*  70 */     S_TASK_ID.name = "$TASK_ID";
/*  71 */     S_TASK_ID.dataType = "long";
/*  72 */     S_TASK_ID.inOutType = PARAMETER_TYPE_INNER;
/*  73 */     S_TASK_ID.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_TASK_ID_description");
/*     */ 
/*  75 */     S_WORKFLOW_TAG.name = "$WORKFLOW_TAG";
/*  76 */     S_WORKFLOW_TAG.dataType = "String";
/*  77 */     S_WORKFLOW_TAG.inOutType = PARAMETER_TYPE_INNER;
/*  78 */     S_WORKFLOW_TAG.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_WORKFLOW_TAG_description");
/*     */ 
/*  80 */     S_TASK_TAG.name = "$TASK_TAG";
/*  81 */     S_TASK_TAG.dataType = "String";
/*  82 */     S_TASK_TAG.inOutType = PARAMETER_TYPE_INNER;
/*  83 */     S_TASK_TAG.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_TASK_TAG_description");
/*     */ 
/*  85 */     S_QUEUE_ID.name = "$QUEUE_ID";
/*  86 */     S_QUEUE_ID.dataType = "String";
/*  87 */     S_QUEUE_ID.inOutType = PARAMETER_TYPE_INNER;
/*  88 */     S_QUEUE_ID.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_QUEUE_ID_description");
/*     */ 
/*  90 */     S_USERTASK_IS_WAIT.name = "$IS_WAIT_USER";
/*  91 */     S_USERTASK_IS_WAIT.dataType = "boolean";
/*  92 */     S_USERTASK_IS_WAIT.inOutType = PARAMETER_TYPE_INNER;
/*  93 */     S_USERTASK_IS_WAIT.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_USERTASK_IS_WAIT_description");
/*     */ 
/*  95 */     S_CONTEXT_MAP.name = "$CONTEXT_MAP";
/*  96 */     S_CONTEXT_MAP.dataType = "java.util.Map";
/*  97 */     S_CONTEXT_MAP.inOutType = PARAMETER_TYPE_INNER;
/*  98 */     S_CONTEXT_MAP.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_CONTEXT_MAP_description");
/*     */ 
/* 100 */     S_WORKFLOW_OBJ_ID.name = "$WORKFLOW_OBJ_ID";
/* 101 */     S_WORKFLOW_OBJ_ID.dataType = "String";
/* 102 */     S_WORKFLOW_OBJ_ID.inOutType = PARAMETER_TYPE_INNER;
/* 103 */     S_WORKFLOW_OBJ_ID.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_WORKFLOW_OBJ_ID_description");
/*     */ 
/* 105 */     S_WORKFLOW_OBJ_TYPE_ID.name = "$WORKFLOW_OBJ_TYPE_ID";
/* 106 */     S_WORKFLOW_OBJ_TYPE_ID.dataType = "String";
/* 107 */     S_WORKFLOW_OBJ_TYPE_ID.inOutType = PARAMETER_TYPE_INNER;
/* 108 */     S_WORKFLOW_OBJ_TYPE_ID.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_WORKFLOW_OBJ_TYPE_ID_description");
/*     */ 
/* 110 */     S_TASK_EXCEPTION_CODE.name = "$TASK_EXCEPTION_CODE";
/* 111 */     S_TASK_EXCEPTION_CODE.dataType = "String";
/* 112 */     S_TASK_EXCEPTION_CODE.inOutType = PARAMETER_TYPE_INNER;
/* 113 */     S_TASK_EXCEPTION_CODE.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_TASK_EXCEPTION_CODE_description");
/*     */ 
/* 115 */     S_TASK_EXCEPTION_MSG.name = "$TASK_EXCEPTION_MSG";
/* 116 */     S_TASK_EXCEPTION_MSG.dataType = "String";
/* 117 */     S_TASK_EXCEPTION_MSG.inOutType = PARAMETER_TYPE_INNER;
/* 118 */     S_TASK_EXCEPTION_MSG.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.ParameterDefine.S_TASK_EXCEPTION_MSG_description");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.ParameterDefine
 * JD-Core Version:    0.5.4
 */