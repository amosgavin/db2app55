/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.appframe2.common.AIDataBase;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.resource.ClasspathResourceLoading;
/*     */ import com.ai.appframe2.util.resource.Resource;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.engine.FlowBase;
/*     */ import com.ai.comframe.vm.engine.Task;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.RoleTemplate;
/*     */ import com.ai.comframe.vm.template.TaskAutoTemplate;
/*     */ import com.ai.comframe.vm.template.TaskDecisionAutoTemplate;
/*     */ import com.ai.comframe.vm.template.TaskDecisionTemplate;
/*     */ import com.ai.comframe.vm.template.TaskFinishTemplate;
/*     */ import com.ai.comframe.vm.template.TaskShellTemplate;
/*     */ import com.ai.comframe.vm.template.TaskSignTemplate;
/*     */ import com.ai.comframe.vm.template.TaskStartTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTimerTemplate;
/*     */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*     */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmTaskValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.awt.Color;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComboBox;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ public class VMUtil
/*     */ {
/*  45 */   private static String FONT_FAMILY = "SimSun";
/*     */   public static Resource[] m_classes;
/*  47 */   public static final String[] innerContexts = { "$TASK_ID", "$TASK_TAG", "$WORKFLOW_ID", "$WORKFLOW_TAG", "$QUEUE_ID", "$WORKFLOW_OBJ_ID", "$WORKFLOW_OBJ_TYPE_ID", "$IS_WAIT_USER", "$TASK_EXCEPTION_CODE", "$TASK_EXCEPTION_MSG", "$CONTEXT_MAP" };
/*     */ 
/*     */   public static Object getObjectByIndex(Object obj, int index) throws Exception
/*     */   {
/*  51 */     if (obj instanceof List) {
/*  52 */       return ((List)obj).get(index);
/*     */     }
/*  54 */     if (obj.getClass().isArray()) {
/*  55 */       return ((Object[])(Object[])obj)[index];
/*     */     }
/*  57 */     return new VMException(obj.getClass().getName() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.getObjectByIndex_notBandle"));
/*     */   }
/*     */ 
/*     */   public static Object getObjectProperty(Object obj, String propertyName)
/*     */   {
/*  62 */     if (obj == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     if (obj instanceof AIDataBase)
/*  66 */       return ((AIDataBase)obj).get(propertyName);
/*     */     try
/*     */     {
/*  69 */       return PropertyUtils.getNestedProperty(obj, propertyName);
/*     */     }
/*     */     catch (Exception ex) {
/*  72 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.getObjectProperty_getAttrFailedFromObj") + ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Color getBackgroud(TaskTemplate task, int state)
/*     */   {
/*  78 */     Color result = null;
/*  79 */     if ((state == 3) || (state == 6) || (state == 21))
/*     */     {
/*  81 */       result = Color.gray;
/*  82 */     } else if ((state == 2) || (state == 5) || (state == 9) || (state == 10))
/*     */     {
/*  85 */       result = Color.green;
/*  86 */     } else if ((state == 99) || (state == 98) || (state == 97) || (state == 11))
/*     */     {
/*  90 */       result = Color.red;
/*  91 */     } else if ((state == 8) || (state == 4))
/*     */     {
/*  93 */       result = Color.yellow;
/*     */     }
/*  95 */     else if (state != -1) {
/*  96 */       result = Color.cyan;
/*     */     }
/*  98 */     else if (task instanceof TaskStartTemplate)
/*  99 */       result = Color.blue;
/* 100 */     else if (task instanceof TaskFinishTemplate)
/* 101 */       result = Color.red;
/* 102 */     else if (task instanceof TaskUserTemplate)
/* 103 */       result = Color.cyan;
/* 104 */     else if (task instanceof TaskDecisionTemplate)
/* 105 */       result = Color.yellow;
/* 106 */     else if (task instanceof TaskDecisionAutoTemplate)
/* 107 */       result = Color.yellow;
/* 108 */     else if (task instanceof TaskTimerTemplate)
/* 109 */       result = Color.pink;
/* 110 */     else if (task instanceof TaskSignTemplate)
/* 111 */       result = Color.magenta;
/* 112 */     else if (task instanceof TaskAutoTemplate)
/* 113 */       result = Color.green;
/* 114 */     else if (task instanceof TaskShellTemplate)
/* 115 */       result = new Color(50, 150, 150, 0);
/*     */     else
/* 117 */       result = Color.orange;
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getBackgroudString(TaskTemplate task, int state) {
/* 122 */     String result = "";
/* 123 */     if ((state == 3) || (state == 6) || (state == 21))
/*     */     {
/* 125 */       result = "gray";
/* 126 */     } else if ((state == 2) || (state == 5) || (state == 9) || (state == 10))
/*     */     {
/* 129 */       result = "current";
/* 130 */     } else if ((state == 99) || (state == 98) || (state == 97))
/*     */     {
/* 133 */       result = "red";
/* 134 */     } else if ((state == 8) || (state == 4))
/*     */     {
/* 136 */       result = "yellow";
/*     */     }
/* 138 */     else if (state != -1) {
/* 139 */       result = "cyan";
/*     */     }
/* 141 */     if (state != -1) {
/* 142 */       return result;
/*     */     }
/* 144 */     Color color = getBackgroud(task, state);
/* 145 */     if (color.equals(Color.gray) == true)
/* 146 */       result = "gray";
/* 147 */     else if (color.equals(Color.blue) == true)
/* 148 */       result = "blue";
/* 149 */     else if (color.equals(Color.red) == true)
/* 150 */       result = "red";
/* 151 */     else if (color.equals(Color.yellow) == true)
/* 152 */       result = "yellow";
/* 153 */     else if (color.equals(Color.orange) == true)
/* 154 */       result = "orange";
/* 155 */     else if (color.equals(Color.cyan) == true)
/* 156 */       result = "cyan";
/* 157 */     else if (color.equals(Color.green) == true)
/* 158 */       result = "lightgreen";
/* 159 */     else if (color.equals(Color.magenta) == true)
/* 160 */       result = "magenta";
/* 161 */     else if (color.equals(Color.pink) == true)
/* 162 */       result = "pink";
/* 163 */     else if (color.equals(new Color(50, 150, 150, 0)) == true) {
/* 164 */       result = "darkgreen";
/*     */     }
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */   private static String svgColorDefine() {
/* 170 */     StringBuffer sb = new StringBuffer();
/* 171 */     sb.append("<desc>Colors</desc>\n<defs>\n").append("<linearGradient id=\"gray\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"gray\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"blue\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"blue\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"red\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"red\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"yellow\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"yellow\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"orange\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"orange\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"cyan\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"cyan\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"lightgreen\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"lightgreen\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"magenta\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"magenta\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"pink\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"pink\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"darkgreen\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" style=\"stop-color:rgb(50,150,150)\"/>\n<stop offset=\"90%\" stop-color=\"white\"/>\n").append("</linearGradient>\n").append("<linearGradient id=\"current\"  gradientTransform=\"rotate(90)\">\n").append("<stop offset=\"0%\" stop-color=\"blue\"/>\n<stop offset=\"50%\" stop-color=\"white\"/>\n<stop offset=\"100%\" stop-color=\"blue\"/>\n").append("</linearGradient>\n").append("</defs>");
/*     */ 
/* 206 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static Resource[] findClasses(String className, String type)
/*     */   {
/* 211 */     if (m_classes == null) {
/* 212 */       m_classes = ClasspathResourceLoading.loadAllClassPathResources("." + type);
/*     */     }
/* 214 */     List result = new ArrayList();
/* 215 */     className = className.toLowerCase();
/* 216 */     for (int i = 0; i < m_classes.length; ++i) {
/* 217 */       if (m_classes[i].getObjectName().toLowerCase().indexOf(className) >= 0)
/* 218 */         result.add(m_classes[i]);
/*     */     }
/* 220 */     return (Resource[])(Resource[])result.toArray(new Resource[0]);
/*     */   }
/*     */ 
/*     */   public static JComboBox getEditorOfType()
/*     */   {
/* 225 */     JComboBox comboBox = new JComboBox();
/* 226 */     String[] names = VMDataType.getDataTypeNames();
/* 227 */     comboBox.addItem("");
/* 228 */     for (int i = 0; i < names.length; ++i) {
/* 229 */       comboBox.addItem(names[i]);
/*     */     }
/* 231 */     return comboBox;
/*     */   }
/*     */   public static JComboBox getEditorInOutType(TaskTemplate type) {
/* 234 */     JComboBox comboBox = new JComboBox();
/* 235 */     if (("workflow".equalsIgnoreCase(type.getTaskType())) || ("process".equalsIgnoreCase(type.getTaskType())) || ("pageflow".equalsIgnoreCase(type.getTaskType())))
/*     */     {
/* 238 */       comboBox.addItem("in");
/* 239 */       comboBox.addItem("out");
/* 240 */       comboBox.addItem("inout");
/* 241 */       comboBox.addItem("inner");
/* 242 */     } else if ("childworkflow".equalsIgnoreCase(type.getTaskType())) {
/* 243 */       comboBox.addItem("in");
/* 244 */       comboBox.addItem("out");
/* 245 */       comboBox.addItem("inout");
/*     */     } else {
/* 247 */       comboBox.addItem("in");
/* 248 */       comboBox.addItem("return");
/*     */     }
/* 250 */     return comboBox;
/*     */   }
/*     */ 
/*     */   public static JComboBox getEditorContextVarName(WorkflowTemplate workflow) {
/* 254 */     JComboBox comboBox = new JComboBox();
/* 255 */     List list = workflow.getVars();
/* 256 */     comboBox.addItem("");
/* 257 */     for (int i = 0; i < innerContexts.length; ++i) {
/* 258 */       comboBox.addItem(innerContexts[i]);
/*     */     }
/* 260 */     for (Iterator it = list.iterator(); it.hasNext(); ) {
/* 261 */       comboBox.addItem(((ParameterDefine)it.next()).name);
/*     */     }
/*     */ 
/* 264 */     return comboBox;
/*     */   }
/*     */ 
/*     */   private static String toSvgLineEnd(Point src, Point dst) {
/* 268 */     src = new Point(src);
/* 269 */     dst = new Point(dst);
/* 270 */     int size = 10;
/* 271 */     int d = (int)Math.max(1.0D, dst.distance(src));
/* 272 */     int ax = -(size * (dst.x - src.x) / d);
/* 273 */     int ay = -(size * (dst.y - src.y) / d);
/*     */ 
/* 275 */     String result = "<polygon fill='black' stroke='black'  points='" + dst.x + "," + dst.y + " " + (dst.x + ax + ay / 2) + "," + (dst.y + ay - ax / 2) + " ";
/*     */ 
/* 278 */     Point last = new Point(dst);
/* 279 */     dst.setLocation(dst.x + ax * 2 / 3, dst.y + ay * 2 / 3);
/* 280 */     result = result + dst.x + "," + dst.y + " " + (last.x + ax - ay / 2) + "," + (last.y + ay + ax / 2) + "'/>";
/*     */ 
/* 282 */     return result;
/*     */   }
/*     */ 
/*     */   private static String toSvg(Point aLabelPosition, String aLabel, ArrayList aPoints, String aColor) {
/* 286 */     StringBuffer str = new StringBuffer();
/*     */ 
/* 289 */     for (int i = 0; i < aPoints.size() - 1; ++i) {
/* 290 */       Point p1 = (Point)aPoints.get(i);
/* 291 */       Point p2 = (Point)aPoints.get(i + 1);
/* 292 */       str.append("<line  stroke='").append(aColor).append("'");
/* 293 */       str.append(" x1 =\"" + p1.x + "\"");
/* 294 */       str.append(" y1 =\"" + p1.y + "\"");
/* 295 */       str.append(" x2 =\"" + p2.x + "\"");
/* 296 */       str.append(" y2 =\"" + p2.y + "\"");
/* 297 */       str.append("  stroke-width=\"1\"  />\n");
/*     */     }
/* 299 */     int n = aPoints.size();
/* 300 */     str.append(toSvgLineEnd((Point)aPoints.get(n - 2), (Point)aPoints.get(n - 1)));
/*     */ 
/* 302 */     if (aLabel != null) {
/* 303 */       str.append("<text x=\"").append(aLabelPosition.x).append("\"").append(" y=\"").append(aLabelPosition.y).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" style=\"text-anchor: middle\">").append(aLabel).append("</text>\n");
/*     */     }
/*     */ 
/* 313 */     return str.toString();
/*     */   }
/*     */ 
/*     */   private static String toSvgOfTaskCircleCell(Rectangle rect, String aColor, long templateId, String taskId, String childCode, String aText, String taskType, int state, String taskTag)
/*     */   {
/* 318 */     StringBuffer _str = new StringBuffer();
/* 319 */     _str.append("\n <ellipse onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" style=\"fill:url(#").append(aColor).append(");");
/*     */ 
/* 323 */     _str.append(" stroke:black;  stroke-width:").append(1).append("\"");
/* 324 */     _str.append(" cx=\"").append(rect.getCenterX()).append("\" ");
/* 325 */     _str.append(" cy=\"").append(rect.getCenterY()).append("\" ");
/* 326 */     _str.append(" rx=\"").append(rect.width / 2).append("\" ");
/* 327 */     _str.append(" ry=\"").append(rect.height / 2).append("\" ");
/* 328 */     double r = 0.0D;
/* 329 */     if (rect.getWidth() < rect.getHeight())
/* 330 */       r = rect.getWidth() / 2.0D;
/*     */     else {
/* 332 */       r = rect.getHeight() / 2.0D;
/*     */     }
/* 334 */     _str.append(" r=\"").append(r).append("\" ");
/* 335 */     _str.append("/> \n");
/* 336 */     _str.append("<text onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" x=\"").append(rect.getCenterX()).append("\"").append(" y=\"").append(rect.getCenterY() + 3.0D).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" style=\"text-anchor: middle\">").append(encode(aText, "UTF-8")).append("</text>");
/*     */ 
/* 347 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toSvgOfRectangleCell(Rectangle rect, String aColor, long templateId, String taskId, String childCode, String aText, String taskType, int state, String taskTag) {
/* 351 */     StringBuffer _str = new StringBuffer();
/* 352 */     _str.append("<rect onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" style=\"fill:url(#" + aColor + ");");
/*     */ 
/* 356 */     _str.append(" stroke:black;  stroke-width:").append(1).append("\"");
/* 357 */     _str.append(" x=\"").append(rect.x).append("\" ");
/* 358 */     _str.append(" y=\"").append(rect.y).append("\" ");
/* 359 */     _str.append("rx=\"").append("7").append("\" ");
/* 360 */     _str.append("ry=\"").append("7").append("\" ");
/* 361 */     _str.append(" width=\"").append(rect.width).append("\" ");
/* 362 */     _str.append(" height=\"").append(rect.height).append("\" ");
/* 363 */     _str.append("/> \n");
/*     */ 
/* 365 */     _str.append("<text onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" x=\"").append((int)rect.getCenterX()).append("\"").append(" y=\"").append((int)rect.getCenterY() + 3).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" style=\"text-anchor: middle\">").append(encode(aText, "UTF-8")).append("</text>\n");
/*     */ 
/* 375 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toSvgOfPolygonCell(Rectangle rect, String aColor, long templateId, String taskId, String childCode, String aText, String taskType, int state, String taskTag) {
/* 379 */     StringBuffer _str = new StringBuffer();
/* 380 */     _str.append("<polygon onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" style=\"fill:url(#" + aColor + ");");
/*     */ 
/* 384 */     _str.append(" stroke:black;  stroke-width:").append(1).append("\"");
/* 385 */     _str.append(" points=\"");
/* 386 */     _str.append(rect.x + "," + (rect.y + rect.getHeight() / 2.0D) + " ");
/* 387 */     _str.append(rect.x + rect.getWidth() / 2.0D + "," + rect.y + " ");
/* 388 */     _str.append(rect.x + rect.getWidth() + "," + (rect.y + rect.getHeight() / 2.0D) + " ");
/* 389 */     _str.append(rect.x + rect.getWidth() / 2.0D + "," + (rect.y + rect.getHeight()));
/* 390 */     _str.append("\"");
/* 391 */     _str.append("/> \n");
/*     */ 
/* 393 */     _str.append("<text onclick=\"svgClick(").append(templateId).append(",'").append(aText).append("','").append(taskId).append("','").append(childCode).append("','").append(taskType).append("',").append(state).append(",'").append(taskTag).append("'").append(")\" x=\"").append((int)rect.getCenterX()).append("\"").append(" y=\"").append((int)rect.getCenterY() + 3).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" style=\"text-anchor: middle\">").append(encode(aText, "UTF-8")).append("</text>\n");
/*     */ 
/* 403 */     return _str.toString();
/*     */   }
/*     */ 
/*     */   private static String toSvgOfRole(Rectangle rect, String label) {
/* 407 */     StringBuffer str = new StringBuffer();
/*     */ 
/* 409 */     if (rect.height > rect.width) {
/* 410 */       str.append("<line  stroke='gray'");
/* 411 */       str.append(" x1 =\"" + rect.x + "\"");
/* 412 */       str.append(" y1 =\"" + rect.y + "\"");
/* 413 */       str.append(" x2 =\"" + rect.x + "\"");
/* 414 */       str.append(" y2 =\"" + (rect.y + rect.height) + "\"");
/* 415 */       str.append(" stroke-dasharray=\"5 5\"");
/* 416 */       str.append(" stroke-width=\"1\"  />\n");
/*     */ 
/* 418 */       str.append("<line  stroke='gray'");
/* 419 */       str.append(" x1 =\"" + (rect.x + rect.width) + "\"");
/* 420 */       str.append(" y1 =\"" + rect.y + "\"");
/* 421 */       str.append(" x2 =\"" + (rect.x + rect.width) + "\"");
/* 422 */       str.append(" y2 =\"" + (rect.y + rect.height) + "\"");
/* 423 */       str.append(" stroke-dasharray=\"5 5\"");
/* 424 */       str.append(" stroke-width=\"1\"  />\n");
/*     */ 
/* 426 */       str.append("<rect fill=\"url(#gray)\"");
/* 427 */       str.append(" stroke=\"gray\"  stroke-width=\"").append(1).append("\"");
/* 428 */       str.append(" x=\"").append(rect.x).append("\" ");
/* 429 */       str.append(" y=\"").append(rect.y).append("\" ");
/* 430 */       str.append(" width=\"").append(rect.width).append("\" ");
/* 431 */       str.append(" height=\"").append(25).append("\" ");
/* 432 */       str.append("/> \n");
/*     */ 
/* 434 */       str.append("<text x=\"").append((rect.x * 2 + rect.width) / 2).append("\"").append(" y=\"").append(rect.y + 20).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" style=\"text-anchor: middle\">").append(encode(label, "UTF-8")).append("</text>\n");
/*     */     }
/*     */     else
/*     */     {
/* 443 */       str.append("<line  stroke='gray'");
/* 444 */       str.append(" x1 =\"" + rect.x + "\"");
/* 445 */       str.append(" y1 =\"" + rect.y + "\"");
/* 446 */       str.append(" x2 =\"" + (rect.x + rect.width) + "\"");
/* 447 */       str.append(" y2 =\"" + rect.y + "\"");
/* 448 */       str.append(" stroke-dasharray=\"5 5\"");
/* 449 */       str.append(" stroke-width=\"1\"  />\n");
/*     */ 
/* 451 */       str.append("<line  stroke='gray'");
/* 452 */       str.append(" x1 =\"" + rect.x + "\"");
/* 453 */       str.append(" y1 =\"" + (rect.y + rect.height) + "\"");
/* 454 */       str.append(" x2 =\"" + (rect.x + rect.width) + "\"");
/* 455 */       str.append(" y2 =\"" + (rect.y + rect.height) + "\"");
/* 456 */       str.append(" stroke-dasharray=\"5 5\"");
/* 457 */       str.append(" stroke-width=\"1\"  />\n");
/*     */ 
/* 459 */       str.append("<rect fill=\"url(#gray)\"");
/* 460 */       str.append(" stroke=\"gray\"  stroke-width=\"").append(1).append("\"");
/* 461 */       str.append(" x=\"").append(rect.x).append("\" ");
/* 462 */       str.append(" y=\"").append(rect.y).append("\" ");
/* 463 */       str.append(" width=\"").append(25).append("\" ");
/* 464 */       str.append(" height=\"").append(rect.height).append("\" ");
/* 465 */       str.append("/> \n");
/*     */ 
/* 467 */       str.append("<text x=\"").append(rect.x + 20).append("\"").append(" y=\"").append((rect.y * 2 + rect.height) / 2).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"black\"").append(" writing-mode=\"tb\" glyph-orientation-vertical=\"270\"").append(" style=\"text-anchor: middle\">").append(encode(label, "UTF-8")).append("</text>\n");
/*     */     }
/*     */ 
/* 476 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public static String toSvg(TaskTemplate task, int state, String taskId, XYScale xyScale)
/*     */   {
/* 481 */     String[] list = StringUtils.split(task.getUIInfo(), ',');
/*     */     Rectangle rect;
/*     */     Rectangle rect;
/* 483 */     if (list.length >= 4) {
/* 484 */       rect = new Rectangle((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]), (int)Double.parseDouble(list[2]), (int)Double.parseDouble(list[3]));
/*     */     }
/*     */     else
/*     */     {
/* 489 */       rect = new Rectangle(10, 10, 60, 30);
/*     */     }
/* 491 */     xyScale.minX = ((xyScale.minX < rect.getMinX()) ? xyScale.minX : rect.getMinX());
/* 492 */     xyScale.minY = ((xyScale.minY < rect.getMinY()) ? xyScale.minY : rect.getMinY());
/* 493 */     xyScale.maxX = ((xyScale.maxX > rect.getMaxX()) ? xyScale.maxX : rect.getMaxX());
/* 494 */     xyScale.maxY = ((xyScale.maxY > rect.getMaxY()) ? xyScale.maxY : rect.getMaxY());
/*     */ 
/* 496 */     String childWorkflowCode = "";
/* 497 */     if (task instanceof TaskWorkflowTemplate) {
/* 498 */       childWorkflowCode = ((TaskWorkflowTemplate)task).getWorkflowCode();
/*     */     }
/* 500 */     String taskType = TaskConfig.getInstance().getBasalType(task.getTaskType());
/* 501 */     String taskTag = task.getTaskTag();
/*     */ 
/* 503 */     if (task instanceof TaskStartTemplate) {
/* 504 */       return toSvgOfTaskCircleCell(rect, getBackgroudString(task, state), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag);
/*     */     }
/* 506 */     if (task instanceof TaskFinishTemplate) {
/* 507 */       return toSvgOfTaskCircleCell(rect, getBackgroudString(task, state), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag);
/*     */     }
/* 509 */     if (task instanceof TaskDecisionTemplate) {
/* 510 */       return toSvgOfPolygonCell(rect, getBackgroudString(task, state), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag);
/*     */     }
/* 512 */     if (task instanceof TaskDecisionAutoTemplate) {
/* 513 */       return toSvgOfPolygonCell(rect, getBackgroudString(task, state), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag);
/*     */     }
/*     */ 
/* 516 */     return toSvgOfRectangleCell(rect, getBackgroudString(task, state), task.getTaskTemplateId(), taskId, childWorkflowCode, task.getDisplayText(), taskType, state, taskTag);
/*     */   }
/*     */ 
/*     */   public static String toSvg(JoinTemplate join, XYScale xyScale)
/*     */   {
/* 521 */     Point labelPosition = null;
/* 522 */     ArrayList points = new ArrayList();
/* 523 */     String[] list = StringUtils.split(join.getUIInfo(), ',');
/* 524 */     if (list.length > 0) {
/* 525 */       labelPosition = new Point((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]));
/* 526 */       labelPosition.x = Math.abs(labelPosition.x - 500);
/* 527 */       labelPosition.y = Math.abs(labelPosition.y - 500);
/*     */ 
/* 529 */       int length = list.length / 2;
/* 530 */       for (int i = 2; i < length; ++i) {
/* 531 */         double x = Double.parseDouble(list[(i * 2)]);
/* 532 */         double y = Double.parseDouble(list[(i * 2 + 1)]);
/* 533 */         points.add(new Point((int)x, (int)y));
/* 534 */         xyScale.minX = ((xyScale.minX < x) ? xyScale.minX : x);
/* 535 */         xyScale.minY = ((xyScale.minY < y) ? xyScale.minY : y);
/* 536 */         xyScale.maxX = ((xyScale.maxX > x) ? xyScale.maxX : x);
/* 537 */         xyScale.maxY = ((xyScale.maxY > y) ? xyScale.maxY : y);
/*     */       }
/*     */     }
/* 540 */     if (points.size() > 2) {
/* 541 */       labelPosition = (Point)points.get(1);
/*     */     }
/* 543 */     else if (points.size() == 2) {
/* 544 */       Point p1 = (Point)points.get(0);
/* 545 */       Point p2 = (Point)points.get(1);
/* 546 */       labelPosition.x = ((int)(p1.getX() + p2.getX()) / 2);
/* 547 */       labelPosition.y = ((int)(p1.getY() + p2.getY()) / 2);
/*     */     }
/*     */     else {
/* 550 */       return "";
/*     */     }
/* 552 */     String color = "black";
/*     */ 
/* 557 */     return toSvg(labelPosition, join.getCondition(), points, color);
/*     */   }
/*     */ 
/*     */   public static String toSvg(RoleTemplate task, XYScale xyScale) {
/* 561 */     String[] list = StringUtils.split(task.getUIInfo(), ',');
/*     */     Rectangle rect;
/*     */     Rectangle rect;
/* 563 */     if (list.length >= 4) {
/* 564 */       rect = new Rectangle((int)Double.parseDouble(list[0]), (int)Double.parseDouble(list[1]), (int)Double.parseDouble(list[2]), (int)Double.parseDouble(list[3]));
/*     */     }
/*     */     else
/*     */     {
/* 569 */       rect = new Rectangle(10, 10, 150, 500);
/*     */     }
/* 571 */     xyScale.minX = ((xyScale.minX < rect.getMinX()) ? xyScale.minX : rect.getMinX());
/* 572 */     xyScale.minY = ((xyScale.minY < rect.getMinY()) ? xyScale.minY : rect.getMinY());
/* 573 */     xyScale.maxX = ((xyScale.maxX > rect.getMaxX()) ? xyScale.maxX : rect.getMaxX());
/* 574 */     xyScale.maxY = ((xyScale.maxY > rect.getMaxY()) ? xyScale.maxY : rect.getMaxY());
/*     */ 
/* 576 */     return toSvgOfRole(rect, task.getLabel());
/*     */   }
/*     */ 
/*     */   public static String toSvg(WorkflowTemplate workflow, String encoding) {
/* 580 */     if ((encoding == null) || (StringUtils.isEmptyString(encoding))) {
/* 581 */       encoding = "utf-8";
/*     */     }
/* 583 */     StringBuffer tmp = new StringBuffer();
/*     */      tmp33_30 = new VMUtil(); tmp33_30.getClass(); XYScale xyScale = new XYScale();
/* 585 */     xyScale.minX = 500.0D;
/* 586 */     xyScale.minY = 500.0D;
/* 587 */     JoinTemplate[] joins = workflow.getJoinTemplates();
/* 588 */     for (int i = 0; i < joins.length; ++i) {
/* 589 */       tmp.append(toSvg(joins[i], xyScale));
/*     */     }
/* 591 */     TaskTemplate[] tasks = workflow.getTaskTemplates();
/* 592 */     for (int i = 0; i < tasks.length; ++i) {
/* 593 */       tmp.append(toSvg(tasks[i], -1, null, xyScale));
/*     */     }
/* 595 */     RoleTemplate[] roles = workflow.getRoleTemplates();
/* 596 */     for (int i = 0; i < roles.length; ++i) {
/* 597 */       tmp.append(toSvg(roles[i], xyScale));
/*     */     }
/*     */ 
/* 600 */     int svgWidth = 15;
/* 601 */     int svgHeight = 15;
/*     */ 
/* 603 */     if (xyScale.maxX < 500.0D) {
/* 604 */       svgWidth = 8;
/* 605 */       xyScale.minX -= 100.0D;
/* 606 */       xyScale.maxX += 100.0D;
/*     */     }
/* 608 */     if (xyScale.maxY < 500.0D) {
/* 609 */       svgHeight = 8;
/* 610 */       xyScale.minY -= 50.0D;
/* 611 */       xyScale.maxY += 100.0D;
/*     */     }
/*     */ 
/* 614 */     StringBuffer svgxml = new StringBuffer();
/* 615 */     svgxml.append("<?xml version=\"1.0\" encoding='" + encoding + "' standalone=\"no\" ?>\n");
/* 616 */     svgxml.append("<svg width=\"" + svgWidth + "cm\" height=\"" + svgHeight + "cm\"").append(" viewBox=\"").append(xyScale.minX - 10.0D).append(" ").append(xyScale.minY - 10.0D).append(" ").append(xyScale.maxX - xyScale.minX + 20.0D).append(" ").append(xyScale.maxY - xyScale.minY + 20.0D).append("\" ");
/*     */ 
/* 621 */     svgxml.append("xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" >\n");
/* 622 */     svgxml.append("<script><![CDATA[function svgClick(taskTemplateId,taskLabel,taskId,childCode,taskType,state,taskTag){var clickFunc = null;").append("try{if(evt.detail==2){eval(\"clickFunc=onSvgClick\");}}catch(e){clickFunc = null;}\n").append("if(clickFunc != null){clickFunc(taskTemplateId,taskLabel,taskId,childCode,taskType,state,taskTag);}}\n").append("]]></script>\n");
/*     */ 
/* 626 */     svgxml.append("<rect x=\"-2000%\" y=\"-2000%\" height=\"4000%\" width=\"4000%\" style=\"fill:yellow;fill-opacity:0.2\"/>");
/* 627 */     svgxml.append(svgColorDefine());
/* 628 */     svgxml.append(tmp);
/* 629 */     svgxml.append("</svg>");
/* 630 */     String svgXml = svgxml.toString();
/* 631 */     svgXml = svgXml.replaceAll("&", "&amp;");
/* 632 */     return svgXml;
/*     */   }
/*     */   public static String toSvg(FlowBase workflow) {
/* 635 */     StringBuffer tmp = new StringBuffer();
/*     */      tmp19_16 = new VMUtil(); tmp19_16.getClass(); XYScale xyScale = new XYScale();
/* 638 */     xyScale.minX = 500.0D;
/* 639 */     xyScale.minY = 500.0D;
/* 640 */     JoinTemplate[] joins = workflow.getWorkflowTemplate().getJoinTemplates();
/* 641 */     for (int i = 0; i < joins.length; ++i) {
/* 642 */       tmp.append(toSvg(joins[i], xyScale));
/*     */     }
/* 644 */     TaskTemplate[] tasks = workflow.getWorkflowTemplate().getTaskTemplates();
/* 645 */     for (int i = 0; i < tasks.length; ++i) {
/* 646 */       Task taskInstance = workflow.getTaskByTemplateId(tasks[i].getTaskTemplateId());
/* 647 */       if (taskInstance == null) {
/* 648 */         tmp.append(toSvg(tasks[i], tasks[i].getState(), null, xyScale));
/*     */       }
/*     */       else {
/* 651 */         tmp.append(toSvg(tasks[i], taskInstance.getState(), taskInstance.getTaskId(), xyScale));
/*     */       }
/*     */     }
/* 654 */     RoleTemplate[] roles = workflow.getWorkflowTemplate().getRoleTemplates();
/* 655 */     for (int i = 0; i < roles.length; ++i) {
/* 656 */       tmp.append(toSvg(roles[i], xyScale));
/*     */     }
/*     */ 
/* 660 */     String parentTaskId = workflow.getParentTaskId();
/* 661 */     int workflowType = workflow.getWorkflowKind();
/* 662 */     String parentWorkflowId = null;
/*     */     try {
/* 664 */       if (workflowType == 1) {
/* 665 */         IBOVmTaskValue parentTaskBean = WorkflowEngineFactory.getInstance().getTaskBean(parentTaskId);
/* 666 */         if (parentTaskBean != null) {
/* 667 */           parentWorkflowId = parentTaskBean.getWorkflowId();
/*     */         }
/*     */       }
/* 670 */       else if (workflowType == 2) {
/* 671 */         parentWorkflowId = parentTaskId;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 675 */       throw new RuntimeException(e);
/*     */     }
/*     */ 
/* 678 */     int svgWidth = 15;
/* 679 */     int svgHeight = 15;
/*     */ 
/* 681 */     if (xyScale.maxX < 500.0D) {
/* 682 */       svgWidth = 8;
/* 683 */       xyScale.minX -= 100.0D;
/* 684 */       xyScale.maxX += 100.0D;
/*     */     }
/* 686 */     if (xyScale.maxY < 500.0D) {
/* 687 */       svgHeight = 8;
/* 688 */       xyScale.minY -= 50.0D;
/* 689 */       xyScale.maxY += 100.0D;
/*     */     }
/*     */ 
/* 692 */     StringBuffer svgxml = new StringBuffer();
/* 693 */     svgxml.append("<?xml version=\"1.0\" encoding='UTF-8' standalone=\"no\" ?>\n");
/* 694 */     svgxml.append("<svg width=\"" + svgWidth + "cm\" height=\"" + svgHeight + "cm\"").append(" viewBox=\"").append(xyScale.minX - 10.0D).append(" ").append(xyScale.minY - 10.0D).append(" ").append(xyScale.maxX - xyScale.minX + 20.0D).append(" ").append(xyScale.maxY - xyScale.minY + 20.0D).append("\" ");
/*     */ 
/* 699 */     svgxml.append("xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" >\n");
/* 700 */     svgxml.append("<script><![CDATA[function svgClick(taskTemplateId,taskLabel,taskId,childCode,taskType,state,taskTag){var clickFunc = null;").append("try{if(evt.detail==2){eval(\"clickFunc=onSvgClick\");}}catch(e){clickFunc = null;}\n").append("if(clickFunc != null){clickFunc(taskTemplateId,taskLabel,taskId,childCode,taskType,state,taskTag);}}\n").append("function btnClick(parentWorkflowId){var btnFunc = null;").append("try{eval(\"btnFunc=showParentSVG\");}catch(e){btnFunc = null;}\n").append("if(btnFunc != null){btnFunc(parentWorkflowId);}else{alert(\"").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.toSvg_unRealizeMethod")).append("showParentSVG(parentWorkflowId)\");}}\n").append("]]></script>\n");
/*     */ 
/* 708 */     svgxml.append("<rect x=\"-2000%\" y=\"-2000%\" height=\"4000%\" width=\"4000%\" style=\"fill:yellow;fill-opacity:0.2\"/>");
/* 709 */     svgxml.append(svgColorDefine());
/* 710 */     svgxml.append(tmp);
/*     */ 
/* 712 */     if (parentWorkflowId != null) {
/* 713 */       StringBuffer _str = new StringBuffer();
/* 714 */       _str.append("<text onclick=\"btnClick('").append(parentWorkflowId).append("')\" x=\"").append(xyScale.maxX).append("\"").append(" y=\"").append(xyScale.maxY).append("\"").append(" font-family=\"" + FONT_FAMILY + "\"").append(" fill=\"blue\"").append(" font-size=\"8\"").append(" style=\"text-anchor: middle\">").append(encode(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.toSvg_showFatherProcess"), "UTF-8")).append("</text>\n");
/*     */ 
/* 724 */       _str.append("<line  stroke='blue'").append(" x1 =\"" + (xyScale.maxX - 20.0D) + "\"").append(" y1 =\"" + (xyScale.maxY + 2.0D) + "\"").append(" x2 =\"" + (xyScale.maxX + 20.0D) + "\"").append(" y2 =\"" + (xyScale.maxY + 2.0D) + "\"").append(" stroke-width=\"1\"  />\n");
/*     */ 
/* 730 */       svgxml.append(_str);
/*     */     }
/*     */ 
/* 733 */     svgxml.append("</svg>");
/* 734 */     String svgXml = svgxml.toString();
/* 735 */     svgXml = svgXml.replaceAll("&", "&amp;");
/* 736 */     return svgXml;
/*     */   }
/*     */   public static Throwable getRootException(Throwable e) {
/* 739 */     while (e.getCause() != null) {
/* 740 */       e = e.getCause();
/*     */     }
/* 742 */     return e;
/*     */   }
/*     */   public static String getErrorMessageFromException(Throwable e) {
/* 745 */     while (e.getCause() != null) {
/* 746 */       e = e.getCause();
/*     */     }
/*     */ 
/* 749 */     StringBuffer sb = new StringBuffer();
/* 750 */     sb.append(e).append("\n");
/* 751 */     StackTraceElement[] stack = e.getStackTrace();
/* 752 */     for (int i = 0; i < stack.length; ++i) {
/* 753 */       sb.append(stack[i].getClassName() + "." + stack[i].getMethodName() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.VMUtil.toSvg_line") + stack[i].getLineNumber() + "\n");
/*     */     }
/*     */ 
/* 756 */     if (sb.length() > 1000) {
/* 757 */       sb.setLength(1000);
/*     */     }
/* 759 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String encode(String s, String enc)
/*     */   {
/* 770 */     s = StringUtils.replace(s, ">", "&gt;");
/*     */ 
/* 772 */     s = StringUtils.replace(s, "<", "&lt;");
/*     */ 
/* 774 */     s = StringUtils.replace(s, "'", "&apos");
/*     */ 
/* 776 */     s = StringUtils.replace(s, "\"", "&quot;");
/* 777 */     return s;
/*     */   }
/*     */ 
/*     */   public static String uniteChildWorkflowOutValues(String contextVarName, WorkflowContext workflowContext, Object currentValue, String taskId, String childWorkflowId)
/*     */     throws Exception
/*     */   {
/* 798 */     String returnStr = "";
/*     */ 
/* 801 */     Object oldValue = workflowContext.get(contextVarName);
/*     */ 
/* 803 */     if ((currentValue != null) && (!StringUtils.isEmptyString(currentValue.toString())))
/*     */     {
/* 805 */       returnStr = childWorkflowId + ":" + currentValue.toString();
/*     */     }
/*     */ 
/* 808 */     if ((oldValue != null) && (!StringUtils.isEmptyString(oldValue.toString())))
/*     */     {
/* 811 */       String parentTaskId = getParentTaskId(oldValue.toString());
/*     */ 
/* 813 */       if ((parentTaskId != null) && (parentTaskId.equals(String.valueOf(taskId))))
/*     */       {
/* 815 */         if (StringUtils.isEmptyString(returnStr))
/*     */         {
/* 817 */           returnStr = oldValue.toString();
/*     */         }
/*     */         else
/*     */         {
/* 821 */           returnStr = oldValue.toString() + ";" + returnStr;
/*     */         }
/*     */ 
/*     */       }
/* 826 */       else if (!StringUtils.isEmptyString(returnStr))
/*     */       {
/* 828 */         returnStr = String.valueOf(taskId) + "_" + returnStr;
/*     */       }
/*     */ 
/*     */     }
/* 832 */     else if (!StringUtils.isEmptyString(returnStr))
/*     */     {
/* 834 */       returnStr = String.valueOf(taskId) + "_" + returnStr;
/*     */     }
/* 836 */     return returnStr;
/*     */   }
/*     */ 
/*     */   public static Map getChildWorkflowReturnVar(WorkflowContext workflowContext, String varName)
/*     */     throws Exception
/*     */   {
/* 849 */     Map resultMap = new HashMap();
/* 850 */     Object varValue = workflowContext.get(varName);
/* 851 */     if ((varValue != null) && (!StringUtils.isEmptyString(varValue.toString())))
/*     */     {
/* 853 */       String[] splitVals = varValue.toString().split(";");
/* 854 */       String temp = "";
/* 855 */       for (int i = 0; i < splitVals.length; ++i) {
/* 856 */         temp = splitVals[i];
/* 857 */         if (temp.indexOf(":") > 0) {
/* 858 */           if (temp.indexOf("_") > 0)
/*     */           {
/* 860 */             resultMap.put(temp.substring(temp.indexOf("_") + 1, temp.indexOf(":")), temp.substring(temp.indexOf(":") + 1));
/*     */           }
/*     */           else
/*     */           {
/* 865 */             resultMap.put(temp.substring(0, temp.indexOf(":")), temp.substring(temp.indexOf(":") + 1));
/*     */           }
/*     */         }
/*     */         else {
/* 869 */           if (resultMap.containsKey(varName))
/* 870 */             varName = varName + i;
/* 871 */           resultMap.put(varName, temp);
/*     */         }
/*     */       }
/*     */     }
/* 875 */     return resultMap;
/*     */   }
/*     */ 
/*     */   private static String getParentTaskId(String oldValue) throws Exception {
/* 879 */     String result = "";
/* 880 */     String[] oldValues = oldValue.split(";");
/* 881 */     if (oldValues.length > 0) {
/* 882 */       String key = oldValues[0];
/* 883 */       if ((key.indexOf("_") > 0) && (key.indexOf(":") > 0))
/* 884 */         result = key.substring(0, key.indexOf("_"));
/*     */     }
/* 886 */     return result; } 
/*     */   class XYScale { double minX;
/*     */     double maxX;
/*     */     double minY;
/*     */     double maxY;
/*     */ 
/* 890 */     XYScale() { this.minX = 0.0D;
/* 891 */       this.maxX = 0.0D;
/* 892 */       this.minY = 0.0D;
/* 893 */       this.maxY = 0.0D; }
/*     */  }
/*     */ 
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.VMUtil
 * JD-Core Version:    0.5.4
 */