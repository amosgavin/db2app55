/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ 
/*     */ public abstract interface Constant
/*     */ {
/*     */   public static final int S_STATE_DISABLED = 1;
/*     */   public static final int S_STATE_ENABLED = 2;
/*     */   public static final int S_STATE_FINISHED = 3;
/*     */   public static final int S_STATE_TERMINATE = 4;
/*     */   public static final int S_STATE_ACTIVE = 5;
/*     */   public static final int S_STATE_BACK = 6;
/*     */   public static final int S_STATE_WAIT = 7;
/*     */   public static final int S_STATE_EXPIRED = 8;
/*     */   public static final int S_STATE_WAIT_PRINT = 9;
/*     */   public static final int S_STATE_REAUTHORIZE = 10;
/*     */   public static final int S_STATE_ABEND = 11;
/*     */   public static final int S_STATE_BUSIEXCEPTION = 98;
/*     */   public static final int S_STATE_EXCEPTION = 99;
/*     */   public static final int S_STATE_WAIT_EXCEPTION_FINISH = 97;
/*     */   public static final char S_SCHEDULE_STATE_F = 'F';
/*     */   public static final char S_SCHEDULE_STATE_W = 'W';
/*     */   public static final char S_SCHEDULE_STATE_S = 'S';
/*     */   public static final char S_SCHEDULE_STATE_E = 'E';
/*     */   public static final char S_SCHEDULE_STATE_T = 'T';
/*     */   public static final char S_SCHEDULE_STATE_A = 'A';
/*     */   public static final int S_STATE_WAIT_CREATE_SCHEDULESERVER_INSTANCE = 20;
/*     */   public static final int S_STATE_HAS_FINISH_SCHEDULESERVER_TASK = 21;
/*     */   public static final String TASK_TYPE_START = "start";
/*     */   public static final String TASK_TYPE_AUTO = "auto";
/*     */   public static final String TASK_TYPE_AND = "and";
/*     */   public static final String TASK_TYPE_OR = "or";
/*     */   public static final String TASK_TYPE_TIMER = "timer";
/*     */   public static final String TASK_TYPE_DECISION = "decision";
/*     */   public static final String TASK_TYPE_AUTODECISION = "autodecision";
/*     */   public static final String TASK_TYPE_USER = "user";
/*     */   public static final String TASK_TYPE_FINISH = "finish";
/*     */   public static final String TASK_TYPE_WORKFLOW = "workflow";
/*     */   public static final String TASK_TYPE_SENDMAIL = "sendmail";
/*     */   public static final String TASK_TYPE_SIGN = "sign";
/*     */   public static final String TASK_TYPE_FORK = "fork";
/*     */   public static final String TASK_BASE_TYPE_CHILDWORKFLOW = "childworkflow";
/*     */   public static final char TASK_RESULT_SUCESS = 'S';
/*     */   public static final char TASK_RESULT_FAIL = 'F';
/*     */   public static final char TASK_RESULT_PAUSE = 'P';
/*     */   public static final char TASK_RESULT_DELETE = 'D';
/*     */   public static final String DEST_TYPE_GOBACK = "B";
/*     */   public static final String DEST_TYPE_JUMPTO = "J";
/*     */   public static final int S_JOIN_TYPE_SEQUENCE = 1;
/*     */   public static final int S_JOIN_TYPE_IF = 2;
/*     */   public static final int WORKFLOW_TYPE_CHILDWORKFLOW = 1;
/*     */   public static final int WORKFLOW_TYPE_EXCEPTIONWORKFLOW = 2;
/*     */   public static final long STATIC_DATA_WORKFLOW_OBJTYPE = 101L;
/*     */   public static final String S_TYPE_STAFF = "staff";
/*     */   public static final String S_TYPE_STATION = "station";
/*     */   public static final String S_TYPE_STATION_TYPE = "stationType";
/*  71 */   public static final String[][] WORKFLOW_STATE = { { "1", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_noSchedule") }, { "2", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_schedule") }, { "3", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_complate") }, { "4", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_end") }, { "5", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_manualHandling") }, { "7", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitingEvent") }, { "8", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_expired") }, { "9", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitPrint") }, { "98", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_businessException") }, { "99", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_systemException") }, { "97", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitProcessEnd") } };
/*     */ 
/*  85 */   public static final int[] WORKFLOW_HIS_STATE = { 3, 4, 8 };
/*     */ 
/*  91 */   public static final String[][] TASK_STATE = { { "1", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_noSchedule") }, { "2", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_schedule") }, { "3", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_complate") }, { "4", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_end") }, { "5", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_manualHandling") }, { "6", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_STATE_taskBack") }, { "7", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitingEvent") }, { "8", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_expired") }, { "9", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitPrint") }, { "10", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_STATE_taskTrans") }, { "11", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_STATE_overException") }, { "98", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_businessException") }, { "99", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_systemException") }, { "97", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_waitProcessEnd") }, { "20", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_STATE_waitProcessTask") }, { "21", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_STATE_returnedTask") } };
/*     */ 
/* 110 */   public static final String[][] WORKFLOW_ACTION = { { "suspendWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_processHold"), "2" }, { "resumeWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_retrieveProcess"), "1" }, { "cancelWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_cancelProcess"), "2,5" }, { "terminateWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_endProcess"), "2,1,98,99" }, { "stopWarningWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_stopWarn"), "2" }, { "startExceptionWorkFlow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_startUnnormalProcess"), "5" }, { "resumeExceptionWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_redoException"), "99" }, { "setWorkflowVars", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_setProcessVars"), "2,1,98,99" }, { "dropWorkflow", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_delProcessData"), "" }, { "getWorkflowVars", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_getProcessData"), "" }, { "toSvg", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_svgMonitor"), "" }, { "toDojo", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_dojoMonitor"), "" } };
/*     */ 
/* 124 */   public static final String[][] TASK_ACTION = { { "lockTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_lockTask"), "2", "9,5" }, { "releaseTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_releaseLock"), "2", "9,5" }, { "printUserTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_printTask"), "2", "9" }, { "finishUserTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_returnHandle"), "2", "5" }, { "stopWarningTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_stopWarn"), "2", "9,5" }, { "jumpToTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_jumpToNode"), "2,99", "9,5,2" }, { "goBackToTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_backToNode"), "2,99", "9,5,2" }, { "reAuthorizeTask", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_authorizeTask"), "2", "9,5" }, { "fireException", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_releaseProcessException"), "2,99", "9,5,2" } };
/*     */ 
/* 136 */   public static final String[][] TASKTRANS_ACTION = { { "lockTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_lockTask"), "2", "9,5" }, { "releaseTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_releaseLock"), "2", "9,5" }, { "printTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_printTask"), "2", "9" }, { "finishTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_returnHandle"), "2", "5,9" }, { "stopWarningTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_ACTION_stopWarn"), "2", "9,5" }, { "reAuthorizeTaskTrans", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_authorizeTask"), "2", "9,5" }, { "fireException", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.TASK_ACTION_releaseProcessException"), "2,99", "9,5,2" } };
/*     */ 
/* 146 */   public static final String[][] VM_DEAL_TYPE = { { "workflow", "workflow" }, { "timer", "timer" }, { "exception", "exception" }, { "warning", "warning" } };
/*     */ 
/* 153 */   public static final String S_STATE_FINISHED_I18N = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskAutoImpl.executeInner_taskComplete");
/* 154 */   public static final String S_STATE_ACTIVE_I18N = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_waitChildProcess");
/* 155 */   public static final String S_STATE_noChildProcessEnd_I18N = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_noChildProcessEnd");
/* 156 */   public static final String S_STATE_childBusinessProcess_I18N = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_childBusinessProcess");
/*     */   public static final String S_COMFRAME_DEV_NAME = "comframe.dev.name";
/*     */   public static final String INST_ID_SPLIT_CHAR = "^";
/*     */   public static final int INST_ID_NUMBER_LENTH = 25;
/*     */   public static final int QUEUE_ID_NUMBER_LENTH = 5;
/*     */   public static final int REGION_ID_NUMBER_LENTH = 6;
/*     */   public static final int ID_HEX_10 = 10;
/*     */   public static final String EXEC_METHOD_THREAD = "THREAD";
/*     */   public static final String EXEC_METHOD_PROCESS = "PROCESS";
/*     */   public static final String S_COUNT_NAME = "COUNT";
/*     */ 
/*     */   public static abstract interface EngineType
/*     */   {
/*     */     public static final String S_ENGINE_TYPE_VM = "VM";
/*     */     public static final String S_ENGINE_TYPE_BPS = "BPS";
/*     */     public static final String S_ENGINE_TYPE_FUEGO = "FUEGO";
/*     */     public static final String S_ENGINE_TYPE_WPS = "WPS";
/*     */   }
/*     */ 
/*     */   public static abstract interface ParamDefine
/*     */   {
/*     */     public static final String PARAM_QUEUE_ID = "-q";
/*     */     public static final String PARAM_QUEUE_TYPE = "-t";
/*     */     public static final String PARAM_REGION_ID = "-r";
/*     */     public static final String PARAM_THREAD_NUM = "-n";
/*     */     public static final String PARAM_MOD = "-m";
/*     */     public static final String PARAM_MOD_VALUE = "-v";
/*     */   }
/*     */ 
/*     */   public static abstract interface TimerDealType
/*     */   {
/*     */     public static final String S_DEAL_TYPE_TIMER = "TIMER";
/*     */     public static final String S_DEAL_TYPE_PRINT = "PRINT";
/*     */     public static final String S_DEAL_TYPE_OVERTIME = "OVERTIME";
/*     */     public static final String S_DEAL_TYPE_STARTTIME = "STARTTIME";
/*     */   }
/*     */ 
/*     */   public static abstract interface QueueType
/*     */   {
/*     */     public static final String S_VM_QUEUE_TYPE_WF = "workflow";
/*     */     public static final String S_VM_QUEUE_TYPE_TIMER = "timer";
/*     */     public static final String S_VM_QUEUE_TYPE_EXCEPTION = "exception";
/*     */     public static final String S_VM_QUEUE_TYPE_WARNING = "warning";
/*     */     public static final String S_VM_QUEUE_TYP_WRAP_BUSI = "scanbusi";
/*     */     public static final String S_VM_QUEUE_TYP_WRAP_ENGINE = "scanengine";
/*     */   }
/*     */ 
/*     */   public static abstract interface YesNo
/*     */   {
/*     */     public static final String YES = "Y";
/*     */     public static final String NO = "N";
/*     */   }
/*     */ 
/*     */   public static abstract interface CommonState
/*     */   {
/*     */     public static final String VALIDATION = "U";
/*     */     public static final String UNVALIDATION = "E";
/*     */   }
/*     */ 
/*     */   public static abstract interface ExceptionDescType
/*     */   {
/*     */     public static final String MATCH_ALL = "A";
/*     */     public static final String MATCH_ONE = "B";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.Constant
 * JD-Core Version:    0.5.4
 */