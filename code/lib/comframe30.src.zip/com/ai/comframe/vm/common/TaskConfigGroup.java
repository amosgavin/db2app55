/*    */ package com.ai.comframe.vm.common;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class TaskConfigGroup
/*    */ {
/*    */   private String title;
/*    */   private String type;
/*    */   private List itemList;
/*    */   private boolean isVisible;
/*    */ 
/*    */   public TaskConfigGroup(String aTitle, String aType)
/*    */   {
/* 20 */     this.title = aTitle;
/* 21 */     this.type = aType;
/*    */   }
/*    */ 
/*    */   public String getTitle() {
/* 25 */     return this.title;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 29 */     return this.type;
/*    */   }
/*    */ 
/*    */   public List getItemList() {
/* 33 */     return this.itemList;
/*    */   }
/*    */ 
/*    */   public void setTitle(String title) {
/* 37 */     this.title = title;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 41 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void setItemList(List itemList) {
/* 45 */     this.itemList = itemList;
/*    */   }
/*    */ 
/*    */   public boolean isVisible() {
/* 49 */     return this.isVisible;
/*    */   }
/*    */ 
/*    */   public void setVisible(boolean isVisible) {
/* 53 */     this.isVisible = isVisible;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.TaskConfigGroup
 * JD-Core Version:    0.5.4
 */