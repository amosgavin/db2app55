package com.ai.comframe.vm.common;

public class DojoInfo
{
  public static final int S_SURFACEP_HEIGHT = 600;
  public static final int S_SURFACEP_WIDTH = 973;
  public static final int S_ICON_HEIGHT = 32;
  public static final int S_ICON_WIDTH = 32;
  public static final String Dojo_TYPE_LIGHT_BUTTON = "button1_hover.png";
  public static final String Dojo_TYPE_LIGHT_BG = "bg.png";
  public static final String Dojo_PATH_COMMON = "";
  public static final String Dojo_PATH_LIGHT_ICON32 = "images/light_icon_32/";
  public static final String Dojo_PATH_GRAY_ICON32 = "images/gray_icon_32/";
  public static final String Dojo_PATH_WARNING_ICON32 = "images/warning_icon_32/";
  public static final String Dojo_PATH_ACTIVE_ICON32 = "images/active_icon_32/";
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.DojoInfo
 * JD-Core Version:    0.5.4
 */