/*    */ package com.ai.comframe.vm.common;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.StringWriter;
/*    */ import java.io.Writer;
/*    */ import org.dom4j.Document;
/*    */ import org.dom4j.DocumentHelper;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.io.OutputFormat;
/*    */ import org.dom4j.io.SAXReader;
/*    */ import org.dom4j.io.XMLWriter;
/*    */ 
/*    */ public class XmlUtil
/*    */ {
/*    */   public static Element parseXml(InputStream in)
/*    */     throws Exception
/*    */   {
/* 17 */     SAXReader saxReader = new SAXReader();
/* 18 */     Document document = saxReader.read(in);
/* 19 */     return document.getRootElement();
/*    */   }
/*    */   public static Element parseXml(String fileName) throws Exception {
/* 22 */     SAXReader saxReader = new SAXReader();
/* 23 */     InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/* 24 */     Document document = saxReader.read(in);
/* 25 */     return document.getRootElement();
/*    */   }
/*    */ 
/*    */   public static Element createElement(String name, String text) {
/* 29 */     Element e = DocumentHelper.createElement(name);
/* 30 */     if ((text != null) && (!text.trim().equals("")))
/* 31 */       e.setText(text);
/* 32 */     return e;
/*    */   }
/*    */ 
/*    */   public static String formatElement(Element e) {
/* 36 */     StringWriter s = new StringWriter();
/* 37 */     OutputFormat format = OutputFormat.createPrettyPrint();
/* 38 */     XMLWriter writer = new XMLWriter(s, format);
/*    */     try {
/* 40 */       writer.write(e);
/* 41 */       writer.close();
/*    */     }
/*    */     catch (IOException ex) {
/* 44 */       ex.printStackTrace();
/*    */     }
/* 46 */     return s.getBuffer().toString();
/*    */   }
/*    */   public static void writerXml(String filename, Element root) throws Exception {
/* 49 */     Writer writer = new FileWriter(new File(filename));
/* 50 */     writerXml(writer, root);
/*    */   }
/*    */ 
/*    */   public static void writerXml(Writer writer, Element root) throws Exception {
/* 54 */     Document doc = DocumentHelper.createDocument(root);
/* 55 */     OutputFormat format = OutputFormat.createPrettyPrint();
/* 56 */     format.setEncoding("GB2312");
/* 57 */     XMLWriter xmlWriter = new XMLWriter(writer, format);
/* 58 */     xmlWriter.write(doc);
/* 59 */     xmlWriter.close();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.XmlUtil
 * JD-Core Version:    0.5.4
 */