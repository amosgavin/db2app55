/*    */ package com.ai.comframe.vm.common;
/*    */ 
/*    */ import com.ai.comframe.vm.engine.Task;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class WorkflowEventManager
/*    */ {
/* 12 */   private static Map m_listeners = new HashMap();
/*    */ 
/* 14 */   public static void addListener(long event, WorkflowEventListener listener) { List tmpList = (List)m_listeners.get(new Long(event));
/* 15 */     if (tmpList == null) {
/* 16 */       tmpList = new ArrayList();
/* 17 */       m_listeners.put(new Long(event), tmpList);
/*    */     }
/* 19 */     tmpList.add(listener); }
/*    */ 
/*    */   public static void removeListener(long event, WorkflowEventListener listener)
/*    */   {
/* 23 */     List tmpList = (List)m_listeners.get(new Long(event));
/* 24 */     if (tmpList == null) {
/* 25 */       return;
/*    */     }
/* 27 */     tmpList.remove(listener);
/*    */   }
/*    */ 
/*    */   public static void fireEvent(long event, Task task) {
/* 31 */     List tmpList = (List)m_listeners.get(new Long(event));
/* 32 */     if (tmpList == null)
/* 33 */       return;
/* 34 */     for (Iterator it = tmpList.iterator(); it.hasNext(); ) {
/* 35 */       WorkflowEventListener listener = (WorkflowEventListener)it.next();
/* 36 */       listener.execute(task);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.WorkflowEventManager
 * JD-Core Version:    0.5.4
 */