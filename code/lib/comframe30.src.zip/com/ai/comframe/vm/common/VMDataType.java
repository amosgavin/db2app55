/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import com.thoughtworks.xstream.io.xml.DomDriver;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class VMDataType
/*     */ {
/*     */   public static String transferToXml(Map value)
/*     */   {
/*  21 */     XStream xStream = new XStream();
/*  22 */     return xStream.toXML(value);
/*     */   }
/*     */ 
/*     */   public static Map transferToMap(String value) {
/*  26 */     XStream xStream = new XStream(new DomDriver());
/*  27 */     return (Map)xStream.fromXML(value);
/*     */   }
/*     */ 
/*     */   public static Class getJavaClass(String type) {
/*  31 */     return DataType.getJavaClass(type);
/*     */   }
/*     */ 
/*     */   public static Class getSimpleDataType(Class aClass) {
/*  35 */     return DataType.getSimpleDataType(aClass);
/*     */   }
/*     */ 
/*     */   public static String getAsString(Object obj) {
/*  39 */     return DataType.getAsString(obj);
/*     */   }
/*     */ 
/*     */   public static short getAsShort(Object obj) {
/*  43 */     return DataType.getAsShort(obj);
/*     */   }
/*     */ 
/*     */   public static int getAsInt(Object obj) {
/*  47 */     return DataType.getAsInt(obj);
/*     */   }
/*     */ 
/*     */   public static long getAsLong(Object obj) {
/*  51 */     return DataType.getAsLong(obj);
/*     */   }
/*     */ 
/*     */   public static double getAsDouble(Object obj) {
/*  55 */     return DataType.getAsDouble(obj);
/*     */   }
/*     */ 
/*     */   public static float getAsFloat(Object obj) {
/*  59 */     return DataType.getAsFloat(obj);
/*     */   }
/*     */ 
/*     */   public static byte getAsByte(Object obj) {
/*  63 */     return DataType.getAsByte(obj);
/*     */   }
/*     */ 
/*     */   public static boolean getAsBoolean(Object obj) {
/*  67 */     return DataType.getAsBoolean(obj);
/*     */   }
/*     */ 
/*     */   public static char getAsChar(Object obj) {
/*  71 */     return DataType.getAsChar(obj);
/*     */   }
/*     */ 
/*     */   public static Date getAsDate(Object obj) {
/*  75 */     return DataType.getAsDate(obj);
/*     */   }
/*     */ 
/*     */   public static Time getAsTime(Object obj) {
/*  79 */     return DataType.getAsTime(obj);
/*     */   }
/*     */ 
/*     */   public static Timestamp getAsDateTime(Object obj) {
/*  83 */     return DataType.getAsDateTime(obj);
/*     */   }
/*     */ 
/*     */   public static Object transfer(Object value, Class type) {
/*  87 */     return DataType.transfer(value, type);
/*     */   }
/*     */ 
/*     */   public static String transferToString(Object value, String type, int precision)
/*     */   {
/*  92 */     return DataType.transferToString(value, type, precision);
/*     */   }
/*     */ 
/*     */   public static String transferToString(Object value, String type) {
/*  96 */     return DataType.transferToString(value, type);
/*     */   }
/*     */ 
/*     */   public static Class getPrimitiveClass(Class type) {
/* 100 */     return DataType.getPrimitiveClass(type);
/*     */   }
/*     */ 
/*     */   public static String getClassName(Class className) {
/* 104 */     return DataType.getClassName(className);
/*     */   }
/*     */ 
/*     */   public static String[] getDataTypeNames()
/*     */   {
/* 109 */     return new String[] { getClassName(String.class), getClassName(Short.TYPE), getClassName(Integer.TYPE), getClassName(Long.TYPE), getClassName(Double.TYPE), getClassName(Float.TYPE), getClassName(Byte.TYPE), getClassName(Character.TYPE), getClassName(Boolean.TYPE), getClassName(Short.class), getClassName(Integer.class), getClassName(Long.class), getClassName(Double.class), getClassName(Float.class), getClassName(Byte.class), getClassName(Character.class), getClassName(Boolean.class), getClassName(Date.class), getClassName(Time.class), getClassName(Timestamp.class), getClassName(Object.class) };
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.VMDataType
 * JD-Core Version:    0.5.4
 */