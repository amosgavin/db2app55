/*    */ package com.ai.comframe.vm.common;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ 
/*    */ public class ServiceUtil
/*    */ {
/*    */   public static String getServiceClassName(String aServiceId)
/*    */   {
/* 10 */     return ServiceFactory.getSeviceInterface(aServiceId).getName();
/*    */   }
/*    */ 
/*    */   public static Object getService(String aServiceId) {
/* 14 */     return ServiceFactory.getService(aServiceId);
/*    */   }
/*    */ 
/*    */   public static Object getService(String aServiceId, Class aServiceInterface) {
/* 18 */     return ServiceFactory.getService(aServiceId, aServiceInterface);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.ServiceUtil
 * JD-Core Version:    0.5.4
 */