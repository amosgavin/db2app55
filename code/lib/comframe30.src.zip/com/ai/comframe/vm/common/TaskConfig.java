/*     */ package com.ai.comframe.vm.common;
/*     */ 
/*     */ import com.ai.appframe2.common.AIRootConfig;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskConfig
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(TaskConfig.class);
/*     */ 
/*  26 */   public static String S_CONFIG_FILE = "TaskConfig.xml";
/*     */   private static TaskConfig m_instance;
/*     */   private TaskConfigGroup sysGroup;
/*  57 */   private Map m_types = new HashMap();
/*     */ 
/*  59 */   private List m_groups = new ArrayList();
/*     */ 
/*  61 */   private List m_config_group = new ArrayList();
/*     */ 
/*     */   public static TaskConfig getInstance()
/*     */   {
/*  31 */     if (m_instance == null) {
/*  32 */       synchronized (TaskConfig.class) {
/*  33 */         if (m_instance == null) {
/*  34 */           m_instance = new TaskConfig();
/*     */         }
/*     */       }
/*     */     }
/*  38 */     return m_instance;
/*     */   }
/*     */ 
/*     */   public static TaskConfig getInstance(InputStream in, boolean reload) {
/*  42 */     if (reload == true) {
/*  43 */       m_instance = null;
/*     */     }
/*  45 */     if (m_instance == null) {
/*  46 */       synchronized (TaskConfig.class) {
/*  47 */         if (m_instance == null) {
/*  48 */           m_instance = new TaskConfig(in);
/*     */         }
/*     */       }
/*     */     }
/*  52 */     return m_instance;
/*     */   }
/*     */ 
/*     */   private TaskConfig()
/*     */   {
/*  64 */     InputStream in = AIRootConfig.getConfigInfo(S_CONFIG_FILE);
/*  65 */     load(in);
/*     */   }
/*     */ 
/*     */   private TaskConfig(InputStream in) {
/*  69 */     load(in);
/*     */   }
/*     */   private void load(InputStream in) {
/*     */     Iterator it;
/*     */     try {
/*  74 */       Element root = XmlUtil.parseXml(in);
/*  75 */       List listgroup = root.elements("group");
/*     */ 
/*  79 */       for (it = listgroup.iterator(); it.hasNext(); ) {
/*  80 */         Element groupElement = (Element)it.next();
/*     */ 
/*  82 */         List group = new ArrayList();
/*  83 */         List listtask = groupElement.elements("task");
/*  84 */         for (Iterator it2 = listtask.iterator(); it2.hasNext(); ) {
/*  85 */           Element e = (Element)it2.next();
/*  86 */           TaskConfigItem item = new TaskConfigItem(e.attributeValue("type"), e.attributeValue("templateclass"), e.attributeValue("executeclass"), e.attributeValue("studioDisplayClass"), e.attributeValue("studioPic"), e.attributeValue("title"), e.attributeValue("studioPartClass"), e);
/*     */ 
/*  93 */           this.m_types.put(e.attributeValue("type"), item);
/*  94 */           group.add(item);
/*     */         }
/*     */ 
/*  97 */         String aTitle = groupElement.attributeValue("title");
/*  98 */         String aType = groupElement.attributeValue("type");
/*  99 */         String visible = groupElement.attributeValue("isvisible");
/* 100 */         TaskConfigGroup configgroup = new TaskConfigGroup(aTitle, aType);
/* 101 */         if (aType.equals("system")) {
/* 102 */           this.sysGroup = configgroup;
/*     */         }
/* 104 */         configgroup.setItemList(group);
/* 105 */         if ((visible == null) || (visible.equals("true"))) {
/* 106 */           configgroup.setVisible(true);
/*     */         }
/*     */         else {
/* 109 */           configgroup.setVisible(false);
/*     */         }
/* 111 */         this.m_config_group.add(configgroup);
/*     */ 
/* 113 */         this.m_groups.add(group);
/*     */       }
/*     */     } catch (Exception ex) {
/* 116 */       log.error(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 122 */     StringBuffer buffer = new StringBuffer();
/* 123 */     for (Iterator it = this.m_types.values().iterator(); it.hasNext(); ) {
/* 124 */       buffer.append(it.next().toString()).append("\n");
/*     */     }
/* 126 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public String getTemplateClass(String type) {
/* 130 */     TaskConfigItem item = getTaskConfigItem(type);
/* 131 */     String result = "";
/* 132 */     if (item != null) {
/* 133 */       result = item.templateClass;
/*     */     }
/* 135 */     return result;
/*     */   }
/*     */ 
/*     */   public String getExecuteClass(String type) {
/* 139 */     TaskConfigItem item = getTaskConfigItem(type);
/* 140 */     String result = "";
/* 141 */     if (item != null) {
/* 142 */       result = item.executeClass;
/*     */     }
/* 144 */     return result;
/*     */   }
/*     */ 
/*     */   public String getStudioDisplayClass(String type) {
/* 148 */     TaskConfigItem item = getTaskConfigItem(type);
/* 149 */     String result = "";
/* 150 */     if (item != null) {
/* 151 */       result = item.studioDisplayClass;
/*     */     }
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   public String getStudioPic(String type) {
/* 157 */     TaskConfigItem item = getTaskConfigItem(type);
/* 158 */     String result = "";
/* 159 */     if (item != null) {
/* 160 */       result = item.studioPic;
/*     */     }
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplate(String type, WorkflowTemplate workflow, Element e)
/*     */   {
/*     */     try {
/* 168 */       Class tmpClass = Class.forName(getTemplateClass(type));
/* 169 */       Constructor c = tmpClass.getConstructor(new Class[] { WorkflowTemplate.class, Element.class });
/*     */ 
/* 171 */       return (TaskTemplate)c.newInstance(new Object[] { workflow, e });
/*     */     } catch (Exception ex) {
/* 173 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplate(String type, WorkflowTemplate workflow, String label) throws Exception
/*     */   {
/* 179 */     Class tmpClass = Class.forName(getTemplateClass(type));
/* 180 */     Constructor c = tmpClass.getConstructor(new Class[] { WorkflowTemplate.class, String.class });
/*     */ 
/* 182 */     return (TaskTemplate)c.newInstance(new Object[] { workflow, type });
/*     */   }
/*     */ 
/*     */   public List getTaskConfigGroups()
/*     */   {
/* 200 */     return this.m_groups;
/*     */   }
/*     */ 
/*     */   public List getM_config_group()
/*     */   {
/* 205 */     return this.m_config_group;
/*     */   }
/*     */ 
/*     */   public Map getAllTasks() {
/* 209 */     return this.m_types;
/*     */   }
/*     */ 
/*     */   public String getBasalType(String type) {
/* 213 */     if (this.sysGroup == null) {
/* 214 */       return type;
/*     */     }
/* 216 */     String exeClass = getExecuteClass(type);
/* 217 */     List items = this.sysGroup.getItemList();
/* 218 */     for (int i = 0; i < items.size(); ++i) {
/* 219 */       TaskConfigItem tmp = (TaskConfigItem)items.get(i);
/* 220 */       if (exeClass.equals(tmp.executeClass)) {
/* 221 */         return tmp.taskType;
/*     */       }
/*     */     }
/* 224 */     return type;
/*     */   }
/*     */ 
/*     */   public TaskConfigItem getTaskConfigItem(String type) {
/* 228 */     TaskConfigItem item = (TaskConfigItem)this.m_types.get(type);
/* 229 */     if (item == null) {
/* 230 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.getTaskConfigItem_noTaskKind") + type + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.getTaskConfigItem_relateInfo"));
/*     */     }
/* 232 */     return item;
/*     */   }
/*     */ 
/*     */   public Element createElement() {
/* 236 */     Element e = XmlUtil.createElement("tasks", "");
/* 237 */     TaskConfigGroup[] groups = (TaskConfigGroup[])(TaskConfigGroup[])this.m_config_group.toArray(new TaskConfigGroup[0]);
/* 238 */     for (int i = 0; i < groups.length; ++i) {
/* 239 */       Element group = e.addElement("group", "");
/* 240 */       group.addAttribute("title", groups[i].getTitle());
/* 241 */       group.addAttribute("type", groups[i].getType());
/* 242 */       group.addAttribute("isvisible", String.valueOf(groups[i].isVisible()));
/* 243 */       TaskConfigItem[] tasks = (TaskConfigItem[])(TaskConfigItem[])groups[i].getItemList().toArray(new TaskConfigItem[0]);
/* 244 */       for (int j = 0; j < tasks.length; ++j) {
/* 245 */         Element task = group.addElement("task", "");
/* 246 */         task.addAttribute("type", tasks[j].taskType);
/* 247 */         task.addAttribute("title", tasks[j].title);
/* 248 */         task.addAttribute("templateclass", tasks[j].templateClass);
/* 249 */         task.addAttribute("executeclass", tasks[j].executeClass);
/* 250 */         task.addAttribute("studioDisplayClass", tasks[j].studioDisplayClass);
/* 251 */         task.addAttribute("studioPic", tasks[j].studioPic);
/* 252 */         task.addAttribute("studioPartClass", tasks[j].studioPartClass);
/* 253 */         Element item = tasks[j].xmlNode;
/*     */ 
/* 255 */         Element tmpMonitorNode = item.element("monitor");
/* 256 */         if (tmpMonitorNode != null) {
/* 257 */           Element monitorNode = task.addElement("monitor");
/* 258 */           String type = tmpMonitorNode.attributeValue("type");
/* 259 */           String service = tmpMonitorNode.attributeValue("service");
/* 260 */           if (!StringUtils.isEmptyString(service)) {
/* 261 */             if (StringUtils.isEmptyString(type)) {
/* 262 */               type = "pojo";
/*     */             }
/* 264 */             monitorNode.addAttribute("type", type);
/* 265 */             monitorNode.addAttribute("service", service);
/*     */           }
/*     */         }
/* 268 */         Element tmpUser = item.element("user");
/* 269 */         if (tmpUser != null) {
/* 270 */           Element user = task.addElement("user");
/* 271 */           user.addAttribute("taskusertype", tmpUser.attributeValue("taskusertype"));
/* 272 */           user.addAttribute("organizeid", tmpUser.attributeValue("organizeid"));
/* 273 */           user.addAttribute("organizename", tmpUser.attributeValue("organizename"));
/* 274 */           user.addAttribute("taskuserid", tmpUser.attributeValue("taskuserid"));
/* 275 */           user.addAttribute("taskusername", tmpUser.attributeValue("taskusername"));
/* 276 */           user.addAttribute("isneedprint", tmpUser.attributeValue("isneedprint"));
/* 277 */           user.addAttribute("isautoprint", tmpUser.attributeValue("isautoprint"));
/*     */         }
/*     */ 
/* 280 */         Element tmpChild = item.element("child");
/*     */         Element child;
/*     */         Iterator it;
/* 281 */         if (tmpChild != null) {
/* 282 */           child = task.addElement("child");
/* 283 */           child.addAttribute("code", tmpChild.attributeValue("code"));
/* 284 */           child.addAttribute("name", tmpChild.attributeValue("name"));
/* 285 */           child.addAttribute("type", tmpChild.attributeValue("type"));
/* 286 */           List childVars = tmpChild.elements("vars");
/* 287 */           if (childVars != null) {
/* 288 */             for (it = childVars.iterator(); it.hasNext(); ) {
/* 289 */               Element var = child.addElement("vars");
/* 290 */               Element p = (Element)it.next();
/* 291 */               var.addAttribute("name", p.attributeValue("name"));
/* 292 */               var.addAttribute("datatype", p.attributeValue("datatype"));
/* 293 */               var.addAttribute("contextvarName", p.attributeValue("contextvarName"));
/* 294 */               var.addAttribute("defaultvalue", p.attributeValue("defaultvalue"));
/* 295 */               var.addAttribute("inouttype", p.attributeValue("inouttype"));
/* 296 */               var.addAttribute("description", p.attributeValue("description"));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 301 */         Element autoDealElement = item.element("autodeal");
/* 302 */         if (autoDealElement != null) {
/* 303 */           task.add(new TaskDealBean(autoDealElement).getElement());
/*     */         }
/* 305 */         Element printDealElement = item.element("printdeal");
/* 306 */         if (printDealElement != null) {
/* 307 */           task.add(new TaskDealBean(printDealElement).getElement());
/*     */         }
/* 309 */         Element postDealElement = item.element("postdeal");
/* 310 */         if (postDealElement != null) {
/* 311 */           task.add(new TaskDealBean(postDealElement).getElement());
/*     */         }
/* 313 */         Element childDealElement = item.element("childdeal");
/* 314 */         if (childDealElement != null) {
/* 315 */           task.add(new TaskDealBean(childDealElement).getElement());
/*     */         }
/* 317 */         Element revertDealElement = item.element("revertdeal");
/* 318 */         if (revertDealElement != null) {
/* 319 */           task.add(new TaskDealBean(revertDealElement).getElement());
/*     */         }
/*     */       }
/*     */     }
/* 323 */     return e;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 327 */     System.out.println(getInstance().toString()); } 
/*     */   public class TaskConfigItem { public String taskType;
/*     */     public String templateClass;
/*     */     public String executeClass;
/*     */     public String studioDisplayClass;
/*     */     public String studioEditClass;
/*     */     public String studioPic;
/*     */     public String title;
/*     */     public Element xmlNode;
/*     */     public String studioPartClass;
/*     */ 
/* 335 */     public TaskConfigItem(String aTaskType, String aTemplateClass, String aExecuteClass, String aStudioDisplayClass, String aStudioPic, String aTitle, String studioPartClass, Element aXmlNode) { this.taskType = aTaskType;
/* 336 */       this.templateClass = aTemplateClass;
/* 337 */       this.executeClass = aExecuteClass;
/* 338 */       this.studioDisplayClass = aStudioDisplayClass;
/* 339 */       this.studioPic = aStudioPic;
/* 340 */       this.title = aTitle;
/* 341 */       this.xmlNode = aXmlNode;
/* 342 */       this.studioPartClass = studioPartClass; }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 346 */       return "taskType=" + this.taskType + " templateClass=" + this.templateClass + " executeClass=" + this.executeClass + " studioDisplayClass=" + this.studioDisplayClass + " studioEditClass=" + this.studioEditClass + "studioPartClass=" + this.studioPartClass;
/*     */     } }
/*     */ 
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.common.TaskConfig
 * JD-Core Version:    0.5.4
 */