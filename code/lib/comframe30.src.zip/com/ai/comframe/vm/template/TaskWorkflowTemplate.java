package com.ai.comframe.vm.template;

import com.ai.comframe.vm.common.ParameterDefine;
import java.util.List;

public abstract interface TaskWorkflowTemplate extends TaskTemplate
{
  public static final String S_PARAMETER_NAME_FLOWOBJECT_CHILD_TASK_CODE = "FLOWOBJECT_CHILD_TASK_CODE";
  public static final String S_PARAMETER_NAME_FLOWOBJECT_TYPE = "FLOWOBJECT_TYPE";
  public static final String S_PARAMETER_NAME_FLOWOBJECT_ID = "FLOWOBJECT_ID";
  public static final String S_PARAMETER_NAME_CREATE_STAFF = "CREATE_STAFF";
  public static final String LoopVarHead = "$LOOP.";

  public abstract String getWorkflowCode();

  public abstract void setWorkflowCode(String paramString);

  public abstract String getWorkflowName();

  public abstract void setWorkflowName(String paramString);

  public abstract ParameterDefine[] getInParameterDefine()
    throws Exception;

  public abstract ParameterDefine[] getOutParameterDefine()
    throws Exception;

  public abstract String getWorkflowType();

  public abstract void setWorkflowType(String paramString);

  public abstract List getWorkflowVars();

  public abstract void setWorkflowVars(List paramList);

  public abstract TaskDealBean getAutoDealBean();

  public abstract void setAutoDealBean(TaskDealBean paramTaskDealBean);

  public abstract TaskDealBean getRevertDealBean();

  public abstract void setRevertDealBean(TaskDealBean paramTaskDealBean);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskWorkflowTemplate
 * JD-Core Version:    0.5.4
 */