/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskStartUserTemplateImpl extends TaskStartTemplateImpl
/*    */ {
/*    */   public TaskStartUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 19 */     super(aWorkflowTemplate, item);
/* 20 */     TaskAutoUserTemplateImpl.initialFromConfig(this, item.attribute("tasktype").getValue());
/* 21 */     this.isStart = true;
/*    */   }
/*    */ 
/*    */   public TaskStartUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 25 */     super(aWorkflowTemplate, type);
/* 26 */     TaskAutoUserTemplateImpl.initialFromConfig(this, type);
/* 27 */     this.isStart = true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskStartUserTemplateImpl
 * JD-Core Version:    0.5.4
 */