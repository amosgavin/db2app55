package com.ai.comframe.vm.template;

public abstract interface TaskStartTemplate extends TaskAutoTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskStartTemplate
 * JD-Core Version:    0.5.4
 */