/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskLoopEndTemplate;
/*    */ import com.ai.comframe.vm.template.TaskLoopTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskLoopEndTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskLoopEndTemplate
/*    */ {
/*    */   public TaskLoopEndTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 18 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskLoopEndTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 22 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList)
/*    */   {
/* 27 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 28 */     if ((joins.length == 1) || (joins.length == 2)) {
/* 29 */       int loopNum = 0;
/* 30 */       for (int i = 0; i < joins.length; ++i) {
/* 31 */         if (joins[i].getTaskTemplateA() instanceof TaskLoopTemplate)
/* 32 */           loopNum += 1;
/*    */       }
/* 34 */       if (loopNum == 0)
/* 35 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_oneShouldFromLoop"));
/* 36 */       else if (loopNum == 2)
/* 37 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_onlyOneFromLoop"));
/*    */     }
/*    */     else {
/* 40 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_twoShouldLoopAndOther"));
/*    */     }
/*    */ 
/* 43 */     joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 44 */     if (joins.length == 2) {
/* 45 */       int loopNum = 0;
/* 46 */       for (int i = 0; i < joins.length; ++i) {
/* 47 */         if (joins[i].getTaskTemplateB() instanceof TaskLoopTemplate) {
/* 48 */           loopNum += 1;
/*    */ 
/* 50 */           if (!super.equals(getWorkflowTemplate().getEndLoopByLoop((TaskLoopTemplate)joins[i].getTaskTemplateB())))
/* 51 */             errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_notMatchEndloop"));
/*    */         }
/*    */       }
/* 54 */       if (loopNum == 0)
/* 55 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_shouldOneLoopOut"));
/* 56 */       else if (loopNum == 2)
/* 57 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_onlyLoopOut"));
/*    */     } else {
/* 59 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_oneOutLoopOneOutOther"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskLoopEndTemplateImpl
 * JD-Core Version:    0.5.4
 */