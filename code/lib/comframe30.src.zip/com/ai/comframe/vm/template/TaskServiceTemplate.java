package com.ai.comframe.vm.template;

import com.ai.comframe.vm.common.ParameterDefine;

public abstract interface TaskServiceTemplate extends TaskTemplate
{
  public abstract String getServiceName();

  public abstract void setServiceName(String paramString);

  public abstract String getServiceInterfaceName();

  public abstract void setServiceInterfaceName(String paramString);

  public abstract String getFunctionName();

  public abstract void setFunctionName(String paramString);

  public abstract ParameterDefine[] getFunctionParameterDefine();

  public abstract ParameterDefine getReturnParameterDefine();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskServiceTemplate
 * JD-Core Version:    0.5.4
 */