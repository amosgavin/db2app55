/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ class TaskNodeIF extends TaskNode
/*     */ {
/* 395 */   Map m_caseChild = new HashMap();
/*     */   TaskNode m_defaultChild;
/*     */ 
/*     */   public TaskNodeIF(TaskNode parent, TaskTemplate task)
/*     */   {
/* 398 */     super(parent, task);
/*     */   }
/*     */ 
/*     */   public void addCaseChildren(JoinTemplate caseJoin, TaskNode taskNode) {
/* 402 */     this.m_caseChild.put(caseJoin, taskNode);
/*     */   }
/*     */ 
/*     */   public void setDefaultChildren(TaskNode taskNode) {
/* 406 */     this.m_defaultChild = taskNode;
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level) {
/* 410 */     this.m_task.toJavaRemark(buffer, level);
/* 411 */     boolean isFirst = true;
/* 412 */     appendLevel(buffer, level);
/* 413 */     String dsCond = "decisionCond" + this.m_task.getTaskTemplateId();
/* 414 */     buffer.append("String ").append(dsCond).append(" = String.valueOf(");
/*     */ 
/* 416 */     this.m_task.toJavaCode(buffer, level);
/* 417 */     buffer.append(");\n");
/* 418 */     for (Iterator it = this.m_caseChild.entrySet().iterator(); it.hasNext(); ) {
/* 419 */       Map.Entry me = (Map.Entry)it.next();
/* 420 */       JoinTemplate tmpJoin = (JoinTemplate)me.getKey();
/* 421 */       TaskNode tmpNode = (TaskNode)me.getValue();
/* 422 */       appendLevel(buffer, level);
/* 423 */       if (isFirst == true) {
/* 424 */         buffer.append("if(");
/* 425 */         isFirst = false;
/*     */       } else {
/* 427 */         buffer.append("else if(");
/*     */       }
/* 429 */       buffer.append(dsCond + ".equals(\"" + tmpJoin.getCondition() + "\")");
/* 430 */       buffer.append("){\n");
/* 431 */       for (int i = 0; i < tmpNode.m_child.size(); ++i) {
/* 432 */         ((TaskNode)tmpNode.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */       }
/* 434 */       appendLevel(buffer, level);
/* 435 */       buffer.append("}\n");
/*     */     }
/* 437 */     appendLevel(buffer, level);
/* 438 */     if (this.m_defaultChild == null) {
/* 439 */       buffer.append("else{logger.warn(\"" + this.m_task.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskNode.toJavaCode_noMatchCond") + "\");}\n");
/*     */     }
/*     */     else {
/* 442 */       buffer.append("else{\n");
/* 443 */       for (int i = 0; i < this.m_defaultChild.m_child.size(); ++i) {
/* 444 */         ((TaskNode)this.m_defaultChild.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */       }
/* 446 */       appendLevel(buffer, level);
/* 447 */       buffer.append("}\n");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskNodeIF
 * JD-Core Version:    0.5.4
 */