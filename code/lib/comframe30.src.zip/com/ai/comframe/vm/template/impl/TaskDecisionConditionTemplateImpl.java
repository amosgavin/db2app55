/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.common.XmlUtil;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskDecisionConditionTemplate;
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskDecisionConditionTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskDecisionConditionTemplate
/*    */ {
/*    */   private String condition;
/*    */   private transient Object[] m_opList;
/*    */ 
/*    */   public TaskDecisionConditionTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 20 */     super(aWorkflowTemplate, item);
/*    */ 
/* 22 */     Element tmpNode = item.element("condition");
/* 23 */     if (tmpNode != null)
/* 24 */       this.condition = tmpNode.getTextTrim();
/*    */   }
/*    */ 
/*    */   public TaskDecisionConditionTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 30 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public Element getElement()
/*    */   {
/* 35 */     Element result = super.getElement();
/* 36 */     result.add(XmlUtil.createElement("condition", this.condition));
/* 37 */     return result;
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList) {
/* 41 */     checkFlowLogicStatic(this, errorList);
/*    */   }
/*    */ 
/*    */   public static void checkFlowLogicStatic(TaskTemplate template, List errorList) {
/* 45 */     JoinTemplate[] joins = template.getWorkflowTemplate().getJoinsByTaskB(template);
/* 46 */     if (joins.length == 0)
/* 47 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/* 48 */     else if (joins.length > 1) {
/* 49 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreInLine"));
/*    */     }
/* 51 */     joins = template.getWorkflowTemplate().getJoinsByTaskA(template);
/* 52 */     if (joins.length == 0)
/* 53 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/*    */   }
/*    */ 
/*    */   public void setCondition(String value)
/*    */   {
/* 59 */     this.condition = value;
/*    */   }
/*    */ 
/*    */   public String getCondition() {
/* 63 */     return this.condition;
/*    */   }
/*    */   public void toJavaCode(StringBuffer buffer, int level) {
/* 66 */     buffer.append(getCondition());
/*    */   }
/*    */ 
/*    */   public Object[] getOperatorList()
/*    */   {
/* 71 */     return this.m_opList;
/*    */   }
/*    */ 
/*    */   public synchronized void setOperatorList(Object[] operatorList) {
/* 75 */     this.m_opList = operatorList;
/*    */   }
/*    */   public String getDisplayText() {
/* 78 */     if ((this.label == null) || (this.label.trim().length() == 0)) {
/* 79 */       return this.condition;
/*    */     }
/* 81 */     return this.label;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskDecisionConditionTemplateImpl
 * JD-Core Version:    0.5.4
 */