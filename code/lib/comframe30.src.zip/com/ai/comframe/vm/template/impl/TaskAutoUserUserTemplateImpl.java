/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskAutoUserUserTemplateImpl extends TaskUserTemplateImpl
/*     */ {
/*     */   public TaskAutoUserUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  25 */     super(aWorkflowTemplate, item);
/*  26 */     initialFromConfig(this, item.attribute("tasktype").getValue());
/*     */   }
/*     */ 
/*     */   public TaskAutoUserUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  31 */     super(aWorkflowTemplate, type);
/*  32 */     initialFromConfig(this, type);
/*     */   }
/*     */ 
/*     */   public static void initialFromConfig(TaskUserTemplateImpl userTemplate, String type) {
/*  36 */     Element item = TaskConfig.getInstance().getTaskConfigItem(type).xmlNode;
/*     */ 
/*  38 */     Element monitorNode = item.element("monitor");
/*  39 */     if (monitorNode != null) {
/*  40 */       userTemplate.monitorType = monitorNode.attributeValue("type");
/*  41 */       userTemplate.monitorService = monitorNode.attributeValue("service");
/*     */     }
/*     */ 
/*  44 */     Element dealNode = item.element("autodeal");
/*  45 */     if (dealNode != null) {
/*  46 */       if (userTemplate.autoDealBean == null) {
/*  47 */         userTemplate.autoDealBean = new TaskDealBean("autodeal");
/*     */       }
/*     */ 
/*  50 */       userTemplate.autoDealBean.setRunType(dealNode.elementText("runtype"));
/*  51 */       userTemplate.autoDealBean.setServiceName(dealNode.elementText("servicename"));
/*  52 */       userTemplate.autoDealBean.setRunClassName(dealNode.elementText("runclassname"));
/*  53 */       userTemplate.autoDealBean.setRunFunctionName(dealNode.elementText("runfunctionname"));
/*     */ 
/*  55 */       List wvmList = userTemplate.autoDealBean.getVars();
/*  56 */       if (wvmList == null)
/*     */       {
/*  58 */         wvmList = new ArrayList();
/*  59 */         wvmList.addAll(userTemplate.m_vars);
/*  60 */         userTemplate.m_vars.clear();
/*     */       }
/*  62 */       List tmpList = dealNode.elements("vars");
/*     */ 
/*  64 */       if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/*  65 */         for (int i = 0; i < tmpList.size(); ++i) {
/*  66 */           Element tmpNode = (Element)tmpList.get(i);
/*  67 */           ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/*  68 */           wvm.name = tmpNode.attributeValue("name");
/*  69 */           wvm.dataType = tmpNode.attributeValue("datatype");
/*  70 */           wvm.inOutType = tmpNode.attributeValue("inouttype");
/*  71 */           wvm.description = tmpNode.attributeValue("description");
/*  72 */           if (wvm.contextVarName == null)
/*  73 */             wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  78 */         wvmList.clear();
/*  79 */         for (int i = 0; i < tmpList.size(); ++i) {
/*  80 */           Element tmpNode = (Element)tmpList.get(i);
/*  81 */           ParameterDefine p = new ParameterDefine();
/*  82 */           p.name = tmpNode.attributeValue("name");
/*  83 */           p.dataType = tmpNode.attributeValue("datatype");
/*  84 */           p.inOutType = tmpNode.attributeValue("inouttype");
/*  85 */           p.description = tmpNode.attributeValue("description");
/*  86 */           p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  87 */           wvmList.add(p);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  92 */     Element user = item.element("user");
/*  93 */     if (user.attribute("taskusertype") != null)
/*  94 */       userTemplate.setTaskUserType(user.attribute("taskusertype").getValue());
/*  95 */     if (user.attribute("organizeid") != null)
/*  96 */       userTemplate.setOrganizeId(user.attribute("organizeid").getValue());
/*  97 */     if (user.attribute("organizename") != null)
/*  98 */       userTemplate.setOrganizeName(user.attribute("organizename").getValue());
/*  99 */     if (user.attribute("taskuserid") != null)
/* 100 */       userTemplate.setTaskUserId(user.attribute("taskuserid").getValue());
/* 101 */     if (user.attribute("taskusername") != null)
/* 102 */       userTemplate.setTaskUserName(user.attribute("taskusername").getValue());
/* 103 */     if (user.attribute("isneedprint") != null)
/* 104 */       userTemplate.setIsNeedPrint(Boolean.valueOf(user.attribute("isneedprint").getValue()).booleanValue());
/* 105 */     if (user.attribute("isautoprint") != null) {
/* 106 */       userTemplate.setIsAutoPrint(Boolean.valueOf(user.attribute("isautoprint").getValue()).booleanValue());
/*     */     }
/*     */ 
/* 109 */     dealNode = item.element("printdeal");
/* 110 */     if (dealNode != null) {
/* 111 */       if (userTemplate.printDealBean == null) {
/* 112 */         userTemplate.printDealBean = new TaskDealBean("printdeal");
/*     */       }
/* 114 */       setDealInfo(userTemplate.printDealBean, dealNode);
/*     */     }
/*     */ 
/* 117 */     dealNode = item.element("postdeal");
/* 118 */     if (dealNode != null) {
/* 119 */       if (userTemplate.postDealBean == null) {
/* 120 */         userTemplate.postDealBean = new TaskDealBean("postdeal");
/*     */       }
/* 122 */       setDealInfo(userTemplate.postDealBean, dealNode);
/*     */     }
/*     */ 
/* 125 */     dealNode = item.element("revertdeal");
/* 126 */     if (dealNode != null) {
/* 127 */       if (userTemplate.revertDealBean == null) {
/* 128 */         userTemplate.revertDealBean = new TaskDealBean("revertdeal");
/*     */       }
/* 130 */       setDealInfo(userTemplate.revertDealBean, dealNode);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static void setDealInfo(TaskDealBean dealBean, Element e) {
/* 135 */     dealBean.setRunType(e.elementText("runtype"));
/* 136 */     dealBean.setServiceName(e.elementText("servicename"));
/* 137 */     dealBean.setRunClassName(e.elementText("runclassname"));
/* 138 */     dealBean.setRunFunctionName(e.elementText("runfunctionname"));
/*     */ 
/* 140 */     List wvmList = dealBean.getVars();
/* 141 */     List tmpList = e.elements("vars");
/*     */ 
/* 143 */     if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/* 144 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 145 */         Element tmpNode = (Element)tmpList.get(i);
/* 146 */         ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/* 147 */         wvm.name = tmpNode.attributeValue("name");
/* 148 */         wvm.dataType = tmpNode.attributeValue("datatype");
/* 149 */         wvm.inOutType = tmpNode.attributeValue("inouttype");
/* 150 */         wvm.description = tmpNode.attributeValue("description");
/* 151 */         if (wvm.contextVarName == null)
/* 152 */           wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 157 */       if (wvmList == null)
/* 158 */         wvmList = new ArrayList();
/*     */       else
/* 160 */         wvmList.clear();
/* 161 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 162 */         Element tmpNode = (Element)tmpList.get(i);
/* 163 */         ParameterDefine p = new ParameterDefine();
/* 164 */         p.name = tmpNode.attributeValue("name");
/* 165 */         p.dataType = tmpNode.attributeValue("datatype");
/* 166 */         p.inOutType = tmpNode.attributeValue("inouttype");
/* 167 */         p.description = tmpNode.attributeValue("description");
/* 168 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/* 169 */         wvmList.add(p);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskAutoUserUserTemplateImpl
 * JD-Core Version:    0.5.4
 */