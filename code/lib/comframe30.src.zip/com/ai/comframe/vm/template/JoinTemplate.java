package com.ai.comframe.vm.template;

import java.util.List;
import org.dom4j.Element;

public abstract interface JoinTemplate
{
  public abstract String getLabel();

  public abstract String getUIInfo();

  public abstract TaskTemplate getTaskTemplateA();

  public abstract long getTaskTemplateAId();

  public abstract TaskTemplate getTaskTemplateB();

  public abstract long getTaskTemplateBId();

  public abstract boolean getIsAgainst();

  public abstract void setIsAgainst(boolean paramBoolean);

  public abstract String getCondition();

  public abstract Element getElement();

  public abstract void setUIInfo(String paramString);

  public abstract void setLabel(String paramString);

  public abstract void setCondition(String paramString);

  public abstract void setTaskTemplateAId(long paramLong);

  public abstract void setTaskTemplateBId(long paramLong);

  public abstract void checkFlowLogic(List paramList);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.JoinTemplate
 * JD-Core Version:    0.5.4
 */