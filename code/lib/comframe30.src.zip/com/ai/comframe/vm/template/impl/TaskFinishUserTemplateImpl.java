/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskFinishUserTemplateImpl extends TaskFinishTemplateImpl
/*    */ {
/*    */   public TaskFinishUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 19 */     super(aWorkflowTemplate, item);
/* 20 */     TaskAutoUserTemplateImpl.initialFromConfig(this, item.attribute("tasktype").getValue());
/*    */   }
/*    */ 
/*    */   public TaskFinishUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 24 */     super(aWorkflowTemplate, type);
/* 25 */     TaskAutoUserTemplateImpl.initialFromConfig(this, type);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskFinishUserTemplateImpl
 * JD-Core Version:    0.5.4
 */