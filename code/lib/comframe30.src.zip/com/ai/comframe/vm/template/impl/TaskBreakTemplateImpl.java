/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.TaskBreakTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskBreakTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskBreakTemplate
/*    */ {
/*    */   public TaskBreakTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 14 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskBreakTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 18 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */   public void toJavaCode(StringBuffer buffer, int level) {
/* 21 */     buffer.append("break;");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskBreakTemplateImpl
 * JD-Core Version:    0.5.4
 */