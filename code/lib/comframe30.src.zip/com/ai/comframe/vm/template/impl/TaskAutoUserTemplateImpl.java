/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskAutoUserTemplateImpl extends TaskAutoTemplateImpl
/*     */ {
/*     */   public TaskAutoUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  18 */     super(aWorkflowTemplate, item);
/*  19 */     initialFromConfig(this, item.attribute("tasktype").getValue());
/*     */   }
/*     */ 
/*     */   public TaskAutoUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  24 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */ 
/*  26 */     initialFromConfig(this, type);
/*     */   }
/*     */ 
/*     */   public static void initialFromConfig(TaskAutoTemplateImpl autoTemplate, String type) {
/*  30 */     Element item = TaskConfig.getInstance().getTaskConfigItem(type).xmlNode;
/*     */ 
/*  32 */     Element monitorNode = item.element("monitor");
/*  33 */     if (monitorNode != null) {
/*  34 */       autoTemplate.monitorType = monitorNode.attributeValue("type");
/*  35 */       autoTemplate.monitorService = monitorNode.attributeValue("service");
/*     */     }
/*     */ 
/*  38 */     Element dealNode = item.element("autodeal");
/*  39 */     if (dealNode == null) {
/*  40 */       return;
/*     */     }
/*  42 */     if (autoTemplate.autoDealBean == null) {
/*  43 */       autoTemplate.autoDealBean = new TaskDealBean("autodeal");
/*     */     }
/*     */ 
/*  46 */     autoTemplate.autoDealBean.setRunType(dealNode.elementText("runtype"));
/*  47 */     autoTemplate.autoDealBean.setServiceName(dealNode.elementText("servicename"));
/*  48 */     autoTemplate.autoDealBean.setRunClassName(dealNode.elementText("runclassname"));
/*  49 */     autoTemplate.autoDealBean.setRunFunctionName(dealNode.elementText("runfunctionname"));
/*     */ 
/*  51 */     List wvmList = autoTemplate.autoDealBean.getVars();
/*  52 */     if (wvmList == null) {
/*  53 */       wvmList = new ArrayList();
/*  54 */       wvmList.addAll(autoTemplate.m_vars);
/*  55 */       autoTemplate.m_vars.clear();
/*     */     }
/*  57 */     List tmpList = dealNode.elements("vars");
/*  58 */     if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/*  59 */       for (int i = 0; i < tmpList.size(); ++i) {
/*  60 */         Element tmpNode = (Element)tmpList.get(i);
/*  61 */         ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/*  62 */         wvm.name = tmpNode.attributeValue("name");
/*  63 */         wvm.dataType = tmpNode.attributeValue("datatype");
/*  64 */         wvm.inOutType = tmpNode.attributeValue("inouttype");
/*  65 */         wvm.description = tmpNode.attributeValue("description");
/*  66 */         if (wvm.contextVarName == null)
/*  67 */           wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  72 */       wvmList.clear();
/*  73 */       for (int i = 0; i < tmpList.size(); ++i) {
/*  74 */         Element tmpNode = (Element)tmpList.get(i);
/*  75 */         ParameterDefine p = new ParameterDefine();
/*  76 */         p.name = tmpNode.attributeValue("name");
/*  77 */         p.dataType = tmpNode.attributeValue("datatype");
/*  78 */         p.inOutType = tmpNode.attributeValue("inouttype");
/*  79 */         p.description = tmpNode.attributeValue("description");
/*  80 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  81 */         wvmList.add(p);
/*     */       }
/*     */     }
/*     */ 
/*  85 */     dealNode = item.element("revertdeal");
/*  86 */     if (dealNode == null) {
/*  87 */       return;
/*     */     }
/*  89 */     if (autoTemplate.revertDealBean == null) {
/*  90 */       autoTemplate.revertDealBean = new TaskDealBean("revertdeal");
/*     */     }
/*     */ 
/*  93 */     autoTemplate.revertDealBean.setRunType(dealNode.elementText("runtype"));
/*  94 */     autoTemplate.revertDealBean.setServiceName(dealNode.elementText("servicename"));
/*  95 */     autoTemplate.revertDealBean.setRunClassName(dealNode.elementText("runclassname"));
/*  96 */     autoTemplate.revertDealBean.setRunFunctionName(dealNode.elementText("runfunctionname"));
/*     */ 
/*  98 */     wvmList = autoTemplate.revertDealBean.getVars();
/*  99 */     if (wvmList == null) {
/* 100 */       wvmList = new ArrayList();
/* 101 */       wvmList.addAll(autoTemplate.m_vars);
/* 102 */       autoTemplate.m_vars.clear();
/*     */     }
/* 104 */     tmpList = dealNode.elements("vars");
/* 105 */     if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/* 106 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 107 */         Element tmpNode = (Element)tmpList.get(i);
/* 108 */         ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/* 109 */         wvm.name = tmpNode.attributeValue("name");
/* 110 */         wvm.dataType = tmpNode.attributeValue("datatype");
/* 111 */         wvm.inOutType = tmpNode.attributeValue("inouttype");
/* 112 */         wvm.description = tmpNode.attributeValue("description");
/* 113 */         if (wvm.contextVarName == null)
/* 114 */           wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 119 */       wvmList.clear();
/* 120 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 121 */         Element tmpNode = (Element)tmpList.get(i);
/* 122 */         ParameterDefine p = new ParameterDefine();
/* 123 */         p.name = tmpNode.attributeValue("name");
/* 124 */         p.dataType = tmpNode.attributeValue("datatype");
/* 125 */         p.inOutType = tmpNode.attributeValue("inouttype");
/* 126 */         p.description = tmpNode.attributeValue("description");
/* 127 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/* 128 */         wvmList.add(p);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskAutoUserTemplateImpl
 * JD-Core Version:    0.5.4
 */