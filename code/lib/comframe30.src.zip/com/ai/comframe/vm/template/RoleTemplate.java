package com.ai.comframe.vm.template;

import org.dom4j.Element;

public abstract interface RoleTemplate
{
  public abstract String getLabel();

  public abstract String getUIInfo();

  public abstract void setUIInfo(String paramString);

  public abstract void setLabel(String paramString);

  public abstract Element getElement();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.RoleTemplate
 * JD-Core Version:    0.5.4
 */