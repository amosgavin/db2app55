/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskStartTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskStartTemplateImpl extends TaskAutoTemplateImpl
/*    */   implements TaskStartTemplate
/*    */ {
/*    */   public TaskStartTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 18 */     super(aWorkflowTemplate, item);
/* 19 */     this.isStart = true;
/*    */   }
/*    */ 
/*    */   public TaskStartTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 23 */     super(aWorkflowTemplate, type);
/* 24 */     this.isStart = true;
/*    */   }
/*    */   public Element getElement() {
/* 27 */     this.isStart = true;
/* 28 */     return super.getElement();
/*    */   }
/*    */   public void checkFlowLogic(List errorList) {
/* 31 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 32 */     if (joins.length == 0)
/* 33 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/* 34 */     else if (joins.length > 1) {
/* 35 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreLine"));
/*    */     }
/* 37 */     joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 38 */     if (joins.length > 0)
/* 39 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskStartTemplateImpl.checkFlowLogic_noInputLine"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskStartTemplateImpl
 * JD-Core Version:    0.5.4
 */