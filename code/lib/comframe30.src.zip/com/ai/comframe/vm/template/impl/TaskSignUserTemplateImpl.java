/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.TaskDealBean;
/*    */ import com.ai.comframe.vm.template.TaskSignTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskSignUserTemplateImpl extends TaskSignTemplateImpl
/*    */   implements TaskSignTemplate
/*    */ {
/*    */   public TaskSignUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 22 */     super(aWorkflowTemplate, item);
/* 23 */     initialFromConfig(this, item.attribute("tasktype").getValue());
/*    */   }
/*    */ 
/*    */   public TaskSignUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 28 */     super(aWorkflowTemplate, type);
/* 29 */     initialFromConfig(this, type);
/*    */   }
/*    */ 
/*    */   public static void initialFromConfig(TaskSignTemplateImpl signTemplate, String type) {
/* 33 */     TaskAutoUserUserTemplateImpl.initialFromConfig(signTemplate, type);
/* 34 */     Element item = TaskConfig.getInstance().getTaskConfigItem(type).xmlNode;
/*    */ 
/* 36 */     Element dealNode = item.element("childdeal");
/* 37 */     if (dealNode != null) {
/* 38 */       if (signTemplate.childDealBean == null) {
/* 39 */         signTemplate.childDealBean = new TaskDealBean("childdeal");
/*    */       }
/* 41 */       TaskAutoUserUserTemplateImpl.setDealInfo(signTemplate.childDealBean, dealNode);
/*    */     }
/*    */ 
/* 44 */     dealNode = item.element("revertdeal");
/* 45 */     if (dealNode != null) {
/* 46 */       if (signTemplate.revertDealBean == null) {
/* 47 */         signTemplate.revertDealBean = new TaskDealBean("revertdeal");
/*    */       }
/* 49 */       TaskAutoUserUserTemplateImpl.setDealInfo(signTemplate.revertDealBean, dealNode);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskSignUserTemplateImpl
 * JD-Core Version:    0.5.4
 */