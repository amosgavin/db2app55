package com.ai.comframe.vm.template;

public abstract interface TaskTimerTemplate extends TaskTemplate
{
  public static final String TIMER_TYPE_ABSOLUTE = "A";
  public static final String TIMER_TYPE_RELATIVE = "R";

  public abstract String getTimerType();

  public abstract void setTimerType(String paramString);

  public abstract String getRuntime();

  public abstract void setRuntime(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskTimerTemplate
 * JD-Core Version:    0.5.4
 */