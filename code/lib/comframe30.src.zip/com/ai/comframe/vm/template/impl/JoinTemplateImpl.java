/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class JoinTemplateImpl
/*     */   implements JoinTemplate
/*     */ {
/*  15 */   private static transient Log log = LogFactory.getLog(JoinTemplateImpl.class);
/*     */   private transient WorkflowTemplate workflowTemplate;
/*  18 */   protected String xmlTag = "join";
/*     */   protected String joinTemplateId;
/*     */   protected long taskTemplateAId;
/*     */   protected long taskTemplateBId;
/*     */   protected String label;
/*     */   protected int sequence;
/*     */   protected boolean isAgainst;
/*     */   protected String condition;
/*     */   protected String uiInfo;
/*     */   protected transient Object[] m_opList;
/*     */ 
/*     */   public JoinTemplateImpl(WorkflowTemplate aWorkflowTemplate)
/*     */   {
/*  30 */     this.workflowTemplate = aWorkflowTemplate;
/*     */   }
/*     */   public JoinTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item) {
/*  33 */     this.workflowTemplate = aWorkflowTemplate;
/*  34 */     this.joinTemplateId = item.attributeValue("id");
/*  35 */     this.label = item.attributeValue("label");
/*     */ 
/*  37 */     if (!StringUtils.isEmptyString(item.attributeValue("sequence"))) {
/*  38 */       this.sequence = Integer.parseInt(item.attributeValue("sequence"));
/*     */     }
/*     */ 
/*  41 */     if (!StringUtils.isEmptyString(item.attributeValue("taska"))) {
/*  42 */       this.taskTemplateAId = Long.parseLong(item.attributeValue("taska"));
/*     */     }
/*  44 */     if (!StringUtils.isEmptyString(item.attributeValue("taskb"))) {
/*  45 */       this.taskTemplateBId = Long.parseLong(item.attributeValue("taskb"));
/*     */     }
/*  47 */     if (!StringUtils.isEmptyString(item.attributeValue("isagainst"))) {
/*  48 */       this.isAgainst = Boolean.getBoolean(item.attributeValue("isagainst"));
/*     */     }
/*     */ 
/*  51 */     Element tmpNode = item.element("condition");
/*  52 */     if (tmpNode != null) {
/*  53 */       this.condition = tmpNode.getText();
/*     */     }
/*     */ 
/*  56 */     tmpNode = item.element("uiinfo");
/*  57 */     if (tmpNode != null)
/*  58 */       this.uiInfo = tmpNode.getText();
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/*  62 */     Element result = XmlUtil.createElement(this.xmlTag, null);
/*  63 */     result.addAttribute("id", this.joinTemplateId);
/*     */ 
/*  65 */     if (!StringUtils.isEmptyString(this.label)) {
/*  66 */       result.addAttribute("label", this.label);
/*     */     }
/*  68 */     if (this.sequence > 0) {
/*  69 */       result.addAttribute("sequence", Integer.toString(this.sequence));
/*     */     }
/*  71 */     if (this.taskTemplateAId > 0L)
/*  72 */       result.addAttribute("taska", Long.toString(this.taskTemplateAId));
/*  73 */     if (this.taskTemplateBId > 0L) {
/*  74 */       result.addAttribute("taskb", Long.toString(this.taskTemplateBId));
/*     */     }
/*  76 */     if (this.isAgainst == true) {
/*  77 */       result.addAttribute("isagainst", Boolean.toString(this.isAgainst));
/*     */     }
/*  79 */     if (!StringUtils.isEmptyString(this.condition))
/*  80 */       result.add(XmlUtil.createElement("condition", this.condition));
/*  81 */     if (!StringUtils.isEmptyString(this.uiInfo)) {
/*  82 */       result.add(XmlUtil.createElement("uiinfo", this.uiInfo));
/*     */     }
/*  84 */     return result;
/*     */   }
/*     */ 
/*     */   public void checkFlowLogic(List errorList) {
/*  88 */     if (getTaskTemplateA() == null)
/*  89 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_connect") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_noStartNode"));
/*  90 */     if (getTaskTemplateB() == null)
/*  91 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_connect") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_noTargetNode"));
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateAId()
/*     */   {
/*  96 */     return this.taskTemplateAId;
/*     */   }
/*     */   public long getTaskTemplateBId() {
/*  99 */     return this.taskTemplateBId;
/*     */   }
/*     */   public boolean getIsAgainst() {
/* 102 */     return this.isAgainst;
/*     */   }
/*     */   public void setIsAgainst(boolean value) {
/* 105 */     this.isAgainst = value;
/*     */   }
/*     */ 
/*     */   public String getJoinTemplateId() {
/* 109 */     return this.joinTemplateId;
/*     */   }
/*     */ 
/*     */   public String getUIInfo() {
/* 113 */     return this.uiInfo;
/*     */   }
/*     */ 
/*     */   public void setSequence(int seq) {
/* 117 */     this.sequence = seq;
/*     */   }
/*     */   public int getSequence() {
/* 120 */     return this.sequence;
/*     */   }
/*     */   public String getCondition() {
/* 123 */     return this.condition;
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplateA()
/*     */   {
/* 130 */     return this.workflowTemplate.getTaskTemplate(getTaskTemplateAId());
/*     */   }
/*     */ 
/*     */   public TaskTemplate getTaskTemplateB()
/*     */   {
/* 137 */     return this.workflowTemplate.getTaskTemplate(getTaskTemplateBId());
/*     */   }
/*     */ 
/*     */   public void setUIInfo(String aUIInfo)
/*     */   {
/* 143 */     this.uiInfo = aUIInfo;
/*     */   }
/*     */   public void setLabel(String aLabel) {
/* 146 */     this.label = aLabel;
/*     */   }
/*     */   public String getLabel() {
/* 149 */     return this.label;
/*     */   }
/*     */   public void setTaskTemplateAId(long id) {
/* 152 */     this.taskTemplateAId = id;
/*     */   }
/*     */ 
/*     */   public void setTaskTemplateBId(long id) {
/* 156 */     this.taskTemplateBId = id;
/*     */   }
/*     */   public void setCondition(String aCondition) {
/* 159 */     this.condition = aCondition;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 163 */     return XmlUtil.formatElement(getElement());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.JoinTemplateImpl
 * JD-Core Version:    0.5.4
 */