/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskFinishTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskFinishTemplateImpl extends TaskAutoUserTemplateImpl
/*    */   implements TaskFinishTemplate
/*    */ {
/*    */   public TaskFinishTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 18 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskFinishTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 22 */     super(aWorkflowTemplate, type);
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList) {
/* 26 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 27 */     if (joins.length > 0) {
/* 28 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskFinishTemplateImpl.checkFlowLogic_noOutPutLine"));
/*    */     }
/* 30 */     joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 31 */     if (joins.length == 0)
/* 32 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/* 33 */     else if (joins.length > 1)
/* 34 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreInLine"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskFinishTemplateImpl
 * JD-Core Version:    0.5.4
 */