/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.common.XmlUtil;
/*    */ import com.ai.comframe.vm.template.TaskShellTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskShellTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskShellTemplate
/*    */ {
/*    */   private String condition;
/*    */ 
/*    */   public TaskShellTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 15 */     super(aWorkflowTemplate, item);
/* 16 */     Element tmpNode = item.element("condition");
/* 17 */     if (tmpNode != null)
/* 18 */       this.condition = tmpNode.getTextTrim();
/*    */   }
/*    */ 
/*    */   public TaskShellTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 24 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public Element getElement() {
/* 28 */     Element result = super.getElement();
/* 29 */     result.add(XmlUtil.createElement("condition", this.condition));
/* 30 */     return result;
/*    */   }
/*    */ 
/*    */   public void setCondition(String value) {
/* 34 */     this.condition = value;
/*    */   }
/*    */ 
/*    */   public String getCondition() {
/* 38 */     return this.condition;
/*    */   }
/*    */   public void toJavaCode(StringBuffer buffer, int level) {
/* 41 */     buffer.append(getCondition()).append(";");
/*    */   }
/*    */   public String getDisplayText() {
/* 44 */     if ((this.label == null) || (this.label.trim().length() == 0)) {
/* 45 */       return this.condition;
/*    */     }
/* 47 */     return this.label;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskShellTemplateImpl
 * JD-Core Version:    0.5.4
 */