package com.ai.comframe.vm.template;

public abstract interface TaskBreakTemplate extends TaskTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskBreakTemplate
 * JD-Core Version:    0.5.4
 */