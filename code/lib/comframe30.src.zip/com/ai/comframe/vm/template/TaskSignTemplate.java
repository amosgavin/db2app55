package com.ai.comframe.vm.template;

public abstract interface TaskSignTemplate extends TaskUserTemplate
{
  public abstract TaskDealBean getChildDealBean();

  public abstract void setChildDealBean(TaskDealBean paramTaskDealBean);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskSignTemplate
 * JD-Core Version:    0.5.4
 */