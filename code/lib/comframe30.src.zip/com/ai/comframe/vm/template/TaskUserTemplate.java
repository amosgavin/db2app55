package com.ai.comframe.vm.template;

public abstract interface TaskUserTemplate extends TaskAutoTemplate
{
  public static final String TIMER_TYPE_ABSOLUTE = "A";
  public static final String TIMER_TYPE_RELATIVE = "R";
  public static final String S_TYPE_STAFF = "staff";
  public static final String S_TYPE_STATION = "station";
  public static final String S_TYPE_STATION_TYPE = "stationType";

  public abstract String getOrganizeId();

  public abstract void setOrganizeId(String paramString);

  public abstract String getOrganizeName();

  public abstract void setOrganizeName(String paramString);

  public abstract String getTaskUserType();

  public abstract void setTaskUserType(String paramString);

  public abstract String getTaskUserId();

  public abstract void setTaskUserId(String paramString);

  public abstract String getTaskUserName();

  public abstract void setTaskUserName(String paramString);

  public abstract boolean isNeedPrint();

  public abstract boolean getIsNeedPrint();

  public abstract void setIsNeedPrint(boolean paramBoolean);

  public abstract boolean isAutoPrint();

  public abstract boolean getIsAutoPrint();

  public abstract boolean isOverTime();

  public abstract void setIsAutoPrint(boolean paramBoolean);

  public abstract TaskDealBean getPrintDealBean();

  public abstract void setPrintDealBean(TaskDealBean paramTaskDealBean);

  public abstract TaskDealBean getPostDealBean();

  public abstract void setPostDealBean(TaskDealBean paramTaskDealBean);

  public abstract String getOvertimeType();

  public abstract void setOvertimeType(String paramString);

  public abstract String getOvertimeValue();

  public abstract void setOvertimeValue(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskUserTemplate
 * JD-Core Version:    0.5.4
 */