/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import com.ai.comframe.vm.template.TaskDealBean;
/*    */ import com.ai.comframe.vm.template.TaskDecisionAutoTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskDecisionAutoTemplateImpl extends TaskAutoTemplateImpl
/*    */   implements TaskDecisionAutoTemplate
/*    */ {
/*    */   public TaskDecisionAutoTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 18 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskDecisionAutoTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 22 */     super(aWorkflowTemplate, type);
/*    */   }
/*    */   public void checkFlowLogic(List errorList) {
/* 25 */     TaskDecisionConditionTemplateImpl.checkFlowLogicStatic(this, errorList);
/*    */   }
/*    */ 
/*    */   public void toJavaCode(StringBuffer buffer, int level)
/*    */   {
/* 31 */     if (this.autoDealBean == null) {
/* 32 */       buffer.append("logger.warn(\"").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_setNode")).append(getLabel()).append(")\");");
/*    */ 
/* 34 */       return;
/*    */     }
/* 36 */     if ("service".equalsIgnoreCase(this.autoDealBean.getRunType()) == true)
/* 37 */       toServiceJavaCode(buffer, level);
/*    */     else
/* 39 */       toPojoJavaCode(buffer, level);
/*    */   }
/*    */ 
/*    */   public void toServiceJavaCode(StringBuffer buffer, int level)
/*    */   {
/* 44 */     ParameterDefine[] parameters = this.autoDealBean.getFunctionParameterDefine();
/*    */ 
/* 46 */     String functionStr = "((" + this.autoDealBean.getRunClassName() + ")com.ai.comframe.vm.common.ServiceUtil.getService(\"" + this.autoDealBean.getServiceName() + "\"," + this.autoDealBean.getRunClassName() + ".class))." + this.autoDealBean.getRunFunctionName() + "(";
/*    */ 
/* 50 */     for (int i = 0; i < parameters.length; ++i) {
/* 51 */       if (i > 0)
/* 52 */         functionStr = functionStr + ",";
/* 53 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 54 */         functionStr = functionStr + Process2JavaUtil.getVarTransferString(getWorkflowTemplate().getVars(parameters[i].contextVarName).getDataTypeClass(), parameters[i].getDataTypeClass(), parameters[i].contextVarName);
/*    */       }
/*    */       else
/*    */       {
/* 63 */         functionStr = functionStr + Process2JavaUtil.getDefaultValueString(parameters[i].getDataTypeClass(), parameters[i].defaultValue);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 68 */     functionStr = functionStr + ")";
/* 69 */     buffer.append(functionStr);
/*    */   }
/*    */ 
/*    */   public void toPojoJavaCode(StringBuffer buffer, int level) {
/* 73 */     ParameterDefine[] parameters = this.autoDealBean.getFunctionParameterDefine();
/* 74 */     String functionStr = " new " + this.autoDealBean.getRunClassName() + "()." + this.autoDealBean.getRunFunctionName() + "(";
/* 75 */     for (int i = 0; i < parameters.length; ++i) {
/* 76 */       if (i > 0)
/* 77 */         functionStr = functionStr + ",";
/* 78 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 79 */         functionStr = functionStr + Process2JavaUtil.getVarTransferString(getWorkflowTemplate().getVars(parameters[i].contextVarName).getDataTypeClass(), parameters[i].getDataTypeClass(), parameters[i].contextVarName);
/*    */       }
/*    */       else
/*    */       {
/* 84 */         functionStr = functionStr + Process2JavaUtil.getDefaultValueString(parameters[i].getDataTypeClass(), parameters[i].defaultValue);
/*    */       }
/*    */     }
/* 87 */     functionStr = functionStr + ")";
/* 88 */     buffer.append(functionStr);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskDecisionAutoTemplateImpl
 * JD-Core Version:    0.5.4
 */