/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.TaskDecisionTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Attribute;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskDecisionAutoUserTemplateImpl extends TaskDecisionAutoTemplateImpl
/*    */   implements TaskDecisionTemplate
/*    */ {
/*    */   public TaskDecisionAutoUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 13 */     super(aWorkflowTemplate, item);
/* 14 */     TaskAutoUserTemplateImpl.initialFromConfig(this, item.attribute("tasktype").getValue());
/*    */   }
/*    */ 
/*    */   public TaskDecisionAutoUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 18 */     super(aWorkflowTemplate, type);
/* 19 */     TaskAutoUserTemplateImpl.initialFromConfig(this, type);
/*    */   }
/*    */   public void checkFlowLogic(List errorList) {
/* 22 */     TaskDecisionConditionTemplateImpl.checkFlowLogicStatic(this, errorList);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskDecisionAutoUserTemplateImpl
 * JD-Core Version:    0.5.4
 */