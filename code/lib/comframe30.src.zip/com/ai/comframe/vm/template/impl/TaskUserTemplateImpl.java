/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskUserTemplateImpl extends TaskAutoTemplateImpl
/*     */   implements TaskUserTemplate
/*     */ {
/*     */   private String taskUserType;
/*     */   private String organizeId;
/*     */   private String organizeName;
/*     */   private String taskUserId;
/*     */   private String taskUserName;
/*     */   private String overtimeType;
/*     */   private String overtimeValue;
/*  30 */   private boolean isNeedPrint = false;
/*     */ 
/*  32 */   private boolean isAutoPrint = false;
/*     */ 
/*  34 */   private boolean isOverTime = false;
/*     */   protected TaskDealBean postDealBean;
/*     */   protected TaskDealBean printDealBean;
/*     */ 
/*     */   public TaskUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  42 */     super(aWorkflowTemplate, item);
/*     */ 
/*  44 */     Element tmpNode = item.element("user");
/*  45 */     this.taskUserType = tmpNode.attributeValue("taskusertype");
/*  46 */     this.organizeId = tmpNode.attributeValue("organizeid");
/*  47 */     this.organizeName = tmpNode.attributeValue("organizename");
/*  48 */     this.taskUserId = tmpNode.attributeValue("taskuserid");
/*  49 */     this.taskUserName = tmpNode.attributeValue("taskusername");
/*  50 */     String s = tmpNode.attributeValue("isneedprint");
/*  51 */     if ((s != null) && (s.trim().length() > 0)) {
/*  52 */       this.isNeedPrint = Boolean.valueOf(s).booleanValue();
/*     */     }
/*  54 */     s = tmpNode.attributeValue("isautoprint");
/*  55 */     if ((s != null) && (s.trim().length() > 0)) {
/*  56 */       this.isAutoPrint = Boolean.valueOf(s).booleanValue();
/*     */     }
/*     */ 
/*  59 */     tmpNode = item.element("overtime");
/*  60 */     if (tmpNode != null) {
/*  61 */       this.isOverTime = true;
/*  62 */       this.overtimeType = tmpNode.attributeValue("type");
/*  63 */       this.overtimeValue = tmpNode.attributeValue("value");
/*     */     }
/*     */     else {
/*  66 */       this.isOverTime = false;
/*     */     }
/*  68 */     tmpNode = item.element("printdeal");
/*  69 */     if (tmpNode != null) {
/*  70 */       this.printDealBean = new TaskDealBean(tmpNode);
/*     */     }
/*  72 */     tmpNode = item.element("postdeal");
/*  73 */     if (tmpNode != null)
/*  74 */       this.postDealBean = new TaskDealBean(tmpNode);
/*     */   }
/*     */ 
/*     */   public TaskUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  80 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */   }
/*     */ 
/*     */   public Element getElement()
/*     */   {
/*  85 */     Element result = super.getElement();
/*  86 */     Element node = result.addElement("user");
/*     */ 
/*  88 */     node.addAttribute("taskusertype", this.taskUserType);
/*     */ 
/*  90 */     if ((this.organizeId != null) && (this.organizeId.trim().length() > 0)) {
/*  91 */       node.addAttribute("organizeid", this.organizeId);
/*  92 */       node.addAttribute("organizename", this.organizeName);
/*     */     }
/*     */ 
/*  95 */     node.addAttribute("taskuserid", this.taskUserId);
/*  96 */     node.addAttribute("taskusername", this.taskUserName);
/*     */ 
/*  98 */     if (this.isNeedPrint == true) {
/*  99 */       node.addAttribute("isneedprint", String.valueOf(this.isNeedPrint));
/*     */     }
/* 101 */     if (this.isAutoPrint == true) {
/* 102 */       node.addAttribute("isautoprint", String.valueOf(this.isAutoPrint));
/*     */     }
/* 104 */     if (this.printDealBean != null) {
/* 105 */       result.add(this.printDealBean.getElement());
/*     */     }
/* 107 */     if (this.postDealBean != null) {
/* 108 */       result.add(this.postDealBean.getElement());
/*     */     }
/* 110 */     if (!StringUtils.isEmptyString(this.overtimeValue)) {
/* 111 */       Element overtimeDeal = result.addElement("overtime");
/* 112 */       if (StringUtils.isEmptyString(this.overtimeType))
/* 113 */         this.overtimeType = "R";
/* 114 */       overtimeDeal.addAttribute("type", this.overtimeType);
/* 115 */       overtimeDeal.addAttribute("value", this.overtimeValue);
/*     */     }
/*     */ 
/* 118 */     return result;
/*     */   }
/*     */ 
/*     */   public String getOrganizeId() {
/* 122 */     return this.organizeId;
/*     */   }
/*     */   public String getTaskUserId() {
/* 125 */     return this.taskUserId;
/*     */   }
/*     */   public String getTaskUserType() {
/* 128 */     return this.taskUserType;
/*     */   }
/*     */   public void setOrganizeId(String organizeId) {
/* 131 */     this.organizeId = organizeId;
/*     */   }
/*     */   public void setTaskUserId(String taskUserId) {
/* 134 */     this.taskUserId = taskUserId;
/*     */   }
/*     */   public void setTaskUserType(String taskUserType) {
/* 137 */     this.taskUserType = taskUserType;
/*     */   }
/*     */   public String getTaskUserName() {
/* 140 */     return this.taskUserName;
/*     */   }
/*     */   public String getOrganizeName() {
/* 143 */     return this.organizeName;
/*     */   }
/*     */   public void setOrganizeName(String organizeName) {
/* 146 */     this.organizeName = organizeName;
/*     */   }
/*     */   public void setTaskUserName(String taskUserName) {
/* 149 */     this.taskUserName = taskUserName;
/*     */   }
/*     */   public boolean isNeedPrint() {
/* 152 */     return this.isNeedPrint;
/*     */   }
/*     */   public boolean getIsNeedPrint() {
/* 155 */     return this.isNeedPrint;
/*     */   }
/*     */   public void setIsNeedPrint(boolean value) {
/* 158 */     this.isNeedPrint = value;
/*     */   }
/*     */ 
/*     */   public boolean isAutoPrint() {
/* 162 */     return this.isAutoPrint;
/*     */   }
/*     */   public boolean getIsAutoPrint() {
/* 165 */     return this.isAutoPrint;
/*     */   }
/*     */   public void setIsAutoPrint(boolean value) {
/* 168 */     this.isAutoPrint = value;
/*     */   }
/*     */ 
/*     */   public TaskDealBean getPrintDealBean() {
/* 172 */     return this.printDealBean;
/*     */   }
/*     */ 
/*     */   public void setPrintDealBean(TaskDealBean value) {
/* 176 */     this.printDealBean = value;
/*     */   }
/*     */ 
/*     */   public TaskDealBean getPostDealBean() {
/* 180 */     return this.postDealBean;
/*     */   }
/*     */ 
/*     */   public void setPostDealBean(TaskDealBean value) {
/* 184 */     this.postDealBean = value;
/*     */   }
/*     */   public String getOvertimeType() {
/* 187 */     return this.overtimeType;
/*     */   }
/*     */   public void setOvertimeType(String overtimeType) {
/* 190 */     this.overtimeType = overtimeType;
/*     */   }
/*     */   public String getOvertimeValue() {
/* 193 */     return this.overtimeValue;
/*     */   }
/*     */   public void setOvertimeValue(String overtimeValue) {
/* 196 */     this.overtimeValue = overtimeValue;
/*     */   }
/*     */   public boolean isOverTime() {
/* 199 */     return this.isOverTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskUserTemplateImpl
 * JD-Core Version:    0.5.4
 */