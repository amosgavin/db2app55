/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskWorkflowUserTemplateImpl extends TaskWorkflowTemplateImpl
/*     */ {
/*     */   public TaskWorkflowUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  25 */     super(aWorkflowTemplate, item);
/*  26 */     initialFromConfig(this, item.attribute("tasktype").getValue());
/*     */   }
/*     */ 
/*     */   public TaskWorkflowUserTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  31 */     super(aWorkflowTemplate, type);
/*  32 */     initialFromConfig(this, type);
/*     */   }
/*     */ 
/*     */   public void initialFromConfig(TaskWorkflowUserTemplateImpl childWorkflow, String type) {
/*  36 */     Element item = TaskConfig.getInstance().getTaskConfigItem(type).xmlNode;
/*     */ 
/*  38 */     Element childNode = item.element("child");
/*  39 */     if (childNode != null) {
/*  40 */       childWorkflow.workflowCode = childNode.attributeValue("code");
/*  41 */       childWorkflow.workflowName = childNode.attributeValue("name");
/*  42 */       childWorkflow.workflowType = childNode.attributeValue("type");
/*  43 */       List childVarList = childWorkflow.getWorkflowVars();
/*  44 */       List tmpList = childNode.elements("vars");
/*  45 */       if ((childVarList != null) && (childVarList.size() == tmpList.size())) {
/*  46 */         for (int i = 0; i < tmpList.size(); ++i) {
/*  47 */           Element tmpNode = (Element)tmpList.get(i);
/*  48 */           ParameterDefine wvm = (ParameterDefine)childVarList.get(i);
/*  49 */           wvm.name = tmpNode.attributeValue("name");
/*  50 */           wvm.dataType = tmpNode.attributeValue("datatype");
/*  51 */           wvm.inOutType = tmpNode.attributeValue("inouttype");
/*  52 */           wvm.description = tmpNode.attributeValue("description");
/*  53 */           if (wvm.contextVarName == null)
/*  54 */             wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  59 */         childVarList = new ArrayList();
/*  60 */         for (int i = 0; i < tmpList.size(); ++i) {
/*  61 */           Element tmpNode = (Element)tmpList.get(i);
/*  62 */           ParameterDefine p = new ParameterDefine();
/*  63 */           p.name = tmpNode.attributeValue("name");
/*  64 */           p.dataType = tmpNode.attributeValue("datatype");
/*  65 */           p.inOutType = tmpNode.attributeValue("inouttype");
/*  66 */           p.description = tmpNode.attributeValue("description");
/*  67 */           p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  68 */           childVarList.add(p);
/*     */         }
/*     */       }
/*  71 */       childWorkflow.setWorkflowVars(childVarList);
/*     */     }
/*     */ 
/*  74 */     Element dealNode = item.element("autodeal");
/*  75 */     if (dealNode == null) {
/*  76 */       return;
/*     */     }
/*  78 */     if (childWorkflow.autoDealBean == null) {
/*  79 */       childWorkflow.autoDealBean = new TaskDealBean("autodeal");
/*     */     }
/*     */ 
/*  82 */     childWorkflow.autoDealBean.setRunType(dealNode.elementText("runtype"));
/*  83 */     childWorkflow.autoDealBean.setServiceName(dealNode.elementText("servicename"));
/*  84 */     childWorkflow.autoDealBean.setRunClassName(dealNode.elementText("runclassname"));
/*  85 */     childWorkflow.autoDealBean.setRunFunctionName(dealNode.elementText("runfunctionname"));
/*     */ 
/*  87 */     List wvmList = childWorkflow.autoDealBean.getVars();
/*  88 */     List tmpList = dealNode.elements("vars");
/*  89 */     if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/*  90 */       for (int i = 0; i < tmpList.size(); ++i) {
/*  91 */         Element tmpNode = (Element)tmpList.get(i);
/*  92 */         ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/*  93 */         wvm.name = tmpNode.attributeValue("name");
/*  94 */         wvm.dataType = tmpNode.attributeValue("datatype");
/*  95 */         wvm.inOutType = tmpNode.attributeValue("inouttype");
/*  96 */         wvm.description = tmpNode.attributeValue("description");
/*  97 */         if (wvm.contextVarName == null)
/*  98 */           wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 103 */       wvmList = new ArrayList();
/* 104 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 105 */         Element tmpNode = (Element)tmpList.get(i);
/* 106 */         ParameterDefine p = new ParameterDefine();
/* 107 */         p.name = tmpNode.attributeValue("name");
/* 108 */         p.dataType = tmpNode.attributeValue("datatype");
/* 109 */         p.inOutType = tmpNode.attributeValue("inouttype");
/* 110 */         p.description = tmpNode.attributeValue("description");
/* 111 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/* 112 */         wvmList.add(p);
/*     */       }
/*     */     }
/* 115 */     childWorkflow.autoDealBean.setVars(wvmList);
/*     */ 
/* 118 */     dealNode = item.element("revertdeal");
/* 119 */     if (dealNode == null) {
/* 120 */       return;
/*     */     }
/* 122 */     if (childWorkflow.revertDealBean == null) {
/* 123 */       childWorkflow.revertDealBean = new TaskDealBean("revertdeal");
/*     */     }
/*     */ 
/* 126 */     childWorkflow.revertDealBean.setRunType(dealNode.elementText("runtype"));
/* 127 */     childWorkflow.revertDealBean.setServiceName(dealNode.elementText("servicename"));
/* 128 */     childWorkflow.revertDealBean.setRunClassName(dealNode.elementText("runclassname"));
/* 129 */     childWorkflow.revertDealBean.setRunFunctionName(dealNode.elementText("runfunctionname"));
/*     */ 
/* 131 */     wvmList = childWorkflow.revertDealBean.getVars();
/* 132 */     tmpList = dealNode.elements("vars");
/* 133 */     if ((wvmList != null) && (wvmList.size() == tmpList.size())) {
/* 134 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 135 */         Element tmpNode = (Element)tmpList.get(i);
/* 136 */         ParameterDefine wvm = (ParameterDefine)wvmList.get(i);
/* 137 */         wvm.name = tmpNode.attributeValue("name");
/* 138 */         wvm.dataType = tmpNode.attributeValue("datatype");
/* 139 */         wvm.inOutType = tmpNode.attributeValue("inouttype");
/* 140 */         wvm.description = tmpNode.attributeValue("description");
/* 141 */         if (wvm.contextVarName == null)
/* 142 */           wvm.contextVarName = tmpNode.attributeValue("contextvarName");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 147 */       wvmList = new ArrayList();
/* 148 */       for (int i = 0; i < tmpList.size(); ++i) {
/* 149 */         Element tmpNode = (Element)tmpList.get(i);
/* 150 */         ParameterDefine p = new ParameterDefine();
/* 151 */         p.name = tmpNode.attributeValue("name");
/* 152 */         p.dataType = tmpNode.attributeValue("datatype");
/* 153 */         p.inOutType = tmpNode.attributeValue("inouttype");
/* 154 */         p.description = tmpNode.attributeValue("description");
/* 155 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/* 156 */         wvmList.add(p);
/*     */       }
/*     */     }
/* 159 */     childWorkflow.revertDealBean.setVars(wvmList);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskWorkflowUserTemplateImpl
 * JD-Core Version:    0.5.4
 */