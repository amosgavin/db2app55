/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ class TaskNodeCase extends TaskNode
/*     */ {
/* 455 */   Map m_caseChild = new HashMap();
/*     */   TaskNode m_defaultChild;
/*     */ 
/*     */   public TaskNodeCase(TaskNode parent, TaskTemplate task)
/*     */   {
/* 458 */     super(parent, task);
/*     */   }
/*     */ 
/*     */   public void addCaseChildren(JoinTemplate caseJoin, TaskNode taskNode) {
/* 462 */     this.m_caseChild.put(caseJoin, taskNode);
/*     */   }
/*     */ 
/*     */   public void setDefaultChildren(TaskNode taskNode) {
/* 466 */     this.m_defaultChild = taskNode;
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level)
/*     */   {
/* 472 */     this.m_task.toJavaRemark(buffer, level);
/* 473 */     boolean isFirst = true;
/* 474 */     for (Iterator it = this.m_caseChild.entrySet().iterator(); it.hasNext(); ) {
/* 475 */       Map.Entry me = (Map.Entry)it.next();
/* 476 */       JoinTemplate tmpJoin = (JoinTemplate)me.getKey();
/* 477 */       TaskNode tmpNode = (TaskNode)me.getValue();
/* 478 */       appendLevel(buffer, level);
/* 479 */       if (isFirst == true) {
/* 480 */         buffer.append("if(");
/* 481 */         isFirst = false;
/*     */       } else {
/* 483 */         buffer.append("else if(");
/*     */       }
/* 485 */       buffer.append(tmpJoin.getCondition());
/* 486 */       buffer.append("){\n");
/* 487 */       for (int i = 0; i < tmpNode.m_child.size(); ++i) {
/* 488 */         ((TaskNode)tmpNode.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */       }
/* 490 */       appendLevel(buffer, level);
/* 491 */       buffer.append("}\n");
/*     */     }
/* 493 */     appendLevel(buffer, level);
/* 494 */     buffer.append("else{\n");
/* 495 */     for (int i = 0; i < this.m_defaultChild.m_child.size(); ++i) {
/* 496 */       ((TaskNode)this.m_defaultChild.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */     }
/* 498 */     appendLevel(buffer, level);
/* 499 */     buffer.append("}\n");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskNodeCase
 * JD-Core Version:    0.5.4
 */