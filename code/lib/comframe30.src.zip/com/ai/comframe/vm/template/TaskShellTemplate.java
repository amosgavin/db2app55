package com.ai.comframe.vm.template;

public abstract interface TaskShellTemplate extends TaskTemplate
{
  public abstract String getCondition();

  public abstract void setCondition(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskShellTemplate
 * JD-Core Version:    0.5.4
 */