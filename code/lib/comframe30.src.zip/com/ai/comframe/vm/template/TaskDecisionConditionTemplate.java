package com.ai.comframe.vm.template;

public abstract interface TaskDecisionConditionTemplate extends TaskDecisionTemplate
{
  public abstract String getCondition();

  public abstract void setCondition(String paramString);

  public abstract Object[] getOperatorList();

  public abstract void setOperatorList(Object[] paramArrayOfObject);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskDecisionConditionTemplate
 * JD-Core Version:    0.5.4
 */