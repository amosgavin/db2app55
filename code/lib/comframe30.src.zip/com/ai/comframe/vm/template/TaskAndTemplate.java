package com.ai.comframe.vm.template;

public abstract interface TaskAndTemplate extends TaskTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskAndTemplate
 * JD-Core Version:    0.5.4
 */