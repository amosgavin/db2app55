/*    */ package com.ai.comframe.vm.template;
/*    */ 
/*    */ public class GoToItem
/*    */ {
/*    */   private String condition;
/*    */   private long nextTaskTemplateId;
/*    */   private transient Object[] m_opList;
/*    */ 
/*    */   public GoToItem()
/*    */   {
/*    */   }
/*    */ 
/*    */   public GoToItem(String aCondition, long aNextTaskTemplateId)
/*    */   {
/* 11 */     this.condition = aCondition;
/* 12 */     this.nextTaskTemplateId = aNextTaskTemplateId;
/*    */   }
/*    */   public String getCondition() {
/* 15 */     return this.condition;
/*    */   }
/*    */   public long getNextTaskTemplateId() {
/* 18 */     return this.nextTaskTemplateId;
/*    */   }
/*    */   public void setNextTaskTemplateId(long nextTaskTemplateId) {
/* 21 */     this.nextTaskTemplateId = nextTaskTemplateId;
/*    */   }
/*    */   public void setCondition(String condition) {
/* 24 */     this.condition = condition;
/*    */   }
/*    */ 
/*    */   public Object[] getOperatorList() {
/* 28 */     return this.m_opList;
/*    */   }
/*    */ 
/*    */   public synchronized void setOperatorList(Object[] operatorList) {
/* 32 */     this.m_opList = operatorList;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.GoToItem
 * JD-Core Version:    0.5.4
 */