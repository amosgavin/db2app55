/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.template.GoToItem;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskBaseTemplateImpl
/*     */   implements TaskTemplate
/*     */ {
/*  21 */   protected String xmlTag = "task";
/*     */   protected String taskType;
/*     */   protected long taskTemplateId;
/*     */   protected String taskTag;
/*     */   protected String label;
/*     */   protected String description;
/*     */   protected WorkflowTemplate workflowTemplate;
/*     */   protected String duration;
/*     */   protected String uiInfo;
/*     */   protected boolean isStart;
/*     */   protected String monitorType;
/*     */   protected String monitorService;
/*  34 */   protected List m_goToItem = new ArrayList();
/*     */ 
/*  36 */   protected List m_vars = new ArrayList();
/*     */   private int state;
/*     */ 
/*     */   public TaskBaseTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type, String aLabel)
/*     */   {
/*  39 */     this.workflowTemplate = aWorkflowTemplate;
/*  40 */     this.taskType = type;
/*  41 */     this.label = aLabel;
/*  42 */     if (aWorkflowTemplate != null)
/*  43 */       this.taskTemplateId = aWorkflowTemplate.getMaxTaskTemplateId();
/*     */   }
/*     */ 
/*     */   public TaskBaseTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  48 */     this.workflowTemplate = aWorkflowTemplate;
/*     */ 
/*  50 */     if (!StringUtils.isEmptyString(item.attributeValue("id"))) {
/*  51 */       this.taskTemplateId = Long.parseLong(item.attributeValue("id"));
/*     */     }
/*  53 */     this.taskType = item.attributeValue("tasktype");
/*  54 */     this.label = item.attributeValue("label");
/*  55 */     this.taskTag = item.attributeValue("tasktag");
/*     */ 
/*  57 */     Element monitorNode = item.element("monitor");
/*  58 */     if (monitorNode != null) {
/*  59 */       this.monitorType = monitorNode.attributeValue("type");
/*  60 */       this.monitorService = monitorNode.attributeValue("service");
/*     */     }
/*     */ 
/*  63 */     if (item.attributeValue("isstart") != null) {
/*  64 */       this.isStart = Boolean.valueOf(item.attributeValue("isstart")).booleanValue();
/*     */     }
/*     */     else {
/*  67 */       this.isStart = false;
/*     */     }
/*  69 */     if (item.attributeValue("duration") != null) {
/*  70 */       this.duration = item.attributeValue("duration");
/*     */     }
/*  72 */     Element tmpNode = item.element("description");
/*  73 */     if (tmpNode != null) {
/*  74 */       this.description = tmpNode.getTextTrim();
/*     */     }
/*     */ 
/*  77 */     tmpNode = item.element("uiinfo");
/*  78 */     if (tmpNode != null) {
/*  79 */       this.uiInfo = tmpNode.getTextTrim();
/*     */     }
/*     */ 
/*  82 */     List tmpList = item.elements("vars");
/*     */ 
/*  84 */     for (int i = 0; i < tmpList.size(); ++i) {
/*  85 */       tmpNode = (Element)tmpList.get(i);
/*  86 */       ParameterDefine p = new ParameterDefine();
/*  87 */       p.name = tmpNode.attributeValue("name");
/*  88 */       p.dataType = tmpNode.attributeValue("datatype");
/*  89 */       p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  90 */       p.defaultValue = tmpNode.attributeValue("defaultvalue");
/*  91 */       p.inOutType = tmpNode.attributeValue("inouttype");
/*  92 */       p.description = tmpNode.attributeValue("description");
/*  93 */       this.m_vars.add(p);
/*     */     }
/*     */ 
/*  97 */     tmpList = item.elements("gotoitem");
/*  98 */     for (int i = 0; i < tmpList.size(); ++i) {
/*  99 */       GoToItem gotoItem = new GoToItem();
/* 100 */       tmpNode = (Element)tmpList.get(i);
/* 101 */       gotoItem.setCondition(tmpNode.attributeValue("condition"));
/* 102 */       if (tmpNode.attributeValue("goto") != null) {
/* 103 */         gotoItem.setNextTaskTemplateId(Long.parseLong(tmpNode.attributeValue("goto")));
/*     */       }
/* 105 */       this.m_goToItem.add(gotoItem);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Element getElement()
/*     */   {
/* 112 */     Element result = XmlUtil.createElement(this.xmlTag, null);
/* 113 */     if (this.taskTemplateId > 0L) {
/* 114 */       result.addAttribute("id", Long.toString(this.taskTemplateId));
/*     */     }
/* 116 */     result.addAttribute("label", this.label);
/* 117 */     result.addAttribute("tasktype", this.taskType);
/* 118 */     result.addAttribute("tasktag", this.taskTag);
/*     */ 
/* 120 */     if (this.isStart == true) {
/* 121 */       result.addAttribute("isstart", Boolean.toString(this.isStart));
/*     */     }
/* 123 */     if (!StringUtils.isEmptyString(this.duration)) {
/* 124 */       result.addAttribute("duration", this.duration);
/*     */     }
/* 126 */     if (!StringUtils.isEmptyString(this.description)) {
/* 127 */       result.add(XmlUtil.createElement("description", this.description));
/*     */     }
/* 129 */     if (!StringUtils.isEmptyString(this.uiInfo)) {
/* 130 */       result.add(XmlUtil.createElement("uiinfo", this.uiInfo));
/*     */     }
/* 132 */     if (!StringUtils.isEmptyString(this.monitorService)) {
/* 133 */       Element node = result.addElement("monitor");
/* 134 */       String type = this.monitorType;
/* 135 */       if (StringUtils.isEmptyString(type)) {
/* 136 */         type = "pojo";
/*     */       }
/* 138 */       node.addAttribute("type", type);
/* 139 */       node.addAttribute("service", this.monitorService);
/*     */     }
/*     */ 
/* 144 */     for (Iterator it = this.m_vars.iterator(); it.hasNext(); ) {
/* 145 */       Element e = result.addElement("vars");
/* 146 */       ParameterDefine p = (ParameterDefine)it.next();
/* 147 */       e.addAttribute("name", p.name);
/* 148 */       e.addAttribute("datatype", p.dataType);
/* 149 */       e.addAttribute("contextvarName", p.contextVarName);
/* 150 */       e.addAttribute("defaultvalue", p.defaultValue);
/* 151 */       e.addAttribute("inouttype", p.inOutType);
/* 152 */       e.addAttribute("description", p.description);
/*     */     }
/*     */ 
/* 157 */     for (Iterator it = this.m_goToItem.iterator(); it.hasNext(); ) {
/* 158 */       Element e = result.addElement("gotoitem");
/* 159 */       GoToItem gotoItem = (GoToItem)it.next();
/* 160 */       if ((gotoItem.getCondition() != null) && (gotoItem.getCondition().trim().length() > 0))
/*     */       {
/* 162 */         e.addAttribute("condition", gotoItem.getCondition());
/* 163 */       }e.addAttribute("goto", Long.toString(gotoItem.getNextTaskTemplateId()));
/*     */     }
/*     */ 
/* 166 */     return result;
/*     */   }
/*     */ 
/*     */   public void checkFlowLogic(List errorList) {
/* 170 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 171 */     if (joins.length == 0)
/* 172 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/* 173 */     else if (joins.length > 1) {
/* 174 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreInLine"));
/*     */     }
/* 176 */     joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 177 */     if (joins.length == 0)
/* 178 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/* 179 */     else if (joins.length > 1)
/* 180 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreLine"));
/*     */   }
/*     */ 
/*     */   public List getGoToItems() {
/* 184 */     return this.m_goToItem;
/*     */   }
/*     */   public GoToItem getGoToItem(String condition) {
/* 187 */     for (Iterator it = this.m_goToItem.iterator(); it.hasNext(); ) {
/* 188 */       GoToItem go = (GoToItem)it.next();
/* 189 */       if (condition.equalsIgnoreCase(go.getCondition()) == true)
/* 190 */         return go;
/*     */     }
/* 192 */     return null;
/*     */   }
/*     */   public GoToItem getGoToItem() {
/* 195 */     if (this.m_goToItem.size() > 0) {
/* 196 */       return (GoToItem)this.m_goToItem.get(0);
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isStart()
/*     */   {
/* 203 */     return this.isStart;
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 207 */     return this.taskType;
/*     */   }
/*     */   public void setTaskType(String value) {
/* 210 */     this.taskType = value;
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 214 */     return this.taskTemplateId;
/*     */   }
/*     */   public String getTaskTag() {
/* 217 */     return this.taskTag;
/*     */   }
/*     */   public void setTaskTag(String tag) {
/* 220 */     this.taskTag = tag;
/*     */   }
/*     */   public String getDescription() {
/* 223 */     return this.description;
/*     */   }
/*     */ 
/*     */   public String getDisplayText() {
/* 227 */     return getLabel();
/*     */   }
/*     */   public String getLabel() {
/* 230 */     return this.label;
/*     */   }
/*     */ 
/*     */   public String getDuration() {
/* 234 */     return this.duration;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplate() {
/* 238 */     return this.workflowTemplate;
/*     */   }
/*     */ 
/*     */   public void setMonitorType(String value) {
/* 242 */     this.monitorType = value;
/*     */   }
/*     */ 
/*     */   public String getMonitorType() {
/* 246 */     return this.monitorType;
/*     */   }
/*     */ 
/*     */   public void setMonitorService(String value) {
/* 250 */     this.monitorService = value;
/*     */   }
/*     */ 
/*     */   public String getMonitorService() {
/* 254 */     return this.monitorService;
/*     */   }
/*     */ 
/*     */   public List getVars() {
/* 258 */     return this.m_vars;
/*     */   }
/*     */ 
/*     */   public ParameterDefine getVars(String name) {
/* 262 */     if (name.equalsIgnoreCase("$WORKFLOW_ID")) {
/* 263 */       return ParameterDefine.S_WORKFLOW_ID;
/*     */     }
/* 265 */     if (name.equalsIgnoreCase("$TASK_ID")) {
/* 266 */       return ParameterDefine.S_TASK_ID;
/*     */     }
/*     */ 
/* 269 */     if (name.equalsIgnoreCase("$WORKFLOW_TAG")) {
/* 270 */       return ParameterDefine.S_WORKFLOW_TAG;
/*     */     }
/* 272 */     if (name.equalsIgnoreCase("$TASK_TAG")) {
/* 273 */       return ParameterDefine.S_TASK_TAG;
/*     */     }
/* 275 */     if (name.equalsIgnoreCase("$QUEUE_ID")) {
/* 276 */       return ParameterDefine.S_QUEUE_ID;
/*     */     }
/* 278 */     if (name.equalsIgnoreCase("$IS_WAIT_USER")) {
/* 279 */       return ParameterDefine.S_USERTASK_IS_WAIT;
/*     */     }
/* 281 */     if (name.equalsIgnoreCase("$CONTEXT_MAP")) {
/* 282 */       return ParameterDefine.S_CONTEXT_MAP;
/*     */     }
/* 284 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_ID")) {
/* 285 */       return ParameterDefine.S_WORKFLOW_OBJ_ID;
/*     */     }
/* 287 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_TYPE_ID")) {
/* 288 */       return ParameterDefine.S_WORKFLOW_OBJ_TYPE_ID;
/*     */     }
/* 290 */     if (name.equalsIgnoreCase("$TASK_EXCEPTION_CODE")) {
/* 291 */       return ParameterDefine.S_TASK_EXCEPTION_CODE;
/*     */     }
/* 293 */     if (name.equalsIgnoreCase("$TASK_EXCEPTION_MSG")) {
/* 294 */       return ParameterDefine.S_TASK_EXCEPTION_MSG;
/*     */     }
/* 296 */     for (int i = 0; i < this.m_vars.size(); ++i) {
/* 297 */       ParameterDefine p = (ParameterDefine)this.m_vars.get(i);
/* 298 */       if (p.name.equalsIgnoreCase(name))
/* 299 */         return p;
/*     */     }
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */   public void setUIInfo(String aUIInfo)
/*     */   {
/* 307 */     this.uiInfo = aUIInfo;
/*     */   }
/*     */   public String getUIInfo() {
/* 310 */     return this.uiInfo;
/*     */   }
/*     */   public void setLabel(String aLabel) {
/* 313 */     this.label = aLabel;
/*     */   }
/*     */ 
/*     */   public int getState()
/*     */   {
/* 319 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int aState) {
/* 323 */     this.state = aState;
/*     */   }
/*     */ 
/*     */   public void setDuration(String aDuration) {
/* 327 */     this.duration = aDuration;
/*     */   }
/*     */   public void setDescription(String aDescription) {
/* 330 */     this.description = aDescription;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 336 */     return XmlUtil.formatElement(getElement());
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level) {
/* 340 */     throw new RuntimeException(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_unRealizeMethod"));
/*     */   }
/*     */ 
/*     */   public void toJavaRemark(StringBuffer buffer, int level)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setTaskTemplateId(long id) {
/* 348 */     this.taskTemplateId = id;
/*     */   }
/*     */   public void setVars(List vars) {
/* 351 */     this.m_vars = vars;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskBaseTemplateImpl
 * JD-Core Version:    0.5.4
 */