/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.TaskDealBean;
/*    */ import com.ai.comframe.vm.template.TaskSignTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskSignTemplateImpl extends TaskUserTemplateImpl
/*    */   implements TaskSignTemplate
/*    */ {
/*    */   protected TaskDealBean childDealBean;
/*    */ 
/*    */   public TaskSignTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 23 */     super(aWorkflowTemplate, item);
/* 24 */     Element tmpNode = item.element("childdeal");
/* 25 */     if (tmpNode != null)
/* 26 */       this.childDealBean = new TaskDealBean(tmpNode);
/*    */   }
/*    */ 
/*    */   public TaskSignTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 32 */     super(aWorkflowTemplate, type);
/*    */   }
/*    */ 
/*    */   public TaskDealBean getChildDealBean() {
/* 36 */     return this.childDealBean;
/*    */   }
/*    */ 
/*    */   public void setChildDealBean(TaskDealBean value) {
/* 40 */     this.childDealBean = value;
/*    */   }
/*    */ 
/*    */   public Element getElement() {
/* 44 */     Element result = super.getElement();
/* 45 */     if (this.childDealBean != null) {
/* 46 */       result.add(this.childDealBean.getElement());
/*    */     }
/* 48 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskSignTemplateImpl
 * JD-Core Version:    0.5.4
 */