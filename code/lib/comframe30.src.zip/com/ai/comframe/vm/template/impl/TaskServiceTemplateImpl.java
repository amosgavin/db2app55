/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.template.TaskServiceTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskServiceTemplateImpl extends TaskBaseTemplateImpl
/*     */   implements TaskServiceTemplate
/*     */ {
/*     */   protected String serviceName;
/*     */   protected String serviceInterfaceName;
/*     */   protected String functionName;
/*     */ 
/*     */   public TaskServiceTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  25 */     super(aWorkflowTemplate, item);
/*  26 */     Element tmpNode = item.element("servicename");
/*  27 */     if (tmpNode != null) {
/*  28 */       this.serviceName = tmpNode.getTextTrim();
/*     */     }
/*     */ 
/*  31 */     tmpNode = item.element("serviceinterfacename");
/*  32 */     if (tmpNode != null) {
/*  33 */       this.serviceInterfaceName = tmpNode.getTextTrim();
/*     */     }
/*  35 */     tmpNode = item.element("functionname");
/*  36 */     if (tmpNode != null)
/*  37 */       this.functionName = tmpNode.getTextTrim();
/*     */   }
/*     */ 
/*     */   public TaskServiceTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  44 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */   }
/*     */ 
/*     */   protected TaskServiceTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type, String aLabel) {
/*  48 */     super(aWorkflowTemplate, type, aLabel);
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/*  52 */     Element result = super.getElement();
/*  53 */     result.add(XmlUtil.createElement("servicename", this.serviceName));
/*  54 */     result.add(XmlUtil.createElement("serviceinterfacename", this.serviceInterfaceName));
/*  55 */     result.add(XmlUtil.createElement("functionname", this.functionName));
/*  56 */     return result;
/*     */   }
/*     */ 
/*     */   public String getServiceName() {
/*  60 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String value) {
/*  64 */     this.serviceName = value;
/*     */   }
/*     */ 
/*     */   public String getServiceInterfaceName() {
/*  68 */     return this.serviceInterfaceName;
/*     */   }
/*     */ 
/*     */   public void setServiceInterfaceName(String value) {
/*  72 */     this.serviceInterfaceName = value;
/*     */   }
/*     */ 
/*     */   public String getFunctionName() {
/*  76 */     return this.functionName;
/*     */   }
/*     */ 
/*     */   public void setFunctionName(String value) {
/*  80 */     this.functionName = value;
/*     */   }
/*     */ 
/*     */   public ParameterDefine[] getFunctionParameterDefine()
/*     */   {
/*  85 */     List parameters = new ArrayList();
/*     */ 
/*  87 */     for (Iterator it = getVars().iterator(); it.hasNext(); ) {
/*  88 */       ParameterDefine p = (ParameterDefine)it.next();
/*  89 */       if (!"return".equalsIgnoreCase(p.inOutType));
/*  90 */       parameters.add(p);
/*     */     }
/*     */ 
/*  93 */     return (ParameterDefine[])(ParameterDefine[])parameters.toArray(new ParameterDefine[0]);
/*     */   }
/*     */ 
/*     */   public ParameterDefine getReturnParameterDefine()
/*     */   {
/*  98 */     for (Iterator it = getVars().iterator(); it.hasNext(); ) {
/*  99 */       ParameterDefine p = (ParameterDefine)it.next();
/* 100 */       if ("return".equalsIgnoreCase(p.inOutType) == true) {
/* 101 */         return p;
/*     */       }
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */   public String getFunctionJavaRemark(ParameterDefine[] parameters, ParameterDefine returnObj) {
/* 108 */     String ss = "//";
/* 109 */     if (returnObj != null)
/* 110 */       ss = ss + returnObj.dataType;
/*     */     else {
/* 112 */       ss = ss + "void";
/*     */     }
/* 114 */     ss = ss + " " + this.serviceName + "[interface:" + this.serviceInterfaceName + "]" + "::" + this.functionName + "(";
/*     */ 
/* 118 */     for (int i = 0; i < parameters.length; ++i) {
/* 119 */       if (i > 0) ss = ss + ",";
/* 120 */       ss = ss + parameters[i].dataType;
/*     */     }
/* 122 */     ss = ss + ")";
/* 123 */     return ss;
/*     */   }
/*     */ 
/*     */   public void toJavaRemark(StringBuffer buffer, int level) {
/* 127 */     ParameterDefine[] parameters = getFunctionParameterDefine();
/* 128 */     ParameterDefine returnObj = getReturnParameterDefine();
/* 129 */     TaskNode.appendLevel(buffer, level);
/* 130 */     buffer.append(getFunctionJavaRemark(parameters, returnObj)).append("\n");
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level)
/*     */   {
/* 135 */     ParameterDefine[] parameters = getFunctionParameterDefine();
/* 136 */     ParameterDefine returnObj = getReturnParameterDefine();
/*     */ 
/* 138 */     String functionStr = "((" + getServiceInterfaceName() + ")com.ai.comframe.vm.common.ServiceUtil.getService(\"" + getServiceName() + "\"," + getServiceInterfaceName() + ".class))." + getFunctionName() + "(";
/*     */ 
/* 142 */     for (int i = 0; i < parameters.length; ++i) {
/* 143 */       if (i > 0)
/* 144 */         functionStr = functionStr + ",";
/* 145 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 146 */         functionStr = functionStr + Process2JavaUtil.getVarTransferString(getWorkflowTemplate().getVars(parameters[i].contextVarName).getDataTypeClass(), parameters[i].getDataTypeClass(), parameters[i].contextVarName);
/*     */       }
/*     */       else
/*     */       {
/* 155 */         functionStr = functionStr + Process2JavaUtil.getDefaultValueString(parameters[i].getDataTypeClass(), parameters[i].defaultValue);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 160 */     functionStr = functionStr + ")";
/* 161 */     if ((returnObj != null) && (!StringUtils.isEmptyString(returnObj.contextVarName))) {
/* 162 */       functionStr = returnObj.contextVarName + " = " + Process2JavaUtil.getVarTransferString(returnObj.getDataTypeClass(), getWorkflowTemplate().getVars(returnObj.contextVarName).getDataTypeClass(), functionStr);
/*     */     }
/*     */ 
/* 169 */     buffer.append(functionStr + ";");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskServiceTemplateImpl
 * JD-Core Version:    0.5.4
 */