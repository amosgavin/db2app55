/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ 
/*     */ public class Process2JavaUtil
/*     */ {
/*     */   public static String getNullValueString(Class type)
/*     */   {
/*   9 */     if (type.equals(Short.TYPE)) return "(short)0";
/*  10 */     if (type.equals(Integer.TYPE)) return "0";
/*  11 */     if (type.equals(Long.TYPE)) return "0";
/*  12 */     if (type.equals(Double.TYPE)) return "0";
/*  13 */     if (type.equals(Float.TYPE)) return "0";
/*  14 */     if (type.equals(Byte.TYPE)) return "(byte)0";
/*  15 */     if (type.equals(Character.TYPE)) return "(char)0";
/*  16 */     if (type.equals(Boolean.TYPE)) return "false";
/*  17 */     if (type.equals(String.class)) return "\"\"";
/*     */ 
/*  19 */     return "null";
/*     */   }
/*     */ 
/*     */   public static String getDefaultValueString(Class type, String value)
/*     */   {
/*  25 */     if ((value == null) || (value.trim().length() == 0))
/*  26 */       return getNullValueString(type);
/*  27 */     if (type.equals(Short.TYPE)) return "(short)" + value;
/*  28 */     if (type.equals(Integer.TYPE)) return value;
/*  29 */     if (type.equals(Long.TYPE)) return value;
/*  30 */     if (type.equals(Double.TYPE)) return value;
/*  31 */     if (type.equals(Float.TYPE)) return value;
/*  32 */     if (type.equals(Byte.TYPE)) return "(byte)" + value;
/*  33 */     if (type.equals(Character.TYPE)) return "(char)'" + value + "'";
/*  34 */     if (type.equals(Boolean.TYPE)) return value;
/*     */ 
/*  36 */     if (type.equals(String.class)) return "\"" + value + "\"";
/*     */ 
/*  38 */     if (type.equals(Short.class)) return "new Short((short)" + value + ")";
/*  39 */     if (type.equals(Integer.class)) return "new Integer(" + value + ")";
/*  40 */     if (type.equals(Long.class)) return "new Long(" + value + ")";
/*  41 */     if (type.equals(Double.class)) return "new Double(" + value + ")";
/*  42 */     if (type.equals(Float.class)) return "new Float(" + value + ")";
/*  43 */     if (type.equals(Byte.class)) return "new Byte((byte)" + value + ")";
/*  44 */     if (type.equals(Character.class)) return "new Character((char)" + value + ")";
/*  45 */     if (type.equals(Boolean.class)) return "new Boolean(" + value + ")";
/*     */ 
/*  47 */     return "(" + VMDataType.getClassName(type) + ")VMDataType.transfer(" + "\"" + value + "\"," + VMDataType.getClassName(type) + ".class)";
/*     */   }
/*     */ 
/*     */   public static String getVarTransferString(Class sourceType, Class destType, String varName)
/*     */   {
/*  54 */     if (DataType.isAssignable(destType, sourceType) == true) {
/*  55 */       return varName;
/*     */     }
/*     */ 
/*  58 */     if (VMDataType.getPrimitiveClass(destType).equals(sourceType) == true) {
/*  59 */       return varName + "." + getTransFunc(destType);
/*     */     }
/*     */ 
/*  62 */     if (VMDataType.getPrimitiveClass(sourceType).equals(destType) == true) {
/*  63 */       return "new " + VMDataType.getClassName(destType) + "(" + varName + ")";
/*     */     }
/*  65 */     String tmpVar = "";
/*  66 */     if (sourceType.isPrimitive() == true)
/*  67 */       tmpVar = "new " + VMDataType.getClassName(VMDataType.getPrimitiveClass(sourceType)) + "(" + varName + ")";
/*     */     else {
/*  69 */       tmpVar = varName;
/*     */     }
/*     */ 
/*  72 */     String result = "";
/*  73 */     if (destType.isPrimitive() == true)
/*  74 */       result = "((" + VMDataType.getClassName(VMDataType.getPrimitiveClass(destType)) + ")VMDataType.transfer(" + tmpVar + "," + VMDataType.getClassName(destType) + ".class))." + getTransFunc(destType);
/*     */     else {
/*  76 */       result = "(" + VMDataType.getClassName(destType) + ")VMDataType.transfer(" + tmpVar + "," + VMDataType.getClassName(destType) + ".class)";
/*     */     }
/*  78 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getParameterInExpress(String outParameterName, Class parameterType, String dataVar, String defaultValue, boolean isDefineVar)
/*     */   {
/*  83 */     String nullValueStr = getDefaultValueString(parameterType, defaultValue);
/*  84 */     String result = "";
/*  85 */     if (isDefineVar == true) {
/*  86 */       result = result + VMDataType.getClassName(parameterType) + " " + outParameterName + " = (" + dataVar + " == null)?" + nullValueStr + ":";
/*     */     }
/*     */     else {
/*  89 */       result = result + outParameterName + " = (" + dataVar + " == null)?" + nullValueStr + ":";
/*     */     }
/*     */ 
/*  92 */     if (parameterType.isPrimitive() == true)
/*  93 */       result = result + "((" + VMDataType.getClassName(VMDataType.getPrimitiveClass(parameterType)) + ")VMDataType.transfer(" + dataVar + "," + VMDataType.getClassName(parameterType) + ".class))." + getTransFunc(parameterType);
/*     */     else {
/*  95 */       result = result + "(" + VMDataType.getClassName(parameterType) + ")VMDataType.transfer(" + dataVar + "," + VMDataType.getClassName(parameterType) + ".class)";
/*     */     }
/*  97 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getParameterOutExpress(String MapName, String outParameterName, Class parameterType, String dataVar)
/*     */   {
/* 102 */     String result = MapName + ".put(\"" + outParameterName + "\",";
/* 103 */     if (parameterType.isPrimitive() == true)
/* 104 */       result = result + "new " + VMDataType.getClassName(VMDataType.getPrimitiveClass(parameterType)) + "(" + dataVar + ")";
/*     */     else {
/* 106 */       result = result + dataVar;
/*     */     }
/* 108 */     result = result + ")";
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getTransFunc(Class type) {
/* 113 */     if (type.equals(Short.TYPE)) return "shortValue()";
/* 114 */     if (type.equals(Integer.TYPE)) return "intValue()";
/* 115 */     if (type.equals(Long.TYPE)) return "longValue()";
/* 116 */     if (type.equals(Double.TYPE)) return "doubleValue()";
/* 117 */     if (type.equals(Float.TYPE)) return "floatValue()";
/* 118 */     if (type.equals(Byte.TYPE)) return "byteValue()";
/* 119 */     if (type.equals(Character.TYPE)) return "charValue()";
/* 120 */     if (type.equals(Boolean.TYPE)) return "booleanValue()";
/* 121 */     return "";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.Process2JavaUtil
 * JD-Core Version:    0.5.4
 */