/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.template.JoinTemplate;
/*     */ import com.ai.comframe.vm.template.TaskCaseTemplate;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskCaseTemplateImpl extends TaskBaseTemplateImpl
/*     */   implements TaskCaseTemplate
/*     */ {
/*     */   private String condition;
/*     */ 
/*     */   public TaskCaseTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  31 */     super(aWorkflowTemplate, item);
/*     */ 
/*  33 */     Element tmpNode = item.element("condition");
/*  34 */     if (tmpNode != null)
/*  35 */       this.condition = tmpNode.getTextTrim();
/*     */   }
/*     */ 
/*     */   public TaskCaseTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  42 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */   }
/*     */ 
/*     */   public Element getElement()
/*     */   {
/*  48 */     Element result = super.getElement();
/*  49 */     result.add(XmlUtil.createElement("condition", this.condition));
/*  50 */     return result;
/*     */   }
/*     */ 
/*     */   public void checkFlowLogic(List errorList)
/*     */   {
/*  55 */     checkFlowLogicStatic(this, errorList);
/*     */   }
/*     */ 
/*     */   public static void checkFlowLogicStatic(TaskTemplate template, List errorList) {
/*  59 */     JoinTemplate[] joins = template.getWorkflowTemplate().getJoinsByTaskB(template);
/*     */ 
/*  61 */     if (joins.length == 0) {
/*  62 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/*     */     }
/*  64 */     else if (joins.length > 1) {
/*  65 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreInLine"));
/*     */     }
/*     */ 
/*  70 */     joins = template.getWorkflowTemplate().getJoinsByTaskA(template);
/*  71 */     if (joins.length == 0) {
/*  72 */       errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/*     */     }
/*     */     else {
/*  75 */       int defaultNum = 0;
/*  76 */       for (int i = 0; i < joins.length; ++i) {
/*  77 */         if (joins[i].getCondition().trim().length() == 0) {
/*  78 */           errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseTemplateImpl.checkFlowLogicStatic_noCaseCondition"));
/*     */         }
/*     */ 
/*  81 */         if (joins[i].getCondition().trim().equalsIgnoreCase("default")) {
/*  82 */           defaultNum += 1;
/*     */         }
/*     */       }
/*  85 */       if (defaultNum != 1)
/*  86 */         errorList.add(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseTemplateImpl.checkFlowLogicStatic_inputLine"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCondition(String value)
/*     */   {
/*  93 */     this.condition = value;
/*     */   }
/*     */ 
/*     */   public String getCondition() {
/*  97 */     return this.condition;
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level) {
/* 101 */     buffer.append(getCondition());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskCaseTemplateImpl
 * JD-Core Version:    0.5.4
 */