/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskOrTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskOrTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskOrTemplate
/*    */ {
/*    */   public TaskOrTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 19 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskOrTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 23 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList)
/*    */   {
/* 28 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 29 */     if (joins.length == 0) {
/* 30 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/*    */     }
/* 32 */     joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 33 */     if (joins.length == 0)
/* 34 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/* 35 */     else if (joins.length > 1)
/* 36 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_hasmoreLine"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskOrTemplateImpl
 * JD-Core Version:    0.5.4
 */