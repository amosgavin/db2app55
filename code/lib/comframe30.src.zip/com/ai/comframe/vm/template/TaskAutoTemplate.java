package com.ai.comframe.vm.template;

public abstract interface TaskAutoTemplate extends TaskTemplate
{
  public abstract TaskDealBean getAutoDealBean();

  public abstract void setAutoDealBean(TaskDealBean paramTaskDealBean);

  public abstract TaskDealBean getRevertDealBean();

  public abstract void setRevertDealBean(TaskDealBean paramTaskDealBean);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskAutoTemplate
 * JD-Core Version:    0.5.4
 */