package com.ai.comframe.vm.template;

public abstract interface TaskEventTemplate extends TaskTemplate
{
  public abstract String getEventId();

  public abstract void setEventId(String paramString);

  public abstract String getEventParameter();

  public abstract void setEventParameter(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskEventTemplate
 * JD-Core Version:    0.5.4
 */