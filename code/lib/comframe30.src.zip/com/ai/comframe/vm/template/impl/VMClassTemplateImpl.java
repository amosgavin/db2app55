/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ClassLoaderUtil;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.template.VMClassTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class VMClassTemplateImpl
/*     */   implements VMClassTemplate
/*     */ {
/*  28 */   protected String xmlTag = "vmclass";
/*     */   protected String name;
/*     */   protected String label;
/*     */   protected String extendsclass;
/*     */   protected String interfaces;
/*     */   protected String description;
/*  34 */   protected List m_vars = new ArrayList();
/*  35 */   protected List m_processes = new ArrayList();
/*     */ 
/*     */   public VMClassTemplateImpl(String aName, Element item)
/*     */   {
/*  39 */     this.name = aName;
/*  40 */     this.label = item.attributeValue("label");
/*  41 */     this.interfaces = item.attributeValue("interfaces");
/*  42 */     this.extendsclass = item.attributeValue("extends");
/*     */ 
/*  44 */     Element tmpNode = item.element("description");
/*  45 */     if (tmpNode != null) {
/*  46 */       this.description = tmpNode.getTextTrim();
/*     */     }
/*     */ 
/*  49 */     List tmpList = item.elements("vars");
/*     */ 
/*  51 */     for (int i = 0; i < tmpList.size(); ++i) {
/*  52 */       tmpNode = (Element)tmpList.get(i);
/*  53 */       ParameterDefine p = new ParameterDefine();
/*  54 */       p.name = tmpNode.attributeValue("name");
/*  55 */       p.dataType = tmpNode.attributeValue("datatype");
/*  56 */       p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  57 */       p.defaultValue = tmpNode.attributeValue("defaultvalue");
/*  58 */       p.accessType = tmpNode.attributeValue("accesstype");
/*  59 */       p.description = tmpNode.attributeValue("description");
/*  60 */       this.m_vars.add(p);
/*     */     }
/*     */ 
/*  63 */     tmpList = item.elements("workflow");
/*     */ 
/*  65 */     for (int i = 0; i < tmpList.size(); ++i) {
/*  66 */       tmpNode = (Element)tmpList.get(i);
/*     */ 
/*  68 */       WorkflowTemplate w = new WorkflowTemplateImpl(tmpNode.attributeValue("tasktag"), null, tmpNode);
/*  69 */       this.m_processes.add(w);
/*     */     }
/*     */   }
/*     */ 
/*     */   public VMClassTemplateImpl(String name, String label, String interfaces, String extendsclass) {
/*  73 */     this.name = name;
/*  74 */     this.label = label;
/*  75 */     this.interfaces = interfaces;
/*  76 */     this.extendsclass = extendsclass;
/*  77 */     if (org.apache.commons.lang.StringUtils.isBlank(interfaces)) {
/*  78 */       return;
/*     */     }
/*  80 */     Map methodMap = new HashMap();
/*  81 */     String[] interfaceArray = org.apache.commons.lang.StringUtils.split(interfaces, ',');
/*  82 */     if ((null == interfaceArray) || (interfaceArray.length == 0)) {
/*  83 */       return;
/*     */     }
/*  85 */     for (int i = 0; i < interfaceArray.length; ++i) {
/*     */       try {
/*  87 */         Class interClass = ClassLoaderUtil.loadClass(interfaceArray[i]);
/*  88 */         Method[] m = interClass.getMethods();
/*  89 */         if ((null != m) && (m.length != 0))
/*  90 */           for (int index = 0; index < m.length; ++index)
/*  91 */             methodMap.put(new VMCMethod(m[index]), m[index]);
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/*  95 */         e.printStackTrace();
/*     */       }
/*     */     }
/*  98 */     for (Iterator iter = methodMap.keySet().iterator(); iter.hasNext(); ) {
/*  99 */       Object key = iter.next();
/* 100 */       Method method = (Method)methodMap.get(key);
/* 101 */       WorkflowTemplate w = new WorkflowTemplateImpl(method.getName(), null, "process", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.VMClassTemplateImpl.VMClassTemplateImpl_testChildProcess"));
/* 102 */       Class[] parame = method.getParameterTypes();
/* 103 */       List vars = new ArrayList();
/* 104 */       for (int i = 0; i < parame.length; ++i) {
/* 105 */         ParameterDefine define = new ParameterDefine();
/* 106 */         define.name = ("P_" + i);
/* 107 */         define.dataType = parame[i].getName();
/* 108 */         define.inOutType = ParameterDefine.PARAMETER_TYPE_IN;
/* 109 */         vars.add(define);
/*     */       }
/* 111 */       Class rtnClass = method.getReturnType();
/* 112 */       if (null != rtnClass) {
/* 113 */         ParameterDefine define = new ParameterDefine();
/* 114 */         define.name = "P_return";
/* 115 */         define.dataType = rtnClass.getName();
/* 116 */         define.inOutType = ParameterDefine.PARAMETER_TYPE_RETURN;
/* 117 */         vars.add(define);
/*     */       }
/* 119 */       w.setVars(vars);
/* 120 */       this.m_processes.add(w);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/* 124 */     Element result = XmlUtil.createElement(this.xmlTag, null);
/* 125 */     result.addAttribute("label", this.label);
/* 126 */     result.addAttribute("interfaces", this.interfaces);
/* 127 */     result.addAttribute("extends", this.extendsclass);
/* 128 */     if (!com.ai.appframe2.util.StringUtils.isEmptyString(this.description)) {
/* 129 */       result.add(XmlUtil.createElement("description", this.description));
/*     */     }
/*     */ 
/* 133 */     for (Iterator it = this.m_vars.iterator(); it.hasNext(); ) {
/* 134 */       Element e = result.addElement("vars");
/* 135 */       ParameterDefine p = (ParameterDefine)it.next();
/* 136 */       e.addAttribute("name", p.name);
/* 137 */       e.addAttribute("datatype", p.dataType);
/* 138 */       e.addAttribute("contextvarName", p.contextVarName);
/* 139 */       e.addAttribute("defaultvalue", p.defaultValue);
/* 140 */       e.addAttribute("accesstype", p.accessType);
/* 141 */       e.addAttribute("description", p.description);
/*     */     }
/*     */ 
/* 144 */     for (Iterator it = this.m_processes.iterator(); it.hasNext(); ) {
/* 145 */       WorkflowTemplate w = (WorkflowTemplate)it.next();
/* 146 */       result.add(w.getElement());
/*     */     }
/* 148 */     return result;
/*     */   }
/*     */ 
/*     */   public List getVars()
/*     */   {
/* 155 */     return this.m_vars;
/*     */   }
/*     */ 
/*     */   public List getParentVars()
/*     */   {
/* 161 */     Map extendsMap = new HashMap();
/* 162 */     List extendsVars = new ArrayList();
/* 163 */     if (org.apache.commons.lang.StringUtils.isBlank(this.extendsclass)) {
/* 164 */       return extendsVars;
/*     */     }
/* 166 */     String[] parentClass = org.apache.commons.lang.StringUtils.split(this.extendsclass, ",");
/* 167 */     if ((null == parentClass) || (parentClass.length == 0)) {
/* 168 */       return extendsVars;
/*     */     }
/* 170 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 171 */     for (int i = 0; i < parentClass.length; ++i) {
/* 172 */       VMClassTemplate vm = null;
/*     */       try {
/* 174 */         vm = templateSV.getVMClassTemplate(parentClass[i]);
/*     */       }
/*     */       catch (Throwable ex) {
/*     */       }
/* 178 */       if (null != vm) {
/* 179 */         List tmpVars = vm.getVars();
/* 180 */         List temPar = vm.getParentVars();
/* 181 */         if (null != tmpVars) {
/* 182 */           extendsVars.addAll(tmpVars);
/*     */         }
/* 184 */         if (null != temPar)
/* 185 */           extendsVars.addAll(temPar);
/*     */       }
/*     */       else
/*     */       {
/*     */         try {
/* 190 */           Class parent = ClassLoaderUtil.loadClass(parentClass[i]);
/* 191 */           if (null != parent) {
/* 192 */             Field[] fields = parent.getDeclaredFields();
/* 193 */             if ((null != fields) && (fields.length > 0)) {
/* 194 */               for (int index = 0; index < fields.length; ++index) {
/* 195 */                 if (Modifier.isPublic(fields[index].getModifiers())) {
/* 196 */                   ParameterDefine define = new ParameterDefine();
/* 197 */                   define.name = fields[index].getName();
/* 198 */                   define.dataType = fields[index].getType().getName();
/* 199 */                   define.accessType = ParameterDefine.PARAMETER_ACCESS_PUBLIC;
/* 200 */                   extendsMap.put(define.name, define);
/*     */                 }
/* 202 */                 else if (Modifier.isProtected(fields[index].getModifiers())) {
/* 203 */                   ParameterDefine define = new ParameterDefine();
/* 204 */                   define.name = fields[index].getName();
/* 205 */                   define.dataType = fields[index].getType().getName();
/* 206 */                   define.accessType = ParameterDefine.PARAMETER_ACCESS_PROTECTED;
/* 207 */                   extendsMap.put(define.name, define);
/*     */                 }
/*     */ 
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (Throwable e)
/*     */         {
/* 220 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 224 */     extendsVars.addAll(extendsMap.values());
/* 225 */     return extendsVars;
/*     */   }
/*     */ 
/*     */   public List getMethods() {
/* 229 */     WorkflowTemplate w = null;
/* 230 */     List methods = new ArrayList();
/* 231 */     for (int i = 0; i < this.m_processes.size(); ++i) {
/* 232 */       w = (WorkflowTemplate)this.m_processes.get(i);
/* 233 */       String[] parameters = null;
/* 234 */       String returnType = null;
/* 235 */       VMCMethod m = new VMCMethod(w.getTaskTag(), parameters, returnType);
/* 236 */       methods.add(m);
/*     */     }
/* 238 */     return methods;
/*     */   }
/*     */   public List getParentMethods() {
/* 241 */     List methods = new ArrayList();
/* 242 */     if (org.apache.commons.lang.StringUtils.isNotBlank(this.extendsclass)) {
/* 243 */       VMClassTemplate vm = null;
/*     */       try {
/* 245 */         ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 246 */         vm = templateSV.getVMClassTemplate(this.extendsclass);
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/* 250 */       if (vm != null) {
/* 251 */         methods.addAll(vm.getParentMethods());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 261 */     return methods;
/*     */   }
/*     */ 
/*     */   public void setVars(List vars) {
/* 265 */     this.m_vars = vars;
/*     */   }
/*     */ 
/*     */   public void setInterfaces(String s) {
/* 269 */     this.interfaces = s;
/*     */   }
/*     */ 
/*     */   public String getInterfaces() {
/* 273 */     return this.interfaces;
/*     */   }
/*     */ 
/*     */   public void setLabel(String label) {
/* 277 */     this.label = label;
/*     */   }
/*     */   public String getLabel() {
/* 280 */     return this.label;
/*     */   }
/*     */   public void setExtendsClass(String className) {
/* 283 */     this.extendsclass = className;
/*     */   }
/*     */   public String getExtendsClass() {
/* 286 */     return this.extendsclass;
/*     */   }
/*     */   public ParameterDefine getVars(String name) {
/* 289 */     for (int i = 0; i < this.m_vars.size(); ++i) {
/* 290 */       ParameterDefine p = (ParameterDefine)this.m_vars.get(i);
/* 291 */       if (p.name.equalsIgnoreCase(name))
/* 292 */         return p;
/*     */     }
/* 294 */     return null;
/*     */   }
/*     */ 
/*     */   public List getWorkflowTemplates()
/*     */   {
/* 299 */     return this.m_processes;
/*     */   }
/*     */ 
/*     */   public WorkflowTemplate getWorkflowTemplate(String name) {
/* 303 */     for (int i = 0; i < this.m_processes.size(); ++i) {
/* 304 */       WorkflowTemplate p = (WorkflowTemplate)this.m_processes.get(i);
/* 305 */       if (p.getTaskTag().equalsIgnoreCase(name))
/* 306 */         return p;
/*     */     }
/* 308 */     return null;
/*     */   }
/*     */ 
/*     */   public void setWorkflowTemplates(List processes)
/*     */   {
/* 313 */     this.m_processes = processes;
/*     */   }
/*     */   public static void appendLevel(StringBuffer buffer, int level) {
/* 316 */     for (int i = 0; i < level; ++i)
/* 317 */       buffer.append("  ");
/*     */   }
/*     */ 
/*     */   public void toJavaRemark(StringBuffer buffer, int level)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level) {
/* 325 */     String className = this.name + "_" + "AIProcess";
/*     */ 
/* 327 */     int index = className.lastIndexOf('.');
/*     */ 
/* 329 */     buffer.append("package " + className.substring(0, index) + ";\n\n");
/* 330 */     buffer.append("import com.ai.comframe.vm.common.VMDataType;\n");
/* 331 */     buffer.append("import org.apache.commons.logging.Log;\n");
/* 332 */     buffer.append("import org.apache.commons.logging.LogFactory;\n\n");
/*     */ 
/* 334 */     toJavaRemark(buffer, level);
/* 335 */     buffer.append("public class " + className.substring(index + 1));
/* 336 */     if ((this.extendsclass != null) && (this.extendsclass.trim().length() > 0)) {
/* 337 */       buffer.append(" extends ").append(this.extendsclass);
/*     */     }
/* 339 */     if ((this.interfaces != null) && (this.interfaces.trim().length() > 0)) {
/* 340 */       buffer.append(" implements ").append(this.interfaces);
/*     */     }
/* 342 */     buffer.append("{\n");
/* 343 */     buffer.append("  private static transient Log logger = LogFactory.getLog(" + className.substring(index + 1) + ".class);\n");
/*     */ 
/* 345 */     for (int i = 0; i < this.m_vars.size(); ++i) {
/* 346 */       ParameterDefine p = (ParameterDefine)this.m_vars.get(i);
/* 347 */       toJavaRemark(buffer, level);
/* 348 */       String s = p.accessType + " " + VMDataType.getClassName(p.getDataTypeClass()) + " " + p.name + " = " + Process2JavaUtil.getDefaultValueString(p.getDataTypeClass(), p.defaultValue);
/*     */ 
/* 351 */       buffer.append(s).append(";\n");
/*     */     }
/*     */ 
/* 354 */     for (int i = 0; i < this.m_processes.size(); ++i) {
/* 355 */       WorkflowTemplateImpl w = (WorkflowTemplateImpl)this.m_processes.get(i);
/* 356 */       TaskNodeProcess p = w.createWorkflowNode();
/* 357 */       p.createExecuteInnerFunction(w, w.getTaskTag(), buffer, 1);
/* 358 */       p.createExecuteFunction(w, w.getTaskTag(), buffer, 1);
/* 359 */       p.createExecuteFunctionWithMapParameter(w, w.getTaskTag(), buffer, 1);
/*     */     }
/* 361 */     buffer.append("}\n");
/*     */   }
/*     */   public String getExtendsclass() {
/* 364 */     return this.extendsclass;
/*     */   }
/*     */   public void setExtendsclass(String extendsclass) {
/* 367 */     this.extendsclass = extendsclass;
/*     */   }
/*     */   public class VMCMethod {
/* 370 */     private String name = "";
/* 371 */     private String[] parameterTypes = new String[0];
/* 372 */     private String returnType = "";
/*     */ 
/*     */     public VMCMethod(Method method)
/*     */     {
/*     */       Class[] params;
/* 374 */       if (null != method) {
/* 375 */         this.name = method.getName();
/* 376 */         this.returnType = method.getReturnType().getName();
/* 377 */         params = method.getParameterTypes();
/* 378 */         if ((null != params) && (params.length > 0)) {
/* 379 */           this.parameterTypes = new String[params.length];
/* 380 */           for (int i = 0; i < params.length; ++i)
/* 381 */             this.parameterTypes[i] = params[i].getName();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public VMCMethod(String name, String[] parameterTypes, String returnType) {
/* 387 */       this.name = name;
/* 388 */       this.parameterTypes = parameterTypes;
/* 389 */       this.returnType = returnType;
/*     */     }
/*     */     public boolean equals(Object obj) {
/* 392 */       if ((obj != null) && (obj instanceof VMCMethod)) {
/* 393 */         VMCMethod other = (VMCMethod)obj;
/* 394 */         if ((this.name == null) || (!this.name.equals(other.name))) {
/* 395 */           return false;
/*     */         }
/* 397 */         if ((this.returnType == null) || (!this.returnType.equals(other.returnType))) {
/* 398 */           return false;
/*     */         }
/* 400 */         if (!Arrays.equals(this.parameterTypes, other.parameterTypes)) {
/* 401 */           return false;
/*     */         }
/*     */       }
/* 404 */       return true;
/*     */     }
/*     */     public int hashCode() {
/* 407 */       return this.name.hashCode() ^ this.parameterTypes.hashCode() ^ this.returnType.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.VMClassTemplateImpl
 * JD-Core Version:    0.5.4
 */