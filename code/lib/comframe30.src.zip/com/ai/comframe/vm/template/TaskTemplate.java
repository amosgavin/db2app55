package com.ai.comframe.vm.template;

import com.ai.comframe.vm.common.ParameterDefine;
import java.util.List;
import org.dom4j.Element;

public abstract interface TaskTemplate
{
  public static final String TASK_TYPE_START = "start";
  public static final String TASK_TYPE_AUTO = "auto";
  public static final String TASK_TYPE_AND = "and";
  public static final String TASK_TYPE_OR = "or";
  public static final String TASK_TYPE_TIMER = "timer";
  public static final String TASK_TYPE_DECISION = "decision";
  public static final String TASK_TYPE_AUTODECISION = "autodecision";
  public static final String TASK_TYPE_USER = "user";
  public static final String TASK_TYPE_FINISH = "finish";
  public static final String TASK_TYPE_SENDMAIL = "sendmail";
  public static final String TASK_TYPE_SIGN = "sign";
  public static final String TASK_TYPE_FORK = "fork";
  public static final String TASK_TYPE_WORKFLOW = "workflow";
  public static final String RUN_TYPE_POJO = "pojo";
  public static final String RUN_TYPE_SERVICE = "service";
  public static final String DEAL_TYPE_AUTO = "autodeal";
  public static final String DEAL_TYPE_PRINT = "printdeal";
  public static final String DEAL_TYPE_POST = "postdeal";
  public static final String DEAL_TYPE_EXCEPTION = "exceptiondeal";
  public static final String DEAL_TYPE_GETUSERINFO = "getuserinfodeal";
  public static final String DEAL_TYPE_OVERTIME = "overtime";
  public static final String DEAL_TYPE_CHILD = "childdeal";
  public static final String DEAL_TYPE_REVERT = "revertdeal";
  public static final String S_EXCEPTION_CONDITION = "exception";

  public abstract long getTaskTemplateId();

  public abstract String getTaskTag();

  public abstract String getTaskType();

  public abstract String getDescription();

  public abstract String getLabel();

  public abstract String getDisplayText();

  public abstract String getDuration();

  public abstract boolean isStart();

  public abstract List getGoToItems();

  public abstract GoToItem getGoToItem(String paramString);

  public abstract GoToItem getGoToItem();

  public abstract void setMonitorType(String paramString);

  public abstract String getMonitorType();

  public abstract void setMonitorService(String paramString);

  public abstract String getMonitorService();

  public abstract List getVars();

  public abstract ParameterDefine getVars(String paramString);

  public abstract WorkflowTemplate getWorkflowTemplate();

  public abstract Element getElement();

  public abstract void setVars(List paramList);

  public abstract void setTaskTemplateId(long paramLong);

  public abstract void setUIInfo(String paramString);

  public abstract String getUIInfo();

  public abstract void setLabel(String paramString);

  public abstract void setTaskTag(String paramString);

  public abstract void setDuration(String paramString);

  public abstract void setDescription(String paramString);

  public abstract void setState(int paramInt);

  public abstract int getState();

  public abstract void checkFlowLogic(List paramList);

  public abstract void toJavaCode(StringBuffer paramStringBuffer, int paramInt);

  public abstract void toJavaRemark(StringBuffer paramStringBuffer, int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskTemplate
 * JD-Core Version:    0.5.4
 */