/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TaskNode
/*    */ {
/*    */   TaskTemplate m_task;
/*    */   TaskNode m_parent;
/* 21 */   List m_child = new ArrayList();
/*    */ 
/*    */   public TaskNode(TaskNode parent, TaskTemplate task) {
/* 24 */     this.m_task = task;
/* 25 */     this.m_parent = parent;
/*    */   }
/*    */ 
/*    */   public TaskTemplate getTask() {
/* 29 */     return this.m_task;
/*    */   }
/*    */ 
/*    */   public static void appendLevel(StringBuffer buffer, int level) {
/* 33 */     for (int i = 0; i < level; ++i)
/* 34 */       buffer.append("  ");
/*    */   }
/*    */ 
/*    */   public void addChild(TaskNode task) {
/* 38 */     this.m_child.add(task);
/*    */   }
/*    */ 
/*    */   public TaskNode[] getChildren() {
/* 42 */     return (TaskNode[])(TaskNode[])this.m_child.toArray(new TaskNode[0]);
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 46 */     StringBuffer buffer = new StringBuffer();
/* 47 */     toJavaCode(buffer, 0);
/* 48 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   public void toJavaCode(StringBuffer buffer, int level)
/*    */   {
/* 53 */     this.m_task.toJavaRemark(buffer, level);
/* 54 */     appendLevel(buffer, level);
/* 55 */     this.m_task.toJavaCode(buffer, level);
/* 56 */     if (this.m_child.size() > 0) {
/* 57 */       buffer.append("{\n");
/* 58 */       for (int i = 0; i < this.m_child.size(); ++i) {
/* 59 */         ((TaskNode)this.m_child.get(i)).toJavaCode(buffer, level + 1);
/*    */       }
/* 61 */       appendLevel(buffer, level);
/* 62 */       buffer.append("}\n");
/*    */     }
/*    */     else {
/* 65 */       buffer.append("\n");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskNode
 * JD-Core Version:    0.5.4
 */