/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.util.XmlUtil;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.TaskTimerTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskTimerTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskTimerTemplate
/*    */ {
/* 18 */   private String timerType = "";
/* 19 */   private String runTime = "";
/*    */ 
/*    */   public TaskTimerTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item) {
/* 22 */     super(aWorkflowTemplate, item);
/*    */ 
/* 24 */     Element tmpNode = item.element("timertype");
/* 25 */     if (tmpNode != null) {
/* 26 */       this.timerType = tmpNode.getTextTrim();
/*    */     }
/* 28 */     tmpNode = item.element("runtime");
/* 29 */     if (tmpNode != null)
/* 30 */       this.runTime = tmpNode.getTextTrim();
/*    */   }
/*    */ 
/*    */   public TaskTimerTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 36 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/* 37 */     setTimerType("R");
/*    */   }
/*    */ 
/*    */   public Element getElement() {
/* 41 */     Element result = super.getElement();
/* 42 */     result.add(XmlUtil.createElement("timertype", this.timerType));
/* 43 */     result.add(XmlUtil.createElement("runtime", this.runTime));
/* 44 */     return result;
/*    */   }
/*    */ 
/*    */   public String getTimerType() {
/* 48 */     return this.timerType;
/*    */   }
/*    */   public void setTimerType(String value) {
/* 51 */     this.timerType = value;
/*    */   }
/*    */ 
/*    */   public String getRuntime()
/*    */   {
/* 59 */     return this.runTime;
/*    */   }
/*    */   public void setRuntime(String value) {
/* 62 */     this.runTime = value;
/*    */   }
/*    */   public void checkFlowLogic(List errorList) {
/* 65 */     super.checkFlowLogic(errorList);
/*    */ 
/* 67 */     if (this.runTime.startsWith(":"))
/* 68 */       if (getWorkflowTemplate().getVars(this.runTime.substring(1)) == null)
/* 69 */         errorList.add(this.runTime.substring(1) + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskTimerTemplateImpl.checkFlowLogic_undefinedVars"));
/*    */     else
/*    */       try
/*    */       {
/*    */         Date tTime;
/*    */         Date tTime;
/* 74 */         if ((this.runTime.indexOf(":") > 0) && (this.runTime.indexOf("-") > 0)) {
/* 75 */           tTime = (Date)DataType.transfer(this.runTime, "DateTime");
/*    */         }
/*    */         else
/*    */         {
/*    */           Date tTime;
/* 76 */           if (this.runTime.indexOf(":") > 0)
/* 77 */             tTime = (Date)DataType.transfer(this.runTime, "Time");
/*    */           else
/* 79 */             tTime = (Date)DataType.transfer(this.runTime, "Date");
/*    */         }
/* 81 */         System.out.println(DataType.transferToString(tTime, "DateTime"));
/*    */       }
/*    */       catch (Exception e) {
/* 84 */         errorList.add(this.runTime + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskTimerTemplateImpl.checkFlowLogic_notValuableTime"));
/* 85 */         e.printStackTrace();
/*    */       }
/*    */   }
/*    */ 
/*    */   public void toJavaCode(StringBuffer buffer, int level)
/*    */   {
/* 91 */     buffer.append("// Runtimer(" + this.runTime + ");");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskTimerTemplateImpl
 * JD-Core Version:    0.5.4
 */