package com.ai.comframe.vm.template;

public abstract interface TaskFinishTemplate extends TaskAutoTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskFinishTemplate
 * JD-Core Version:    0.5.4
 */