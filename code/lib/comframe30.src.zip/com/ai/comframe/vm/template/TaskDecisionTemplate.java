package com.ai.comframe.vm.template;

public abstract interface TaskDecisionTemplate extends TaskTemplate
{
  public static final String S_DEFAULT_CONDITION = "default";
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskDecisionTemplate
 * JD-Core Version:    0.5.4
 */