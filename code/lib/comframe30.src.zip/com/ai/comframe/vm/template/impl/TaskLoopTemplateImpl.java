/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskLoopEndTemplate;
/*    */ import com.ai.comframe.vm.template.TaskLoopTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskLoopTemplateImpl extends TaskDecisionConditionTemplateImpl
/*    */   implements TaskLoopTemplate
/*    */ {
/*    */   public TaskLoopTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 19 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskLoopTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 24 */     super(aWorkflowTemplate, type);
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList)
/*    */   {
/* 31 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 32 */     if (joins.length == 2) {
/* 33 */       int endLoopNum = 0;
/* 34 */       for (int i = 0; i < joins.length; ++i) {
/* 35 */         if (joins[i].getTaskTemplateA() instanceof TaskLoopEndTemplate) {
/* 36 */           endLoopNum += 1;
/*    */         }
/*    */       }
/* 39 */       if (endLoopNum == 0)
/* 40 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_oneShouldFromEndloop"));
/* 41 */       else if (endLoopNum == 2)
/* 42 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_onlyOneFromEndloop"));
/*    */     }
/*    */     else {
/* 45 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_twoShouldEndloopAndOther"));
/*    */     }
/*    */ 
/* 48 */     joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 49 */     if ((joins.length == 1) || (joins.length == 2)) {
/* 50 */       int endLoopNum = 0;
/* 51 */       for (int i = 0; i < joins.length; ++i) {
/* 52 */         if (joins[i].getTaskTemplateB() instanceof TaskLoopEndTemplate) {
/* 53 */           endLoopNum += 1;
/*    */ 
/* 55 */           if (!super.equals(getWorkflowTemplate().getLoopByLoopEnd((TaskLoopEndTemplate)joins[i].getTaskTemplateB()))) {
/* 56 */             errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopEndTemplateImpl.checkFlowLogic_notMatchEndloop"));
/*    */           }
/*    */         }
/*    */       }
/* 60 */       if (endLoopNum == 0)
/* 61 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_oneShouldEndloopOut"));
/* 62 */       else if (endLoopNum == 2)
/* 63 */         errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_onlyOneEndloopOut"));
/*    */     } else {
/* 65 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskLoopTemplateImpl.checkFlowLogic_oneOutLoopOneOutOther"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskLoopTemplateImpl
 * JD-Core Version:    0.5.4
 */