/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskWorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskWorkflowTemplateImpl extends TaskBaseTemplateImpl
/*     */   implements TaskWorkflowTemplate
/*     */ {
/*     */   protected String workflowCode;
/*     */   protected String workflowName;
/*  24 */   protected String workflowType = "";
/*  25 */   protected List childVars = new ArrayList();
/*     */   TaskDealBean autoDealBean;
/*     */   TaskDealBean revertDealBean;
/*  28 */   protected transient boolean m_isInitial = false;
/*     */ 
/*     */   public TaskWorkflowTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  33 */     super(aWorkflowTemplate, item);
/*  34 */     Element tmpNode = item.element("child");
/*  35 */     if (tmpNode != null) {
/*  36 */       this.workflowCode = tmpNode.attributeValue("code");
/*  37 */       this.workflowName = tmpNode.attributeValue("name");
/*  38 */       this.workflowType = tmpNode.attributeValue("type");
/*  39 */       List tmpList = tmpNode.elements("vars");
/*  40 */       for (int i = 0; i < tmpList.size(); ++i) {
/*  41 */         tmpNode = (Element)tmpList.get(i);
/*  42 */         ParameterDefine p = new ParameterDefine();
/*  43 */         p.name = tmpNode.attributeValue("name");
/*  44 */         p.dataType = tmpNode.attributeValue("datatype");
/*  45 */         p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  46 */         p.defaultValue = tmpNode.attributeValue("defaultvalue");
/*  47 */         p.inOutType = tmpNode.attributeValue("inouttype");
/*  48 */         p.description = tmpNode.attributeValue("description");
/*  49 */         this.childVars.add(p);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  54 */       tmpNode = item.element("workflowcode");
/*  55 */       if (tmpNode != null) {
/*  56 */         this.workflowCode = tmpNode.getTextTrim();
/*     */       }
/*  58 */       tmpNode = item.element("workflowname");
/*  59 */       if (tmpNode != null) {
/*  60 */         this.workflowName = tmpNode.getTextTrim();
/*     */       }
/*  62 */       tmpNode = item.element("workflowtype");
/*  63 */       if (tmpNode != null) {
/*  64 */         this.workflowType = tmpNode.getTextTrim();
/*     */       }
/*  66 */       this.childVars.addAll(this.m_vars);
/*  67 */       this.m_vars.clear();
/*     */     }
/*     */ 
/*  70 */     tmpNode = item.element("autodeal");
/*  71 */     if (tmpNode != null) {
/*  72 */       this.autoDealBean = new TaskDealBean(tmpNode);
/*     */     }
/*     */ 
/*  75 */     tmpNode = item.element("revertdeal");
/*  76 */     if (tmpNode != null)
/*  77 */       this.revertDealBean = new TaskDealBean(tmpNode);
/*     */   }
/*     */ 
/*     */   public TaskWorkflowTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  82 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */   }
/*     */ 
/*     */   protected TaskWorkflowTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type, String aLabel) {
/*  86 */     super(aWorkflowTemplate, type, aLabel);
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/*  90 */     Element result = super.getElement();
/*  91 */     Element child = XmlUtil.createElement("child", "");
/*  92 */     child.addAttribute("code", this.workflowCode);
/*  93 */     child.addAttribute("name", this.workflowName);
/*  94 */     child.addAttribute("type", this.workflowType);
/*     */     Iterator it;
/*  95 */     if (this.childVars != null)
/*     */     {
/*  98 */       for (it = this.childVars.iterator(); it.hasNext(); ) {
/*  99 */         Element e = child.addElement("vars");
/* 100 */         ParameterDefine p = (ParameterDefine)it.next();
/* 101 */         e.addAttribute("name", p.name);
/* 102 */         e.addAttribute("datatype", p.dataType);
/* 103 */         e.addAttribute("contextvarName", p.contextVarName);
/* 104 */         e.addAttribute("defaultvalue", p.defaultValue);
/* 105 */         e.addAttribute("inouttype", p.inOutType);
/* 106 */         e.addAttribute("description", p.description);
/*     */       }
/*     */     }
/* 109 */     result.add(child);
/*     */ 
/* 111 */     if ((this.autoDealBean != null) && (this.autoDealBean.getElement() != null)) {
/* 112 */       result.add(this.autoDealBean.getElement());
/*     */     }
/* 114 */     if ((this.revertDealBean != null) && (this.revertDealBean.getElement() != null)) {
/* 115 */       result.add(this.revertDealBean.getElement());
/*     */     }
/* 117 */     return result;
/*     */   }
/*     */ 
/*     */   public String getWorkflowName() {
/* 121 */     return this.workflowName;
/*     */   }
/*     */ 
/*     */   public void setWorkflowName(String value) {
/* 125 */     this.workflowName = value;
/*     */   }
/*     */ 
/*     */   public String getWorkflowCode() {
/* 129 */     return this.workflowCode;
/*     */   }
/*     */ 
/*     */   public void setWorkflowCode(String value) {
/* 133 */     this.workflowCode = value;
/*     */   }
/*     */ 
/*     */   public String getWorkflowType() {
/* 137 */     return this.workflowType;
/*     */   }
/*     */ 
/*     */   public void setWorkflowType(String value) {
/* 141 */     this.workflowType = value;
/*     */   }
/*     */ 
/*     */   public List getWorkflowVars() {
/* 145 */     return this.childVars;
/*     */   }
/*     */ 
/*     */   public void setWorkflowVars(List value) {
/* 149 */     this.childVars = value;
/*     */   }
/*     */ 
/*     */   public ParameterDefine[] getInParameterDefine()
/*     */   {
/* 154 */     List parameters = new ArrayList();
/* 155 */     for (Iterator it = getWorkflowVars().iterator(); it.hasNext(); ) {
/* 156 */       ParameterDefine p = (ParameterDefine)it.next();
/* 157 */       if ((ParameterDefine.PARAMETER_TYPE_IN.equalsIgnoreCase(p.inOutType) != true) && (ParameterDefine.PARAMETER_TYPE_INOUT.equalsIgnoreCase(p.inOutType) != true)) {
/*     */         continue;
/*     */       }
/* 160 */       if (!StringUtils.isEmptyString(p.defaultValue)) {
/* 161 */         p.setValue(VMDataType.transfer(p.defaultValue, p.getDataTypeClass()));
/*     */       }
/* 163 */       parameters.add(p);
/*     */     }
/*     */ 
/* 166 */     return (ParameterDefine[])(ParameterDefine[])parameters.toArray(new ParameterDefine[0]);
/*     */   }
/*     */ 
/*     */   public ParameterDefine[] getOutParameterDefine() {
/* 170 */     List parameters = new ArrayList();
/* 171 */     for (Iterator it = getWorkflowVars().iterator(); it.hasNext(); ) {
/* 172 */       ParameterDefine p = (ParameterDefine)it.next();
/* 173 */       if ((ParameterDefine.PARAMETER_TYPE_OUT.equalsIgnoreCase(p.inOutType) != true) && (ParameterDefine.PARAMETER_TYPE_INOUT.equalsIgnoreCase(p.inOutType) != true)) {
/*     */         continue;
/*     */       }
/* 176 */       if (!StringUtils.isEmptyString(p.defaultValue)) {
/* 177 */         p.setValue(VMDataType.transfer(p.defaultValue, p.getDataTypeClass()));
/*     */       }
/* 179 */       parameters.add(p);
/*     */     }
/*     */ 
/* 182 */     return (ParameterDefine[])(ParameterDefine[])parameters.toArray(new ParameterDefine[0]);
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level)
/*     */   {
/* 188 */     String mapName = "tmpMap" + getTaskTemplateId();
/* 189 */     String loopVarName = "loopVar" + getTaskTemplateId();
/* 190 */     String loopCountVarName = "loopCount" + getTaskTemplateId();
/* 191 */     String workflowObjectTypeVarName = "workflowObjectType" + getTaskTemplateId();
/* 192 */     String workflowObjectIDVarName = "workflowObjectID" + getTaskTemplateId();
/* 193 */     String workflowCreateStaffVarName = "workflowCreateStaff" + getTaskTemplateId();
/*     */ 
/* 197 */     buffer.append("{").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskWorkflowTemplateImpl.toJavaCode_getChildProcess") + getWorkflowName() + "\n");
/* 198 */     level += 1;
/* 199 */     TaskNode.appendLevel(buffer, level);
/* 200 */     buffer.append("java.util.Map " + mapName + " = new java.util.HashMap();\n");
/* 201 */     TaskNode.appendLevel(buffer, level);
/* 202 */     buffer.append("Object " + loopVarName + " = null;\n");
/* 203 */     TaskNode.appendLevel(buffer, level);
/* 204 */     buffer.append("int " + loopCountVarName + " = 0;\n");
/*     */ 
/* 206 */     if ((this.autoDealBean != null) && (!StringUtils.isEmptyString(this.autoDealBean.getRunClassName()))) {
/* 207 */       TaskNode.appendLevel(buffer, level);
/* 208 */       buffer.append(loopVarName + " = (");
/* 209 */       TaskAutoTemplateImpl.toJavaCode(this, getAutoDealBean(), buffer, level);
/* 210 */       if (buffer.charAt(buffer.length() - 1) == ';') {
/* 211 */         buffer.deleteCharAt(buffer.length() - 1);
/*     */       }
/* 213 */       buffer.append(");\n");
/* 214 */       TaskNode.appendLevel(buffer, level);
/* 215 */       buffer.append("if(" + loopVarName + " == null){ " + loopVarName + " = new Object[0]; " + loopCountVarName + " = 0;}\n" + "else if(" + loopVarName + " instanceof java.util.List){" + loopCountVarName + " = ((java.util.List)" + loopVarName + ").size();\n}" + "else if(" + loopVarName + ".getClass().isArray()){" + loopCountVarName + " = ((Object[])" + loopVarName + ").length;\n}");
/*     */     }
/*     */     else
/*     */     {
/* 220 */       TaskNode.appendLevel(buffer, level);
/* 221 */       buffer.append(loopVarName + " = new Object[]{null};\n");
/* 222 */       TaskNode.appendLevel(buffer, level);
/* 223 */       buffer.append(loopCountVarName + " = 1;\n");
/*     */     }
/*     */ 
/* 226 */     TaskNode.appendLevel(buffer, level);
/*     */ 
/* 228 */     buffer.append("for(int i=0;i < " + loopCountVarName + ";i++){\n");
/* 229 */     TaskNode.appendLevel(buffer, level);
/* 230 */     buffer.append(mapName + ".clear();\n");
/*     */ 
/* 232 */     ParameterDefine[] ps = getInParameterDefine();
/* 233 */     for (int i = 0; i < ps.length; ++i) {
/* 234 */       if (!StringUtils.isEmptyString(ps[i].contextVarName)) {
/* 235 */         TaskNode.appendLevel(buffer, level);
/* 236 */         if (!ps[i].contextVarName.startsWith("$LOOP.")) {
/* 237 */           Class tmpClass = getWorkflowTemplate().getVars(ps[i].contextVarName).getDataTypeClass();
/*     */ 
/* 239 */           buffer.append(Process2JavaUtil.getParameterOutExpress(mapName, ps[i].name, tmpClass, ps[i].contextVarName) + ";\n");
/*     */         }
/*     */         else
/*     */         {
/* 243 */           String varStr = "com.ai.comframe.vm.common.VMUtil.getObjectProperty(com.ai.comframe.vm.common.VMUtil.getObjectByIndex(" + loopVarName + ",i),\"" + ps[i].contextVarName.substring("$LOOP.".length()) + "\")";
/*     */ 
/* 245 */           buffer.append(Process2JavaUtil.getParameterOutExpress(mapName, ps[i].name, Object.class, varStr) + ";\n");
/*     */         }
/*     */ 
/*     */       }
/* 250 */       else if (!StringUtils.isEmptyString(ps[i].defaultValue)) {
/* 251 */         TaskNode.appendLevel(buffer, level);
/* 252 */         buffer.append(Process2JavaUtil.getParameterOutExpress(mapName, ps[i].name, String.class, new StringBuilder().append("\"").append(ps[i].defaultValue).append("\"").toString()) + ";\n");
/*     */       }
/*     */     }
/*     */ 
/* 256 */     buffer.append("\n");
/*     */ 
/* 258 */     if (this.workflowType.equals("process")) {
/* 259 */       TaskNode.appendLevel(buffer, level);
/* 260 */       buffer.append("com.ai.comframe.vm.processflow.ProcessEngineFactory.getProcessEngine().executeProcess(\"" + getWorkflowCode() + "\"," + mapName + ");\n");
/*     */ 
/* 263 */       ps = getOutParameterDefine();
/* 264 */       for (int i = 0; i < ps.length; ++i) {
/* 265 */         if (!StringUtils.isEmptyString(ps[i].contextVarName)) {
/* 266 */           TaskNode.appendLevel(buffer, level);
/* 267 */           Class tmpClass = getWorkflowTemplate().getVars(ps[i].contextVarName).getDataTypeClass();
/*     */ 
/* 269 */           buffer.append(Process2JavaUtil.getParameterInExpress(ps[i].contextVarName, tmpClass, mapName + ".get(\"" + ps[i].name + "\")", "", false)).append(";\n");
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/* 274 */     else if (this.workflowType.equals("workflow")) {
/* 275 */       buffer.append("String " + workflowObjectTypeVarName + " = (" + mapName + ".get(\"" + "FLOWOBJECT_TYPE" + "\")==null)?\"\":" + mapName + ".get(\"" + "FLOWOBJECT_TYPE" + "\").toString();\n");
/* 276 */       buffer.append("String " + workflowObjectIDVarName + " = (" + mapName + ".get(\"" + "FLOWOBJECT_ID" + "\")==null)?\"\":" + mapName + ".get(\"" + "FLOWOBJECT_ID" + "\").toString();\n");
/* 277 */       buffer.append("String " + workflowCreateStaffVarName + " = (" + mapName + ".get(\"" + "CREATE_STAFF" + "\")==null)?\"\":" + mapName + ".get(\"" + "CREATE_STAFF" + "\").toString();\n");
/*     */ 
/* 280 */       buffer.append("com.ai.comframe.ComframeWorkflowFactory.getComframeClientInstance().createWorkflow(null,\"-1\",\"" + getWorkflowCode() + "\",com.ai.comframe.vm.common.Constant.WORKFLOW_TYPE_CHILDWORKFLOW," + workflowCreateStaffVarName + "," + workflowObjectTypeVarName + "," + workflowObjectIDVarName + "," + mapName + ");");
/*     */     }
/*     */     else {
/* 283 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_childProcess") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskWorkflowTemplateImpl.toJavaCode_definedChildProcess") + getWorkflowType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.TaskWorkflowImpl.executeInner_unlegal"));
/*     */     }
/*     */ 
/* 287 */     buffer.append("\n");
/* 288 */     TaskNode.appendLevel(buffer, level);
/* 289 */     buffer.append(mapName + ".clear();\n");
/*     */ 
/* 291 */     TaskNode.appendLevel(buffer, level);
/* 292 */     buffer.append("}");
/*     */ 
/* 294 */     TaskNode.appendLevel(buffer, level - 1);
/* 295 */     buffer.append("}\n");
/*     */   }
/*     */ 
/*     */   public TaskDealBean getAutoDealBean()
/*     */   {
/* 300 */     return this.autoDealBean;
/*     */   }
/*     */ 
/*     */   public void setAutoDealBean(TaskDealBean value) {
/* 304 */     this.autoDealBean = value;
/*     */   }
/*     */   public TaskDealBean getRevertDealBean() {
/* 307 */     return this.revertDealBean;
/*     */   }
/*     */ 
/*     */   public void setRevertDealBean(TaskDealBean value) {
/* 311 */     this.revertDealBean = value;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskWorkflowTemplateImpl
 * JD-Core Version:    0.5.4
 */