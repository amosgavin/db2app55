/*      */ package com.ai.comframe.vm.template.impl;
/*      */ 
/*      */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*      */ import com.ai.comframe.vm.common.ParameterDefine;
/*      */ import com.ai.comframe.vm.common.TaskConfig;
/*      */ import com.ai.comframe.vm.common.XmlUtil;
/*      */ import com.ai.comframe.vm.template.GoToItem;
/*      */ import com.ai.comframe.vm.template.JoinTemplate;
/*      */ import com.ai.comframe.vm.template.RoleTemplate;
/*      */ import com.ai.comframe.vm.template.TaskAndTemplate;
/*      */ import com.ai.comframe.vm.template.TaskBreakTemplate;
/*      */ import com.ai.comframe.vm.template.TaskCaseEndTemplate;
/*      */ import com.ai.comframe.vm.template.TaskCaseTemplate;
/*      */ import com.ai.comframe.vm.template.TaskContinueTemplate;
/*      */ import com.ai.comframe.vm.template.TaskDealBean;
/*      */ import com.ai.comframe.vm.template.TaskDecisionEndTemplate;
/*      */ import com.ai.comframe.vm.template.TaskDecisionTemplate;
/*      */ import com.ai.comframe.vm.template.TaskFinishTemplate;
/*      */ import com.ai.comframe.vm.template.TaskForkTemplate;
/*      */ import com.ai.comframe.vm.template.TaskLoopEndTemplate;
/*      */ import com.ai.comframe.vm.template.TaskLoopTemplate;
/*      */ import com.ai.comframe.vm.template.TaskOrTemplate;
/*      */ import com.ai.comframe.vm.template.TaskStartTemplate;
/*      */ import com.ai.comframe.vm.template.TaskTemplate;
/*      */ import com.ai.comframe.vm.template.TaskUserTemplate;
/*      */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*      */ import java.io.Writer;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.dom4j.Element;
/*      */ 
/*      */ public class WorkflowTemplateImpl extends TaskBaseTemplateImpl
/*      */   implements WorkflowTemplate
/*      */ {
/*   40 */   private static transient Log log = LogFactory.getLog(WorkflowTemplateImpl.class);
/*      */ 
/*   42 */   private List m_joinTemplates = new ArrayList();
/*   43 */   private List m_taskTempaltes = new ArrayList();
/*   44 */   private List m_roleTemplates = new ArrayList();
/*      */ 
/*   47 */   private long m_maxTaskTemplateId = 0L;
/*      */ 
/*   49 */   private String m_oldFileString = "";
/*      */   private TaskDealBean exceptionDealBean;
/*      */   private TaskDealBean getUserInfoDealBean;
/*      */   private Timestamp validDate;
/*      */   private Timestamp expireDate;
/*      */ 
/*      */   public WorkflowTemplateImpl(String aWorkflowName, WorkflowTemplate parentWorkflowTemplate, String workflowType, String aLabel)
/*      */   {
/*   59 */     super(parentWorkflowTemplate, "workflow", aLabel);
/*   60 */     this.xmlTag = "workflow";
/*   61 */     this.taskType = workflowType;
/*   62 */     this.taskTag = aWorkflowName;
/*   63 */     addJugeResultParameterDefine();
/*      */   }
/*      */ 
/*      */   public WorkflowTemplateImpl(String aWorkflowName, WorkflowTemplate parentWorkflowTemplate, Element item)
/*      */   {
/*   69 */     super(parentWorkflowTemplate, item);
/*      */ 
/*   71 */     this.xmlTag = "workflow";
/*   72 */     if ((aWorkflowName != null) && (aWorkflowName.trim().length() > 0)) {
/*   73 */       this.taskTag = aWorkflowName;
/*      */     }
/*      */ 
/*   77 */     Element tmpNode = item.element("exceptiondeal");
/*   78 */     if (tmpNode != null) {
/*   79 */       this.exceptionDealBean = new TaskDealBean(tmpNode);
/*      */     }
/*      */ 
/*   82 */     tmpNode = item.element("getuserinfodeal");
/*   83 */     if (tmpNode != null) {
/*   84 */       this.getUserInfoDealBean = new TaskDealBean(tmpNode);
/*      */     }
/*      */ 
/*   87 */     List tmpList = item.elements("task");
/*      */ 
/*   91 */     for (Iterator it = tmpList.iterator(); it.hasNext(); ) {
/*   92 */       tmpNode = (Element)it.next();
/*   93 */       TaskTemplate task = TaskConfig.getInstance().getTaskTemplate(tmpNode.attributeValue("tasktype"), this, tmpNode);
/*      */ 
/*   95 */       this.m_taskTempaltes.add(task);
/*   96 */       if (task.getTaskTemplateId() > this.m_maxTaskTemplateId);
/*   97 */       this.m_maxTaskTemplateId = task.getTaskTemplateId();
/*      */     }
/*      */ 
/*  100 */     tmpList = item.elements("join");
/*      */ 
/*  102 */     for (Iterator it = tmpList.iterator(); it.hasNext(); ) {
/*  103 */       tmpNode = (Element)it.next();
/*  104 */       JoinTemplate join = new JoinTemplateImpl(this, tmpNode);
/*  105 */       this.m_joinTemplates.add(join);
/*      */     }
/*      */ 
/*  108 */     tmpList = item.elements("role");
/*      */ 
/*  110 */     for (Iterator it = tmpList.iterator(); it.hasNext(); ) {
/*  111 */       tmpNode = (Element)it.next();
/*  112 */       RoleTemplate role = new RoleTemplateImpl(tmpNode);
/*  113 */       this.m_roleTemplates.add(role);
/*      */     }
/*  115 */     this.m_oldFileString = XmlUtil.formatElement(getElement());
/*  116 */     if (getVars("_TASK_JUGE_RESULT") == null)
/*  117 */       addJugeResultParameterDefine();
/*      */   }
/*      */ 
/*      */   public void addJugeResultParameterDefine() {
/*  121 */     ParameterDefine taskResultParameter = new ParameterDefine();
/*  122 */     taskResultParameter.name = "_TASK_JUGE_RESULT";
/*  123 */     taskResultParameter.dataType = "java.lang.String";
/*  124 */     taskResultParameter.inOutType = ParameterDefine.PARAMETER_TYPE_INNER;
/*  125 */     taskResultParameter.description = ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.WorkflowTemplateImpl_checkNodeResult");
/*  126 */     this.m_vars.add(taskResultParameter);
/*      */   }
/*      */ 
/*      */   public void fillBackTaskForJoin()
/*      */   {
/*  135 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  136 */       TaskTemplate tmpTask = (TaskTemplate)it.next();
/*  137 */       tmpTask.getGoToItems().clear();
/*      */     }
/*      */ 
/*  142 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  143 */       JoinTemplate join = (JoinTemplate)it.next();
/*  144 */       if ((join.getTaskTemplateBId() <= 0L) || 
/*  145 */         (join.getTaskTemplateA() == null)) continue;
/*  146 */       join.getTaskTemplateA().getGoToItems().add(new GoToItem(join.getCondition(), join.getTaskTemplateBId()));
/*      */     }
/*      */ 
/*  152 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  153 */       TaskTemplate tmpTask = (TaskTemplate)it.next();
/*  154 */       if (tmpTask instanceof TaskLoopTemplate) {
/*  155 */         TaskTemplate loopEnd = getEndLoopByLoop((TaskLoopTemplate)tmpTask);
/*  156 */         tmpTask.getGoToItems().clear();
/*  157 */         TaskTemplate temp = getNextTaskOfLoop(tmpTask);
/*  158 */         if (temp == null)
/*      */         {
/*  160 */           tmpTask.getGoToItems().add(new GoToItem("true", tmpTask.getTaskTemplateId()));
/*      */         }
/*      */         else
/*      */         {
/*  164 */           tmpTask.getGoToItems().add(new GoToItem("true", temp.getTaskTemplateId()));
/*      */         }
/*      */ 
/*  167 */         tmpTask.getGoToItems().add(new GoToItem("false", getNextTaskOfEndLoop(loopEnd).getTaskTemplateId()));
/*      */ 
/*  171 */         loopEnd.getGoToItems().clear();
/*  172 */         loopEnd.getGoToItems().add(new GoToItem("", tmpTask.getTaskTemplateId()));
/*      */       }
/*  174 */       if (tmpTask instanceof TaskLoopEndTemplate)
/*      */       {
/*  176 */         getLoopByLoopEnd((TaskLoopEndTemplate)tmpTask);
/*      */       }
/*  178 */       if (tmpTask instanceof TaskBreakTemplate) {
/*  179 */         TaskTemplate loop = getLoopByOtherTask(tmpTask);
/*  180 */         TaskTemplate endLoop = getEndLoopByLoop((TaskLoopTemplate)loop);
/*  181 */         tmpTask.getGoToItems().clear();
/*  182 */         tmpTask.getGoToItems().add(new GoToItem("", getNextTaskOfEndLoop(endLoop).getTaskTemplateId()));
/*      */       }
/*      */ 
/*  186 */       if (tmpTask instanceof TaskContinueTemplate);
/*  187 */       TaskTemplate loop = getLoopByOtherTask(tmpTask);
/*  188 */       TaskTemplate endLoop = getEndLoopByLoop((TaskLoopTemplate)loop);
/*  189 */       tmpTask.getGoToItems().clear();
/*  190 */       tmpTask.getGoToItems().add(new GoToItem("", endLoop.getTaskTemplateId()));
/*      */     }
/*      */ 
/*  195 */     judgeAgainst();
/*      */   }
/*      */ 
/*      */   protected TaskTemplate getLoopByOtherTask(TaskTemplate task) {
/*  199 */     TaskTemplate tmpTask = task;
/*      */     while (true) {
/*  201 */       JoinTemplate[] joins = getJoinsByTaskB(tmpTask);
/*  202 */       if ((joins == null) || (joins.length == 0)) {
/*  203 */         throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getLoopByOtherTask_cannotTask") + task.getLabel() + "(" + task.getTaskTemplateId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getLoopByOtherTask_findLoopNode"));
/*      */       }
/*      */ 
/*  206 */       TaskTemplate parent = joins[0].getTaskTemplateA();
/*  207 */       if (parent == null) {
/*  208 */         throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getLoopByOtherTask_cannotTask") + task.getLabel() + "(" + task.getTaskTemplateId() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getLoopByOtherTask_findLoopNode"));
/*      */       }
/*      */ 
/*  211 */       if (parent instanceof TaskLoopTemplate) {
/*  212 */         return parent;
/*      */       }
/*      */ 
/*  215 */       tmpTask = parent;
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskTemplate getEndLoopByLoop(TaskLoopTemplate loop)
/*      */   {
/*  221 */     JoinTemplate[] joins = getJoinsByTaskA(loop);
/*  222 */     for (int i = 0; i < joins.length; ++i) {
/*  223 */       if (joins[i].getTaskTemplateB() instanceof TaskLoopEndTemplate)
/*  224 */         return joins[i].getTaskTemplateB();
/*      */     }
/*  226 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_noLoopNode") + loop.getLabel() + "(" + loop.getTaskTemplateId() + ")" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_getLoopendNode"));
/*      */   }
/*      */ 
/*      */   public TaskTemplate getLoopByLoopEnd(TaskLoopEndTemplate endLoop)
/*      */   {
/*  232 */     JoinTemplate[] joins = getJoinsByTaskA(endLoop);
/*  233 */     for (int i = 0; i < joins.length; ++i) {
/*  234 */       if (joins[i].getTaskTemplateB() instanceof TaskLoopTemplate)
/*  235 */         return joins[i].getTaskTemplateB();
/*      */     }
/*  237 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_noLoopEndNode") + endLoop.getLabel() + "(" + endLoop.getTaskTemplateId() + ")" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_getCurrertLoopNode"));
/*      */   }
/*      */ 
/*      */   protected TaskTemplate getNextTaskOfLoop(TaskTemplate loop)
/*      */   {
/*  243 */     JoinTemplate[] joins = getJoinsByTaskA(loop);
/*  244 */     for (int i = 0; i < joins.length; ++i) {
/*  245 */       if (!joins[i].getTaskTemplateB() instanceof TaskLoopEndTemplate)
/*  246 */         return joins[i].getTaskTemplateB();
/*      */     }
/*  248 */     return null;
/*      */   }
/*      */ 
/*      */   protected boolean judgeTaskAAndTaskBIsOneLoop(TaskTemplate taskA, TaskTemplate taskB) {
/*  252 */     JoinTemplate[] joins = getJoinsByTaskA(taskA);
/*  253 */     for (int i = 0; i < joins.length; ++i) {
/*  254 */       if (joins[i].getTaskTemplateB().equals(taskB)) {
/*  255 */         JoinTemplate[] tempJoins = getJoinsByTaskA(taskB);
/*  256 */         for (int j = 0; j < tempJoins.length; ++j) {
/*  257 */           if (tempJoins[j].getTaskTemplateB().equals(taskA))
/*  258 */             return true;
/*      */         }
/*      */       }
/*      */     }
/*  262 */     return false;
/*      */   }
/*      */   protected TaskTemplate getNextTaskOfEndLoop(TaskTemplate endLoop) {
/*  265 */     JoinTemplate[] joins = getJoinsByTaskA(endLoop);
/*  266 */     for (int i = 0; i < joins.length; ++i) {
/*  267 */       TaskTemplate task = joins[i].getTaskTemplateB();
/*  268 */       if (!task instanceof TaskLoopTemplate) {
/*  269 */         return task;
/*      */       }
/*  271 */       JoinTemplate[] tempJoins = getJoinsByTaskA(task);
/*  272 */       boolean isSelfLoogStart = false;
/*  273 */       for (int j = 0; j < tempJoins.length; ++j) {
/*  274 */         if (tempJoins[j].getTaskTemplateB().equals(endLoop)) {
/*  275 */           isSelfLoogStart = true;
/*  276 */           break;
/*      */         }
/*      */       }
/*  279 */       if (!isSelfLoogStart) {
/*  280 */         return task;
/*      */       }
/*      */     }
/*      */ 
/*  284 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_noEndLoopNode") + endLoop.getLabel() + "(" + endLoop.getTaskTemplateId() + ")" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.getEndLoopByLoop_getAfterNode"));
/*      */   }
/*      */ 
/*      */   public void judgeAgainst()
/*      */   {
/*  294 */     List paths = new ArrayList();
/*      */ 
/*  297 */     TaskTemplate[] starts = getStartTaskTemplates();
/*  298 */     for (int i = 0; i < starts.length; ++i) {
/*  299 */       List tmpList = new ArrayList();
/*  300 */       tmpList.add(starts[i]);
/*  301 */       paths.add(tmpList);
/*      */     }
/*      */ 
/*  305 */     int point = 0;
/*  306 */     List okList = new ArrayList();
/*      */ 
/*  308 */     while (point < paths.size()) {
/*  309 */       List tmpList = (List)paths.get(point);
/*  310 */       List tmpOrgiList = new ArrayList();
/*  311 */       tmpOrgiList.addAll(tmpList);
/*  312 */       TaskTemplate taska = (TaskTemplate)tmpList.get(tmpList.size() - 1);
/*      */ 
/*  314 */       JoinTemplate[] joins = getJoinsByTaskA(taska);
/*  315 */       for (int i = 0; i < joins.length; ++i) {
/*  316 */         TaskTemplate taskb = joins[i].getTaskTemplateB();
/*  317 */         if (taskb == null) {
/*      */           continue;
/*      */         }
/*  320 */         if (taskb instanceof TaskFinishTemplate) {
/*  321 */           tmpList.add(taskb);
/*  322 */           okList.add(new Integer(point));
/*      */         }
/*      */         else
/*      */         {
/*  326 */           boolean isAgainst = false;
/*      */ 
/*  328 */           for (int j = 0; j < tmpList.size(); ++j) {
/*  329 */             if (taskb.equals(tmpList.get(j)) == true) {
/*  330 */               isAgainst = true;
/*  331 */               break;
/*      */             }
/*      */           }
/*  334 */           if (!isAgainst) {
/*  335 */             List l = new ArrayList();
/*  336 */             l.addAll(tmpOrgiList);
/*  337 */             l.add(taskb);
/*  338 */             paths.add(l);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  348 */       point += 1;
/*      */     }
/*      */ 
/*  351 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  352 */       ((JoinTemplate)it.next()).setIsAgainst(true);
/*      */     }
/*      */ 
/*  355 */     for (Iterator it = okList.iterator(); it.hasNext(); ) {
/*  356 */       point = ((Integer)it.next()).intValue();
/*  357 */       List tmpList = (List)paths.get(point);
/*      */ 
/*  359 */       for (int i = 0; i < tmpList.size() - 1; ++i) {
/*  360 */         TaskTemplate taska = (TaskTemplate)tmpList.get(i);
/*  361 */         TaskTemplate taskb = (TaskTemplate)tmpList.get(i + 1);
/*      */ 
/*  363 */         getJoinTemplate(taska, taskb).setIsAgainst(false);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public JoinTemplate getJoinTemplate(TaskTemplate taska, TaskTemplate taskb)
/*      */   {
/*  371 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  372 */       join = (JoinTemplate)it.next();
/*  373 */       if ((taska.equals(join.getTaskTemplateA()) == true) && (taskb.equals(join.getTaskTemplateB()) == true))
/*      */       {
/*  375 */         return join;
/*      */       }
/*      */     }
/*      */     JoinTemplate join;
/*  377 */     return null;
/*      */   }
/*      */ 
/*      */   public Element getElement()
/*      */   {
/*      */     try
/*      */     {
/*  386 */       fillBackTaskForJoin();
/*      */     }
/*      */     catch (Exception e) {
/*  389 */       e.printStackTrace();
/*      */     }
/*      */ 
/*  395 */     Element result = super.getElement();
/*  396 */     if (this.exceptionDealBean != null) {
/*  397 */       result.add(this.exceptionDealBean.getElement());
/*      */     }
/*      */ 
/*  400 */     if (this.getUserInfoDealBean != null) {
/*  401 */       result.add(this.getUserInfoDealBean.getElement());
/*      */     }
/*      */ 
/*  405 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  406 */       result.add(((TaskTemplate)it.next()).getElement());
/*      */     }
/*      */ 
/*  409 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  410 */       result.add(((JoinTemplate)it.next()).getElement());
/*      */     }
/*      */ 
/*  413 */     for (Iterator it = this.m_roleTemplates.iterator(); it.hasNext(); ) {
/*  414 */       result.add(((RoleTemplate)it.next()).getElement());
/*      */     }
/*      */ 
/*  417 */     return result;
/*      */   }
/*      */ 
/*      */   public void addJoinTemplate(JoinTemplate join)
/*      */   {
/*  425 */     this.m_joinTemplates.add(join);
/*      */   }
/*      */ 
/*      */   public void addTaskTemplate(TaskTemplate join)
/*      */   {
/*  433 */     this.m_taskTempaltes.add(join);
/*      */   }
/*      */ 
/*      */   public void addRoleTemplate(RoleTemplate role)
/*      */   {
/*  440 */     this.m_roleTemplates.add(role);
/*      */   }
/*      */ 
/*      */   public TaskTemplate[] getStartTaskTemplates()
/*      */   {
/*  448 */     List list = new ArrayList();
/*      */ 
/*  450 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  451 */       TaskTemplate task = (TaskTemplate)it.next();
/*  452 */       if (task.isStart() == true);
/*  453 */       list.add(task);
/*      */     }
/*  455 */     return (TaskTemplate[])(TaskTemplate[])list.toArray(new TaskTemplate[0]);
/*      */   }
/*      */ 
/*      */   public TaskTemplate[] getFinishTaskTemplates()
/*      */   {
/*  462 */     List list = new ArrayList();
/*      */ 
/*  464 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  465 */       TaskTemplate task = (TaskTemplate)it.next();
/*  466 */       if (task instanceof TaskFinishTemplate);
/*  467 */       list.add(task);
/*      */     }
/*  469 */     return (TaskTemplate[])(TaskTemplate[])list.toArray(new TaskTemplate[0]);
/*      */   }
/*      */ 
/*      */   public TaskTemplate[] getUserTaskTemplates()
/*      */     throws Exception
/*      */   {
/*  477 */     List list = new ArrayList();
/*      */ 
/*  479 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  480 */       TaskTemplate task = (TaskTemplate)it.next();
/*  481 */       if (task instanceof TaskUserTemplate);
/*  482 */       list.add(task);
/*      */     }
/*  484 */     return (TaskTemplate[])(TaskTemplate[])list.toArray(new TaskTemplate[0]);
/*      */   }
/*      */ 
/*      */   public JoinTemplate[] getJoinsByTaskA(TaskTemplate task)
/*      */   {
/*  495 */     List tmpList = new ArrayList();
/*      */ 
/*  497 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  498 */       JoinTemplate join = (JoinTemplate)it.next();
/*  499 */       if (join.getTaskTemplateAId() == task.getTaskTemplateId());
/*  500 */       tmpList.add(join);
/*      */     }
/*  502 */     return (JoinTemplate[])(JoinTemplate[])tmpList.toArray(new JoinTemplate[0]);
/*      */   }
/*      */ 
/*      */   public JoinTemplate[] getJoinsByTaskB(TaskTemplate task)
/*      */   {
/*  512 */     List tmpList = new ArrayList();
/*      */ 
/*  514 */     for (Iterator it = this.m_joinTemplates.iterator(); it.hasNext(); ) {
/*  515 */       JoinTemplate join = (JoinTemplate)it.next();
/*  516 */       if (join.getTaskTemplateBId() == task.getTaskTemplateId());
/*  517 */       tmpList.add(join);
/*      */     }
/*  519 */     return (JoinTemplate[])(JoinTemplate[])tmpList.toArray(new JoinTemplate[0]);
/*      */   }
/*      */ 
/*      */   public TaskTemplate getTaskTemplate(long taskTemplateId)
/*      */   {
/*  529 */     TaskTemplate result = null;
/*  530 */     for (Iterator it = this.m_taskTempaltes.iterator(); it.hasNext(); ) {
/*  531 */       result = (TaskTemplate)it.next();
/*  532 */       if (result.getTaskTemplateId() == taskTemplateId)
/*  533 */         return result;
/*      */     }
/*  535 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isBeforTask(long taskAId, long taskBId)
/*      */   {
/*  545 */     JoinTemplate[] joins = getJoinsByTaskB(getTaskTemplate(taskBId));
/*  546 */     for (int i = 0; i < joins.length; ++i) {
/*  547 */       if (joins[i].getIsAgainst() == true) {
/*      */         continue;
/*      */       }
/*  550 */       if (joins[i].getTaskTemplateAId() == taskAId) {
/*  551 */         return true;
/*      */       }
/*  553 */       if (isBeforTask(taskAId, joins[i].getTaskTemplateAId()) == true) {
/*  554 */         return true;
/*      */       }
/*      */     }
/*  557 */     return false;
/*      */   }
/*      */ 
/*      */   public TaskTemplate[] getTaskTemplates()
/*      */   {
/*  562 */     return (TaskTemplate[])(TaskTemplate[])this.m_taskTempaltes.toArray(new TaskTemplate[0]);
/*      */   }
/*      */ 
/*      */   public JoinTemplate[] getJoinTemplates() {
/*  566 */     return (JoinTemplate[])(JoinTemplate[])this.m_joinTemplates.toArray(new JoinTemplate[0]);
/*      */   }
/*      */ 
/*      */   public RoleTemplate[] getRoleTemplates() {
/*  570 */     return (RoleTemplate[])(RoleTemplate[])this.m_roleTemplates.toArray(new RoleTemplate[0]);
/*      */   }
/*      */ 
/*      */   public void deleteTaskTemplate(TaskTemplate task) {
/*  574 */     this.m_taskTempaltes.remove(task);
/*      */   }
/*      */ 
/*      */   public void deleteJoinTemplate(JoinTemplate join) {
/*  578 */     this.m_joinTemplates.remove(join);
/*      */   }
/*      */ 
/*      */   public void deleteRoleTemplate(RoleTemplate role)
/*      */   {
/*  583 */     this.m_roleTemplates.remove(role);
/*      */   }
/*      */ 
/*      */   public JoinTemplate createJoinTemplate()
/*      */   {
/*  588 */     JoinTemplateImpl result = new JoinTemplateImpl(this);
/*  589 */     this.m_joinTemplates.add(result);
/*  590 */     return result;
/*      */   }
/*      */ 
/*      */   public TaskTemplate createTaskTemplate(String type, String label) throws Exception
/*      */   {
/*  595 */     TaskTemplate task = TaskConfig.getInstance().getTaskTemplate(type, this, label);
/*      */ 
/*  597 */     this.m_taskTempaltes.add(task);
/*  598 */     return task;
/*      */   }
/*      */ 
/*      */   public RoleTemplate createRoleTemplate(String label) {
/*  602 */     RoleTemplateImpl result = new RoleTemplateImpl(label);
/*  603 */     this.m_roleTemplates.add(result);
/*  604 */     return result;
/*      */   }
/*      */ 
/*      */   public long getMaxTaskTemplateId() {
/*  608 */     this.m_maxTaskTemplateId += 1L;
/*  609 */     return this.m_maxTaskTemplateId;
/*      */   }
/*      */ 
/*      */   public void save(Writer writer) throws Exception {
/*  613 */     Element e = getElement();
/*  614 */     XmlUtil.writerXml(writer, e);
/*      */   }
/*      */ 
/*      */   public boolean isModify() {
/*  618 */     String s = XmlUtil.formatElement(getElement());
/*      */ 
/*  628 */     return !s.equals(this.m_oldFileString);
/*      */   }
/*      */ 
/*      */   public void checkFlowLogic(List errorList) {
/*  632 */     TaskTemplate[] tasks = getTaskTemplates();
/*  633 */     JoinTemplate[] joins = getJoinTemplates();
/*      */ 
/*  635 */     int startNum = 0;
/*  636 */     int endNum = 0;
/*  637 */     for (int i = 0; i < tasks.length; ++i) {
/*  638 */       if (tasks[i] instanceof TaskStartTemplate)
/*  639 */         startNum += 1;
/*  640 */       if (tasks[i] instanceof TaskFinishTemplate)
/*  641 */         endNum += 1;
/*      */     }
/*  643 */     if (startNum == 0)
/*  644 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processNoStartNode"));
/*  645 */     else if (startNum > 1) {
/*  646 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processMoreStartNode"));
/*      */     }
/*  648 */     if (endNum == 0)
/*  649 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processNoFinishNode"));
/*  650 */     else if (endNum > 1) {
/*  651 */       errorList.add(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processMoreFinishNode"));
/*      */     }
/*  653 */     for (int i = 0; i < joins.length; ++i) {
/*  654 */       joins[i].checkFlowLogic(errorList);
/*      */     }
/*  656 */     for (int i = 0; i < tasks.length; ++i)
/*  657 */       tasks[i].checkFlowLogic(errorList);
/*      */   }
/*      */ 
/*      */   public void toJavaCode(StringBuffer buffer, int level)
/*      */   {
/*  665 */     createWorkflowNode().toJavaCode(buffer, level);
/*      */   }
/*      */ 
/*      */   public TaskNodeProcess createWorkflowNode() {
/*  669 */     TaskTemplate[] starts = getStartTaskTemplates();
/*  670 */     if (starts.length == 0)
/*  671 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processNoStartNode"));
/*  672 */     if (starts.length > 1)
/*  673 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processMoreStartNode"));
/*  674 */     TaskTemplate[] ends = getFinishTaskTemplates();
/*  675 */     if (ends.length == 0)
/*  676 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processNoFinishNode"));
/*  677 */     if (ends.length > 1)
/*  678 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.checkFlowLogic_processMoreFinishNode"));
/*  679 */     TaskTemplate[] tasks = getTaskTemplates();
/*  680 */     if (tasks.length == 2) {
/*  681 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.createWorkflowNode_processOnlyStartEndNode"));
/*      */     }
/*      */ 
/*  685 */     TaskTemplate template = starts[0];
/*  686 */     JoinTemplate[] joins = getJoinsByTaskA(template);
/*  687 */     if (joins.length != 1) {
/*  688 */       throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.createWorkflowNode_onlyOneLine"));
/*      */     }
/*      */ 
/*  691 */     TaskNodeProcess workflowNode = new TaskNodeProcess(null, this);
/*  692 */     template = fillChild(workflowNode, joins[0]);
/*  693 */     if (!template instanceof TaskFinishTemplate) {
/*  694 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.createWorkflowNode_processEndUnnormal"));
/*      */     }
/*      */ 
/*  698 */     return workflowNode;
/*      */   }
/*      */ 
/*      */   public TaskTemplate fillChild(TaskNode prarentNode, JoinTemplate join)
/*      */   {
/*  703 */     TaskTemplate template = join.getTaskTemplateB();
/*      */     while (true) {
/*  705 */       if ((template instanceof TaskLoopEndTemplate) || (template instanceof TaskDecisionEndTemplate) || (template instanceof TaskOrTemplate) || (template instanceof TaskAndTemplate) || (template instanceof TaskFinishTemplate) || (template instanceof TaskCaseEndTemplate))
/*      */       {
/*  708 */         return template;
/*      */       }
/*  710 */       JoinTemplate[] joins = getJoinsByTaskA(template);
/*  711 */       if (template instanceof TaskLoopTemplate) {
/*  712 */         if ((joins.length == 1) || (joins.length == 2))
/*      */         {
/*  714 */           if (joins.length == 1) {
/*  715 */             if (joins[0].getTaskTemplateB() instanceof TaskLoopEndTemplate) {
/*  716 */               throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneOutLine"));
/*      */             }
/*  718 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneLineToEndloop"));
/*      */           }
/*      */ 
/*  722 */           JoinTemplate nextJoin = null;
/*  723 */           TaskTemplate endLoop = null;
/*  724 */           if (joins[0].getTaskTemplateB() instanceof TaskLoopEndTemplate)
/*  725 */             endLoop = joins[0].getTaskTemplateB();
/*      */           else {
/*  727 */             nextJoin = joins[0];
/*      */           }
/*  729 */           if (joins.length == 2) {
/*  730 */             if (joins[1].getTaskTemplateB() instanceof TaskLoopEndTemplate) {
/*  731 */               if (endLoop != null) {
/*  732 */                 throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_no2LineToEndLoop"));
/*      */               }
/*  734 */               endLoop = joins[1].getTaskTemplateB();
/*      */             } else {
/*  736 */               if (nextJoin != null) {
/*  737 */                 throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_no2LineToOtherNode"));
/*      */               }
/*  739 */               nextJoin = joins[1];
/*      */             }
/*      */           }
/*  742 */           TaskNode loopNode = new TaskNodeLoop(prarentNode, template);
/*  743 */           prarentNode.addChild(loopNode);
/*  744 */           TaskTemplate tempEndLoop = fillChild(loopNode, nextJoin);
/*  745 */           if ((!tempEndLoop instanceof TaskLoopEndTemplate) || ((endLoop != null) && (endLoop != tempEndLoop))) {
/*  746 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_noCurrectEndNode"));
/*      */           }
/*  748 */           joins = getJoinsByTaskA(tempEndLoop);
/*      */ 
/*  750 */           if ((joins.length == 0) || (joins.length > 2))
/*  751 */             throw new RuntimeException(tempEndLoop.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + tempEndLoop.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneToOtherOneToLoop"));
/*  752 */           if (((joins.length == 1) && (joins[0].getTaskTemplateB() instanceof TaskLoopTemplate)) || ((joins.length == 2) && (judgeTaskAAndTaskBIsOneLoop(joins[0].getTaskTemplateA(), joins[0].getTaskTemplateB())) && (judgeTaskAAndTaskBIsOneLoop(joins[1].getTaskTemplateA(), joins[1].getTaskTemplateB()))))
/*      */           {
/*  755 */             throw new RuntimeException(tempEndLoop.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + tempEndLoop.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneToOtherOneToLoop"));
/*      */           }
/*  757 */           if (joins.length == 1) {
/*  758 */             if (joins[0].getTaskTemplateB() instanceof TaskLoopTemplate) {
/*  759 */               throw new RuntimeException(tempEndLoop.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + tempEndLoop.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneOutLine"));
/*      */             }
/*  761 */             throw new RuntimeException(tempEndLoop.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + tempEndLoop.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_oneOutToLoopNode"));
/*      */           }
/*  763 */           if (joins.length == 2)
/*      */           {
/*  769 */             if (!joins[0].getTaskTemplateB() instanceof TaskLoopTemplate)
/*  770 */               template = joins[0].getTaskTemplateB();
/*      */             else {
/*  772 */               template = joins[1].getTaskTemplateB();
/*      */             }
/*      */           }
/*  775 */           break label3452:
/*  776 */         }throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_has2OneToOtherOneToEndLoop"));
/*      */       }
/*  778 */       if (template instanceof TaskDecisionTemplate) {
/*  779 */         if (joins.length == 0) {
/*  780 */           throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/*      */         }
/*  782 */         TaskNodeIF ifNode = new TaskNodeIF(prarentNode, template);
/*  783 */         prarentNode.addChild(ifNode);
/*  784 */         JoinTemplate defaultJoin = null;
/*  785 */         for (int i = 0; i < joins.length; ++i) {
/*  786 */           if ((joins[i].getCondition() == null) || (joins[i].getCondition().trim().length() == 0)) {
/*  787 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_noSetCond"));
/*      */           }
/*  789 */           if (joins[i].getCondition().trim().equalsIgnoreCase("default")) {
/*  790 */             if (ifNode.m_defaultChild != null) {
/*  791 */               throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneLine") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */             }
/*      */ 
/*  794 */             ifNode.setDefaultChildren(new TaskNode(ifNode, null));
/*  795 */             defaultJoin = joins[i];
/*      */           }
/*      */           else {
/*  798 */             ifNode.addCaseChildren(joins[i], new TaskNode(ifNode, null));
/*      */           }
/*      */         }
/*  801 */         if (ifNode.m_defaultChild == null) {
/*  802 */           if (joins.length == 2) { if (("true".equalsIgnoreCase(joins[0].getCondition())) && ("false".equalsIgnoreCase(joins[1].getCondition()))) break label1415; if (("true".equalsIgnoreCase(joins[1].getCondition())) && ("false".equalsIgnoreCase(joins[0].getCondition())))
/*      */             {
/*      */               break label1415;
/*      */             }
/*      */  }
/*      */ 
/*      */ 
/*  809 */           throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_notTrueFalseOnlyOne") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */         }
/*      */ 
/*  814 */         label1415: TaskTemplate endIf = null;
/*  815 */         if (defaultJoin != null) {
/*  816 */           endIf = fillChild(ifNode.m_defaultChild, defaultJoin);
/*      */         }
/*  818 */         for (Iterator it = ifNode.m_caseChild.entrySet().iterator(); it.hasNext(); ) {
/*  819 */           Map.Entry me = (Map.Entry)it.next();
/*  820 */           JoinTemplate tmpJoin = (JoinTemplate)me.getKey();
/*  821 */           TaskNode tmpNode = (TaskNode)me.getValue();
/*  822 */           TaskTemplate tmpEndIf = fillChild(tmpNode, tmpJoin);
/*  823 */           if (endIf == null) {
/*  824 */             endIf = tmpEndIf;
/*      */           }
/*  826 */           else if (!endIf.equals(tmpEndIf)) {
/*  827 */             throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_notConvergedOne"));
/*      */           }
/*      */         }
/*  830 */         joins = getJoinsByTaskA(endIf);
/*  831 */         if (joins.length > 1) {
/*  832 */           if (endIf instanceof TaskLoopEndTemplate) {
/*  833 */             template = endIf; break label1682:
/*      */           }
/*  835 */           throw new RuntimeException(endIf.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + endIf.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_oneLineeOut"));
/*      */         }
/*      */ 
/*  838 */         label2194: label1682: label2461: label3452: if (joins.length == 0) {
/*  839 */           template = endIf;
/*      */         }
/*      */         else {
/*  842 */           template = joins[0].getTaskTemplateB();
/*      */         }
/*      */       }
/*  845 */       else if (template instanceof TaskUserTemplate) {
/*  846 */         if (joins.length == 0) {
/*  847 */           throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/*      */         }
/*  849 */         if (joins.length == 1) {
/*  850 */           prarentNode.addChild(new TaskNode(prarentNode, template));
/*  851 */           template = joins[0].getTaskTemplateB();
/*      */         }
/*      */         else {
/*  854 */           TaskNodeIF ifNode = new TaskNodeIF(prarentNode, template);
/*  855 */           prarentNode.addChild(ifNode);
/*  856 */           JoinTemplate defaultJoin = null;
/*  857 */           for (int i = 0; i < joins.length; ++i) {
/*  858 */             if ((joins[i].getCondition() == null) || (joins[i].getCondition().trim().length() == 0)) {
/*  859 */               throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_noSetCond"));
/*      */             }
/*  861 */             if (joins[i].getCondition().trim().equalsIgnoreCase("default")) {
/*  862 */               if (ifNode.m_defaultChild != null) {
/*  863 */                 throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOneLine") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */               }
/*      */ 
/*  866 */               ifNode.setDefaultChildren(new TaskNode(ifNode, null));
/*  867 */               defaultJoin = joins[i];
/*      */             }
/*      */             else {
/*  870 */               ifNode.addCaseChildren(joins[i], new TaskNode(ifNode, null));
/*      */             }
/*      */           }
/*  873 */           if (ifNode.m_defaultChild == null) {
/*  874 */             if (joins.length == 2) { if (("true".equalsIgnoreCase(joins[0].getCondition())) && ("false".equalsIgnoreCase(joins[1].getCondition()))) break label2194; if (("true".equalsIgnoreCase(joins[1].getCondition())) && ("false".equalsIgnoreCase(joins[0].getCondition())))
/*      */               {
/*      */                 break label2194;
/*      */               }
/*      */  }
/*      */ 
/*      */ 
/*  881 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_notTrueFalseOnlyOne") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */           }
/*      */ 
/*  886 */           TaskTemplate endIf = null;
/*  887 */           if (defaultJoin != null) {
/*  888 */             endIf = fillChild(ifNode.m_defaultChild, defaultJoin);
/*      */           }
/*  890 */           for (Iterator it = ifNode.m_caseChild.entrySet().iterator(); it.hasNext(); ) {
/*  891 */             Map.Entry me = (Map.Entry)it.next();
/*  892 */             JoinTemplate tmpJoin = (JoinTemplate)me.getKey();
/*  893 */             TaskNode tmpNode = (TaskNode)me.getValue();
/*  894 */             TaskTemplate tmpEndIf = fillChild(tmpNode, tmpJoin);
/*  895 */             if (endIf == null) {
/*  896 */               endIf = tmpEndIf;
/*      */             }
/*  898 */             else if (!endIf.equals(tmpEndIf)) {
/*  899 */               throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_notConvergedOne"));
/*      */             }
/*      */           }
/*  902 */           joins = getJoinsByTaskA(endIf);
/*  903 */           if (joins.length > 1) {
/*  904 */             if (endIf instanceof TaskLoopEndTemplate) {
/*  905 */               template = endIf; break label2461:
/*      */             }
/*  907 */             throw new RuntimeException(endIf.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + endIf.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_oneLineeOut"));
/*      */           }
/*      */ 
/*  910 */           if (joins.length == 0) {
/*  911 */             template = endIf;
/*      */           }
/*      */           else
/*  914 */             template = joins[0].getTaskTemplateB();
/*      */         }
/*      */       } else {
/*  917 */         if (template instanceof TaskForkTemplate)
/*  918 */           throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_noDealWay"));
/*  919 */         if (template instanceof TaskCaseTemplate)
/*      */         {
/*  921 */           if (joins.length == 0) {
/*  922 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineOut"));
/*      */           }
/*      */ 
/*  926 */           TaskNodeCase caseNode = new TaskNodeCase(prarentNode, template);
/*  927 */           prarentNode.addChild(caseNode);
/*  928 */           JoinTemplate defaultJoin = null;
/*  929 */           for (int i = 0; i < joins.length; ++i) {
/*  930 */             if ((joins[i].getCondition() == null) || (joins[i].getCondition().trim().length() == 0)) {
/*  931 */               throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseTemplateImpl.checkFlowLogicStatic_noCaseCondition"));
/*      */             }
/*      */ 
/*  934 */             if (joins[i].getCondition().trim().equalsIgnoreCase("default")) {
/*  935 */               if (caseNode.m_defaultChild != null) {
/*  936 */                 throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseTemplateImpl.checkFlowLogicStatic_inputLine"));
/*      */               }
/*      */ 
/*  939 */               caseNode.setDefaultChildren(new TaskNode(caseNode, null));
/*  940 */               defaultJoin = joins[i];
/*      */             } else {
/*  942 */               caseNode.addCaseChildren(joins[i], new TaskNode(caseNode, null));
/*      */             }
/*      */           }
/*  945 */           if (caseNode.m_defaultChild == null) {
/*  946 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseTemplateImpl.checkFlowLogicStatic_inputLine"));
/*      */           }
/*      */ 
/*  950 */           TaskTemplate endCase = fillChild(caseNode.m_defaultChild, defaultJoin);
/*  951 */           if (!endCase instanceof TaskCaseEndTemplate) {
/*  952 */             throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_defaultNoTogetherOne"));
/*      */           }
/*  954 */           for (Iterator it = caseNode.m_caseChild.entrySet().iterator(); it.hasNext(); ) {
/*  955 */             Map.Entry me = (Map.Entry)it.next();
/*  956 */             JoinTemplate tmpJoin = (JoinTemplate)me.getKey();
/*  957 */             TaskNode tmpNode = (TaskNode)me.getValue();
/*  958 */             TaskTemplate tmpEndCase = fillChild(tmpNode, tmpJoin);
/*  959 */             if (!endCase.equals(tmpEndCase)) {
/*  960 */               throw new RuntimeException("case " + tmpJoin.getCondition() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_noTogetherWithDefault"));
/*      */             }
/*      */           }
/*  963 */           joins = getJoinsByTaskA(endCase);
/*  964 */           if (joins.length != 1) {
/*  965 */             throw new RuntimeException(endCase.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + endCase.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.createWorkflowNode_onlyOneLine"));
/*      */           }
/*      */ 
/*  968 */           template = joins[0].getTaskTemplateB();
/*      */         }
/*      */         else {
/*  971 */           prarentNode.addChild(new TaskNode(prarentNode, template));
/*  972 */           if (joins.length == 1) {
/*  973 */             template = joins[0].getTaskTemplateB();
/*      */           } else {
/*  975 */             if (joins.length == 2) {
/*  976 */               if ((joins[0].getCondition() != null) && (joins[0].getCondition().equalsIgnoreCase("exception")) && (joins[1].getCondition().equalsIgnoreCase("default")))
/*      */               {
/*  978 */                 template = joins[1].getTaskTemplateB();
/*  979 */                 break label3452:
/*  980 */               }if ((joins[1].getCondition() != null) && (joins[1].getCondition().equalsIgnoreCase("exception")) && (joins[0].getCondition().equalsIgnoreCase("default")))
/*      */               {
/*  982 */                 template = joins[0].getTaskTemplateB();
/*  983 */                 break label3452:
/*      */               }
/*  985 */               throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOnelineOutOrOne") + "exception" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_condLineOutAndOne") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */             }
/*      */ 
/*  991 */             throw new RuntimeException(template.getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + template.getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_onlyOnelineOutOrOne") + "exception" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_condLineOutAndOne") + "default" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.WorkflowTemplateImpl.fillChild_lineOut"));
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskDealBean getExceptionDealBean() {
/*  998 */     return this.exceptionDealBean;
/*      */   }
/*      */ 
/*      */   public void setExceptionDealBean(TaskDealBean value) {
/* 1002 */     this.exceptionDealBean = value;
/*      */   }
/*      */ 
/*      */   public TaskDealBean getGetUserInfoDealBean() {
/* 1006 */     return this.getUserInfoDealBean;
/*      */   }
/*      */ 
/*      */   public void setGetUserInfoDealBean(TaskDealBean value) {
/* 1010 */     this.getUserInfoDealBean = value;
/*      */   }
/*      */ 
/*      */   public Timestamp getValidDate() {
/* 1014 */     return this.validDate;
/*      */   }
/*      */   public Timestamp getExpireDate() {
/* 1017 */     return this.expireDate;
/*      */   }
/*      */ 
/*      */   public void setValidDate(Timestamp date) {
/* 1021 */     this.validDate = date;
/*      */   }
/*      */   public void setExpireDate(Timestamp date) {
/* 1024 */     this.expireDate = date;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.WorkflowTemplateImpl
 * JD-Core Version:    0.5.4
 */