/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.template.JoinTemplate;
/*    */ import com.ai.comframe.vm.template.TaskCaseEndTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskCaseEndTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskCaseEndTemplate
/*    */ {
/*    */   public TaskCaseEndTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 28 */     super(aWorkflowTemplate, item);
/*    */   }
/*    */ 
/*    */   public TaskCaseEndTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*    */   {
/* 33 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public void checkFlowLogic(List errorList)
/*    */   {
/* 39 */     JoinTemplate[] joins = getWorkflowTemplate().getJoinsByTaskB(this);
/* 40 */     if (joins.length == 0) {
/* 41 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_nolineIn"));
/*    */     }
/*    */ 
/* 45 */     joins = getWorkflowTemplate().getJoinsByTaskA(this);
/* 46 */     if (joins.length != 1)
/* 47 */       errorList.add(getTaskType() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.JoinTemplateImpl.checkFlowLogic_node") + getLabel() + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskCaseEndTemplateImpl.checkFlowLogic_onlyOneLine"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskCaseEndTemplateImpl
 * JD-Core Version:    0.5.4
 */