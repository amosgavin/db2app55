package com.ai.comframe.vm.template;

import com.ai.comframe.vm.common.ParameterDefine;
import java.util.List;

public abstract interface VMClassTemplate
{
  public abstract List getVars();

  public abstract List getParentVars();

  public abstract List getMethods();

  public abstract List getParentMethods();

  public abstract void setVars(List paramList);

  public abstract void setInterfaces(String paramString);

  public abstract String getInterfaces();

  public abstract void setLabel(String paramString);

  public abstract String getLabel();

  public abstract void setExtendsClass(String paramString);

  public abstract String getExtendsClass();

  public abstract ParameterDefine getVars(String paramString);

  public abstract List getWorkflowTemplates();

  public abstract WorkflowTemplate getWorkflowTemplate(String paramString);

  public abstract void setWorkflowTemplates(List paramList);

  public abstract void toJavaRemark(StringBuffer paramStringBuffer, int paramInt);

  public abstract void toJavaCode(StringBuffer paramStringBuffer, int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.VMClassTemplate
 * JD-Core Version:    0.5.4
 */