package com.ai.comframe.vm.template;

public abstract interface TaskLoopTemplate extends TaskDecisionConditionTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskLoopTemplate
 * JD-Core Version:    0.5.4
 */