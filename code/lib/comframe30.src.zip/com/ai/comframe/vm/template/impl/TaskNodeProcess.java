/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ class TaskNodeProcess extends TaskNode
/*     */ {
/*     */   public TaskNodeProcess(TaskNode parent, TaskTemplate task)
/*     */   {
/*  94 */     super(parent, task);
/*     */   }
/*     */ 
/*     */   public void createExecuteFunction(WorkflowTemplate process, StringBuffer buffer, int level)
/*     */   {
/*  99 */     createExecuteFunction(process, "execute", buffer, level);
/*     */   }
/*     */ 
/*     */   public void createExecuteFunction(WorkflowTemplate process, String functionName, StringBuffer buffer, int level) {
/* 103 */     appendLevel(buffer, level);
/*     */ 
/* 105 */     List l = process.getVars();
/* 106 */     String pStr = "";
/* 107 */     String callParameterStr = "";
/* 108 */     ParameterDefine pReturn = null;
/* 109 */     boolean isFirst = true;
/* 110 */     for (int i = 0; i < l.size(); ++i) {
/* 111 */       ParameterDefine p = (ParameterDefine)l.get(i);
/* 112 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true))))
/*     */       {
/* 115 */         if (!isFirst) {
/* 116 */           pStr = pStr + ",";
/* 117 */           callParameterStr = callParameterStr + ",";
/*     */         } else {
/* 119 */           isFirst = false;
/*     */         }
/* 121 */         pStr = pStr + p.dataType + " " + p.name;
/* 122 */         callParameterStr = callParameterStr + " " + p.name;
/*     */       }
/* 124 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("out") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/* 125 */         if (pReturn != null) {
/* 126 */           throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + process.getTaskTag() + "." + functionName + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskNode.createExecuteFunction_moreReturnValues"));
/*     */         }
/*     */ 
/* 129 */         pReturn = p;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 134 */     if (pReturn != null)
/* 135 */       buffer.append("public " + pReturn.dataType + " " + functionName + "(");
/*     */     else {
/* 137 */       buffer.append("public void " + functionName + "(");
/*     */     }
/* 139 */     buffer.append(pStr);
/* 140 */     buffer.append(") throws Exception{\n");
/*     */ 
/* 142 */     appendLevel(buffer, level + 1);
/* 143 */     buffer.append("java.util.Map $inParameter = new java.util.HashMap();\n");
/* 144 */     appendLevel(buffer, level + 1);
/* 145 */     buffer.append("java.util.Map $returnParameter = new java.util.HashMap();\n");
/*     */ 
/* 147 */     for (Iterator it = process.getVars().iterator(); it.hasNext(); ) {
/* 148 */       ParameterDefine p = (ParameterDefine)it.next();
/* 149 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/* 150 */         appendLevel(buffer, level + 1);
/* 151 */         if (!p.getDataTypeClass().isPrimitive()) {
/* 152 */           buffer.append("$inParameter.put(\"" + p.name + "\"," + p.name + ");\n");
/*     */         }
/*     */         else {
/* 155 */           buffer.append("$inParameter.put(\"" + p.name + "\",new " + DataType.getJavaObjectType(p.dataType) + "(" + p.name + "));\n");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 172 */     buffer.append("try{\n");
/* 173 */     appendLevel(buffer, level + 1);
/* 174 */     if (pReturn != null) {
/* 175 */       buffer.append(pReturn.dataType + " realReturn;\n");
/* 176 */       buffer.append("realReturn = " + functionName + "Inner(" + callParameterStr + ");\n");
/* 177 */       appendLevel(buffer, level + 1);
/* 178 */       if (!pReturn.getDataTypeClass().isPrimitive())
/* 179 */         buffer.append("$returnParameter.put(\"" + pReturn.name + "\",realReturn);\n");
/*     */       else {
/* 181 */         buffer.append("$returnParameter.put(\"" + pReturn.name + "\",new " + DataType.getJavaObjectType(pReturn.dataType) + "(realReturn));\n");
/*     */       }
/*     */ 
/* 184 */       appendLevel(buffer, level);
/* 185 */       buffer.append("return realReturn;\n");
/*     */     } else {
/* 187 */       buffer.append(functionName + "Inner(" + callParameterStr + ");\n");
/*     */     }
/*     */ 
/* 191 */     buffer.append("}catch(Exception ex ){\n");
/*     */ 
/* 193 */     buffer.append("throw ex;\n");
/* 194 */     buffer.append("}catch(Throwable e ){\n");
/*     */ 
/* 196 */     buffer.append("if(e instanceof RuntimeException){\n throw (RuntimeException)e ;\n} else {\n throw new RuntimeException(e);\n}\n");
/* 197 */     buffer.append("}\n");
/*     */ 
/* 203 */     appendLevel(buffer, level);
/* 204 */     buffer.append("}\n");
/*     */   }
/*     */   public void createExecuteFunctionWithMapParameter(WorkflowTemplate process, StringBuffer buffer, int level) {
/* 207 */     createExecuteFunctionWithMapParameter(process, "execute", buffer, level);
/*     */   }
/*     */   public void createExecuteFunctionWithMapParameter(WorkflowTemplate process, String functionName, StringBuffer buffer, int level) {
/* 210 */     appendLevel(buffer, level);
/* 211 */     buffer.append("public java.util.Map " + functionName + "(java.util.Map $vmParameters) throws Exception{\n");
/*     */ 
/* 214 */     ParameterDefine pReturn = null;
/* 215 */     List l = process.getVars();
/* 216 */     boolean isFirst = true;
/* 217 */     String callParameter = "";
/* 218 */     for (int i = 0; i < l.size(); ++i) {
/* 219 */       ParameterDefine p = (ParameterDefine)l.get(i);
/* 220 */       String result = "";
/* 221 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true))))
/*     */       {
/* 223 */         if (!isFirst)
/* 224 */           callParameter = callParameter + ",";
/*     */         else {
/* 226 */           isFirst = false;
/*     */         }
/* 228 */         callParameter = callParameter + p.name;
/* 229 */         result = Process2JavaUtil.getParameterInExpress(p.name, p.getDataTypeClass(), "$vmParameters.get(\"" + p.name + "\")", p.defaultValue, true);
/* 230 */         appendLevel(buffer, level + 1);
/* 231 */         buffer.append(result + ";\n");
/*     */       }
/* 233 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("out") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/* 234 */         pReturn = p;
/*     */       }
/*     */     }
/*     */ 
/* 238 */     if (pReturn != null) {
/* 239 */       buffer.append(pReturn.dataType + " realReturn;\n");
/* 240 */       buffer.append("realReturn = " + functionName + "(" + callParameter + ");\n");
/* 241 */       appendLevel(buffer, level + 1);
/* 242 */       if (!pReturn.getDataTypeClass().isPrimitive())
/* 243 */         buffer.append("$vmParameters.put(\"" + pReturn.name + "\",realReturn);\n");
/*     */       else {
/* 245 */         buffer.append("$vmParameters.put(\"" + pReturn.name + "\",new " + DataType.getJavaObjectType(pReturn.dataType) + "(realReturn));\n");
/*     */       }
/*     */ 
/* 248 */       appendLevel(buffer, level);
/*     */     } else {
/* 250 */       buffer.append(functionName + "(" + callParameter + ");\n");
/*     */     }
/* 252 */     appendLevel(buffer, level);
/* 253 */     buffer.append("return $vmParameters;\n");
/* 254 */     appendLevel(buffer, level);
/* 255 */     buffer.append("}\n");
/*     */   }
/*     */ 
/*     */   public void createExecuteInnerFunction(WorkflowTemplate process, StringBuffer buffer, int level) {
/* 259 */     createExecuteInnerFunction(process, "execute", buffer, level);
/*     */   }
/*     */   public void createExecuteInnerFunction(WorkflowTemplate process, String functionName, StringBuffer buffer, int level) {
/* 262 */     appendLevel(buffer, level);
/* 263 */     List l = process.getVars();
/* 264 */     String pStr = "";
/* 265 */     ParameterDefine pReturn = null;
/* 266 */     boolean isFirst = true;
/* 267 */     for (int i = 0; i < l.size(); ++i) {
/* 268 */       ParameterDefine p = (ParameterDefine)l.get(i);
/* 269 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true))))
/*     */       {
/* 271 */         if (!isFirst)
/* 272 */           pStr = pStr + ",";
/*     */         else {
/* 274 */           isFirst = false;
/*     */         }
/* 276 */         pStr = pStr + p.dataType + " " + p.name;
/*     */       }
/* 278 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("out") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/* 279 */         if (pReturn != null) {
/* 280 */           throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.engine.impl.FlowBaseImpl.dealCaseTask_process") + process.getTaskTag() + "." + functionName + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskNode.createExecuteFunction_moreReturnValues"));
/*     */         }
/*     */ 
/* 283 */         pReturn = p;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 288 */     if (pReturn != null)
/* 289 */       buffer.append("protected " + pReturn.dataType + " " + functionName + "Inner(");
/*     */     else {
/* 291 */       buffer.append("protected void " + functionName + "Inner(");
/*     */     }
/* 293 */     buffer.append(pStr);
/* 294 */     buffer.append(") throws Exception{\n");
/*     */ 
/* 296 */     for (int i = 0; i < l.size(); ++i) {
/* 297 */       ParameterDefine p = (ParameterDefine)l.get(i);
/* 298 */       String result = "";
/* 299 */       if ((p.inOutType != null) && (p.inOutType.equalsIgnoreCase("inner") != true) && (p.inOutType.equalsIgnoreCase("out") != true))
/*     */         continue;
/* 301 */       result = VMDataType.getClassName(p.getDataTypeClass()) + " " + p.name + " = " + Process2JavaUtil.getDefaultValueString(p.getDataTypeClass(), p.defaultValue);
/*     */ 
/* 305 */       buffer.append(result + ";\n");
/*     */     }
/*     */ 
/* 308 */     for (int i = 0; i < this.m_child.size(); ++i) {
/* 309 */       ((TaskNode)this.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */     }
/*     */ 
/* 313 */     if (pReturn != null) {
/* 314 */       appendLevel(buffer, level + 1);
/* 315 */       buffer.append("return " + pReturn.name + ";\n");
/*     */     }
/*     */ 
/* 318 */     appendLevel(buffer, level);
/* 319 */     buffer.append("}\n");
/*     */   }
/*     */   public void createExecuteInnerFunction2(WorkflowTemplate process, String functionName, StringBuffer buffer, int level) {
/* 322 */     appendLevel(buffer, level);
/* 323 */     buffer.append("private java.util.Map " + functionName + "Inner(java.util.Map $vmParameters) throws Exception{\n");
/*     */ 
/* 325 */     for (Iterator it = process.getVars().iterator(); it.hasNext(); ) {
/* 326 */       ParameterDefine p = (ParameterDefine)it.next();
/* 327 */       String result = "";
/* 328 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true))))
/*     */       {
/* 330 */         result = Process2JavaUtil.getParameterInExpress(p.name, p.getDataTypeClass(), "$vmParameters.get(\"" + p.name + "\")", p.defaultValue, true);
/*     */       }
/*     */       else {
/* 333 */         result = VMDataType.getClassName(p.getDataTypeClass()) + " " + p.name + " = " + Process2JavaUtil.getDefaultValueString(p.getDataTypeClass(), p.defaultValue);
/*     */       }
/* 335 */       appendLevel(buffer, level + 1);
/* 336 */       buffer.append(result + ";\n");
/*     */     }
/*     */ 
/* 341 */     for (int i = 0; i < this.m_child.size(); ++i) {
/* 342 */       ((TaskNode)this.m_child.get(i)).toJavaCode(buffer, level + 1);
/*     */     }
/*     */ 
/* 347 */     for (Iterator it = process.getVars().iterator(); it.hasNext(); ) {
/* 348 */       ParameterDefine p = (ParameterDefine)it.next();
/* 349 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("out") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/* 350 */         appendLevel(buffer, level + 1);
/* 351 */         buffer.append(Process2JavaUtil.getParameterOutExpress("$vmParameters", p.name, p.getDataTypeClass(), p.name) + ";\n");
/*     */       }
/*     */     }
/*     */ 
/* 355 */     appendLevel(buffer, level + 1);
/* 356 */     buffer.append("return $vmParameters;\n");
/*     */ 
/* 358 */     appendLevel(buffer, level);
/* 359 */     buffer.append("}\n");
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level)
/*     */   {
/* 364 */     WorkflowTemplate process = (WorkflowTemplate)this.m_task;
/*     */ 
/* 366 */     this.m_task.toJavaRemark(buffer, level);
/* 367 */     String className = process.getTaskTag() + "_" + "AIProcess";
/*     */ 
/* 369 */     int index = className.lastIndexOf('.');
/*     */ 
/* 372 */     if (index != -1) {
/* 373 */       buffer.append("package " + className.substring(0, index) + ";\n\n");
/*     */     }
/* 375 */     buffer.append("import com.ai.comframe.vm.common.VMDataType;\n");
/* 376 */     buffer.append("import org.apache.commons.logging.Log;\n");
/* 377 */     buffer.append("import org.apache.commons.logging.LogFactory;\n\n");
/*     */ 
/* 379 */     buffer.append("public class " + className.substring(index + 1) + " implements com.ai.comframe.vm.processflow.ProcessInstance{\n");
/* 380 */     buffer.append("  private static transient Log logger = LogFactory.getLog(" + className.substring(index + 1) + ".class);\n");
/*     */ 
/* 382 */     createExecuteInnerFunction(process, buffer, level + 1);
/* 383 */     createExecuteFunction(process, buffer, level + 1);
/* 384 */     createExecuteFunctionWithMapParameter(process, buffer, 1);
/*     */ 
/* 387 */     appendLevel(buffer, level);
/* 388 */     buffer.append("}");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskNodeProcess
 * JD-Core Version:    0.5.4
 */