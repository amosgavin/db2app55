/*     */ package com.ai.comframe.vm.template;
/*     */ 
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.VMDataType;
/*     */ import com.ai.comframe.vm.common.XmlUtil;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskDealBean
/*     */ {
/*     */   protected String dealType;
/*     */   protected String runType;
/*     */   protected String serviceName;
/*     */   protected String runClassName;
/*     */   protected String runFunctionName;
/*  33 */   protected List vars = new ArrayList();
/*     */   protected transient Class m_runClass;
/*     */   protected transient Method m_runFunction;
/*     */ 
/*     */   public TaskDealBean(String dealType)
/*     */   {
/*  40 */     this.dealType = dealType;
/*     */   }
/*     */ 
/*     */   public TaskDealBean(Element item) {
/*  44 */     if (item == null)
/*  45 */       return;
/*  46 */     this.dealType = item.getName();
/*  47 */     this.runType = item.elementText("runtype");
/*  48 */     this.serviceName = item.elementText("servicename");
/*  49 */     this.runClassName = item.elementText("runclassname");
/*  50 */     this.runFunctionName = item.elementText("runfunctionname");
/*  51 */     if (this.vars == null) {
/*  52 */       this.vars = new ArrayList();
/*     */     }
/*  54 */     List tmpList = item.elements("vars");
/*     */ 
/*  56 */     for (int i = 0; i < tmpList.size(); ++i) {
/*  57 */       Element tmpNode = (Element)tmpList.get(i);
/*  58 */       ParameterDefine p = new ParameterDefine();
/*  59 */       p.name = tmpNode.attributeValue("name");
/*  60 */       p.dataType = tmpNode.attributeValue("datatype");
/*  61 */       p.contextVarName = tmpNode.attributeValue("contextvarName");
/*  62 */       p.defaultValue = tmpNode.attributeValue("defaultvalue");
/*  63 */       p.inOutType = tmpNode.attributeValue("inouttype");
/*  64 */       p.description = tmpNode.attributeValue("description");
/*  65 */       this.vars.add(p);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/*  70 */     Element result = XmlUtil.createElement(this.dealType, null);
/*  71 */     result.add(XmlUtil.createElement("runtype", this.runType));
/*  72 */     result.add(XmlUtil.createElement("servicename", this.serviceName));
/*  73 */     result.add(XmlUtil.createElement("runclassname", this.runClassName));
/*  74 */     result.add(XmlUtil.createElement("runfunctionname", this.runFunctionName));
/*     */     Iterator it;
/*  75 */     if (this.vars != null)
/*     */     {
/*  78 */       for (it = this.vars.iterator(); it.hasNext(); ) {
/*  79 */         Element e = result.addElement("vars");
/*  80 */         ParameterDefine p = (ParameterDefine)it.next();
/*  81 */         e.addAttribute("name", p.name);
/*  82 */         e.addAttribute("datatype", p.dataType);
/*  83 */         e.addAttribute("contextvarName", p.contextVarName);
/*  84 */         e.addAttribute("defaultvalue", p.defaultValue);
/*  85 */         e.addAttribute("inouttype", p.inOutType);
/*  86 */         e.addAttribute("description", p.description);
/*     */       }
/*     */     }
/*  89 */     return result;
/*     */   }
/*     */ 
/*     */   public String getDealType() {
/*  93 */     return this.dealType;
/*     */   }
/*     */ 
/*     */   public void setDealType(String value) {
/*  97 */     this.dealType = value;
/*     */   }
/*     */ 
/*     */   public String getRunType() {
/* 101 */     return this.runType;
/*     */   }
/*     */ 
/*     */   public void setRunType(String runType) {
/* 105 */     this.runType = runType;
/*     */   }
/*     */ 
/*     */   public String getServiceName() {
/* 109 */     this.serviceName = StringUtils.trim(this.serviceName);
/* 110 */     return this.serviceName;
/*     */   }
/*     */ 
/*     */   public void setServiceName(String serviceName) {
/* 114 */     this.serviceName = serviceName;
/*     */   }
/*     */ 
/*     */   public String getRunClassName() {
/* 118 */     return this.runClassName;
/*     */   }
/*     */ 
/*     */   public void setRunClassName(String value) {
/* 122 */     this.runClassName = value;
/*     */   }
/*     */ 
/*     */   public String getRunFunctionName() {
/* 126 */     return this.runFunctionName;
/*     */   }
/*     */ 
/*     */   public void setRunFunctionName(String value) {
/* 130 */     this.runFunctionName = value;
/*     */   }
/*     */ 
/*     */   public List getVars() {
/* 134 */     return this.vars;
/*     */   }
/*     */ 
/*     */   public void setVars(List value) {
/* 138 */     this.vars = value;
/*     */   }
/*     */ 
/*     */   public Class getRunClass() throws Exception {
/* 142 */     if (this.m_runClass == null)
/* 143 */       this.m_runClass = VMDataType.getJavaClass(getRunClassName());
/* 144 */     return this.m_runClass;
/*     */   }
/*     */ 
/*     */   public Method getRunFunction() throws Exception {
/* 148 */     if (this.m_runFunction == null) {
/* 149 */       ParameterDefine[] ps = getFunctionParameterDefine();
/* 150 */       Class[] pClasses = new Class[ps.length];
/* 151 */       for (int i = 0; i < pClasses.length; ++i) {
/* 152 */         pClasses[i] = ps[i].getDataTypeClass();
/*     */       }
/* 154 */       this.m_runFunction = this.m_runClass.getMethod(getRunFunctionName(), pClasses);
/*     */     }
/*     */ 
/* 157 */     return this.m_runFunction;
/*     */   }
/*     */   public ParameterDefine[] getFunctionParameterDefine() {
/* 160 */     List parameters = new ArrayList();
/*     */ 
/* 162 */     for (Iterator it = getVars().iterator(); it.hasNext(); ) {
/* 163 */       ParameterDefine p = (ParameterDefine)it.next();
/* 164 */       if (!"return".equalsIgnoreCase(p.inOutType));
/* 165 */       parameters.add(p);
/*     */     }
/*     */ 
/* 168 */     return (ParameterDefine[])(ParameterDefine[])parameters.toArray(new ParameterDefine[0]);
/*     */   }
/*     */ 
/*     */   public ParameterDefine getReturnParameterDefine()
/*     */   {
/* 173 */     for (Iterator it = getVars().iterator(); it.hasNext(); ) {
/* 174 */       ParameterDefine p = (ParameterDefine)it.next();
/* 175 */       if ("return".equalsIgnoreCase(p.inOutType) == true) {
/* 176 */         return p;
/*     */       }
/*     */     }
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */   public ParameterDefine getVars(String name) {
/* 183 */     if (name.equalsIgnoreCase("$WORKFLOW_ID")) {
/* 184 */       return ParameterDefine.S_WORKFLOW_ID;
/*     */     }
/* 186 */     if (name.equalsIgnoreCase("$TASK_ID")) {
/* 187 */       return ParameterDefine.S_TASK_ID;
/*     */     }
/*     */ 
/* 190 */     if (name.equalsIgnoreCase("$WORKFLOW_TAG")) {
/* 191 */       return ParameterDefine.S_WORKFLOW_TAG;
/*     */     }
/* 193 */     if (name.equalsIgnoreCase("$TASK_TAG")) {
/* 194 */       return ParameterDefine.S_TASK_TAG;
/*     */     }
/*     */ 
/* 198 */     if (name.equalsIgnoreCase("$QUEUE_ID")) {
/* 199 */       return ParameterDefine.S_QUEUE_ID;
/*     */     }
/* 201 */     if (name.equalsIgnoreCase("$IS_WAIT_USER")) {
/* 202 */       return ParameterDefine.S_USERTASK_IS_WAIT;
/*     */     }
/* 204 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_ID")) {
/* 205 */       return ParameterDefine.S_WORKFLOW_OBJ_ID;
/*     */     }
/* 207 */     if (name.equalsIgnoreCase("$WORKFLOW_OBJ_TYPE_ID")) {
/* 208 */       return ParameterDefine.S_WORKFLOW_OBJ_TYPE_ID;
/*     */     }
/* 210 */     if (name.equalsIgnoreCase("$TASK_EXCEPTION_CODE")) {
/* 211 */       return ParameterDefine.S_TASK_EXCEPTION_CODE;
/*     */     }
/* 213 */     if (name.equalsIgnoreCase("$TASK_EXCEPTION_MSG")) {
/* 214 */       return ParameterDefine.S_TASK_EXCEPTION_MSG;
/*     */     }
/* 216 */     for (int i = 0; i < this.vars.size(); ++i) {
/* 217 */       ParameterDefine p = (ParameterDefine)this.vars.get(i);
/* 218 */       if (p.name.equalsIgnoreCase(name))
/* 219 */         return p;
/*     */     }
/* 221 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskDealBean
 * JD-Core Version:    0.5.4
 */