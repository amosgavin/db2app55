/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.appframe2.util.XmlUtil;
/*    */ import com.ai.comframe.vm.template.RoleTemplate;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class RoleTemplateImpl
/*    */   implements RoleTemplate
/*    */ {
/* 10 */   protected String xmlTag = "role";
/*    */   private String label;
/*    */   private String uiInfo;
/*    */ 
/*    */   public RoleTemplateImpl(String label)
/*    */   {
/* 15 */     this.label = label;
/*    */   }
/*    */ 
/*    */   public RoleTemplateImpl(Element item) {
/* 19 */     this.label = item.attributeValue("label");
/* 20 */     Element e = item.element("uiinfo");
/* 21 */     if (e != null)
/* 22 */       this.uiInfo = e.getText();
/*    */   }
/*    */ 
/*    */   public String getLabel()
/*    */   {
/* 27 */     return this.label;
/*    */   }
/*    */ 
/*    */   public String getUIInfo() {
/* 31 */     return this.uiInfo;
/*    */   }
/*    */ 
/*    */   public void setLabel(String aLabel) {
/* 35 */     this.label = aLabel;
/*    */   }
/*    */ 
/*    */   public void setUIInfo(String aUIInfo) {
/* 39 */     this.uiInfo = aUIInfo;
/*    */   }
/*    */ 
/*    */   public Element getElement() {
/* 43 */     Element result = XmlUtil.createElement(this.xmlTag, null);
/* 44 */     result.addAttribute("label", this.label);
/*    */ 
/* 46 */     if (!StringUtils.isEmptyString(this.uiInfo)) {
/* 47 */       result.add(XmlUtil.createElement("uiinfo", this.uiInfo));
/*    */     }
/* 49 */     return result;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 53 */     return XmlUtil.formatElement(getElement());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.RoleTemplateImpl
 * JD-Core Version:    0.5.4
 */