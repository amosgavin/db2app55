package com.ai.comframe.vm.template;

import java.io.Writer;
import java.sql.Timestamp;

public abstract interface WorkflowTemplate extends TaskTemplate
{
  public static final String S_TYPE_WORKFLOW = "workflow";
  public static final String S_TYPE_PROCESS = "process";
  public static final String S_TYPE_PAGEFLOW = "pageflow";
  public static final String S_PROCESS_CLASS_POSTFIX = "AIProcess";
  public static final String S_JUGERESULT_CONTEXT_NAME = "_TASK_JUGE_RESULT";

  public abstract void setTaskType(String paramString);

  public abstract TaskTemplate[] getStartTaskTemplates();

  public abstract TaskTemplate[] getFinishTaskTemplates();

  public abstract JoinTemplate[] getJoinsByTaskA(TaskTemplate paramTaskTemplate);

  public abstract JoinTemplate[] getJoinsByTaskB(TaskTemplate paramTaskTemplate);

  public abstract TaskTemplate getTaskTemplate(long paramLong);

  public abstract boolean isBeforTask(long paramLong1, long paramLong2);

  public abstract long getMaxTaskTemplateId();

  public abstract TaskTemplate getEndLoopByLoop(TaskLoopTemplate paramTaskLoopTemplate);

  public abstract TaskTemplate getLoopByLoopEnd(TaskLoopEndTemplate paramTaskLoopEndTemplate);

  public abstract TaskTemplate[] getTaskTemplates();

  public abstract JoinTemplate[] getJoinTemplates();

  public abstract RoleTemplate[] getRoleTemplates();

  public abstract void deleteTaskTemplate(TaskTemplate paramTaskTemplate);

  public abstract void deleteJoinTemplate(JoinTemplate paramJoinTemplate);

  public abstract void deleteRoleTemplate(RoleTemplate paramRoleTemplate);

  public abstract JoinTemplate createJoinTemplate();

  public abstract TaskTemplate createTaskTemplate(String paramString1, String paramString2)
    throws Exception;

  public abstract RoleTemplate createRoleTemplate(String paramString);

  public abstract boolean isModify();

  public abstract void save(Writer paramWriter)
    throws Exception;

  public abstract TaskDealBean getExceptionDealBean();

  public abstract void setExceptionDealBean(TaskDealBean paramTaskDealBean);

  public abstract TaskDealBean getGetUserInfoDealBean();

  public abstract void setGetUserInfoDealBean(TaskDealBean paramTaskDealBean);

  public abstract Timestamp getValidDate();

  public abstract Timestamp getExpireDate();

  public abstract void setValidDate(Timestamp paramTimestamp);

  public abstract void setExpireDate(Timestamp paramTimestamp);

  public abstract TaskTemplate[] getUserTaskTemplates()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.WorkflowTemplate
 * JD-Core Version:    0.5.4
 */