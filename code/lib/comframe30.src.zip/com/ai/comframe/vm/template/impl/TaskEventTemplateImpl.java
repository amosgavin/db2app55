/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.common.ParameterDefine;
/*    */ import com.ai.comframe.vm.common.TaskConfig;
/*    */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*    */ import com.ai.comframe.vm.common.XmlUtil;
/*    */ import com.ai.comframe.vm.template.TaskEventTemplate;
/*    */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class TaskEventTemplateImpl extends TaskBaseTemplateImpl
/*    */   implements TaskEventTemplate
/*    */ {
/*    */   private String eventId;
/*    */   private String eventParameter;
/*    */ 
/*    */   public TaskEventTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*    */   {
/* 19 */     super(aWorkflowTemplate, item);
/* 20 */     this.eventId = item.elementText("eventid");
/* 21 */     this.eventParameter = item.elementText("eventparameter");
/*    */   }
/*    */ 
/*    */   public TaskEventTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type) {
/* 25 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*    */   }
/*    */ 
/*    */   public Element getElement() {
/* 29 */     Element result = super.getElement();
/* 30 */     result.add(XmlUtil.createElement("eventid", this.eventId));
/* 31 */     result.add(XmlUtil.createElement("eventparameter", this.eventParameter));
/* 32 */     return result;
/*    */   }
/*    */ 
/*    */   public void toJavaCode(StringBuffer buffer, int level) {
/* 36 */     if (StringUtils.isEmptyString(this.eventParameter)) {
/* 37 */       throw new RuntimeException(getTaskType() + ":(" + getLabel() + ")" + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskDecisionEndTemplateImpl.toJavaCode_nodeParamVarEmpty"));
/*    */     }
/* 39 */     String type = getWorkflowTemplate().getVars(this.eventParameter).dataType;
/* 40 */     if (DataType.isSimpleDataType(type) == true) {
/* 41 */       buffer.append("com.ai.appframe2.event.EventFactory.triggerEvent(\"" + this.eventId + "\",new " + DataType.getPrimitiveClass(type) + "(" + this.eventParameter + "));");
/*    */     }
/*    */     else
/* 44 */       buffer.append("com.ai.appframe2.event.EventFactory.triggerEvent(\"" + this.eventId + "\"," + this.eventParameter + ");");
/*    */   }
/*    */ 
/*    */   public String getEventId()
/*    */   {
/* 49 */     return this.eventId;
/*    */   }
/*    */   public String getEventParameter() {
/* 52 */     return this.eventParameter;
/*    */   }
/*    */   public void setEventId(String eventId) {
/* 55 */     this.eventId = eventId;
/*    */   }
/*    */   public void setEventParameter(String eventParameter) {
/* 58 */     this.eventParameter = eventParameter;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskEventTemplateImpl
 * JD-Core Version:    0.5.4
 */