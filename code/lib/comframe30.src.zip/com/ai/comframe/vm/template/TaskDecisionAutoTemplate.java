package com.ai.comframe.vm.template;

public abstract interface TaskDecisionAutoTemplate extends TaskAutoTemplate, TaskDecisionTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskDecisionAutoTemplate
 * JD-Core Version:    0.5.4
 */