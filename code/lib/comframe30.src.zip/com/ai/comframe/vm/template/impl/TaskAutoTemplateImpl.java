/*     */ package com.ai.comframe.vm.template.impl;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.common.TaskConfig;
/*     */ import com.ai.comframe.vm.common.TaskConfig.TaskConfigItem;
/*     */ import com.ai.comframe.vm.template.TaskAutoTemplate;
/*     */ import com.ai.comframe.vm.template.TaskDealBean;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class TaskAutoTemplateImpl extends TaskBaseTemplateImpl
/*     */   implements TaskAutoTemplate
/*     */ {
/*     */   TaskDealBean autoDealBean;
/*     */   TaskDealBean revertDealBean;
/*     */ 
/*     */   public TaskAutoTemplateImpl(WorkflowTemplate aWorkflowTemplate, Element item)
/*     */   {
/*  27 */     super(aWorkflowTemplate, item);
/*     */ 
/*  29 */     Element tmpNode = item.element("autodeal");
/*     */ 
/*  31 */     if (tmpNode != null) {
/*  32 */       this.autoDealBean = new TaskDealBean(tmpNode);
/*     */     }
/*     */     else
/*     */     {
/*  36 */       this.autoDealBean = new TaskDealBean("autodeal");
/*  37 */       this.autoDealBean.setRunType(item.elementText("runtype"));
/*  38 */       this.autoDealBean.setServiceName(item.elementText("servicename"));
/*  39 */       this.autoDealBean.setRunClassName(item.elementText("runclassname"));
/*  40 */       this.autoDealBean.setRunFunctionName(item.elementText("runfunctionname"));
/*  41 */       List vars = new ArrayList();
/*  42 */       vars.addAll(this.m_vars);
/*  43 */       this.autoDealBean.setVars(vars);
/*  44 */       this.m_vars.clear();
/*     */     }
/*     */ 
/*  47 */     tmpNode = item.element("revertdeal");
/*  48 */     if (tmpNode != null)
/*  49 */       this.revertDealBean = new TaskDealBean(tmpNode);
/*     */   }
/*     */ 
/*     */   public TaskAutoTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type)
/*     */   {
/*  56 */     super(aWorkflowTemplate, type, TaskConfig.getInstance().getTaskConfigItem(type).title);
/*     */   }
/*     */ 
/*     */   protected TaskAutoTemplateImpl(WorkflowTemplate aWorkflowTemplate, String type, String aLabel) {
/*  60 */     super(aWorkflowTemplate, type, aLabel);
/*     */   }
/*     */ 
/*     */   public Element getElement() {
/*  64 */     Element result = super.getElement();
/*  65 */     if ((this.autoDealBean != null) && (this.autoDealBean.getElement() != null))
/*  66 */       result.add(this.autoDealBean.getElement());
/*  67 */     if ((this.revertDealBean != null) && (this.revertDealBean.getElement() != null)) {
/*  68 */       result.add(this.revertDealBean.getElement());
/*     */     }
/*  70 */     return result;
/*     */   }
/*     */ 
/*     */   public TaskDealBean getAutoDealBean() {
/*  74 */     return this.autoDealBean;
/*     */   }
/*     */ 
/*     */   public void setAutoDealBean(TaskDealBean value) {
/*  78 */     this.autoDealBean = value;
/*     */   }
/*     */   public TaskDealBean getRevertDealBean() {
/*  81 */     return this.revertDealBean;
/*     */   }
/*     */ 
/*     */   public void setRevertDealBean(TaskDealBean value) {
/*  85 */     this.revertDealBean = value;
/*     */   }
/*     */ 
/*     */   public static String getFunctionJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, ParameterDefine[] parameters, ParameterDefine returnObj) {
/*  89 */     if ("service".equalsIgnoreCase(autoDealBean.getRunType()) == true) {
/*  90 */       return getServiceFunctionJavaRemark(taskTemplate, autoDealBean, parameters, returnObj);
/*     */     }
/*  92 */     return getPojoFunctionJavaRemark(taskTemplate, autoDealBean, parameters, returnObj);
/*     */   }
/*     */ 
/*     */   public static void toJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level)
/*     */   {
/*  98 */     if ("service".equalsIgnoreCase(autoDealBean.getRunType()) == true)
/*  99 */       toServiceJavaRemark(taskTemplate, autoDealBean, buffer, level);
/* 100 */     else if ("pojo".equalsIgnoreCase(autoDealBean.getRunType()) == true)
/* 101 */       toPojoJavaRemark(taskTemplate, autoDealBean, buffer, level);
/*     */   }
/*     */ 
/*     */   public void toJavaCode(StringBuffer buffer, int level)
/*     */   {
/* 106 */     toJavaCode(this, this.autoDealBean, buffer, level);
/*     */   }
/*     */   public static void toJavaCode(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level) {
/* 109 */     if (autoDealBean == null) {
/* 110 */       buffer.append("logger.warn(\"").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_setNode")).append(taskTemplate.getLabel()).append(")\");");
/*     */ 
/* 112 */       return;
/*     */     }
/*     */ 
/* 115 */     if ("service".equalsIgnoreCase(autoDealBean.getRunType()) == true)
/* 116 */       toServiceJavaCode(taskTemplate, autoDealBean, buffer, level);
/* 117 */     else if ("pojo".equalsIgnoreCase(autoDealBean.getRunType()) == true) {
/* 118 */       toPojoJavaCode(taskTemplate, autoDealBean, buffer, level);
/*     */     }
/*     */     else
/* 121 */       buffer.append("logger.warn(\"").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_setNode")).append(taskTemplate.getLabel()).append(")\");");
/*     */   }
/*     */ 
/*     */   public static String getPojoFunctionJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, ParameterDefine[] parameters, ParameterDefine returnObj)
/*     */   {
/* 127 */     String ss = "//";
/* 128 */     if (returnObj != null)
/* 129 */       ss = ss + returnObj.dataType;
/*     */     else {
/* 131 */       ss = ss + "void";
/*     */     }
/* 133 */     ss = ss + " " + autoDealBean.getRunClassName() + "::" + autoDealBean.getRunFunctionName() + "(";
/*     */ 
/* 135 */     for (int i = 0; i < parameters.length; ++i) {
/* 136 */       if (i > 0) ss = ss + ",";
/* 137 */       ss = ss + parameters[i].dataType;
/*     */     }
/* 139 */     ss = ss + ")";
/* 140 */     return ss;
/*     */   }
/*     */ 
/*     */   public static void toPojoJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level) {
/* 144 */     ParameterDefine[] parameters = autoDealBean.getFunctionParameterDefine();
/* 145 */     ParameterDefine returnObj = autoDealBean.getReturnParameterDefine();
/* 146 */     TaskNode.appendLevel(buffer, level);
/* 147 */     buffer.append(getFunctionJavaRemark(taskTemplate, autoDealBean, parameters, returnObj)).append("\n");
/*     */   }
/*     */ 
/*     */   public static void toPojoJavaCode(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level)
/*     */   {
/* 152 */     ParameterDefine[] parameters = autoDealBean.getFunctionParameterDefine();
/* 153 */     ParameterDefine returnObj = autoDealBean.getReturnParameterDefine();
/* 154 */     String functionStr = " new " + autoDealBean.getRunClassName() + "()." + autoDealBean.getRunFunctionName() + "(";
/* 155 */     for (int i = 0; i < parameters.length; ++i) {
/* 156 */       if (i > 0)
/* 157 */         functionStr = functionStr + ",";
/* 158 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 159 */         functionStr = functionStr + Process2JavaUtil.getVarTransferString(taskTemplate.getWorkflowTemplate().getVars(parameters[i].contextVarName).getDataTypeClass(), parameters[i].getDataTypeClass(), parameters[i].contextVarName);
/*     */       }
/*     */       else
/*     */       {
/* 164 */         functionStr = functionStr + Process2JavaUtil.getDefaultValueString(parameters[i].getDataTypeClass(), parameters[i].defaultValue);
/*     */       }
/*     */     }
/* 167 */     functionStr = functionStr + ")";
/* 168 */     if ((returnObj != null) && (!StringUtils.isEmptyString(returnObj.contextVarName))) {
/* 169 */       if (returnObj.contextVarName.equals("$CONTEXT_MAP")) {
/* 170 */         buffer.append(functionStr);
/* 171 */         buffer.append(";\nlogger.warn(\"process").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_notSupportSet")).append("$CONTEXT_MAP\");");
/*     */       }
/*     */       else {
/* 174 */         functionStr = returnObj.contextVarName + " = " + Process2JavaUtil.getVarTransferString(returnObj.getDataTypeClass(), taskTemplate.getWorkflowTemplate().getVars(returnObj.contextVarName).getDataTypeClass(), functionStr);
/*     */ 
/* 178 */         buffer.append(functionStr).append(";");
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/* 183 */       buffer.append(functionStr).append(";");
/*     */   }
/*     */ 
/*     */   public static String getServiceFunctionJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, ParameterDefine[] parameters, ParameterDefine returnObj)
/*     */   {
/* 189 */     String ss = "//";
/* 190 */     if (returnObj != null)
/* 191 */       ss = ss + returnObj.dataType;
/*     */     else {
/* 193 */       ss = ss + "void";
/*     */     }
/* 195 */     ss = ss + " " + autoDealBean.getServiceName() + "[interface:" + autoDealBean.getRunClassName() + "]" + "::" + autoDealBean.getRunFunctionName() + "(";
/*     */ 
/* 199 */     for (int i = 0; i < parameters.length; ++i) {
/* 200 */       if (i > 0) ss = ss + ",";
/* 201 */       ss = ss + parameters[i].dataType;
/*     */     }
/* 203 */     ss = ss + ")";
/* 204 */     return ss;
/*     */   }
/*     */ 
/*     */   public static void toServiceJavaRemark(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level) {
/* 208 */     ParameterDefine[] parameters = autoDealBean.getFunctionParameterDefine();
/* 209 */     ParameterDefine returnObj = autoDealBean.getReturnParameterDefine();
/* 210 */     TaskNode.appendLevel(buffer, level);
/* 211 */     buffer.append(getFunctionJavaRemark(taskTemplate, autoDealBean, parameters, returnObj)).append("\n");
/*     */   }
/*     */ 
/*     */   public static void toServiceJavaCode(TaskTemplate taskTemplate, TaskDealBean autoDealBean, StringBuffer buffer, int level)
/*     */   {
/* 216 */     ParameterDefine[] parameters = autoDealBean.getFunctionParameterDefine();
/* 217 */     ParameterDefine returnObj = autoDealBean.getReturnParameterDefine();
/*     */ 
/* 219 */     String functionStr = "((" + autoDealBean.getRunClassName() + ")com.ai.comframe.vm.common.ServiceUtil.getService(\"" + autoDealBean.getServiceName() + "\"," + autoDealBean.getRunClassName() + ".class))." + autoDealBean.getRunFunctionName() + "(";
/*     */ 
/* 223 */     for (int i = 0; i < parameters.length; ++i) {
/* 224 */       if (i > 0)
/* 225 */         functionStr = functionStr + ",";
/* 226 */       if (!StringUtils.isEmptyString(parameters[i].contextVarName)) {
/* 227 */         functionStr = functionStr + Process2JavaUtil.getVarTransferString(taskTemplate.getWorkflowTemplate().getVars(parameters[i].contextVarName).getDataTypeClass(), parameters[i].getDataTypeClass(), parameters[i].contextVarName);
/*     */       }
/*     */       else
/*     */       {
/* 236 */         functionStr = functionStr + Process2JavaUtil.getDefaultValueString(parameters[i].getDataTypeClass(), parameters[i].defaultValue);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 241 */     functionStr = functionStr + ")";
/* 242 */     if ((returnObj != null) && (!StringUtils.isEmptyString(returnObj.contextVarName))) {
/* 243 */       if (returnObj.contextVarName.equals("$CONTEXT_MAP")) {
/* 244 */         buffer.append(functionStr);
/* 245 */         buffer.append(";\nlogger.warn(\"process").append(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.template.impl.TaskAutoTemplateImpl.toJavaCode_notSupportSet")).append("$CONTEXT_MAP\");");
/*     */       }
/*     */       else {
/* 248 */         functionStr = returnObj.contextVarName + " = " + Process2JavaUtil.getVarTransferString(returnObj.getDataTypeClass(), taskTemplate.getWorkflowTemplate().getVars(returnObj.contextVarName).getDataTypeClass(), functionStr);
/*     */ 
/* 253 */         buffer.append(functionStr).append(";");
/*     */       }
/*     */     }
/*     */     else
/* 257 */       buffer.append(functionStr).append(";");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskAutoTemplateImpl
 * JD-Core Version:    0.5.4
 */