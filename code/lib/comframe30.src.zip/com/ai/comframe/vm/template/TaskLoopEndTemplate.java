package com.ai.comframe.vm.template;

public abstract interface TaskLoopEndTemplate extends TaskTemplate
{
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.TaskLoopEndTemplate
 * JD-Core Version:    0.5.4
 */