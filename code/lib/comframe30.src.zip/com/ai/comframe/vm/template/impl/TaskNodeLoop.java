/*    */ package com.ai.comframe.vm.template.impl;
/*    */ 
/*    */ import com.ai.comframe.vm.template.TaskTemplate;
/*    */ import java.util.List;
/*    */ 
/*    */ class TaskNodeLoop extends TaskNode
/*    */ {
/*    */   public TaskNodeLoop(TaskNode parent, TaskTemplate task)
/*    */   {
/* 74 */     super(parent, task);
/*    */   }
/*    */ 
/*    */   public void toJavaCode(StringBuffer buffer, int level)
/*    */   {
/* 79 */     appendLevel(buffer, level);
/* 80 */     buffer.append("while(");
/* 81 */     this.m_task.toJavaCode(buffer, level);
/* 82 */     buffer.append("){\n");
/* 83 */     for (int i = 0; i < this.m_child.size(); ++i) {
/* 84 */       ((TaskNode)this.m_child.get(i)).toJavaCode(buffer, level + 1);
/*    */     }
/* 86 */     appendLevel(buffer, level);
/* 87 */     buffer.append("}\n");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.template.impl.TaskNodeLoop
 * JD-Core Version:    0.5.4
 */