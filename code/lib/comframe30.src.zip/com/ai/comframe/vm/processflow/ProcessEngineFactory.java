/*    */ package com.ai.comframe.vm.processflow;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class ProcessEngineFactory
/*    */ {
/* 21 */   private static transient Log log = LogFactory.getLog(ProcessEngineFactory.class);
/*    */ 
/* 23 */   private static ProcessEngine m_instance = null;
/*    */ 
/* 25 */   private static Object LOCK = new Object();
/*    */ 
/*    */   public static ProcessEngine getProcessEngine()
/*    */   {
/* 32 */     if (m_instance == null) {
/* 33 */       synchronized (LOCK) {
/* 34 */         if (m_instance == null) {
/* 35 */           Class clazz = null;
/*    */           try {
/* 37 */             HashMap propertyMap = AIConfigManager.getConfigItemsByKind("AppFrameInit");
/* 38 */             String impl = (String)propertyMap.get("ProcessEngineImplClassName");
/* 39 */             if (!StringUtils.isBlank(impl))
/* 40 */               clazz = Class.forName(impl.trim());
/*    */           }
/*    */           catch (Throwable ex)
/*    */           {
/* 44 */             log.error("The implementation class loaded ProcessEngine problems", ex);
/*    */           }
/*    */ 
/* 47 */           if (clazz == null)
/* 48 */             m_instance = new ProcessEngineImpl();
/*    */           else {
/*    */             try
/*    */             {
/* 52 */               m_instance = (ProcessEngine)clazz.newInstance();
/*    */             }
/*    */             catch (Exception ex) {
/* 55 */               throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.getProcessEngine_problem"), ex);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 61 */     return m_instance;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.processflow.ProcessEngineFactory
 * JD-Core Version:    0.5.4
 */