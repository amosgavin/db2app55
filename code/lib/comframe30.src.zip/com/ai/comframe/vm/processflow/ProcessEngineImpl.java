/*     */ package com.ai.comframe.vm.processflow;
/*     */ 
/*     */ import com.ai.appframe2.common.AIClassLoader;
/*     */ import com.ai.appframe2.common.ClassLoaderUtil;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.client.Config;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.vm.common.ParameterDefine;
/*     */ import com.ai.comframe.vm.engine.FlowFactory;
/*     */ import com.ai.comframe.vm.engine.Processflow;
/*     */ import com.ai.comframe.vm.engine.WorkflowContext;
/*     */ import com.ai.comframe.vm.template.VMClassTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProcessEngineImpl
/*     */   implements ProcessEngine
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(ProcessEngineImpl.class);
/*  25 */   private static boolean isDebug = true;
/*     */ 
/*     */   public Map executeProcessInVM(String aQueueId, String processName, Map parameters)
/*     */     throws Exception
/*     */   {
/*  38 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  39 */     WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(processName);
/*     */ 
/*  41 */     Map tmpMap = new HashMap();
/*  42 */     for (Iterator it = template.getVars().iterator(); it.hasNext(); ) {
/*  43 */       ParameterDefine p = (ParameterDefine)it.next();
/*  44 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("in") == true) || (p.inOutType.equalsIgnoreCase("inout") == true))) && 
/*  45 */         (parameters.get(p.name) != null)) {
/*  46 */         tmpMap.put(p.name, parameters.get(p.name));
/*     */       }
/*     */     }
/*     */ 
/*  50 */     Processflow process = FlowFactory.createProcess(aQueueId, null, template, tmpMap);
/*  51 */     process.executeProcess();
/*     */ 
/*  54 */     for (Iterator it = template.getVars().iterator(); it.hasNext(); ) {
/*  55 */       ParameterDefine p = (ParameterDefine)it.next();
/*  56 */       if ((p.inOutType != null) && (((p.inOutType.equalsIgnoreCase("out") == true) || (p.inOutType.equalsIgnoreCase("inout") == true)))) {
/*  57 */         parameters.put(p.name, process.getWorkflowContext().get(p.name));
/*     */       }
/*     */     }
/*  60 */     return parameters;
/*     */   }
/*     */ 
/*     */   public Map executeProcess(String processName, Map parameters) throws Exception {
/*  64 */     if (isDebug == true) {
/*  65 */       removeCached(processName);
/*     */     }
/*  67 */     if (log.isDebugEnabled()) {
/*  68 */       Set set = parameters.keySet();
/*  69 */       String[] keys = (String[])(String[])set.toArray(new String[0]);
/*  70 */       StringBuffer sb = new StringBuffer();
/*  71 */       for (int i = 0; i < keys.length; ++i) {
/*  72 */         sb.append(keys[i]).append(": ").append(parameters.get(keys[i])).append("\n");
/*     */       }
/*  74 */       log.debug(processName + "Parameters:\n" + sb.toString());
/*     */     }
/*  76 */     Class processClass = loadProcessClass(processName);
/*  77 */     ProcessInstance instance = (ProcessInstance)processClass.newInstance();
/*  78 */     return instance.execute(parameters);
/*     */   }
/*     */ 
/*     */   public Map executeVMClass(String processName, String functionName, Map parameters) throws Exception {
/*  82 */     if (isDebug == true) {
/*  83 */       removeCached(processName);
/*     */     }
/*  85 */     Class processClass = loadVMClass(processName);
/*  86 */     Object instance = processClass.newInstance();
/*  87 */     Method m = processClass.getMethod(functionName, new Class[] { Map.class });
/*  88 */     return (Map)m.invoke(instance, new Object[] { parameters });
/*     */   }
/*     */ 
/*     */   public Object getVMClassInstance(String processName) throws Exception
/*     */   {
/*  93 */     if (isDebug == true) {
/*  94 */       removeCached(processName);
/*     */     }
/*  96 */     Class processClass = loadVMClass(processName);
/*  97 */     return processClass.newInstance();
/*     */   }
/*     */ 
/*     */   public String getProcessJavaCode(String processName) throws Exception {
/* 101 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 102 */     WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(processName);
/* 103 */     StringBuffer buffer = new StringBuffer();
/* 104 */     template.toJavaCode(buffer, 0);
/* 105 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public String getVMClassJavaCode(String vmClassName) throws Exception {
/* 109 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*     */ 
/* 111 */     VMClassTemplate template = templateSV.getVMClassTemplate(vmClassName);
/* 112 */     StringBuffer buffer = new StringBuffer();
/* 113 */     template.toJavaCode(buffer, 0);
/* 114 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public void removeCached(String processName)
/*     */   {
/* 119 */     AIClassLoader.clearCache();
/*     */   }
/*     */ 
/*     */   public Class loadProcessClass(String processName) throws ClassNotFoundException {
/* 123 */     String tmpClassName = processName + "_" + "AIProcess";
/* 124 */     Class clasz = ClassLoaderUtil.findLoadedClass(AIClassLoader.getInstance(), tmpClassName);
/* 125 */     if (clasz != null)
/* 126 */       return clasz;
/*     */     try {
/* 128 */       synchronized (this) {
/* 129 */         clasz = ClassLoaderUtil.findLoadedClass(AIClassLoader.getInstance(), tmpClassName);
/* 130 */         if (clasz != null)
/* 131 */           return clasz;
/* 132 */         ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 133 */         WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(processName);
/* 134 */         StringBuffer buffer = new StringBuffer();
/* 135 */         template.toJavaCode(buffer, 0);
/* 136 */         byte[] classData = ClassLoaderUtil.complieJavaCode(tmpClassName, buffer.toString());
/* 137 */         if (classData != null)
/* 138 */           clasz = AIClassLoader.getInstance().defineClassSelf(tmpClassName, classData, 0, classData.length);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 143 */       log.error(ex.getMessage(), ex);
/* 144 */       throw new ClassNotFoundException(ex.getMessage(), ex);
/*     */     }
/* 146 */     return clasz;
/*     */   }
/*     */ 
/*     */   public Class loadVMClass(String vmClassName) throws ClassNotFoundException
/*     */   {
/* 151 */     String tmpClassName = vmClassName + "_" + "AIProcess";
/* 152 */     Class clasz = ClassLoaderUtil.findLoadedClass(AIClassLoader.getInstance(), vmClassName);
/* 153 */     if (clasz != null)
/* 154 */       return clasz;
/*     */     try {
/* 156 */       synchronized (this) {
/* 157 */         clasz = ClassLoaderUtil.findLoadedClass(AIClassLoader.getInstance(), vmClassName);
/* 158 */         if (clasz != null)
/* 159 */           return clasz;
/* 160 */         ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 161 */         VMClassTemplate template = templateSV.getVMClassTemplate(vmClassName);
/* 162 */         StringBuffer buffer = new StringBuffer();
/* 163 */         template.toJavaCode(buffer, 0);
/* 164 */         byte[] classData = ClassLoaderUtil.complieJavaCode(tmpClassName, buffer.toString());
/*     */ 
/* 167 */         if (classData != null)
/* 168 */           clasz = AIClassLoader.getInstance().defineClassSelf(tmpClassName, classData, 0, classData.length);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 173 */       log.error(ex.getMessage(), ex);
/* 174 */       throw new ClassNotFoundException(ex.getMessage(), ex);
/*     */     }
/* 176 */     return clasz;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  29 */       String prop = Config.getProperty("process.debug");
/*  30 */       isDebug = Boolean.valueOf(prop).booleanValue();
/*     */     }
/*     */     catch (Exception e) {
/*  33 */       log.error("Failure to obtain ProcessEngine the debug state：" + e.getMessage());
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.processflow.ProcessEngineImpl
 * JD-Core Version:    0.5.4
 */