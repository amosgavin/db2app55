package com.ai.comframe.vm.processflow;

import java.util.Map;

public abstract interface ProcessEngine
{
  public abstract Map executeProcess(String paramString, Map paramMap)
    throws Exception;

  public abstract Map executeVMClass(String paramString1, String paramString2, Map paramMap)
    throws Exception;

  public abstract Map executeProcessInVM(String paramString1, String paramString2, Map paramMap)
    throws Exception;

  public abstract String getProcessJavaCode(String paramString)
    throws Exception;

  public abstract String getVMClassJavaCode(String paramString)
    throws Exception;

  public abstract Object getVMClassInstance(String paramString)
    throws Exception;

  public abstract void removeCached(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.processflow.ProcessEngine
 * JD-Core Version:    0.5.4
 */