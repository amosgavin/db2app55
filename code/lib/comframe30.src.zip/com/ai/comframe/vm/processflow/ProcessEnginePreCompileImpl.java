/*     */ package com.ai.comframe.vm.processflow;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import com.ai.comframe.vm.template.impl.WorkflowTemplateImpl;
/*     */ import java.io.InputStream;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class ProcessEnginePreCompileImpl
/*     */   implements ProcessEngine
/*     */ {
/*     */   public Map executeProcessInVM(String aQueueId, String processName, Map parameters)
/*     */     throws Exception
/*     */   {
/*  33 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "executeProcessInVM");
/*     */   }
/*     */ 
/*     */   public Map executeProcess(String processName, Map parameters)
/*     */     throws Exception
/*     */   {
/*  46 */     Class processClass = getProcessClass(processName);
/*  47 */     ProcessInstance instance = (ProcessInstance)processClass.newInstance();
/*  48 */     return instance.execute(parameters);
/*     */   }
/*     */ 
/*     */   public Map executeVMClass(String processName, String functionName, Map parameters)
/*     */     throws Exception
/*     */   {
/*  61 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "executeVMClass");
/*     */   }
/*     */ 
/*     */   public Object getVMClassInstance(String processName)
/*     */     throws Exception
/*     */   {
/*  74 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "getVMClassInstance");
/*     */   }
/*     */ 
/*     */   public String getProcessJavaCode(String processName)
/*     */   {
/*  86 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "getProcessJavaCode");
/*     */   }
/*     */ 
/*     */   public String getVMClassJavaCode(String vmClassName)
/*     */   {
/*  98 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "getVMClassJavaCode");
/*     */   }
/*     */ 
/*     */   public void removeCached(String processName)
/*     */   {
/* 108 */     throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.executeProcessInVM_notRealize") + "removeCached");
/*     */   }
/*     */ 
/*     */   public Class getProcessClass(String processName)
/*     */     throws ClassNotFoundException
/*     */   {
/* 119 */     String tmpClassName = processName + "_" + "AIProcess";
/* 120 */     return Class.forName(tmpClassName);
/*     */   }
/*     */ 
/*     */   public static String createPreJavaCodeByProcessName(String processName)
/*     */     throws Exception
/*     */   {
/* 131 */     String rtn = null;
/* 132 */     WorkflowTemplate template = getWorkflowTemplateFromFile(processName);
/* 133 */     if (template != null) {
/* 134 */       StringBuffer buffer = new StringBuffer();
/* 135 */       template.toJavaCode(buffer, 0);
/* 136 */       rtn = buffer.toString();
/*     */     }
/* 138 */     return rtn;
/*     */   }
/*     */ 
/*     */   private static WorkflowTemplate getWorkflowTemplateFromFile(String aWorkflowName)
/*     */   {
/* 147 */     String fileName = StringUtils.replace(aWorkflowName, ".", "/") + ".wvm";
/* 148 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/* 149 */     if (input == null) {
/* 150 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.appframe2.vm.processflow.ProcessEnginePreCompileImpl.getWorkflowTemplateFromFile_notLoadModel") + aWorkflowName);
/*     */     }
/* 152 */     return getWorkflowTemplate(aWorkflowName, -1L, input);
/*     */   }
/*     */ 
/*     */   private static WorkflowTemplate getWorkflowTemplate(String aWorkflowName, long templateId, InputStream input)
/*     */   {
/* 164 */     Element root = null;
/*     */     try {
/* 166 */       root = XmlUtil.parseXml(input);
/*     */     }
/*     */     catch (Exception ex) {
/* 169 */       throw new RuntimeException(ex);
/*     */     }
/*     */ 
/* 172 */     String taskType = root.attributeValue("tasktype");
/*     */ 
/* 174 */     WorkflowTemplate result = null;
/* 175 */     if (taskType.equalsIgnoreCase("process")) {
/* 176 */       result = new WorkflowTemplateImpl(aWorkflowName, null, root);
/* 177 */       result.setTaskTemplateId(templateId);
/*     */     }
/* 179 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getPackageByProcessName(String processName)
/*     */   {
/* 188 */     String rtn = null;
/* 189 */     String[] tmp = StringUtils.split(processName, ".");
/* 190 */     if (tmp.length == 1) {
/* 191 */       rtn = "";
/*     */     }
/*     */     else {
/* 194 */       String[] tmp2 = new String[tmp.length - 1];
/* 195 */       for (int i = 0; i < tmp2.length; ++i) {
/* 196 */         tmp2[i] = tmp[i];
/*     */       }
/* 198 */       rtn = StringUtils.join(tmp2, ".");
/*     */     }
/* 200 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static String getShortClassNameByProcessName(String processName)
/*     */   {
/* 209 */     String[] tmp = StringUtils.split(processName, ".");
/* 210 */     return tmp[(tmp.length - 1)];
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.processflow.ProcessEnginePreCompileImpl
 * JD-Core Version:    0.5.4
 */