package com.ai.comframe.vm.processflow;

import java.util.Map;

public abstract interface ProcessInstance
{
  public abstract Map execute(Map paramMap)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.processflow.ProcessInstance
 * JD-Core Version:    0.5.4
 */