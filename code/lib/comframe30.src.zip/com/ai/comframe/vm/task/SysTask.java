/*    */ package com.ai.comframe.vm.task;
/*    */ 
/*    */ import com.ai.comframe.utils.TimeUtil;
/*    */ import java.sql.Date;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class SysTask
/*    */ {
/*    */   public boolean isOverTime(Date data)
/*    */   {
/*    */     try
/*    */     {
/* 12 */       return data.before(new Date(TimeUtil.getSysTime().getTime()));
/*    */     }
/*    */     catch (Exception ex) {
/* 15 */       throw new RuntimeException();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.task.SysTask
 * JD-Core Version:    0.5.4
 */