/*    */ package com.ai.comframe.vm.task;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SendMail
/*    */ {
/*  6 */   private static transient Log log = LogFactory.getLog(SendMail.class);
/*    */ 
/*    */   public boolean send(String addr, String ccAddr, String subject, String body, String files)
/*    */   {
/* 10 */     log.debug("Send e-mail：" + subject);
/* 11 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.vm.task.SendMail
 * JD-Core Version:    0.5.4
 */