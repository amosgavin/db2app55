/*    */ package com.ai.comframe.cache;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.impl.AbstractCache;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*    */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmTemplateCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 13 */     ITemplateSV ts = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 14 */     IBOVmTemplateValue[] vmTemplates = ts.loadAllVmTemplate();
/* 15 */     HashMap map = new HashMap();
/* 16 */     if ((vmTemplates != null) && (vmTemplates.length > 0)) {
/* 17 */       for (int i = 0; i < vmTemplates.length; ++i) {
/* 18 */         String key = vmTemplates[i].getTemplateTag();
/* 19 */         map.put(key, vmTemplates[i]);
/*    */       }
/*    */     }
/* 22 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.cache.VmTemplateCacheImpl
 * JD-Core Version:    0.5.4
 */