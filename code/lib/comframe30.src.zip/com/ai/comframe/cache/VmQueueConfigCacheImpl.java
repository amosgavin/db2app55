/*    */ package com.ai.comframe.cache;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.impl.AbstractCache;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*    */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmQueueConfigCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 13 */     IVmQueueConfigSV vmConfigSV = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/* 14 */     IBOVmQueueConfigValue[] vmQueueConfigs = vmConfigSV.getAllVmQueueConfigs();
/* 15 */     HashMap data = new HashMap();
/* 16 */     if ((vmQueueConfigs != null) && (vmQueueConfigs.length > 0)) {
/* 17 */       for (int i = 0; i < vmQueueConfigs.length; ++i) {
/* 18 */         StringBuffer key = new StringBuffer();
/* 19 */         key.append(vmQueueConfigs[i].getQueueId()).append("|");
/* 20 */         key.append(vmQueueConfigs[i].getQueueType());
/* 21 */         data.put(key.toString(), vmQueueConfigs[i]);
/*    */       }
/*    */     }
/* 24 */     return data;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.cache.VmQueueConfigCacheImpl
 * JD-Core Version:    0.5.4
 */