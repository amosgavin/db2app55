/*    */ package com.ai.comframe.cache;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.impl.AbstractCache;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*    */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmAlarmConfigCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 13 */     IVmAlarmConfigSV alarm = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 14 */     IBOVmAlarmConfigValue[] alarms = alarm.loadAllVmAlarmConfigs();
/* 15 */     HashMap map = new HashMap();
/* 16 */     if ((alarms != null) && (alarms.length > 0)) {
/* 17 */       for (int i = 0; i < alarms.length; ++i) {
/* 18 */         String key = String.valueOf(alarms[i].getAlarmConfigId());
/* 19 */         map.put(key, alarms[i]);
/*    */       }
/*    */     }
/* 22 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.cache.VmAlarmConfigCacheImpl
 * JD-Core Version:    0.5.4
 */