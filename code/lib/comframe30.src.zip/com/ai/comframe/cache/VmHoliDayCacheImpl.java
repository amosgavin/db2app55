/*    */ package com.ai.comframe.cache;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.impl.AbstractCache;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmHoliDayValue;
/*    */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmHoliDayCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 13 */     IVmAlarmConfigSV alarm = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 14 */     IBOVmHoliDayValue[] holiday = alarm.loadAllHolidays();
/* 15 */     HashMap map = new HashMap();
/* 16 */     if ((holiday != null) && (holiday.length > 0)) {
/* 17 */       for (int i = 0; i < holiday.length; ++i) {
/* 18 */         String key = holiday[i].getHoliday().toString();
/* 19 */         map.put(key, holiday[i]);
/*    */       }
/*    */     }
/* 22 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.cache.VmHoliDayCacheImpl
 * JD-Core Version:    0.5.4
 */