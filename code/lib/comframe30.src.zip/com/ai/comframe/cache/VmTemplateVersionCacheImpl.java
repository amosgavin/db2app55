/*    */ package com.ai.comframe.cache;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.impl.AbstractCache;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmTemplateVersionValue;
/*    */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class VmTemplateVersionCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 31 */     ITemplateSV ts = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 32 */     IBOVmTemplateVersionValue[] versions = ts.loadAllVmTemplateVersion();
/* 33 */     HashMap map = new HashMap();
/* 34 */     if ((versions != null) && (versions.length > 0)) {
/* 35 */       for (int i = 0; i < versions.length; ++i) {
/* 36 */         String key = versions[i].getTemplateVersionId() + "|" + versions[i].getOrderNum();
/* 37 */         map.put(key, versions[i]);
/*    */       }
/*    */     }
/* 40 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.cache.VmTemplateVersionCacheImpl
 * JD-Core Version:    0.5.4
 */