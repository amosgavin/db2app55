/*    */ package com.ai.comframe;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.client.service.interfaces.IComframeCallBusiDefaultSV;
/*    */ import com.ai.comframe.client.service.interfaces.IComframeClientSV;
/*    */ 
/*    */ public class ComframeWorkflowFactory
/*    */ {
/*    */   public static IComframeClientSV getComframeClientInstance()
/*    */     throws Exception
/*    */   {
/* 24 */     return (IComframeClientSV)ServiceFactory.getService(IComframeClientSV.class);
/*    */   }
/*    */ 
/*    */   public static IComframeCallBusiDefaultSV getComframeCallBusiInstance() {
/* 28 */     return (IComframeCallBusiDefaultSV)ServiceFactory.getService(IComframeCallBusiDefaultSV.class);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.ComframeWorkflowFactory
 * JD-Core Version:    0.5.4
 */