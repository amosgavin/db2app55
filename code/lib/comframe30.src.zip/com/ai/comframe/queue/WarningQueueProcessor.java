/*    */ package com.ai.comframe.queue;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IVmWorkflowSV;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class WarningQueueProcessor
/*    */   implements IQueueProcessor
/*    */ {
/* 22 */   private static transient Log logger = LogFactory.getLog(WarningQueueProcessor.class);
/*    */ 
/*    */   public boolean execute(Object task) throws Exception {
/* 25 */     WarningTaskBean bean = (WarningTaskBean)task;
/*    */     try {
/* 27 */       IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 28 */       alarmConfigSV.warning(bean);
/* 29 */       return true;
/*    */     }
/*    */     catch (Throwable t) {
/* 32 */       logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.WarningQueueProcessor_warnException"), t);
/* 33 */       throw new Exception(t);
/*    */     }
/*    */   }
/*    */ 
/*    */   public List queryTask(String queueId, int mod, int value, int fetchNum) throws Exception
/*    */   {
/* 39 */     List tList = new ArrayList();
/* 40 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 41 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/*    */ 
/* 43 */     WarningTaskBean[] wfBeans = workflowSv.getWarningWorkflowData(queueId, mod, value, fetchNum);
/* 44 */     if ((wfBeans != null) && (wfBeans.length > 0)) {
/* 45 */       for (int i = 0; i < wfBeans.length; ++i) {
/* 46 */         tList.add(wfBeans[i]);
/*    */       }
/*    */     }
/* 49 */     WarningTaskBean[] taskBeans = taskSv.getWarningTaskData(queueId, mod, value, fetchNum);
/* 50 */     if ((taskBeans != null) && (taskBeans.length > 0)) {
/* 51 */       for (int i = 0; i < taskBeans.length; ++i)
/* 52 */         tList.add(taskBeans[i]);
/*    */     }
/* 54 */     WarningTaskBean[] taskTsBeans = taskSv.getWarningTaskTsData(queueId, mod, value, fetchNum);
/* 55 */     if ((taskTsBeans != null) && (taskTsBeans.length > 0))
/* 56 */       for (int i = 0; i < taskTsBeans.length; ++i)
/* 57 */         tList.add(taskTsBeans[i]);
/* 58 */     return tList;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 62 */     System.setProperty("comframe.dev.name", "dev");
/* 63 */     IVmWorkflowSV workflowSv = (IVmWorkflowSV)ServiceFactory.getService(IVmWorkflowSV.class);
/* 64 */     WarningTaskBean[] wfBeans = workflowSv.getWarningWorkflowData("dev", 10, 1, 100);
/* 65 */     if (wfBeans != null)
/* 66 */       logger.debug("wfBeans:" + wfBeans.length);
/* 67 */     ITaskSV taskSv = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 68 */     WarningTaskBean[] taskBeans = taskSv.getWarningTaskData("dev", 10, 0, 100);
/* 69 */     logger.debug("taskBeans:" + taskBeans.length);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.WarningQueueProcessor
 * JD-Core Version:    0.5.4
 */