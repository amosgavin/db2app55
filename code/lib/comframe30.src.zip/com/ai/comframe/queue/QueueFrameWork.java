/*     */ package com.ai.comframe.queue;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.center.interfaces.ICenter;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.PropertiesUtil;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class QueueFrameWork
/*     */ {
/*  26 */   private static final transient Log logger = LogFactory.getLog(QueueFrameWork.class);
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  35 */     if ((args == null) || (args.length == 0))
/*     */     {
/*  37 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_inputStartAttr"));
/*     */ 
/*  39 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueID"));
/*     */ 
/*  41 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueType"));
/*     */ 
/*  43 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_areaCode"));
/*     */ 
/*  45 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_mode"));
/*     */ 
/*  47 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_modValue"));
/*  48 */       System.out.println("Example：java com.ai.comframe.core.QueueFrameWork -q test -t workflow -r 571 -m 10 -v 0-2");
/*  49 */       System.exit(1);
/*     */     }
/*     */ 
/*  52 */     if (args.length % 2 != 0)
/*     */     {
/*  54 */       System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_startError"));
/*  55 */       System.exit(1);
/*     */     }
/*     */     try
/*     */     {
/*  59 */       QueueParam param = init(args);
/*     */ 
/*  62 */       start(param);
/*     */     }
/*     */     catch (Exception ex) {
/*  65 */       ex.printStackTrace();
/*  66 */       System.exit(1);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void start(QueueParam param) throws Exception
/*     */   {
/*  72 */     System.out.println(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_startAttr") + param.toString());
/*     */     try {
/*  74 */       IVmQueueConfigSV configSV = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/*  75 */       configSV.insertVMQueueServer(param);
/*     */     } catch (Throwable ex) {
/*  77 */       logger.error("insert vm_queue_server_regist error!", ex);
/*     */     }
/*     */ 
/*  80 */     if (StringUtils.contains(param.getModValue(), "-")) {
/*  81 */       String[] simple = StringUtils.split(param.getModValue(), "-");
/*  82 */       if ((simple == null) || (simple.length != 2))
/*     */       {
/*  84 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_style"));
/*     */       }
/*     */ 
/*  87 */       if ((!StringUtils.isNumeric(simple[0])) || (!StringUtils.isNumeric(simple[1])))
/*     */       {
/*  89 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_shouldBeNumber"));
/*     */       }
/*     */ 
/*  92 */       int intMod = param.getMod();
/*  93 */       int min = Integer.parseInt(simple[0]);
/*  94 */       int max = Integer.parseInt(simple[1]);
/*     */ 
/*  96 */       if (min < 0) {
/*  97 */         String[] pParams = new String[1];
/*  98 */         pParams[0] = String.valueOf(min);
/*     */ 
/* 100 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_largerThanZero", pParams));
/*     */       }
/*     */ 
/* 103 */       if (max >= intMod) {
/* 104 */         String[] pParams = new String[2];
/* 105 */         pParams[0] = String.valueOf(max);
/* 106 */         pParams[1] = String.valueOf(intMod);
/*     */ 
/* 108 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_valueRange", pParams));
/*     */       }
/*     */ 
/* 112 */       for (int j = min; j <= max; ++j) {
/* 113 */         QueueParam inParam = (QueueParam)BeanUtils.cloneBean(param);
/* 114 */         inParam.setModValue(String.valueOf(j));
/* 115 */         StringBuilder threadName = new StringBuilder("");
/* 116 */         threadName.append(inParam.getQueueType()).append("_grp[").append(inParam.getQueueId()).append(":").append((StringUtils.isBlank(inParam.getRegionId())) ? "-1" : inParam.getRegionId()).append(":").append(inParam.getMod()).append(":").append(j).append("]");
/*     */ 
/* 119 */         Thread thread = new Thread(new QueueGroupThread(inParam));
/* 120 */         thread.setName(threadName.toString());
/* 121 */         thread.start();
/*     */       }
/*     */     }
/*     */     else {
/* 125 */       StringBuilder threadName = new StringBuilder("");
/* 126 */       threadName.append(param.getQueueType()).append("_grp[").append(param.getQueueId()).append(":").append((StringUtils.isBlank(param.getRegionId())) ? "-1" : param.getRegionId()).append(":").append(param.getMod()).append(":").append(param.getModValue()).append("]");
/*     */ 
/* 129 */       Thread thread = new Thread(new QueueGroupThread(param));
/* 130 */       thread.setName(threadName.toString());
/* 131 */       thread.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static QueueParam init(String[] args)
/*     */     throws Exception
/*     */   {
/* 138 */     QueueParam queueParam = paramParser(args);
/*     */ 
/* 140 */     if (PropertiesUtil.isDev()) {
/* 141 */       String devName = PropertiesUtil.getDevId();
/*     */ 
/* 143 */       String[] pParam = new String[1];
/* 144 */       pParam[0] = "comframe.dev.name";
/* 145 */       if (StringUtils.isBlank(devName))
/* 146 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_devName", pParam));
/* 147 */       queueParam.setDevName(devName);
/*     */     }
/*     */ 
/* 151 */     if (StringUtils.isBlank(queueParam.getQueueId())) {
/* 152 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_inputQueueID"));
/*     */     }
/* 154 */     if (StringUtils.isBlank(queueParam.getQueueType())) {
/* 155 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_inputQueueType"));
/*     */     }
/* 157 */     if (queueParam.getMod() == 0) {
/* 158 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_AttrNotZero"));
/*     */     }
/*     */ 
/* 161 */     IVmQueueConfigSV configSv = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/* 162 */     IBOVmQueueConfigValue configValue = configSv.getVmQueueConfig(queueParam.getQueueId(), queueParam.getQueueType());
/*     */ 
/* 166 */     if ((configValue == null) || (configValue.isNew())) {
/* 167 */       String[] pParams = new String[2];
/* 168 */       pParams[0] = queueParam.getQueueId();
/* 169 */       pParams[1] = queueParam.getQueueType();
/* 170 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_notFindConfig", pParams));
/*     */     }
/*     */ 
/* 173 */     if ((StringUtils.isNotBlank(configValue.getSplitRegion())) && (configValue.getSplitRegion().equals("Y"))) {
/* 174 */       String[] Param = new String[1];
/* 175 */       Param[0] = queueParam.getQueueId();
/*     */ 
/* 177 */       if (StringUtils.isBlank(queueParam.getRegionId())) {
/* 178 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_inputRegion", Param));
/*     */       }
/*     */     }
/*     */ 
/* 182 */     if (StringUtils.isBlank(configValue.getDatasoure())) {
/* 183 */       String[] Param = new String[1];
/* 184 */       Param[0] = queueParam.getQueueId();
/*     */ 
/* 186 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_dataSourceEmpty", Param));
/*     */     }
/*     */ 
/* 189 */     ICenter center = PropertiesUtil.getCenterImpl();
/* 190 */     if (StringUtils.contains(configValue.getDatasoure(), "{CENTER}")) {
/* 191 */       String[] param = new String[1];
/* 192 */       param[0] = queueParam.getQueueId();
/* 193 */       if (StringUtils.isBlank(queueParam.getRegionId()))
/*     */       {
/* 196 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_inputCenterRegion", param));
/*     */       }
/* 198 */       if (center == null)
/*     */       {
/* 201 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_centerImpl", param));
/*     */       }
/*     */     }
/*     */ 
/* 205 */     if ((StringUtils.isNotBlank(queueParam.getRegionId())) && (center != null)) {
/* 206 */       CenterInfo centerInfo = center.getCenterByValue(queueParam.getRegionId());
/* 207 */       queueParam.setCenter(centerInfo.getCenter());
/*     */     }
/*     */ 
/* 211 */     return queueParam;
/*     */   }
/*     */ 
/*     */   private static QueueParam paramParser(String[] args)
/*     */     throws Exception
/*     */   {
/* 222 */     QueueParam queueParam = new QueueParam();
/* 223 */     for (int i = 0; i < args.length; ++i)
/*     */     {
/* 225 */       if (!args[i].startsWith("-")) {
/*     */         continue;
/*     */       }
/* 228 */       if ("-q".equalsIgnoreCase(args[i])) {
/* 229 */         if (i + 1 > args.length - 1)
/*     */         {
/* 231 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueIDError"));
/*     */         }
/* 233 */         queueParam.setQueueId(args[(i + 1)]);
/*     */       }
/*     */ 
/* 236 */       if ("-t".equalsIgnoreCase(args[i])) {
/* 237 */         if (i + 1 > args.length - 1)
/*     */         {
/* 239 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueTypeError"));
/*     */         }
/* 241 */         queueParam.setQueueType(args[(i + 1)]);
/*     */       }
/* 243 */       if ("-r".equalsIgnoreCase(args[i])) {
/* 244 */         if (i + 1 > args.length - 1)
/*     */         {
/* 246 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_areaCodeError"));
/*     */         }
/* 248 */         queueParam.setRegionId(args[(i + 1)]);
/*     */       }
/*     */ 
/* 251 */       if ("-m".equalsIgnoreCase(args[i])) {
/* 252 */         if (i + 1 > args.length - 1)
/*     */         {
/* 254 */           throw new Exception("-m" + ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_attrError"));
/*     */         }
/* 256 */         if (!StringUtils.isNumeric(args[(i + 1)]))
/*     */         {
/* 258 */           throw new Exception("-m" + ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_attrValueError"));
/*     */         }
/* 260 */         queueParam.setMod(Integer.parseInt(args[(i + 1)]));
/*     */       }
/* 262 */       if ("-v".equalsIgnoreCase(args[i])) {
/* 263 */         if (i + 1 > args.length - 1)
/*     */         {
/* 265 */           throw new Exception("-v" + ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_attrError"));
/*     */         }
/* 267 */         queueParam.setModValue(args[(i + 1)]);
/*     */       }
/*     */     }
/* 270 */     return queueParam;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.QueueFrameWork
 * JD-Core Version:    0.5.4
 */