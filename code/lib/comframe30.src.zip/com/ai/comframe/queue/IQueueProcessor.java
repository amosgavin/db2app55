package com.ai.comframe.queue;

import java.util.List;

public abstract interface IQueueProcessor
{
  public abstract List queryTask(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws Exception;

  public abstract boolean execute(Object paramObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.IQueueProcessor
 * JD-Core Version:    0.5.4
 */