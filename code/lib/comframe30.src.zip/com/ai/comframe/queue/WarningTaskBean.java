/*     */ package com.ai.comframe.queue;
/*     */ 
/*     */ public class WarningTaskBean
/*     */ {
/*     */   String taskId;
/*     */   String staffId;
/*     */   String stationId;
/*     */   String templateTag;
/*     */   String taskTag;
/*     */   long duration;
/*     */   int alarmtimes;
/*     */   String regionId;
/*     */   String type;
/*     */   String workflowObjId;
/*     */   String workflowObjTypeId;
/*     */ 
/*     */   public String getWorkflowObjId()
/*     */   {
/*  18 */     return this.workflowObjId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjId(String workflowObjId) {
/*  22 */     this.workflowObjId = workflowObjId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjTypeId() {
/*  26 */     return this.workflowObjTypeId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjTypeId(String workflowObjTypeId) {
/*  30 */     this.workflowObjTypeId = workflowObjTypeId;
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/*  34 */     return this.taskId;
/*     */   }
/*     */ 
/*     */   public void setTaskId(String taskId) {
/*  38 */     this.taskId = taskId;
/*     */   }
/*     */ 
/*     */   public String getStaffId() {
/*  42 */     return this.staffId;
/*     */   }
/*     */ 
/*     */   public void setStaffId(String staffId) {
/*  46 */     this.staffId = staffId;
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/*  50 */     return this.stationId;
/*     */   }
/*     */ 
/*     */   public void setStationId(String stationId) {
/*  54 */     this.stationId = stationId;
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/*  58 */     return this.templateTag;
/*     */   }
/*     */ 
/*     */   public void setTemplateTag(String templateTag) {
/*  62 */     this.templateTag = templateTag;
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/*  66 */     return this.taskTag;
/*     */   }
/*     */ 
/*     */   public void setTaskTag(String taskTag) {
/*  70 */     this.taskTag = taskTag;
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/*  74 */     return this.duration;
/*     */   }
/*     */ 
/*     */   public void setDuration(long duration) {
/*  78 */     this.duration = duration;
/*     */   }
/*     */ 
/*     */   public int getAlarmtimes() {
/*  82 */     return this.alarmtimes;
/*     */   }
/*     */ 
/*     */   public void setAlarmtimes(int alarmtimes) {
/*  86 */     this.alarmtimes = alarmtimes;
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/*  90 */     return this.regionId;
/*     */   }
/*     */ 
/*     */   public void setRegionId(String regionId) {
/*  94 */     this.regionId = regionId;
/*     */   }
/*     */ 
/*     */   public String getType() {
/*  98 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(String type) {
/* 102 */     this.type = type;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.WarningTaskBean
 * JD-Core Version:    0.5.4
 */