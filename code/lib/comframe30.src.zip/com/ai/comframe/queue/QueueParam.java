/*    */ package com.ai.comframe.queue;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class QueueParam
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 6760194799594630632L;
/*    */   String queueId;
/*    */   String queueType;
/*    */   String regionId;
/*    */   String center;
/*    */   int mod;
/*    */   String modValue;
/*    */   String devName;
/*    */   String execMethod;
/*    */ 
/*    */   public String getExecMethod()
/*    */   {
/* 34 */     return this.execMethod;
/*    */   }
/*    */ 
/*    */   public void setExecMethod(String execMethod) {
/* 38 */     this.execMethod = execMethod;
/*    */   }
/*    */ 
/*    */   public String getCenter() {
/* 42 */     return this.center;
/*    */   }
/*    */ 
/*    */   public void setCenter(String center) {
/* 46 */     this.center = center;
/*    */   }
/*    */ 
/*    */   public String getDevName() {
/* 50 */     return this.devName;
/*    */   }
/*    */ 
/*    */   public void setDevName(String devName) {
/* 54 */     this.devName = devName;
/*    */   }
/*    */ 
/*    */   public String getQueueId() {
/* 58 */     return this.queueId;
/*    */   }
/*    */ 
/*    */   public void setQueueId(String queueId) {
/* 62 */     this.queueId = queueId;
/*    */   }
/*    */ 
/*    */   public String getQueueType() {
/* 66 */     return this.queueType;
/*    */   }
/*    */ 
/*    */   public void setQueueType(String queueType) {
/* 70 */     this.queueType = queueType;
/*    */   }
/*    */ 
/*    */   public String getRegionId() {
/* 74 */     return this.regionId;
/*    */   }
/*    */ 
/*    */   public void setRegionId(String regionId) {
/* 78 */     this.regionId = regionId;
/*    */   }
/*    */ 
/*    */   public int getMod() {
/* 82 */     return this.mod;
/*    */   }
/*    */ 
/*    */   public void setMod(int mod) {
/* 86 */     this.mod = mod;
/*    */   }
/*    */ 
/*    */   public String getModValue() {
/* 90 */     return this.modValue;
/*    */   }
/*    */ 
/*    */   public void setModValue(String value) {
/* 94 */     this.modValue = value;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 98 */     return "queueId:" + getQueueId() + ",queueType:" + getQueueType() + ",regionId:" + getRegionId() + ",center:" + getCenter() + ",mod:" + getMod() + ",modValue:" + getModValue() + ",devName:" + getDevName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.QueueParam
 * JD-Core Version:    0.5.4
 */