/*    */ package com.ai.comframe.queue;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.vm.engine.Workflow;
/*    */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IVmScheduleSV;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class ExceptionQueueProcessor
/*    */   implements IQueueProcessor
/*    */ {
/* 25 */   private static transient Log logger = LogFactory.getLog(ExceptionQueueProcessor.class);
/*    */ 
/*    */   public boolean execute(Object task) throws Exception {
/* 28 */     IBOVmScheduleValue schedule = (IBOVmScheduleValue)task;
/* 29 */     IWorkflowEngineSV enginerSV = WorkflowEngineFactory.getInstance();
/* 30 */     Workflow workflow = null;
/*    */     try
/*    */     {
/* 33 */       workflow = enginerSV.getWorkflowForSchedule(schedule.getWorkflowId());
/* 34 */       enginerSV.executeExceptionWorkflow(workflow);
/* 35 */       return true;
/*    */     } catch (Exception ex) {
/* 37 */       logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.ExceptionQueueProcessor_exception"), ex);
/* 38 */       enginerSV.executeExceptionWfError(workflow, ex);
/* 39 */       throw ex;
/*    */     }
/*    */   }
/*    */ 
/*    */   public List queryTask(String queueId, int mod, int value, int fetchNum)
/*    */     throws Exception
/*    */   {
/* 46 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/* 47 */     IBOVmScheduleValue[] scheValues = scheduleSV.getVmScheduleData(queueId, null, mod, value, fetchNum, String.valueOf('A'));
/*    */ 
/* 50 */     List result = new ArrayList();
/* 51 */     if ((scheValues != null) && (scheValues.length > 0)) {
/* 52 */       for (int i = 0; i < scheValues.length; ++i) {
/* 53 */         result.add(scheValues[i]);
/*    */       }
/*    */     }
/* 56 */     if (logger.isDebugEnabled())
/* 57 */       logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.ExceptionQueueProcessor_getExceptionData") + result.size());
/* 58 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.ExceptionQueueProcessor
 * JD-Core Version:    0.5.4
 */