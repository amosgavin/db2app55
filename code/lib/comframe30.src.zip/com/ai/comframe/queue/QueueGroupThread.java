/*    */ package com.ai.comframe.queue;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class QueueGroupThread
/*    */   implements Runnable
/*    */ {
/* 16 */   private static transient Log logger = LogFactory.getLog(QueueGroupThread.class);
/*    */   QueueParam param;
/*    */ 
/*    */   QueueGroupThread(QueueParam _param)
/*    */   {
/* 20 */     this.param = _param;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 27 */       new QueueProcessFactory(this.param).process();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 31 */       logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueThreadStartFailed") + this.param.toString(), ex);
/* 32 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueFrameWork_queueThreadStartFailed"), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.QueueGroupThread
 * JD-Core Version:    0.5.4
 */