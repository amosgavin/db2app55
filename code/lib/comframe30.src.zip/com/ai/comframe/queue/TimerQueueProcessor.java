/*    */ package com.ai.comframe.queue;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import com.ai.comframe.utils.PropertiesUtil;
/*    */ import com.ai.comframe.vm.common.VMUtil;
/*    */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*    */ import com.ai.comframe.vm.workflow.ivalues.IBOVmDealTaskValue;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.ITaskSV;
/*    */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TimerQueueProcessor
/*    */   implements IQueueProcessor
/*    */ {
/* 23 */   private static transient Log logger = LogFactory.getLog(TimerQueueProcessor.class);
/*    */ 
/*    */   public boolean execute(Object task) throws Exception {
/* 26 */     IBOVmDealTaskValue taskVaule = (IBOVmDealTaskValue)task;
/* 27 */     String taskId = taskVaule.getTaskId();
/* 28 */     String workflowId = taskVaule.getWorkflowId();
/* 29 */     String dealType = taskVaule.getDealType();
/*    */     try
/*    */     {
/* 33 */       if ("TIMER".equalsIgnoreCase(dealType))
/*    */       {
/* 35 */         return WorkflowEngineFactory.getInstance().finishTimerTask(taskId);
/* 36 */       }if ("PRINT".equalsIgnoreCase(dealType))
/*    */       {
/* 38 */         return WorkflowEngineFactory.getInstance().printUserTaskBySystemAuto(taskId, null, null);
/* 39 */       }if ("OVERTIME".equalsIgnoreCase(dealType))
/*    */       {
/* 41 */         return WorkflowEngineFactory.getInstance().finishUserTaskOvertime(taskId, "-1");
/* 42 */       }if ("STARTTIME".equalsIgnoreCase(dealType))
/*    */       {
/* 44 */         return WorkflowEngineFactory.getInstance().finishTaskByStarttime(workflowId, taskId);
/*    */       }
/* 46 */       WorkflowEngineFactory.getInstance().dealTaskError(taskId, PropertiesUtil.getSystemUserId(), "NOT_FOUND_DEAL_TYPE", ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.TaskTimerScan.execute_task") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.TaskTimerScan.execute_undefinedDealType") + dealType);
/*    */ 
/* 54 */       return true;
/*    */     }
/*    */     catch (Exception e) {
/* 57 */       WorkflowEngineFactory.getInstance().dealTaskError(taskId, PropertiesUtil.getSystemUserId(), "TaskTimerScan.execute", ComframeLocaleFactory.getResource("com.ai.comframe.core.ScanTaskForOtherServer.dealWorkflow_dealTask") + taskId + ComframeLocaleFactory.getResource("com.ai.appframe2.vm.workflow.WorkflowEngineImpl.canExecuteTask_failed") + VMUtil.getErrorMessageFromException(e));
/*    */ 
/* 66 */       logger.error("Mission：" + taskId + "Failed：" + e.getMessage(), e);
/* 67 */     }return false;
/*    */   }
/*    */ 
/*    */   public List queryTask(String queueId, int mod, int value, int fetchNum)
/*    */     throws Exception
/*    */   {
/* 73 */     ITaskSV taskSV = (ITaskSV)ServiceFactory.getService(ITaskSV.class);
/* 74 */     IBOVmDealTaskValue[] tasks = taskSV.getVmDealTaskData(queueId, mod, value, fetchNum, 2);
/* 75 */     List result = new ArrayList();
/* 76 */     if ((tasks != null) && (tasks.length > 0)) {
/* 77 */       for (int i = 0; i < tasks.length; ++i) {
/* 78 */         result.add(tasks[i]);
/*    */       }
/*    */     }
/*    */ 
/* 82 */     if (logger.isDebugEnabled())
/* 83 */       logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.TimerQueueProcessor_getTimeTaskData") + result.size());
/* 84 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.TimerQueueProcessor
 * JD-Core Version:    0.5.4
 */