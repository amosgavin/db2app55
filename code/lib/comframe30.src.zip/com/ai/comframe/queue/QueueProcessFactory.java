/*     */ package com.ai.comframe.queue;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.DataSourceUtil;
/*     */ import com.ai.comframe.utils.WrapPropertiesUtil;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class QueueProcessFactory
/*     */ {
/*  25 */   private static transient Log logger = LogFactory.getLog(QueueProcessFactory.class);
/*     */   private QueueParam param;
/*     */   private IBOVmQueueConfigValue queueConfig;
/*     */   private IQueueProcessor processor;
/*     */ 
/*     */   public QueueProcessFactory(QueueParam _prarm)
/*     */     throws Exception
/*     */   {
/*  37 */     this.param = _prarm;
/*  38 */     initialize();
/*     */   }
/*     */ 
/*     */   private void initialize()
/*     */     throws Exception
/*     */   {
/*  48 */     if (this.param == null) {
/*  49 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_dealAttrEmpty"));
/*     */     }
/*  51 */     this.processor = getQueueProcessor(this.param.getQueueType());
/*     */ 
/*  53 */     if (this.processor == null) {
/*  54 */       String[] params = new String[1];
/*  55 */       params[0] = this.param.getQueueType();
/*  56 */       throw new RuntimeException(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_getImplFailed", params));
/*     */     }
/*     */ 
/*  59 */     IVmQueueConfigSV configsv = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/*  60 */     this.queueConfig = configsv.getVmQueueConfig(this.param.getQueueId(), this.param.getQueueType());
/*     */ 
/*  62 */     if (this.queueConfig == null) {
/*  63 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_queueConfigNotExist") + this.param.getQueueId() + ",queueType:" + this.param.getQueueType());
/*     */     }
/*     */ 
/*  66 */     if (StringUtils.isBlank(this.queueConfig.getDatasoure())) {
/*  67 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_queueDataSourceNotEmpty"));
/*     */     }
/*  69 */     if (StringUtils.isBlank(this.queueConfig.getSplitQueue())) {
/*  70 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_queueSplitEmpty"));
/*     */     }
/*  72 */     if (StringUtils.isBlank(this.queueConfig.getSplitRegion())) {
/*  73 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_regionSplitEmpty"));
/*     */     }
/*  75 */     if (this.queueConfig.getFetchNum() == 0)
/*  76 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_configCountEmpty"));
/*     */   }
/*     */ 
/*     */   public void process()
/*     */     throws Exception
/*     */   {
/*  87 */     if ("THREAD".equalsIgnoreCase(this.param.getExecMethod()))
/*     */     {
/*  89 */       if (logger.isDebugEnabled())
/*  90 */         logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_useThread"));
/*  91 */       processByThread();
/*     */     }
/*     */     else {
/*  94 */       if (logger.isDebugEnabled())
/*  95 */         logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_useProcess"));
/*  96 */       processDefault();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processDefault()
/*     */     throws Exception
/*     */   {
/* 107 */     if (StringUtils.isNotBlank(this.param.getRegionId()))
/* 108 */       CenterFactory.setDirectCenterInfo(new CenterInfo(this.param.getCenter(), this.param.getRegionId()));
/* 109 */     boolean isPushDataSource = false;
/*     */     try {
/* 111 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(this.param.getQueueId());
/*     */ 
/* 114 */       long workTime = 0L;
/* 115 */       if (StringUtils.isNotBlank(this.param.getRegionId()))
/* 116 */         CenterFactory.setDirectCenterInfo(new CenterInfo(this.param.getCenter(), this.param.getRegionId()));
/*     */       try {
/* 118 */         long start = System.currentTimeMillis();
/* 119 */         List queryList = this.processor.queryTask(this.param.getQueueId(), this.param.getMod(), Integer.parseInt(this.param.getModValue()), this.queueConfig.getFetchNum());
/*     */ 
/* 122 */         if ((queryList != null) && (queryList.size() > 0)) {
/* 123 */           for (int i = 0; i < queryList.size(); ++i) {
/*     */             try {
/* 125 */               this.processor.execute(queryList.get(i));
/*     */             } catch (Throwable ex) {
/* 127 */               logger.error("execute error!", ex);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 132 */         workTime = System.currentTimeMillis() - start;
/*     */ 
/* 134 */         if (logger.isDebugEnabled())
/* 135 */           logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_exeTime") + workTime);
/*     */       }
/*     */       catch (Throwable leftTime)
/*     */       {
/*     */         long leftTime;
/* 139 */         logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_exeError"), ex);
/*     */       }
/*     */       finally
/*     */       {
/*     */         long leftTime;
/* 141 */         long leftTime = this.queueConfig.getTimeInterval() - workTime;
/* 142 */         if (leftTime > 0L);
/*     */         try
/*     */         {
/* 148 */           Thread.currentThread(); Thread.sleep(leftTime);
/*     */         }
/*     */         catch (InterruptedException ex1) {
/* 151 */           logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_sleepError"), ex1);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 157 */       if (isPushDataSource == true)
/* 158 */         DataSourceUtil.popDataSource();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processByThread()
/*     */     throws Exception
/*     */   {
/* 169 */     throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.queue.QueueProcessFactory_threadExeNotRealize"));
/*     */   }
/*     */ 
/*     */   public IQueueProcessor getQueueProcessor(String queueType)
/*     */   {
/* 179 */     IQueueProcessor result = null;
/* 180 */     if ("workflow".equals(queueType))
/* 181 */       result = new WorkflowQueueProcessor();
/* 182 */     else if ("timer".equals(queueType))
/* 183 */       result = new TimerQueueProcessor();
/* 184 */     else if ("exception".equals(queueType))
/* 185 */       result = new ExceptionQueueProcessor();
/* 186 */     else if ("warning".equals(queueType))
/* 187 */       result = new WarningQueueProcessor();
/* 188 */     else if (("scanengine".equals(queueType)) || ("scanbusi".equals(queueType)))
/*     */     {
/* 190 */       result = getWrapQueueProcessor(queueType);
/*     */     }
/* 192 */     return result;
/*     */   }
/*     */ 
/*     */   private IQueueProcessor getWrapQueueProcessor(String queueType)
/*     */   {
/*     */     try
/*     */     {
/* 199 */       String className = WrapPropertiesUtil.getWrapQueueProcessor(queueType);
/*     */ 
/* 201 */       if (StringUtils.isBlank(className))
/* 202 */         throw new Exception("找不到商用流程引擎的队列实现类！");
/* 203 */       Object processorObj = Class.forName(className).newInstance();
/* 204 */       if (!processorObj instanceof IQueueProcessor)
/* 205 */         throw new Exception("配置商用流程引擎队列：" + queueType + ",处理类未实现IQueueProcessor接口！" + className);
/* 206 */       return (IQueueProcessor)processorObj;
/*     */     } catch (Throwable ex) {
/* 208 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.QueueProcessFactory
 * JD-Core Version:    0.5.4
 */