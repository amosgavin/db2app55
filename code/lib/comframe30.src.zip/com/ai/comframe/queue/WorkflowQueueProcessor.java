/*     */ package com.ai.comframe.queue;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.comframe.client.ComframeBusiException;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.engine.Workflow;
/*     */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*     */ import com.ai.comframe.vm.workflow.ivalues.IBOVmScheduleValue;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IVmScheduleSV;
/*     */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class WorkflowQueueProcessor
/*     */   implements IQueueProcessor
/*     */ {
/*  31 */   private static transient Log logger = LogFactory.getLog(WorkflowQueueProcessor.class);
/*     */ 
/*     */   public List queryTask(String queueId, int mod, int value, int fetchNum)
/*     */     throws Exception
/*     */   {
/*  41 */     IVmScheduleSV scheduleSV = (IVmScheduleSV)ServiceFactory.getService(IVmScheduleSV.class);
/*  42 */     IBOVmScheduleValue[] scheValues = scheduleSV.getVmScheduleData(queueId, "VM", mod, value, fetchNum, String.valueOf('W'));
/*     */ 
/*  45 */     List result = new ArrayList();
/*  46 */     if ((scheValues != null) && (scheValues.length > 0)) {
/*  47 */       for (int i = 0; i < scheValues.length; ++i) {
/*  48 */         result.add(scheValues[i]);
/*     */       }
/*     */     }
/*  51 */     if (logger.isDebugEnabled())
/*  52 */       logger.debug(ComframeLocaleFactory.getResource("com.ai.comframe.queue.WorkflowQueueProcessor_getWorkflowScheData") + result.size());
/*  53 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean execute(Object task)
/*     */     throws Exception
/*     */   {
/*  62 */     IBOVmScheduleValue schedule = (IBOVmScheduleValue)task;
/*  63 */     IWorkflowEngineSV enginerSV = WorkflowEngineFactory.getInstance();
/*     */ 
/*  65 */     String workflowId = schedule.getWorkflowId();
/*  66 */     Workflow workflow = null;
/*     */     try
/*     */     {
/*  70 */       workflow = enginerSV.getWorkflowForSchedule(workflowId);
/*  71 */       List finishTaskList = new ArrayList();
/*  72 */       if (logger.isDebugEnabled())
/*  73 */         logger.debug("Workflow instance： " + workflow.getWorkflowId() + " Scheduling begin");
/*     */       try
/*     */       {
/*  76 */         long start = System.currentTimeMillis();
/*     */ 
/*  78 */         if (4 == workflow.getState()) {
/*  79 */           IWorkflowEngineSV engineSV = (IWorkflowEngineSV)ServiceFactory.getService(IWorkflowEngineSV.class);
/*  80 */           engineSV.terminateWorkflowInQueue(workflow);
/*  81 */           int i = 1;
/*     */ 
/* 134 */           ServiceManager.setServiceUserInfo(null);
/* 135 */           return i;
/*     */         }
/*  84 */         UserInfoInterface userinfo = enginerSV.getWorkflowSysUserInfo(workflow);
/*  85 */         ServiceManager.setServiceUserInfo(userinfo);
/*     */         do
/*     */         {
/*     */           try
/*     */           {
/*  90 */             finishTaskList.clear();
/*     */ 
/*  92 */             finishTaskList = enginerSV.executeWorkflow(workflow);
/*     */           } catch (Throwable ex) {
/*  94 */             if (ex instanceof ComframeBusiException) {
/*  95 */               boolean addFinsh = enginerSV.busiExceptionProcess(workflowId, workflow, (ComframeBusiException)ex);
/*     */ 
/*  97 */               if (addFinsh)
/*  98 */                 finishTaskList.add(workflow.getNowScheduleTask());
/*     */               else
/* 100 */                 throw ex;
/*     */             } else {
/* 102 */               throw ex;
/*     */             }
/*     */           }
/* 105 */           if ((finishTaskList.size() <= 0) || (workflow.getState() == 3))
/*     */             continue;
/* 107 */           enginerSV.excuteFinishTask(workflow, finishTaskList);
/*     */         }
/* 109 */         while ((workflow.getCurrentTaskList().size() > 0) && (finishTaskList.size() > 0));
/*     */ 
/* 111 */         if (logger.isDebugEnabled())
/* 112 */           logger.debug("Workflow instance： " + workflow.getWorkflowId() + " Scheduling complete,time cost:" + (System.currentTimeMillis() - start));
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 116 */         enginerSV.taskExceptionProcess(workflowId, workflow, ex);
/*     */ 
/* 118 */         throw ex;
/*     */       }
/*     */ 
/* 121 */       enginerSV.endWorkflowSchedule(workflow);
/*     */ 
/* 124 */       if (logger.isDebugEnabled())
/* 125 */         logger.debug("Workflow instance： " + workflow.getWorkflowId() + " Scheduling End");
/*     */     }
/*     */     catch (Throwable ex) {
/* 128 */       logger.error(ComframeLocaleFactory.getResource("com.ai.comframe.queue.WorkflowQueueProcessor_workflowScheduleException") + workflowId, ex);
/*     */ 
/* 130 */       enginerSV.workflowExceptionProcess(workflowId, workflow, ex);
/* 131 */       ex = 0;
/*     */ 
/* 135 */       return ex;
/*     */     }
/*     */     finally
/*     */     {
/* 134 */       ServiceManager.setServiceUserInfo(null);
/*     */     }
/* 136 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.queue.WorkflowQueueProcessor
 * JD-Core Version:    0.5.4
 */