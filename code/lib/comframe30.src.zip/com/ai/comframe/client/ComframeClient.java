/*     */ package com.ai.comframe.client;
/*     */ 
/*     */ import com.ai.comframe.ComframeWorkflowFactory;
/*     */ import com.ai.comframe.client.service.interfaces.IComframeClientSV;
/*     */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ComframeClient
/*     */ {
/*     */   public static final String TASK_TYPE_START = "start";
/*     */   public static final String TASK_TYPE_AUTO = "auto";
/*     */   public static final String TASK_TYPE_AND = "and";
/*     */   public static final String TASK_TYPE_OR = "or";
/*     */   public static final String TASK_TYPE_TIMER = "timer";
/*     */   public static final String TASK_TYPE_DECISION = "decision";
/*     */   public static final String TASK_TYPE_AUTODECISION = "autodecision";
/*     */   public static final String TASK_TYPE_USER = "user";
/*     */   public static final String TASK_TYPE_FINISH = "finish";
/*     */   public static final String TASK_TYPE_WORKFLOW = "workflow";
/*     */   public static final String TASK_TYPE_SENDMAIL = "sendmail";
/*     */   public static final String TASK_TYPE_SIGN = "sign";
/*     */   public static final int S_STATE_DISABLED = 1;
/*     */   public static final int S_STATE_ENABLED = 2;
/*     */   public static final int S_STATE_FINISHED = 3;
/*     */   public static final int S_STATE_TERMINATE = 4;
/*     */   public static final int S_STATE_ACTIVE = 5;
/*     */   public static final int S_STATE_BACK = 6;
/*     */   public static final int S_STATE_WAIT = 7;
/*     */   public static final int S_STATE_EXPIRED = 8;
/*     */   public static final int S_STATE_WAIT_PRINT = 9;
/*     */   public static final int S_STATE_REAUTHORIZE = 10;
/*     */   public static final int S_STATE_ABEND = 11;
/*     */   public static final int S_STATE_BUSIEXCEPTION = 98;
/*     */   public static final int S_STATE_EXCEPTION = 99;
/*     */   public static final int S_STATE_WAIT_EXCEPTION_FINISH = 97;
/*     */   public static final String S_PARAM_NAMW_QUEUE_IDS = "$QUEUE_IDS$";
/*     */   public static final String S_PARAM_VALUE_BLANK = "$BLANK$";
/*     */   private static ComframeClient defaultClient;
/*     */ 
/*     */   /** @deprecated */
/*     */   public static ComframeClient getDefaultComframeClient()
/*     */     throws Exception
/*     */   {
/*  73 */     if (defaultClient == null) {
/*  74 */       synchronized (ComframeClient.class) {
/*  75 */         if (defaultClient == null) {
/*  76 */           defaultClient = new ComframeClient();
/*     */         }
/*     */       }
/*     */     }
/*  80 */     return defaultClient;
/*     */   }
/*     */ 
/*     */   private static IComframeClientSV getIComframeClient() throws Exception {
/*  84 */     return ComframeWorkflowFactory.getComframeClientInstance();
/*     */   }
/*     */ 
/*     */   public static String createWorkflow(String flowCode, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes)
/*     */     throws RemoteException, Exception
/*     */   {
/*  92 */     return getIComframeClient().createWorkflow(flowCode, staffId, objectTypeId, objectId, aVars, startTime, notes);
/*     */   }
/*     */ 
/*     */   public static String createWorkflow(String flowCode, String parentTaskId, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes)
/*     */     throws RemoteException, Exception
/*     */   {
/* 100 */     return getIComframeClient().createWorkflow(flowCode, parentTaskId, staffId, objectTypeId, objectId, aVars, startTime, notes);
/*     */   }
/*     */ 
/*     */   public static void cancelWorkflow(String workflowId, String staffId, String errorCode, String errorMessage)
/*     */     throws RemoteException, Exception
/*     */   {
/* 106 */     getIComframeClient().cancelWorkflow(workflowId, staffId, errorCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static void cancelWorkflow(String workflowId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage) throws RemoteException, Exception
/*     */   {
/* 111 */     getIComframeClient().cancelWorkflow(workflowId, staffId, errorCode, nextWorkflowCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static void cancelWorkflowByWorkflowObject(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String errorMessage) throws RemoteException, Exception
/*     */   {
/* 116 */     getIComframeClient().cancelWorkflowByWorkflowObject(queueID, objectTypeId, objectId, staffId, errorCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static void cancelWorkflow(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage) throws RemoteException, Exception
/*     */   {
/* 121 */     getIComframeClient().cancelWorkflow(queueID, objectTypeId, objectId, staffId, errorCode, nextWorkflowCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static String[] getWorkflowsByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 126 */     return getIComframeClient().getWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static String[] getWorkflowsHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 131 */     return getIComframeClient().getWorkflowsHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static String[] getWorkflowsHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 136 */     return getIComframeClient().getWorkflowsHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getRootWorkflowByWorkflowObjectId(String queueID, String objectTypeId, String objectId)
/*     */     throws RemoteException, Exception
/*     */   {
/* 142 */     return getIComframeClient().getRootWorkflowByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 147 */     return getIComframeClient().getRootWorkflowHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 152 */     return getIComframeClient().getRootWorkflowHisByWorkflowObjectId(queueID, acctPreiod, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static void stopWorkflow(String workflowId, String staffId, String reason)
/*     */     throws RemoteException, Exception
/*     */   {
/* 158 */     getIComframeClient().stopWorkflow(workflowId, staffId, reason);
/*     */   }
/*     */ 
/*     */   public static void stopWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason) throws RemoteException, Exception
/*     */   {
/* 163 */     getIComframeClient().stopWorkflow(queueID, workflowObjectType, workflowObjectId, staffId, reason);
/*     */   }
/*     */ 
/*     */   public static void resumeWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*     */   {
/* 168 */     getIComframeClient().resumeWorkflow(workflowId, staffId, reason);
/*     */   }
/*     */ 
/*     */   public static void resumeWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason) throws RemoteException, Exception
/*     */   {
/* 173 */     getIComframeClient().resumeWorkflow(queueID, workflowObjectType, workflowObjectId, staffId, reason);
/*     */   }
/*     */ 
/*     */   public static void terminateWorkflow(String workflowId, String staffId, String reason) throws RemoteException, Exception
/*     */   {
/* 178 */     getIComframeClient().terminateWorkflow(workflowId, staffId, reason);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void dropWorkflow(String workflowId) throws Exception
/*     */   {
/* 184 */     getIComframeClient().dropWorkflow(workflowId);
/*     */   }
/*     */ 
/*     */   public static boolean canExecuteTask(String taskId, long[] stations, String staffId) throws RemoteException, Exception
/*     */   {
/* 189 */     return getIComframeClient().canExecuteTask(taskId, stations, staffId);
/*     */   }
/*     */ 
/*     */   public static Map getWorkflowVars(String workflowId) throws RemoteException, Exception {
/* 193 */     return getIComframeClient().getWorkflowVars(workflowId);
/*     */   }
/*     */ 
/*     */   public static Map getChildWorkflowReturnVar(String workflowId, String aVarName) throws RemoteException, Exception {
/* 197 */     return getIComframeClient().getChildWorkflowReturnVar(workflowId, aVarName);
/*     */   }
/*     */ 
/*     */   public static void setWorkflowVars(String workflowId, HashMap aVars) throws RemoteException, Exception {
/* 201 */     getIComframeClient().setWorkflowVars(workflowId, aVars);
/*     */   }
/*     */ 
/*     */   public static String toSvg(String workflowId) throws RemoteException, Exception {
/* 205 */     return getIComframeClient().toSvg(workflowId);
/*     */   }
/*     */ 
/*     */   public static String toSvgHis(String workflowId, String acctPeriod) throws RemoteException, Exception {
/* 209 */     return getIComframeClient().toSvgHis(workflowId, acctPeriod);
/*     */   }
/*     */ 
/*     */   public static String toSvgByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 214 */     return getIComframeClient().toSvgByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static String toSvgHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 219 */     return getIComframeClient().toSvgHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static String toSvg(long templateId, String taskTag) throws Exception {
/* 223 */     return getIComframeClient().toSvg(templateId, taskTag);
/*     */   }
/*     */ 
/*     */   public static String toDojo(String workflowId) throws RemoteException, Exception {
/* 227 */     return getIComframeClient().toDojo(workflowId, "");
/*     */   }
/*     */ 
/*     */   public static String toDojoHis(String workflowId, String acctPeriod) throws RemoteException, Exception {
/* 231 */     return getIComframeClient().toDojoHis(workflowId, acctPeriod, "");
/*     */   }
/*     */ 
/*     */   public static String toDojoByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 236 */     return getIComframeClient().toDojoByWorkflowObjectId(queueID, objectTypeId, objectId, "");
/*     */   }
/*     */ 
/*     */   public static String toDojoHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 241 */     return getIComframeClient().toDojoHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId, "");
/*     */   }
/*     */ 
/*     */   public static String toDojo(long templateId, String taskTag) throws Exception {
/* 245 */     return getIComframeClient().toDojo(templateId, taskTag, "");
/*     */   }
/*     */ 
/*     */   public static String toDojo(String workflowId, String imagePath) throws RemoteException, Exception
/*     */   {
/* 250 */     return getIComframeClient().toDojo(workflowId, imagePath);
/*     */   }
/*     */ 
/*     */   public static String toDojoHis(String workflowId, String acctPeriod, String imagePath) throws RemoteException, Exception {
/* 254 */     return getIComframeClient().toDojoHis(workflowId, acctPeriod, imagePath);
/*     */   }
/*     */ 
/*     */   public static String toDojoByWorkflowObjectId(String queueID, String objectTypeId, String objectId, String imagePath) throws RemoteException, Exception
/*     */   {
/* 259 */     return getIComframeClient().toDojoByWorkflowObjectId(queueID, objectTypeId, objectId, imagePath);
/*     */   }
/*     */ 
/*     */   public static String toDojoHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId, String imagePath) throws RemoteException, Exception
/*     */   {
/* 264 */     return getIComframeClient().toDojoHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId, imagePath);
/*     */   }
/*     */ 
/*     */   public static String toDojo(long templateId, String taskTag, String imagePath) throws Exception {
/* 268 */     return getIComframeClient().toDojo(templateId, taskTag, imagePath);
/*     */   }
/*     */ 
/*     */   public static void lockTask(String taskId, String staffId) throws RemoteException, Exception {
/* 272 */     getIComframeClient().lockTask(taskId, staffId);
/*     */   }
/*     */ 
/*     */   public static void realseTask(String taskId) throws RemoteException, Exception {
/* 276 */     getIComframeClient().realseTask(taskId);
/*     */   }
/*     */ 
/*     */   public static boolean finishUserTask(String taskId, String staffId, String result, String reason, Map aVars) throws RemoteException, Exception
/*     */   {
/* 281 */     return getIComframeClient().finishUserTask(taskId, staffId, result, reason, aVars);
/*     */   }
/*     */ 
/*     */   public static boolean goBackToTask(String currentTaskId, String goBackTaskTag, String staffId, String reason, Map aVars) throws RemoteException, Exception
/*     */   {
/* 286 */     return getIComframeClient().goBackToTask(currentTaskId, goBackTaskTag, staffId, reason, aVars);
/*     */   }
/*     */ 
/*     */   public static boolean goBackToTask(String currentTaskId, Map vars, String staffId, String notes) throws RemoteException, Exception
/*     */   {
/* 291 */     return getIComframeClient().goBackToTask(currentTaskId, vars, staffId, notes);
/*     */   }
/*     */ 
/*     */   public static boolean goBackToTask(String currentTaskId, long goBackTaskTemplateId, String staffId, String reason, Map aVars) throws RemoteException, Exception
/*     */   {
/* 296 */     return getIComframeClient().goBackToTask(currentTaskId, goBackTaskTemplateId, staffId, reason, aVars);
/*     */   }
/*     */ 
/*     */   public static boolean jumpToTask(String taskId, long taskTemplateId, Map vars, String staffId, String notes)
/*     */     throws RemoteException, Exception
/*     */   {
/* 310 */     return getIComframeClient().jumpToTask(taskId, taskTemplateId, vars, staffId, notes);
/*     */   }
/*     */ 
/*     */   public static boolean printUserTask(String taskId, String staffId, Map aVars) throws RemoteException, Exception {
/* 314 */     return getIComframeClient().printUserTask(taskId, staffId, aVars);
/*     */   }
/*     */ 
/*     */   public static void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String errorMessage) throws Exception
/*     */   {
/* 319 */     getIComframeClient().fireWorkflowExceptionByTaskId(taskId, staffId, errorCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage) throws Exception
/*     */   {
/* 324 */     getIComframeClient().fireWorkflowExceptionByTaskId(taskId, staffId, errorCode, nextWorkflowCode, errorMessage);
/*     */   }
/*     */ 
/*     */   public static String reAuthorizeTask(String taskId, String authorizeStaffId, String authorizeStationId, String staffId) throws RemoteException, Exception
/*     */   {
/* 329 */     return getIComframeClient().reAuthorizeTask(taskId, authorizeStaffId, authorizeStationId, staffId);
/*     */   }
/*     */ 
/*     */   public static void resumeExceptionWorkflow(String workflowId) throws Exception {
/* 333 */     getIComframeClient().resumeExceptionWorkflow(workflowId);
/*     */   }
/*     */ 
/*     */   public static int resumeExceptionWorkflows(String queueID, String[] workflowIds) throws Exception {
/* 337 */     return getIComframeClient().resumeExceptionWorkflows(queueID, workflowIds);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByWorkflowId(String workflowId) throws RemoteException, Exception {
/* 341 */     return getIComframeClient().getTaskInfosByWorkflowId(workflowId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHisByWorkflowId(String workflowId) throws RemoteException, Exception {
/* 345 */     return getIComframeClient().getTaskInfosHisByWorkflowId(workflowId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHisByWorkflowId(String workflowId, String acctPeriod) throws RemoteException, Exception {
/* 349 */     return getIComframeClient().getTaskInfosHisByWorkflowId(workflowId, acctPeriod);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] getWorkflowInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 354 */     return getIComframeClient().getWorkflowInfos(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] getWorkflowInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 359 */     return getIComframeClient().getWorkflowInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] getWorkflowInfosHis(String queueID, String acctPeriod, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 364 */     return getIComframeClient().getWorkflowInfosHis(queueID, acctPeriod, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] getWorkflowHisInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 369 */     return getIComframeClient().getWorkflowInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo[] getWorkflowHisInfos(String queueID, String acctPeriod, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 374 */     return getIComframeClient().getWorkflowInfosHis(queueID, acctPeriod, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getWorkflowInfo(String workflowId) throws RemoteException, Exception {
/* 378 */     return getIComframeClient().getWorkflowInfo(workflowId);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getWorkflowInfoHis(String workflowId) throws RemoteException, Exception {
/* 382 */     return getIComframeClient().getWorkflowInfoHis(workflowId);
/*     */   }
/*     */ 
/*     */   public static WorkflowInfo getWorkflowInfoHis(String workflowId, String acctPeriod) throws RemoteException, Exception {
/* 386 */     return getIComframeClient().getWorkflowInfoHis(workflowId, acctPeriod);
/*     */   }
/*     */ 
/*     */   public static TaskInfo getRootInfo(String taskId) throws RemoteException, Exception
/*     */   {
/* 391 */     return getIComframeClient().getRootInfo(taskId);
/*     */   }
/*     */ 
/*     */   public static int getWorkflowCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/* 395 */     return getIComframeClient().getWorkflowCount(queueID, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static int getWorkflowHisCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/* 399 */     return getIComframeClient().getWorkflowHisCount(queueID, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static int getWorkflowHisCount(String queueID, String acctPeriod, String condition, HashMap parameter) throws RemoteException, Exception {
/* 403 */     return getIComframeClient().getWorkflowHisCount(queueID, acctPeriod, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByStationId(String queueID, long stationId, String workflowTemplateCode, String taskTag) throws RemoteException, Exception
/*     */   {
/* 408 */     return getIComframeClient().getTaskInfosByStationId(queueID, stationId, workflowTemplateCode, taskTag);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByStationId(String queueID, long[] stations, String workflowTemplateCode, String taskTag) throws RemoteException, Exception
/*     */   {
/* 413 */     return getIComframeClient().getTaskInfosByStationId(queueID, stations, workflowTemplateCode, taskTag);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByStationIdAndStaffId(String queueID, long[] stations, String staffId, String workflowTemplateCode, String taskTag) throws RemoteException, Exception
/*     */   {
/* 418 */     return getIComframeClient().getTaskInfosByStationIdAndStaffId(queueID, stations, staffId, workflowTemplateCode, taskTag);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 423 */     return getIComframeClient().getTaskInfosByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 428 */     return getIComframeClient().getTaskInfosHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception
/*     */   {
/* 433 */     return getIComframeClient().getTaskInfosHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 438 */     return getIComframeClient().getTaskInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosHis(String queueID, String acctPeriod, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 443 */     return getIComframeClient().getTaskInfosHis(queueID, acctPeriod, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static TaskInfo getTaskInfo(String taskId) throws RemoteException, Exception {
/* 447 */     return getIComframeClient().getTaskInfo(taskId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo getTaskInfoHis(String taskId) throws RemoteException, Exception {
/* 451 */     return getIComframeClient().getTaskInfoHis(taskId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo getTaskInfoHis(String taskId, String acctPeriod) throws RemoteException, Exception {
/* 455 */     return getIComframeClient().getTaskInfoHis(taskId, acctPeriod);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 460 */     return getIComframeClient().getTaskInfos(queueID, condition, parameter, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static int getTaskHisCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/* 464 */     return getIComframeClient().getTaskHisCount(queueID, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static int getTaskHisCount(String queueID, String acctPeriod, String condition, HashMap parameter) throws RemoteException, Exception {
/* 468 */     return getIComframeClient().getTaskHisCount(queueID, acctPeriod, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static int getTaskCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/* 472 */     return getIComframeClient().getTaskCount(queueID, condition, parameter);
/*     */   }
/*     */ 
/*     */   public static Map executeProcess(String processName, Map parameters) throws Exception, RemoteException {
/* 476 */     return getIComframeClient().executeProcess(processName, parameters);
/*     */   }
/*     */ 
/*     */   public static boolean isProcess(String templateCode) throws Exception, RemoteException {
/* 480 */     return getIComframeClient().isProcess(templateCode);
/*     */   }
/*     */ 
/*     */   public static boolean isWorkflow(String templateCode) throws Exception, RemoteException {
/* 484 */     return getIComframeClient().isWorkflow(templateCode);
/*     */   }
/*     */ 
/*     */   public static WorkflowTemplateInfo[] getWorkflowTemplates(String templateCode, String sValidDate, String eValidDate) throws Exception, RemoteException
/*     */   {
/* 489 */     return getIComframeClient().getWorkflowTemplates(templateCode, sValidDate, eValidDate);
/*     */   }
/*     */ 
/*     */   public static TaskTemplateInfo[] getUserTaskTemplates(long templateId, String templateCode) throws Exception, RemoteException
/*     */   {
/* 494 */     return getIComframeClient().getUserTaskTemplates(templateId, templateCode);
/*     */   }
/*     */ 
/*     */   public static TaskTemplateInfo[] getTaskTemplates(long templateId, String templateCode) throws Exception, RemoteException
/*     */   {
/* 499 */     return getIComframeClient().getTaskTemplates(templateId, templateCode);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTasksCanBeDragged(String queueID, String staffId) throws Exception {
/* 503 */     return getIComframeClient().getTasksCanBeDragged(queueID, staffId);
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfosByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue, int startIndex, int endIndex) throws RemoteException, Exception
/*     */   {
/* 508 */     return getIComframeClient().getTaskInfosByAttr(queueID, condition, parameter, attrCode, attrValue, startIndex, endIndex);
/*     */   }
/*     */ 
/*     */   public static int getTaskCountByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue) throws RemoteException, Exception
/*     */   {
/* 513 */     return getIComframeClient().getTaskCountByAttr(queueID, condition, parameter, attrCode, attrValue);
/*     */   }
/*     */ 
/*     */   public static VmWorkflowAttrInfo[] getVmWorkflowAttrsByWorkflowId(String workflowId) throws RemoteException, Exception
/*     */   {
/* 518 */     return getIComframeClient().getVmWorkflowAttrsByWorkflowId(workflowId);
/*     */   }
/*     */ 
/*     */   public static void updateWarning(String taskId, Timestamp date, int alarmTimes, String type) throws Exception, RemoteException
/*     */   {
/* 523 */     getIComframeClient().updateWarning(taskId, date, alarmTimes, type);
/*     */   }
/*     */ 
/*     */   public static void updateDuration(String taskId, int duration, String type) throws Exception, RemoteException {
/* 527 */     getIComframeClient().updateDuration(taskId, duration, type);
/*     */   }
/*     */ 
/*     */   public static String[][] getExceptionCode(String workflowObjectType, String currentWorkflowCode, String taskTag) throws Exception, RemoteException
/*     */   {
/* 532 */     return getIComframeClient().getExceptionCode(workflowObjectType, currentWorkflowCode, taskTag);
/*     */   }
/*     */ 
/*     */   public static void claimTask(String taskId, String staffId) throws RemoteException, Exception {
/* 536 */     getIComframeClient().claimTask(taskId, staffId);
/*     */   }
/*     */ 
/*     */   public static void unClaimTask(String taskId) throws RemoteException, Exception {
/* 540 */     getIComframeClient().unClaimTask(taskId);
/*     */   }
/*     */ 
/*     */   public static IBOVmAlarmConfigValue[] getAlarmConfig(String taskTag, String templateTag) throws Exception {
/* 544 */     return getIComframeClient().getAlarmConfig(taskTag, templateTag);
/*     */   }
/*     */ 
/*     */   public static IBOVmAlarmConfigValue[] getAlarmConfigs(String templateTag) throws Exception {
/* 548 */     return getIComframeClient().getAlarmConfigs(templateTag);
/*     */   }
/*     */ 
/*     */   public static Timestamp[] getHolidayList() throws Exception {
/* 552 */     return getIComframeClient().getHolidayList();
/*     */   }
/*     */ 
/*     */   public static TaskInfo[] getTaskInfos(String queueID, String stations, String staffId, String state, String orderId, int startIndex, int endIndex)
/*     */     throws Exception, RemoteException
/*     */   {
/* 558 */     return getIComframeClient().getTaskInfos(queueID, stations, staffId, state, orderId, startIndex, endIndex);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.ComframeClient
 * JD-Core Version:    0.5.4
 */