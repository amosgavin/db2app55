/*    */ package com.ai.comframe.client;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class WorkflowTemplateInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 3045512943780233661L;
/*    */   private long templateId;
/*    */   private String templateType;
/*    */   private String templateTag;
/*    */   private String label;
/*    */   private String createStaffId;
/*    */   private Timestamp createDate;
/*    */   private Timestamp validDate;
/*    */   private Timestamp expireDate;
/*    */   private String modifyDesc;
/*    */   private String content;
/*    */ 
/*    */   public String getContent()
/*    */   {
/* 21 */     return this.content;
/*    */   }
/*    */   public Timestamp getCreateDate() {
/* 24 */     return this.createDate;
/*    */   }
/*    */   public String getCreateStaffId() {
/* 27 */     return this.createStaffId;
/*    */   }
/*    */   public String getLabel() {
/* 30 */     return this.label;
/*    */   }
/*    */   public String getModifyDesc() {
/* 33 */     return this.modifyDesc;
/*    */   }
/*    */ 
/*    */   public Timestamp getValidDate() {
/* 37 */     return this.validDate;
/*    */   }
/*    */   public Timestamp getExpireDate() {
/* 40 */     return this.expireDate;
/*    */   }
/*    */ 
/*    */   public long getTemplateId() {
/* 44 */     return this.templateId;
/*    */   }
/*    */   public void setTemplateId(long templateId) {
/* 47 */     this.templateId = templateId;
/*    */   }
/*    */ 
/*    */   public String getTemplateType() {
/* 51 */     return this.templateType;
/*    */   }
/*    */   public void setTemplateType(String templateType) {
/* 54 */     this.templateType = templateType;
/*    */   }
/*    */   public String getTemplateTag() {
/* 57 */     return this.templateTag;
/*    */   }
/*    */   public void setTemplateTag(String templateTag) {
/* 60 */     this.templateTag = templateTag;
/*    */   }
/*    */   public void setModifyDesc(String modifyDesc) {
/* 63 */     this.modifyDesc = modifyDesc;
/*    */   }
/*    */   public void setLabel(String label) {
/* 66 */     this.label = label;
/*    */   }
/*    */   public void setCreateStaffId(String createStaffId) {
/* 69 */     this.createStaffId = createStaffId;
/*    */   }
/*    */   public void setCreateDate(Timestamp createDate) {
/* 72 */     this.createDate = createDate;
/*    */   }
/*    */   public void setContent(String content) {
/* 75 */     this.content = content;
/*    */   }
/*    */   public void setValidDate(Timestamp date) {
/* 78 */     this.validDate = date;
/*    */   }
/*    */   public void setExpireDate(Timestamp date) {
/* 81 */     this.expireDate = date;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.WorkflowTemplateInfo
 * JD-Core Version:    0.5.4
 */