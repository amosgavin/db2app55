/*     */ package com.ai.comframe.client.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.client.service.interfaces.IComframeCallBusiDefaultSV;
/*     */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.utils.TimeUtil;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ComframeCallBusiDefaultSVImpl
/*     */   implements IComframeCallBusiDefaultSV
/*     */ {
/*  28 */   private static transient Log log = LogFactory.getLog(ComframeCallBusiDefaultSVImpl.class);
/*     */ 
/*  30 */   private static final String msg = ComframeLocaleFactory.getResource("com.ai.comframe.client.ComframeCallBusiDefault.msg_unRealizeMethod");
/*     */ 
/*     */   public String getStationIdByStationTypeIdAndOrgId(String stationTypeId, String organizeId) throws Exception {
/*  33 */     throw new Exception(msg);
/*     */   }
/*     */ 
/*     */   public int getDurationDefault(long templateId, String templateTag, String taskTag, String workflowObjId, String workflowObjTypeId) throws Exception, RemoteException {
/*  37 */     return 1;
/*     */   }
/*     */ 
/*     */   public Timestamp getAlarmTimeDefault(long templateId, String templateTag, String taskTag, String workflowObjId, String workflowObjTypeId, int duration, int alarmtimes, int isHoliday)
/*     */     throws Exception, RemoteException
/*     */   {
/*  43 */     if (StringUtils.isEmptyString(templateTag)) {
/*  44 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.client.ComframeCallBusiDefault.getAlarmTimeDefault_templateCodeNull"));
/*     */     }
/*     */ 
/*  47 */     Timestamp currentTime = TimeUtil.getSysTime();
/*  48 */     if (duration <= 0) {
/*  49 */       return null;
/*     */     }
/*  51 */     if (alarmtimes > 1) {
/*  52 */       duration = 1;
/*     */     }
/*     */ 
/*  56 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/*  57 */     Date[] holidayList = alarmConfigSV.getHolidayList();
/*     */ 
/*  60 */     long dNum = 0L;
/*  61 */     Calendar currentCalendar = Calendar.getInstance();
/*  62 */     Calendar calendar = null;
/*  63 */     currentCalendar.setTime(currentTime);
/*     */ 
/*  65 */     if (isHoliday == 1) {
/*  66 */       for (int i = 0; i < holidayList.length; ++i) {
/*  67 */         Date holiday = null;
/*     */ 
/*  69 */         holiday = holidayList[i];
/*     */ 
/*  71 */         Calendar holidayCalendarFrom = Calendar.getInstance();
/*  72 */         holidayCalendarFrom.setTime(holiday);
/*  73 */         holidayCalendarFrom.set(12, 0);
/*  74 */         holidayCalendarFrom.set(13, 0);
/*  75 */         holidayCalendarFrom.set(11, 0);
/*  76 */         Calendar holidayCalendarTo = (Calendar)holidayCalendarFrom.clone();
/*  77 */         holidayCalendarTo.add(5, 1);
/*  78 */         if ((holidayCalendarFrom.before(currentCalendar)) && (holidayCalendarTo.after(currentCalendar))) {
/*  79 */           currentCalendar.add(5, 1);
/*  80 */           currentCalendar.set(11, 0);
/*  81 */           currentCalendar.set(12, 0);
/*  82 */           currentCalendar.set(13, 0);
/*  83 */           currentCalendar.set(14, 1);
/*     */         }
/*     */       }
/*     */     }
/*  87 */     long dura = duration;
/*  88 */     dNum = dura * 1000L * 60L * 60L * 24L;
/*  89 */     long cTime = currentCalendar.getTimeInMillis() + dNum;
/*  90 */     calendar = Calendar.getInstance();
/*  91 */     calendar.setTimeInMillis(cTime);
/*     */ 
/*  93 */     if (isHoliday == 1) {
/*  94 */       Calendar[][] cas = new Calendar[holidayList.length][2];
/*  95 */       for (int i = 0; i < holidayList.length; ++i) {
/*  96 */         Date holiday = null;
/*     */ 
/*  98 */         holiday = holidayList[i];
/*     */ 
/* 100 */         Calendar holidayCalendarFrom = Calendar.getInstance();
/* 101 */         holidayCalendarFrom.setTime(holiday);
/* 102 */         holidayCalendarFrom.set(12, 0);
/* 103 */         holidayCalendarFrom.set(13, 0);
/* 104 */         holidayCalendarFrom.set(11, 0);
/* 105 */         Calendar holidayCalendarTo = (Calendar)holidayCalendarFrom.clone();
/* 106 */         holidayCalendarTo.add(5, 1);
/* 107 */         cas[i][0] = holidayCalendarFrom;
/* 108 */         cas[i][1] = holidayCalendarTo;
/*     */       }
/*     */ 
/* 111 */       for (int i = 0; i < cas.length; ++i) {
/* 112 */         Calendar holidayCalendarFrom = cas[i][0];
/* 113 */         Calendar holidayCalendarTo = cas[i][1];
/* 114 */         if ((holidayCalendarFrom.before(calendar)) && (holidayCalendarTo.after(currentCalendar)) && (holidayCalendarFrom.after(currentCalendar))) {
/* 115 */           calendar.add(5, 1);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 120 */       boolean resultIsHoliday = false;
/* 121 */       for (int i = 0; i < cas.length; ++i) {
/* 122 */         Calendar holidayCalendarFrom = cas[i][0];
/* 123 */         Calendar holidayCalendarTo = cas[i][1];
/* 124 */         if ((calendar.after(holidayCalendarFrom)) && (calendar.before(holidayCalendarTo))) {
/* 125 */           resultIsHoliday = true;
/*     */         }
/*     */       }
/* 128 */       while (resultIsHoliday) {
/* 129 */         resultIsHoliday = false;
/* 130 */         calendar.add(5, 1);
/* 131 */         for (int i = 0; i < cas.length; ++i) {
/* 132 */           Calendar holidayCalendarFrom = cas[i][0];
/* 133 */           Calendar holidayCalendarTo = cas[i][1];
/* 134 */           if ((calendar.after(holidayCalendarFrom)) && (calendar.before(holidayCalendarTo))) {
/* 135 */             resultIsHoliday = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 140 */     Timestamp a = new Timestamp(calendar.getTimeInMillis());
/*     */ 
/* 142 */     Calendar tempcalendar = Calendar.getInstance();
/* 143 */     tempcalendar.setTimeInMillis(a.getTime());
/* 144 */     tempcalendar.set(12, 0);
/* 145 */     tempcalendar.set(13, 0);
/* 146 */     tempcalendar.set(11, 12);
/* 147 */     return new Timestamp(tempcalendar.getTimeInMillis());
/*     */   }
/*     */ 
/*     */   public void alarmDealDefault(long templateId, String templateTag, String taskTag, String staffId, String stationId, String workflowObjId, String workflowObjTypeId, int alarmTimes) throws Exception, RemoteException {
/* 151 */     log.info("Corresponding template ID：[" + templateId + "]，Template code：[" + templateTag + "]，Task code：[" + taskTag + "]Workflow instance need alarms. ID for the task processing personnel：[" + staffId + "],Post is：[" + stationId + "]。" + "Workflow processing object number：[" + workflowObjId + "]Workflow processing object type：[" + workflowObjTypeId + "]。");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.service.impl.ComframeCallBusiDefaultSVImpl
 * JD-Core Version:    0.5.4
 */