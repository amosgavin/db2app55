package com.ai.comframe.client.service.interfaces;

import com.ai.comframe.client.TaskInfo;
import com.ai.comframe.client.TaskTemplateInfo;
import com.ai.comframe.client.VmWorkflowAttrInfo;
import com.ai.comframe.client.WorkflowInfo;
import com.ai.comframe.client.WorkflowTemplateInfo;
import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

public abstract interface IComframeClientSV
{
  public static final String S_TYPE_STAFF = "staff";
  public static final String S_TYPE_STATION = "station";
  public static final String S_TYPE_STATION_TYPE = "stationType";
  public static final int WORKFLOW_TYPE_CHILDWORKFLOW = 1;
  public static final int WORKFLOW_TYPE_EXCEPTIONWORKFLOW = 2;

  public abstract String createWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap, Timestamp paramTimestamp, String paramString5)
    throws RemoteException, Exception;

  public abstract String createWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, Map paramMap, Timestamp paramTimestamp, String paramString6)
    throws RemoteException, Exception;

  public abstract String createWorkflow(String paramString1, String paramString2, String paramString3, int paramInt, String paramString4, String paramString5, String paramString6, Map paramMap)
    throws Exception;

  public abstract void cancelWorkflow(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract void cancelWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract void cancelWorkflowByWorkflowObject(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws RemoteException, Exception;

  public abstract void cancelWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
    throws RemoteException, Exception;

  public abstract String[] getWorkflowsByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String[] getWorkflowsHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String[] getWorkflowsHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getRootWorkflowByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract void stopWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void stopWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract void resumeWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void resumeWorkflow(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract void terminateWorkflow(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract void dropWorkflow(String paramString)
    throws Exception;

  public abstract boolean canExecuteTask(String paramString1, long[] paramArrayOfLong, String paramString2)
    throws RemoteException, Exception;

  public abstract Map getWorkflowVars(String paramString)
    throws RemoteException, Exception;

  public abstract Map getChildWorkflowReturnVar(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract void setWorkflowVars(String paramString, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract String toSvg(String paramString)
    throws RemoteException, Exception;

  public abstract String toSvgHis(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract String toSvgByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String toSvgHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract String toSvg(long paramLong, String paramString)
    throws RemoteException, Exception;

  public abstract String toDojo(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract String toDojoHis(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract String toDojoByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract String toDojoHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws RemoteException, Exception;

  public abstract String toDojo(long paramLong, String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract void lockTask(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract void realseTask(String paramString)
    throws RemoteException, Exception;

  public abstract boolean finishUserTask(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean goBackToTask(String paramString1, String paramString2, String paramString3, String paramString4, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean goBackToTask(String paramString1, long paramLong, String paramString2, String paramString3, Map paramMap)
    throws RemoteException, Exception;

  public abstract boolean goBackToTask(String paramString1, Map paramMap, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract boolean jumpToTask(String paramString1, long paramLong, Map paramMap, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract boolean printUserTask(String paramString1, String paramString2, Map paramMap)
    throws RemoteException, Exception;

  public abstract void fireWorkflowExceptionByTaskId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;

  public abstract void fireWorkflowExceptionByTaskId(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws Exception;

  public abstract String reAuthorizeTask(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract void resumeExceptionWorkflow(String paramString)
    throws Exception;

  public abstract int resumeExceptionWorkflows(String paramString, String[] paramArrayOfString)
    throws Exception;

  public abstract TaskInfo[] getTaskInfosByWorkflowId(String paramString)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHisByWorkflowId(String paramString)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHisByWorkflowId(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract int getWorkflowCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract int getWorkflowHisCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract int getWorkflowHisCount(String paramString1, String paramString2, String paramString3, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract WorkflowInfo[] getWorkflowInfos(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getWorkflowInfo(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getWorkflowInfoHis(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowInfo getWorkflowInfoHis(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract TaskInfo getRootInfo(String paramString)
    throws RemoteException, Exception;

  public abstract WorkflowInfo[] getWorkflowInfosHis(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract WorkflowInfo[] getWorkflowInfosHis(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosByStationId(String paramString1, long paramLong, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosByStationId(String paramString1, long[] paramArrayOfLong, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosByStationIdAndStaffId(String paramString1, long[] paramArrayOfLong, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHisByWorkflowObjectId(String paramString1, String paramString2, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfos(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosByAttr(String paramString1, String paramString2, HashMap paramHashMap, String paramString3, String paramString4, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract TaskInfo getTaskInfo(String paramString)
    throws RemoteException, Exception;

  public abstract TaskInfo getTaskInfoHis(String paramString)
    throws RemoteException, Exception;

  public abstract TaskInfo getTaskInfoHis(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHis(String paramString1, String paramString2, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract TaskInfo[] getTaskInfosHis(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, int paramInt1, int paramInt2)
    throws RemoteException, Exception;

  public abstract int getTaskCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract int getTaskHisCount(String paramString1, String paramString2, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract int getTaskHisCount(String paramString1, String paramString2, String paramString3, HashMap paramHashMap)
    throws RemoteException, Exception;

  public abstract int getTaskCountByAttr(String paramString1, String paramString2, HashMap paramHashMap, String paramString3, String paramString4)
    throws RemoteException, Exception;

  public abstract Map executeProcess(String paramString, Map paramMap)
    throws Exception, RemoteException;

  public abstract boolean isProcess(String paramString)
    throws Exception, RemoteException;

  public abstract boolean isWorkflow(String paramString)
    throws Exception, RemoteException;

  public abstract WorkflowTemplateInfo[] getWorkflowTemplates(String paramString1, String paramString2, String paramString3)
    throws Exception, RemoteException;

  public abstract TaskTemplateInfo[] getUserTaskTemplates(long paramLong, String paramString)
    throws Exception, RemoteException;

  public abstract TaskTemplateInfo[] getTaskTemplates(long paramLong, String paramString)
    throws Exception, RemoteException;

  public abstract TaskInfo[] getTasksCanBeDragged(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract VmWorkflowAttrInfo[] getVmWorkflowAttrsByWorkflowId(String paramString)
    throws RemoteException, Exception;

  public abstract void updateWarning(String paramString1, Timestamp paramTimestamp, int paramInt, String paramString2)
    throws Exception, RemoteException;

  public abstract void updateDuration(String paramString1, int paramInt, String paramString2)
    throws Exception, RemoteException;

  public abstract String[][] getExceptionCode(String paramString1, String paramString2, String paramString3)
    throws Exception, RemoteException;

  public abstract void claimTask(String paramString1, String paramString2)
    throws RemoteException, Exception;

  public abstract void unClaimTask(String paramString)
    throws RemoteException, Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfig(String paramString1, String paramString2)
    throws Exception;

  public abstract IBOVmAlarmConfigValue[] getAlarmConfigs(String paramString)
    throws Exception;

  public abstract Timestamp[] getHolidayList()
    throws Exception;

  public abstract TaskInfo[] getTaskInfos(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, int paramInt1, int paramInt2)
    throws Exception, RemoteException;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.service.interfaces.IComframeClientSV
 * JD-Core Version:    0.5.4
 */