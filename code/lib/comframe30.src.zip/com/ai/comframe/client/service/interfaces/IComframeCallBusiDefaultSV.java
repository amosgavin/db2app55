package com.ai.comframe.client.service.interfaces;

import java.rmi.RemoteException;
import java.sql.Timestamp;

public abstract interface IComframeCallBusiDefaultSV
{
  public abstract String getStationIdByStationTypeIdAndOrgId(String paramString1, String paramString2)
    throws Exception, RemoteException;

  public abstract int getDurationDefault(long paramLong, String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception, RemoteException;

  public abstract Timestamp getAlarmTimeDefault(long paramLong, String paramString1, String paramString2, String paramString3, String paramString4, int paramInt1, int paramInt2, int paramInt3)
    throws Exception, RemoteException;

  public abstract void alarmDealDefault(long paramLong, String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, int paramInt)
    throws Exception, RemoteException;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.service.interfaces.IComframeCallBusiDefaultSV
 * JD-Core Version:    0.5.4
 */