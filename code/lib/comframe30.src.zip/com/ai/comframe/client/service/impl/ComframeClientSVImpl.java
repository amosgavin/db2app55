/*      */ package com.ai.comframe.client.service.impl;
/*      */ 
/*      */ import com.ai.appframe2.service.ServiceFactory;
/*      */ import com.ai.comframe.client.TaskInfo;
/*      */ import com.ai.comframe.client.TaskTemplateInfo;
/*      */ import com.ai.comframe.client.VmWorkflowAttrInfo;
/*      */ import com.ai.comframe.client.WorkflowInfo;
/*      */ import com.ai.comframe.client.WorkflowTemplateInfo;
/*      */ import com.ai.comframe.client.service.interfaces.IComframeClientSV;
/*      */ import com.ai.comframe.config.ivalues.IBOVmAlarmConfigValue;
/*      */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*      */ import com.ai.comframe.config.service.interfaces.IVmAlarmConfigSV;
/*      */ import com.ai.comframe.query.TemplateInfoHelper;
/*      */ import com.ai.comframe.query.WorkflowInfoHelper;
/*      */ import com.ai.comframe.utils.DataSourceUtil;
/*      */ import com.ai.comframe.utils.IDAssembleUtil;
/*      */ import com.ai.comframe.vm.processflow.ProcessEngine;
/*      */ import com.ai.comframe.vm.processflow.ProcessEngineFactory;
/*      */ import com.ai.comframe.vm.template.TaskTemplate;
/*      */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*      */ import com.ai.comframe.vm.workflow.WorkflowEngineFactory;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFAttrValue;
/*      */ import com.ai.comframe.vm.workflow.ivalues.IBOVmWFValue;
/*      */ import com.ai.comframe.vm.workflow.service.interfaces.IWorkflowEngineSV;
/*      */ import java.rmi.RemoteException;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ 
/*      */ public class ComframeClientSVImpl
/*      */   implements IComframeClientSV
/*      */ {
/*      */   public String createWorkflow(String templateTag, String parentTaskId, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/*   56 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*   57 */     String queueId = templateSV.getQueueId(templateTag);
/*   58 */     String scheduleServerName = templateSV.getEngineType(templateTag);
/*   59 */     boolean isPushDataSource = false;
/*      */     try {
/*   61 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueId);
/*   62 */       String str1 = WorkflowEngineFactory.getInstance().createWorkflow(queueId, parentTaskId, templateTag, -1, scheduleServerName, staffId, objectTypeId, objectId, aVars, startTime, notes);
/*      */ 
/*   67 */       return str1;
/*      */     }
/*      */     finally
/*      */     {
/*   65 */       if (isPushDataSource == true)
/*   66 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String templateTag, String staffId, String objectTypeId, String objectId, Map aVars, Timestamp startTime, String notes) throws RemoteException, Exception
/*      */   {
/*   72 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*   73 */     String queueId = templateSV.getQueueId(templateTag);
/*   74 */     String scheduleServerName = templateSV.getEngineType(templateTag);
/*   75 */     boolean isPushDataSource = false;
/*      */     try {
/*   77 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueId);
/*   78 */       String str1 = WorkflowEngineFactory.getInstance().createWorkflow(queueId, "-1", templateTag, -1, scheduleServerName, staffId, objectTypeId, objectId, aVars, startTime, notes);
/*      */ 
/*   83 */       return str1;
/*      */     }
/*      */     finally
/*      */     {
/*   81 */       if (isPushDataSource == true)
/*   82 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String createWorkflow(String aQueueId, String parentTaskId, String templateTag, int workflowKind, String staffId, String objectTypeId, String objectId, Map aVars) throws Exception
/*      */   {
/*   88 */     boolean isPushDataSource = false;
/*      */     try {
/*   90 */       String queueId = aQueueId;
/*   91 */       if (StringUtils.isEmpty(queueId)) {
/*   92 */         templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*   93 */         queueId = templateSV.getQueueId(templateTag);
/*      */       }
/*   95 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueId);
/*   96 */       ITemplateSV templateSV = WorkflowEngineFactory.getInstance().createWorkflow(aQueueId, parentTaskId, templateTag, workflowKind, staffId, objectTypeId, objectId, aVars);
/*      */ 
/*  101 */       return templateSV;
/*      */     }
/*      */     finally
/*      */     {
/*   99 */       if (isPushDataSource == true)
/*  100 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsByWorkflowObjectId(String queueID, String objectTypeId, String objectId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  116 */     boolean isPushDataSource = false;
/*      */     try {
/*  118 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  119 */       String[] arrayOfString = WorkflowEngineFactory.getInstance().getWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/*  123 */       return arrayOfString;
/*      */     }
/*      */     finally
/*      */     {
/*  121 */       if (isPushDataSource == true)
/*  122 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  128 */     boolean isPushDataSource = false;
/*      */     try {
/*  130 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  131 */       String[] arrayOfString = WorkflowEngineFactory.getInstance().getWorkflowsHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/*  135 */       return arrayOfString;
/*      */     }
/*      */     finally
/*      */     {
/*  133 */       if (isPushDataSource == true)
/*  134 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[] getWorkflowsHisByWorkflowObjectId(String queueID, String acctPriod, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  140 */     boolean isPushDataSource = false;
/*      */     try {
/*  142 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  143 */       String[] arrayOfString = WorkflowEngineFactory.getInstance().getWorkflowsHisByWorkflowObjectId(queueID, acctPriod, objectTypeId, objectId);
/*      */ 
/*  147 */       return arrayOfString;
/*      */     }
/*      */     finally
/*      */     {
/*  145 */       if (isPushDataSource == true)
/*  146 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception {
/*  151 */     boolean isPushDataSource = false;
/*      */     try {
/*  153 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  154 */       WorkflowInfo localWorkflowInfo = WorkflowEngineFactory.getInstance().getRootWorkflowsByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/*  158 */       return localWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/*  156 */       if (isPushDataSource == true)
/*  157 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  163 */     boolean isPushDataSource = false;
/*      */     try {
/*  165 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  166 */       WorkflowInfo localWorkflowInfo = WorkflowEngineFactory.getInstance().getRootWorkflowsHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/*  170 */       return localWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/*  168 */       if (isPushDataSource == true)
/*  169 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getRootWorkflowHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/*  175 */     boolean isPushDataSource = false;
/*      */     try {
/*  177 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  178 */       WorkflowInfo localWorkflowInfo = WorkflowEngineFactory.getInstance().getRootWorkflowsHisByWorkflowObjectId(queueID, acctPreiod, objectTypeId, objectId);
/*      */ 
/*  182 */       return localWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/*  180 */       if (isPushDataSource == true)
/*  181 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stopWorkflow(String workflowId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  197 */     boolean isPushDataSource = false;
/*      */     try {
/*  199 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  200 */       WorkflowEngineFactory.getInstance().stopWorkflow(workflowId, staffId, reason);
/*      */     } finally {
/*  202 */       if (isPushDataSource == true)
/*  203 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void stopWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  223 */     boolean isPushDataSource = false;
/*      */     try {
/*  225 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  226 */       WorkflowEngineFactory.getInstance().stopWorkflow(queueID, workflowObjectType, workflowObjectId, staffId, reason);
/*      */     } finally {
/*  228 */       if (isPushDataSource == true)
/*  229 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void resumeWorkflow(String queueID, String workflowObjectType, String workflowObjectId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  249 */     boolean isPushDataSource = false;
/*      */     try {
/*  251 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  252 */       WorkflowEngineFactory.getInstance().resumeWorkflow(queueID, workflowObjectType, workflowObjectId, staffId, reason);
/*      */     } finally {
/*  254 */       if (isPushDataSource == true)
/*  255 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void resumeWorkflow(String workflowId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  271 */     boolean isPushDataSource = false;
/*      */     try {
/*  273 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  274 */       WorkflowEngineFactory.getInstance().resumeWorkflow(workflowId, staffId, reason);
/*      */     } finally {
/*  276 */       if (isPushDataSource == true)
/*  277 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void terminateWorkflow(String workflowId, String staffId, String reason)
/*      */     throws RemoteException, Exception
/*      */   {
/*  291 */     boolean isPushDataSource = false;
/*      */     try {
/*  293 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  294 */       WorkflowEngineFactory.getInstance().terminateWorkflow(workflowId, staffId, reason);
/*      */     } finally {
/*  296 */       if (isPushDataSource == true)
/*  297 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void dropWorkflow(String workflowId)
/*      */     throws Exception
/*      */   {
/*  309 */     boolean isPushDataSource = false;
/*      */     try {
/*  311 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  312 */       WorkflowEngineFactory.getInstance().dropWorkflow(workflowId);
/*      */     } finally {
/*  314 */       if (isPushDataSource == true)
/*  315 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean canExecuteTask(String taskId, long[] stations, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  333 */     boolean isPushDataSource = false;
/*      */     try {
/*  335 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  336 */       boolean bool1 = WorkflowEngineFactory.getInstance().canExecuteTask(taskId, stations, staffId);
/*      */ 
/*  340 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  338 */       if (isPushDataSource == true)
/*  339 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String workflowId, String staffId, String errorCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/*  355 */     boolean isPushDataSource = false;
/*      */     try {
/*  357 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  358 */       WorkflowEngineFactory.getInstance().cancelWorkflow(workflowId, staffId, errorCode, errorMessage);
/*      */     } finally {
/*  360 */       if (isPushDataSource == true)
/*  361 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cancelWorkflowByWorkflowObject(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/*  377 */     boolean isPushDataSource = false;
/*      */     try {
/*  379 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  380 */       WorkflowEngineFactory.getInstance().cancelWorkflowByWorkflowObject(queueID, objectTypeId, objectId, staffId, errorCode, errorMessage);
/*      */     }
/*      */     finally {
/*  383 */       if (isPushDataSource == true)
/*  384 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String queueID, String objectTypeId, String objectId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/*  400 */     boolean isPushDataSource = false;
/*      */     try {
/*  402 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  403 */       WorkflowEngineFactory.getInstance().cancelWorkflow(queueID, objectTypeId, objectId, staffId, errorCode, nextWorkflowCode, errorMessage);
/*      */     }
/*      */     finally {
/*  406 */       if (isPushDataSource == true)
/*  407 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void cancelWorkflow(String workflowId, String staffId, String errorCode, String nextWorkflow, String errorMessage)
/*      */     throws RemoteException, Exception
/*      */   {
/*  424 */     boolean isPushDataSource = false;
/*      */     try {
/*  426 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  427 */       WorkflowEngineFactory.getInstance().cancelWorkflow(workflowId, staffId, errorCode, nextWorkflow, errorMessage);
/*      */     } finally {
/*  429 */       if (isPushDataSource == true)
/*  430 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map getWorkflowVars(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  444 */     boolean isPushDataSource = false;
/*      */     try {
/*  446 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  447 */       Map localMap = WorkflowEngineFactory.getInstance().getWorkflowVars(workflowId);
/*      */ 
/*  451 */       return localMap;
/*      */     }
/*      */     finally
/*      */     {
/*  449 */       if (isPushDataSource == true)
/*  450 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map getChildWorkflowReturnVar(String workflowId, String aVarName) throws RemoteException, Exception {
/*  455 */     return WorkflowEngineFactory.getInstance().getChildWorkflowReturnVar(workflowId, aVarName);
/*      */   }
/*      */ 
/*      */   public int getWorkflowCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/*  468 */     boolean isPushDataSource = false;
/*      */     try {
/*  470 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  471 */       int i = WorkflowEngineFactory.getInstance().getWorkflowCount(queueID, condition, parameter);
/*      */ 
/*  475 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  473 */       if (isPushDataSource == true)
/*  474 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getWorkflowHisCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/*  488 */     boolean isPushDataSource = false;
/*      */     try {
/*  490 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  491 */       int i = WorkflowEngineFactory.getInstance().getWorkflowHisCount(queueID, condition, parameter);
/*      */ 
/*  495 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  493 */       if (isPushDataSource == true)
/*  494 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getWorkflowHisCount(String queueID, String acctPreiod, String condition, HashMap parameter) throws RemoteException, Exception {
/*  499 */     boolean isPushDataSource = false;
/*      */     try {
/*  501 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  502 */       int i = WorkflowEngineFactory.getInstance().getWorkflowHisCount(queueID, acctPreiod, condition, parameter);
/*      */ 
/*  506 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  504 */       if (isPushDataSource == true)
/*  505 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setWorkflowVars(String workflowId, HashMap aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  521 */     boolean isPushDataSource = false;
/*      */     try {
/*  523 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  524 */       WorkflowEngineFactory.getInstance().setWorkflowVars(workflowId, aVars);
/*      */     } finally {
/*  526 */       if (isPushDataSource == true)
/*  527 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toSvg(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  541 */     boolean isPushDataSource = false;
/*      */     try {
/*  543 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  544 */       String str = WorkflowEngineFactory.getInstance().toSvg(workflowId);
/*      */ 
/*  548 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  546 */       if (isPushDataSource == true)
/*  547 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toSvgHis(String workflowId, String acctPreiod) throws RemoteException, Exception {
/*  552 */     boolean isPushDataSource = false;
/*      */     try {
/*  554 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  555 */       String str = WorkflowEngineFactory.getInstance().toSvgHis(workflowId, acctPreiod);
/*      */ 
/*  559 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  557 */       if (isPushDataSource == true)
/*  558 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toSvg(long templateId, String taskTag)
/*      */     throws Exception
/*      */   {
/*  572 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  573 */     return templateSV.toSvg(templateId, taskTag);
/*      */   }
/*      */ 
/*      */   public String toSvgByWorkflowObjectId(String queueID, String objectTypeId, String objectId)
/*      */     throws Exception
/*      */   {
/*  587 */     boolean isPushDataSource = false;
/*      */     try {
/*  589 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  590 */       String str = WorkflowEngineFactory.getInstance().toSvgByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/*  594 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  592 */       if (isPushDataSource == true)
/*  593 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toSvgHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId) throws Exception {
/*  598 */     boolean isPushDataSource = false;
/*      */     try {
/*  600 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  601 */       String str = WorkflowEngineFactory.getInstance().toSvgHisByWorkflowObjectId(queueID, acctPreiod, objectTypeId, objectId);
/*      */ 
/*  605 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  603 */       if (isPushDataSource == true)
/*  604 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toDojo(String workflowId, String imagePath)
/*      */     throws RemoteException, Exception
/*      */   {
/*  618 */     boolean isPushDataSource = false;
/*      */     try {
/*  620 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  621 */       String str = WorkflowEngineFactory.getInstance().toDojo(workflowId, imagePath);
/*      */ 
/*  625 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  623 */       if (isPushDataSource == true)
/*  624 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toDojoHis(String workflowId, String acctPreiod, String imagePath) throws RemoteException, Exception {
/*  629 */     boolean isPushDataSource = false;
/*      */     try {
/*  631 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  632 */       String str = WorkflowEngineFactory.getInstance().toDojoHis(workflowId, acctPreiod, imagePath);
/*      */ 
/*  636 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  634 */       if (isPushDataSource == true)
/*  635 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toDojo(long templateId, String taskTag, String imagePath)
/*      */     throws Exception
/*      */   {
/*  649 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  650 */     return templateSV.toDojo(templateId, taskTag, imagePath);
/*      */   }
/*      */ 
/*      */   public String toDojoByWorkflowObjectId(String queueID, String objectTypeId, String objectId, String imagePath)
/*      */     throws Exception
/*      */   {
/*  664 */     boolean isPushDataSource = false;
/*      */     try {
/*  666 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  667 */       String str = WorkflowEngineFactory.getInstance().toDojoByWorkflowObjectId(queueID, objectTypeId, objectId, imagePath);
/*      */ 
/*  671 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  669 */       if (isPushDataSource == true)
/*  670 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toDojoHisByWorkflowObjectId(String queueID, String acctPreiod, String objectTypeId, String objectId, String imagePath) throws Exception {
/*  675 */     boolean isPushDataSource = false;
/*      */     try {
/*  677 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  678 */       String str = WorkflowEngineFactory.getInstance().toDojoHisByWorkflowObjectId(queueID, acctPreiod, objectTypeId, objectId, imagePath);
/*      */ 
/*  682 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  680 */       if (isPushDataSource == true)
/*  681 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void lockTask(String taskId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  696 */     boolean isPushDataSource = false;
/*      */     try {
/*  698 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  699 */       WorkflowEngineFactory.getInstance().lockTask(taskId, staffId);
/*      */     } finally {
/*  701 */       if (isPushDataSource == true)
/*  702 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void realseTask(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  715 */     boolean isPushDataSource = false;
/*      */     try {
/*  717 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  718 */       WorkflowEngineFactory.getInstance().realseTask(taskId);
/*      */     } finally {
/*  720 */       if (isPushDataSource == true)
/*  721 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean finishUserTask(String taskId, String staffId, String result, String reason, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  744 */     boolean isPushDataSource = false;
/*      */     try {
/*  746 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  747 */       boolean bool1 = WorkflowEngineFactory.getInstance().finishUserTask(taskId, staffId, result, aVars, reason);
/*      */ 
/*  751 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  749 */       if ((isPushDataSource = 1) != 0)
/*  750 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String currentTaskId, String goBackTaskTag, String staffId, String reason, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  775 */     boolean isPushDataSource = false;
/*      */     try {
/*  777 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(currentTaskId));
/*  778 */       boolean bool1 = WorkflowEngineFactory.getInstance().goBackToTask(currentTaskId, goBackTaskTag, staffId, reason, aVars);
/*      */ 
/*  782 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  780 */       if (isPushDataSource == true)
/*  781 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String currentTaskId, long goBackTaskTemplateId, String staffId, String reason, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  804 */     boolean isPushDataSource = false;
/*      */     try {
/*  806 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(currentTaskId));
/*  807 */       boolean bool1 = WorkflowEngineFactory.getInstance().goBackToTask(currentTaskId, goBackTaskTemplateId, aVars, staffId, reason);
/*      */ 
/*  811 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  809 */       if (isPushDataSource == true)
/*  810 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean goBackToTask(String currentTaskId, Map vars, String staffId, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/*  829 */     boolean isPushDataSource = false;
/*      */     try {
/*  831 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(currentTaskId));
/*  832 */       boolean bool1 = WorkflowEngineFactory.getInstance().goBackToTask(currentTaskId, vars, staffId, notes);
/*      */ 
/*  836 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  834 */       if (isPushDataSource == true)
/*  835 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean jumpToTask(String taskId, long taskTemplateId, Map vars, String staffId, String notes)
/*      */     throws RemoteException, Exception
/*      */   {
/*  849 */     boolean isPushDataSource = false;
/*      */     try {
/*  851 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  852 */       boolean bool1 = WorkflowEngineFactory.getInstance().jumpToTask(taskId, taskTemplateId, vars, staffId, notes);
/*      */ 
/*  856 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  854 */       if (isPushDataSource == true)
/*  855 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean printUserTask(String taskId, String staffId, Map aVars)
/*      */     throws RemoteException, Exception
/*      */   {
/*  873 */     boolean isPushDataSource = false;
/*      */     try {
/*  875 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  876 */       boolean bool1 = WorkflowEngineFactory.getInstance().printUserTask(taskId, staffId, aVars);
/*      */ 
/*  880 */       return bool1;
/*      */     }
/*      */     finally
/*      */     {
/*  878 */       if (isPushDataSource == true)
/*  879 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String errorMessage)
/*      */     throws Exception
/*      */   {
/*  896 */     boolean isPushDataSource = false;
/*      */     try {
/*  898 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  899 */       WorkflowEngineFactory.getInstance().fireWorkflowExceptionByTaskId(taskId, staffId, errorCode, errorMessage);
/*      */     } finally {
/*  901 */       if (isPushDataSource == true)
/*  902 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void fireWorkflowExceptionByTaskId(String taskId, String staffId, String errorCode, String nextWorkflowCode, String errorMessage)
/*      */     throws Exception
/*      */   {
/*  919 */     boolean isPushDataSource = false;
/*      */     try {
/*  921 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  922 */       WorkflowEngineFactory.getInstance().fireWorkflowExceptionByTaskId(taskId, staffId, errorCode, nextWorkflowCode, errorMessage);
/*      */     }
/*      */     finally {
/*  925 */       if (isPushDataSource == true)
/*  926 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String reAuthorizeTask(String taskId, String authorizeStaffId, String authorizeStationId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/*  947 */     boolean isPushDataSource = false;
/*      */     try {
/*  949 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/*  950 */       String str = WorkflowEngineFactory.getInstance().reAuthorizeTask(taskId, authorizeStaffId, authorizeStationId, staffId);
/*      */ 
/*  954 */       return str;
/*      */     }
/*      */     finally
/*      */     {
/*  952 */       if (isPushDataSource == true)
/*  953 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void resumeExceptionWorkflow(String workflowId)
/*      */     throws Exception
/*      */   {
/*  965 */     boolean isPushDataSource = false;
/*      */     try {
/*  967 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  968 */       WorkflowEngineFactory.getInstance().resumExceptionWorkflow(workflowId);
/*      */     } finally {
/*  970 */       if (isPushDataSource == true)
/*  971 */         DataSourceUtil.popDataSource(); 
/*      */     }
/*      */   }
/*      */ 
/*      */   public int resumeExceptionWorkflows(String queueID, String[] workflowIds) throws Exception {
/*  975 */     boolean isPushDataSource = false;
/*      */     try {
/*  977 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/*  978 */       int i = WorkflowEngineFactory.getInstance().resumeExceptionWorkflows(workflowIds);
/*      */ 
/*  982 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/*  980 */       if (isPushDataSource == true)
/*  981 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByWorkflowId(String workflowId) throws RemoteException, Exception {
/*  986 */     boolean isPushDataSource = false;
/*      */     try {
/*  988 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/*  989 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().queryTaskByWorkflowId(workflowId);
/*      */ 
/*  993 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/*  991 */       if (isPushDataSource == true)
/*  992 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHisByWorkflowId(String workflowId) throws RemoteException, Exception
/*      */   {
/*  998 */     boolean isPushDataSource = false;
/*      */     try {
/* 1000 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1001 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().queryTaskHisByWorkflowId(workflowId);
/*      */ 
/* 1005 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1003 */       if (isPushDataSource == true)
/* 1004 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHisByWorkflowId(String workflowId, String acctPeriod) throws RemoteException, Exception
/*      */   {
/* 1010 */     boolean isPushDataSource = false;
/*      */     try {
/* 1012 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1013 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().queryTaskHisByWorkflowId(workflowId, acctPeriod);
/*      */ 
/* 1017 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1015 */       if (isPushDataSource == true)
/* 1016 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByStationId(String queueID, long stationId, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1031 */     boolean isPushDataSource = false;
/*      */     try {
/* 1033 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1034 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksByStationId(queueID, stationId, workflowTemplateCode, taskTag);
/*      */ 
/* 1038 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1036 */       if (isPushDataSource == true)
/* 1037 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByStationId(String queueID, long[] stations, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1051 */     boolean isPushDataSource = false;
/*      */     try {
/* 1053 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1054 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksByStationId(queueID, stations, workflowTemplateCode, taskTag);
/*      */ 
/* 1058 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1056 */       if (isPushDataSource == true)
/* 1057 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByStationIdAndStaffId(String queueID, long[] stations, String staffId, String workflowTemplateCode, String taskTag)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1073 */     boolean isPushDataSource = false;
/*      */     try {
/* 1075 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1076 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksByStationIdAndStaffId(queueID, stations, staffId, workflowTemplateCode, taskTag);
/*      */ 
/* 1081 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1079 */       if (isPushDataSource == true)
/* 1080 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByWorkflowObjectId(String queueID, String objectTypeId, String objectId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1096 */     boolean isPushDataSource = false;
/*      */     try {
/* 1098 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1099 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/* 1103 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1101 */       if (isPushDataSource == true)
/* 1102 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHisByWorkflowObjectId(String queueID, String objectTypeId, String objectId) throws RemoteException, Exception
/*      */   {
/* 1108 */     boolean isPushDataSource = false;
/*      */     try {
/* 1110 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1111 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksHisByWorkflowObjectId(queueID, objectTypeId, objectId);
/*      */ 
/* 1115 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1113 */       if (isPushDataSource == true)
/* 1114 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHisByWorkflowObjectId(String queueID, String acctPeriod, String objectTypeId, String objectId) throws RemoteException, Exception {
/* 1119 */     boolean isPushDataSource = false;
/*      */     try {
/* 1121 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1122 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksHisByWorkflowObjectId(queueID, acctPeriod, objectTypeId, objectId);
/*      */ 
/* 1126 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1124 */       if (isPushDataSource == true)
/* 1125 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1146 */     boolean isPushDataSource = false;
/*      */     try {
/* 1148 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1149 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfos(queueID, condition, parameter, startIndex, endIndex);
/*      */ 
/* 1153 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1151 */       if (isPushDataSource == true)
/* 1152 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1159 */     boolean isPushDataSource = false;
/*      */     try {
/* 1161 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1162 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*      */ 
/* 1166 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1164 */       if (isPushDataSource == true)
/* 1165 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosHis(String queueID, String acctPeriod, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1172 */     boolean isPushDataSource = false;
/*      */     try {
/* 1174 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1175 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfosHis(queueID, acctPeriod, condition, parameter, startIndex, endIndex);
/*      */ 
/* 1179 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1177 */       if (isPushDataSource == true)
/* 1178 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfo(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1194 */     boolean isPushDataSource = false;
/*      */     try {
/* 1196 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1197 */       TaskInfo localTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfo(taskId);
/*      */ 
/* 1201 */       return localTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1199 */       if (isPushDataSource == true)
/* 1200 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfoHis(String taskId) throws RemoteException, Exception
/*      */   {
/* 1206 */     boolean isPushDataSource = false;
/*      */     try {
/* 1208 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1209 */       TaskInfo localTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfoHis(taskId);
/*      */ 
/* 1213 */       return localTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1211 */       if (isPushDataSource == true)
/* 1212 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo getTaskInfoHis(String taskId, String acctPeriod) throws RemoteException, Exception
/*      */   {
/* 1218 */     boolean isPushDataSource = false;
/*      */     try {
/* 1220 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1221 */       TaskInfo localTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfoHis(taskId, acctPeriod);
/*      */ 
/* 1225 */       return localTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1223 */       if (isPushDataSource == true)
/* 1224 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTaskCount(String queueID, String condition, HashMap parameter)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1239 */     boolean isPushDataSource = false;
/*      */     try {
/* 1241 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1242 */       int i = WorkflowEngineFactory.getInstance().getTaskCount(queueID, condition, parameter);
/*      */ 
/* 1246 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1244 */       if (isPushDataSource == true)
/* 1245 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTaskHisCount(String queueID, String condition, HashMap parameter) throws RemoteException, Exception {
/* 1250 */     boolean isPushDataSource = false;
/*      */     try {
/* 1252 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1253 */       int i = WorkflowEngineFactory.getInstance().getTaskHisCount(queueID, condition, parameter);
/*      */ 
/* 1257 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1255 */       if (isPushDataSource == true)
/* 1256 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTaskHisCount(String queueID, String acctPeriod, String condition, HashMap parameter) throws RemoteException, Exception {
/* 1261 */     boolean isPushDataSource = false;
/*      */     try {
/* 1263 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1264 */       int i = WorkflowEngineFactory.getInstance().getTaskHisCount(queueID, acctPeriod, condition, parameter);
/*      */ 
/* 1268 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1266 */       if (isPushDataSource == true)
/* 1267 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTaskCountByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue) throws RemoteException, Exception {
/* 1272 */     boolean isPushDataSource = false;
/*      */     try {
/* 1274 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1275 */       int i = WorkflowEngineFactory.getInstance().getTaskCountByAttr(queueID, condition, parameter, attrCode, attrValue);
/*      */ 
/* 1279 */       return i;
/*      */     }
/*      */     finally
/*      */     {
/* 1277 */       if (isPushDataSource == true)
/* 1278 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfosByAttr(String queueID, String condition, HashMap parameter, String attrCode, String attrValue, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/* 1284 */     boolean isPushDataSource = false;
/*      */     try {
/* 1286 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1287 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfosByAttr(queueID, condition, parameter, attrCode, attrValue, startIndex, endIndex);
/*      */ 
/* 1292 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1290 */       if (isPushDataSource == true)
/* 1291 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfos(String queueID, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/* 1313 */     boolean isPushDataSource = false;
/*      */     IBOVmWFValue[] beans;
/*      */     try {
/* 1315 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1316 */       beans = WorkflowEngineFactory.getInstance().getWorkflowBeans(queueID, condition, parameter, startIndex, endIndex);
/*      */     }
/*      */     finally {
/* 1319 */       if (isPushDataSource == true)
/* 1320 */         DataSourceUtil.popDataSource();
/*      */     }
/* 1322 */     return WorkflowInfoHelper.transfer(beans);
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfosHis(String queueID, String condition, HashMap parameter, int startIndex, int endIndex)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1342 */     boolean isPushDataSource = false;
/*      */     try {
/* 1344 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1345 */       WorkflowInfo[] arrayOfWorkflowInfo = WorkflowEngineFactory.getInstance().getWorkflowInfosHis(queueID, condition, parameter, startIndex, endIndex);
/*      */ 
/* 1349 */       return arrayOfWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1347 */       if (isPushDataSource == true)
/* 1348 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo[] getWorkflowInfosHis(String queueID, String acctPreiod, String condition, HashMap parameter, int startIndex, int endIndex) throws RemoteException, Exception
/*      */   {
/* 1354 */     boolean isPushDataSource = false;
/*      */     try {
/* 1356 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1357 */       WorkflowInfo[] arrayOfWorkflowInfo = WorkflowEngineFactory.getInstance().getWorkflowInfosHis(queueID, acctPreiod, condition, parameter, startIndex, endIndex);
/*      */ 
/* 1361 */       return arrayOfWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1359 */       if (isPushDataSource == true)
/* 1360 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getWorkflowInfo(String workflowId) throws RemoteException, Exception
/*      */   {
/* 1377 */     boolean isPushDataSource = false;
/*      */     IBOVmWFValue bean;
/*      */     try {
/* 1379 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1380 */       bean = WorkflowEngineFactory.getInstance().getWorkflowBean(workflowId);
/* 1381 */       if (bean == null) {
/* 1382 */         Object localObject1 = null;
/*      */         return localObject1;
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1385 */       if (isPushDataSource == true)
/* 1386 */         DataSourceUtil.popDataSource();
/*      */     }
/* 1388 */     return WorkflowInfoHelper.transfer(new IBOVmWFValue[] { bean })[0];
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getWorkflowInfoHis(String workflowId) throws RemoteException, Exception {
/* 1392 */     boolean isPushDataSource = false;
/*      */     try {
/* 1394 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1395 */       WorkflowInfo localWorkflowInfo = WorkflowEngineFactory.getInstance().getWorkflowInfoHis(workflowId);
/*      */ 
/* 1399 */       return localWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1397 */       if (isPushDataSource == true)
/* 1398 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public WorkflowInfo getWorkflowInfoHis(String workflowId, String acctPeriod) throws RemoteException, Exception {
/* 1403 */     boolean isPushDataSource = false;
/*      */     try {
/* 1405 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1406 */       WorkflowInfo localWorkflowInfo = WorkflowEngineFactory.getInstance().getWorkflowInfoHis(workflowId, acctPeriod);
/*      */ 
/* 1410 */       return localWorkflowInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1408 */       if (isPushDataSource == true)
/* 1409 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskInfo getRootInfo(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1425 */     boolean isPushDataSource = false;
/*      */     try {
/* 1427 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1428 */       TaskInfo localTaskInfo = WorkflowEngineFactory.getInstance().getRootBean(taskId);
/*      */ 
/* 1432 */       return localTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1430 */       if (isPushDataSource == true)
/* 1431 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map executeProcess(String processName, Map parameters)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1447 */     return ProcessEngineFactory.getProcessEngine().executeProcess(processName, parameters);
/*      */   }
/*      */ 
/*      */   public boolean isProcess(String templateCode)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1460 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1461 */     return templateSV.isProcess(templateCode);
/*      */   }
/*      */ 
/*      */   public boolean isWorkflow(String templateCode)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1475 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1476 */     return templateSV.isWorkflow(templateCode);
/*      */   }
/*      */ 
/*      */   public WorkflowTemplateInfo[] getWorkflowTemplates(String templateCode, String sValidDate, String eValidDate)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1492 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1493 */     return templateSV.getWorkflowTemplateInfo(templateCode, sValidDate, eValidDate);
/*      */   }
/*      */ 
/*      */   public TaskTemplateInfo[] getUserTaskTemplates(long templateId, String templateCode)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1507 */     WorkflowTemplate wt = getWorkflowTemplate(templateId, templateCode);
/* 1508 */     TaskTemplate[] taskTemplates = wt.getUserTaskTemplates();
/* 1509 */     return TemplateInfoHelper.transfer(taskTemplates, wt);
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTasksCanBeDragged(String queueID, String staffId)
/*      */     throws Exception
/*      */   {
/* 1520 */     boolean isPushDataSource = false;
/*      */     try {
/* 1522 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1523 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTasksCanBeDragged(queueID, staffId);
/*      */ 
/* 1527 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1525 */       if (isPushDataSource == true)
/* 1526 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public TaskTemplateInfo[] getTaskTemplates(long templateId, String templateCode)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1540 */     WorkflowTemplate wt = getWorkflowTemplate(templateId, templateCode);
/* 1541 */     TaskTemplate[] taskTemplates = wt.getTaskTemplates();
/* 1542 */     return TemplateInfoHelper.transfer(taskTemplates, wt);
/*      */   }
/*      */ 
/*      */   private WorkflowTemplate getWorkflowTemplate(long templateId, String templateCode) throws Exception, RemoteException
/*      */   {
/* 1547 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 1548 */     return templateSV.getWorkflowTemplate(templateId, templateCode);
/*      */   }
/*      */ 
/*      */   public VmWorkflowAttrInfo[] getVmWorkflowAttrsByWorkflowId(String workflowId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1560 */     boolean isPushDataSource = false;
/*      */     try {
/* 1562 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(workflowId));
/* 1563 */       IBOVmWFAttrValue[] beans = WorkflowEngineFactory.getInstance().getVmWorkflowAttrsByWorkflowId(workflowId);
/* 1564 */       VmWorkflowAttrInfo[] arrayOfVmWorkflowAttrInfo = WorkflowInfoHelper.transfer(beans);
/*      */ 
/* 1568 */       return arrayOfVmWorkflowAttrInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1566 */       if (isPushDataSource == true)
/* 1567 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateWarning(String taskId, Timestamp date, int alarmTimes, String type)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1584 */     boolean isPushDataSource = false;
/*      */     try {
/* 1586 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1587 */       IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1588 */       alarmConfigSV.updateWarning(taskId, date, alarmTimes, type);
/*      */     } finally {
/* 1590 */       if (isPushDataSource == true)
/* 1591 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void updateDuration(String taskId, int duration, String type)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1606 */     boolean isPushDataSource = false;
/*      */     try {
/* 1608 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1609 */       IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1610 */       alarmConfigSV.updateDuration(taskId, duration, type);
/*      */     } finally {
/* 1612 */       if (isPushDataSource == true)
/* 1613 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public String[][] getExceptionCode(String workflowObjectType, String currentWorkflowCode, String taskTag)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1632 */     return WorkflowEngineFactory.getInstance().getExceptionCode(workflowObjectType, currentWorkflowCode, taskTag);
/*      */   }
/*      */ 
/*      */   public void claimTask(String taskId, String staffId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1646 */     boolean isPushDataSource = false;
/*      */     try {
/* 1648 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1649 */       WorkflowEngineFactory.getInstance().claimTask(taskId, staffId);
/*      */     } finally {
/* 1651 */       if (isPushDataSource == true)
/* 1652 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unClaimTask(String taskId)
/*      */     throws RemoteException, Exception
/*      */   {
/* 1665 */     boolean isPushDataSource = false;
/*      */     try {
/* 1667 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(IDAssembleUtil.unwrapPrefix(taskId));
/* 1668 */       WorkflowEngineFactory.getInstance().unClaimTask(taskId);
/*      */     } finally {
/* 1670 */       if (isPushDataSource == true)
/* 1671 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ 
/*      */   public IBOVmAlarmConfigValue[] getAlarmConfig(String taskTag, String templateTag) throws Exception
/*      */   {
/* 1677 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1678 */     return alarmConfigSV.getAlarmConfig(taskTag, templateTag);
/*      */   }
/*      */ 
/*      */   public IBOVmAlarmConfigValue[] getAlarmConfigs(String templateTag) throws Exception
/*      */   {
/* 1683 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1684 */     return alarmConfigSV.getAlarmConfigs(templateTag);
/*      */   }
/*      */ 
/*      */   public Timestamp[] getHolidayList() throws Exception {
/* 1688 */     IVmAlarmConfigSV alarmConfigSV = (IVmAlarmConfigSV)ServiceFactory.getService(IVmAlarmConfigSV.class);
/* 1689 */     return alarmConfigSV.getHolidayList();
/*      */   }
/*      */ 
/*      */   public TaskInfo[] getTaskInfos(String queueID, String stations, String staffId, String state, String orderId, int startIndex, int endIndex)
/*      */     throws Exception, RemoteException
/*      */   {
/* 1695 */     boolean isPushDataSource = false;
/*      */     try {
/* 1697 */       isPushDataSource = DataSourceUtil.pushDataSourcebyQueueId(queueID);
/* 1698 */       TaskInfo[] arrayOfTaskInfo = WorkflowEngineFactory.getInstance().getTaskInfos(queueID, stations, staffId, state, orderId, startIndex, endIndex);
/*      */ 
/* 1703 */       return arrayOfTaskInfo;
/*      */     }
/*      */     finally
/*      */     {
/* 1701 */       if ((isPushDataSource = 1) != 0)
/* 1702 */         DataSourceUtil.popDataSource();
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.service.impl.ComframeClientSVImpl
 * JD-Core Version:    0.5.4
 */