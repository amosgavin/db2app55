/*    */ package com.ai.comframe.client;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ import com.ai.appframe2.complex.center.interfaces.ICenter;
/*    */ 
/*    */ public class DefaultCenterImpl
/*    */   implements ICenter
/*    */ {
/*    */   public CenterInfo getCenterByValue(String value)
/*    */     throws Exception
/*    */   {
/* 15 */     CenterInfo center = new CenterInfo("0", value);
/* 16 */     if ("571".equals(value))
/* 17 */       center = new CenterInfo("1", value);
/* 18 */     return center;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.DefaultCenterImpl
 * JD-Core Version:    0.5.4
 */