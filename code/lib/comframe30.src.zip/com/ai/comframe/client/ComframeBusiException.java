/*    */ package com.ai.comframe.client;
/*    */ 
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ 
/*    */ public class ComframeBusiException extends Exception
/*    */ {
/*    */   String code;
/*    */ 
/*    */   public ComframeBusiException(String aCode, String aMessage)
/*    */   {
/* 20 */     super(aMessage);
/* 21 */     this.code = aCode;
/*    */   }
/*    */   public String toString() {
/* 24 */     return ComframeLocaleFactory.getResource("com.ai.appframe2.vm.common.Constant.WORKFLOW_STATE_businessException") + this.code + ":" + getMessage();
/*    */   }
/*    */ 
/*    */   public String getCode() {
/* 28 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String code) {
/* 32 */     this.code = code;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.ComframeBusiException
 * JD-Core Version:    0.5.4
 */