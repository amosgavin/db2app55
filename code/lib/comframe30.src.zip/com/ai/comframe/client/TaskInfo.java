/*     */ package com.ai.comframe.client;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class TaskInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -9048702000036771126L;
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_WorkflowCreateDate = "WORKFLOW_CREATE_DATE";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_WorkflowName = "WORKFLOW_NAME";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_LockDate = "LOCK_DATE";
/*     */   public static final String S_WorkflowCreateStaffId = "WORKFLOW_CREATE_STAFF_ID";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_WorkflowObjectId = "WORKFLOW_OBJECT_ID";
/*     */   public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
/*     */   public static final String S_TaskStaffId = "TASK_STAFF_ID";
/*     */   public static final String S_LockStaffId = "LOCK_STAFF_ID";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_WorkflowCode = "WORKFLOW_CODE";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_WorkflowParentTaskId = "WORKFLOW_PARENT_TASK_ID";
/*     */   public static final String S_WorkflowKind = "WORKFLOW_KIND";
/*     */   public static final String S_StationId = "STATION_ID";
/*     */   public static final String S_WorkflowTaskTemplateId = "WORKFLOW_TASK_TEMPLATE_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_TaskBaseType = "TASK_BASE_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_WorkflowDuration = "WORKFLOW_DURATION";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_workflowErrorMessage = "WORKFLOW_ERROR_MESSAGE";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_TaskId = "TASK_ID";
/*     */   public static final String S_WorkflowState = "WORKFLOW_STATE";
/*     */   public static final String S_IsCurrentTask = "IS_CURRENT_TASK";
/*     */   public static final String S_FinishStaffId = "FINISH_STAFF_ID";
/*     */   public static final String S_DecisionResult = "DECISION_RESULT";
/*     */   public static final String S_LastTaskId = "LAST_TASK_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_WorkflowWarningDate = "WORKFLOW_WARNING_DATE";
/*     */   public static final String S_WorkflowWarningTimes = "WORKFLOW_WARNING_TIMES";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_ChildWorkflowCount = "CHILD_WORKFLOW_COUNT";
/*     */   int state;
/*     */   String stationId;
/*     */   long duration;
/*     */   Timestamp workflowCreateDate;
/*     */   Timestamp createDate;
/*     */   String workflowName;
/*     */   String workflowCode;
/*     */   String taskTag;
/*     */   String workflowId;
/*     */   String errorMessage;
/*     */   String workflowErrorMessage;
/*     */   String label;
/*     */   String workflowObjectId;
/*     */   String workflowObjectType;
/*     */   String description;
/*     */   String taskId;
/*     */   String taskStaffId;
/*     */   int workflowState;
/*     */   Timestamp finishDate;
/*     */   long taskTemplateId;
/*     */   String finishStaffId;
/*     */   String decisionResult;
/*     */   String parentTaskId;
/*     */   String tasktype;
/*     */   String taskBasetype;
/*     */   String isCurrentTask;
/*     */   Timestamp stateDate;
/*     */   String lockStaffId;
/*     */   Timestamp lockDate;
/*     */   long workflowTaskTemplateId;
/*     */   String workflowParentTaskId;
/*     */   int workflowKind;
/*     */   long workflowDuration;
/*     */   String workflowCreateStaffId;
/*     */   String lastTaskId;
/*     */   String queueId;
/*     */   String regionId;
/*     */   Timestamp warningDate;
/*     */   int warningTimes;
/*     */   Timestamp workflowWarningDate;
/*     */   int workflowWarningTimes;
/*     */   long childWorkflowCount;
/*     */ 
/*     */   public long getChildWorkflowCount()
/*     */   {
/* 109 */     return this.childWorkflowCount;
/*     */   }
/*     */ 
/*     */   public void setChildWorkflowCount(long childWorkflowCount) {
/* 113 */     this.childWorkflowCount = childWorkflowCount;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate()
/*     */   {
/* 121 */     return this.createDate;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 125 */     return this.description;
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 129 */     return this.duration;
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 133 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 137 */     return this.finishDate;
/*     */   }
/*     */ 
/*     */   public String getFinishStaffId() {
/* 141 */     return this.finishStaffId;
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 145 */     return this.label;
/*     */   }
/*     */ 
/*     */   public int getState() {
/* 149 */     return this.state;
/*     */   }
/*     */ 
/*     */   public String getStationId() {
/* 153 */     return this.stationId;
/*     */   }
/*     */ 
/*     */   public String getTaskId() {
/* 157 */     return this.taskId;
/*     */   }
/*     */ 
/*     */   public String getTaskStaffId() {
/* 161 */     return this.taskStaffId;
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 165 */     return this.taskTag;
/*     */   }
/*     */ 
/*     */   public Timestamp getWorkflowCreateDate() {
/* 169 */     return this.workflowCreateDate;
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 173 */     return this.taskTemplateId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowId() {
/* 177 */     return this.workflowId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowName() {
/* 181 */     return this.workflowName;
/*     */   }
/*     */ 
/*     */   public String getWorkflowCode() {
/* 185 */     return this.workflowCode;
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectId() {
/* 189 */     return this.workflowObjectId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectType() {
/* 193 */     return this.workflowObjectType;
/*     */   }
/*     */ 
/*     */   public int getWorkflowState() {
/* 197 */     return this.workflowState;
/*     */   }
/*     */ 
/*     */   public void setCreateDate(Timestamp createDate) {
/* 201 */     this.createDate = createDate;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) {
/* 205 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public void setDuration(long duration) {
/* 209 */     this.duration = duration;
/*     */   }
/*     */ 
/*     */   public void setErrorMessage(String errorMessage) {
/* 213 */     this.errorMessage = errorMessage;
/*     */   }
/*     */ 
/*     */   public void setFinishDate(Timestamp finishDate) {
/* 217 */     this.finishDate = finishDate;
/*     */   }
/*     */ 
/*     */   public void setFinishStaffId(String finishStaffId) {
/* 221 */     this.finishStaffId = finishStaffId;
/*     */   }
/*     */ 
/*     */   public void setLabel(String label) {
/* 225 */     this.label = label;
/*     */   }
/*     */ 
/*     */   public void setState(int state) {
/* 229 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public void setStationId(String stationId) {
/* 233 */     this.stationId = stationId;
/*     */   }
/*     */ 
/*     */   public void setTaskId(String taskId) {
/* 237 */     this.taskId = taskId;
/*     */   }
/*     */ 
/*     */   public void setTaskStaffId(String taskStaffId) {
/* 241 */     this.taskStaffId = taskStaffId;
/*     */   }
/*     */ 
/*     */   public void setTaskTag(String taskTag) {
/* 245 */     this.taskTag = taskTag;
/*     */   }
/*     */ 
/*     */   public void setTaskTemplateId(long taskTemplateId) {
/* 249 */     this.taskTemplateId = taskTemplateId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowCreateDate(Timestamp workflowCreateDate) {
/* 253 */     this.workflowCreateDate = workflowCreateDate;
/*     */   }
/*     */ 
/*     */   public void setWorkflowId(String workflowId) {
/* 257 */     this.workflowId = workflowId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowName(String workflowName) {
/* 261 */     this.workflowName = workflowName;
/*     */   }
/*     */ 
/*     */   public void setWorkflowCode(String workflowCode) {
/* 265 */     this.workflowCode = workflowCode;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjectId(String workflowObjectId) {
/* 269 */     this.workflowObjectId = workflowObjectId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowState(int workflowState) {
/* 273 */     this.workflowState = workflowState;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjectType(String workflowObjectType) {
/* 277 */     this.workflowObjectType = workflowObjectType;
/*     */   }
/*     */ 
/*     */   public String getTasktype() {
/* 281 */     return this.tasktype;
/*     */   }
/*     */ 
/*     */   public void setTasktype(String tasktype) {
/* 285 */     this.tasktype = tasktype;
/*     */   }
/*     */ 
/*     */   public String getIsCurrentTask() {
/* 289 */     return this.isCurrentTask;
/*     */   }
/*     */ 
/*     */   public void setIsCurrentTask(String isCurrentTask) {
/* 293 */     this.isCurrentTask = isCurrentTask;
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 297 */     return this.stateDate;
/*     */   }
/*     */ 
/*     */   public void setStateDate(Timestamp stateDate) {
/* 301 */     this.stateDate = stateDate;
/*     */   }
/*     */ 
/*     */   public String getLockStaffId() {
/* 305 */     return this.lockStaffId;
/*     */   }
/*     */ 
/*     */   public void setLockStaffId(String lockStaffId) {
/* 309 */     this.lockStaffId = lockStaffId;
/*     */   }
/*     */ 
/*     */   public Timestamp getLockDate() {
/* 313 */     return this.lockDate;
/*     */   }
/*     */ 
/*     */   public void setLockDate(Timestamp lockDate) {
/* 317 */     this.lockDate = lockDate;
/*     */   }
/*     */ 
/*     */   public long getWorkflowTaskTemplateId() {
/* 321 */     return this.workflowTaskTemplateId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowTaskTemplateId(long workflowTaskTemplateId) {
/* 325 */     this.workflowTaskTemplateId = workflowTaskTemplateId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowParentTaskId() {
/* 329 */     return this.workflowParentTaskId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowParentTaskId(String workflowParentTaskId) {
/* 333 */     this.workflowParentTaskId = workflowParentTaskId;
/*     */   }
/*     */ 
/*     */   public int getWorkflowKind() {
/* 337 */     return this.workflowKind;
/*     */   }
/*     */ 
/*     */   public void setWorkflowKind(int workflowKind) {
/* 341 */     this.workflowKind = workflowKind;
/*     */   }
/*     */ 
/*     */   public long getWorkflowDuration() {
/* 345 */     return this.workflowDuration;
/*     */   }
/*     */ 
/*     */   public void setWorkflowDuration(long workflowDuration) {
/* 349 */     this.workflowDuration = workflowDuration;
/*     */   }
/*     */ 
/*     */   public String getWorkflowCreateStaffId() {
/* 353 */     return this.workflowCreateStaffId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowCreateStaffId(String workflowCreateStaffId) {
/* 357 */     this.workflowCreateStaffId = workflowCreateStaffId;
/*     */   }
/*     */ 
/*     */   public String getDecisionResult() {
/* 361 */     return this.decisionResult;
/*     */   }
/*     */ 
/*     */   public void setDecisionResult(String decisionResult) {
/* 365 */     this.decisionResult = decisionResult;
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 369 */     return this.parentTaskId;
/*     */   }
/*     */ 
/*     */   public void setParentTaskId(String parentTaskId) {
/* 373 */     this.parentTaskId = parentTaskId;
/*     */   }
/*     */ 
/*     */   public String getLastTaskId() {
/* 377 */     return this.lastTaskId;
/*     */   }
/*     */ 
/*     */   public void setLastTaskId(String lastTaskId) {
/* 381 */     this.lastTaskId = lastTaskId;
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 385 */     return this.queueId;
/*     */   }
/*     */ 
/*     */   public void setQueueId(String queueId) {
/* 389 */     this.queueId = queueId;
/*     */   }
/*     */ 
/*     */   public Timestamp getWarningDate() {
/* 393 */     return this.warningDate;
/*     */   }
/*     */ 
/*     */   public void setWarningDate(Timestamp warningDate) {
/* 397 */     this.warningDate = warningDate;
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/* 401 */     return this.warningTimes;
/*     */   }
/*     */ 
/*     */   public void setWarningTimes(int warningTimes) {
/* 405 */     this.warningTimes = warningTimes;
/*     */   }
/*     */ 
/*     */   public Timestamp getWorkflowWarningDate() {
/* 409 */     return this.workflowWarningDate;
/*     */   }
/*     */ 
/*     */   public void setWorkflowWarningDate(Timestamp workflowWarningDate) {
/* 413 */     this.workflowWarningDate = workflowWarningDate;
/*     */   }
/*     */ 
/*     */   public int getWorkflowWarningTimes() {
/* 417 */     return this.workflowWarningTimes;
/*     */   }
/*     */ 
/*     */   public void setWorkflowWarningTimes(int workflowWarningTimes) {
/* 421 */     this.workflowWarningTimes = workflowWarningTimes;
/*     */   }
/*     */ 
/*     */   public String getTaskBasetype() {
/* 425 */     return this.taskBasetype;
/*     */   }
/*     */ 
/*     */   public void setTaskBasetype(String taskBasetype) {
/* 429 */     this.taskBasetype = taskBasetype;
/*     */   }
/*     */ 
/*     */   public String getWorkflowErrorMessage() {
/* 433 */     return this.workflowErrorMessage;
/*     */   }
/*     */ 
/*     */   public void setWorkflowErrorMessage(String workflowErrorMessage) {
/* 437 */     this.workflowErrorMessage = workflowErrorMessage;
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 441 */     return this.regionId;
/*     */   }
/*     */ 
/*     */   public void setRegionId(String regionId) {
/* 445 */     this.regionId = regionId;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.TaskInfo
 * JD-Core Version:    0.5.4
 */