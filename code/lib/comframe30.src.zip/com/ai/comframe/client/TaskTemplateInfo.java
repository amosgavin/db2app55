/*    */ package com.ai.comframe.client;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TaskTemplateInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -2091802486478496515L;
/*    */   private long task_template_id;
/*    */   private String label;
/*    */   private String task_type;
/*    */   private String task_type_base;
/*    */   private String task_tag;
/*    */   private long workflow_template_id;
/*    */   private String workflow_template_code;
/*    */ 
/*    */   public String getLabel()
/*    */   {
/* 16 */     return this.label;
/*    */   }
/*    */   public void setLabel(String label) {
/* 19 */     this.label = label;
/*    */   }
/*    */   public String getTask_tag() {
/* 22 */     return this.task_tag;
/*    */   }
/*    */   public void setTask_tag(String task_tag) {
/* 25 */     this.task_tag = task_tag;
/*    */   }
/*    */   public long getTask_template_id() {
/* 28 */     return this.task_template_id;
/*    */   }
/*    */   public void setTask_template_id(long task_template_id) {
/* 31 */     this.task_template_id = task_template_id;
/*    */   }
/*    */   public String getTask_type() {
/* 34 */     return this.task_type;
/*    */   }
/*    */   public void setTask_type(String task_type) {
/* 37 */     this.task_type = task_type;
/*    */   }
/*    */   public String getTask_type_base() {
/* 40 */     return this.task_type_base;
/*    */   }
/*    */   public void setTask_type_base(String task_type_base) {
/* 43 */     this.task_type_base = task_type_base;
/*    */   }
/*    */   public String getWorkflow_template_code() {
/* 46 */     return this.workflow_template_code;
/*    */   }
/*    */   public void setWorkflow_template_code(String workflow_template_code) {
/* 49 */     this.workflow_template_code = workflow_template_code;
/*    */   }
/*    */   public long getWorkflow_template_id() {
/* 52 */     return this.workflow_template_id;
/*    */   }
/*    */   public void setWorkflow_template_id(long workflow_template_id) {
/* 55 */     this.workflow_template_id = workflow_template_id;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.TaskTemplateInfo
 * JD-Core Version:    0.5.4
 */