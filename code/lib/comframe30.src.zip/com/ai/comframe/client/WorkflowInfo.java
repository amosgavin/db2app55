/*     */ package com.ai.comframe.client;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class WorkflowInfo
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -7201752866723623460L;
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_OpStaffId = "OP_STAFF_ID";
/*     */   public static final String S_Duration = "DURATION";
/*     */   public static final String S_StateDate = "STATE_DATE";
/*     */   public static final String S_WorkflowKind = "WORKFLOW_KIND";
/*     */   public static final String S_ParentTaskId = "PARENT_TASK_ID";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_CreateStaffId = "CREATE_STAFF_ID";
/*     */   public static final String S_Vars = "VARS";
/*     */   public static final String S_TaskTag = "TASK_TAG";
/*     */   public static final String S_TaskType = "TASK_TYPE";
/*     */   public static final String S_ErrorCount = "ERROR_COUNT";
/*     */   public static final String S_UserTaskCount = "USER_TASK_COUNT";
/*     */   public static final String S_ErrorMessage = "ERROR_MESSAGE";
/*     */   public static final String S_Label = "LABEL";
/*     */   public static final String S_WorkflowObjectId = "WORKFLOW_OBJECT_ID";
/*     */   public static final String S_WorkflowObjectType = "WORKFLOW_OBJECT_TYPE";
/*     */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_FinishDate = "FINISH_DATE";
/*     */   public static final String S_TaskTemplateId = "TASK_TEMPLATE_ID";
/*     */   public static final String S_CurrentTaskId = "CURRENT_TASK_ID";
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_DistrictId = "DISTRICT_ID";
/*     */   public static final String S_EngineWorkflowId = "ENGINE_WORKFLOW_ID";
/*     */   public static final String S_EngineType = "ENGINE_TYPE";
/*     */   public static final String S_StartDate = "START_DATE";
/*     */   public static final String S_WarningDate = "WARNING_DATE";
/*     */   public static final String S_WarningTimes = "WARNING_TIMES";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   int state;
/*     */   String opStaffId;
/*     */   long duration;
/*     */   Timestamp createDate;
/*     */   Timestamp stateDate;
/*     */   int workflowKind;
/*     */   String parentTaskId;
/*     */   String createStaffId;
/*     */   String vars;
/*     */   String taskTag;
/*     */   String taskType;
/*     */   long errorCount;
/*     */   long userTaskCout;
/*     */   String errorMessage;
/*     */   String label;
/*     */   String workflowObjectId;
/*     */   String workflowObjectType;
/*     */   String workflowId;
/*     */   String regionId;
/*     */   String description;
/*     */   Timestamp finishDate;
/*     */   long taskTemplateId;
/*     */   String currentTaskId;
/*     */   String queueId;
/*     */   String districtId;
/*     */   String engineWorkflowId;
/*     */   String engineType;
/*     */   Timestamp startDate;
/*     */   Timestamp warningDate;
/*     */   int warningTimes;
/*     */ 
/*     */   public Timestamp getWarningDate()
/*     */   {
/*  84 */     return this.warningDate;
/*     */   }
/*     */ 
/*     */   public void setWarningDate(Timestamp warningDate) {
/*  88 */     this.warningDate = warningDate;
/*     */   }
/*     */ 
/*     */   public int getWarningTimes() {
/*  92 */     return this.warningTimes;
/*     */   }
/*     */ 
/*     */   public void setWarningTimes(int warningTimes) {
/*  96 */     this.warningTimes = warningTimes;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate()
/*     */   {
/* 103 */     return this.createDate;
/*     */   }
/*     */ 
/*     */   public void setCreateDate(Timestamp createDate) {
/* 107 */     this.createDate = createDate;
/*     */   }
/*     */ 
/*     */   public String getCreateStaffId() {
/* 111 */     return this.createStaffId;
/*     */   }
/*     */ 
/*     */   public void setCreateStaffId(String createStaffId) {
/* 115 */     this.createStaffId = createStaffId;
/*     */   }
/*     */ 
/*     */   public String getCurrentTaskId() {
/* 119 */     return this.currentTaskId;
/*     */   }
/*     */ 
/*     */   public void setCurrentTaskId(String currentTaskId) {
/* 123 */     this.currentTaskId = currentTaskId;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 127 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) {
/* 131 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public String getDistrictId() {
/* 135 */     return this.districtId;
/*     */   }
/*     */ 
/*     */   public void setDistrictId(String districtId) {
/* 139 */     this.districtId = districtId;
/*     */   }
/*     */ 
/*     */   public long getDuration() {
/* 143 */     return this.duration;
/*     */   }
/*     */ 
/*     */   public void setDuration(long duration) {
/* 147 */     this.duration = duration;
/*     */   }
/*     */ 
/*     */   public String getEngineType() {
/* 151 */     return this.engineType;
/*     */   }
/*     */ 
/*     */   public void setEngineType(String engineType) {
/* 155 */     this.engineType = engineType;
/*     */   }
/*     */ 
/*     */   public String getEngineWorkflowId() {
/* 159 */     return this.engineWorkflowId;
/*     */   }
/*     */ 
/*     */   public void setEngineWorkflowId(String engineWorkflowId) {
/* 163 */     this.engineWorkflowId = engineWorkflowId;
/*     */   }
/*     */ 
/*     */   public long getErrorCount() {
/* 167 */     return this.errorCount;
/*     */   }
/*     */ 
/*     */   public void setErrorCount(long errorCount) {
/* 171 */     this.errorCount = errorCount;
/*     */   }
/*     */ 
/*     */   public String getErrorMessage() {
/* 175 */     return this.errorMessage;
/*     */   }
/*     */ 
/*     */   public void setErrorMessage(String errorMessage) {
/* 179 */     this.errorMessage = errorMessage;
/*     */   }
/*     */ 
/*     */   public Timestamp getFinishDate() {
/* 183 */     return this.finishDate;
/*     */   }
/*     */ 
/*     */   public void setFinishDate(Timestamp finishDate) {
/* 187 */     this.finishDate = finishDate;
/*     */   }
/*     */ 
/*     */   public int getWorkflowKind() {
/* 191 */     return this.workflowKind;
/*     */   }
/*     */ 
/*     */   public void setWorkflowKind(int workflowKind) {
/* 195 */     this.workflowKind = workflowKind;
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 199 */     return this.label;
/*     */   }
/*     */ 
/*     */   public void setLabel(String label) {
/* 203 */     this.label = label;
/*     */   }
/*     */ 
/*     */   public String getOpStaffId() {
/* 207 */     return this.opStaffId;
/*     */   }
/*     */ 
/*     */   public void setOpStaffId(String opStaffId) {
/* 211 */     this.opStaffId = opStaffId;
/*     */   }
/*     */ 
/*     */   public String getParentTaskId() {
/* 215 */     return this.parentTaskId;
/*     */   }
/*     */ 
/*     */   public void setParentTaskId(String parentTaskId) {
/* 219 */     this.parentTaskId = parentTaskId;
/*     */   }
/*     */ 
/*     */   public String getQueueId() {
/* 223 */     return this.queueId;
/*     */   }
/*     */ 
/*     */   public void setQueueId(String queueId) {
/* 227 */     this.queueId = queueId;
/*     */   }
/*     */ 
/*     */   public Timestamp getStartDate() {
/* 231 */     return this.startDate;
/*     */   }
/*     */ 
/*     */   public void setStartDate(Timestamp startDate) {
/* 235 */     this.startDate = startDate;
/*     */   }
/*     */ 
/*     */   public int getState() {
/* 239 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setState(int state) {
/* 243 */     this.state = state;
/*     */   }
/*     */ 
/*     */   public Timestamp getStateDate() {
/* 247 */     return this.stateDate;
/*     */   }
/*     */ 
/*     */   public void setStateDate(Timestamp stateDate) {
/* 251 */     this.stateDate = stateDate;
/*     */   }
/*     */ 
/*     */   public String getWorkflowId()
/*     */   {
/* 257 */     return this.workflowId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowId(String workflowId) {
/* 261 */     this.workflowId = workflowId;
/*     */   }
/*     */ 
/*     */   public String getTaskTag() {
/* 265 */     return this.taskTag;
/*     */   }
/*     */ 
/*     */   public void setTaskTag(String taskTag) {
/* 269 */     this.taskTag = taskTag;
/*     */   }
/*     */ 
/*     */   public long getTaskTemplateId() {
/* 273 */     return this.taskTemplateId;
/*     */   }
/*     */ 
/*     */   public void setTaskTemplateId(long taskTemplateId) {
/* 277 */     this.taskTemplateId = taskTemplateId;
/*     */   }
/*     */ 
/*     */   public String getTaskType() {
/* 281 */     return this.taskType;
/*     */   }
/*     */ 
/*     */   public void setTaskType(String taskType) {
/* 285 */     this.taskType = taskType;
/*     */   }
/*     */ 
/*     */   public long getUserTaskCout() {
/* 289 */     return this.userTaskCout;
/*     */   }
/*     */ 
/*     */   public void setUserTaskCout(long userTaskCout) {
/* 293 */     this.userTaskCout = userTaskCout;
/*     */   }
/*     */ 
/*     */   public String getVars() {
/* 297 */     return this.vars;
/*     */   }
/*     */ 
/*     */   public void setVars(String vars) {
/* 301 */     this.vars = vars;
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectId() {
/* 305 */     return this.workflowObjectId;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjectId(String workflowObjectId) {
/* 309 */     this.workflowObjectId = workflowObjectId;
/*     */   }
/*     */ 
/*     */   public String getWorkflowObjectType() {
/* 313 */     return this.workflowObjectType;
/*     */   }
/*     */ 
/*     */   public void setWorkflowObjectType(String workflowObjectType) {
/* 317 */     this.workflowObjectType = workflowObjectType;
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/* 321 */     return this.regionId;
/*     */   }
/*     */ 
/*     */   public void setRegionId(String regionId) {
/* 325 */     this.regionId = regionId;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.WorkflowInfo
 * JD-Core Version:    0.5.4
 */