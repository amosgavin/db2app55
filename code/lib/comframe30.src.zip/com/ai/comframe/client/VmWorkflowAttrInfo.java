/*    */ package com.ai.comframe.client;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class VmWorkflowAttrInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -6633929908479133185L;
/*    */   public static final String S_WorkflowId = "WORKFLOW_ID";
/*    */   public static final String S_AttrName = "ATTR_NAME";
/*    */   public static final String S_AttrCode = "ATTR_CODE";
/*    */   public static final String S_AttrId = "ATTR_ID";
/*    */   public static final String S_AttrValue = "ATTR_VALUE";
/*    */   String workflowId;
/*    */   long attrId;
/*    */   String attrName;
/*    */   String attrCode;
/*    */   String attrValue;
/*    */ 
/*    */   public String getAttrCode()
/*    */   {
/* 20 */     return this.attrCode;
/*    */   }
/*    */   public void setAttrCode(String attrCode) {
/* 23 */     this.attrCode = attrCode;
/*    */   }
/*    */   public long getAttrId() {
/* 26 */     return this.attrId;
/*    */   }
/*    */   public void setAttrId(long attrId) {
/* 29 */     this.attrId = attrId;
/*    */   }
/*    */   public String getAttrName() {
/* 32 */     return this.attrName;
/*    */   }
/*    */   public void setAttrName(String attrName) {
/* 35 */     this.attrName = attrName;
/*    */   }
/*    */   public String getAttrValue() {
/* 38 */     return this.attrValue;
/*    */   }
/*    */   public void setAttrValue(String attrValue) {
/* 41 */     this.attrValue = attrValue;
/*    */   }
/*    */   public String getWorkflowId() {
/* 44 */     return this.workflowId;
/*    */   }
/*    */   public void setWorkflowId(String workflowId) {
/* 47 */     this.workflowId = workflowId;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.VmWorkflowAttrInfo
 * JD-Core Version:    0.5.4
 */