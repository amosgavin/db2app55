/*     */ package com.ai.comframe.client;
/*     */ 
/*     */ import com.ai.appframe2.common.AIRootConfig;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class Config
/*     */ {
/*  27 */   private static Properties CONFIG = null;
/*     */ 
/*     */   public static Properties getConfigInfo() throws Exception {
/*     */     try { InputStream in = AIRootConfig.getConfigInfo("comframe.ini");
/*  31 */       if (in == null)
/*  32 */         return null;
/*  33 */       CONFIG = new Properties();
/*  34 */       CONFIG.load(in);
/*  35 */       return CONFIG;
/*     */     } catch (IOException ex)
/*     */     {
/*  38 */       ex.printStackTrace();
/*  39 */     }return null;
/*     */   }
/*     */ 
/*     */   public static String getProperty(String key) throws Exception
/*     */   {
/*  44 */     return getProperty(key, null);
/*     */   }
/*     */   public static String getProperty(String key, String defaultValue) throws Exception {
/*  47 */     if (CONFIG == null) {
/*  48 */       CONFIG = getConfigInfo();
/*     */     }
/*  50 */     if (CONFIG != null) {
/*  51 */       String value = CONFIG.getProperty(key, defaultValue);
/*  52 */       if (value != null) {
/*  53 */         return new String(value.getBytes("ISO-8859-1"), "GBK");
/*     */       }
/*     */     }
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   public static InputStream getResourceAsStream(Class aClass, String fileName) {
/*  60 */     InputStream result = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/*  61 */     if (result == null) {
/*  62 */       result = aClass.getClassLoader().getResourceAsStream(fileName);
/*     */     }
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */   public static List parseProperties(Properties props, String keyPrefix) {
/*  68 */     Iterator iter = props.keySet().iterator();
/*  69 */     List listL = new ArrayList();
/*  70 */     Hashtable tmpHashMap = new Hashtable();
/*  71 */     while (iter.hasNext()) {
/*  72 */       String key = (String)iter.next();
/*  73 */       if (key.indexOf(keyPrefix) != 0)
/*     */         continue;
/*  75 */       key = key.substring(keyPrefix.length());
/*  76 */       String[] tempArray = StringUtils.splitString(key, ".");
/*  77 */       for (int i = 0; i < tempArray.length; ++i) {
/*  78 */         tmpHashMap.put("L" + i + "|" + tempArray[i], "L" + i + "|" + tempArray[i]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  83 */     Iterator iter2 = tmpHashMap.keySet().iterator();
/*  84 */     while (iter2.hasNext()) {
/*  85 */       String key = (String)iter2.next();
/*  86 */       String ii = String.valueOf(tmpHashMap.get(key));
/*  87 */       listL.add(StringUtils.splitString(ii, "|"));
/*     */     }
/*     */ 
/*  90 */     return listL;
/*     */   }
/*     */ 
/*     */   public static String findOut(Properties props, String key, List list, String keyPrefix) {
/*  94 */     String returnValue = null;
/*  95 */     if ((list == null) || (list.size() == 0)) {
/*  96 */       return returnValue;
/*     */     }
/*  98 */     String[] workCode = StringUtils.splitString(key, ".");
/*  99 */     String tmp = "";
/* 100 */     for (int i = 0; i < workCode.length; ++i) {
/* 101 */       if (i == 0)
/* 102 */         tmp = workCode[i];
/*     */       else
/* 104 */         tmp = tmp + "." + workCode[i];
/* 105 */       if ((!isInList(workCode[i], i, list)) || 
/* 106 */         (props.get(keyPrefix + tmp) == null)) continue;
/* 107 */       returnValue = String.valueOf(props.get(keyPrefix + tmp));
/*     */     }
/*     */ 
/* 110 */     return returnValue;
/*     */   }
/*     */ 
/*     */   private static boolean isInList(String tmp, int level, List list) {
/* 114 */     boolean is = false;
/* 115 */     for (int i = 0; i < list.size(); ++i) {
/* 116 */       String[] tmpArray = (String[])(String[])list.get(i);
/* 117 */       if ((("L" + level).equals(tmpArray[0])) && (tmp.equals(tmpArray[1]))) {
/* 118 */         is = true;
/* 119 */         break;
/*     */       }
/*     */     }
/* 122 */     return is;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.client.Config
 * JD-Core Version:    0.5.4
 */