/*     */ package com.ai.comframe;
/*     */ 
/*     */ import com.ai.appframe2.privilege.LoginException;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.privilege.UserManager;
/*     */ import com.ai.appframe2.util.Encrypt;
/*     */ import com.ai.comframe.client.Config;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.frame.loginmgr.AbstractUserManagerImpl;
/*     */ import com.ai.frame.loginmgr.demo.SysFunctionImpl;
/*     */ import com.ai.frame.loginmgr.demo.UserInfoDemoImpl;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class ComframeUserManagerImpl extends AbstractUserManagerImpl
/*     */   implements UserManager
/*     */ {
/*     */   public UserInfoInterface getBlankUserInfo()
/*     */   {
/*  28 */     return new UserInfoDemoImpl();
/*     */   }
/*     */ 
/*     */   public UserInfoInterface loginIn(String pUserCode, String pPassWord, long domainId, int curLoginNum, HttpServletRequest req)
/*     */     throws Exception
/*     */   {
/*  34 */     long loginId = 1L;
/*  35 */     String loginCode = pUserCode;
/*  36 */     String password = Encrypt.DoEncrypt(pPassWord);
/*  37 */     long orgId = 1L;
/*  38 */     String orgName = ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.loginIn_orgName");
/*  39 */     String tmp = Config.getProperty("console.login.id");
/*  40 */     String regionID = "";
/*  41 */     if ((StringUtils.isNotBlank(tmp)) && (StringUtils.isNumeric(tmp))) {
/*  42 */       loginId = Long.parseLong(tmp);
/*     */     }
/*  44 */     tmp = Config.getProperty("console.login.code");
/*  45 */     if (StringUtils.isNotBlank(tmp)) {
/*  46 */       loginCode = tmp;
/*     */     }
/*  48 */     tmp = Config.getProperty("console.login.password");
/*  49 */     if (StringUtils.isNotBlank(tmp)) {
/*  50 */       password = tmp;
/*     */     }
/*  52 */     tmp = Config.getProperty("console.login.org.id");
/*  53 */     if ((StringUtils.isNotBlank(tmp)) && (StringUtils.isNumeric(tmp))) {
/*  54 */       orgId = Long.parseLong(tmp);
/*     */     }
/*  56 */     tmp = Config.getProperty("console.login.org.name");
/*  57 */     if (StringUtils.isNotBlank(tmp)) {
/*  58 */       orgName = tmp;
/*     */     }
/*     */ 
/*  61 */     tmp = Config.getProperty("console.login.region.id");
/*  62 */     if (StringUtils.isNotBlank(tmp)) {
/*  63 */       regionID = tmp;
/*     */     }
/*  65 */     if ((!loginCode.equalsIgnoreCase(pUserCode)) || (!password.equals(Encrypt.DoEncrypt(pPassWord))))
/*     */     {
/*  67 */       throw new LoginException(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.loginIn_nameOrPwdError"));
/*     */     }
/*  69 */     UserInfoDemoImpl user = new UserInfoDemoImpl();
/*  70 */     user.setID(loginId);
/*  71 */     user.setName(loginCode);
/*  72 */     user.setCode(loginCode);
/*  73 */     user.setOrgId(orgId);
/*  74 */     user.set("REGION_ID", regionID);
/*  75 */     user.setOrgName(orgName);
/*  76 */     user.setDomainId(domainId);
/*  77 */     return user;
/*     */   }
/*     */ 
/*     */   public List getUserMenuNodeList(String pStaffCode, String pFuncType, long domainId) throws Exception
/*     */   {
/*  82 */     List list = new ArrayList();
/*     */ 
/*  84 */     SysFunctionImpl bean1 = new SysFunctionImpl();
/*  85 */     bean1.setFuncId(10L);
/*  86 */     bean1.setParentId(40L);
/*  87 */     bean1.setViewname("/workflow/WorkflowInst.jsp");
/*  88 */     bean1.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.loginIn_processIns"));
/*  89 */     list.add(bean1);
/*     */ 
/*  91 */     bean1 = new SysFunctionImpl();
/*  92 */     bean1.setFuncId(11L);
/*  93 */     bean1.setParentId(40L);
/*  94 */     bean1.setViewname("/workflow/WorkflowHisInst.jsp");
/*  95 */     bean1.setName(ComframeLocaleFactory.getResource("com.ai.comframe.comframeusermanageimpl_hisInst"));
/*  96 */     list.add(bean1);
/*     */ 
/*  99 */     bean1 = new SysFunctionImpl();
/* 100 */     bean1.setFuncId(22L);
/* 101 */     bean1.setParentId(1L);
/* 102 */     bean1.setName(ComframeLocaleFactory.getResource("com.ai.comframe.ComframeUserManagerImpl_manageTemplate"));
/* 103 */     list.add(bean1);
/*     */ 
/* 105 */     SysFunctionImpl bean6 = new SysFunctionImpl();
/* 106 */     bean6.setFuncId(60L);
/* 107 */     bean6.setParentId(22L);
/* 108 */     bean6.setViewname("/workflow/TemplateQuery.jsp");
/* 109 */     bean6.setName(ComframeLocaleFactory.getResource("com.ai.comframe.ComframeUserManagerImpl_manageTemplate"));
/* 110 */     list.add(bean6);
/*     */ 
/* 112 */     SysFunctionImpl bean8 = new SysFunctionImpl();
/* 113 */     bean8.setFuncId(80L);
/* 114 */     bean8.setParentId(22L);
/* 115 */     bean8.setViewname("/workflow/TemplatePublish.jsp");
/* 116 */     bean8.setName(ComframeLocaleFactory.getResource("com.ai.comframe.ComframeUserManagerImpl_templateQuery"));
/* 117 */     list.add(bean8);
/*     */ 
/* 119 */     SysFunctionImpl bean2 = new SysFunctionImpl();
/* 120 */     bean2.setFuncId(20L);
/* 121 */     bean2.setParentId(1L);
/* 122 */     bean2.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_exception"));
/* 123 */     list.add(bean2);
/*     */ 
/* 125 */     SysFunctionImpl bean7 = new SysFunctionImpl();
/* 126 */     bean7.setFuncId(70L);
/* 127 */     bean7.setParentId(1L);
/* 128 */     bean7.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_overWarn"));
/* 129 */     list.add(bean7);
/*     */ 
/* 131 */     bean7 = new SysFunctionImpl();
/* 132 */     bean7.setFuncId(71L);
/* 133 */     bean7.setParentId(70L);
/* 134 */     bean7.setViewname("/workflow/Alarm.jsp");
/* 135 */     bean7.setName(ComframeLocaleFactory.getResource("com.ai.comframe.ComframeUserManagerImpl_overWarn"));
/* 136 */     list.add(bean7);
/*     */ 
/* 138 */     bean7 = new SysFunctionImpl();
/* 139 */     bean7.setFuncId(72L);
/* 140 */     bean7.setParentId(70L);
/* 141 */     bean7.setViewname("/workflow/Holiday.jsp");
/* 142 */     bean7.setName(ComframeLocaleFactory.getResource("com.ai.comframe.ComframeUserManagerImpl_holiday"));
/* 143 */     list.add(bean7);
/*     */ 
/* 145 */     bean2 = new SysFunctionImpl();
/* 146 */     bean2.setFuncId(21L);
/* 147 */     bean2.setParentId(20L);
/* 148 */     bean2.setViewname("/workflow/exception/ExceptionCodeMaintain.jsp");
/* 149 */     bean2.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_exceptionCode"));
/* 150 */     list.add(bean2);
/*     */ 
/* 166 */     bean2 = new SysFunctionImpl();
/* 167 */     bean2.setFuncId(24L);
/* 168 */     bean2.setParentId(20L);
/* 169 */     bean2.setViewname("/workflow/exception/Exceptionmaintain.jsp");
/* 170 */     bean2.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_excetionRelate"));
/* 171 */     list.add(bean2);
/*     */ 
/* 180 */     SysFunctionImpl bean4 = new SysFunctionImpl();
/* 181 */     bean4.setFuncId(40L);
/* 182 */     bean4.setParentId(1L);
/* 183 */     bean4.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_processTest"));
/* 184 */     list.add(bean4);
/*     */ 
/* 186 */     SysFunctionImpl bean41 = new SysFunctionImpl();
/* 187 */     bean41.setFuncId(41L);
/* 188 */     bean41.setParentId(40L);
/* 189 */     bean41.setViewname("/workflow/StartWorkFlow.jsp");
/* 190 */     bean41.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_createProcess"));
/* 191 */     list.add(bean41);
/*     */ 
/* 193 */     SysFunctionImpl bean42 = new SysFunctionImpl();
/* 194 */     bean42.setFuncId(42L);
/* 195 */     bean42.setParentId(40L);
/* 196 */     bean42.setViewname("/workflow/TaskInfoMain.jsp");
/* 197 */     bean42.setName(ComframeLocaleFactory.getResource("com.ai.comframe.console.ComframeUserManagerImpl.getUserMenuNodeList_taskDeal"));
/* 198 */     list.add(bean42);
/*     */ 
/* 202 */     SysFunctionImpl bean5 = new SysFunctionImpl();
/* 203 */     bean5.setFuncId(50L);
/* 204 */     bean5.setParentId(1L);
/* 205 */     bean5.setViewname("/workflow/autoform/ObjectItemTree.jsp");
/* 206 */     bean5.setName(ComframeLocaleFactory.getResource("comframe.html.workflow.autoform"));
/* 207 */     list.add(bean5);
/*     */ 
/* 210 */     SysFunctionImpl bean51 = new SysFunctionImpl();
/* 211 */     bean51.setFuncId(51L);
/* 212 */     bean51.setParentId(50L);
/* 213 */     bean51.setViewname("/workflow/autoform/ObjectItemTree.jsp");
/* 214 */     bean51.setName(ComframeLocaleFactory.getResource("comframe.html.workflow.autoform.ObjectItemTree203"));
/* 215 */     list.add(bean51);
/*     */ 
/* 217 */     SysFunctionImpl bean52 = new SysFunctionImpl();
/* 218 */     bean52.setFuncId(52L);
/* 219 */     bean52.setParentId(50L);
/* 220 */     bean52.setViewname("/workflow/autoform/TaskMultaddUrl.jsp");
/* 221 */     bean52.setName(ComframeLocaleFactory.getResource("comframe.html.workflow.autoform.objectInfoMain16"));
/* 222 */     list.add(bean52);
/*     */ 
/* 224 */     return list;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.ComframeUserManagerImpl
 * JD-Core Version:    0.5.4
 */