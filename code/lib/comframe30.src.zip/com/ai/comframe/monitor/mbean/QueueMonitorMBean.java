package com.ai.comframe.monitor.mbean;

public abstract interface QueueMonitorMBean
{
  public abstract String reportActive();
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.monitor.mbean.QueueMonitorMBean
 * JD-Core Version:    0.5.4
 */