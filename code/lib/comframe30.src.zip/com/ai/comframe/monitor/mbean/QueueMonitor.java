/*    */ package com.ai.comframe.monitor.mbean;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class QueueMonitor
/*    */   implements QueueMonitorMBean
/*    */ {
/*    */   public String reportActive()
/*    */   {
/*  9 */     System.out.println("report active...jvm currnetTime:" + new Timestamp(System.currentTimeMillis()));
/* 10 */     return "active";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.monitor.mbean.QueueMonitor
 * JD-Core Version:    0.5.4
 */