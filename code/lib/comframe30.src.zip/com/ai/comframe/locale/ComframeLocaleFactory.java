/*     */ package com.ai.comframe.locale;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AII18NException;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ComframeLocaleFactory
/*     */ {
/*     */   private static final String RESOURCE_BUNDLE_NAME = "i18n.comframe_resource";
/*  14 */   private static transient Log log = LogFactory.getLog(ComframeLocaleFactory.class);
/*     */ 
/*     */   public static String getStrLocale()
/*     */   {
/*  18 */     String strLocale = null;
/*     */     try {
/*  20 */       Locale locale = AppframeLocaleFactory.getCurrentLocale();
/*  21 */       if (locale != null)
/*  22 */         strLocale = locale.toString();
/*     */       else
/*  24 */         strLocale = Locale.CHINA.toString();
/*     */     } catch (Throwable e) {
/*  26 */       log.error("getStrLocale error: " + e.getMessage());
/*  27 */       strLocale = Locale.CHINA.toString();
/*     */     }
/*  29 */     return strLocale;
/*     */   }
/*     */ 
/*     */   public static String getResource(String pKey)
/*     */   {
/*     */     try
/*     */     {
/*  42 */       return AppframeLocaleFactory.getResource("i18n.comframe_resource", pKey);
/*     */     } catch (Throwable e) {
/*  44 */       log.error("Getting resource " + pKey + " from " + "i18n.comframe_resource" + " is error:" + e.getMessage());
/*     */     }
/*  46 */     return pKey;
/*     */   }
/*     */ 
/*     */   public static String getResource(String pKey, Object[] pParams)
/*     */   {
/*     */     try
/*     */     {
/*  60 */       return AppframeLocaleFactory.getResource("i18n.comframe_resource", pKey, pParams);
/*     */     }
/*     */     catch (Throwable e) {
/*  63 */       log.error("Getting resource " + pKey + " from " + "i18n.comframe_resource" + " is error:" + e.getMessage());
/*     */     }
/*  65 */     return pKey;
/*     */   }
/*     */ 
/*     */   public static String getResource(String pRes, String pKey)
/*     */   {
/*  80 */     if (StringUtils.isBlank(pRes))
/*  81 */       return pKey;
/*     */     try {
/*  83 */       return AppframeLocaleFactory.getResource(pRes, pKey);
/*     */     } catch (Throwable e) {
/*  85 */       log.error("Getting resource " + pKey + " from " + pRes + " is error:" + e.getMessage());
/*     */     }
/*  87 */     return pKey;
/*     */   }
/*     */ 
/*     */   public static String getResource(String pRes, String pKey, Object[] pParams)
/*     */   {
/* 104 */     if (StringUtils.isBlank(pRes))
/* 105 */       return pKey;
/*     */     try {
/* 107 */       return AppframeLocaleFactory.getResource(pRes, pKey, pParams);
/*     */     } catch (Throwable e) {
/* 109 */       log.error("Getting resource " + pKey + " from " + pRes + " is error:" + e.getMessage());
/*     */     }
/* 111 */     return pKey;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 117 */       throw new AII18NException("com.ai.appframe2.init_error");
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 121 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.locale.ComframeLocaleFactory
 * JD-Core Version:    0.5.4
 */