/*     */ package com.ai.comframe.ant;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileWriter;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ 
/*     */ public class CreateTemplateDeployScriptTask extends Task
/*     */ {
/*     */   private List fileSets;
/*     */   private String destPath;
/*     */   private String expireDate;
/*     */ 
/*     */   public CreateTemplateDeployScriptTask()
/*     */   {
/*  23 */     this.fileSets = new LinkedList();
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet)
/*     */   {
/*  28 */     this.fileSets.add(fileSet);
/*     */   }
/*     */ 
/*     */   public void execute() throws BuildException
/*     */   {
/*  36 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */     Iterator iter;
/*     */     try {
/*  38 */       Thread.currentThread().setContextClassLoader(CreateTemplateDeployScriptTask.class.getClassLoader());
/*     */ 
/*  40 */       if (StringUtils.isBlank(this.destPath)) {
/*  41 */         throw new Exception("ant 任务必须设置destPath 属性");
/*     */       }
/*     */ 
/*  44 */       for (iter = getFiles().iterator(); iter.hasNext(); ) {
/*  45 */         File item = (File)iter.next();
/*  46 */         if (!item.getName().endsWith(".jar"))
/*     */         {
/*  48 */           log(item.getName() + "，不是jar类型文件!");
/*     */         }
/*     */ 
/*  51 */         JarInputStream jis = new JarInputStream(new BufferedInputStream(new FileInputStream(item)));
/*  52 */         JarEntry jarEntry = null;
/*  53 */         InputStream input = null;
/*  54 */         while ((jarEntry = jis.getNextJarEntry()) != null) {
/*  55 */           if ((!jarEntry.isDirectory()) && (jarEntry.getName().endsWith(".wvm")));
/*  56 */           String fileName = jarEntry.getName();
/*  57 */           String tmpStr = StringUtils.replace(fileName, ".wvm", "");
/*  58 */           tmpStr = StringUtils.replace(tmpStr, "/", ".");
/*     */ 
/*  60 */           input = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/*     */ 
/*  62 */           BufferedReader br = new BufferedReader(new InputStreamReader(input));
/*     */ 
/*  64 */           StringBuilder content = new StringBuilder("");
/*  65 */           String line = null;
/*  66 */           while ((line = br.readLine()) != null) {
/*  67 */             content.append(line);
/*     */           }
/*  69 */           br.close();
/*     */ 
/*  71 */           if ((content == null) || ("".equals(content.toString().trim()))) {
/*  72 */             throw new Exception("文件：" + fileName + "，内容为空!");
/*     */           }
/*  74 */           if (content.toString().indexOf("tasktype=\"workflow\"") > -1) {
/*  75 */             System.out.println("生成模板发布脚本：" + fileName);
/*     */ 
/*  78 */             createScript(tmpStr, content.toString());
/*     */           }
/*     */ 
/*  81 */           input.close();
/*     */         }
/*     */ 
/*  84 */         jis.close();
/*     */       }
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/*     */     finally {
/*  91 */       if (old != null)
/*  92 */         Thread.currentThread().setContextClassLoader(old);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void createScript(String taskTag, String content)
/*     */     throws Exception
/*     */   {
/*  99 */     String fileName = taskTag + ".sql";
/* 100 */     String[] contents = splitString(content, 2000);
/* 101 */     FileWriter fw = new FileWriter(new File(getDestPath() + "/" + fileName));
/*     */ 
/* 103 */     StringBuilder sb = new StringBuilder("");
/* 104 */     sb.append(" update vm_template_version a set a.expire_date = sysdate \n");
/* 105 */     sb.append(" where a.template_version_id = ( \n");
/* 106 */     sb.append(" select max(b.template_version_id)  from vm_template_version b where \n");
/* 107 */     sb.append(" b.template_tag = '").append(taskTag).append("');\n\n");
/*     */ 
/* 109 */     fw.write(sb.toString());
/*     */ 
/* 111 */     StringBuilder insert = new StringBuilder("");
/* 112 */     StringBuilder value = new StringBuilder("");
/* 113 */     int rowNum = 0;
/* 114 */     for (int j = 0; j < contents.length; ++j) {
/* 115 */       if ((j + (rowNum + 1) * 16) % 16 == 0) {
/* 116 */         if (j != 0) {
/* 117 */           ++rowNum;
/* 118 */           String temp = (value + ";\n\n").replaceAll("content0", "content");
/*     */ 
/* 120 */           fw.write(temp);
/*     */         }
/*     */ 
/* 123 */         insert = new StringBuilder("");
/* 124 */         value = new StringBuilder("");
/* 125 */         insert.append(" insert into vm_template_version (template_version_id,\n");
/* 126 */         insert.append(" order_num,\n");
/* 127 */         insert.append(" template_tag,\n");
/* 128 */         insert.append(" create_staff_id,\n");
/* 129 */         insert.append(" create_date,\n");
/* 130 */         insert.append(" valid_date,\n");
/* 131 */         insert.append(" expire_date,\n");
/*     */ 
/* 133 */         value.append(" values ( \n");
/* 134 */         value.append(" vm_template_version$seq.nextval, \n");
/* 135 */         value.append(rowNum + " , \n");
/* 136 */         value.append(" '").append(taskTag).append("', \n");
/* 137 */         value.append(" '1', \n");
/* 138 */         value.append(" sysdate, \n");
/* 139 */         value.append(" sysdate, \n");
/* 140 */         if (StringUtils.isEmpty(getExpireDate()))
/* 141 */           value.append(" sysdate+365, \n");
/*     */         else {
/* 143 */           value.append(" to_date('").append(getExpireDate()).append("','yyyy-mm-dd hh24:mi:ss'), \n");
/*     */         }
/*     */       }
/*     */ 
/* 147 */       if (j - rowNum * 16 == contents.length - rowNum * 16 - 1) {
/* 148 */         insert.append(" content").append(j).append(" )\n");
/* 149 */         value.append("'").append(contents[j]).append("' )\n");
/*     */       } else {
/* 151 */         insert.append(" content").append(j).append(",\n");
/* 152 */         value.append("'").append(contents[j]).append("',\n");
/*     */       }
/*     */     }
/*     */ 
/* 156 */     String temp = (value + ";\n\n" + "commit;\n").replaceAll("content0", "content");
/*     */ 
/* 158 */     fw.write(temp);
/* 159 */     fw.flush();
/*     */   }
/*     */ 
/*     */   private String[] splitString(String content, int length) {
/* 163 */     List l = new ArrayList();
/* 164 */     String temp = "";
/* 165 */     int i = 0;
/*     */     while (true) {
/* 167 */       if (content.length() <= (i + 1) * length) {
/* 168 */         temp = content.substring(i * length);
/*     */ 
/* 170 */         l.add(temp);
/* 171 */         break;
/*     */       }
/* 173 */       temp = content.substring(i * length, (i + 1) * length);
/*     */ 
/* 175 */       l.add(temp);
/*     */ 
/* 177 */       ++i;
/*     */     }
/*     */ 
/* 180 */     return (String[])(String[])l.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   private List getFiles()
/*     */   {
/* 185 */     List files = new LinkedList();
/* 186 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/* 188 */       FileSet fs = (FileSet)i.next();
/* 189 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/* 191 */       String[] dsFiles = ds.getIncludedFiles();
/* 192 */       for (int j = 0; j < dsFiles.length; ++j) {
/* 193 */         File f = new File(dsFiles[j]);
/* 194 */         if (!f.isFile()) {
/* 195 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/* 198 */         files.add(f);
/*     */       }
/*     */     }
/* 201 */     return files;
/*     */   }
/*     */ 
/*     */   public String getDestPath() {
/* 205 */     return this.destPath;
/*     */   }
/*     */ 
/*     */   public void setDestPath(String destPath) {
/* 209 */     this.destPath = destPath;
/*     */   }
/*     */ 
/*     */   public void setExpireDate(String expireDate) {
/* 213 */     this.expireDate = expireDate;
/*     */   }
/*     */ 
/*     */   public String getExpireDate() {
/* 217 */     return this.expireDate;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.ant.CreateTemplateDeployScriptTask
 * JD-Core Version:    0.5.4
 */