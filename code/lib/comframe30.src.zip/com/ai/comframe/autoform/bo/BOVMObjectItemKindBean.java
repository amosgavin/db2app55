/*     */ package com.ai.comframe.autoform.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
/*     */ 
/*     */ public class BOVMObjectItemKindBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVMObjectItemKindValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.autoform.bo.BOVMObjectItemKind";
/*     */   public static final String S_KindId = "KIND_ID";
/*     */   public static final String S_ItemKindName = "ITEM_KIND_NAME";
/*     */   public static final String S_ParentKindId = "PARENT_KIND_ID";
/*     */   public static final String S_Sortby = "SORTBY";
/*     */   public static final String S_ItemKindCode = "ITEM_KIND_CODE";
/*     */   public static final String S_ObjectItemType = "OBJECT_ITEM_TYPE";
/*  26 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVMObjectItemKindBean()
/*     */     throws AIException
/*     */   {
/*  35 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  39 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  44 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initKindId(long value)
/*     */   {
/*  49 */     initProperty("KIND_ID", new Long(value));
/*     */   }
/*     */   public void setKindId(long value) {
/*  52 */     set("KIND_ID", new Long(value));
/*     */   }
/*     */   public void setKindIdNull() {
/*  55 */     set("KIND_ID", null);
/*     */   }
/*     */ 
/*     */   public long getKindId() {
/*  59 */     return DataType.getAsLong(get("KIND_ID"));
/*     */   }
/*     */ 
/*     */   public long getKindIdInitialValue() {
/*  63 */     return DataType.getAsLong(getOldObj("KIND_ID"));
/*     */   }
/*     */ 
/*     */   public void initItemKindName(String value) {
/*  67 */     initProperty("ITEM_KIND_NAME", value);
/*     */   }
/*     */   public void setItemKindName(String value) {
/*  70 */     set("ITEM_KIND_NAME", value);
/*     */   }
/*     */   public void setItemKindNameNull() {
/*  73 */     set("ITEM_KIND_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getItemKindName() {
/*  77 */     return DataType.getAsString(get("ITEM_KIND_NAME"));
/*     */   }
/*     */ 
/*     */   public String getItemKindNameInitialValue() {
/*  81 */     return DataType.getAsString(getOldObj("ITEM_KIND_NAME"));
/*     */   }
/*     */ 
/*     */   public void initParentKindId(long value) {
/*  85 */     initProperty("PARENT_KIND_ID", new Long(value));
/*     */   }
/*     */   public void setParentKindId(long value) {
/*  88 */     set("PARENT_KIND_ID", new Long(value));
/*     */   }
/*     */   public void setParentKindIdNull() {
/*  91 */     set("PARENT_KIND_ID", null);
/*     */   }
/*     */ 
/*     */   public long getParentKindId() {
/*  95 */     return DataType.getAsLong(get("PARENT_KIND_ID"));
/*     */   }
/*     */ 
/*     */   public long getParentKindIdInitialValue() {
/*  99 */     return DataType.getAsLong(getOldObj("PARENT_KIND_ID"));
/*     */   }
/*     */ 
/*     */   public void initSortby(int value) {
/* 103 */     initProperty("SORTBY", new Integer(value));
/*     */   }
/*     */   public void setSortby(int value) {
/* 106 */     set("SORTBY", new Integer(value));
/*     */   }
/*     */   public void setSortbyNull() {
/* 109 */     set("SORTBY", null);
/*     */   }
/*     */ 
/*     */   public int getSortby() {
/* 113 */     return DataType.getAsInt(get("SORTBY"));
/*     */   }
/*     */ 
/*     */   public int getSortbyInitialValue() {
/* 117 */     return DataType.getAsInt(getOldObj("SORTBY"));
/*     */   }
/*     */ 
/*     */   public void initItemKindCode(String value) {
/* 121 */     initProperty("ITEM_KIND_CODE", value);
/*     */   }
/*     */   public void setItemKindCode(String value) {
/* 124 */     set("ITEM_KIND_CODE", value);
/*     */   }
/*     */   public void setItemKindCodeNull() {
/* 127 */     set("ITEM_KIND_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getItemKindCode() {
/* 131 */     return DataType.getAsString(get("ITEM_KIND_CODE"));
/*     */   }
/*     */ 
/*     */   public String getItemKindCodeInitialValue() {
/* 135 */     return DataType.getAsString(getOldObj("ITEM_KIND_CODE"));
/*     */   }
/*     */ 
/*     */   public void initObjectItemType(String value) {
/* 139 */     initProperty("OBJECT_ITEM_TYPE", value);
/*     */   }
/*     */   public void setObjectItemType(String value) {
/* 142 */     set("OBJECT_ITEM_TYPE", value);
/*     */   }
/*     */   public void setObjectItemTypeNull() {
/* 145 */     set("OBJECT_ITEM_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getObjectItemType() {
/* 149 */     return DataType.getAsString(get("OBJECT_ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getObjectItemTypeInitialValue() {
/* 153 */     return DataType.getAsString(getOldObj("OBJECT_ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  29 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  31 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemKindBean
 * JD-Core Version:    0.5.4
 */