/*     */ package com.ai.comframe.autoform.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVMObjectItemBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVMObjectItemValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.autoform.bo.BOVMObjectItem";
/*     */   public static final String S_FinishcodeDsParam = "FINISHCODE_DS_PARAM";
/*     */   public static final String S_FinishcodeSv = "FINISHCODE_SV";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_ModifyDate = "MODIFY_DATE";
/*     */   public static final String S_Creater = "CREATER";
/*     */   public static final String S_Remarks = "REMARKS";
/*     */   public static final String S_DataCommitSv = "DATA_COMMIT_SV";
/*     */   public static final String S_CreateDate = "CREATE_DATE";
/*     */   public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
/*     */   public static final String S_DataCommitSvFunction = "DATA_COMMIT_SV_FUNCTION";
/*     */   public static final String S_Islock = "ISLOCK";
/*     */   public static final String S_BusinessDomainId = "BUSINESS_DOMAIN_ID";
/*     */   public static final String S_FinishcodeSvFunction = "FINISHCODE_SV_FUNCTION";
/*     */   public static final String S_SortBy = "SORT_BY";
/*     */   public static final String S_BusinessTypeId = "BUSINESS_TYPE_ID";
/*     */   public static final String S_Checker = "CHECKER";
/*     */   public static final String S_Url = "URL";
/*     */   public static final String S_ItemType = "ITEM_TYPE";
/*     */   public static final String S_Code = "CODE";
/*     */   public static final String S_Name = "NAME";
/*     */   public static final String S_Description = "DESCRIPTION";
/*     */   public static final String S_FinishcodeDs = "FINISHCODE_DS";
/*  42 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVMObjectItemBean()
/*     */     throws AIException
/*     */   {
/*  51 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  55 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  60 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initFinishcodeDsParam(String value)
/*     */   {
/*  65 */     initProperty("FINISHCODE_DS_PARAM", value);
/*     */   }
/*     */   public void setFinishcodeDsParam(String value) {
/*  68 */     set("FINISHCODE_DS_PARAM", value);
/*     */   }
/*     */   public void setFinishcodeDsParamNull() {
/*  71 */     set("FINISHCODE_DS_PARAM", null);
/*     */   }
/*     */ 
/*     */   public String getFinishcodeDsParam() {
/*  75 */     return DataType.getAsString(get("FINISHCODE_DS_PARAM"));
/*     */   }
/*     */ 
/*     */   public String getFinishcodeDsParamInitialValue() {
/*  79 */     return DataType.getAsString(getOldObj("FINISHCODE_DS_PARAM"));
/*     */   }
/*     */ 
/*     */   public void initFinishcodeSv(String value) {
/*  83 */     initProperty("FINISHCODE_SV", value);
/*     */   }
/*     */   public void setFinishcodeSv(String value) {
/*  86 */     set("FINISHCODE_SV", value);
/*     */   }
/*     */   public void setFinishcodeSvNull() {
/*  89 */     set("FINISHCODE_SV", null);
/*     */   }
/*     */ 
/*     */   public String getFinishcodeSv() {
/*  93 */     return DataType.getAsString(get("FINISHCODE_SV"));
/*     */   }
/*     */ 
/*     */   public String getFinishcodeSvInitialValue() {
/*  97 */     return DataType.getAsString(getOldObj("FINISHCODE_SV"));
/*     */   }
/*     */ 
/*     */   public void initState(String value) {
/* 101 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/* 104 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/* 107 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/* 111 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/* 115 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initModifyDate(Timestamp value) {
/* 119 */     initProperty("MODIFY_DATE", value);
/*     */   }
/*     */   public void setModifyDate(Timestamp value) {
/* 122 */     set("MODIFY_DATE", value);
/*     */   }
/*     */   public void setModifyDateNull() {
/* 125 */     set("MODIFY_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getModifyDate() {
/* 129 */     return DataType.getAsDateTime(get("MODIFY_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getModifyDateInitialValue() {
/* 133 */     return DataType.getAsDateTime(getOldObj("MODIFY_DATE"));
/*     */   }
/*     */ 
/*     */   public void initCreater(long value) {
/* 137 */     initProperty("CREATER", new Long(value));
/*     */   }
/*     */   public void setCreater(long value) {
/* 140 */     set("CREATER", new Long(value));
/*     */   }
/*     */   public void setCreaterNull() {
/* 143 */     set("CREATER", null);
/*     */   }
/*     */ 
/*     */   public long getCreater() {
/* 147 */     return DataType.getAsLong(get("CREATER"));
/*     */   }
/*     */ 
/*     */   public long getCreaterInitialValue() {
/* 151 */     return DataType.getAsLong(getOldObj("CREATER"));
/*     */   }
/*     */ 
/*     */   public void initRemarks(String value) {
/* 155 */     initProperty("REMARKS", value);
/*     */   }
/*     */   public void setRemarks(String value) {
/* 158 */     set("REMARKS", value);
/*     */   }
/*     */   public void setRemarksNull() {
/* 161 */     set("REMARKS", null);
/*     */   }
/*     */ 
/*     */   public String getRemarks() {
/* 165 */     return DataType.getAsString(get("REMARKS"));
/*     */   }
/*     */ 
/*     */   public String getRemarksInitialValue() {
/* 169 */     return DataType.getAsString(getOldObj("REMARKS"));
/*     */   }
/*     */ 
/*     */   public void initDataCommitSv(String value) {
/* 173 */     initProperty("DATA_COMMIT_SV", value);
/*     */   }
/*     */   public void setDataCommitSv(String value) {
/* 176 */     set("DATA_COMMIT_SV", value);
/*     */   }
/*     */   public void setDataCommitSvNull() {
/* 179 */     set("DATA_COMMIT_SV", null);
/*     */   }
/*     */ 
/*     */   public String getDataCommitSv() {
/* 183 */     return DataType.getAsString(get("DATA_COMMIT_SV"));
/*     */   }
/*     */ 
/*     */   public String getDataCommitSvInitialValue() {
/* 187 */     return DataType.getAsString(getOldObj("DATA_COMMIT_SV"));
/*     */   }
/*     */ 
/*     */   public void initCreateDate(Timestamp value) {
/* 191 */     initProperty("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDate(Timestamp value) {
/* 194 */     set("CREATE_DATE", value);
/*     */   }
/*     */   public void setCreateDateNull() {
/* 197 */     set("CREATE_DATE", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDate() {
/* 201 */     return DataType.getAsDateTime(get("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public Timestamp getCreateDateInitialValue() {
/* 205 */     return DataType.getAsDateTime(getOldObj("CREATE_DATE"));
/*     */   }
/*     */ 
/*     */   public void initObjectItemId(long value) {
/* 209 */     initProperty("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemId(long value) {
/* 212 */     set("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemIdNull() {
/* 215 */     set("OBJECT_ITEM_ID", null);
/*     */   }
/*     */ 
/*     */   public long getObjectItemId() {
/* 219 */     return DataType.getAsLong(get("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public long getObjectItemIdInitialValue() {
/* 223 */     return DataType.getAsLong(getOldObj("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public void initDataCommitSvFunction(String value) {
/* 227 */     initProperty("DATA_COMMIT_SV_FUNCTION", value);
/*     */   }
/*     */   public void setDataCommitSvFunction(String value) {
/* 230 */     set("DATA_COMMIT_SV_FUNCTION", value);
/*     */   }
/*     */   public void setDataCommitSvFunctionNull() {
/* 233 */     set("DATA_COMMIT_SV_FUNCTION", null);
/*     */   }
/*     */ 
/*     */   public String getDataCommitSvFunction() {
/* 237 */     return DataType.getAsString(get("DATA_COMMIT_SV_FUNCTION"));
/*     */   }
/*     */ 
/*     */   public String getDataCommitSvFunctionInitialValue() {
/* 241 */     return DataType.getAsString(getOldObj("DATA_COMMIT_SV_FUNCTION"));
/*     */   }
/*     */ 
/*     */   public void initIslock(String value) {
/* 245 */     initProperty("ISLOCK", value);
/*     */   }
/*     */   public void setIslock(String value) {
/* 248 */     set("ISLOCK", value);
/*     */   }
/*     */   public void setIslockNull() {
/* 251 */     set("ISLOCK", null);
/*     */   }
/*     */ 
/*     */   public String getIslock() {
/* 255 */     return DataType.getAsString(get("ISLOCK"));
/*     */   }
/*     */ 
/*     */   public String getIslockInitialValue() {
/* 259 */     return DataType.getAsString(getOldObj("ISLOCK"));
/*     */   }
/*     */ 
/*     */   public void initBusinessDomainId(long value) {
/* 263 */     initProperty("BUSINESS_DOMAIN_ID", new Long(value));
/*     */   }
/*     */   public void setBusinessDomainId(long value) {
/* 266 */     set("BUSINESS_DOMAIN_ID", new Long(value));
/*     */   }
/*     */   public void setBusinessDomainIdNull() {
/* 269 */     set("BUSINESS_DOMAIN_ID", null);
/*     */   }
/*     */ 
/*     */   public long getBusinessDomainId() {
/* 273 */     return DataType.getAsLong(get("BUSINESS_DOMAIN_ID"));
/*     */   }
/*     */ 
/*     */   public long getBusinessDomainIdInitialValue() {
/* 277 */     return DataType.getAsLong(getOldObj("BUSINESS_DOMAIN_ID"));
/*     */   }
/*     */ 
/*     */   public void initFinishcodeSvFunction(String value) {
/* 281 */     initProperty("FINISHCODE_SV_FUNCTION", value);
/*     */   }
/*     */   public void setFinishcodeSvFunction(String value) {
/* 284 */     set("FINISHCODE_SV_FUNCTION", value);
/*     */   }
/*     */   public void setFinishcodeSvFunctionNull() {
/* 287 */     set("FINISHCODE_SV_FUNCTION", null);
/*     */   }
/*     */ 
/*     */   public String getFinishcodeSvFunction() {
/* 291 */     return DataType.getAsString(get("FINISHCODE_SV_FUNCTION"));
/*     */   }
/*     */ 
/*     */   public String getFinishcodeSvFunctionInitialValue() {
/* 295 */     return DataType.getAsString(getOldObj("FINISHCODE_SV_FUNCTION"));
/*     */   }
/*     */ 
/*     */   public void initSortBy(int value) {
/* 299 */     initProperty("SORT_BY", new Integer(value));
/*     */   }
/*     */   public void setSortBy(int value) {
/* 302 */     set("SORT_BY", new Integer(value));
/*     */   }
/*     */   public void setSortByNull() {
/* 305 */     set("SORT_BY", null);
/*     */   }
/*     */ 
/*     */   public int getSortBy() {
/* 309 */     return DataType.getAsInt(get("SORT_BY"));
/*     */   }
/*     */ 
/*     */   public int getSortByInitialValue() {
/* 313 */     return DataType.getAsInt(getOldObj("SORT_BY"));
/*     */   }
/*     */ 
/*     */   public void initBusinessTypeId(long value) {
/* 317 */     initProperty("BUSINESS_TYPE_ID", new Long(value));
/*     */   }
/*     */   public void setBusinessTypeId(long value) {
/* 320 */     set("BUSINESS_TYPE_ID", new Long(value));
/*     */   }
/*     */   public void setBusinessTypeIdNull() {
/* 323 */     set("BUSINESS_TYPE_ID", null);
/*     */   }
/*     */ 
/*     */   public long getBusinessTypeId() {
/* 327 */     return DataType.getAsLong(get("BUSINESS_TYPE_ID"));
/*     */   }
/*     */ 
/*     */   public long getBusinessTypeIdInitialValue() {
/* 331 */     return DataType.getAsLong(getOldObj("BUSINESS_TYPE_ID"));
/*     */   }
/*     */ 
/*     */   public void initChecker(long value) {
/* 335 */     initProperty("CHECKER", new Long(value));
/*     */   }
/*     */   public void setChecker(long value) {
/* 338 */     set("CHECKER", new Long(value));
/*     */   }
/*     */   public void setCheckerNull() {
/* 341 */     set("CHECKER", null);
/*     */   }
/*     */ 
/*     */   public long getChecker() {
/* 345 */     return DataType.getAsLong(get("CHECKER"));
/*     */   }
/*     */ 
/*     */   public long getCheckerInitialValue() {
/* 349 */     return DataType.getAsLong(getOldObj("CHECKER"));
/*     */   }
/*     */ 
/*     */   public void initUrl(String value) {
/* 353 */     initProperty("URL", value);
/*     */   }
/*     */   public void setUrl(String value) {
/* 356 */     set("URL", value);
/*     */   }
/*     */   public void setUrlNull() {
/* 359 */     set("URL", null);
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 363 */     return DataType.getAsString(get("URL"));
/*     */   }
/*     */ 
/*     */   public String getUrlInitialValue() {
/* 367 */     return DataType.getAsString(getOldObj("URL"));
/*     */   }
/*     */ 
/*     */   public void initItemType(String value) {
/* 371 */     initProperty("ITEM_TYPE", value);
/*     */   }
/*     */   public void setItemType(String value) {
/* 374 */     set("ITEM_TYPE", value);
/*     */   }
/*     */   public void setItemTypeNull() {
/* 377 */     set("ITEM_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getItemType() {
/* 381 */     return DataType.getAsString(get("ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getItemTypeInitialValue() {
/* 385 */     return DataType.getAsString(getOldObj("ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initCode(String value) {
/* 389 */     initProperty("CODE", value);
/*     */   }
/*     */   public void setCode(String value) {
/* 392 */     set("CODE", value);
/*     */   }
/*     */   public void setCodeNull() {
/* 395 */     set("CODE", null);
/*     */   }
/*     */ 
/*     */   public String getCode() {
/* 399 */     return DataType.getAsString(get("CODE"));
/*     */   }
/*     */ 
/*     */   public String getCodeInitialValue() {
/* 403 */     return DataType.getAsString(getOldObj("CODE"));
/*     */   }
/*     */ 
/*     */   public void initName(String value) {
/* 407 */     initProperty("NAME", value);
/*     */   }
/*     */   public void setName(String value) {
/* 410 */     set("NAME", value);
/*     */   }
/*     */   public void setNameNull() {
/* 413 */     set("NAME", null);
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 417 */     return DataType.getAsString(get("NAME"));
/*     */   }
/*     */ 
/*     */   public String getNameInitialValue() {
/* 421 */     return DataType.getAsString(getOldObj("NAME"));
/*     */   }
/*     */ 
/*     */   public void initDescription(String value) {
/* 425 */     initProperty("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescription(String value) {
/* 428 */     set("DESCRIPTION", value);
/*     */   }
/*     */   public void setDescriptionNull() {
/* 431 */     set("DESCRIPTION", null);
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 435 */     return DataType.getAsString(get("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public String getDescriptionInitialValue() {
/* 439 */     return DataType.getAsString(getOldObj("DESCRIPTION"));
/*     */   }
/*     */ 
/*     */   public void initFinishcodeDs(String value) {
/* 443 */     initProperty("FINISHCODE_DS", value);
/*     */   }
/*     */   public void setFinishcodeDs(String value) {
/* 446 */     set("FINISHCODE_DS", value);
/*     */   }
/*     */   public void setFinishcodeDsNull() {
/* 449 */     set("FINISHCODE_DS", null);
/*     */   }
/*     */ 
/*     */   public String getFinishcodeDs() {
/* 453 */     return DataType.getAsString(get("FINISHCODE_DS"));
/*     */   }
/*     */ 
/*     */   public String getFinishcodeDsInitialValue() {
/* 457 */     return DataType.getAsString(getOldObj("FINISHCODE_DS"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  45 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  47 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemBean
 * JD-Core Version:    0.5.4
 */