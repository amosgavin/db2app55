/*     */ package com.ai.comframe.autoform.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainerFactory;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.appframe2.util.criteria.UniqueList;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemRelatValue;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class BOVMObjectItemRelatEngine
/*     */ {
/*     */   public static BOVMObjectItemRelatBean[] getBeans(DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  20 */     Map ps = dc.getProperties();
/*  21 */     StringBuffer buffer = new StringBuffer();
/*  22 */     Map pList = new HashMap();
/*  23 */     for (Iterator cc = ps.entrySet().iterator(); cc.hasNext(); ) {
/*  24 */       e = (Map.Entry)cc.next();
/*  25 */       if (buffer.length() > 0)
/*  26 */         buffer.append(" and ");
/*  27 */       buffer.append(e.getKey().toString() + " = :p_" + e.getKey().toString());
/*  28 */       pList.put("p_" + e.getKey().toString(), e.getValue());
/*     */     }
/*     */     Map.Entry e;
/*  30 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try {
/*  32 */       e = getBeans(buffer.toString(), pList);
/*     */ 
/*  36 */       return e;
/*     */     }
/*     */     finally
/*     */     {
/*  34 */       if (conn != null)
/*  35 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean getBean(long _ItemRelatId) throws Exception
/*     */   {
/*  41 */     String condition = "ITEM_RELAT_ID = :S_ITEM_RELAT_ID";
/*  42 */     Map map = new HashMap();
/*  43 */     map.put("S_ITEM_RELAT_ID", new Long(_ItemRelatId));
/*     */ 
/*  45 */     BOVMObjectItemRelatBean[] beans = getBeans(condition, map);
/*  46 */     if ((beans != null) && (beans.length == 1))
/*  47 */       return beans[0];
/*  48 */     if ((beans != null) && (beans.length > 1))
/*     */     {
/*  50 */       throw new Exception("[ERROR]More datas than one queryed by PK");
/*     */     }
/*  52 */     BOVMObjectItemRelatBean bean = new BOVMObjectItemRelatBean();
/*  53 */     bean.setItemRelatId(_ItemRelatId);
/*  54 */     return bean;
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeans(Criteria sql) throws Exception
/*     */   {
/*  59 */     return getBeans(sql, -1, -1, false);
/*     */   }
/*     */   public static BOVMObjectItemRelatBean[] getBeans(Criteria sql, int startNum, int endNum, boolean isShowFK) throws Exception {
/*  62 */     String[] cols = null;
/*  63 */     String condition = "";
/*  64 */     Map param = null;
/*  65 */     if (sql != null) {
/*  66 */       cols = (String[])(String[])sql.getSelectColumns().toArray(new String[0]);
/*  67 */       condition = sql.toString();
/*  68 */       param = sql.getParameters();
/*     */     }
/*  70 */     return (BOVMObjectItemRelatBean[])getBeans(cols, condition, param, startNum, endNum, isShowFK);
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeans(String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  77 */     return getBeans(null, condition, parameter, -1, -1, false);
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK) throws Exception
/*     */   {
/*  82 */     Connection conn = null;
/*     */     try {
/*  84 */       conn = ServiceManager.getSession().getConnection();
/*  85 */       BOVMObjectItemRelatBean[] arrayOfBOVMObjectItemRelatBean = (BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])ServiceManager.getDataStore().retrieve(conn, BOVMObjectItemRelatBean.class, BOVMObjectItemRelatBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, null);
/*     */ 
/*  91 */       return arrayOfBOVMObjectItemRelatBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  89 */       if (conn != null)
/*  90 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK, String[] extendBOAttrs) throws Exception
/*     */   {
/*  96 */     Connection conn = null;
/*     */     try {
/*  98 */       conn = ServiceManager.getSession().getConnection();
/*  99 */       BOVMObjectItemRelatBean[] arrayOfBOVMObjectItemRelatBean = (BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])ServiceManager.getDataStore().retrieve(conn, BOVMObjectItemRelatBean.class, BOVMObjectItemRelatBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, extendBOAttrs);
/*     */ 
/* 105 */       return arrayOfBOVMObjectItemRelatBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 103 */       if (conn != null)
/* 104 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter) throws Exception
/*     */   {
/* 110 */     Connection conn = null;
/*     */     try {
/* 112 */       conn = ServiceManager.getSession().getConnection();
/* 113 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVMObjectItemRelatBean.getObjectTypeStatic(), condition, parameter, null);
/*     */ 
/* 119 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 117 */       if (conn != null)
/* 118 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter, String[] extendBOAttrs) throws Exception {
/* 123 */     Connection conn = null;
/*     */     try {
/* 125 */       conn = ServiceManager.getSession().getConnection();
/* 126 */       int i = ServiceManager.getDataStore().retrieveCount(conn, BOVMObjectItemRelatBean.getObjectTypeStatic(), condition, parameter, extendBOAttrs);
/*     */ 
/* 132 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 130 */       if (conn != null)
/* 131 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVMObjectItemRelatBean aBean) throws Exception
/*     */   {
/* 137 */     Connection conn = null;
/*     */     try {
/* 139 */       conn = ServiceManager.getSession().getConnection();
/* 140 */       ServiceManager.getDataStore().save(conn, aBean);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 144 */       if (conn != null)
/* 145 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(BOVMObjectItemRelatBean[] aBeans) throws Exception {
/* 150 */     Connection conn = null;
/*     */     try {
/* 152 */       conn = ServiceManager.getSession().getConnection();
/* 153 */       ServiceManager.getDataStore().save(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 157 */       if (conn != null)
/* 158 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveBatch(BOVMObjectItemRelatBean[] aBeans) throws Exception {
/* 163 */     Connection conn = null;
/*     */     try {
/* 165 */       conn = ServiceManager.getSession().getConnection();
/* 166 */       ServiceManager.getDataStore().saveBatch(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 170 */       if (conn != null)
/* 171 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeansFromQueryBO(String soureBO, Map parameter) throws Exception
/*     */   {
/* 177 */     Connection conn = null;
/* 178 */     ResultSet resultset = null;
/*     */     try {
/* 180 */       conn = ServiceManager.getSession().getConnection();
/* 181 */       String sql = ServiceManager.getObjectTypeFactory().getInstance(soureBO).getMapingEnty();
/* 182 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 183 */       BOVMObjectItemRelatBean[] arrayOfBOVMObjectItemRelatBean = (BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVMObjectItemRelatBean.class, BOVMObjectItemRelatBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 190 */       return arrayOfBOVMObjectItemRelatBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 187 */       if (resultset != null) resultset.close();
/* 188 */       if (conn != null)
/* 189 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] getBeansFromSql(String sql, Map parameter) throws Exception {
/* 194 */     Connection conn = null;
/* 195 */     ResultSet resultset = null;
/*     */     try {
/* 197 */       conn = ServiceManager.getSession().getConnection();
/* 198 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 199 */       BOVMObjectItemRelatBean[] arrayOfBOVMObjectItemRelatBean = (BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(BOVMObjectItemRelatBean.class, BOVMObjectItemRelatBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 206 */       return arrayOfBOVMObjectItemRelatBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 203 */       if (resultset != null) resultset.close();
/* 204 */       if (conn != null)
/* 205 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId() throws Exception {
/* 210 */     return ServiceManager.getIdGenerator().getNewId(BOVMObjectItemRelatBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static Timestamp getSysDate() throws Exception
/*     */   {
/* 215 */     return ServiceManager.getIdGenerator().getSysDate(BOVMObjectItemRelatBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean wrap(DataContainerInterface source, Map colMatch, boolean canModify)
/*     */   {
/*     */     try {
/* 221 */       return (BOVMObjectItemRelatBean)DataContainerFactory.wrap(source, BOVMObjectItemRelatBean.class, colMatch, canModify);
/*     */     } catch (Exception e) {
/* 223 */       if (e.getCause() != null) {
/* 224 */         throw new RuntimeException(e.getCause());
/*     */       }
/* 226 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean copy(DataContainerInterface source, Map colMatch, boolean canModify) {
/*     */     try {
/* 231 */       BOVMObjectItemRelatBean result = new BOVMObjectItemRelatBean();
/* 232 */       DataContainerFactory.copy(source, result, colMatch);
/* 233 */       return result;
/*     */     }
/*     */     catch (AIException ex) {
/* 236 */       if (ex.getCause() != null) {
/* 237 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 239 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean transfer(IBOVMObjectItemRelatValue value) {
/* 244 */     if (value == null)
/* 245 */       return null;
/*     */     try {
/* 247 */       if (value instanceof BOVMObjectItemRelatBean) {
/* 248 */         return (BOVMObjectItemRelatBean)value;
/*     */       }
/* 250 */       BOVMObjectItemRelatBean newBean = new BOVMObjectItemRelatBean();
/*     */ 
/* 252 */       DataContainerFactory.transfer(value, newBean);
/* 253 */       return newBean;
/*     */     } catch (Exception ex) {
/* 255 */       if (ex.getCause() != null) {
/* 256 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 258 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BOVMObjectItemRelatBean[] transfer(IBOVMObjectItemRelatValue[] value) {
/* 263 */     if ((value == null) || (value.length == 0))
/* 264 */       return null;
/*     */     try
/*     */     {
/* 267 */       if (value instanceof BOVMObjectItemRelatBean[]) {
/* 268 */         return (BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])value;
/*     */       }
/* 270 */       BOVMObjectItemRelatBean[] newBeans = new BOVMObjectItemRelatBean[value.length];
/* 271 */       for (int i = 0; i < newBeans.length; ++i) {
/* 272 */         newBeans[i] = new BOVMObjectItemRelatBean();
/* 273 */         DataContainerFactory.transfer(value[i], newBeans[i]);
/*     */       }
/* 275 */       return newBeans;
/*     */     } catch (Exception ex) {
/* 277 */       if (ex.getCause() != null) {
/* 278 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 280 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(IBOVMObjectItemRelatValue aValue) throws Exception {
/* 285 */     save(transfer(aValue));
/*     */   }
/*     */ 
/*     */   public static void save(IBOVMObjectItemRelatValue[] aValues) throws Exception {
/* 289 */     save(transfer(aValues));
/*     */   }
/*     */ 
/*     */   public static void saveBatch(IBOVMObjectItemRelatValue[] aValues) throws Exception {
/* 293 */     saveBatch(transfer(aValues));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemRelatEngine
 * JD-Core Version:    0.5.4
 */