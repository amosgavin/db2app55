/*     */ package com.ai.comframe.autoform.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
/*     */ 
/*     */ public class QBOVMObjectItemRelatBean extends DataContainer
/*     */   implements DataContainerInterface, IQBOVMObjectItemRelatValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.autoform.bo.QBOVMObjectItemRelat";
/*     */   public static final String S_RelatItemType = "RELAT_ITEM_TYPE";
/*     */   public static final String S_RelatType = "RELAT_TYPE";
/*     */   public static final String S_RelatObjectItemId = "RELAT_OBJECT_ITEM_ID";
/*     */   public static final String S_RelatId = "RELAT_ID";
/*     */   public static final String S_TaskCode = "TASK_CODE";
/*     */   public static final String S_ItemType = "ITEM_TYPE";
/*     */   public static final String S_Name = "NAME";
/*     */   public static final String S_TemplateTag = "TEMPLATE_TAG";
/*     */   public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
/*  29 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public QBOVMObjectItemRelatBean()
/*     */     throws AIException
/*     */   {
/*  38 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  42 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  47 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initRelatItemType(String value)
/*     */   {
/*  52 */     initProperty("RELAT_ITEM_TYPE", value);
/*     */   }
/*     */   public void setRelatItemType(String value) {
/*  55 */     set("RELAT_ITEM_TYPE", value);
/*     */   }
/*     */   public void setRelatItemTypeNull() {
/*  58 */     set("RELAT_ITEM_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getRelatItemType() {
/*  62 */     return DataType.getAsString(get("RELAT_ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getRelatItemTypeInitialValue() {
/*  66 */     return DataType.getAsString(getOldObj("RELAT_ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initRelatType(String value) {
/*  70 */     initProperty("RELAT_TYPE", value);
/*     */   }
/*     */   public void setRelatType(String value) {
/*  73 */     set("RELAT_TYPE", value);
/*     */   }
/*     */   public void setRelatTypeNull() {
/*  76 */     set("RELAT_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getRelatType() {
/*  80 */     return DataType.getAsString(get("RELAT_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getRelatTypeInitialValue() {
/*  84 */     return DataType.getAsString(getOldObj("RELAT_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initRelatObjectItemId(long value) {
/*  88 */     initProperty("RELAT_OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setRelatObjectItemId(long value) {
/*  91 */     set("RELAT_OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setRelatObjectItemIdNull() {
/*  94 */     set("RELAT_OBJECT_ITEM_ID", null);
/*     */   }
/*     */ 
/*     */   public long getRelatObjectItemId() {
/*  98 */     return DataType.getAsLong(get("RELAT_OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public long getRelatObjectItemIdInitialValue() {
/* 102 */     return DataType.getAsLong(getOldObj("RELAT_OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public void initRelatId(long value) {
/* 106 */     initProperty("RELAT_ID", new Long(value));
/*     */   }
/*     */   public void setRelatId(long value) {
/* 109 */     set("RELAT_ID", new Long(value));
/*     */   }
/*     */   public void setRelatIdNull() {
/* 112 */     set("RELAT_ID", null);
/*     */   }
/*     */ 
/*     */   public long getRelatId() {
/* 116 */     return DataType.getAsLong(get("RELAT_ID"));
/*     */   }
/*     */ 
/*     */   public long getRelatIdInitialValue() {
/* 120 */     return DataType.getAsLong(getOldObj("RELAT_ID"));
/*     */   }
/*     */ 
/*     */   public void initTaskCode(String value) {
/* 124 */     initProperty("TASK_CODE", value);
/*     */   }
/*     */   public void setTaskCode(String value) {
/* 127 */     set("TASK_CODE", value);
/*     */   }
/*     */   public void setTaskCodeNull() {
/* 130 */     set("TASK_CODE", null);
/*     */   }
/*     */ 
/*     */   public String getTaskCode() {
/* 134 */     return DataType.getAsString(get("TASK_CODE"));
/*     */   }
/*     */ 
/*     */   public String getTaskCodeInitialValue() {
/* 138 */     return DataType.getAsString(getOldObj("TASK_CODE"));
/*     */   }
/*     */ 
/*     */   public void initItemType(String value) {
/* 142 */     initProperty("ITEM_TYPE", value);
/*     */   }
/*     */   public void setItemType(String value) {
/* 145 */     set("ITEM_TYPE", value);
/*     */   }
/*     */   public void setItemTypeNull() {
/* 148 */     set("ITEM_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getItemType() {
/* 152 */     return DataType.getAsString(get("ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getItemTypeInitialValue() {
/* 156 */     return DataType.getAsString(getOldObj("ITEM_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initName(String value) {
/* 160 */     initProperty("NAME", value);
/*     */   }
/*     */   public void setName(String value) {
/* 163 */     set("NAME", value);
/*     */   }
/*     */   public void setNameNull() {
/* 166 */     set("NAME", null);
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 170 */     return DataType.getAsString(get("NAME"));
/*     */   }
/*     */ 
/*     */   public String getNameInitialValue() {
/* 174 */     return DataType.getAsString(getOldObj("NAME"));
/*     */   }
/*     */ 
/*     */   public void initTemplateTag(String value) {
/* 178 */     initProperty("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTag(String value) {
/* 181 */     set("TEMPLATE_TAG", value);
/*     */   }
/*     */   public void setTemplateTagNull() {
/* 184 */     set("TEMPLATE_TAG", null);
/*     */   }
/*     */ 
/*     */   public String getTemplateTag() {
/* 188 */     return DataType.getAsString(get("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public String getTemplateTagInitialValue() {
/* 192 */     return DataType.getAsString(getOldObj("TEMPLATE_TAG"));
/*     */   }
/*     */ 
/*     */   public void initObjectItemId(long value) {
/* 196 */     initProperty("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemId(long value) {
/* 199 */     set("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemIdNull() {
/* 202 */     set("OBJECT_ITEM_ID", null);
/*     */   }
/*     */ 
/*     */   public long getObjectItemId() {
/* 206 */     return DataType.getAsLong(get("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public long getObjectItemIdInitialValue() {
/* 210 */     return DataType.getAsLong(getOldObj("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  34 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.QBOVMObjectItemRelatBean
 * JD-Core Version:    0.5.4
 */