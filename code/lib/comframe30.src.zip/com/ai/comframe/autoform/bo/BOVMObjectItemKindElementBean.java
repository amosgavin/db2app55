/*    */ package com.ai.comframe.autoform.bo;
/*    */ 
/*    */ import com.ai.appframe2.bo.DataContainer;
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import com.ai.appframe2.common.ObjectTypeFactory;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindElementValue;
/*    */ 
/*    */ public class BOVMObjectItemKindElementBean extends DataContainer
/*    */   implements DataContainerInterface, IBOVMObjectItemKindElementValue
/*    */ {
/* 15 */   private static String m_boName = "com.ai.comframe.autoform.bo.BOVMObjectItemKindElement";
/*    */   public static final String S_ItemKindRelatId = "ITEM_KIND_RELAT_ID";
/*    */   public static final String S_ItemKindId = "ITEM_KIND_ID";
/*    */   public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
/* 23 */   public static ObjectType S_TYPE = null;
/*    */ 
/*    */   public BOVMObjectItemKindElementBean()
/*    */     throws AIException
/*    */   {
/* 32 */     super(S_TYPE);
/*    */   }
/*    */ 
/*    */   public static ObjectType getObjectTypeStatic() throws AIException {
/* 36 */     return S_TYPE;
/*    */   }
/*    */ 
/*    */   public void setObjectType(ObjectType value) throws AIException
/*    */   {
/* 41 */     throw new AIException("Cannot reset ObjectType");
/*    */   }
/*    */ 
/*    */   public void initItemKindRelatId(long value)
/*    */   {
/* 46 */     initProperty("ITEM_KIND_RELAT_ID", new Long(value));
/*    */   }
/*    */   public void setItemKindRelatId(long value) {
/* 49 */     set("ITEM_KIND_RELAT_ID", new Long(value));
/*    */   }
/*    */   public void setItemKindRelatIdNull() {
/* 52 */     set("ITEM_KIND_RELAT_ID", null);
/*    */   }
/*    */ 
/*    */   public long getItemKindRelatId() {
/* 56 */     return DataType.getAsLong(get("ITEM_KIND_RELAT_ID"));
/*    */   }
/*    */ 
/*    */   public long getItemKindRelatIdInitialValue() {
/* 60 */     return DataType.getAsLong(getOldObj("ITEM_KIND_RELAT_ID"));
/*    */   }
/*    */ 
/*    */   public void initItemKindId(long value) {
/* 64 */     initProperty("ITEM_KIND_ID", new Long(value));
/*    */   }
/*    */   public void setItemKindId(long value) {
/* 67 */     set("ITEM_KIND_ID", new Long(value));
/*    */   }
/*    */   public void setItemKindIdNull() {
/* 70 */     set("ITEM_KIND_ID", null);
/*    */   }
/*    */ 
/*    */   public long getItemKindId() {
/* 74 */     return DataType.getAsLong(get("ITEM_KIND_ID"));
/*    */   }
/*    */ 
/*    */   public long getItemKindIdInitialValue() {
/* 78 */     return DataType.getAsLong(getOldObj("ITEM_KIND_ID"));
/*    */   }
/*    */ 
/*    */   public void initObjectItemId(long value) {
/* 82 */     initProperty("OBJECT_ITEM_ID", new Long(value));
/*    */   }
/*    */   public void setObjectItemId(long value) {
/* 85 */     set("OBJECT_ITEM_ID", new Long(value));
/*    */   }
/*    */   public void setObjectItemIdNull() {
/* 88 */     set("OBJECT_ITEM_ID", null);
/*    */   }
/*    */ 
/*    */   public long getObjectItemId() {
/* 92 */     return DataType.getAsLong(get("OBJECT_ITEM_ID"));
/*    */   }
/*    */ 
/*    */   public long getObjectItemIdInitialValue() {
/* 96 */     return DataType.getAsLong(getOldObj("OBJECT_ITEM_ID"));
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 26 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*    */     } catch (Exception e) {
/* 28 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemKindElementBean
 * JD-Core Version:    0.5.4
 */