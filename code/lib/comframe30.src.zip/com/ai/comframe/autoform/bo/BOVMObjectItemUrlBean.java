/*    */ package com.ai.comframe.autoform.bo;
/*    */ 
/*    */ import com.ai.appframe2.bo.DataContainer;
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import com.ai.appframe2.common.ObjectTypeFactory;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue;
/*    */ 
/*    */ public class BOVMObjectItemUrlBean extends DataContainer
/*    */   implements DataContainerInterface, IBOVMObjectItemUrlValue
/*    */ {
/* 15 */   private static String m_boName = "com.ai.comframe.autoform.bo.BOVMObjectItemUrl";
/*    */   public static final String S_UrlBusiType = "URL_BUSI_TYPE";
/*    */   public static final String S_Url = "URL";
/*    */   public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
/* 23 */   public static ObjectType S_TYPE = null;
/*    */ 
/*    */   public BOVMObjectItemUrlBean()
/*    */     throws AIException
/*    */   {
/* 32 */     super(S_TYPE);
/*    */   }
/*    */ 
/*    */   public static ObjectType getObjectTypeStatic() throws AIException {
/* 36 */     return S_TYPE;
/*    */   }
/*    */ 
/*    */   public void setObjectType(ObjectType value) throws AIException
/*    */   {
/* 41 */     throw new AIException("Cannot reset ObjectType");
/*    */   }
/*    */ 
/*    */   public void initUrlBusiType(int value)
/*    */   {
/* 46 */     initProperty("URL_BUSI_TYPE", new Integer(value));
/*    */   }
/*    */   public void setUrlBusiType(int value) {
/* 49 */     set("URL_BUSI_TYPE", new Integer(value));
/*    */   }
/*    */   public void setUrlBusiTypeNull() {
/* 52 */     set("URL_BUSI_TYPE", null);
/*    */   }
/*    */ 
/*    */   public int getUrlBusiType() {
/* 56 */     return DataType.getAsInt(get("URL_BUSI_TYPE"));
/*    */   }
/*    */ 
/*    */   public int getUrlBusiTypeInitialValue() {
/* 60 */     return DataType.getAsInt(getOldObj("URL_BUSI_TYPE"));
/*    */   }
/*    */ 
/*    */   public void initUrl(String value) {
/* 64 */     initProperty("URL", value);
/*    */   }
/*    */   public void setUrl(String value) {
/* 67 */     set("URL", value);
/*    */   }
/*    */   public void setUrlNull() {
/* 70 */     set("URL", null);
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 74 */     return DataType.getAsString(get("URL"));
/*    */   }
/*    */ 
/*    */   public String getUrlInitialValue() {
/* 78 */     return DataType.getAsString(getOldObj("URL"));
/*    */   }
/*    */ 
/*    */   public void initObjectItemId(long value) {
/* 82 */     initProperty("OBJECT_ITEM_ID", new Long(value));
/*    */   }
/*    */   public void setObjectItemId(long value) {
/* 85 */     set("OBJECT_ITEM_ID", new Long(value));
/*    */   }
/*    */   public void setObjectItemIdNull() {
/* 88 */     set("OBJECT_ITEM_ID", null);
/*    */   }
/*    */ 
/*    */   public long getObjectItemId() {
/* 92 */     return DataType.getAsLong(get("OBJECT_ITEM_ID"));
/*    */   }
/*    */ 
/*    */   public long getObjectItemIdInitialValue() {
/* 96 */     return DataType.getAsLong(getOldObj("OBJECT_ITEM_ID"));
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 26 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*    */     } catch (Exception e) {
/* 28 */       throw new RuntimeException(e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemUrlBean
 * JD-Core Version:    0.5.4
 */