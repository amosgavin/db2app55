/*     */ package com.ai.comframe.autoform.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemRelatValue;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ public class BOVMObjectItemRelatBean extends DataContainer
/*     */   implements DataContainerInterface, IBOVMObjectItemRelatValue
/*     */ {
/*  15 */   private static String m_boName = "com.ai.comframe.autoform.bo.BOVMObjectItemRelat";
/*     */   public static final String S_State = "STATE";
/*     */   public static final String S_ExtendAttrG = "EXTEND_ATTR_G";
/*     */   public static final String S_ExtendAttrJ = "EXTEND_ATTR_J";
/*     */   public static final String S_ExtendAttrH = "EXTEND_ATTR_H";
/*     */   public static final String S_ExtendAttrC = "EXTEND_ATTR_C";
/*     */   public static final String S_ItemRelatId = "ITEM_RELAT_ID";
/*     */   public static final String S_Remarks = "REMARKS";
/*     */   public static final String S_SortNo = "SORT_NO";
/*     */   public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
/*     */   public static final String S_ExtendAttrD = "EXTEND_ATTR_D";
/*     */   public static final String S_RelatType = "RELAT_TYPE";
/*     */   public static final String S_RelatObjectItemId = "RELAT_OBJECT_ITEM_ID";
/*     */   public static final String S_ExtendAttrI = "EXTEND_ATTR_I";
/*     */   public static final String S_ExtendAttrE = "EXTEND_ATTR_E";
/*     */   public static final String S_ExtendAttrA = "EXTEND_ATTR_A";
/*     */   public static final String S_ExtendAttrF = "EXTEND_ATTR_F";
/*     */   public static final String S_ExtendAttrK = "EXTEND_ATTR_K";
/*     */   public static final String S_ExtendAttrB = "EXTEND_ATTR_B";
/*  38 */   public static ObjectType S_TYPE = null;
/*     */ 
/*     */   public BOVMObjectItemRelatBean()
/*     */     throws AIException
/*     */   {
/*  47 */     super(S_TYPE);
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  51 */     return S_TYPE;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  56 */     throw new AIException("Cannot reset ObjectType");
/*     */   }
/*     */ 
/*     */   public void initState(String value)
/*     */   {
/*  61 */     initProperty("STATE", value);
/*     */   }
/*     */   public void setState(String value) {
/*  64 */     set("STATE", value);
/*     */   }
/*     */   public void setStateNull() {
/*  67 */     set("STATE", null);
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  71 */     return DataType.getAsString(get("STATE"));
/*     */   }
/*     */ 
/*     */   public String getStateInitialValue() {
/*  75 */     return DataType.getAsString(getOldObj("STATE"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrG(String value) {
/*  79 */     initProperty("EXTEND_ATTR_G", value);
/*     */   }
/*     */   public void setExtendAttrG(String value) {
/*  82 */     set("EXTEND_ATTR_G", value);
/*     */   }
/*     */   public void setExtendAttrGNull() {
/*  85 */     set("EXTEND_ATTR_G", null);
/*     */   }
/*     */ 
/*     */   public String getExtendAttrG() {
/*  89 */     return DataType.getAsString(get("EXTEND_ATTR_G"));
/*     */   }
/*     */ 
/*     */   public String getExtendAttrGInitialValue() {
/*  93 */     return DataType.getAsString(getOldObj("EXTEND_ATTR_G"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrJ(Timestamp value) {
/*  97 */     initProperty("EXTEND_ATTR_J", value);
/*     */   }
/*     */   public void setExtendAttrJ(Timestamp value) {
/* 100 */     set("EXTEND_ATTR_J", value);
/*     */   }
/*     */   public void setExtendAttrJNull() {
/* 103 */     set("EXTEND_ATTR_J", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExtendAttrJ() {
/* 107 */     return DataType.getAsDateTime(get("EXTEND_ATTR_J"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExtendAttrJInitialValue() {
/* 111 */     return DataType.getAsDateTime(getOldObj("EXTEND_ATTR_J"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrH(String value) {
/* 115 */     initProperty("EXTEND_ATTR_H", value);
/*     */   }
/*     */   public void setExtendAttrH(String value) {
/* 118 */     set("EXTEND_ATTR_H", value);
/*     */   }
/*     */   public void setExtendAttrHNull() {
/* 121 */     set("EXTEND_ATTR_H", null);
/*     */   }
/*     */ 
/*     */   public String getExtendAttrH() {
/* 125 */     return DataType.getAsString(get("EXTEND_ATTR_H"));
/*     */   }
/*     */ 
/*     */   public String getExtendAttrHInitialValue() {
/* 129 */     return DataType.getAsString(getOldObj("EXTEND_ATTR_H"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrC(long value) {
/* 133 */     initProperty("EXTEND_ATTR_C", new Long(value));
/*     */   }
/*     */   public void setExtendAttrC(long value) {
/* 136 */     set("EXTEND_ATTR_C", new Long(value));
/*     */   }
/*     */   public void setExtendAttrCNull() {
/* 139 */     set("EXTEND_ATTR_C", null);
/*     */   }
/*     */ 
/*     */   public long getExtendAttrC() {
/* 143 */     return DataType.getAsLong(get("EXTEND_ATTR_C"));
/*     */   }
/*     */ 
/*     */   public long getExtendAttrCInitialValue() {
/* 147 */     return DataType.getAsLong(getOldObj("EXTEND_ATTR_C"));
/*     */   }
/*     */ 
/*     */   public void initItemRelatId(long value) {
/* 151 */     initProperty("ITEM_RELAT_ID", new Long(value));
/*     */   }
/*     */   public void setItemRelatId(long value) {
/* 154 */     set("ITEM_RELAT_ID", new Long(value));
/*     */   }
/*     */   public void setItemRelatIdNull() {
/* 157 */     set("ITEM_RELAT_ID", null);
/*     */   }
/*     */ 
/*     */   public long getItemRelatId() {
/* 161 */     return DataType.getAsLong(get("ITEM_RELAT_ID"));
/*     */   }
/*     */ 
/*     */   public long getItemRelatIdInitialValue() {
/* 165 */     return DataType.getAsLong(getOldObj("ITEM_RELAT_ID"));
/*     */   }
/*     */ 
/*     */   public void initRemarks(String value) {
/* 169 */     initProperty("REMARKS", value);
/*     */   }
/*     */   public void setRemarks(String value) {
/* 172 */     set("REMARKS", value);
/*     */   }
/*     */   public void setRemarksNull() {
/* 175 */     set("REMARKS", null);
/*     */   }
/*     */ 
/*     */   public String getRemarks() {
/* 179 */     return DataType.getAsString(get("REMARKS"));
/*     */   }
/*     */ 
/*     */   public String getRemarksInitialValue() {
/* 183 */     return DataType.getAsString(getOldObj("REMARKS"));
/*     */   }
/*     */ 
/*     */   public void initSortNo(int value) {
/* 187 */     initProperty("SORT_NO", new Integer(value));
/*     */   }
/*     */   public void setSortNo(int value) {
/* 190 */     set("SORT_NO", new Integer(value));
/*     */   }
/*     */   public void setSortNoNull() {
/* 193 */     set("SORT_NO", null);
/*     */   }
/*     */ 
/*     */   public int getSortNo() {
/* 197 */     return DataType.getAsInt(get("SORT_NO"));
/*     */   }
/*     */ 
/*     */   public int getSortNoInitialValue() {
/* 201 */     return DataType.getAsInt(getOldObj("SORT_NO"));
/*     */   }
/*     */ 
/*     */   public void initObjectItemId(long value) {
/* 205 */     initProperty("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemId(long value) {
/* 208 */     set("OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setObjectItemIdNull() {
/* 211 */     set("OBJECT_ITEM_ID", null);
/*     */   }
/*     */ 
/*     */   public long getObjectItemId() {
/* 215 */     return DataType.getAsLong(get("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public long getObjectItemIdInitialValue() {
/* 219 */     return DataType.getAsLong(getOldObj("OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrD(long value) {
/* 223 */     initProperty("EXTEND_ATTR_D", new Long(value));
/*     */   }
/*     */   public void setExtendAttrD(long value) {
/* 226 */     set("EXTEND_ATTR_D", new Long(value));
/*     */   }
/*     */   public void setExtendAttrDNull() {
/* 229 */     set("EXTEND_ATTR_D", null);
/*     */   }
/*     */ 
/*     */   public long getExtendAttrD() {
/* 233 */     return DataType.getAsLong(get("EXTEND_ATTR_D"));
/*     */   }
/*     */ 
/*     */   public long getExtendAttrDInitialValue() {
/* 237 */     return DataType.getAsLong(getOldObj("EXTEND_ATTR_D"));
/*     */   }
/*     */ 
/*     */   public void initRelatType(String value) {
/* 241 */     initProperty("RELAT_TYPE", value);
/*     */   }
/*     */   public void setRelatType(String value) {
/* 244 */     set("RELAT_TYPE", value);
/*     */   }
/*     */   public void setRelatTypeNull() {
/* 247 */     set("RELAT_TYPE", null);
/*     */   }
/*     */ 
/*     */   public String getRelatType() {
/* 251 */     return DataType.getAsString(get("RELAT_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getRelatTypeInitialValue() {
/* 255 */     return DataType.getAsString(getOldObj("RELAT_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initRelatObjectItemId(long value) {
/* 259 */     initProperty("RELAT_OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setRelatObjectItemId(long value) {
/* 262 */     set("RELAT_OBJECT_ITEM_ID", new Long(value));
/*     */   }
/*     */   public void setRelatObjectItemIdNull() {
/* 265 */     set("RELAT_OBJECT_ITEM_ID", null);
/*     */   }
/*     */ 
/*     */   public long getRelatObjectItemId() {
/* 269 */     return DataType.getAsLong(get("RELAT_OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public long getRelatObjectItemIdInitialValue() {
/* 273 */     return DataType.getAsLong(getOldObj("RELAT_OBJECT_ITEM_ID"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrI(Timestamp value) {
/* 277 */     initProperty("EXTEND_ATTR_I", value);
/*     */   }
/*     */   public void setExtendAttrI(Timestamp value) {
/* 280 */     set("EXTEND_ATTR_I", value);
/*     */   }
/*     */   public void setExtendAttrINull() {
/* 283 */     set("EXTEND_ATTR_I", null);
/*     */   }
/*     */ 
/*     */   public Timestamp getExtendAttrI() {
/* 287 */     return DataType.getAsDateTime(get("EXTEND_ATTR_I"));
/*     */   }
/*     */ 
/*     */   public Timestamp getExtendAttrIInitialValue() {
/* 291 */     return DataType.getAsDateTime(getOldObj("EXTEND_ATTR_I"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrE(double value) {
/* 295 */     initProperty("EXTEND_ATTR_E", new Double(value));
/*     */   }
/*     */   public void setExtendAttrE(double value) {
/* 298 */     set("EXTEND_ATTR_E", new Double(value));
/*     */   }
/*     */   public void setExtendAttrENull() {
/* 301 */     set("EXTEND_ATTR_E", null);
/*     */   }
/*     */ 
/*     */   public double getExtendAttrE() {
/* 305 */     return DataType.getAsDouble(get("EXTEND_ATTR_E"));
/*     */   }
/*     */ 
/*     */   public double getExtendAttrEInitialValue() {
/* 309 */     return DataType.getAsDouble(getOldObj("EXTEND_ATTR_E"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrA(String value) {
/* 313 */     initProperty("EXTEND_ATTR_A", value);
/*     */   }
/*     */   public void setExtendAttrA(String value) {
/* 316 */     set("EXTEND_ATTR_A", value);
/*     */   }
/*     */   public void setExtendAttrANull() {
/* 319 */     set("EXTEND_ATTR_A", null);
/*     */   }
/*     */ 
/*     */   public String getExtendAttrA() {
/* 323 */     return DataType.getAsString(get("EXTEND_ATTR_A"));
/*     */   }
/*     */ 
/*     */   public String getExtendAttrAInitialValue() {
/* 327 */     return DataType.getAsString(getOldObj("EXTEND_ATTR_A"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrF(double value) {
/* 331 */     initProperty("EXTEND_ATTR_F", new Double(value));
/*     */   }
/*     */   public void setExtendAttrF(double value) {
/* 334 */     set("EXTEND_ATTR_F", new Double(value));
/*     */   }
/*     */   public void setExtendAttrFNull() {
/* 337 */     set("EXTEND_ATTR_F", null);
/*     */   }
/*     */ 
/*     */   public double getExtendAttrF() {
/* 341 */     return DataType.getAsDouble(get("EXTEND_ATTR_F"));
/*     */   }
/*     */ 
/*     */   public double getExtendAttrFInitialValue() {
/* 345 */     return DataType.getAsDouble(getOldObj("EXTEND_ATTR_F"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrK(String value) {
/* 349 */     initProperty("EXTEND_ATTR_K", value);
/*     */   }
/*     */   public void setExtendAttrK(String value) {
/* 352 */     set("EXTEND_ATTR_K", value);
/*     */   }
/*     */   public void setExtendAttrKNull() {
/* 355 */     set("EXTEND_ATTR_K", null);
/*     */   }
/*     */ 
/*     */   public String getExtendAttrK() {
/* 359 */     return DataType.getAsString(get("EXTEND_ATTR_K"));
/*     */   }
/*     */ 
/*     */   public String getExtendAttrKInitialValue() {
/* 363 */     return DataType.getAsString(getOldObj("EXTEND_ATTR_K"));
/*     */   }
/*     */ 
/*     */   public void initExtendAttrB(String value) {
/* 367 */     initProperty("EXTEND_ATTR_B", value);
/*     */   }
/*     */   public void setExtendAttrB(String value) {
/* 370 */     set("EXTEND_ATTR_B", value);
/*     */   }
/*     */   public void setExtendAttrBNull() {
/* 373 */     set("EXTEND_ATTR_B", null);
/*     */   }
/*     */ 
/*     */   public String getExtendAttrB() {
/* 377 */     return DataType.getAsString(get("EXTEND_ATTR_B"));
/*     */   }
/*     */ 
/*     */   public String getExtendAttrBInitialValue() {
/* 381 */     return DataType.getAsString(getOldObj("EXTEND_ATTR_B"));
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  41 */       S_TYPE = ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */     } catch (Exception e) {
/*  43 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.bo.BOVMObjectItemRelatBean
 * JD-Core Version:    0.5.4
 */