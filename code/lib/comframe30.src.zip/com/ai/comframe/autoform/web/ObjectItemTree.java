/*     */ package com.ai.comframe.autoform.web;
/*     */ 
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.web.tag.dbtree.AIDBTreeNode;
/*     */ import com.ai.appframe2.web.tag.dbtree.AIDBTreeNodeInterface;
/*     */ import com.ai.appframe2.web.tag.dbtree.DBTreeNewDataModelInterface;
/*     */ import com.ai.appframe2.web.tag.dbtree.QueryTreeDataInterface;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
/*     */ import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
/*     */ import com.ai.comframe.autoform.service.interfaces.IAutoFormSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletRequest;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ObjectItemTree
/*     */   implements DBTreeNewDataModelInterface, QueryTreeDataInterface
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(ObjectItemTree.class);
/*     */ 
/*     */   public AIDBTreeNodeInterface getRootNode()
/*     */   {
/*  35 */     AIDBTreeNode node = new AIDBTreeNode();
/*  36 */     node.setValue("-1");
/*  37 */     node.setLabel(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.webvObjectItemTree.getRootNode_yuanjianlib"));
/*     */ 
/*  39 */     node.setUserObj("");
/*  40 */     return node;
/*     */   }
/*     */ 
/*     */   public void getChildren(AIDBTreeNodeInterface pParentNode, int getChildDeep)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  55 */       String pParentVal = pParentNode.getValue();
/*  56 */       String aParentUserObj = pParentNode.getUserObj();
/*  57 */       HashMap aParentUserObjMap = getNodeUdfObjMap(aParentUserObj);
/*  58 */       String aParentItemTypeCode = (String)aParentUserObjMap.get("OBJECT_ITEM_TYPE_CODE");
/*  59 */       String aParentItemKindId = (String)aParentUserObjMap.get("OBJECT_ITEM_KIND_ID");
/*  60 */       String aParentNodeType = (String)aParentUserObjMap.get("OBJECT_NODE_TYPE");
/*  61 */       String aParentNodeIcon = pParentNode.getFoldClosePicUrl();
/*     */ 
/*  63 */       IAutoFormSV autoformSV = (IAutoFormSV)ServiceFactory.getService(IAutoFormSV.class);
/*  64 */       if (pParentVal.equalsIgnoreCase("-1")) {
/*  65 */         AIDBTreeNode node = new AIDBTreeNode();
/*  66 */         node.setValue("0");
/*     */ 
/*  68 */         node.setLabel(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.ObjectItemTree_workflowTemplate"));
/*  69 */         HashMap aUserMap = new HashMap();
/*  70 */         aUserMap.put("OBJECT_ITEM_TYPE_CODE", "WORKFLOW");
/*  71 */         aUserMap.put("OBJECT_ITEM_KIND_ID", "0");
/*  72 */         aUserMap.put("OBJECT_ITEM_ID", "-1");
/*  73 */         aUserMap.put("OBJECT_NODE_TYPE", "OBJECT_ITEM_TYPE");
/*  74 */         node.setUserObj(getNodeUdfObjStr(aUserMap));
/*  75 */         node.setLeaf(false);
/*  76 */         if (pParentNode.isChecked())
/*  77 */           node.setChecked(true);
/*  78 */         ((AIDBTreeNode)pParentNode).addChild(node);
/*     */       }
/*     */       else {
/*  81 */         if (("OBJECT_ITEM".equals(aParentNodeType)) && ("WORKFLOW".equals(aParentItemTypeCode))) {
/*  82 */           IQBOVMObjectItemRelatValue[] objectItemsRelats = autoformSV.getRelatObjectItemByObjItemId(Long.parseLong(pParentVal));
/*     */ 
/*  84 */           if ((objectItemsRelats != null) && (objectItemsRelats.length > 0)) {
/*  85 */             for (int i = 0; i < objectItemsRelats.length; ++i) {
/*  86 */               AIDBTreeNode node = new AIDBTreeNode();
/*  87 */               node.setValue(String.valueOf(objectItemsRelats[i].getRelatObjectItemId()));
/*  88 */               node.setLabel(objectItemsRelats[i].getName());
/*  89 */               HashMap aUserMap = new HashMap();
/*  90 */               aUserMap.put("OBJECT_ITEM_TYPE_CODE", objectItemsRelats[i].getRelatItemType());
/*  91 */               aUserMap.put("OBJECT_ITEM_KIND_ID", "-1");
/*  92 */               aUserMap.put("OBJECT_ITEM_ID", "" + objectItemsRelats[i].getRelatObjectItemId());
/*  93 */               aUserMap.put("OBJECT_NODE_TYPE", "OBJECT_ITEM");
/*  94 */               node.setUserObj(getNodeUdfObjStr(aUserMap));
/*  95 */               node.setLeaf(true);
/*  96 */               String aIconPath = getObjectItemIcon(objectItemsRelats[i].getRelatItemType());
/*  97 */               if ((aIconPath != null) && (!aIconPath.trim().equals(""))) {
/*  98 */                 node.setFoldClosePicUrl(aIconPath);
/*  99 */                 node.setFoldOpenPicUrl(aIconPath);
/* 100 */                 node.setLeafPicUrl(aIconPath);
/*     */               }
/* 102 */               if (pParentNode.isChecked())
/* 103 */                 node.setChecked(true);
/* 104 */               ((AIDBTreeNode)pParentNode).addChild(node);
/*     */             }
/*     */           }
/* 107 */           return;
/*     */         }
/*     */ 
/* 111 */         IBOVMObjectItemKindValue[] objectItemKinds = null;
/* 112 */         if (!"-1".equals(aParentItemKindId)) {
/* 113 */           objectItemKinds = autoformSV.getObjectItemKinds(aParentItemTypeCode, Long.parseLong(aParentItemKindId));
/*     */         }
/* 115 */         if ((objectItemKinds != null) && (objectItemKinds.length > 0))
/*     */         {
/* 117 */           for (int i = 0; i < objectItemKinds.length; ++i) {
/* 118 */             AIDBTreeNode node = new AIDBTreeNode();
/* 119 */             node.setValue(String.valueOf(objectItemKinds[i].getKindId()));
/* 120 */             node.setLabel(objectItemKinds[i].getItemKindName());
/* 121 */             HashMap aUserMap = new HashMap();
/* 122 */             aUserMap.put("OBJECT_ITEM_TYPE_CODE", aParentItemTypeCode);
/* 123 */             aUserMap.put("OBJECT_ITEM_KIND_ID", "" + objectItemKinds[i].getKindId());
/* 124 */             aUserMap.put("OBJECT_ITEM_ID", "-1");
/* 125 */             aUserMap.put("OBJECT_NODE_TYPE", "OBJECT_ITEM_KIND");
/* 126 */             node.setUserObj(getNodeUdfObjStr(aUserMap));
/* 127 */             node.setLeaf(false);
/* 128 */             node.setFoldClosePicUrl(aParentNodeIcon);
/* 129 */             node.setFoldOpenPicUrl(aParentNodeIcon);
/* 130 */             if (pParentNode.isChecked())
/* 131 */               node.setChecked(true);
/* 132 */             ((AIDBTreeNode)pParentNode).addChild(node);
/*     */           }
/*     */         }
/*     */ 
/* 136 */         IBOVMObjectItemValue[] objectItems = autoformSV.getObjectItemByItemKindId(aParentItemTypeCode, new Long(aParentItemKindId).longValue());
/*     */ 
/* 139 */         for (int i = 0; i < objectItems.length; ++i) {
/* 140 */           AIDBTreeNode node = new AIDBTreeNode();
/* 141 */           node.setValue(String.valueOf(objectItems[i].getObjectItemId()));
/* 142 */           node.setLabel(objectItems[i].getName());
/* 143 */           HashMap aUserMap = new HashMap();
/* 144 */           aUserMap.put("OBJECT_ITEM_TYPE_CODE", objectItems[i].getItemType());
/* 145 */           aUserMap.put("OBJECT_ITEM_KIND_ID", aParentItemKindId);
/* 146 */           aUserMap.put("OBJECT_ITEM_ID", "" + objectItems[i].getObjectItemId());
/* 147 */           aUserMap.put("OBJECT_NODE_TYPE", "OBJECT_ITEM");
/* 148 */           node.setUserObj(getNodeUdfObjStr(aUserMap));
/* 149 */           node.setLeaf(false);
/* 150 */           String aIconPath = getObjectItemIcon(objectItems[i].getItemType());
/* 151 */           if ((aIconPath != null) && (!aIconPath.trim().equals(""))) {
/* 152 */             node.setFoldClosePicUrl(aIconPath);
/* 153 */             node.setFoldOpenPicUrl(aIconPath);
/* 154 */             node.setLeafPicUrl(aIconPath);
/*     */           }
/* 156 */           if (pParentNode.isChecked())
/* 157 */             node.setChecked(true);
/* 158 */           ((AIDBTreeNode)pParentNode).addChild(node);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 163 */       log.error(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.ObjectItemTree_getChildException"), ex);
/* 164 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getTreeData(AIDBTreeNodeInterface parentNode, HashMap paraMap)
/*     */     throws Exception
/*     */   {
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */   public String getNodeUdfObjStr(HashMap aMap)
/*     */     throws Exception
/*     */   {
/* 192 */     String ret = "";
/*     */     try {
/* 194 */       if ((aMap != null) && (aMap.size() > 0)) {
/* 195 */         sb = new StringBuffer();
/* 196 */         Iterator attrs = aMap.keySet().iterator();
/* 197 */         while (attrs.hasNext()) {
/* 198 */           String aProp = ((String)attrs.next()).toUpperCase();
/* 199 */           sb.append(aProp + "=" + aMap.get(aProp) + ",");
/*     */         }
/* 201 */         ret = sb.toString();
/*     */       }
/* 203 */       StringBuffer sb = ret;
/*     */ 
/* 208 */       return sb;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 205 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public HashMap getNodeUdfObjMap(String aStr)
/*     */     throws Exception
/*     */   {
/* 220 */     HashMap ret = new HashMap();
/*     */     try {
/* 222 */       if ((aStr != null) && (!aStr.trim().equals(""))) {
/* 223 */         aStrAry = aStr.split(",");
/* 224 */         if ((aStrAry != null) && (aStrAry.length > 0)) {
/* 225 */           for (int i = 0; i < aStrAry.length; ++i) {
/* 226 */             String[] aValueAry = aStrAry[i].split("=");
/* 227 */             if ((aValueAry != null) && (aValueAry.length > 0)) {
/* 228 */               ret.put(aValueAry[0], aValueAry[1]);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 233 */       String[] aStrAry = ret;
/*     */ 
/* 238 */       return aStrAry;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 235 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void init(ServletRequest req) throws Exception {
/*     */   }
/*     */ 
/*     */   private String getObjectItemIcon(String itemType) {
/* 246 */     String iconPath = "";
/* 247 */     if ("WORKFLOW_KIND".equals(itemType)) {
/* 248 */       iconPath = "/workflow/autoform/images/workflow_type.png";
/* 249 */       return iconPath;
/*     */     }
/* 251 */     if ("WORKFLOW".equals(itemType)) {
/* 252 */       iconPath = "/workflow/autoform/images/workflow.png";
/* 253 */       return iconPath;
/*     */     }
/* 255 */     if ("WORKFLOW_NODE".equals(itemType)) {
/* 256 */       iconPath = "/workflow/autoform/images/workflownode.png";
/* 257 */       return iconPath;
/*     */     }
/* 259 */     return iconPath;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.web.ObjectItemTree
 * JD-Core Version:    0.5.4
 */