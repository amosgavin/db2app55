/*     */ package com.ai.comframe.autoform.web;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.web.CustomProperty;
/*     */ import com.ai.appframe2.web.DataContainerList;
/*     */ import com.ai.appframe2.web.HttpUtil;
/*     */ import com.ai.appframe2.web.action.BaseAction;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
/*     */ import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
/*     */ import com.ai.comframe.autoform.service.interfaces.IAutoFormSV;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class AutoFormAction extends BaseAction
/*     */ {
/*     */   public IBOVMObjectItemValue[] getObjectItemDetail(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  37 */       IBOVMObjectItemValue[] ObjectItems = new IBOVMObjectItemValue[1];
/*  38 */       String aObjectItemId = HttpUtil.getParameter(request, "OBJECT_ITEM_ID");
/*  39 */       if (aObjectItemId != null) {
/*  40 */         autoformSV = getAutoFormSV();
/*  41 */         IBOVMObjectItemValue aObjectItem = autoformSV.getObjectItemDetail(Long.parseLong(aObjectItemId));
/*  42 */         ObjectItems[0] = aObjectItem;
/*     */       }
/*  44 */       IAutoFormSV autoformSV = ObjectItems;
/*     */ 
/*  49 */       return autoformSV;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  46 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemKindValue[] getObjectItemKindDetail(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  62 */       IBOVMObjectItemKindValue[] ObjectItemKinds = new IBOVMObjectItemKindValue[1];
/*  63 */       String aObjectItemKindId = HttpUtil.getParameter(request, "KIND_ID");
/*  64 */       if (aObjectItemKindId != null) {
/*  65 */         autoformSV = getAutoFormSV();
/*  66 */         IBOVMObjectItemKindValue aObjectItemKind = autoformSV.getObjectItemKindDetail(aObjectItemKindId);
/*  67 */         ObjectItemKinds[0] = aObjectItemKind;
/*     */       }
/*  69 */       IAutoFormSV autoformSV = ObjectItemKinds;
/*     */ 
/*  74 */       return autoformSV;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  71 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public IQBOVMObjectItemRelatValue[] getObjectItemRelate(HttpServletRequest request)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/*  87 */       IQBOVMObjectItemRelatValue[] QBOObjectItemRelates = null;
/*  88 */       String aObjectItemId = HttpUtil.getParameter(request, "OBJECT_ITEM_ID");
/*  89 */       String aRelaType = HttpUtil.getParameter(request, "RELAT_TYPE");
/*  90 */       if (aObjectItemId != null) {
/*  91 */         autoformSV = getAutoFormSV();
/*  92 */         QBOObjectItemRelates = autoformSV.getObjectItemRelate(Long.parseLong(aObjectItemId), aRelaType);
/*     */       }
/*  94 */       IAutoFormSV autoformSV = QBOObjectItemRelates;
/*     */ 
/*  99 */       return autoformSV;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  96 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addObjectItemRelat(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 112 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 114 */       String aRelatObjectItemIdList = HttpUtil.getAsString(request, "RELAT_OBJECT_ITEM_ID_LIST");
/* 115 */       String ObjectItemId = HttpUtil.getAsString(request, "OBJECT_ITEM_ID").trim();
/* 116 */       String aRelatType = HttpUtil.getAsString(request, "RELAT_TYPE").trim();
/* 117 */       String aRelatId = HttpUtil.getAsString(request, "RELAT_ID").trim();
/* 118 */       long lRelatId = 0L;
/* 119 */       if ((aRelatId != null) && (Long.parseLong(aRelatId) > 0L)) {
/* 120 */         lRelatId = Long.parseLong(aRelatId);
/*     */       }
/* 122 */       String aAddType = HttpUtil.getAsString(request, "ADD_TYPE");
/* 123 */       String aIsVisible = HttpUtil.getAsString(request, "IS_VISIBLE");
/* 124 */       String aIsEditable = HttpUtil.getAsString(request, "IS_EDITABLE");
/* 125 */       String[] aStrRelatObjectItemId = aRelatObjectItemIdList.split(",");
/* 126 */       Long[] RelatObjectItemId = new Long[aStrRelatObjectItemId.length];
/* 127 */       for (int i = 0; i < aStrRelatObjectItemId.length; ++i) {
/* 128 */         RelatObjectItemId[i] = new Long(aStrRelatObjectItemId[i]);
/*     */       }
/* 130 */       IAutoFormSV autoformSV = getAutoFormSV();
/*     */ 
/* 132 */       boolean aresu = autoformSV.addObjectItemRelat(Long.parseLong(ObjectItemId), RelatObjectItemId, aRelatType.trim(), aAddType, lRelatId, aIsVisible, aIsEditable);
/*     */ 
/* 134 */       if (aresu == true) {
/* 135 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.addObjectItemRelat_addRelS"));
/*     */       }
/*     */       else {
/* 138 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.addObjectItemRelat_addRelF"));
/*     */       }
/*     */ 
/* 141 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     catch (Exception ex) {
/* 144 */       ex.printStackTrace();
/* 145 */       cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.addObjectItemRelat__addRelFReason") + ex.getMessage());
/*     */ 
/* 150 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteObjectItemRelat(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 167 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 169 */       long aRelatId = HttpUtil.getAsLong(request, "RELAT_ID");
/* 170 */       String aDelType = HttpUtil.getAsString(request, "DELETE_TYPE");
/* 171 */       boolean aresu = false;
/* 172 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 173 */       if (aDelType.trim().equals("OBJECT_ITEM_RELAT"))
/* 174 */         aresu = autoformSV.deleteObjectItemRelat(aRelatId);
/*     */       else {
/* 176 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction_unSuppportRelate"));
/*     */       }
/*     */ 
/* 179 */       if (aresu == true) {
/* 180 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delSuccess"));
/*     */       }
/*     */       else {
/* 183 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailed"));
/*     */       }
/*     */ 
/* 186 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     catch (Exception ex) {
/* 189 */       ex.printStackTrace();
/* 190 */       cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailedReason") + ex.getMessage());
/*     */ 
/* 195 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteObjectItemKind(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 212 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 214 */       long aKindId = HttpUtil.getAsLong(request, "KIND_ID");
/* 215 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 216 */       boolean aresu = autoformSV.deleteObjectItemKind(aKindId);
/* 217 */       if (aresu == true) {
/* 218 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delSuccess"));
/*     */       }
/*     */       else {
/* 221 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailed"));
/*     */       }
/*     */ 
/* 224 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     catch (Exception ex) {
/* 227 */       ex.printStackTrace();
/* 228 */       cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailedReason") + ex.getMessage());
/*     */ 
/* 233 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteObjectItem(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 250 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 252 */       long aObjectItemId = HttpUtil.getAsLong(request, "OBJECT_ITEM_ID");
/* 253 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 254 */       boolean aresu = autoformSV.deleteObjectItem(aObjectItemId);
/* 255 */       if (aresu == true) {
/* 256 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delSuccess"));
/*     */       }
/*     */       else {
/* 259 */         cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailed"));
/*     */       }
/*     */ 
/* 262 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     catch (Exception ex) {
/* 265 */       ex.printStackTrace();
/* 266 */       cp.set("retValue", ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.deleteObjectItemRelat_delFailedReason") + ex.getMessage());
/*     */ 
/* 271 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveTaskUrl(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 297 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 299 */       response.setContentType("text/xml; charset=GBK");
/*     */ 
/* 301 */       String list = HttpUtil.getAsString(request, "objectItemIds");
/*     */ 
/* 303 */       if ((list == null) || (list.trim().equals(""))) {
/* 304 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItem_dcListEmpty"));
/*     */       }
/*     */ 
/* 307 */       String[] List = list.split(",");
/* 308 */       DataContainerList[] Lists = HttpUtil.getDataContainerLists(request.getInputStream(), null);
/*     */ 
/* 310 */       DataContainerInterface[] urls = Lists[0].getAllDataContainerInterface();
/* 311 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 312 */       String retValue = autoformSV.saveTaskUrl(List, urls);
/* 313 */       cp.set("retVal", retValue);
/*     */     } catch (Exception ex) {
/* 315 */       ex.printStackTrace();
/* 316 */       cp.set("retVal", ex.getLocalizedMessage());
/*     */     } finally {
/* 318 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveObjectItemKind(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 334 */       response.setContentType("text/xml; charset=GBK");
/* 335 */       CustomProperty cp = CustomProperty.getInstance();
/* 336 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), null);
/* 337 */       DataContainerInterface dc = dcLists[0].getAllDataContainerInterface()[0];
/* 338 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 339 */       String retValue = autoformSV.saveObjectItemKind(dc);
/* 340 */       cp.set("retVal", retValue);
/* 341 */       HttpUtil.showInfo(response, cp);
/*     */     } catch (Exception ex) {
/* 343 */       ex.printStackTrace();
/* 344 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private IAutoFormSV getAutoFormSV()
/*     */   {
/* 358 */     return (IAutoFormSV)ServiceFactory.getService(IAutoFormSV.class);
/*     */   }
/*     */ 
/*     */   public void getDetailInfo(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 369 */     CustomProperty cp = CustomProperty.getInstance();
/* 370 */     String msg = "";
/* 371 */     String taskTag = "";
/*     */     try {
/* 373 */       String tmpName = HttpUtil.getAsString(request, "tmpName");
/* 374 */       ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 375 */       WorkflowTemplate template = templateSV.getWorkflowTemplateByTag(tmpName);
/* 376 */       if ((template != null) && (null != template.getTaskTag())) {
/* 377 */         msg = "Y";
/* 378 */         taskTag = template.getTaskTag();
/* 379 */         cp.set("msg", "Y");
/* 380 */         cp.set("taskTag", taskTag);
/*     */       } else {
/* 382 */         msg = "N";
/*     */       }
/* 384 */       cp.set("msg", msg);
/*     */     }
/*     */     catch (Exception e) {
/* 387 */       cp.set("msg", "N");
/*     */     }
/*     */     finally {
/* 390 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveObjectItem(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 404 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 406 */       response.setContentType("text/xml; charset=GBK");
/*     */ 
/* 408 */       String DC_LIST = HttpUtil.getAsString(request, "DC_LIST");
/*     */ 
/* 410 */       if ((DC_LIST == null) || (DC_LIST.trim().equals(""))) {
/* 411 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItem_dcListEmpty"));
/*     */       }
/*     */ 
/* 414 */       String[] dcList = DC_LIST.split(",");
/* 415 */       DataContainerList[] dcLists = HttpUtil.getDataContainerLists(request.getInputStream(), null);
/* 416 */       if (dcList.length != dcLists.length) {
/* 417 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItem_dcNumWrong"));
/*     */       }
/*     */ 
/* 420 */       for (int i = 0; i < dcList.length; ++i) {
/* 421 */         if (!dcList[i].equalsIgnoreCase("CustomerDC")) {
/*     */           continue;
/*     */         }
/*     */       }
/* 425 */       long aObjectItemKindId = HttpUtil.getAsLong(request, "OBJECT_ITEM_KIND_ID");
/* 426 */       String selectTemplateCheck = HttpUtil.getAsString(request, "selectTemplateCheck");
/* 427 */       IAutoFormSV autoformSV = getAutoFormSV();
/* 428 */       String retValue = autoformSV.saveObjectItem(dcList, dcLists, aObjectItemKindId, selectTemplateCheck);
/* 429 */       cp.set("retVal", retValue);
/*     */     }
/*     */     catch (Exception ex) {
/* 432 */       ex.printStackTrace();
/* 433 */       cp.set("retVal", ex.getMessage());
/*     */     } finally {
/* 435 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void checkURL(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 459 */     CustomProperty cp = CustomProperty.getInstance();
/*     */     try {
/* 461 */       int urlBusiType = 1;
/* 462 */       String aWorkFlowCode = HttpUtil.getAsString(request, "WORK_FLOW_CODE");
/* 463 */       String aWorkFlowNodeCode = HttpUtil.getAsString(request, "WORK_FLOW_NODE_CODE");
/* 464 */       urlBusiType = HttpUtil.getAsInt(request, "urlType");
/* 465 */       IAutoFormSV autoformSV = (IAutoFormSV)ServiceFactory.getService(IAutoFormSV.class);
/* 466 */       String URL = autoformSV.getObjectItemUrlForTask(aWorkFlowCode, aWorkFlowNodeCode, urlBusiType);
/* 467 */       if ((URL != null) && (URL.length() > 0))
/* 468 */         cp.set("url", URL);
/*     */       else
/* 470 */         cp.set("url", "");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 474 */       cp.set("url", "");
/*     */     } finally {
/* 476 */       HttpUtil.showInfo(response, cp);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.web.AutoFormAction
 * JD-Core Version:    0.5.4
 */