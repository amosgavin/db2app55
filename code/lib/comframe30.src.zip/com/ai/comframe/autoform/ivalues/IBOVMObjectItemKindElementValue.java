package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IBOVMObjectItemKindElementValue extends DataStructInterface
{
  public static final String S_ItemKindRelatId = "ITEM_KIND_RELAT_ID";
  public static final String S_ItemKindId = "ITEM_KIND_ID";
  public static final String S_ObjectItemId = "OBJECT_ITEM_ID";

  public abstract long getItemKindRelatId();

  public abstract long getItemKindId();

  public abstract long getObjectItemId();

  public abstract void setItemKindRelatId(long paramLong);

  public abstract void setItemKindId(long paramLong);

  public abstract void setObjectItemId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindElementValue
 * JD-Core Version:    0.5.4
 */