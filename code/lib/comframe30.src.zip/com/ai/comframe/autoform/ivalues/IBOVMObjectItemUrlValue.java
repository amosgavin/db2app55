package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IBOVMObjectItemUrlValue extends DataStructInterface
{
  public static final String S_UrlBusiType = "URL_BUSI_TYPE";
  public static final String S_Url = "URL";
  public static final String S_ObjectItemId = "OBJECT_ITEM_ID";

  public abstract int getUrlBusiType();

  public abstract String getUrl();

  public abstract long getObjectItemId();

  public abstract void setUrlBusiType(int paramInt);

  public abstract void setUrl(String paramString);

  public abstract void setObjectItemId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue
 * JD-Core Version:    0.5.4
 */