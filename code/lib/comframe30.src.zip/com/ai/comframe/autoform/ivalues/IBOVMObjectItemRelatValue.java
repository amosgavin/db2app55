package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVMObjectItemRelatValue extends DataStructInterface
{
  public static final String S_State = "STATE";
  public static final String S_ExtendAttrG = "EXTEND_ATTR_G";
  public static final String S_ExtendAttrJ = "EXTEND_ATTR_J";
  public static final String S_ExtendAttrH = "EXTEND_ATTR_H";
  public static final String S_ExtendAttrC = "EXTEND_ATTR_C";
  public static final String S_ItemRelatId = "ITEM_RELAT_ID";
  public static final String S_Remarks = "REMARKS";
  public static final String S_SortNo = "SORT_NO";
  public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
  public static final String S_ExtendAttrD = "EXTEND_ATTR_D";
  public static final String S_RelatType = "RELAT_TYPE";
  public static final String S_RelatObjectItemId = "RELAT_OBJECT_ITEM_ID";
  public static final String S_ExtendAttrI = "EXTEND_ATTR_I";
  public static final String S_ExtendAttrE = "EXTEND_ATTR_E";
  public static final String S_ExtendAttrA = "EXTEND_ATTR_A";
  public static final String S_ExtendAttrF = "EXTEND_ATTR_F";
  public static final String S_ExtendAttrK = "EXTEND_ATTR_K";
  public static final String S_ExtendAttrB = "EXTEND_ATTR_B";

  public abstract String getState();

  public abstract String getExtendAttrG();

  public abstract Timestamp getExtendAttrJ();

  public abstract String getExtendAttrH();

  public abstract long getExtendAttrC();

  public abstract long getItemRelatId();

  public abstract String getRemarks();

  public abstract int getSortNo();

  public abstract long getObjectItemId();

  public abstract long getExtendAttrD();

  public abstract String getRelatType();

  public abstract long getRelatObjectItemId();

  public abstract Timestamp getExtendAttrI();

  public abstract double getExtendAttrE();

  public abstract String getExtendAttrA();

  public abstract double getExtendAttrF();

  public abstract String getExtendAttrK();

  public abstract String getExtendAttrB();

  public abstract void setState(String paramString);

  public abstract void setExtendAttrG(String paramString);

  public abstract void setExtendAttrJ(Timestamp paramTimestamp);

  public abstract void setExtendAttrH(String paramString);

  public abstract void setExtendAttrC(long paramLong);

  public abstract void setItemRelatId(long paramLong);

  public abstract void setRemarks(String paramString);

  public abstract void setSortNo(int paramInt);

  public abstract void setObjectItemId(long paramLong);

  public abstract void setExtendAttrD(long paramLong);

  public abstract void setRelatType(String paramString);

  public abstract void setRelatObjectItemId(long paramLong);

  public abstract void setExtendAttrI(Timestamp paramTimestamp);

  public abstract void setExtendAttrE(double paramDouble);

  public abstract void setExtendAttrA(String paramString);

  public abstract void setExtendAttrF(double paramDouble);

  public abstract void setExtendAttrK(String paramString);

  public abstract void setExtendAttrB(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IBOVMObjectItemRelatValue
 * JD-Core Version:    0.5.4
 */