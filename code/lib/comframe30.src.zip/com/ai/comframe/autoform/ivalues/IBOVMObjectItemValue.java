package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;
import java.sql.Timestamp;

public abstract interface IBOVMObjectItemValue extends DataStructInterface
{
  public static final String S_FinishcodeDsParam = "FINISHCODE_DS_PARAM";
  public static final String S_FinishcodeSv = "FINISHCODE_SV";
  public static final String S_State = "STATE";
  public static final String S_ModifyDate = "MODIFY_DATE";
  public static final String S_Creater = "CREATER";
  public static final String S_Remarks = "REMARKS";
  public static final String S_DataCommitSv = "DATA_COMMIT_SV";
  public static final String S_CreateDate = "CREATE_DATE";
  public static final String S_ObjectItemId = "OBJECT_ITEM_ID";
  public static final String S_DataCommitSvFunction = "DATA_COMMIT_SV_FUNCTION";
  public static final String S_Islock = "ISLOCK";
  public static final String S_BusinessDomainId = "BUSINESS_DOMAIN_ID";
  public static final String S_FinishcodeSvFunction = "FINISHCODE_SV_FUNCTION";
  public static final String S_SortBy = "SORT_BY";
  public static final String S_BusinessTypeId = "BUSINESS_TYPE_ID";
  public static final String S_Checker = "CHECKER";
  public static final String S_Url = "URL";
  public static final String S_ItemType = "ITEM_TYPE";
  public static final String S_Code = "CODE";
  public static final String S_Name = "NAME";
  public static final String S_Description = "DESCRIPTION";
  public static final String S_FinishcodeDs = "FINISHCODE_DS";

  public abstract String getFinishcodeDsParam();

  public abstract String getFinishcodeSv();

  public abstract String getState();

  public abstract Timestamp getModifyDate();

  public abstract long getCreater();

  public abstract String getRemarks();

  public abstract String getDataCommitSv();

  public abstract Timestamp getCreateDate();

  public abstract long getObjectItemId();

  public abstract String getDataCommitSvFunction();

  public abstract String getIslock();

  public abstract long getBusinessDomainId();

  public abstract String getFinishcodeSvFunction();

  public abstract int getSortBy();

  public abstract long getBusinessTypeId();

  public abstract long getChecker();

  public abstract String getUrl();

  public abstract String getItemType();

  public abstract String getCode();

  public abstract String getName();

  public abstract String getDescription();

  public abstract String getFinishcodeDs();

  public abstract void setFinishcodeDsParam(String paramString);

  public abstract void setFinishcodeSv(String paramString);

  public abstract void setState(String paramString);

  public abstract void setModifyDate(Timestamp paramTimestamp);

  public abstract void setCreater(long paramLong);

  public abstract void setRemarks(String paramString);

  public abstract void setDataCommitSv(String paramString);

  public abstract void setCreateDate(Timestamp paramTimestamp);

  public abstract void setObjectItemId(long paramLong);

  public abstract void setDataCommitSvFunction(String paramString);

  public abstract void setIslock(String paramString);

  public abstract void setBusinessDomainId(long paramLong);

  public abstract void setFinishcodeSvFunction(String paramString);

  public abstract void setSortBy(int paramInt);

  public abstract void setBusinessTypeId(long paramLong);

  public abstract void setChecker(long paramLong);

  public abstract void setUrl(String paramString);

  public abstract void setItemType(String paramString);

  public abstract void setCode(String paramString);

  public abstract void setName(String paramString);

  public abstract void setDescription(String paramString);

  public abstract void setFinishcodeDs(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue
 * JD-Core Version:    0.5.4
 */