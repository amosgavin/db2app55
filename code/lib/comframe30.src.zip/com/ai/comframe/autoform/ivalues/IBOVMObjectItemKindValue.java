package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IBOVMObjectItemKindValue extends DataStructInterface
{
  public static final String S_KindId = "KIND_ID";
  public static final String S_ItemKindName = "ITEM_KIND_NAME";
  public static final String S_ParentKindId = "PARENT_KIND_ID";
  public static final String S_Sortby = "SORTBY";
  public static final String S_ItemKindCode = "ITEM_KIND_CODE";
  public static final String S_ObjectItemType = "OBJECT_ITEM_TYPE";

  public abstract long getKindId();

  public abstract String getItemKindName();

  public abstract long getParentKindId();

  public abstract int getSortby();

  public abstract String getItemKindCode();

  public abstract String getObjectItemType();

  public abstract void setKindId(long paramLong);

  public abstract void setItemKindName(String paramString);

  public abstract void setParentKindId(long paramLong);

  public abstract void setSortby(int paramInt);

  public abstract void setItemKindCode(String paramString);

  public abstract void setObjectItemType(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue
 * JD-Core Version:    0.5.4
 */