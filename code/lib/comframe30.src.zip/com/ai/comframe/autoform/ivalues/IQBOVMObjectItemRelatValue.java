package com.ai.comframe.autoform.ivalues;

import com.ai.appframe2.common.DataStructInterface;

public abstract interface IQBOVMObjectItemRelatValue extends DataStructInterface
{
  public static final String S_RelatItemType = "RELAT_ITEM_TYPE";
  public static final String S_RelatType = "RELAT_TYPE";
  public static final String S_RelatObjectItemId = "RELAT_OBJECT_ITEM_ID";
  public static final String S_RelatId = "RELAT_ID";
  public static final String S_TaskCode = "TASK_CODE";
  public static final String S_ItemType = "ITEM_TYPE";
  public static final String S_Name = "NAME";
  public static final String S_TemplateTag = "TEMPLATE_TAG";
  public static final String S_ObjectItemId = "OBJECT_ITEM_ID";

  public abstract String getRelatItemType();

  public abstract String getRelatType();

  public abstract long getRelatObjectItemId();

  public abstract long getRelatId();

  public abstract String getTaskCode();

  public abstract String getItemType();

  public abstract String getName();

  public abstract String getTemplateTag();

  public abstract long getObjectItemId();

  public abstract void setRelatItemType(String paramString);

  public abstract void setRelatType(String paramString);

  public abstract void setRelatObjectItemId(long paramLong);

  public abstract void setRelatId(long paramLong);

  public abstract void setTaskCode(String paramString);

  public abstract void setItemType(String paramString);

  public abstract void setName(String paramString);

  public abstract void setTemplateTag(String paramString);

  public abstract void setObjectItemId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue
 * JD-Core Version:    0.5.4
 */