/*     */ package com.ai.comframe.autoform.dao.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemBean;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemEngine;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemKindBean;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemKindElementBean;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemKindElementEngine;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemKindEngine;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemRelatBean;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemRelatEngine;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemUrlBean;
/*     */ import com.ai.comframe.autoform.bo.BOVMObjectItemUrlEngine;
/*     */ import com.ai.comframe.autoform.bo.QBOVMObjectItemRelatBean;
/*     */ import com.ai.comframe.autoform.bo.QBOVMObjectItemRelatEngine;
/*     */ import com.ai.comframe.autoform.dao.interfaces.IAutoFormDAO;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindElementValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
/*     */ import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.TaskTemplate;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AutoFormDAOImpl
/*     */   implements IAutoFormDAO
/*     */ {
/*     */   public IBOVMObjectItemKindValue[] getObjectItemKinds(String aObjectItemTypeCode, long aParentKindId)
/*     */     throws Exception
/*     */   {
/*  38 */     StringBuffer condition = new StringBuffer();
/*  39 */     HashMap parameter = new HashMap();
/*     */ 
/*  41 */     condition.append("OBJECT_ITEM_TYPE").append("=:").append("OBJECT_ITEM_TYPE");
/*     */ 
/*  43 */     parameter.put("OBJECT_ITEM_TYPE", aObjectItemTypeCode);
/*     */ 
/*  45 */     condition.append(" and ");
/*     */ 
/*  47 */     condition.append("PARENT_KIND_ID").append("=:").append("PARENT_KIND_ID");
/*  48 */     parameter.put("PARENT_KIND_ID", new Long(aParentKindId));
/*     */ 
/*  50 */     return BOVMObjectItemKindEngine.getBeans(condition.toString(), parameter);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue[] getObjectItemByItemKindId(String aParentItemTypeCode, long aParentItemKindId)
/*     */     throws Exception
/*     */   {
/*  56 */     StringBuilder sql = new StringBuilder("");
/*  57 */     Map parameter = new HashMap();
/*  58 */     sql.append(" select i.* from vm_object_item_kind_element e, vm_object_item i where ");
/*  59 */     sql.append(" e.item_kind_id = :ObjectItemKindId  and i.object_item_id = e.object_item_id  and i.state = :aState ");
/*  60 */     sql.append(" and i.item_type = :ObjectItemTypeCode ");
/*  61 */     parameter.put("ObjectItemKindId", String.valueOf(aParentItemKindId));
/*  62 */     parameter.put("ObjectItemTypeCode", aParentItemTypeCode);
/*  63 */     parameter.put("aState", "U");
/*  64 */     return BOVMObjectItemEngine.getBeansFromSql(sql.toString(), parameter);
/*     */   }
/*     */ 
/*     */   public IQBOVMObjectItemRelatValue[] getRelatObjectItemByObjItemId(long objItemID) throws Exception {
/*  68 */     StringBuilder condition = new StringBuilder("");
/*  69 */     Map param = new HashMap();
/*  70 */     condition.append("OBJECT_ITEM_ID").append(" = :objectItemId");
/*  71 */     param.put("objectItemId", String.valueOf(objItemID));
/*  72 */     return QBOVMObjectItemRelatEngine.getBeans(condition.toString(), param);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemKindValue getObjectItemKindDetail(long aObjectItemKindId) throws Exception {
/*  76 */     return BOVMObjectItemKindEngine.getBean(aObjectItemKindId);
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItemKind(long aKindId) throws Exception
/*     */   {
/*  81 */     BOVMObjectItemKindBean aBean = BOVMObjectItemKindEngine.getBean(aKindId);
/*  82 */     aBean.delete();
/*  83 */     BOVMObjectItemKindEngine.save(aBean);
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItem(long aObjectItemId) throws Exception {
/*     */     try {
/*  89 */       BOVMObjectItemBean aBean = BOVMObjectItemEngine.getBean(aObjectItemId);
/*  90 */       aBean.delete();
/*  91 */       BOVMObjectItemEngine.save(aBean);
/*     */ 
/*  93 */       IBOVMObjectItemKindElementValue[] obj = queryObjectItemKindElement(String.valueOf(aObjectItemId), -1, -1);
/*  94 */       deleteObjectItemKindElement(obj);
/*     */ 
/*  96 */       HashMap map = new HashMap();
/*     */ 
/*  98 */       String sql = "OBJECT_ITEM_ID= :aObjectItemId or RELAT_OBJECT_ITEM_ID=:bObjectItemId";
/*     */ 
/* 100 */       map.clear();
/* 101 */       map.put("aObjectItemId", String.valueOf(aObjectItemId));
/* 102 */       map.put("bObjectItemId", String.valueOf(aObjectItemId));
/* 103 */       BOVMObjectItemRelatBean[] aRelatBeans = BOVMObjectItemRelatEngine.getBeans(sql, map);
/* 104 */       if ((aRelatBeans == null) || (aRelatBeans.length == 0)) {
/* 105 */         int i = 1;
/*     */         return i;
/*     */       }
/*     */       int j;
/* 106 */       for (int j = 0; j < aRelatBeans.length; ++j) {
/* 107 */         aRelatBeans[j].delete();
/*     */       }
/* 109 */       BOVMObjectItemRelatEngine.saveBatch(aRelatBeans);
/*     */ 
/* 111 */       j = 1;
/*     */ 
/* 115 */       return j;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 113 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemKindElementValue[] queryObjectItemKindElement(String objectItemId, int startIndex, int endIndex)
/*     */     throws Exception
/*     */   {
/* 129 */     StringBuffer condition = new StringBuffer("1=1");
/* 130 */     HashMap parameter = new HashMap();
/* 131 */     if ((objectItemId != null) && (!objectItemId.equals(""))) {
/* 132 */       condition.append(" and OBJECT_ITEM_ID=:objectItemId");
/* 133 */       parameter.put("objectItemId", objectItemId);
/*     */     }
/* 135 */     return BOVMObjectItemKindElementEngine.getBeans(null, condition.toString(), parameter, startIndex, endIndex, false, null);
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItemKindElement(IBOVMObjectItemKindElementValue[] obj)
/*     */     throws Exception
/*     */   {
/* 147 */     if ((obj == null) || (obj.length == 0))
/* 148 */       return true;
/* 149 */     IBOVMObjectItemKindElementValue[] aobj = BOVMObjectItemKindElementEngine.transfer(obj);
/* 150 */     for (int i = 0; i < aobj.length; ++i) {
/* 151 */       aobj[i].delete();
/*     */     }
/* 153 */     BOVMObjectItemKindElementEngine.saveBatch(aobj);
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItemRelat(long aRelatId) throws Exception
/*     */   {
/* 159 */     BOVMObjectItemRelatBean aBean = BOVMObjectItemRelatEngine.getBean(aRelatId);
/* 160 */     aBean.delete();
/* 161 */     BOVMObjectItemRelatEngine.save(aBean);
/*     */ 
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue getObjectItemDetail(long aObjectItemId) throws Exception
/*     */   {
/* 168 */     return BOVMObjectItemEngine.getBean(aObjectItemId);
/*     */   }
/*     */ 
/*     */   public IQBOVMObjectItemRelatValue[] getObjectItemRelate(long aObjectItemId, String aRelaType)
/*     */     throws Exception
/*     */   {
/* 174 */     StringBuffer condition = new StringBuffer();
/* 175 */     HashMap parameter = new HashMap();
/*     */ 
/* 177 */     condition.append("OBJECT_ITEM_ID").append("=:").append("OBJECT_ITEM_ID");
/*     */ 
/* 179 */     parameter.put("OBJECT_ITEM_ID", new Long(aObjectItemId));
/*     */ 
/* 181 */     condition.append(" and ");
/*     */ 
/* 183 */     condition.append("RELAT_TYPE").append("=:").append("RELAT_TYPE");
/* 184 */     parameter.put("RELAT_TYPE", aRelaType);
/*     */ 
/* 186 */     return QBOVMObjectItemRelatEngine.getBeans(condition.toString(), parameter);
/*     */   }
/*     */ 
/*     */   public boolean addObjectItemRelat(long aObjectItemId, Long[] RelatObjectItemId, String aRelatType, String aAddType, long aRelatId, String aIsVisible, String aIsEditable)
/*     */     throws Exception
/*     */   {
/* 192 */     if (aAddType.equals("OBJECT_ITEM_RELAT"))
/*     */     {
/* 194 */       for (int i = 0; i < RelatObjectItemId.length; ++i)
/*     */       {
/* 196 */         BOVMObjectItemRelatBean aObjectItemRelat = new BOVMObjectItemRelatBean();
/*     */ 
/* 198 */         long aRelatNewId = BOVMObjectItemRelatEngine.getNewId().longValue();
/*     */ 
/* 200 */         aObjectItemRelat.setItemRelatId(aRelatNewId);
/*     */ 
/* 202 */         aObjectItemRelat.setObjectItemId(aObjectItemId);
/*     */ 
/* 204 */         aObjectItemRelat.setRelatObjectItemId(RelatObjectItemId[i].longValue());
/*     */ 
/* 206 */         aObjectItemRelat.setRelatType(aRelatType);
/*     */ 
/* 208 */         aObjectItemRelat.setState("U");
/*     */ 
/* 210 */         if (aIsVisible.trim().equals("Y"))
/* 211 */           aObjectItemRelat.setExtendAttrA("1");
/*     */         else {
/* 213 */           aObjectItemRelat.setExtendAttrA("0");
/*     */         }
/* 215 */         if (aIsEditable.trim().equals("Y"))
/* 216 */           aObjectItemRelat.setExtendAttrB("1");
/*     */         else {
/* 218 */           aObjectItemRelat.setExtendAttrB("0");
/*     */         }
/*     */ 
/* 221 */         BOVMObjectItemRelatEngine.save(aObjectItemRelat);
/*     */       }
/*     */     }
/*     */     else {
/* 225 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction_unSuppportRelate"));
/*     */     }
/* 227 */     return true;
/*     */   }
/*     */ 
/*     */   public String saveTaskUrl(String[] listIds, DataContainerInterface[] urls) throws Exception
/*     */   {
/* 232 */     String retValue = ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItemRelat_saveSuccess");
/*     */     try
/*     */     {
/* 235 */       BOVMObjectItemUrlBean urlBean = null;
/*     */ 
/* 237 */       for (int j = 0; j < listIds.length; ++j) {
/* 238 */         for (int i = 0; i < urls.length; ++i)
/*     */         {
/* 240 */           urlBean = BOVMObjectItemUrlEngine.getBean(Integer.parseInt(urls[i].getAsString("URL_BUSI_TYPE")), Long.parseLong(listIds[j]));
/*     */ 
/* 242 */           if (urlBean == null) {
/* 243 */             urlBean = new BOVMObjectItemUrlBean();
/* 244 */             urlBean.setObjectItemId(Long.parseLong(listIds[j]));
/* 245 */             urlBean.copy(urls[i]);
/*     */           } else {
/* 247 */             urlBean.setUrl(urls[i].getAsString("URL"));
/*     */           }
/* 249 */           BOVMObjectItemUrlEngine.save(urlBean);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 256 */       retValue = ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveJsRuleConfig_saveFailed");
/*     */ 
/* 258 */       throw ex;
/*     */     }
/* 260 */     return retValue;
/*     */   }
/*     */ 
/*     */   public String saveObjectItemKind(DataContainerInterface dc) throws Exception {
/*     */     try {
/* 265 */       String retValue = ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItemRelat_saveSuccess");
/*     */ 
/* 267 */       BOVMObjectItemKindBean aBean = new BOVMObjectItemKindBean();
/* 268 */       aBean.copy(dc);
/* 269 */       long aNewId = 0L;
/* 270 */       if (dc.isNew()) {
/* 271 */         aNewId = BOVMObjectItemKindEngine.getNewId().longValue();
/* 272 */         aBean.setKindId(aNewId);
/* 273 */         retValue = retValue + ComframeLocaleFactory.getResource("com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl.saveObjectItemKind_symKindCode") + aNewId + "。";
/*     */       }
/*     */ 
/* 278 */       BOVMObjectItemKindEngine.save(aBean);
/* 279 */       String str1 = retValue;
/*     */ 
/* 284 */       return str1;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 281 */       throw ex;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public String saveObjectItemWorkflow(String[] dcList, DataContainerInterface dc, long aObjectItemKindId, WorkflowTemplate template) throws Exception {
/* 289 */     return "";
/*     */   }
/*     */ 
/*     */   public void generateWorkflowChild(WorkflowTemplate template, long parentObjectItemID, long itemKindID)
/*     */     throws Exception
/*     */   {
/* 295 */     List tmpois = new ArrayList();
/* 296 */     List tmpoisr = new ArrayList();
/* 297 */     TaskTemplate[] tt = template.getTaskTemplates();
/* 298 */     for (int i = 0; i < tt.length; ++i) {
/* 299 */       if ("user".equals(tt[i].getTaskType())) {
/* 300 */         BOVMObjectItemBean oi = new BOVMObjectItemBean();
/* 301 */         oi.setObjectItemId(BOVMObjectItemEngine.getNewId().longValue());
/* 302 */         oi.setCode(tt[i].getTaskTag());
/* 303 */         oi.setName(tt[i].getTaskTag());
/* 304 */         oi.setDescription(tt[i].getTaskTag());
/* 305 */         oi.setItemType("WORKFLOW_NODE");
/* 306 */         oi.setState("U");
/* 307 */         oi.setRemarks(tt[i].getTaskTag());
/* 308 */         tmpois.add(oi);
/*     */ 
/* 310 */         BOVMObjectItemRelatBean oir = new BOVMObjectItemRelatBean();
/* 311 */         oir.setItemRelatId(BOVMObjectItemRelatEngine.getNewId().longValue());
/* 312 */         oir.setObjectItemId(parentObjectItemID);
/* 313 */         oir.setRelatObjectItemId(oi.getObjectItemId());
/* 314 */         oir.setState("U");
/* 315 */         oir.setRelatType("WORKFLOW.WORKFLOW_NODE");
/* 316 */         tmpoisr.add(oir);
/*     */       }
/*     */     }
/*     */ 
/* 320 */     BOVMObjectItemEngine.saveBatch((BOVMObjectItemBean[])(BOVMObjectItemBean[])tmpois.toArray(new BOVMObjectItemBean[0]));
/* 321 */     BOVMObjectItemRelatEngine.saveBatch((BOVMObjectItemRelatBean[])(BOVMObjectItemRelatBean[])tmpoisr.toArray(new BOVMObjectItemRelatBean[0]));
/*     */   }
/*     */ 
/*     */   public long saveObjectItemWorkflow(String dcType, DataContainerInterface dc, long aObjectItemKindId, WorkflowTemplate template) throws Exception
/*     */   {
/* 326 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try
/*     */     {
/* 329 */       long aObjectItemId = 0L;
/* 330 */       if (StringUtils.isEmptyString(dcType)) {
/* 331 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl_dataTypeNotEmpty"));
/*     */       }
/* 333 */       if (dcType.equalsIgnoreCase("ObjectItemDc")) {
/* 334 */         aBean = new BOVMObjectItemBean();
/* 335 */         aBean.copy(dc);
/* 336 */         boolean isNewItem = false;
/* 337 */         long aNewId = 0L;
/* 338 */         if (dc.isNew()) {
/* 339 */           aNewId = BOVMObjectItemEngine.getNewId().longValue();
/* 340 */           aObjectItemId = aNewId;
/* 341 */           aBean.setObjectItemId(aNewId);
/* 342 */           aBean.setState("U");
/*     */ 
/* 344 */           if (template != null) {
/* 345 */             generateWorkflowChild(template, aBean.getObjectItemId(), aObjectItemKindId);
/*     */           }
/* 347 */           isNewItem = true;
/*     */         } else {
/* 349 */           aObjectItemId = aBean.getObjectItemId();
/*     */         }
/* 351 */         BOVMObjectItemEngine.save(aBean);
/* 352 */         if (isNewItem == true)
/*     */         {
/* 354 */           BOVMObjectItemKindElementBean aElement = new BOVMObjectItemKindElementBean();
/* 355 */           long aElementId = BOVMObjectItemKindElementEngine.getNewId().longValue();
/* 356 */           aElement.setObjectItemId(aObjectItemId);
/* 357 */           aElement.setItemKindRelatId(aElementId);
/* 358 */           aElement.setItemKindId(aObjectItemKindId);
/* 359 */           BOVMObjectItemKindElementEngine.save(aElement);
/*     */         }
/*     */       }
/*     */       else {
/* 363 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl_unSupportOpType"));
/*     */       }
/* 365 */       BOVMObjectItemBean aBean = aObjectItemId;
/*     */ 
/* 375 */       return aBean;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 371 */       if (conn != null) {
/* 372 */         conn.close();
/* 373 */         conn = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveObjectItemUrl(long objectItemId, DataContainerInterface[] urlDcs) throws Exception
/*     */   {
/* 380 */     for (int j = 0; j < urlDcs.length; ++j) {
/* 381 */       BOVMObjectItemUrlBean urlBean = new BOVMObjectItemUrlBean();
/* 382 */       urlBean.copy(urlDcs[j]);
/* 383 */       if (objectItemId > 0L)
/* 384 */         urlBean.setObjectItemId(objectItemId);
/* 385 */       BOVMObjectItemUrlEngine.save(urlBean);
/*     */     }
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemUrlValue[] getObjectItemUrl(String objectItemId, int $STARTROWINDEX, int $ENDROWINDEX)
/*     */     throws Exception
/*     */   {
/* 392 */     HashMap map = new HashMap();
/* 393 */     IBOVMObjectItemUrlValue[] relust = null;
/* 394 */     StringBuffer condition = new StringBuffer();
/*     */ 
/* 396 */     if (!StringUtils.isEmptyString(objectItemId)) {
/* 397 */       condition.append("OBJECT_ITEM_ID").append(" = ").append(objectItemId);
/* 398 */       relust = BOVMObjectItemUrlEngine.getBeans(condition.toString(), map);
/*     */     }
/* 400 */     return relust;
/*     */   }
/*     */ 
/*     */   public int getObjectItemDetailCountByCode(String aObjectItemCode) throws Exception
/*     */   {
/* 405 */     StringBuffer condition = new StringBuffer();
/* 406 */     HashMap parameter = new HashMap();
/*     */ 
/* 408 */     condition.append("ITEM_TYPE = :WORKFLOW_NODE ");
/* 409 */     parameter.put("WORKFLOW_NODE", "WORKFLOW_NODE");
/*     */ 
/* 411 */     if ((aObjectItemCode != null) && (!aObjectItemCode.equals(""))) {
/* 412 */       condition.append(" and CODE  like :aObjectItemCode ");
/* 413 */       parameter.put("aObjectItemCode", "%" + aObjectItemCode + "%");
/*     */     }
/* 415 */     return BOVMObjectItemEngine.getBeansCount(condition.toString(), parameter);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue[] getObjectItemDetailByCode(String aObjectItemCode, int start, int end) throws Exception
/*     */   {
/* 420 */     StringBuilder condition = new StringBuilder();
/* 421 */     HashMap paraMap = new HashMap();
/*     */ 
/* 423 */     condition.append("ITEM_TYPE = :WORKFLOW_NODE ");
/* 424 */     paraMap.put("WORKFLOW_NODE", "WORKFLOW_NODE");
/*     */ 
/* 426 */     if ((aObjectItemCode != null) && (aObjectItemCode.length() > 0)) {
/* 427 */       condition.append(" and CODE  like :aObjectItemCode ");
/* 428 */       paraMap.put("aObjectItemCode", "%" + aObjectItemCode + "%");
/*     */     }
/*     */ 
/* 431 */     System.out.println(condition.toString());
/* 432 */     return BOVMObjectItemEngine.getBeans(null, condition.toString(), paraMap, start, end, false);
/*     */   }
/*     */ 
/*     */   public String getObjectItemUrlForTask(String aWorkFlowCode, String aWorkFlowNodeCode, int urlBusiType) throws Exception {
/* 436 */     StringBuffer cond = new StringBuffer(" 1=1 ");
/* 437 */     HashMap param = new HashMap();
/* 438 */     boolean ifNode = true;
/*     */ 
/* 440 */     if (!StringUtils.isEmptyString(aWorkFlowNodeCode)) {
/* 441 */       cond.append(" and ").append("TASK_CODE").append("=:").append("TASK_CODE");
/* 442 */       param.put("TASK_CODE", aWorkFlowNodeCode);
/*     */     }
/*     */ 
/* 445 */     QBOVMObjectItemRelatBean[] qVmObjectItem = getIQBOVMObjectItemRelatValue(cond.toString(), param);
/* 446 */     if ((qVmObjectItem == null) || (qVmObjectItem.length == 0)) {
/* 447 */       ifNode = false;
/* 448 */       if (!StringUtils.isEmptyString(aWorkFlowCode)) {
/* 449 */         cond = new StringBuffer(" 1=1 ");
/* 450 */         cond.append(" and ").append("TEMPLATE_TAG").append("=:").append("TEMPLATE_TAG");
/* 451 */         param.put("TEMPLATE_TAG", aWorkFlowCode);
/*     */       }
/* 453 */       qVmObjectItem = getIQBOVMObjectItemRelatValue(cond.toString(), param);
/* 454 */       if ((qVmObjectItem == null) || (qVmObjectItem.length == 0)) {
/* 455 */         return null;
/*     */       }
/*     */     }
/* 458 */     if (qVmObjectItem.length > 1)
/*     */     {
/* 460 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl_queryMore"));
/*     */     }
/*     */ 
/* 463 */     if (qVmObjectItem.length == 1) {
/* 464 */       StringBuffer urlCond = new StringBuffer(" 1=1 ");
/* 465 */       HashMap pParam = new HashMap();
/* 466 */       String objectItemID = null;
/* 467 */       if (ifNode)
/* 468 */         objectItemID = String.valueOf(qVmObjectItem[0].getRelatObjectItemId());
/*     */       else {
/* 470 */         objectItemID = String.valueOf(qVmObjectItem[0].getObjectItemId());
/*     */       }
/*     */ 
/* 474 */       urlCond.append(" and ").append("OBJECT_ITEM_ID").append("=:").append("OBJECT_ITEM_ID");
/* 475 */       pParam.put("OBJECT_ITEM_ID", objectItemID);
/*     */ 
/* 477 */       urlCond.append(" and ").append("URL_BUSI_TYPE").append("=:").append("URL_BUSI_TYPE");
/* 478 */       pParam.put("URL_BUSI_TYPE", String.valueOf(urlBusiType));
/* 479 */       BOVMObjectItemUrlBean[] objItemUrl = BOVMObjectItemUrlEngine.getBeans(urlCond.toString(), pParam);
/* 480 */       if ((objItemUrl == null) || (objItemUrl.length == 0)) {
/* 481 */         ifNode = false;
/* 482 */         if (!StringUtils.isEmptyString(aWorkFlowCode)) {
/* 483 */           cond = new StringBuffer(" 1=1 ");
/* 484 */           cond.append(" and ").append("TEMPLATE_TAG").append("=:").append("TEMPLATE_TAG");
/* 485 */           param.put("TEMPLATE_TAG", aWorkFlowCode);
/*     */         }
/* 487 */         qVmObjectItem = getIQBOVMObjectItemRelatValue(cond.toString(), param);
/* 488 */         urlCond = new StringBuffer(" 1=1 ");
/* 489 */         pParam = new HashMap();
/* 490 */         if (ifNode)
/* 491 */           objectItemID = String.valueOf(qVmObjectItem[0].getRelatObjectItemId());
/*     */         else {
/* 493 */           objectItemID = String.valueOf(qVmObjectItem[0].getObjectItemId());
/*     */         }
/*     */ 
/* 497 */         urlCond.append(" and ").append("OBJECT_ITEM_ID").append("=:").append("OBJECT_ITEM_ID");
/* 498 */         pParam.put("OBJECT_ITEM_ID", objectItemID);
/*     */ 
/* 500 */         urlCond.append(" and ").append("URL_BUSI_TYPE").append("=:").append("URL_BUSI_TYPE");
/* 501 */         pParam.put("URL_BUSI_TYPE", String.valueOf(urlBusiType));
/* 502 */         objItemUrl = BOVMObjectItemUrlEngine.getBeans(urlCond.toString(), pParam);
/* 503 */         if ((objItemUrl == null) || (objItemUrl.length == 0)) {
/* 504 */           return null;
/*     */         }
/*     */       }
/* 507 */       if (objItemUrl.length > 1)
/*     */       {
/* 509 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl_queryMore"));
/*     */       }
/* 511 */       if (objItemUrl.length == 1) {
/* 512 */         return BOVMObjectItemUrlEngine.getBeans(urlCond.toString(), pParam)[0].getUrl();
/*     */       }
/*     */     }
/* 515 */     return null;
/*     */   }
/*     */ 
/*     */   private QBOVMObjectItemRelatBean[] getIQBOVMObjectItemRelatValue(String cond, HashMap param) throws Exception {
/* 519 */     return QBOVMObjectItemRelatEngine.getBeans(cond, param);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.dao.impl.AutoFormDAOImpl
 * JD-Core Version:    0.5.4
 */