package com.ai.comframe.autoform.dao.interfaces;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
import com.ai.comframe.vm.template.WorkflowTemplate;

public abstract interface IAutoFormDAO
{
  public abstract IBOVMObjectItemKindValue[] getObjectItemKinds(String paramString, long paramLong)
    throws Exception;

  public abstract IBOVMObjectItemValue[] getObjectItemByItemKindId(String paramString, long paramLong)
    throws Exception;

  public abstract IQBOVMObjectItemRelatValue[] getRelatObjectItemByObjItemId(long paramLong)
    throws Exception;

  public abstract IBOVMObjectItemKindValue getObjectItemKindDetail(long paramLong)
    throws Exception;

  public abstract boolean deleteObjectItemKind(long paramLong)
    throws Exception;

  public abstract boolean deleteObjectItem(long paramLong)
    throws Exception;

  public abstract boolean deleteObjectItemRelat(long paramLong)
    throws Exception;

  public abstract IBOVMObjectItemValue getObjectItemDetail(long paramLong)
    throws Exception;

  public abstract IQBOVMObjectItemRelatValue[] getObjectItemRelate(long paramLong, String paramString)
    throws Exception;

  public abstract boolean addObjectItemRelat(long paramLong1, Long[] paramArrayOfLong, String paramString1, String paramString2, long paramLong2, String paramString3, String paramString4)
    throws Exception;

  public abstract String saveTaskUrl(String[] paramArrayOfString, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception;

  public abstract String saveObjectItemKind(DataContainerInterface paramDataContainerInterface)
    throws Exception;

  public abstract long saveObjectItemWorkflow(String paramString, DataContainerInterface paramDataContainerInterface, long paramLong, WorkflowTemplate paramWorkflowTemplate)
    throws Exception;

  public abstract void saveObjectItemUrl(long paramLong, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception;

  public abstract IBOVMObjectItemUrlValue[] getObjectItemUrl(String paramString, int paramInt1, int paramInt2)
    throws Exception;

  public abstract int getObjectItemDetailCountByCode(String paramString)
    throws Exception;

  public abstract IBOVMObjectItemValue[] getObjectItemDetailByCode(String paramString, int paramInt1, int paramInt2)
    throws Exception;

  public abstract String getObjectItemUrlForTask(String paramString1, String paramString2, int paramInt)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.dao.interfaces.IAutoFormDAO
 * JD-Core Version:    0.5.4
 */