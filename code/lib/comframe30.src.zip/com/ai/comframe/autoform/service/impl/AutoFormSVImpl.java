/*     */ package com.ai.comframe.autoform.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.web.DataContainerList;
/*     */ import com.ai.comframe.autoform.dao.interfaces.IAutoFormDAO;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue;
/*     */ import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
/*     */ import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
/*     */ import com.ai.comframe.autoform.service.interfaces.IAutoFormSV;
/*     */ import com.ai.comframe.client.ComframeClient;
/*     */ import com.ai.comframe.config.ivalues.IBOVmTemplateValue;
/*     */ import com.ai.comframe.config.service.interfaces.ITemplateSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import com.ai.comframe.vm.template.WorkflowTemplate;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class AutoFormSVImpl
/*     */   implements IAutoFormSV
/*     */ {
/*     */   public IBOVMObjectItemKindValue[] getObjectItemKinds(String aObjectItemTypeCode, long aParentKindId)
/*     */     throws Exception, RemoteException
/*     */   {
/*  27 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  28 */     return autoFormDao.getObjectItemKinds(aObjectItemTypeCode, aParentKindId);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue[] getObjectItemByItemKindId(String aParentItemTypeCode, long aParentItemKindId) throws Exception, RemoteException
/*     */   {
/*  33 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  34 */     return autoFormDao.getObjectItemByItemKindId(aParentItemTypeCode, aParentItemKindId);
/*     */   }
/*     */ 
/*     */   public IQBOVMObjectItemRelatValue[] getRelatObjectItemByObjItemId(long objItemID) throws Exception, RemoteException {
/*  38 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  39 */     return autoFormDao.getRelatObjectItemByObjItemId(objItemID);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemKindValue getObjectItemKindDetail(String aObjectItemKindId) throws Exception, RemoteException {
/*  43 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  44 */     return autoFormDao.getObjectItemKindDetail(Long.parseLong(aObjectItemKindId));
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItemKind(long aKindId) throws Exception, RemoteException {
/*  48 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  49 */     return autoFormDao.deleteObjectItemKind(aKindId);
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItem(long aObjectItemId) throws Exception, RemoteException {
/*  53 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  54 */     return autoFormDao.deleteObjectItem(aObjectItemId);
/*     */   }
/*     */ 
/*     */   public boolean deleteObjectItemRelat(long aRelatId) throws Exception, RemoteException {
/*  58 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  59 */     return autoFormDao.deleteObjectItemRelat(aRelatId);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue getObjectItemDetail(long aObjectItemId) throws Exception, RemoteException {
/*  63 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  64 */     return autoFormDao.getObjectItemDetail(aObjectItemId);
/*     */   }
/*     */ 
/*     */   public IQBOVMObjectItemRelatValue[] getObjectItemRelate(long aObjectItemId, String aRelaType) throws Exception, RemoteException
/*     */   {
/*  69 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  70 */     return autoFormDao.getObjectItemRelate(aObjectItemId, aRelaType);
/*     */   }
/*     */ 
/*     */   public boolean addObjectItemRelat(long aObjectItemId, Long[] RelatObjectItemId, String aRelatType, String aAddType, long aRelatId, String aIsVisible, String aIsEditable)
/*     */     throws Exception, RemoteException
/*     */   {
/*  76 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  77 */     return autoFormDao.addObjectItemRelat(aObjectItemId, RelatObjectItemId, aRelatType, aAddType, aRelatId, aIsVisible, aIsEditable);
/*     */   }
/*     */ 
/*     */   public String saveTaskUrl(String[] list, DataContainerInterface[] urls)
/*     */     throws Exception, RemoteException
/*     */   {
/*  83 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  84 */     return autoFormDao.saveTaskUrl(list, urls);
/*     */   }
/*     */ 
/*     */   public String saveObjectItemKind(DataContainerInterface dc) throws Exception, RemoteException {
/*  88 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/*  89 */     return autoFormDao.saveObjectItemKind(dc);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] searchTemplate(String templateTag) throws Exception, RemoteException
/*     */   {
/*  94 */     ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/*  95 */     IBOVmTemplateValue[] templates = templateSV.getAllVmTemplateFromCache();
/*  96 */     if (templateTag == null)
/*  97 */       return (DataContainerInterface[])(DataContainerInterface[])templates;
/*  98 */     List list = new ArrayList();
/*  99 */     for (int i = 0; i < templates.length; ++i) {
/* 100 */       if (templates[i].getTemplateTag().indexOf(templateTag) > -1) {
/* 101 */         list.add(templates[i]);
/*     */       }
/*     */     }
/* 104 */     return (DataContainerInterface[])(DataContainerInterface[])list.toArray(new DataContainerInterface[0]);
/*     */   }
/*     */ 
/*     */   public String saveObjectItem(String[] dcList, DataContainerList[] dcLists, long aObjectItemKindId, String selectTemplateCheck)
/*     */     throws Exception, RemoteException
/*     */   {
/* 110 */     if ((dcList == null) || (dcList.length > 2))
/*     */     {
/* 112 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.service.impl.AutoFormSVImpl_unSupportUnitOp"));
/* 113 */     }String retValue = ComframeLocaleFactory.getResource("com.ai.comframe.autoform.web.AutoFormAction.saveObjectItemRelat_saveSuccess");
/*     */ 
/* 115 */     long objectItemId = -1L;
/* 116 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/* 117 */     for (int i = 0; i < dcList.length; ++i)
/* 118 */       if (dcList[i].equals("ObjectItemDc")) {
/* 119 */         DataContainerInterface dc = dcLists[i].getColDataContainerInterface(0)[0];
/* 120 */         if (dc == null)
/*     */         {
/* 122 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.service.impl.AutoFormSVImpl_datasetEmpty"));
/*     */         }
/* 124 */         String templateTag = dc.getAsString("CODE");
/* 125 */         WorkflowTemplate template = null;
/* 126 */         if ("Y".equals(selectTemplateCheck)) {
/* 127 */           ITemplateSV templateSV = (ITemplateSV)ServiceFactory.getService(ITemplateSV.class);
/* 128 */           template = templateSV.getWorkflowTemplateByTag(templateTag);
/* 129 */           if (template == null)
/*     */           {
/* 131 */             throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.service.impl.AutoFormSVImpl_notFindTemplate"));
/*     */           }
/*     */         }
/* 134 */         objectItemId = autoFormDao.saveObjectItemWorkflow(dcList[i], dc, aObjectItemKindId, template);
/* 135 */       } else if (dcList[i].equals("ObjectItemUrlSetDc"))
/*     */       {
/* 137 */         DataContainerInterface[] urlDcs = dcLists[i].getColDataContainerInterface(0);
/* 138 */         if ((urlDcs != null) && (urlDcs.length > 0))
/* 139 */           autoFormDao.saveObjectItemUrl(objectItemId, urlDcs);
/*     */       }
/*     */       else
/*     */       {
/* 143 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.autoform.service.impl.AutoFormSVImpl_unSupportUnitOp") + dcList[i]);
/*     */       }
/* 145 */     return retValue;
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemUrlValue[] getObjectItemUrl(String aObjectItemId, int $STARTROWINDEX, int $ENDROWINDEX)
/*     */     throws Exception, RemoteException
/*     */   {
/* 151 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/* 152 */     return autoFormDao.getObjectItemUrl(aObjectItemId, $STARTROWINDEX, $ENDROWINDEX);
/*     */   }
/*     */ 
/*     */   public String getObjectItemUrlForTask(String aWorkFlowCode, String aWorkFlowNodeCode, int urlBusiType) throws Exception, RemoteException {
/* 156 */     IAutoFormDAO dao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/* 157 */     return dao.getObjectItemUrlForTask(aWorkFlowCode, aWorkFlowNodeCode, urlBusiType);
/*     */   }
/*     */ 
/*     */   public int getObjectItemDetailCountByCode(String aObjectItemCode) throws Exception, RemoteException
/*     */   {
/* 162 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/* 163 */     return autoFormDao.getObjectItemDetailCountByCode(aObjectItemCode);
/*     */   }
/*     */ 
/*     */   public IBOVMObjectItemValue[] getObjectItemDetailByCode(String aObjectItemCode, int start, int end)
/*     */     throws Exception, RemoteException
/*     */   {
/* 169 */     IAutoFormDAO autoFormDao = (IAutoFormDAO)ServiceFactory.getService(IAutoFormDAO.class);
/* 170 */     return autoFormDao.getObjectItemDetailByCode(aObjectItemCode, start, end);
/*     */   }
/*     */   public Map getWorkFlowVars(String workflowId) throws Exception, RemoteException {
/* 173 */     return ComframeClient.getWorkflowVars(workflowId);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.service.impl.AutoFormSVImpl
 * JD-Core Version:    0.5.4
 */