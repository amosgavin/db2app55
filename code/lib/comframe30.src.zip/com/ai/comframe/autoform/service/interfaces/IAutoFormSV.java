package com.ai.comframe.autoform.service.interfaces;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.appframe2.web.DataContainerList;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemKindValue;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemUrlValue;
import com.ai.comframe.autoform.ivalues.IBOVMObjectItemValue;
import com.ai.comframe.autoform.ivalues.IQBOVMObjectItemRelatValue;
import java.rmi.RemoteException;
import java.util.Map;

public abstract interface IAutoFormSV
{
  public abstract IBOVMObjectItemKindValue[] getObjectItemKinds(String paramString, long paramLong)
    throws Exception, RemoteException;

  public abstract IBOVMObjectItemValue[] getObjectItemByItemKindId(String paramString, long paramLong)
    throws Exception, RemoteException;

  public abstract IQBOVMObjectItemRelatValue[] getRelatObjectItemByObjItemId(long paramLong)
    throws Exception, RemoteException;

  public abstract IBOVMObjectItemKindValue getObjectItemKindDetail(String paramString)
    throws Exception, RemoteException;

  public abstract boolean deleteObjectItemKind(long paramLong)
    throws Exception, RemoteException;

  public abstract boolean deleteObjectItem(long paramLong)
    throws Exception, RemoteException;

  public abstract boolean deleteObjectItemRelat(long paramLong)
    throws Exception, RemoteException;

  public abstract IBOVMObjectItemValue getObjectItemDetail(long paramLong)
    throws Exception, RemoteException;

  public abstract IQBOVMObjectItemRelatValue[] getObjectItemRelate(long paramLong, String paramString)
    throws Exception, RemoteException;

  public abstract boolean addObjectItemRelat(long paramLong1, Long[] paramArrayOfLong, String paramString1, String paramString2, long paramLong2, String paramString3, String paramString4)
    throws Exception, RemoteException;

  public abstract String saveTaskUrl(String[] paramArrayOfString, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception, RemoteException;

  public abstract String saveObjectItemKind(DataContainerInterface paramDataContainerInterface)
    throws Exception, RemoteException;

  public abstract DataContainerInterface[] searchTemplate(String paramString)
    throws Exception, RemoteException;

  public abstract String saveObjectItem(String[] paramArrayOfString, DataContainerList[] paramArrayOfDataContainerList, long paramLong, String paramString)
    throws Exception, RemoteException;

  public abstract IBOVMObjectItemUrlValue[] getObjectItemUrl(String paramString, int paramInt1, int paramInt2)
    throws Exception, RemoteException;

  public abstract String getObjectItemUrlForTask(String paramString1, String paramString2, int paramInt)
    throws Exception, RemoteException;

  public abstract int getObjectItemDetailCountByCode(String paramString)
    throws Exception, RemoteException;

  public abstract IBOVMObjectItemValue[] getObjectItemDetailByCode(String paramString, int paramInt1, int paramInt2)
    throws Exception, RemoteException;

  public abstract Map getWorkFlowVars(String paramString)
    throws Exception, RemoteException;
}

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.autoform.service.interfaces.IAutoFormSV
 * JD-Core Version:    0.5.4
 */