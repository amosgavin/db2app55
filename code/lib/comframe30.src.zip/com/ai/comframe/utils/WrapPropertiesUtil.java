/*    */ package com.ai.comframe.utils;
/*    */ 
/*    */ import java.io.BufferedInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class WrapPropertiesUtil
/*    */ {
/* 13 */   private static transient Log logger = LogFactory.getLog(WrapPropertiesUtil.class);
/*    */   private static PropertiesParser parser;
/* 15 */   private static String WRAP_FILE_NAME = "comframe.ini";
/*    */   private static final String COMFRAME_WRAP_FILE_NAME = "comframe.wrap.filename";
/*    */   private static final String WRAP_CORE_QUEUE_PROCESSOR = "wrap.core.queue.processor";
/*    */   private static final String WRAP_CORE_ENGINE_TYPE = "wrap.core.engine.type";
/*    */ 
/*    */   public static String getWrapQueueProcessor(String queueType)
/*    */   {
/* 57 */     return getStringProperties("wrap.core.queue.processor." + queueType);
/*    */   }
/*    */ 
/*    */   public static String getWrapEngineType() {
/* 61 */     return getStringProperties("wrap.core.engine.type").toUpperCase();
/*    */   }
/*    */ 
/*    */   public static String getStringProperties(String name) {
/* 65 */     return parser.getStringProperty(name);
/*    */   }
/*    */ 
/*    */   public static boolean getBooleanProperty(String name) {
/* 69 */     return parser.getBooleanProperty(name);
/*    */   }
/*    */ 
/*    */   public static int getIntProperty(String name) {
/* 73 */     return parser.getIntProperty(name);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 22 */     if (!StringUtils.isBlank(System.getProperty("comframe.wrap.filename"))) {
/* 23 */       WRAP_FILE_NAME = System.getProperty("comframe.wrap.filename").trim();
/* 24 */       if (logger.isInfoEnabled()) {
/* 25 */         logger.info("Use wrap config file name:" + WRAP_FILE_NAME);
/*    */       }
/*    */     }
/* 28 */     InputStream in = null;
/* 29 */     Properties props = new Properties();
/*    */     try
/*    */     {
/* 32 */       in = Thread.currentThread().getContextClassLoader().getResourceAsStream(WRAP_FILE_NAME);
/*    */ 
/* 34 */       if (in == null)
/*    */       {
/* 36 */         throw new Exception("无法找到商用工作流引擎的配置文件！");
/*    */       }
/* 38 */       in = new BufferedInputStream(in);
/*    */ 
/* 40 */       props.load(in);
/* 41 */       parser = new PropertiesParser(props);
/*    */     }
/*    */     catch (Throwable ex) {
/*    */     }
/*    */     finally {
/* 46 */       if (in != null)
/*    */         try {
/* 48 */           in.close();
/*    */         }
/*    */         catch (IOException ignore)
/*    */         {
/*    */         }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.WrapPropertiesUtil
 * JD-Core Version:    0.5.4
 */