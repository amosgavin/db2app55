/*    */ package com.ai.comframe.utils;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class PropertiesParser
/*    */ {
/*  7 */   Properties props = null;
/*    */ 
/*    */   public PropertiesParser(Properties props) {
/* 10 */     this.props = props;
/*    */   }
/*    */ 
/*    */   public Properties getProperties() {
/* 14 */     return this.props;
/*    */   }
/*    */ 
/*    */   public String getStringProperty(String name) {
/* 18 */     return getStringProperty(name, null);
/*    */   }
/*    */ 
/*    */   public String getStringProperty(String name, String def) {
/* 22 */     String val = this.props.getProperty(name, def);
/* 23 */     if (val == null) {
/* 24 */       return def;
/*    */     }
/*    */ 
/* 27 */     val = val.trim();
/*    */ 
/* 29 */     return (val.length() == 0) ? def : val;
/*    */   }
/*    */ 
/*    */   public boolean getBooleanProperty(String name) {
/* 33 */     return getBooleanProperty(name, false);
/*    */   }
/*    */ 
/*    */   public boolean getBooleanProperty(String name, boolean def) {
/* 37 */     String val = getStringProperty(name);
/*    */ 
/* 39 */     return (val == null) ? def : Boolean.valueOf(val).booleanValue();
/*    */   }
/*    */ 
/*    */   public int getIntProperty(String name) throws NumberFormatException {
/* 43 */     String val = getStringProperty(name);
/* 44 */     if (val == null) {
/* 45 */       throw new NumberFormatException(" null string");
/*    */     }
/*    */     try
/*    */     {
/* 49 */       return Integer.parseInt(val);
/*    */     } catch (NumberFormatException nfe) {
/* 51 */       throw new NumberFormatException(" '" + val + "'");
/*    */     }
/*    */   }
/*    */ 
/*    */   public int getIntProperty(String name, int def) throws NumberFormatException {
/* 56 */     String val = getStringProperty(name);
/* 57 */     if (val == null) {
/* 58 */       return def;
/*    */     }
/*    */     try
/*    */     {
/* 62 */       return Integer.parseInt(val);
/*    */     } catch (NumberFormatException nfe) {
/* 64 */       throw new NumberFormatException(" '" + val + "'");
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object getClassProperty(String name) throws ClassNotFoundException, InstantiationException, IllegalAccessException
/*    */   {
/* 70 */     String val = getStringProperty(name);
/* 71 */     if (val == null) {
/* 72 */       return null;
/*    */     }
/*    */     try
/*    */     {
/* 76 */       return Class.forName(val).newInstance();
/*    */     } catch (ClassNotFoundException nfe) {
/* 78 */       throw new ClassNotFoundException(" '" + val + "'");
/*    */     } catch (IllegalAccessException iae) {
/* 80 */       throw new IllegalAccessException(" '" + val + "'");
/*    */     } catch (InstantiationException ine) {
/* 82 */       throw new InstantiationException(" '" + val + "'");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.PropertiesParser
 * JD-Core Version:    0.5.4
 */