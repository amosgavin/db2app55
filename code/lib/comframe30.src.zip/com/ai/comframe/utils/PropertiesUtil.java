/*     */ package com.ai.comframe.utils;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.interfaces.ICenter;
/*     */ import com.ai.comframe.client.Config;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class PropertiesUtil
/*     */ {
/*  20 */   private static transient Log log = LogFactory.getLog(PropertiesUtil.class);
/*     */   private static PropertiesParser parser;
/*     */   private static final String PROP_WORKFLOW_STAFF_ID = "workflow.staff.id";
/*     */   private static final String PROP_WORKFLOW_STAFF_ORG = "workflow.staff.org";
/*     */   private static final String PROP_WORKFLOW_STAFF_DOMAIN = "workflow.staff.domain";
/*     */   private static final String PROP_WORKFLOW_ATTR_RECORD = "workflow.attr.record";
/*     */   private static final String PROP_WORKFLOW_RETRY_COUNT = "workflow.retry.count";
/*     */   private static final String PROP_QUEUE_CENTER_CLASS = "queue.center.class";
/*     */   private static final String PROP_QUEUE_DEFAULT_THREAD_NUM = "queue.default.thread.num";
/*     */   private static final String PROP_CONSOLE_LOGIN_ID = "console.login.id";
/*     */   private static final String PROP_CONSOLE_LOGIN_CODE = "console.login.code";
/*     */   private static final String PROP_CONSOLE_LOGIN_PASSWORD = "console.login.password";
/*     */   private static final String PROP_CONSOLE_LOGIN_ORG_ID = "console.login.org.id";
/*     */   private static final String PROP_CONSOLE_LOGIN_ORG_NAME = "console.login.org.name";
/*     */   private static final String PROP_CONSOLE_LOGIN_REGION_ID = "console.login.region.id";
/*     */   private static final String PROP_IS_DEV = "dev";
/*     */   private static final String PROP_IS_HIS_SPLIT = "his.split";
/*     */   private static final String PROP_QUERY_HIS = "query.his";
/*     */   private static final String PROP_QUERY_HIS_MONTH_COUNT = "query.his.month.count";
/*     */   private static String DEV_ID;
/*     */ 
/*     */   public static boolean isAttrRecord()
/*     */   {
/*  59 */     return parser.getBooleanProperty("workflow.attr.record", false);
/*     */   }
/*     */ 
/*     */   public static ICenter getCenterImpl()
/*     */     throws Exception
/*     */   {
/*  69 */     Object centerObj = parser.getClassProperty("queue.center.class");
/*  70 */     if (centerObj == null)
/*  71 */       return null;
/*  72 */     if (!centerObj instanceof ICenter) {
/*  73 */       String[] param = new String[1];
/*  74 */       param[0] = centerObj.getClass().getName();
/*  75 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.PropertiesUtil_notRealizeICenter", param));
/*     */     }
/*  77 */     return (ICenter)parser.getClassProperty("queue.center.class");
/*     */   }
/*     */ 
/*     */   public static int getDefaultThreadNum()
/*     */   {
/*  88 */     return parser.getIntProperty("queue.default.thread.num", 5);
/*     */   }
/*     */ 
/*     */   public static boolean isDev()
/*     */   {
/*  97 */     return parser.getBooleanProperty("dev", true);
/*     */   }
/*     */ 
/*     */   public static String getDevId()
/*     */   {
/* 106 */     return DEV_ID;
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginId()
/*     */   {
/* 115 */     return parser.getStringProperty("console.login.id");
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginCode()
/*     */   {
/* 124 */     return parser.getStringProperty("console.login.code");
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginPassword()
/*     */   {
/* 133 */     return parser.getStringProperty("console.login.password");
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginOrgId()
/*     */   {
/* 142 */     return parser.getStringProperty("console.login.org.id");
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginOrgName()
/*     */   {
/* 151 */     return parser.getStringProperty("console.login.org.name");
/*     */   }
/*     */ 
/*     */   public static String getConsoleLoginRegionId()
/*     */   {
/* 160 */     return parser.getStringProperty("console.login.region.id");
/*     */   }
/*     */ 
/*     */   public static int getRetryCount()
/*     */   {
/* 169 */     return parser.getIntProperty("workflow.retry.count", 0);
/*     */   }
/*     */ 
/*     */   public static boolean isQueryHis()
/*     */   {
/* 179 */     return parser.getBooleanProperty("query.his", false);
/*     */   }
/*     */ 
/*     */   public static int getQueryHisMonthCount()
/*     */   {
/* 188 */     return parser.getIntProperty("query.his.month.count", 3);
/*     */   }
/*     */ 
/*     */   public static boolean isHisSplit() {
/* 192 */     return parser.getBooleanProperty("his.split", true);
/*     */   }
/*     */ 
/*     */   public static String getSystemUserId() {
/* 196 */     return parser.getStringProperty("workflow.staff.id", "Administrator");
/*     */   }
/*     */ 
/*     */   public static String getWorkflowStaffOrg() {
/* 200 */     return parser.getStringProperty("workflow.staff.org");
/*     */   }
/*     */ 
/*     */   public static String getWorkflowStaffDomain() {
/* 204 */     return parser.getStringProperty("workflow.staff.domain");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  44 */       Properties props = Config.getConfigInfo();
/*  45 */       parser = new PropertiesParser(props);
/*     */ 
/*  47 */       DEV_ID = System.getProperty("comframe.dev.name", "");
/*     */     } catch (Throwable ex) {
/*  49 */       log.error("For process configuration information fails", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.PropertiesUtil
 * JD-Core Version:    0.5.4
 */