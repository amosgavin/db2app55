/*    */ package com.ai.comframe.utils;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.dao.interfaces.ITimeDAO;
/*    */ import com.ai.comframe.config.service.interfaces.ITimeSV;
/*    */ import java.sql.Timestamp;
/*    */ import java.text.SimpleDateFormat;
/*    */ 
/*    */ public class TimeUtil
/*    */ {
/*    */   public static Timestamp getSysTime()
/*    */     throws Exception
/*    */   {
/* 19 */     ITimeDAO timeDAO = (ITimeDAO)ServiceFactory.getService(ITimeDAO.class);
/* 20 */     return timeDAO.getSysdate();
/*    */   }
/*    */ 
/*    */   public static String getSysDateBySV() throws Exception {
/* 24 */     ITimeSV timeSV = (ITimeSV)ServiceFactory.getService(ITimeSV.class);
/* 25 */     Timestamp time = timeSV.getSysdate();
/* 26 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
/* 27 */     return dateFormat.format(time);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.TimeUtil
 * JD-Core Version:    0.5.4
 */