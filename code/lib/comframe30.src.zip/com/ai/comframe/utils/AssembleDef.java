/*     */ package com.ai.comframe.utils;
/*     */ 
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.List;
/*     */ 
/*     */ public class AssembleDef
/*     */ {
/*     */   private String queueId;
/*     */   private String regionId;
/*     */   private String sdate;
/*     */ 
/*     */   public String getQueueId()
/*     */   {
/*  28 */     return this.queueId;
/*     */   }
/*     */ 
/*     */   public void setQueueId(String queueId) {
/*  32 */     this.queueId = queueId;
/*     */   }
/*     */ 
/*     */   public String getRegionId() {
/*  36 */     return this.regionId;
/*     */   }
/*     */ 
/*     */   public void setRegionId(String regionId) {
/*  40 */     this.regionId = regionId;
/*     */   }
/*     */ 
/*     */   public String getSdate() {
/*  44 */     return this.sdate;
/*     */   }
/*     */ 
/*     */   public void setSdate(String sdate) {
/*  48 */     this.sdate = sdate;
/*     */   }
/*     */ 
/*     */   public static String getTimePeriod(Timestamp date)
/*     */   {
/*  57 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
/*  58 */     String period = dateFormat.format(date);
/*  59 */     return period;
/*     */   }
/*     */ 
/*     */   public static String[] splitTimePeriod(Timestamp startdate, Timestamp enddate)
/*     */     throws Exception
/*     */   {
/*  70 */     if (enddate.before(startdate))
/*  71 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.AssembleDef_startTimeLargerThanEnd"));
/*  72 */     SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
/*  73 */     Date date = new Date(startdate.getTime());
/*  74 */     GregorianCalendar cal = new GregorianCalendar();
/*  75 */     cal.setTime(date);
/*  76 */     String endpreiod = dateFormat.format(enddate);
/*  77 */     String tmpPreiod = "";
/*  78 */     List tmpList = new ArrayList();
/*  79 */     cal.add(2, -1);
/*  80 */     while (!tmpPreiod.equals(endpreiod)) {
/*  81 */       cal.add(2, 1);
/*  82 */       tmpPreiod = dateFormat.format(cal.getTime());
/*  83 */       tmpList.add(tmpPreiod);
/*     */     }
/*  85 */     return (String[])(String[])tmpList.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public static String[] getDefautTimePeriod()
/*     */     throws Exception
/*     */   {
/*  95 */     Timestamp current = TimeUtil.getSysTime();
/*  96 */     Date date = new Date(current.getTime());
/*  97 */     GregorianCalendar cal = new GregorianCalendar();
/*  98 */     cal.setTime(date);
/*  99 */     int hiscount = PropertiesUtil.getQueryHisMonthCount();
/* 100 */     String[] periods = { getTimePeriod(current) };
/* 101 */     if (PropertiesUtil.isHisSplit()) {
/* 102 */       periods = new String[hiscount];
/* 103 */       SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
/* 104 */       cal.add(2, -hiscount);
/* 105 */       for (int i = 0; i < hiscount; ++i) {
/* 106 */         cal.add(2, 1);
/* 107 */         periods[i] = dateFormat.format(cal.getTime());
/*     */       }
/*     */     }
/* 110 */     return periods;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.AssembleDef
 * JD-Core Version:    0.5.4
 */