/*     */ package com.ai.comframe.utils;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*     */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Timestamp;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TableAssembleUtil
/*     */ {
/*     */   public static final String S_QueueId = "QUEUE_ID";
/*     */   public static final String S_RegionId = "REGION_ID";
/*     */   public static final String S_TransferDate = "TRANSFER_DATE";
/*     */   public static final String SPLIT_CHAR = "_";
/*  29 */   private static transient Log log = LogFactory.getLog(TableAssembleUtil.class);
/*     */ 
/*     */   public static String createSelectSQL(DataContainer dc, AssembleDef assembleDef, String condition, int start, int end)
/*     */     throws Exception
/*     */   {
/*  44 */     return createSelectSQL(dc, null, assembleDef, condition, start, end);
/*     */   }
/*     */ 
/*     */   public static String createSelectSQL(DataContainer dc, String[] cols, AssembleDef assembleDef, String condition, int start, int end)
/*     */     throws Exception
/*     */   {
/*  59 */     String tableName = getTableName(dc.fetchTableName(), assembleDef);
/*  60 */     String selectSQL = DialectFactory.getDialect().getSelectSQL(null, dc.getObjectType(), cols, condition, start, end, false, false, null);
/*     */ 
/*  63 */     String result = StringUtils.replace(selectSQL, dc.fetchTableName(), tableName);
/*     */ 
/*  65 */     return result;
/*     */   }
/*     */ 
/*     */   public static String createHisSelectSQL(DataContainer dc, AssembleDef assembleDef, String condition, int start, int end)
/*     */     throws Exception
/*     */   {
/*  79 */     String tableName = getHisTableName(dc.fetchTableName(), assembleDef);
/*  80 */     String selectSQL = DialectFactory.getDialect().getSelectSQL(null, dc.getObjectType(), null, condition, start, end, false, false, null);
/*     */ 
/*  83 */     String result = StringUtils.replace(selectSQL, dc.fetchTableName(), tableName);
/*     */ 
/*  85 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getTableName(String tableName, AssembleDef assemDef)
/*     */     throws Exception
/*     */   {
/*  96 */     String queueId = assemDef.getQueueId();
/*     */ 
/*  98 */     if (StringUtils.isEmptyString(queueId))
/*  99 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_notSetQueueID"));
/* 100 */     IVmQueueConfigSV queueConfSv = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/* 101 */     IBOVmQueueConfigValue queueConf = queueConfSv.getVmQueueConfig(queueId, "workflow");
/* 102 */     String tabName = null;
/* 103 */     if (tableName.indexOf("{") > -1) {
/* 104 */       String[] tmpTableNames = StringUtils.getParamFromString(tableName, "{", "}");
/*     */ 
/* 106 */       if ((tmpTableNames != null) && (tmpTableNames.length == 1)) {
/* 107 */         tabName = tmpTableNames[0];
/*     */       }
/*     */       else
/* 110 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_getRealTableNameError") + tableName);
/*     */     } else {
/* 112 */       tabName = tableName;
/* 113 */     }StringBuffer sbTableName = new StringBuffer();
/* 114 */     sbTableName.append(tabName);
/* 115 */     if ("Y".equals(queueConf.getSplitQueue())) {
/* 116 */       sbTableName.append("_").append(queueId);
/*     */     }
/* 118 */     if ("Y".equals(queueConf.getSplitRegion())) {
/* 119 */       if (CenterFactory.isSetCenterInfo()) {
/* 120 */         CenterInfo info = CenterFactory.peekCenterInfo();
/* 121 */         if ((info == null) || (StringUtils.isEmptyString(info.getRegion())))
/*     */         {
/* 123 */           throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_noSplitInfo"));
/* 124 */         }sbTableName.append("_").append(info.getRegion());
/*     */       } else {
/* 126 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_noSplitInfo"));
/*     */       }
/*     */     }
/* 129 */     return sbTableName.toString();
/*     */   }
/*     */ 
/*     */   public static String getHisTableName(String tableName, AssembleDef assemDef)
/*     */     throws Exception
/*     */   {
/* 140 */     String tabName = getTableName(tableName, assemDef);
/* 141 */     if (log.isDebugEnabled())
/*     */     {
/* 143 */       log.debug(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_hisDataTable") + PropertiesUtil.isHisSplit());
/* 144 */     }if (PropertiesUtil.isHisSplit()) {
/* 145 */       String postFix = assemDef.getSdate();
/* 146 */       if (log.isDebugEnabled())
/*     */       {
/* 148 */         log.debug(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_hisTableDataIs") + postFix);
/* 149 */       }if (StringUtils.isEmptyString(postFix))
/*     */       {
/* 151 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.TableAssembleUtil_noDate"));
/* 152 */       }StringBuffer sb = new StringBuffer();
/* 153 */       sb.append(tabName).append("_").append(postFix);
/* 154 */       tabName = sb.toString();
/*     */     }
/* 156 */     return tabName;
/*     */   }
/*     */ 
/*     */   public static DataContainer replaceTableName(DataContainer aBean)
/*     */     throws Exception
/*     */   {
/* 166 */     String queueId = aBean.getAsString("QUEUE_ID");
/* 167 */     String tableName = aBean.fetchTableName();
/* 168 */     AssembleDef asDef = new AssembleDef();
/* 169 */     asDef.setQueueId(queueId);
/* 170 */     String TABLE_NAME = getTableName(tableName, asDef);
/* 171 */     aBean.replaceTableName(TABLE_NAME);
/* 172 */     if ((aBean.isNew()) && (StringUtils.isEmptyString(aBean.getAsString("REGION_ID"))) && (CenterFactory.isSetCenterInfo())) {
/* 173 */       CenterInfo info = CenterFactory.peekCenterInfo();
/* 174 */       if ((info != null) && (!StringUtils.isEmptyString(info.getRegion())))
/* 175 */         aBean.set("REGION_ID", info.getRegion());
/*     */     }
/* 177 */     return aBean;
/*     */   }
/*     */ 
/*     */   public static DataContainer replaceHisTableName(DataContainer aBean)
/*     */     throws Exception
/*     */   {
/* 187 */     String queueId = aBean.getAsString("QUEUE_ID");
/* 188 */     Timestamp transDate = aBean.getAsDateTime("TRANSFER_DATE");
/* 189 */     String tableName = aBean.fetchTableName();
/* 190 */     AssembleDef asDef = new AssembleDef();
/* 191 */     asDef.setQueueId(queueId);
/* 192 */     String sdate = AssembleDef.getTimePeriod(transDate);
/* 193 */     asDef.setSdate(sdate);
/* 194 */     String TABLE_NAME = getHisTableName(tableName, asDef);
/* 195 */     aBean.replaceTableName(TABLE_NAME);
/* 196 */     if ((aBean.isNew()) && (StringUtils.isEmptyString(aBean.getAsString("REGION_ID"))) && (CenterFactory.isSetCenterInfo())) {
/* 197 */       CenterInfo info = CenterFactory.peekCenterInfo();
/* 198 */       if ((info != null) && (!StringUtils.isEmptyString(info.getRegion())))
/* 199 */         aBean.set("REGION_ID", info.getRegion());
/*     */     }
/* 201 */     return aBean;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 205 */     AssembleDef a = new AssembleDef();
/* 206 */     a.setQueueId("dev");
/* 207 */     String tname = getTableName("{H_VM_TASK_TS}", a);
/* 208 */     System.out.println(tname);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.TableAssembleUtil
 * JD-Core Version:    0.5.4
 */