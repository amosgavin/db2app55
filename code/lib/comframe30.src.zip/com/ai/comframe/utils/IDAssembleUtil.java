/*     */ package com.ai.comframe.utils;
/*     */ 
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class IDAssembleUtil
/*     */ {
/*  21 */   private static transient Log logger = LogFactory.getLog(IDAssembleUtil.class);
/*     */ 
/*     */   public static String wrapPrefix(long id, String queueId, String regionId)
/*     */   {
/*  30 */     StringBuffer newId = new StringBuffer();
/*  31 */     newId.append(queueId).append("^");
/*     */ 
/*  33 */     if (regionId == null) {
/*  34 */       regionId = "";
/*     */     }
/*  36 */     newId.append(regionId).append("^");
/*     */ 
/*  38 */     String tmp = StringUtils.leftPad(String.valueOf(id), 25 - newId.toString().length(), "0");
/*  39 */     newId.append(tmp);
/*  40 */     if (logger.isDebugEnabled())
/*  41 */       logger.debug("wrap workflowId or taskId :" + newId.toString());
/*  42 */     return newId.toString();
/*     */   }
/*     */ 
/*     */   public static String unwrapPrefix(String id)
/*     */     throws Exception
/*     */   {
/*  51 */     if (StringUtils.countMatches(id, "^") == 0) {
/*  52 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.IDAssembleUtil_IDERROR") + id);
/*     */     }
/*  54 */     return StringUtils.substringBefore(id, "^");
/*     */   }
/*     */ 
/*     */   public static String unwrapRegionId(String id)
/*     */     throws Exception
/*     */   {
/*  63 */     if (StringUtils.countMatches(id, "^") != 2) {
/*  64 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.IDAssembleUtil_IDERROR") + id);
/*     */     }
/*  66 */     return StringUtils.substringBetween(id, "^", "^");
/*     */   }
/*     */ 
/*     */   public static boolean isWrapRegionId(String id) throws Exception
/*     */   {
/*  71 */     return StringUtils.countMatches(id, "^") == 2;
/*     */   }
/*     */ 
/*     */   public static long unwrapID(String id)
/*     */     throws Exception
/*     */   {
/*  83 */     if (StringUtils.countMatches(id, "^") == 0) {
/*  84 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.IDAssembleUtil_IDERROR") + id);
/*     */     }
/*  86 */     String tmp = StringUtils.substringAfterLast(id, "^");
/*  87 */     long unwrapid = Long.parseLong(tmp);
/*  88 */     return unwrapid;
/*     */   }
/*     */ 
/*     */   public static String wrappedIdColToNumFunc(String colName)
/*     */     throws Exception
/*     */   {
/* 100 */     if (StringUtils.isBlank(colName))
/* 101 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.IDAssembleUtil_IDNotEmpty"));
/* 102 */     StringBuilder result = new StringBuilder("");
/* 103 */     String dbType = DialectFactory.getDialect().getDatabaseType();
/* 104 */     if ("ORACLE".equals(dbType)) {
/* 105 */       result.append(" to_number(");
/* 106 */       result.append(" substr(").append(colName).append(",");
/* 107 */       result.append("^".length() * 2 + 5 + 6 + 1);
/* 108 */       result.append("))");
/*     */     }
/* 110 */     else if ("MYSQL".equals(dbType)) {
/* 111 */       result.append(" conv(");
/* 112 */       result.append(" right(").append(colName).append(",");
/* 113 */       result.append(25 - ("^".length() * 2 + 5 + 6 + 1));
/*     */ 
/* 115 */       result.append("),").append(10).append(",").append(10).append(")");
/* 116 */     } else if ("DB2".equals(dbType)) {
/* 117 */       result.append(" double(");
/* 118 */       result.append(" right(").append(colName).append(",");
/* 119 */       result.append("^".length() * 2 + 5 + 6 + 1);
/* 120 */       result.append("))");
/*     */     } else {
/* 122 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.IDAssembleUtil_noSupportDataBase") + dbType);
/*     */     }
/* 124 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 138 */     System.out.println(StringUtils.countMatches("", "^"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.IDAssembleUtil
 * JD-Core Version:    0.5.4
 */