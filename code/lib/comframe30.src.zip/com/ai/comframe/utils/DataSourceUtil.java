/*    */ package com.ai.comframe.utils;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterFactory;
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ import com.ai.appframe2.complex.util.CustomDataSourceUtil;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.comframe.config.ivalues.IBOVmQueueConfigValue;
/*    */ import com.ai.comframe.config.service.interfaces.IVmQueueConfigSV;
/*    */ import com.ai.comframe.locale.ComframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class DataSourceUtil
/*    */ {
/* 27 */   private static final Log log = LogFactory.getLog(DataSourceUtil.class);
/*    */ 
/*    */   public static boolean pushDataSourcebyQueueId(String queueId)
/*    */     throws Exception
/*    */   {
/* 34 */     if ((queueId == null) || (queueId.length() == 0)) {
/* 35 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.DataSourceUtil_queueIDNull") + queueId);
/*    */     }
/*    */ 
/* 38 */     Map map = new HashMap();
/* 39 */     IVmQueueConfigSV configsv = (IVmQueueConfigSV)ServiceFactory.getService(IVmQueueConfigSV.class);
/* 40 */     IBOVmQueueConfigValue queueConfig = configsv.getVmQueueConfig(queueId, "workflow");
/* 41 */     if ((queueConfig == null) || (queueConfig.isNew()))
/* 42 */       throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.DataSourceUtil_queueConfigIsNull") + queueId);
/* 43 */     String datasource = queueConfig.getDatasoure();
/* 44 */     if (StringUtils.contains(datasource, "{CENTER}"))
/*    */     {
/* 46 */       if (!CenterFactory.isSetCenterInfo()) {
/* 47 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.DataSourceUtil_noCenterInfo"));
/*    */       }
/* 49 */       CenterInfo info = CenterFactory.peekCenterInfo();
/*    */ 
/* 51 */       if ((info == null) || (StringUtils.isEmpty(info.getCenter())))
/* 52 */         throw new Exception(ComframeLocaleFactory.getResource("com.ai.comframe.utils.DataSourceUtil_noCenterInfo"));
/* 53 */       datasource = datasource.replace("{CENTER}", info.getCenter());
/*    */     }
/*    */ 
/* 57 */     map.put("com.ai.comframe.exception", datasource);
/* 58 */     map.put("com.ai.comframe.vm", datasource);
/*    */ 
/* 60 */     CustomDataSourceUtil.pushTmpMapping(map);
/* 61 */     return true;
/*    */   }
/*    */ 
/*    */   public static void popDataSource()
/*    */     throws Exception
/*    */   {
/* 68 */     CustomDataSourceUtil.popTmpMapping();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\comframe30.jar
 * Qualified Name:     com.ai.comframe.utils.DataSourceUtil
 * JD-Core Version:    0.5.4
 */