package com.ai.appframe2.ejb.proxy;

import com.ai.appframe2.monitor.ClientInfo;
import com.ai.appframe2.privilege.UserInfoInterface;
import com.ai.appframe2.service.proxy.RemoteCallDefine;
import java.rmi.RemoteException;
import javax.ejb.EJBObject;

public abstract interface ProxyEjbRemote extends EJBObject
{
  public static final String PROXYEJB_JNDI = "com.ai.appframe2.ejb.proxy.ProxyEjbService";
  public static final String PROXYEJB_HOME = "com.ai.appframe2.ejb.proxy.ProxyEjbRemoteHome";

  public abstract Object callRemote(UserInfoInterface paramUserInfoInterface, ClientInfo paramClientInfo, RemoteCallDefine paramRemoteCallDefine)
    throws Exception, RemoteException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.proxy.ProxyEjbRemote
 * JD-Core Version:    0.5.4
 */