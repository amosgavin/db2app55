/*    */ package com.ai.appframe2.ejb.proxy;
/*    */ 
/*    */ import com.ai.appframe2.common.AIThreadLocal;
/*    */ import com.ai.appframe2.common.DataType;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.appframe2.monitor.CallManager;
/*    */ import com.ai.appframe2.monitor.ClientInfo;
/*    */ import com.ai.appframe2.privilege.UserInfoInterface;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.service.proxy.RemoteCallDefine;
/*    */ import java.lang.reflect.Method;
/*    */ import java.rmi.RemoteException;
/*    */ import javax.ejb.CreateException;
/*    */ import javax.ejb.EJBException;
/*    */ import javax.ejb.SessionBean;
/*    */ import javax.ejb.SessionContext;
/*    */ 
/*    */ public class ProxyEjbService
/*    */   implements SessionBean
/*    */ {
/*    */   private SessionContext ejbSessionContext;
/*    */ 
/*    */   public ProxyEjbService()
/*    */   {
/* 53 */     this.ejbSessionContext = null;
/*    */   }
/*    */   public void setSessionContext(SessionContext ejbSessionContext) throws EJBException, RemoteException {
/* 56 */     this.ejbSessionContext = ejbSessionContext;
/*    */   }
/*    */ 
/*    */   public void ejbCreate()
/*    */     throws CreateException
/*    */   {
/*    */   }
/*    */ 
/*    */   public void ejbRemove()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void ejbActivate()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void ejbPassivate()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Object callRemote(UserInfoInterface userInfo, ClientInfo clientInfo, RemoteCallDefine define)
/*    */     throws Exception, RemoteException
/*    */   {
/* 80 */     AIThreadLocal.clearAll();
/*    */ 
/* 82 */     ServiceManager.setServiceUserInfo(userInfo);
/* 83 */     CallManager.setClientInfoForEJBCall(clientInfo);
/*    */ 
/* 85 */     String serviceId = define.getClassName();
/* 86 */     String methodName = define.getMethodName();
/* 87 */     String[] paramClassNames = define.getParameterClassNames();
/* 88 */     Object[] params = define.getParameterObjects();
/*    */ 
/* 90 */     Class[] pClasses = new Class[paramClassNames.length];
/* 91 */     for (int i = 0; i < paramClassNames.length; ++i) {
/* 92 */       pClasses[i] = DataType.getJavaClass(paramClassNames[i]);
/*    */     }
/* 94 */     Method tmpMethod = ServiceFactory.getService(serviceId).getClass().getMethod(methodName, pClasses);
/* 95 */     Object result = tmpMethod.invoke(ServiceFactory.getService(serviceId), params);
/*    */ 
/* 97 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.proxy.ProxyEjbService
 * JD-Core Version:    0.5.4
 */