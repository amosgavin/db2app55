package com.ai.appframe2.ejb.proxy;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface ProxyEjbRemoteHome extends EJBHome
{
  public abstract ProxyEjbRemote create()
    throws RemoteException, CreateException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.proxy.ProxyEjbRemoteHome
 * JD-Core Version:    0.5.4
 */