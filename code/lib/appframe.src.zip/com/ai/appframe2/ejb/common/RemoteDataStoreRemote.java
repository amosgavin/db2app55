package com.ai.appframe2.ejb.common;

import com.ai.appframe2.common.RemoteDataStore;
import javax.ejb.EJBObject;

public abstract interface RemoteDataStoreRemote extends EJBObject, RemoteDataStore
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.common.RemoteDataStoreRemote
 * JD-Core Version:    0.5.4
 */