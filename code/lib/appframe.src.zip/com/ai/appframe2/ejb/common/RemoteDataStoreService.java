/*     */ package com.ai.appframe2.ejb.common;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.RemoteDataStore;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Map;
/*     */ import javax.ejb.CreateException;
/*     */ import javax.ejb.EJBException;
/*     */ import javax.ejb.SessionBean;
/*     */ import javax.ejb.SessionContext;
/*     */ 
/*     */ public class RemoteDataStoreService
/*     */   implements SessionBean
/*     */ {
/*     */   private RemoteDataStore impl;
/*     */   private SessionContext ejbSessionContext;
/*     */ 
/*     */   public RemoteDataStoreService()
/*     */   {
/*  54 */     this.impl = null;
/*  55 */     this.ejbSessionContext = null;
/*     */   }
/*     */ 
/*     */   public void setSessionContext(SessionContext ejbSessionContext) throws EJBException, RemoteException {
/*  59 */     this.ejbSessionContext = ejbSessionContext;
/*     */   }
/*     */ 
/*     */   public void ejbCreate() throws CreateException {
/*     */     try {
/*  64 */       this.impl = ((RemoteDataStore)ServiceFactory.getService("com.ai.appframe.service.RemoteDataStore"));
/*     */     } catch (Exception ex) {
/*  66 */       throw new CreateException("EjbCreate Exception:" + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ejbRemove()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void ejbActivate() {
/*     */   }
/*     */ 
/*     */   public void ejbPassivate() {
/*     */   }
/*     */ 
/*     */   public void save(UserInfoInterface userInfo, DataContainerInterface[] dcs) throws RemoteException, Exception {
/*  81 */     this.impl.save(userInfo, dcs);
/*     */   }
/*     */ 
/*     */   public int retrieveCount(ObjectType aType, String aCondition, Map aParameterList, String[] aExtenBOArray)
/*     */     throws RemoteException, Exception
/*     */   {
/*  96 */     return this.impl.retrieveCount(aType, aCondition, aParameterList, aExtenBOArray);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] retrieve(Class dcClass, ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws RemoteException, Exception
/*     */   {
/* 124 */     return this.impl.retrieve(dcClass, aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] retrieve(String strSql, Map aParameterList)
/*     */     throws RemoteException, Exception
/*     */   {
/* 142 */     return this.impl.retrieve(strSql, aParameterList);
/*     */   }
/*     */ 
/*     */   public int execute(String strSql, Map aParameterList)
/*     */     throws RemoteException, Exception
/*     */   {
/* 153 */     return this.impl.execute(strSql, aParameterList);
/*     */   }
/*     */ 
/*     */   public long getNewId(String tableName)
/*     */     throws RemoteException, Exception
/*     */   {
/* 163 */     return this.impl.getNewId(tableName);
/*     */   }
/*     */ 
/*     */   public ResultSet retrieve(ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws RemoteException, Exception
/*     */   {
/* 173 */     return this.impl.retrieve(aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/*     */   }
/*     */ 
/*     */   public void fillDataContainerFromBoClass(ResultSet aDataRowSet, DataContainerInterface dc, Property[] attrList, boolean aFkFlag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 186 */     this.impl.fillDataContainerFromBoClass(aDataRowSet, dc, attrList, aFkFlag);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] createDtaContainerFromResultSet(Class dcClass, ObjectType type, ResultSet aDataRowSet, String[] attrList, boolean aFkFlag)
/*     */     throws RemoteException, Exception
/*     */   {
/* 193 */     return this.impl.createDtaContainerFromResultSet(dcClass, type, aDataRowSet, attrList, aFkFlag);
/*     */   }
/*     */ 
/*     */   public Date getSysDate()
/*     */     throws RemoteException, Exception
/*     */   {
/* 199 */     return this.impl.getSysDate();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.common.RemoteDataStoreService
 * JD-Core Version:    0.5.4
 */