package com.ai.appframe2.ejb.common;

import java.rmi.RemoteException;
import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public abstract interface RemoteDataStoreRemoteHome extends EJBHome
{
  public abstract RemoteDataStoreRemote create()
    throws RemoteException, CreateException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.ejb.common.RemoteDataStoreRemoteHome
 * JD-Core Version:    0.5.4
 */