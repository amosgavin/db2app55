/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Test
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/*  9 */     CrossGridImpl crossgrid = null;
/* 10 */     String dimes = "bmh=-1,spbh=" + DimensionOrMeas.SUBTOTAL_DESC + ",year=" + DimensionOrMeas.SUBTOTAL_DESC + ",month=" + DimensionOrMeas.SUBTOTAL_DESC;
/*    */ 
/* 12 */     String meass = "sl";
/* 13 */     Object[][] t = crossgrid.getFactData(dimes, meass);
/* 14 */     for (int i = 0; i < t.length; ++i) {
/* 15 */       for (int j = 0; j < t[i].length; ++j)
/* 16 */         System.out.print(t[i][j] + "\t");
/* 17 */       System.out.println("\n");
/*    */     }
/* 19 */     System.out.println("-----------");
/* 20 */     dimes = "bmh=0106,spbh=-1,year=" + DimensionOrMeas.SUBTOTAL_DESC + ",month=" + DimensionOrMeas.SUBTOTAL_DESC;
/* 21 */     t = crossgrid.getFactData(dimes, meass);
/* 22 */     for (int i = 0; i < t.length; ++i) {
/* 23 */       for (int j = 0; j < t[i].length; ++j)
/* 24 */         System.out.print(t[i][j] + "\t");
/* 25 */       System.out.println("\n");
/*    */     }
/*    */ 
/* 28 */     System.out.println("-----------");
/* 29 */     dimes = "bmh=0106,spbh=013,year=-1,month=" + DimensionOrMeas.SUBTOTAL_DESC;
/* 30 */     t = crossgrid.getFactData(dimes, meass);
/* 31 */     for (int i = 0; i < t.length; ++i) {
/* 32 */       for (int j = 0; j < t[i].length; ++j)
/* 33 */         System.out.print(t[i][j] + "\t");
/* 34 */       System.out.println("\n");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.Test
 * JD-Core Version:    0.5.4
 */