/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class TreeGrid extends McGrid
/*     */ {
/*  16 */   public static String imgFoldc = null;
/*  17 */   public static String imgFoldo = null;
/*  18 */   public static String imgLeafc = null;
/*     */ 
/*     */   public void initial(String contextPath, CrossGridImpl aCrossGrid, PivotList aPivots, boolean aIsDKE)
/*     */     throws Exception
/*     */   {
/*  28 */     if (imgFoldc == null)
/*     */     {
/*  30 */       HashMap picMap = AIConfigManager.getConfigItemsByKind("TreeGridImg");
/*  31 */       imgFoldc = (String)picMap.get("TreeGrid_FoldCloseImg");
/*  32 */       imgFoldo = (String)picMap.get("TreeGrid_FoldOpenImg");
/*  33 */       imgLeafc = (String)picMap.get("TreeGrid_LeafImg");
/*     */     }
/*     */ 
/*  37 */     for (int i = 0; i < aPivots.pivots[Pivot.ROW_AREA].size(); ++i) {
/*  38 */       ((Pivot)aPivots.pivots[Pivot.ROW_AREA].get(i)).isSubTotal = true;
/*  39 */       ((Pivot)aPivots.pivots[Pivot.ROW_AREA].get(i)).IsSuppressRepeat = true;
/*  40 */       ((Pivot)aPivots.pivots[Pivot.ROW_AREA].get(i)).subTotalPosition = CrossGridImpl.S_TYPE_TOTAL_BEFORE;
/*     */     }
/*     */ 
/*  43 */     super.initial(contextPath, aCrossGrid, aPivots, aIsDKE);
/*     */   }
/*     */ 
/*     */   private void toHtmlTableHead(Writer writer)
/*     */     throws Exception
/*     */   {
/*  49 */     List tmpList = new ArrayList();
/*     */ 
/*  54 */     if (this.tableHeadCount == 0)
/*  55 */       if (getPivots().size(Pivot.ROW_AREA) > 0) {
/*  56 */         writer.write("<tr align='center'  height='30' class=\"G-TableHead\" bgColor=\"#7691C7\" colPivot=\"0\"> ");
/*     */ 
/*  58 */         writer.write("<td>");
/*  59 */         for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j) {
/*  60 */           writer.write(this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName());
/*     */         }
/*     */ 
/*  67 */         writer.write("</td>");
/*     */ 
/*  69 */         if (this.measIndex >= 0) {
/*  70 */           writer.write("<td width=\"100\" collevel=\"1\">" + this.m_crossGrid.getMeas().getDesc(this.measIndex) + "</td>");
/*     */         }
/*     */         else
/*     */         {
/*  74 */           String strData = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.TreeGrid.data");
/*  75 */           writer.write("<td width=\"100\" collevel=\"1\">" + strData + "</td>");
/*     */         }
/*     */ 
/*  79 */         writer.write("</tr>");
/*     */       }
/*     */     else
/*  82 */       for (int i = 0; i < this.tableHeadCount; ++i) {
/*  83 */         writer.write("<tr align='center'  height='30' class=\"G-TableHead\" bgColor=\"#7691C7\" colPivot=\"" + i + "\"  isRowTotal=\"false\"> ");
/*     */ 
/*  87 */         if (getPivots().size(Pivot.ROW_AREA) > 0) {
/*  88 */           if (i == this.tableHeadCount - 1) {
/*  89 */             writer.write("<td width=\"100\">");
/*  90 */             for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j) {
/*  91 */               writer.write(this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName());
/*     */             }
/*     */ 
/*  98 */             writer.write("</td>");
/*     */           } else {
/* 100 */             writer.write("<td width=\"100\"></td>");
/*     */           }
/*     */         }
/*     */ 
/* 104 */         tmpList.clear();
/* 105 */         this.tableHead.getListByLevel(i, tmpList);
/* 106 */         Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.COL_AREA, i);
/* 107 */         DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 109 */         for (int j = 0; j < tmpList.size(); ++j) {
/* 110 */           CrossGridNode tmpNode = (CrossGridNode)tmpList.get(j);
/* 111 */           CrossGridNode parentNode = tmpNode.getParent();
/* 112 */           boolean parentIsSubTotal = false;
/* 113 */           if ((parentNode != null) && (parentNode.getDimValueIndex() == this.m_crossGrid.getDimOrMeasByIndex(parentNode.getDimIndex()).count()))
/*     */           {
/* 117 */             parentIsSubTotal = true;
/*     */           }
/*     */ 
/* 120 */           if (tmpPivot.IsSuppressRepeat == true) {
/* 121 */             writer.write("<td colspan='" + tmpNode.getRange() + "' width='" + tmpNode.getRange() * 100 + "' collevel=\"" + i + "\">");
/*     */ 
/* 124 */             if (!parentIsSubTotal) {
/* 125 */               writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/*     */             }
/* 127 */             writer.write("</td>");
/*     */           }
/*     */           else {
/* 130 */             for (int k = 0; k < tmpNode.getRange(); ++k) {
/* 131 */               writer.write("<td width='100' collevel=\"" + i + "\">");
/* 132 */               if (!parentIsSubTotal) {
/* 133 */                 writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/*     */               }
/* 135 */               writer.write("</td>");
/*     */             }
/*     */           }
/*     */         }
/* 139 */         writer.write("</tr>");
/*     */       }
/*     */   }
/*     */ 
/*     */   public void toHtmlRowHead(Writer writer, String id, CrossGridNode node, int level, int startRow, boolean parentIsSubTotal, String parentName, String parentRows)
/*     */     throws Exception
/*     */   {
/* 148 */     List tmpList = node.getChilds();
/*     */ 
/* 150 */     if (tmpList == null) {
/* 151 */       toHtmlRowData(writer, level);
/* 152 */       return;
/*     */     }
/*     */ 
/* 156 */     for (int i = 0; i < tmpList.size(); ++i) {
/* 157 */       CrossGridNode tmpNode = (CrossGridNode)tmpList.get(i);
/*     */ 
/* 159 */       Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.ROW_AREA, level);
/* 160 */       DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 162 */       if (tmpNode.getDimIndex() == this.m_crossGrid.getDimCount())
/* 163 */         this.measIndex = tmpNode.getDimValueIndex();
/*     */       else {
/* 165 */         this.indexRec[tmpNode.getDimIndex()] = tmpNode.getDimValueIndex();
/*     */       }
/* 167 */       boolean tmpIsSubTotal = tmpNode.getDimValueIndex() == tmpDim.count();
/* 168 */       if ((!parentIsSubTotal) && (((tmpIsSubTotal == true) || (level == this.m_pivots.pivots[Pivot.ROW_AREA].size() - 1)))) {
/* 169 */         writer.write("<tr NOWRAP  height='25' class=\"G-TableBody\" borderColor=\"#000000\"");
/*     */ 
/* 171 */         int tmpLevel = level;
/* 172 */         if (!tmpIsSubTotal) {
/* 173 */           tmpLevel = level + 1;
/* 174 */           writer.write(" nodetype='leaf'");
/*     */         }
/*     */         else
/*     */         {
/* 178 */           tmpLevel = level;
/* 179 */           writer.write(" nodetype='dir'");
/*     */         }
/* 181 */         writer.write(">");
/*     */ 
/* 183 */         writer.write("<td NOWRAP  rowPivot=\"" + tmpLevel + "\" parentRows=\"" + parentRows + "\">");
/* 184 */         writer.write("<label  style='width:" + tmpLevel * 20 + "px;display:in-line;'></label>");
/*     */ 
/* 189 */         if (tmpIsSubTotal == true) {
/* 190 */           writer.write("<img src='" + CONTEXT_PATH + imgFoldo + "' onclick=\"TreeGrid_Expansion('" + id + "',this,'" + (startRow + i) + "')\"/>");
/*     */ 
/* 192 */           writer.write("<span NOWRAP='true' style='display:in-line;'>");
/* 193 */           writer.write(parentName);
/* 194 */           writer.write("</span>");
/*     */ 
/* 197 */           parentRows = parentRows + startRow + ",";
/* 198 */         } else if (level == this.m_pivots.pivots[Pivot.ROW_AREA].size() - 1) {
/* 199 */           writer.write("<img src='" + CONTEXT_PATH + imgLeafc + "' onclick=\"TreeGrid_Expansion('" + id + "',this,'" + (startRow + i) + "')\"/>");
/*     */ 
/* 201 */           writer.write("<span NOWRAP='true' style='display:in-line;'>");
/* 202 */           writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/* 203 */           writer.write("</span>");
/*     */         }
/* 205 */         writer.write("</td>");
/*     */       }
/* 207 */       toHtmlRowHead(writer, id, tmpNode, level + 1, startRow, tmpIsSubTotal, tmpDim.getDesc(tmpNode.getDimValueIndex()), parentRows);
/*     */ 
/* 210 */       if ((!parentIsSubTotal) && (((tmpIsSubTotal == true) || (level == this.m_pivots.pivots[Pivot.ROW_AREA].size() - 1))))
/*     */       {
/* 213 */         writer.write("</tr>\n");
/*     */       }
/* 215 */       startRow += tmpNode.getRange();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void toHtmlGrid(Writer writer, String id)
/*     */     throws Exception
/*     */   {
/* 223 */     writer.write("<table id=\"crosshead\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\" style=\"color:#F1F3F9;BORDER-RIGHT: 1px solid; BORDER-TOP: 0px solid; BORDER-LEFT: 1px solid;BORDER-BOTTOM: 1px solid; TABLE-LAYOUT: fixed; BORDER-COLLAPSE: collapse\" borderColor=\"#404D5D\"  border=\"0\" onclick=\"CrossGrid_GridData_OnClick('" + id + "')\">");
/*     */ 
/* 225 */     toHtmlTableHead(writer);
/* 226 */     String strTotal = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.TreeGrid.total");
/* 227 */     toHtmlRowHead(writer, id, this.rowHead, 0, 1, false, strTotal, ",");
/* 228 */     writer.write("</table>\n");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.TreeGrid
 * JD-Core Version:    0.5.4
 */