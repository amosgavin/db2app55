/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class DataBlock
/*    */ {
/*    */   public HashMap list;
/*    */ 
/*    */   public DataBlock()
/*    */   {
/* 15 */     this.list = new HashMap();
/*    */   }
/*    */ 
/*    */   public void free() {
/* 19 */     this.list.clear();
/*    */   }
/*    */ 
/*    */   public RowData getRow(int index)
/*    */   {
/* 26 */     return (RowData)this.list.get(new Integer(index));
/*    */   }
/*    */ 
/*    */   public void addRow(int index, RowData data) {
/* 30 */     this.list.put(new Integer(index), data);
/*    */   }
/*    */ 
/*    */   public int getRowCount() {
/* 34 */     return this.list.size();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.DataBlock
 * JD-Core Version:    0.5.4
 */