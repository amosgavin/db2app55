/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ class InitialLock
/*     */ {
/*     */   public boolean m_boolean;
/*     */ 
/*     */   public InitialLock(boolean aBoolean)
/*     */   {
/* 895 */     this.m_boolean = aBoolean;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.InitialLock
 * JD-Core Version:    0.5.4
 */