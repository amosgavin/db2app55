/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CrossGridManagerImpl
/*     */   implements CrossGridManager
/*     */ {
/*     */   public static final String CrossGrid_ShowType = "crossgrid";
/*     */   public static final String TreeGrid_ShowType = "treegrid";
/*  21 */   private String contextPath = "";
/*     */ 
/*  23 */   private static transient Log log = LogFactory.getLog(CrossGridManagerImpl.class);
/*     */ 
/*     */   private McGridInterface getInstanceByType(String contextPath, CrossGridImpl impl, PivotList pivotList, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/*  29 */     McGridInterface mcGrid = null;
/*  30 */     String showTypeImplClassNameProp = showType + "_implclass";
/*     */ 
/*  32 */     log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.getImplementByshowtype", new String[] { showTypeImplClassNameProp }));
/*  33 */     String showTypeImplClassName = AIConfigManager.getConfigItem(showTypeImplClassNameProp);
/*  34 */     if (showTypeImplClassName != null) {
/*  35 */       mcGrid = (McGridInterface)Class.forName(showTypeImplClassName).newInstance();
/*  36 */       mcGrid.initial(contextPath, impl, pivotList, isDke);
/*     */     }
/*     */     else
/*     */     {
/*  41 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridManagerImpl.get_by_attr_error", new String[] { showTypeImplClassNameProp }));
/*  42 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridManagerImpl.get_by_attr_error", new String[] { showTypeImplClassNameProp }));
/*     */     }
/*  44 */     return mcGrid;
/*     */   }
/*     */ 
/*     */   public McGridInterface getInstance(long pk, PivotList pivotList, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/*  54 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/*  55 */     return getInstanceByType(this.contextPath, impl, pivotList, isDke, showType);
/*     */   }
/*     */ 
/*     */   public McGridInterface getNewCrossGridInstance(HttpServletRequest req, String pName, String pDataModelStr, PivotList pivotList, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/*  64 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pName, pDataModelStr, true, req);
/*  65 */     return getInstanceByType(this.contextPath, impl, pivotList, isDke, showType);
/*     */   }
/*     */ 
/*     */   public void toHtmlSelectArea(Writer writer, McGridInterface pMcGrid)
/*     */     throws Exception
/*     */   {
/*  72 */     for (int i = 0; i < pMcGrid.getPivots().size(Pivot.SELECT_AREA); ++i) {
/*  73 */       Pivot pivot = pMcGrid.getPivots().getPivot(pMcGrid.getCrossGridImpl(), Pivot.SELECT_AREA, i);
/*  74 */       DimensionOrMeas dim = pMcGrid.getCrossGridImpl().getDimOrMeasByIndex(pivot.dimIndex);
/*  75 */       int dimDataCount = dim.count();
/*  76 */       if (pivot.isSubTotal == true)
/*  77 */         dimDataCount += 1;
/*  78 */       writer.write("<select id='cross_selsect_" + dim.getCode() + "'>\n");
/*     */ 
/*  87 */       for (int j = 0; j < dimDataCount; ++j) {
/*  88 */         if (j == pivot.selectValueIndex) {
/*  89 */           writer.write("\t<option selected value='" + dim.getRealDimIndex(j, pivot.sortType) + "'>" + dim.getDesc(dim.getRealDimIndex(j, pivot.sortType)) + "</option>\n");
/*     */         }
/*     */         else {
/*  92 */           writer.write("\t<option value='" + dim.getRealDimIndex(j, pivot.sortType) + "'>" + dim.getDesc(dim.getRealDimIndex(j, pivot.sortType)) + "</option>\n");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  97 */       writer.write("</select>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void toHtmlGrid(Writer writer, String pId, McGridInterface aMcGrid) throws Exception {
/* 102 */     aMcGrid.toHtmlGrid(writer, pId);
/*     */   }
/*     */ 
/*     */   public String getPovitsConfigStr(McGridInterface pMcGrid)
/*     */     throws Exception
/*     */   {
/* 114 */     StringBuilder revStrBuff = new StringBuilder();
/* 115 */     int[] areaTypeArray = { Pivot.SELECT_AREA, Pivot.ROW_AREA, Pivot.COL_AREA };
/*     */ 
/* 118 */     for (int m = 0; m < areaTypeArray.length; ++m) {
/* 119 */       if (pMcGrid.getPivots().size(areaTypeArray[m]) == 0) {
/* 120 */         revStrBuff.append("null").append("$$");
/*     */       }
/*     */       else {
/* 123 */         for (int i = 0; i < pMcGrid.getPivots().size(areaTypeArray[m]); ++i) {
/* 124 */           Pivot pivot = pMcGrid.getPivots().getPivot(pMcGrid.getCrossGridImpl(), areaTypeArray[m], i);
/* 125 */           DimensionOrMeas dimObj = pMcGrid.getCrossGridImpl().getDimOrMeasByIndex(pivot.dimIndex);
/*     */ 
/* 127 */           revStrBuff.append(pivot.dimIndex).append(",").append(dimObj.getCode()).append(",").append(dimObj.getName()).append(",").append(areaTypeArray[m]).append(",");
/*     */ 
/* 135 */           if (pivot.isSubTotal == true) {
/* 136 */             revStrBuff.append("1").append(",");
/*     */           }
/*     */           else {
/* 139 */             revStrBuff.append("0").append(",");
/*     */           }
/* 141 */           if (areaTypeArray[m] == Pivot.SELECT_AREA) {
/* 142 */             revStrBuff.append("-1").append(",");
/*     */           }
/* 145 */           else if (pivot.IsSuppressRepeat == true) {
/* 146 */             revStrBuff.append("1").append(",");
/*     */           }
/*     */           else {
/* 149 */             revStrBuff.append("0").append(",");
/*     */           }
/*     */ 
/* 152 */           if (pivot.sortType == 1)
/*     */           {
/* 154 */             revStrBuff.append("asc");
/*     */           }
/* 156 */           else if (pivot.sortType == -1) {
/* 157 */             revStrBuff.append("desc");
/*     */           }
/*     */           else {
/* 160 */             revStrBuff.append("0");
/*     */           }
/* 162 */           revStrBuff.append("$$");
/*     */         }
/*     */       }
/*     */ 
/* 166 */       revStrBuff.setLength(revStrBuff.length() - 2);
/* 167 */       revStrBuff.append("|||");
/*     */     }
/*     */ 
/* 172 */     revStrBuff.setLength(revStrBuff.length() - 3);
/* 173 */     return revStrBuff.toString();
/*     */   }
/*     */ 
/*     */   public void refreshConfig(Writer writer, String id, long pk, String configStr, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/* 180 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/* 181 */     PivotList pivotList = transPivot(configStr);
/* 182 */     McGridInterface mcGrid = getInstanceByType(this.contextPath, impl, pivotList, isDke, showType);
/* 183 */     writer.write("<?xml version ='1.0' encoding = 'GB2312'?>\n\n");
/* 184 */     writer.write("<CrossGridData>");
/* 185 */     writer.write("<ConfigStr><![CDATA[");
/* 186 */     writer.write(configStr);
/* 187 */     writer.write("]]></ConfigStr>");
/* 188 */     writer.write("<SelectArea><![CDATA[");
/* 189 */     toHtmlSelectArea(writer, mcGrid);
/* 190 */     writer.write("]]></SelectArea>");
/* 191 */     writer.write("<Data><![CDATA[");
/* 192 */     toHtmlGrid(writer, id, mcGrid);
/* 193 */     writer.write("]]></Data>");
/* 194 */     writer.write("</CrossGridData>");
/*     */   }
/*     */ 
/*     */   public void refresh(Writer writer, String id, long pk, String selectValueIndexList, String pivotListStr, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/* 200 */     String[] selectIndexs = StringUtils.split(selectValueIndexList, ",");
/* 201 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/* 202 */     PivotList list = transPivot(pivotListStr);
/* 203 */     for (int i = 0; i < selectIndexs.length; ++i) {
/* 204 */       if (selectIndexs[i].length() >= 1) {
/* 205 */         list.getPivot(impl, Pivot.SELECT_AREA, i).selectValueIndex = Integer.parseInt(selectIndexs[i]);
/*     */       }
/*     */     }
/* 208 */     McGridInterface grid = getInstanceByType(this.contextPath, impl, list, isDke, showType);
/* 209 */     writer.write("<?xml version ='1.0' encoding = 'GB2312'?>\n\n");
/* 210 */     writer.write("<Data><![CDATA[");
/* 211 */     toHtmlGrid(writer, id, grid);
/* 212 */     writer.write("]]></Data>");
/*     */   }
/*     */ 
/*     */   public void reloadCrossGridImpl(Writer writer, String id, long pk, String selectValueIndexList, String pivotListStr, boolean isDke, String showType, ServletRequest req)
/*     */     throws Exception
/*     */   {
/* 219 */     String[] selectIndexs = StringUtils.split(selectValueIndexList, ',');
/* 220 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/* 221 */     impl.free();
/* 222 */     CrossGridFactory.getCrossGridFactory().initCrossGridData(impl.getConfigXmlName(), impl, impl.getDataModelStr(), req);
/* 223 */     PivotList list = transPivot(pivotListStr);
/* 224 */     for (int i = 0; i < selectIndexs.length; ++i) {
/* 225 */       if (selectIndexs[i].length() >= 1) {
/* 226 */         list.getPivot(impl, Pivot.SELECT_AREA, i).selectValueIndex = Integer.parseInt(selectIndexs[i]);
/*     */       }
/*     */     }
/* 229 */     McGridInterface grid = getInstanceByType(this.contextPath, impl, list, isDke, showType);
/* 230 */     writer.write("<?xml version ='1.0' encoding = 'GB2312'?>\n\n");
/* 231 */     writer.write("<Data><![CDATA[");
/* 232 */     toHtmlGrid(writer, id, grid);
/* 233 */     writer.write("]]></Data>");
/*     */   }
/*     */ 
/*     */   public void toExcel(OutputStream out, String id, long pk, String selectValueIndexList, String pivotListStr, boolean isDke, String showType)
/*     */     throws Exception
/*     */   {
/* 242 */     CrossGridImpl impl = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/* 243 */     PivotList list = transPivot(pivotListStr);
/*     */ 
/* 245 */     String[] selectIndexs = StringUtils.split(selectValueIndexList, ',');
/* 246 */     for (int i = 0; i < selectIndexs.length; ++i) {
/* 247 */       if (selectIndexs[i].length() >= 1) {
/* 248 */         list.getPivot(impl, Pivot.SELECT_AREA, i).selectValueIndex = Integer.parseInt(selectIndexs[i]);
/*     */       }
/*     */     }
/*     */ 
/* 252 */     McGridInterface grid = getInstanceByType(this.contextPath, impl, list, isDke, showType);
/* 253 */     grid.toExcel(out, id);
/*     */   }
/*     */ 
/*     */   public PivotList transPivot(String pivotListStr)
/*     */     throws Exception
/*     */   {
/* 265 */     PivotList povitList = new PivotList();
/* 266 */     boolean isTotal = false;
/* 267 */     boolean isCompress = false;
/* 268 */     String[] pivotArray = StringUtils.split(pivotListStr, "|||");
/* 269 */     for (int i = 0; i < pivotArray.length; ++i) {
/* 270 */       if (!pivotArray[i].equals("null")) {
/* 271 */         String[] dimsArray = StringUtils.split(pivotArray[i], "$$");
/* 272 */         for (int j = 0; j < dimsArray.length; ++j) {
/* 273 */           String[] dimArray = StringUtils.split(dimsArray[j], ",");
/* 274 */           if (dimArray.length == 7) {
/* 275 */             isTotal = false;
/* 276 */             isCompress = false;
/* 277 */             if (dimArray[4].equals("1"))
/* 278 */               isTotal = true;
/* 279 */             if (dimArray[5].equals("1"))
/* 280 */               isCompress = true;
/* 281 */             povitList.addPivot(Integer.parseInt(dimArray[3]), Integer.parseInt(dimArray[0]), dimArray[1], 0, isTotal, isCompress, dimArray[6]);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 296 */     return povitList;
/*     */   }
/*     */ 
/*     */   public String getContextPath()
/*     */   {
/* 304 */     return this.contextPath;
/*     */   }
/*     */   public void setContextPath(String contextPath) {
/* 307 */     this.contextPath = contextPath;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridManagerImpl
 * JD-Core Version:    0.5.4
 */