package com.ai.appframe2.analyse;

import javax.servlet.ServletRequest;

public abstract interface CrossGridDataModelInterface
{
  public abstract void init(String paramString, ServletRequest paramServletRequest)
    throws Exception;

  public abstract Object getGridData()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridDataModelInterface
 * JD-Core Version:    0.5.4
 */