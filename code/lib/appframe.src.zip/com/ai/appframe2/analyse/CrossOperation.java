/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.express.Operation;
/*    */ import com.ai.appframe2.express.OperatorManager;
/*    */ 
/*    */ public class CrossOperation extends Operation
/*    */ {
/*    */   public CrossGridImpl m_crossGrid;
/*    */   public RowData m_currentRow;
/*    */ 
/*    */   public CrossOperation(CrossGridImpl crossgrid)
/*    */   {
/* 12 */     super(new OperatorManager());
/* 13 */     this.m_crossGrid = crossgrid;
/* 14 */     getOperatorManager().addFunction("group", new GroupOperator(this));
/*    */   }
/*    */ 
/*    */   public Object getAttrValue(String name) throws Exception {
/* 18 */     int index = this.m_crossGrid.getDimIndexByCode(name);
/* 19 */     Object result = null;
/* 20 */     if (index >= 0) {
/* 21 */       result = this.m_crossGrid.getDimension(index).getDesc(this.m_currentRow.getDimIndex(index));
/*    */     }
/*    */     else {
/* 24 */       index = this.m_crossGrid.getMeas().indexOfByCode(name);
/* 25 */       if (index >= 0)
/* 26 */         result = this.m_currentRow.getMeasObject(index);
/*    */     }
/* 28 */     return result;
/*    */   }
/*    */   public void setCurrentRowData(RowData row) {
/* 31 */     this.m_currentRow = row;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossOperation
 * JD-Core Version:    0.5.4
 */