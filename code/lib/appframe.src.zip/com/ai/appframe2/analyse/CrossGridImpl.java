/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.express.Add;
/*     */ import com.ai.appframe2.express.Arith;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class CrossGridImpl
/*     */ {
/*  20 */   public static int S_AREA_SELECT = 0;
/*  21 */   public static int S_AREA_ROW = 1;
/*  22 */   public static int S_AREA_COL = 2;
/*     */ 
/*  24 */   public static int S_TYPE_TOTAL_BEFORE = 1;
/*  25 */   public static int S_TYPE_TOTAL_AFTER = 2;
/*     */   private List dimensionss;
/*     */   private Meas meass;
/*     */   private DataBlock factDatas;
/*     */   private List initalGrid;
/*     */   private CrossOperation m_operation;
/*  33 */   private String configXmlName = null;
/*  34 */   private String dataModelStr = null;
/*     */ 
/*  36 */   private long pk = -1L;
/*     */   private String m_name;
/*     */   protected InitialLock m_hasInitial;
/*     */ 
/*     */   public CrossGridImpl(String name)
/*     */   {
/*  47 */     this.m_name = name;
/*  48 */     this.m_hasInitial = new InitialLock(false);
/*  49 */     this.meass = new Meas();
/*  50 */     this.dimensionss = new ArrayList();
/*  51 */     this.initalGrid = new ArrayList();
/*  52 */     this.factDatas = new DataBlock();
/*  53 */     this.m_operation = new CrossOperation(this);
/*     */   }
/*     */ 
/*     */   public void free()
/*     */   {
/*  58 */     this.m_hasInitial.m_boolean = false;
/*  59 */     this.meass.free();
/*  60 */     this.dimensionss.clear();
/*  61 */     this.initalGrid.clear();
/*  62 */     this.factDatas.free();
/*     */   }
/*     */ 
/*     */   public int getInitialRowCount()
/*     */   {
/*  68 */     return this.initalGrid.size();
/*     */   }
/*     */ 
/*     */   public int[] getAllRows() {
/*  72 */     int[] result = new int[this.initalGrid.size()];
/*  73 */     for (int i = 0; i < result.length; ++i) {
/*  74 */       result[i] = i;
/*     */     }
/*  76 */     return result;
/*     */   }
/*     */ 
/*     */   public int findMid(int[] aArray, int aStart, int aValue) {
/*  80 */     int startPoint = aStart;
/*  81 */     int endPoint = aArray.length - 1;
/*  82 */     int mid = -1;
/*  83 */     int result = -1;
/*     */     while (true) { if (endPoint < startPoint) break label72;
/*  85 */       mid = (startPoint + endPoint) / 2;
/*  86 */       if (aArray[mid] > aValue)
/*  87 */         endPoint = mid - 1;
/*  88 */       if (aArray[mid] >= aValue) break;
/*  89 */       startPoint = mid + 1; }
/*     */ 
/*  91 */     result = mid;
/*     */ 
/*  95 */     label72: return result;
/*     */   }
/*     */   public int[] intersection(List aInArray) {
/*  98 */     int[][] aArray = (int[][])(int[][])aInArray.toArray(new int[0][]);
/*  99 */     int dimCount = aArray.length;
/* 100 */     int[] pointStartArray = new int[dimCount];
/* 101 */     int baseDim = 0;
/* 102 */     for (int i = 0; i < dimCount; ++i) {
/* 103 */       pointStartArray[i] = 0;
/* 104 */       if (aArray[i].length < aArray[baseDim].length) {
/* 105 */         baseDim = i;
/*     */       }
/*     */     }
/* 108 */     int[] tmpArray = aArray[0];
/* 109 */     aArray[0] = aArray[baseDim];
/* 110 */     aArray[baseDim] = tmpArray;
/*     */ 
/* 112 */     int[] resultArray = new int[aArray[0].length];
/*     */ 
/* 115 */     int resultPoint = 0;
/*     */ 
/* 117 */     for (int i = 0; i < aArray[0].length; ++i) {
/* 118 */       boolean hasFind = true;
/* 119 */       for (int j = 1; j < aArray.length; ++j) {
/* 120 */         int point = findMid(aArray[j], pointStartArray[j], aArray[0][i]);
/* 121 */         if (point < 0) {
/* 122 */           hasFind = false;
/*     */         }
/*     */         else {
/* 125 */           pointStartArray[j] = (point + 1);
/*     */         }
/*     */       }
/* 128 */       if (hasFind == true) {
/* 129 */         resultArray[resultPoint] = aArray[0][i];
/* 130 */         resultPoint += 1;
/*     */       }
/*     */     }
/* 133 */     int[] result = new int[resultPoint];
/* 134 */     System.arraycopy(resultArray, 0, result, 0, resultPoint);
/* 135 */     return result;
/*     */   }
/*     */ 
/*     */   public void fillData() throws Exception {
/* 139 */     computerDimRange();
/* 140 */     this.factDatas.free();
/* 141 */     for (int i = 0; i < this.initalGrid.size(); ++i) {
/* 142 */       RowData initialRow = (RowData)this.initalGrid.get(i);
/* 143 */       int logicIndex = indexOf(initialRow.getDimIndex());
/* 144 */       initialRow.setLogicIndex(logicIndex);
/* 145 */       setFactData(initialRow.getDimIndex(), initialRow.getMeasObject());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object[][] getFactData(String dimValues, String measCodes)
/*     */     throws Exception
/*     */   {
/* 158 */     String[] dimValueList = StringUtils.split(dimValues, ',');
/*     */ 
/* 161 */     String[] measList = StringUtils.split(measCodes, ',');
/* 162 */     int[] measIndexArray = new int[measList.length];
/*     */ 
/* 164 */     for (int i = 0; i < measList.length; ++i) {
/* 165 */       measIndexArray[i] = this.meass.indexOfByCode(measList[i]);
/*     */     }
/* 167 */     PivotList tmpPivotList = new PivotList();
/* 168 */     int[] dimIndexArray = new int[getDimCount()];
/*     */ 
/* 170 */     for (int i = 0; i < dimValueList.length; ++i) {
/* 171 */       String[] tmp = StringUtils.split(dimValueList[i], '=');
/* 172 */       int dimIndex = getDimIndexByCode(tmp[0]);
/* 173 */       if (!tmp[1].toString().equalsIgnoreCase("-1")) {
/* 174 */         dimIndexArray[dimIndex] = getDimension(dimIndex).getRealDimIndex(tmp[1]);
/* 175 */         tmpPivotList.addPivot(Pivot.SELECT_AREA, dimIndex, dimIndexArray[dimIndex], false, false, "asc");
/*     */       }
/*     */       else {
/* 178 */         tmpPivotList.addPivot(Pivot.ROW_AREA, dimIndex, -1, false, false, "asc");
/*     */       }
/*     */     }
/* 181 */     List rowHead = new ArrayList();
/* 182 */     List tmpRowHeadSubTotal = new ArrayList();
/*     */ 
/* 185 */     int rowHeadSize = tmpPivotList.size(Pivot.ROW_AREA);
/* 186 */     Object[][] result = (Object[][])null;
/* 187 */     if (rowHeadSize > 0) {
/* 188 */       incMcGridIndex(tmpPivotList, rowHead, null, Pivot.ROW_AREA, 0, null, tmpRowHeadSubTotal);
/*     */ 
/* 190 */       result = new Object[rowHead.size()][];
/* 191 */       for (int i = 0; i < result.length; ++i) {
/* 192 */         int[] tmpInt = (int[])(int[])rowHead.get(i);
/* 193 */         result[i] = new Object[rowHeadSize + measIndexArray.length];
/* 194 */         for (int j = 0; j < rowHeadSize; ++j) {
/* 195 */           Pivot tmpPivot = tmpPivotList.getPivot(this, Pivot.ROW_AREA, j);
/* 196 */           dimIndexArray[tmpPivot.dimIndex] = tmpInt[j];
/* 197 */           result[i][j] = getDimension(tmpPivot.dimIndex).getDesc(tmpInt[j]);
/*     */         }
/* 199 */         for (int j = 0; j < measIndexArray.length; ++j)
/* 200 */           result[i][(j + rowHeadSize)] = getFactData(dimIndexArray, measIndexArray[j]);
/*     */       }
/*     */     }
/*     */     else {
/* 204 */       result = new Object[1][];
/* 205 */       result[0] = new Object[measIndexArray.length];
/* 206 */       for (int j = 0; j < measIndexArray.length; ++j) {
/* 207 */         result[0][j] = getFactData(dimIndexArray, measIndexArray[j]);
/*     */       }
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */ 
/*     */   public Object getFactData(Object[] dimValue, String measCode)
/*     */     throws Exception
/*     */   {
/* 222 */     int[] dimIndexArray = new int[dimValue.length];
/* 223 */     for (int i = 0; i < dimIndexArray.length; ++i) {
/* 224 */       dimIndexArray[i] = getDimension(i).getRealDimIndex(dimValue);
/*     */     }
/* 226 */     int measIndex = this.meass.indexOfByCode(measCode);
/* 227 */     return getFactData(dimIndexArray, measIndex);
/*     */   }
/*     */ 
/*     */   public Object getFactData(int[] dimIndexArray, int measIndex)
/*     */     throws Exception
/*     */   {
/* 237 */     int logicIndex = indexOf(dimIndexArray);
/* 238 */     RowData tmpRowData = this.factDatas.getRow(logicIndex);
/* 239 */     int measCount = this.meass.count();
/* 240 */     int dimCount = this.dimensionss.size();
/* 241 */     int realMeasCount = this.meass.getRealMeasCount();
/* 242 */     int computerMeasCount = this.meass.getComputerMeasCount();
/* 243 */     if (tmpRowData == null) {
/* 244 */       boolean tmpIsSubTotal = isSubTotalRow(dimIndexArray);
/* 245 */       tmpRowData = new RowData(dimCount, measCount + 1);
/* 246 */       tmpRowData.setDimIndexArray(dimIndexArray);
/* 247 */       this.factDatas.addRow(logicIndex, tmpRowData);
/* 248 */       List tmpRowsArray = new ArrayList();
/* 249 */       int[] tmpRows = null;
/* 250 */       for (int i = 0; i < dimIndexArray.length; ++i) {
/* 251 */         tmpRows = getDimension(i).getRows(dimIndexArray[i]);
/* 252 */         if ((tmpRows != null) && (tmpRows.length > 0))
/* 253 */           tmpRowsArray.add(tmpRows);
/*     */       }
/* 255 */       if (tmpRowsArray.size() > 0)
/* 256 */         tmpRows = intersection(tmpRowsArray);
/*     */       else {
/* 258 */         tmpRows = getAllRows();
/*     */       }
/* 260 */       for (int i = 0; i < measCount; ++i) {
/* 261 */         tmpRowData.addMeasObject(i, AnaDataType.getNullValueString(this.meass.getDataType(i)));
/*     */       }
/*     */ 
/* 267 */       for (int i = 0; i < tmpRows.length; ++i)
/*     */       {
/* 269 */         RowData tmpRow = this.factDatas.getRow(((RowData)this.initalGrid.get(tmpRows[i])).getLogicIndex());
/* 270 */         for (int j = 0; j < realMeasCount; ++j) {
/* 271 */           if ((tmpIsSubTotal) && (!this.meass.isCanSubTotal(j)))
/*     */             continue;
/* 273 */           if (tmpRowData.getMeasObject(j) == null) {
/*     */             continue;
/*     */           }
/* 276 */           tmpRowData.addMeasObject(j, Add.execute(tmpRowData.getMeasObject(j), tmpRow.getMeasObject(j)));
/*     */         }
/*     */ 
/* 280 */         for (int j = realMeasCount; j < computerMeasCount + realMeasCount; ++j) {
/* 281 */           if ((tmpIsSubTotal != true) || (this.meass.getSubTotalType(j - realMeasCount) != Meas.SUTTOTAL_TYPE_STATIC))
/*     */             continue;
/* 283 */           if (tmpRowData.getMeasObject(j) == null) {
/*     */             continue;
/*     */           }
/* 286 */           tmpRowData.addMeasObject(j, Add.execute(tmpRowData.getMeasObject(j), tmpRow.getMeasObject(j)));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 293 */       if (computerMeasCount > 0) {
/* 294 */         computerMeas(tmpRowData);
/*     */       }
/*     */ 
/* 298 */       for (int j = 0; j < computerMeasCount + realMeasCount; ++j) {
/* 299 */         double v = 0.0D;
/*     */         try {
/* 301 */           v = Double.parseDouble(tmpRowData.getMeasObject(j).toString());
/*     */         } catch (Exception e) {
/*     */         }
/* 304 */         tmpRowData.addMeasObject(j, new Double(Arith.round(v, 6)));
/*     */       }
/*     */     }
/* 307 */     return tmpRowData.getMeasObject(measIndex);
/*     */   }
/*     */ 
/*     */   public Object getFactDataForGridInitial(int[] dimIndexArray, int measIndex) throws Exception
/*     */   {
/* 312 */     int logicIndex = indexOf(dimIndexArray);
/*     */ 
/* 314 */     RowData tmpRowData = this.factDatas.getRow(logicIndex);
/* 315 */     if (tmpRowData != null) {
/* 316 */       return tmpRowData.getMeasObject(measIndex);
/*     */     }
/* 318 */     List tmpRowsArray = new ArrayList();
/* 319 */     int[] tmpRows = null;
/* 320 */     for (int i = 0; i < dimIndexArray.length; ++i) {
/* 321 */       tmpRows = getDimension(i).getRows(dimIndexArray[i]);
/* 322 */       if ((tmpRows != null) && (tmpRows.length > 0))
/* 323 */         tmpRowsArray.add(tmpRows);
/*     */     }
/* 325 */     if (tmpRowsArray.size() > 0)
/* 326 */       tmpRows = intersection(tmpRowsArray);
/*     */     else {
/* 328 */       tmpRows = getAllRows();
/*     */     }
/* 330 */     Object result = AnaDataType.getNullValueString(this.meass.getDataType(measIndex));
/*     */ 
/* 334 */     for (int i = 0; i < tmpRows.length; ++i) {
/* 335 */       result = Add.execute(((RowData)this.initalGrid.get(tmpRows[i])).getMeasObject(measIndex), result);
/*     */     }
/*     */ 
/* 339 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isSubTotalRow(int[] aDimIndexArray)
/*     */   {
/* 344 */     for (int i = 0; i < aDimIndexArray.length; ++i) {
/* 345 */       if (aDimIndexArray[i] == getDimension(i).count())
/* 346 */         return true;
/*     */     }
/* 348 */     return false;
/*     */   }
/*     */ 
/*     */   public int indexOf(int[] dimIndex)
/*     */   {
/* 353 */     int result = 0;
/* 354 */     for (int i = 0; i < this.dimensionss.size(); ++i) {
/* 355 */       result += dimIndex[i] * getDimension(i).getRange();
/*     */     }
/* 357 */     return result;
/*     */   }
/*     */ 
/*     */   public Dimension getDimension(int index) {
/* 361 */     return (Dimension)this.dimensionss.get(index);
/*     */   }
/*     */ 
/*     */   public int getDimIndexByCode(String dimCode) throws Exception
/*     */   {
/* 366 */     if (Meas.MEAS_CODE.equalsIgnoreCase(dimCode) == true)
/* 367 */       return this.dimensionss.size();
/* 368 */     for (int i = 0; i < this.dimensionss.size(); ++i)
/* 369 */       if (getDimension(i).getCode().equalsIgnoreCase(dimCode) == true)
/* 370 */         return i;
/* 371 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getDimIndexByName(String dimName) throws Exception {
/* 375 */     if (Meas.MEAS_NAME.equalsIgnoreCase(dimName) == true)
/* 376 */       return this.dimensionss.size();
/* 377 */     for (int i = 0; i < this.dimensionss.size(); ++i) {
/* 378 */       if (getDimension(i).getName().equalsIgnoreCase(dimName) == true)
/* 379 */         return i;
/*     */     }
/* 381 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridImpl.no_dimension", new String[] { dimName });
/* 382 */     throw new Exception(msg);
/*     */   }
/*     */ 
/*     */   public void computerDimRange() {
/* 386 */     int result = 1;
/* 387 */     Dimension dim = null;
/* 388 */     for (int i = this.dimensionss.size() - 1; i >= 0; --i) {
/* 389 */       dim = getDimension(i);
/* 390 */       dim.setRange(result);
/* 391 */       result *= (dim.count() + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int incMcGridIndex()
/*     */   {
/* 397 */     return 0;
/*     */   }
/*     */   public Object group(RowData row, String dimNames, String measName) throws Exception {
/* 400 */     if (this.meass.indexOfByCode(measName) >= this.meass.getRealMeasCount())
/*     */     {
/* 402 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridImpl.groupfunction");
/* 403 */       throw new Exception(msg);
/*     */     }
/*     */ 
/* 406 */     String[] dimes = StringUtils.split(dimNames, ',');
/* 407 */     int[] dimIndexs = new int[this.dimensionss.size()];
/* 408 */     for (int i = 0; i < dimIndexs.length; ++i) {
/* 409 */       dimIndexs[i] = getDimension(i).count();
/*     */     }
/* 411 */     for (int i = 0; i < dimes.length; ++i) {
/* 412 */       for (int j = 0; j < dimIndexs.length; ++j) {
/* 413 */         if (dimes[i].equalsIgnoreCase(getDimension(j).getCode()) == true) {
/* 414 */           dimIndexs[j] = row.getDimIndex(j);
/* 415 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 419 */     return getFactDataForGridInitial(dimIndexs, this.meass.indexOfByCode(measName));
/*     */   }
/*     */ 
/*     */   public void setFactData(int[] aDimIndexArray, Object[] valueArray)
/*     */     throws Exception
/*     */   {
/* 426 */     int index = indexOf(aDimIndexArray);
/* 427 */     RowData row = this.factDatas.getRow(index);
/* 428 */     if (row == null) {
/* 429 */       row = new RowData(this.dimensionss.size(), this.meass.count() + 1);
/* 430 */       row.setLogicIndex(index);
/* 431 */       row.setDimIndexArray(aDimIndexArray);
/* 432 */       row.setMeasObjects(valueArray);
/* 433 */       this.factDatas.addRow(index, row);
/*     */     }
/*     */     else {
/* 436 */       for (int i = 0; i < this.meass.getRealMeasCount(); ++i) {
/* 437 */         row.addMeasObject(i, Add.execute(row.getMeasObject(i), valueArray[i]));
/*     */       }
/*     */     }
/*     */ 
/* 441 */     if (this.meass.getComputerMeasCount() > 0)
/* 442 */       computerMeas(row);
/*     */   }
/*     */ 
/*     */   public void computerMeas(RowData aRow) throws Exception
/*     */   {
/* 447 */     int realMeasCount = this.meass.getRealMeasCount();
/* 448 */     int computerMeasCount = this.meass.getComputerMeasCount();
/*     */ 
/* 450 */     if (computerMeasCount <= 0) {
/* 451 */       return;
/*     */     }
/* 453 */     for (int i = 0; i < computerMeasCount; ++i)
/*     */       try {
/* 455 */         if ((!isSubTotalRow(aRow.getDimIndex())) || (this.meass.getSubTotalType(i) == Meas.SUTTOTAL_TYPE_DYNAMIC))
/*     */         {
/* 457 */           this.m_operation.setCurrentRowData(aRow);
/*     */ 
/* 459 */           Object obj = this.m_operation.executeByCResult(this.meass.getFormualAfterParse(i));
/* 460 */           aRow.addMeasObject(realMeasCount + i, obj);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 464 */         e.printStackTrace();
/*     */       }
/*     */   }
/*     */ 
/*     */   public int refresh()
/*     */   {
/* 513 */     return 0;
/*     */   }
/*     */ 
/*     */   public int getDimCount() {
/* 517 */     return this.dimensionss.size();
/*     */   }
/*     */ 
/*     */   public boolean addDimension(String aServerDimId, String name, String code, String dataType)
/*     */   {
/* 522 */     Dimension dim = new Dimension(aServerDimId, name, code, new String[] { name }, 0, new String[] { dataType });
/*     */ 
/* 524 */     this.dimensionss.add(dim);
/* 525 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean addMeas(String aDataID, String aName, String aCode, String aDataType, boolean aCanSubTotal)
/*     */   {
/* 530 */     this.meass.addMember(aDataID, aName, aCode, aDataType, aCanSubTotal);
/* 531 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean addComputerMeas(String aDataID, String aName, String aCode, String formual, String aDataType, boolean aCanSubTotal, int aSubTotalType)
/*     */     throws Exception
/*     */   {
/* 537 */     this.meass.addComputerMeas(this.m_operation, aDataID, aName, aCode, formual, aDataType, aCanSubTotal, aSubTotalType);
/*     */ 
/* 539 */     return true;
/*     */   }
/*     */ 
/*     */   public int addRow()
/*     */   {
/* 544 */     this.initalGrid.add(new RowData(this.dimensionss.size(), this.meass.count()));
/* 545 */     return this.initalGrid.size() - 1;
/*     */   }
/*     */ 
/*     */   public boolean addRowItem(int rowIndex, int colIndex, Object value) throws Exception
/*     */   {
/* 550 */     RowData row = (RowData)this.initalGrid.get(rowIndex);
/* 551 */     if (colIndex < getDimCount()) {
/* 552 */       row.addDimIndex(colIndex, getDimension(colIndex).addMember(new Object[] { value }, rowIndex, "-1"));
/*     */     }
/*     */     else
/*     */     {
/* 556 */       row.addMeasObject(colIndex - getDimCount(), AnaDataType.transfer(value, this.meass.getDataType(colIndex - getDimCount())));
/*     */     }
/*     */ 
/* 561 */     return true;
/*     */   }
/*     */   public DimensionOrMeas getDimOrMeasByIndex(int index) {
/* 564 */     if ((index >= 0) && (index < this.dimensionss.size())) {
/* 565 */       return getDimension(index);
/*     */     }
/* 567 */     return this.meass;
/*     */   }
/*     */ 
/*     */   public String toInitialDataString() {
/* 571 */     StringBuilder buffer = new StringBuilder();
/* 572 */     Dimension[] dimes = (Dimension[])(Dimension[])this.dimensionss.toArray(new Dimension[0]);
/* 573 */     for (int i = 0; i < this.initalGrid.size(); ++i) {
/* 574 */       RowData row = (RowData)this.initalGrid.get(i);
/* 575 */       if (i > 0)
/* 576 */         buffer.append("\n");
/* 577 */       buffer.append(row.toString(dimes));
/*     */     }
/* 579 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public void incIndex(int[] aIndexRec, int aDimIdx)
/*     */   {
/* 588 */     if ((aIndexRec[aDimIdx] >= 0) && (aIndexRec[aDimIdx] < getDimension(aDimIdx).count() - 1)) {
/* 589 */       aIndexRec[aDimIdx] += 1;
/* 590 */     } else if (aIndexRec[aDimIdx] == getDimension(aDimIdx).count() - 1) {
/* 591 */       aIndexRec[aDimIdx] = getDimension(aDimIdx).count();
/*     */     } else {
/* 593 */       aIndexRec[aDimIdx] = 0;
/* 594 */       if (aDimIdx > 0)
/* 595 */         incIndex(aIndexRec, aDimIdx - 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void incMcGridIndex(PivotList aPivots, List Inarray, int[] indexRec, int area, int areaIndex, int[] rows, List subTotalArray) throws Exception
/*     */   {
/* 601 */     Pivot pivot = aPivots.getPivot(this, area, areaIndex);
/* 602 */     DimensionOrMeas obj = getDimOrMeasByIndex(pivot.dimIndex);
/* 603 */     boolean hasData = false;
/* 604 */     int[] TmpIndexRec = null;
/* 605 */     List rowsArray = new ArrayList();
/* 606 */     for (int i = 0; i < obj.count(); ++i) {
/* 607 */       TmpIndexRec = new int[aPivots.size(area)];
/* 608 */       if (indexRec != null) {
/* 609 */         System.arraycopy(indexRec, 0, TmpIndexRec, 0, indexRec.length);
/*     */       }
/* 611 */       TmpIndexRec[areaIndex] = obj.getRealDimIndex(i, pivot.sortType);
/*     */ 
/* 613 */       int[] tmpRows = null;
/*     */ 
/* 616 */       rowsArray.clear();
/* 617 */       if ((rows != null) && (rows.length > 0))
/* 618 */         rowsArray.add(rows);
/* 619 */       int[] t = obj.getRows(TmpIndexRec[areaIndex]);
/* 620 */       if ((t != null) && (t.length > 0)) {
/* 621 */         rowsArray.add(t);
/*     */       }
/* 623 */       if (rowsArray.size() > 0) {
/* 624 */         tmpRows = intersection(rowsArray);
/* 625 */         if (tmpRows.length == 0) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 631 */       if (areaIndex == aPivots.size(area) - 1) {
/* 632 */         Inarray.add(TmpIndexRec);
/* 633 */         subTotalArray.add(new Boolean(false));
/*     */       } else {
/* 635 */         incMcGridIndex(aPivots, Inarray, TmpIndexRec, area, areaIndex + 1, tmpRows, subTotalArray);
/* 636 */         TmpIndexRec = null;
/*     */       }
/* 638 */       hasData = true;
/*     */     }
/*     */ 
/* 641 */     if ((hasData == true) && (pivot.isSubTotal == true)) {
/* 642 */       TmpIndexRec = new int[aPivots.size(area)];
/* 643 */       if (indexRec != null) {
/* 644 */         System.arraycopy(indexRec, 0, TmpIndexRec, 0, indexRec.length);
/*     */       }
/* 646 */       for (int i = areaIndex; i < aPivots.size(area); ++i) {
/* 647 */         Pivot p = aPivots.getPivot(this, area, i);
/* 648 */         TmpIndexRec[i] = getDimOrMeasByIndex(p.dimIndex).count();
/*     */       }
/*     */ 
/* 651 */       Inarray.add(TmpIndexRec);
/* 652 */       subTotalArray.add(new Boolean(true));
/*     */     }
/*     */   }
/*     */ 
/*     */   public int incMcGridIndexTreeNode(PivotList aPivots, List treeNodeList, int[] indexRec, int area, int areaIndex, int[] rows, List subTotalArray)
/*     */     throws Exception
/*     */   {
/* 659 */     Pivot pivot = aPivots.getPivot(this, area, areaIndex);
/* 660 */     DimensionOrMeas obj = getDimOrMeasByIndex(pivot.dimIndex);
/* 661 */     boolean hasData = false;
/* 662 */     int[] TmpIndexRec = null;
/* 663 */     int result = 0;
/* 664 */     List rowsArray = new ArrayList();
/* 665 */     int startIndex = treeNodeList.size();
/* 666 */     for (int i = 0; i < obj.count(); ++i) {
/* 667 */       TmpIndexRec = new int[aPivots.size(area)];
/* 668 */       if (indexRec != null) {
/* 669 */         System.arraycopy(indexRec, 0, TmpIndexRec, 0, indexRec.length);
/*     */       }
/* 671 */       TmpIndexRec[areaIndex] = obj.getRealDimIndex(i, pivot.sortType);
/*     */ 
/* 673 */       int[] tmpRows = null;
/*     */ 
/* 676 */       rowsArray.clear();
/* 677 */       if ((rows != null) && (rows.length > 0))
/* 678 */         rowsArray.add(rows);
/* 679 */       int[] t = obj.getRows(TmpIndexRec[areaIndex]);
/* 680 */       if ((t != null) && (t.length > 0)) {
/* 681 */         rowsArray.add(t);
/*     */       }
/* 683 */       if (rowsArray.size() > 0) {
/* 684 */         tmpRows = intersection(rowsArray);
/* 685 */         if (tmpRows.length == 0) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 691 */       if (areaIndex == aPivots.size(area) - 1) {
/* 692 */         CrossGridNode tmpNode = new CrossGridNode(pivot.dimIndex, TmpIndexRec[areaIndex]);
/* 693 */         tmpNode.setRange(1);
/* 694 */         treeNodeList.add(tmpNode);
/* 695 */         result += 1;
/* 696 */         subTotalArray.add(new Boolean(false));
/*     */       } else {
/* 698 */         List tmpNodeList = new ArrayList();
/* 699 */         int tmpRange = incMcGridIndexTreeNode(aPivots, tmpNodeList, TmpIndexRec, area, areaIndex + 1, tmpRows, subTotalArray);
/* 700 */         if (tmpNodeList.size() > 0) {
/* 701 */           CrossGridNode tmpNode = new CrossGridNode(pivot.dimIndex, TmpIndexRec[areaIndex]);
/* 702 */           tmpNode.setRange(tmpRange);
/* 703 */           for (int m = 0; m < tmpNodeList.size(); ++m)
/* 704 */             ((CrossGridNode)tmpNodeList.get(m)).setParent(tmpNode);
/* 705 */           tmpNode.setChilds(tmpNodeList);
/* 706 */           treeNodeList.add(tmpNode);
/* 707 */           result += tmpRange;
/*     */         }
/* 709 */         tmpNodeList = null;
/*     */       }
/* 711 */       TmpIndexRec = null;
/* 712 */       hasData = true;
/*     */     }
/*     */ 
/* 715 */     CrossGridNode tmpNodeP = null;
/* 716 */     if ((hasData == true) && (pivot.isSubTotal == true)) {
/* 717 */       for (int i = areaIndex; i < aPivots.size(area); ++i) {
/* 718 */         Pivot p = aPivots.getPivot(this, area, i);
/* 719 */         CrossGridNode tmpNode = new CrossGridNode(p.dimIndex, getDimOrMeasByIndex(aPivots.getPivot(this, area, i).dimIndex).count());
/*     */ 
/* 721 */         tmpNode.setRange(1);
/* 722 */         if (i == areaIndex) {
/* 723 */           if (p.subTotalPosition == S_TYPE_TOTAL_AFTER)
/* 724 */             treeNodeList.add(tmpNode);
/*     */           else {
/* 726 */             treeNodeList.add(startIndex, tmpNode);
/*     */           }
/* 728 */           tmpNodeP = tmpNode;
/*     */         }
/*     */         else {
/* 731 */           tmpNodeP.addChild(tmpNode);
/* 732 */           tmpNode.setParent(tmpNodeP);
/* 733 */           tmpNodeP = tmpNode;
/*     */         }
/*     */       }
/* 736 */       if (pivot.subTotalPosition == S_TYPE_TOTAL_AFTER)
/* 737 */         subTotalArray.add(new Boolean(true));
/*     */       else {
/* 739 */         subTotalArray.add(startIndex, new Boolean(true));
/*     */       }
/* 741 */       result += 1;
/*     */     }
/* 743 */     return result;
/*     */   }
/*     */ 
/*     */   public Meas getMeas()
/*     */   {
/* 748 */     return this.meass;
/*     */   }
/*     */ 
/*     */   public void incMcGridRowIndex(PivotList aPivots, List Inarray, int[] indexRec, int areaIndex, int[] rows, List subTotalArray)
/*     */     throws Exception
/*     */   {
/* 754 */     Pivot pivot = aPivots.getPivot(this, Pivot.ROW_AREA, areaIndex);
/* 755 */     DimensionOrMeas obj = getDimOrMeasByIndex(pivot.dimIndex);
/* 756 */     boolean hasData = false;
/* 757 */     int[] TmpIndexRec = null;
/*     */ 
/* 761 */     int subTotalIndex = -1;
/* 762 */     TmpIndexRec = new int[aPivots.size(Pivot.ROW_AREA)];
/* 763 */     if (indexRec != null) {
/* 764 */       System.arraycopy(indexRec, 0, TmpIndexRec, 0, indexRec.length);
/*     */     }
/* 766 */     for (int i = areaIndex; i < aPivots.size(Pivot.ROW_AREA); ++i) {
/* 767 */       Pivot p = aPivots.getPivot(this, Pivot.ROW_AREA, i);
/* 768 */       TmpIndexRec[i] = getDimOrMeasByIndex(p.dimIndex).count();
/*     */     }
/* 770 */     Inarray.add(TmpIndexRec);
/* 771 */     subTotalIndex = Inarray.size() - 1;
/* 772 */     subTotalArray.add(new Boolean(true));
/*     */ 
/* 779 */     List rowsArray = new ArrayList();
/*     */ 
/* 781 */     for (int i = 0; i < obj.count(); ++i) {
/* 782 */       TmpIndexRec = new int[aPivots.size(Pivot.ROW_AREA)];
/* 783 */       if (indexRec != null) {
/* 784 */         System.arraycopy(indexRec, 0, TmpIndexRec, 0, indexRec.length);
/*     */       }
/* 786 */       TmpIndexRec[areaIndex] = obj.getRealDimIndex(i, pivot.sortType);
/*     */ 
/* 788 */       int[] tmpRows = null;
/*     */ 
/* 791 */       rowsArray.clear();
/* 792 */       if ((rows != null) && (rows.length > 0))
/* 793 */         rowsArray.add(rows);
/* 794 */       int[] t = obj.getRows(TmpIndexRec[areaIndex]);
/* 795 */       if ((t != null) && (t.length > 0)) {
/* 796 */         rowsArray.add(t);
/*     */       }
/* 798 */       if (rowsArray.size() > 0) {
/* 799 */         tmpRows = intersection(rowsArray);
/* 800 */         if (tmpRows.length == 0) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 806 */       if (areaIndex == aPivots.size(Pivot.ROW_AREA) - 1)
/*     */       {
/* 809 */         Inarray.add(TmpIndexRec);
/* 810 */         subTotalArray.add(new Boolean(false));
/*     */       } else {
/* 812 */         incMcGridRowIndex(aPivots, Inarray, TmpIndexRec, areaIndex + 1, tmpRows, subTotalArray);
/* 813 */         TmpIndexRec = null;
/*     */       }
/* 815 */       hasData = true;
/*     */     }
/*     */ 
/* 818 */     if ((!hasData) && (subTotalIndex >= 0)) {
/* 819 */       Inarray.remove(subTotalIndex);
/* 820 */       subTotalArray.remove(subTotalIndex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public long getPk()
/*     */   {
/* 872 */     return this.pk;
/*     */   }
/*     */ 
/*     */   public void setPk(long pk) {
/* 876 */     this.pk = pk;
/*     */   }
/*     */   public String getConfigXmlName() {
/* 879 */     return this.configXmlName;
/*     */   }
/*     */   public void setConfigXmlName(String configXmlName) {
/* 882 */     this.configXmlName = configXmlName;
/*     */   }
/*     */   public String getDataModelStr() {
/* 885 */     return this.dataModelStr;
/*     */   }
/*     */   public void setDataModelStr(String dataModelStr) {
/* 888 */     this.dataModelStr = dataModelStr;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridImpl
 * JD-Core Version:    0.5.4
 */