/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ public class Pivot
/*    */ {
/* 15 */   public static int SELECT_AREA = 0;
/* 16 */   public static int ROW_AREA = 1;
/* 17 */   public static int COL_AREA = 2;
/* 18 */   public static String MEASS = "meass";
/*    */ 
/* 21 */   public int dimIndex = -1;
/*    */ 
/* 23 */   public String dimCode = "";
/*    */   public boolean isMeas;
/* 27 */   public int selectValueIndex = 0;
/*    */ 
/* 29 */   public String selectValue = null;
/*    */   public boolean isSubTotal;
/* 32 */   public int subTotalPosition = CrossGridImpl.S_TYPE_TOTAL_AFTER;
/*    */   public int sortType;
/*    */   public boolean IsSuppressRepeat;
/*    */   public int range;
/*    */ 
/*    */   public Pivot(int aDimIndex, boolean isMeas, int aValueIndex, boolean aIsSubTotal, int ASortType, boolean aIsSuppressRepeat)
/*    */   {
/* 39 */     this.dimIndex = aDimIndex;
/*    */ 
/* 41 */     this.isMeas = isMeas;
/* 42 */     this.selectValueIndex = aValueIndex;
/* 43 */     this.isSubTotal = aIsSubTotal;
/* 44 */     this.sortType = ASortType;
/* 45 */     this.IsSuppressRepeat = aIsSuppressRepeat;
/* 46 */     this.range = 1;
/*    */   }
/*    */ 
/*    */   public Pivot(int aDimIndex, String aCode, boolean isMeas, int aValueIndex, boolean aIsSubTotal, int ASortType, boolean aIsSuppressRepeat)
/*    */   {
/* 51 */     this.dimIndex = aDimIndex;
/* 52 */     this.dimCode = aCode;
/* 53 */     this.isMeas = isMeas;
/* 54 */     this.selectValueIndex = aValueIndex;
/* 55 */     this.isSubTotal = aIsSubTotal;
/* 56 */     this.sortType = ASortType;
/* 57 */     this.IsSuppressRepeat = aIsSuppressRepeat;
/* 58 */     this.range = 1;
/*    */   }
/*    */ 
/*    */   public Pivot(int aDimIndex, String aCode, boolean isMeas, String aSelectValue, boolean aIsSubTotal, int ASortType, boolean aIsSuppressRepeat)
/*    */   {
/* 64 */     this.dimIndex = aDimIndex;
/* 65 */     this.dimCode = aCode;
/* 66 */     this.isMeas = isMeas;
/* 67 */     this.selectValue = aSelectValue;
/* 68 */     this.selectValueIndex = -1;
/* 69 */     this.isSubTotal = aIsSubTotal;
/* 70 */     this.sortType = ASortType;
/* 71 */     this.IsSuppressRepeat = aIsSuppressRepeat;
/* 72 */     this.range = 1;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 77 */     return Integer.toString(this.dimIndex) + ':' + Integer.toString(this.selectValueIndex) + ':' + new Boolean(this.isSubTotal).toString();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/*    */   }
/*    */ 
/*    */   public String getSelectValue() {
/* 84 */     return this.selectValue;
/*    */   }
/*    */   public void setSelectValue(String selectValue) {
/* 87 */     this.selectValue = selectValue;
/*    */   }
/*    */   public int getSelectValueIndex() {
/* 90 */     return this.selectValueIndex;
/*    */   }
/*    */   public void setSelectValueIndex(int selectValueIndex) {
/* 93 */     this.selectValueIndex = selectValueIndex;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.Pivot
 * JD-Core Version:    0.5.4
 */