/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.RemoteDataStore;
/*    */ import com.ai.appframe2.common.SessionManager;
/*    */ import com.ai.appframe2.web.HttpUtil;
/*    */ import javax.servlet.ServletRequest;
/*    */ 
/*    */ public class DemoCrossGridDatamodelImpl
/*    */   implements CrossGridDataModelInterface
/*    */ {
/*    */   public void init(String name, ServletRequest request)
/*    */     throws Exception
/*    */   {
/* 25 */     String action = HttpUtil.getParameter(request, "oper");
/*    */     String a;
/*    */     String a;
/* 27 */     if (action.equals("init"))
/*    */     {
/* 29 */       a = HttpUtil.getParameter(request, "a");
/*    */     }
/*    */     else {
/* 32 */       if (!action.equals("refresh"))
/*    */         return;
/* 34 */       a = HttpUtil.getParameter(request, "a");
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object getGridData()
/*    */     throws Exception
/*    */   {
/* 44 */     String sql = "select bmh,to_char(rq,'yyyy') as year, to_char(rq,'mm') as month ,substr(spbh,0,3) as spbh, sum(sl) as sl,100 as dj from order_qh where bmh='0106'group by bmh,substr(spbh,0,3),to_char(rq,'yyyy') , to_char(rq,'mm')";
/*    */ 
/* 48 */     DataContainerInterface[] ret = null;
/*    */     try
/*    */     {
/* 51 */       ret = SessionManager.getRemoteDataStore().retrieve(sql, null);
/*    */ 
/* 60 */       return ret; } finally {  }
/* 60 */     return ret;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.DemoCrossGridDatamodelImpl
 * JD-Core Version:    0.5.4
 */