/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.SimpleDateFormat;
/*     */ 
/*     */ public class AnaDataType
/*     */ {
/*     */   public static final String DATATYPE_STRING = "String";
/*     */   public static final String DATATYPE_SHORT = "Short";
/*     */   public static final String DATATYPE_INTEGER = "Integer";
/*     */   public static final String DATATYPE_LONG = "Long";
/*     */   public static final String DATATYPE_DOUBLE = "Double";
/*     */   public static final String DATATYPE_FLOAT = "Float";
/*     */   public static final String DATATYPE_BYTE = "Byte";
/*     */   public static final String DATATYPE_CHAR = "Char";
/*     */   public static final String DATATYPE_BOOLEAN = "Boolean";
/*     */   public static final String DATATYPE_DATE = "Date";
/*     */   public static final String DATATYPE_TIME = "Time";
/*     */   public static final String DATATYPE_DATETIME = "DateTime";
/*     */   public static final String DATATYPE_OBJECT = "Object";
/*     */ 
/*     */   public static Object transfer(Object value, String type)
/*     */     throws Exception
/*     */   {
/*  24 */     if (value == null) return null;
/*  25 */     if ((value instanceof String) && (value.toString().trim().equals(""))) {
/*  26 */       if ("String".equalsIgnoreCase(type)) {
/*  27 */         return value;
/*     */       }
/*  29 */       return null;
/*     */     }
/*     */ 
/*  32 */     if (type.equalsIgnoreCase("Short")) {
/*  33 */       if (value instanceof Short) {
/*  34 */         return value;
/*     */       }
/*  36 */       return new Short(new BigDecimal(value.toString()).shortValue());
/*  37 */     }if (type.equalsIgnoreCase("Integer")) {
/*  38 */       if (value instanceof Integer) {
/*  39 */         return value;
/*     */       }
/*  41 */       return new Integer(new BigDecimal(value.toString()).intValue());
/*  42 */     }if (type.equalsIgnoreCase("Char")) {
/*  43 */       if (value instanceof Character) {
/*  44 */         return value;
/*     */       }
/*  46 */       return new Character(value.toString().charAt(0));
/*  47 */     }if (type.equalsIgnoreCase("Long")) {
/*  48 */       if (value instanceof Long) {
/*  49 */         return value;
/*     */       }
/*  51 */       return new Long(new BigDecimal(value.toString()).longValue());
/*  52 */     }if (type.equalsIgnoreCase("String")) {
/*  53 */       if (value instanceof String) {
/*  54 */         return value;
/*     */       }
/*  56 */       return value.toString();
/*  57 */     }if (type.equalsIgnoreCase("Date")) {
/*  58 */       if (value instanceof java.sql.Date)
/*  59 */         return value;
/*  60 */       if (value instanceof Timestamp)
/*  61 */         return new java.sql.Date(((Timestamp)value).getTime());
/*     */       try
/*     */       {
/*  64 */         SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
/*  65 */         return new java.sql.Date(a.parse(value.toString()).getTime());
/*     */       }
/*     */       catch (Exception e) {
/*  68 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Date" });
/*     */ 
/*  70 */         throw new Exception(msg);
/*     */       }
/*     */     }
/*  73 */     if (type.equalsIgnoreCase("Time")) {
/*  74 */       if (value instanceof Time)
/*  75 */         return value;
/*  76 */       if (value instanceof Timestamp)
/*  77 */         return new Time(((Timestamp)value).getTime());
/*     */       try
/*     */       {
/*  80 */         SimpleDateFormat a = new SimpleDateFormat("HH:mm:ss");
/*  81 */         return new Time(a.parse(value.toString()).getTime());
/*     */       }
/*     */       catch (Exception e) {
/*  84 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Date" });
/*     */ 
/*  86 */         throw new Exception(msg);
/*     */       }
/*     */     }
/*  89 */     if (type.equalsIgnoreCase("DateTime")) {
/*  90 */       if (value instanceof java.sql.Date)
/*  91 */         return value;
/*  92 */       if (value instanceof Timestamp)
/*  93 */         return new java.sql.Date(((Timestamp)value).getTime());
/*     */       try
/*     */       {
/*  96 */         SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  97 */         String tmpstr = value.toString();
/*  98 */         if (tmpstr.trim().length() <= 10)
/*  99 */           tmpstr = tmpstr + " 00:00:00";
/* 100 */         return new java.sql.Date(a.parse(tmpstr).getTime());
/*     */       }
/*     */       catch (Exception e) {
/* 103 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "DateTime" });
/*     */ 
/* 105 */         throw new Exception(msg);
/*     */       }
/*     */     }
/* 108 */     if (type.equalsIgnoreCase("Double")) {
/* 109 */       if (value instanceof Double) {
/* 110 */         return value;
/*     */       }
/* 112 */       return new Double(new BigDecimal(value.toString()).doubleValue());
/* 113 */     }if (type.equalsIgnoreCase("Float")) {
/* 114 */       if (value instanceof Float) {
/* 115 */         return value;
/*     */       }
/* 117 */       return new Float(new BigDecimal(value.toString()).floatValue());
/* 118 */     }if (type.equalsIgnoreCase("Byte")) {
/* 119 */       if (value instanceof Byte) {
/* 120 */         return value;
/*     */       }
/* 122 */       return new Byte(new BigDecimal(value.toString()).byteValue());
/* 123 */     }if (type.equalsIgnoreCase("Boolean")) {
/* 124 */       if (value instanceof Boolean)
/* 125 */         return value;
/* 126 */       if (value instanceof Number) {
/* 127 */         if (((Number)value).doubleValue() > 0.0D) {
/* 128 */           return new Boolean(true);
/*     */         }
/* 130 */         return new Boolean(false);
/* 131 */       }if (value instanceof String) {
/* 132 */         if ((((String)value).equalsIgnoreCase("true")) || (((String)value).equalsIgnoreCase("y"))) {
/* 133 */           return new Boolean(true);
/*     */         }
/* 135 */         return new Boolean(false);
/*     */       }
/*     */ 
/* 138 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Boolean" });
/*     */ 
/* 140 */       throw new Exception(msg);
/*     */     }
/*     */ 
/* 143 */     return value;
/*     */   }
/*     */ 
/*     */   public static Object getNullValueString(String type) throws Exception
/*     */   {
/* 148 */     if (type.equalsIgnoreCase("String")) return "";
/* 149 */     if (type.equalsIgnoreCase("Short")) return new Short(0);
/* 150 */     if (type.equalsIgnoreCase("Integer")) return new Integer(0);
/* 151 */     if (type.equalsIgnoreCase("Long")) return new Long(0L);
/* 152 */     if (type.equalsIgnoreCase("Double")) return new Double(0.0D);
/* 153 */     if (type.equalsIgnoreCase("Float")) return new Float(0.0F);
/* 154 */     if (type.equalsIgnoreCase("Byte")) return "((byte)0)";
/* 155 */     if (type.equalsIgnoreCase("Char")) return "((char)0)";
/* 156 */     if (type.equalsIgnoreCase("Boolean")) return Boolean.FALSE;
/* 157 */     if (type.equalsIgnoreCase("Date")) return null;
/* 158 */     if (type.equalsIgnoreCase("Time")) return null;
/* 159 */     if (type.equalsIgnoreCase("DateTime")) return null;
/* 160 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.AnaDataType
 * JD-Core Version:    0.5.4
 */