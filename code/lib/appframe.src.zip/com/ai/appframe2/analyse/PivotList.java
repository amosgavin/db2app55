/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class PivotList
/*     */ {
/*     */   public List[] pivots;
/*     */   private CrossGridImpl m_crossGrid;
/*     */ 
/*     */   public PivotList()
/*     */   {
/*  20 */     this.pivots = new List[3];
/*  21 */     this.pivots[0] = new ArrayList();
/*  22 */     this.pivots[1] = new ArrayList();
/*  23 */     this.pivots[2] = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void free()
/*     */   {
/*  29 */     this.pivots[0].clear();
/*  30 */     this.pivots[1].clear();
/*  31 */     this.pivots[2].clear();
/*     */   }
/*     */   public int size(int aArea) {
/*  34 */     return this.pivots[aArea].size();
/*     */   }
/*     */ 
/*     */   public Pivot getPivot(CrossGridImpl aCrossGrid, int aArea, int index) throws Exception
/*     */   {
/*  39 */     Pivot pivot = (Pivot)this.pivots[aArea].get(index);
/*  40 */     if (pivot.dimIndex == -1) {
/*  41 */       pivot.dimIndex = aCrossGrid.getDimIndexByCode(pivot.dimCode);
/*  42 */       if (pivot.dimIndex == aCrossGrid.getDimCount())
/*     */       {
/*  44 */         pivot.isMeas = true;
/*     */       }
/*     */     }
/*     */ 
/*  48 */     if ((aArea == Pivot.SELECT_AREA) && (pivot.getSelectValueIndex() == -1))
/*     */     {
/*  50 */       if (StringUtils.isBlank(pivot.getSelectValue()) == true)
/*     */       {
/*  52 */         pivot.setSelectValueIndex(0);
/*     */       }
/*     */       else {
/*  55 */         DimensionOrMeas dim = aCrossGrid.getDimOrMeasByIndex(pivot.dimIndex);
/*  56 */         int dimDataCount = dim.count();
/*  57 */         if (pivot.isSubTotal == true) {
/*  58 */           dimDataCount += 1;
/*     */         }
/*     */ 
/*  61 */         for (int j = 0; j < dimDataCount; ++j) {
/*  62 */           if ((dim.getDesc(j) == null) || (!dim.getDesc(j).equals(pivot.getSelectValue())))
/*     */             continue;
/*  64 */           pivot.setSelectValueIndex(j);
/*  65 */           break;
/*     */         }
/*     */ 
/*  69 */         if (pivot.getSelectValueIndex() == -1) {
/*  70 */           pivot.setSelectValueIndex(dim.getRealDimIndex(0, pivot.sortType));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  78 */     return pivot;
/*     */   }
/*     */ 
/*     */   public void addPivot(int area, int dimIndex, int selectValueIndex, boolean isSubTotal, boolean aIsSuppressRepeat, String aOrderType)
/*     */   {
/*  87 */     boolean isMeas = false;
/*     */ 
/*  92 */     int orderType = 0;
/*     */ 
/*  94 */     if ("asc".equalsIgnoreCase(aOrderType) == true)
/*  95 */       orderType = 1;
/*  96 */     else if ("desc".equalsIgnoreCase(aOrderType) == true)
/*  97 */       orderType = -1;
/*     */     else {
/*  99 */       orderType = 0;
/*     */     }
/* 101 */     Pivot pivot = new Pivot(dimIndex, isMeas, selectValueIndex, isSubTotal, orderType, aIsSuppressRepeat);
/* 102 */     this.pivots[area].add(pivot);
/*     */   }
/*     */ 
/*     */   public void addPivot(int area, int dimIndex, String code, int selectValueIndex, boolean isSubTotal, boolean aIsSuppressRepeat, String aOrderType)
/*     */     throws Exception
/*     */   {
/* 108 */     boolean isMeas = false;
/* 109 */     if (code.equalsIgnoreCase(Meas.MEAS_CODE))
/*     */     {
/* 111 */       isMeas = true;
/*     */     }
/* 113 */     int orderType = 0;
/*     */ 
/* 115 */     if ("asc".equalsIgnoreCase(aOrderType) == true)
/* 116 */       orderType = 1;
/* 117 */     else if ("desc".equalsIgnoreCase(aOrderType) == true)
/* 118 */       orderType = -1;
/*     */     else {
/* 120 */       orderType = 0;
/*     */     }
/* 122 */     Pivot pivot = new Pivot(dimIndex, code, isMeas, selectValueIndex, isSubTotal, orderType, aIsSuppressRepeat);
/* 123 */     this.pivots[area].add(pivot);
/*     */   }
/*     */ 
/*     */   public void addPivot(int area, int dimIndex, String code, String selectValue, boolean isSubTotal, boolean aIsSuppressRepeat, String aOrderType)
/*     */     throws Exception
/*     */   {
/* 129 */     boolean isMeas = false;
/* 130 */     if (code.equalsIgnoreCase(Meas.MEAS_CODE))
/*     */     {
/* 132 */       isMeas = true;
/*     */     }
/* 134 */     int orderType = 0;
/*     */ 
/* 136 */     if ("asc".equalsIgnoreCase(aOrderType) == true)
/* 137 */       orderType = 1;
/* 138 */     else if ("desc".equalsIgnoreCase(aOrderType) == true)
/* 139 */       orderType = -1;
/*     */     else {
/* 141 */       orderType = 0;
/*     */     }
/* 143 */     Pivot pivot = new Pivot(dimIndex, code, isMeas, selectValue, isSubTotal, orderType, aIsSuppressRepeat);
/* 144 */     this.pivots[area].add(pivot);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.PivotList
 * JD-Core Version:    0.5.4
 */