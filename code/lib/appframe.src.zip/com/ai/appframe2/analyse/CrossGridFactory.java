/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.analyse.xml.ComputerMeas;
/*     */ import com.ai.appframe2.analyse.xml.ComputerMeass;
/*     */ import com.ai.appframe2.analyse.xml.CrossGridDefine;
/*     */ import com.ai.appframe2.analyse.xml.Dimensions;
/*     */ import com.ai.appframe2.analyse.xml.Meass;
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public abstract class CrossGridFactory
/*     */ {
/*     */   public static CrossGridFactory m_factory;
/*     */   public static final String S_FACTORY_CLASS = "CrossGridFactory";
/*  23 */   public static Map m_gridDefaineList = new HashMap();
/*  24 */   public static long m_pk_seq = 1L;
/*     */ 
/*     */   public final synchronized long getNewPk() throws Exception {
/*  27 */     m_pk_seq += 1L;
/*  28 */     return m_pk_seq;
/*     */   }
/*     */   public static CrossGridFactory getCrossGridFactory() throws Exception {
/*  31 */     if (m_factory == null) {
/*  32 */       String factoryClassName = AIConfigManager.getConfigItem("CrossGridFactory");
/*  33 */       if (StringUtils.isBlank(factoryClassName))
/*  34 */         factoryClassName = "com.ai.appframe2.analyse.CrossGridFactoryDefault";
/*  35 */       m_factory = (CrossGridFactory)Class.forName(factoryClassName).newInstance();
/*     */     }
/*  37 */     return m_factory;
/*     */   }
/*     */ 
/*     */   public abstract CrossGridImpl getInstance(String paramString1, String paramString2, boolean paramBoolean, HttpServletRequest paramHttpServletRequest)
/*     */     throws Exception;
/*     */ 
/*     */   public abstract CrossGridImpl getInstance(long paramLong)
/*     */     throws Exception;
/*     */ 
/*     */   protected void initCrossGridData(String name, CrossGridImpl cross, String dataModelStr, ServletRequest req)
/*     */     throws Exception
/*     */   {
/*  50 */     CrossGridDefine tmpGridDefine = getCrossGridDefine(name);
/*  51 */     getCrossGridImpl(cross, tmpGridDefine);
/*     */ 
/*  53 */     Object data = null;
/*  54 */     long s = System.currentTimeMillis();
/*  55 */     CrossGridDataModelInterface m_model = (CrossGridDataModelInterface)Class.forName(dataModelStr).newInstance();
/*     */ 
/*  57 */     m_model.init(name, req);
/*  58 */     data = m_model.getGridData();
/*  59 */     System.out.println("Data Query: " + (System.currentTimeMillis() - s));
/*  60 */     initialData(cross, data);
/*  61 */     cross.fillData();
/*     */   }
/*     */ 
/*     */   protected static CrossGridDefine getCrossGridDefine(String name)
/*     */   {
/*  67 */     CrossGridDefine result = (CrossGridDefine)m_gridDefaineList.get(name);
/*  68 */     if (result == null) {
/*  69 */       name = name.replace('.', '/') + ".xml";
/*  70 */       InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(name);
/*     */ 
/*  72 */       result = CrossGridDefine.unmarshal(in);
/*     */     }
/*     */ 
/*  75 */     return result;
/*     */   }
/*     */ 
/*     */   protected static void getCrossGridImpl(CrossGridImpl aGridImpl, CrossGridDefine aGridDefine) throws Exception {
/*  79 */     Dimensions dims = aGridDefine.getDimensions();
/*  80 */     for (int i = 0; i < dims.getDimensionCount(); ++i) {
/*  81 */       com.ai.appframe2.analyse.xml.Dimension dim = dims.getDimension(i);
/*  82 */       aGridImpl.addDimension(dim.getAttr(), dim.getName(), dim.getAttr(), dim.getType());
/*     */     }
/*  84 */     Meass meass = aGridDefine.getMeass();
/*  85 */     for (int i = 0; i < meass.getMeasCount(); ++i) {
/*  86 */       com.ai.appframe2.analyse.xml.Meas meas = meass.getMeas(i);
/*  87 */       aGridImpl.addMeas(meas.getAttr(), meas.getName(), meas.getAttr(), meas.getType(), Boolean.valueOf(meas.getCanSubTotal()).booleanValue());
/*     */     }
/*  89 */     ComputerMeass computerMeass = aGridDefine.getComputerMeass();
/*  90 */     int subTotalType = 0;
/*  91 */     if (computerMeass != null)
/*  92 */       for (int i = 0; i < computerMeass.getComputerMeasCount(); ++i) {
/*  93 */         ComputerMeas computerMeas = computerMeass.getComputerMeas(i);
/*  94 */         if (computerMeas.getSubTotalType() != null)
/*  95 */           subTotalType = Integer.parseInt(computerMeas.getSubTotalType());
/*     */         else
/*  97 */           subTotalType = 0;
/*  98 */         aGridImpl.addComputerMeas(computerMeas.getName(), computerMeas.getName(), computerMeas.getName(), computerMeas.getFormual(), computerMeas.getType(), Boolean.valueOf(computerMeas.getCanSubTotal()).booleanValue(), subTotalType);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void initialData(CrossGridImpl aGrid, Object obj)
/*     */     throws Exception
/*     */   {
/* 110 */     if (obj instanceof ResultSet) {
/* 111 */       initialData(aGrid, (ResultSet)obj);
/* 112 */     } else if (obj instanceof DataContainerInterface[]) {
/* 113 */       initialData(aGrid, (DataContainerInterface[])(DataContainerInterface[])obj);
/*     */     }
/*     */     else {
/* 116 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridFactory.nonsupport_datatype");
/* 117 */       throw new Exception("CrossGridFactory.initialData " + msg + obj.getClass().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initialData(CrossGridImpl aGrid, ResultSet aSet) throws Exception
/*     */   {
/* 123 */     int rowindex = -1;
/*     */ 
/* 125 */     String[] colnames = new String[aGrid.getDimCount() + aGrid.getMeas().getRealMeasCount()];
/* 126 */     for (int i = 0; i < aGrid.getDimCount(); ++i) {
/* 127 */       colnames[i] = aGrid.getDimension(i).getCode();
/*     */     }
/* 129 */     for (int i = 0; i < aGrid.getMeas().getRealMeasCount(); ++i) {
/* 130 */       colnames[(aGrid.getDimCount() + i)] = aGrid.getMeas().getCode(i);
/*     */     }
/*     */ 
/* 134 */     while (aSet.next()) {
/* 135 */       rowindex = aGrid.addRow();
/* 136 */       for (int i = 0; i < colnames.length; ++i) {
/* 137 */         aGrid.addRowItem(rowindex, i, aSet.getString(colnames[i]));
/*     */       }
/*     */     }
/* 140 */     aSet.close();
/*     */   }
/*     */ 
/*     */   protected static void initialData(CrossGridImpl aGrid, DataContainerInterface[] aDcs) throws Exception {
/* 144 */     int rowindex = -1;
/*     */ 
/* 146 */     String[] colnames = new String[aGrid.getDimCount() + aGrid.getMeas().getRealMeasCount()];
/* 147 */     for (int i = 0; i < aGrid.getDimCount(); ++i) {
/* 148 */       colnames[i] = aGrid.getDimension(i).getCode();
/*     */     }
/* 150 */     for (int i = 0; i < aGrid.getMeas().getRealMeasCount(); ++i) {
/* 151 */       colnames[(aGrid.getDimCount() + i)] = aGrid.getMeas().getCode(i);
/*     */     }
/*     */ 
/* 154 */     for (int i = 0; (aDcs != null) && (i < aDcs.length); ++i) {
/* 155 */       rowindex = aGrid.addRow();
/* 156 */       for (int j = 0; j < colnames.length; ++j)
/* 157 */         aGrid.addRowItem(rowindex, j, aDcs[i].get(colnames[j]));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridFactory
 * JD-Core Version:    0.5.4
 */