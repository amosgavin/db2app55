/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.common.SessionCashe;
/*    */ import com.ai.appframe2.common.SessionCasheFactory;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class CrossGridFactoryDefault extends CrossGridFactory
/*    */ {
/* 23 */   private static String S_CASHE_NAME = "CrossGridFactoryDefault";
/*    */ 
/*    */   public CrossGridImpl getInstance(String name, String dataModelStr, boolean canCashe, HttpServletRequest req)
/*    */     throws Exception
/*    */   {
/* 31 */     CrossGridImpl result = new CrossGridImpl(name);
/*    */ 
/* 33 */     result.setConfigXmlName(name);
/* 34 */     result.setDataModelStr(dataModelStr);
/*    */ 
/* 36 */     String sessionId = req.getSession(true).getId();
/* 37 */     long pk = SessionCasheFactory.getInstance(S_CASHE_NAME).add(sessionId, result);
/* 38 */     result.setPk(pk);
/*    */ 
/* 40 */     synchronized (result.m_hasInitial) {
/* 41 */       if (!result.m_hasInitial.m_boolean)
/*    */       {
/* 43 */         initCrossGridData(name, result, dataModelStr, req);
/* 44 */         result.m_hasInitial.m_boolean = true;
/*    */       }
/*    */     }
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public CrossGridImpl getInstance(long pk) throws Exception {
/* 51 */     CrossGridImpl result = (CrossGridImpl)SessionCasheFactory.getInstance(S_CASHE_NAME).find(new Long(pk));
/*    */ 
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 25 */     SessionCasheFactory.getInstance(S_CASHE_NAME).setMaxNumber(5);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridFactoryDefault
 * JD-Core Version:    0.5.4
 */