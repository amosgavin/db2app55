/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ class DimMember
/*     */ {
/*     */   public Object baseName;
/*     */   public int orgiIndex;
/*     */   public String serverLevelId;
/*     */   public Object[] members;
/*     */   public List membersRowIndexs;
/*     */ 
/*     */   public DimMember()
/*     */   {
/* 246 */     this.membersRowIndexs = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void free()
/*     */   {
/* 251 */     this.membersRowIndexs.clear();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.DimMember
 * JD-Core Version:    0.5.4
 */