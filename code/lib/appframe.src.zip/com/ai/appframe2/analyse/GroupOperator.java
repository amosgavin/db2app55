/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.express.ConditionData;
/*    */ import com.ai.appframe2.express.Operation;
/*    */ import com.ai.appframe2.express.Operator;
/*    */ 
/*    */ class GroupOperator extends Operator
/*    */ {
/*    */   CrossOperation m_operator;
/*    */ 
/*    */   public GroupOperator(CrossOperation operator)
/*    */   {
/* 42 */     this.name = "group";
/* 43 */     this.m_operator = operator;
/*    */   }
/*    */ 
/*    */   public ConditionData execute(Operation parent, ConditionData[] list) throws Exception
/*    */   {
/* 48 */     if (list.length == 0)
/* 49 */       return null;
/* 50 */     ConditionData result = new ConditionData();
/* 51 */     Object obj = this.m_operator.m_crossGrid.group(this.m_operator.m_currentRow, (String)(String)list[0].getObject(parent), (String)(String)list[1].getObject(parent));
/* 52 */     result.setObject(parent, obj);
/* 53 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.GroupOperator
 * JD-Core Version:    0.5.4
 */