/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ public class RowData
/*    */ {
/*    */   private int logicIndex;
/*    */   private int[] dimIndexArray;
/*    */   private Object[] measObjects;
/*    */ 
/*    */   public RowData(int dimCount, int measCount)
/*    */   {
/* 18 */     this.logicIndex = -1;
/* 19 */     this.dimIndexArray = new int[dimCount];
/* 20 */     this.measObjects = new Object[measCount];
/*    */   }
/*    */   public void free() {
/* 23 */     this.dimIndexArray = null;
/* 24 */     this.measObjects = null;
/*    */   }
/*    */   public void setLogicIndex(int aLogicIndex) {
/* 27 */     this.logicIndex = aLogicIndex;
/*    */   }
/*    */   public int getLogicIndex() {
/* 30 */     return this.logicIndex;
/*    */   }
/*    */ 
/*    */   public void setDimIndexArray(int[] aDimIndexArray) {
/* 34 */     for (int i = 0; i < aDimIndexArray.length; ++i)
/* 35 */       this.dimIndexArray[i] = aDimIndexArray[i];
/*    */   }
/*    */ 
/*    */   public void setMeasObjects(Object[] aValues) {
/* 39 */     for (int i = 0; i < aValues.length; ++i)
/* 40 */       this.measObjects[i] = aValues[i];
/*    */   }
/*    */ 
/*    */   public void addDimIndex(int colIndex, int dimIndex) {
/* 44 */     this.dimIndexArray[colIndex] = dimIndex;
/*    */   }
/*    */   public int getDimIndex(int colIndex) {
/* 47 */     return this.dimIndexArray[colIndex];
/*    */   }
/*    */   public int[] getDimIndex() {
/* 50 */     return this.dimIndexArray;
/*    */   }
/*    */   public Object[] getMeasObject() {
/* 53 */     return this.measObjects;
/*    */   }
/*    */   public void addMeasObject(int measIndex, Object value) {
/* 56 */     this.measObjects[measIndex] = value;
/*    */   }
/*    */   public Object getMeasObject(int measIndex) {
/* 59 */     return this.measObjects[measIndex];
/*    */   }
/*    */   public String toString(Dimension[] dims) {
/* 62 */     StringBuilder buffer = new StringBuilder();
/* 63 */     for (int i = 0; i < this.dimIndexArray.length; ++i) {
/* 64 */       if (i > 0)
/* 65 */         buffer.append("\t");
/* 66 */       buffer.append(dims[i].getDesc(this.dimIndexArray[i]));
/*    */     }
/* 68 */     for (int i = 0; i < this.measObjects.length; ++i) {
/* 69 */       buffer.append("\t");
/* 70 */       if (this.measObjects[i] != null)
/* 71 */         buffer.append(this.measObjects[i].toString());
/*    */       else
/* 73 */         buffer.append("NULL");
/*    */     }
/* 75 */     return buffer.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.RowData
 * JD-Core Version:    0.5.4
 */