package com.ai.appframe2.analyse;

import java.io.OutputStream;
import java.io.Writer;

public abstract interface McGridInterface
{
  public abstract void initial(String paramString, CrossGridImpl paramCrossGridImpl, PivotList paramPivotList, boolean paramBoolean)
    throws Exception;

  public abstract int getRowCount();

  public abstract int getColCount();

  public abstract CrossGridImpl getCrossGridImpl();

  public abstract PivotList getPivots();

  public abstract boolean rowIsSubTotal(int paramInt);

  public abstract boolean colIsSubTotal(int paramInt);

  public abstract long getPk();

  public abstract void toHtmlGrid(Writer paramWriter, String paramString)
    throws Exception;

  public abstract void toExcel(OutputStream paramOutputStream, String paramString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.McGridInterface
 * JD-Core Version:    0.5.4
 */