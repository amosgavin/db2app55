/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class Dimension
/*     */   implements DimensionOrMeas
/*     */ {
/*     */   private int range;
/*     */   private String name;
/*     */   private String code;
/*     */   private String serverDimId;
/*     */   private String[] dimMemberNames;
/*     */   private int baseMemberIndex;
/*     */   private String[] dataTypes;
/*     */   private List beforeSort;
/*     */   private List afterSort;
/*     */   private TreeMap members;
/*     */ 
/*     */   public Dimension(String aServerDimId, String aDimName, String aDimCode, String[] aDimFields, int aBaseMemberIndex, String[] aDataTypes)
/*     */   {
/*  40 */     this.serverDimId = aServerDimId;
/*  41 */     this.name = aDimName;
/*  42 */     this.code = aDimCode;
/*  43 */     this.range = 0;
/*  44 */     this.baseMemberIndex = aBaseMemberIndex;
/*  45 */     this.dimMemberNames = aDimFields;
/*  46 */     this.dataTypes = aDataTypes;
/*  47 */     this.members = new TreeMap();
/*  48 */     this.beforeSort = new ArrayList();
/*     */   }
/*     */ 
/*     */   public void free()
/*     */   {
/*  54 */     this.members.clear();
/*  55 */     this.beforeSort.clear();
/*  56 */     if (this.afterSort != null)
/*  57 */       this.afterSort.clear();
/*     */   }
/*     */ 
/*     */   private List getAfterSort()
/*     */   {
/*  62 */     if (this.afterSort == null)
/*  63 */       this.afterSort = new ArrayList(this.members.keySet());
/*  64 */     return this.afterSort;
/*     */   }
/*     */   public int getRange() {
/*  67 */     return this.range;
/*     */   }
/*     */   public void setRange(int aRange) {
/*  70 */     this.range = aRange;
/*     */   }
/*     */ 
/*     */   public int getRealDimIndex(int index, int aSortType)
/*     */   {
/*  78 */     int result = -1;
/*  79 */     if (index == this.members.size())
/*  80 */       result = this.members.size();
/*  81 */     else if (aSortType == 0)
/*  82 */       result = index;
/*  83 */     else if (aSortType == 1)
/*  84 */       result = getDimMember(getAfterSort().get(index).toString()).orgiIndex;
/*     */     else {
/*  86 */       result = getDimMember(getAfterSort().get(this.beforeSort.size() - index - 1).toString()).orgiIndex;
/*     */     }
/*  88 */     return result;
/*     */   }
/*     */   public int getRealDimIndex(Object baseName) {
/*  91 */     if (SUBTOTAL_DESC.equalsIgnoreCase(baseName.toString()) == true) {
/*  92 */       return count();
/*     */     }
/*  94 */     return getDimMember(baseName.toString()).orgiIndex;
/*     */   }
/*     */ 
/*     */   public String getDesc(int index)
/*     */   {
/* 100 */     String result = "";
/* 101 */     if (index == this.members.size())
/* 102 */       result = SUBTOTAL_DESC;
/*     */     else {
/* 104 */       result = this.beforeSort.get(index).toString();
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   public int[] getRows(int index) {
/* 110 */     if (index == this.beforeSort.size())
/* 111 */       return null;
/* 112 */     return getRows(this.beforeSort.get(index));
/*     */   }
/*     */   private int[] getRows(Object baseName) {
/* 115 */     int[] result = null;
/* 116 */     List tmpList = ((DimMember)this.members.get(baseName)).membersRowIndexs;
/* 117 */     if (tmpList == null) {
/* 118 */       result = new int[0];
/*     */     } else {
/* 120 */       result = new int[tmpList.size()];
/* 121 */       for (int i = 0; i < result.length; ++i)
/* 122 */         result[i] = ((Integer)tmpList.get(i)).intValue();
/*     */     }
/* 124 */     return result;
/*     */   }
/*     */ 
/*     */   public int addMember(String aMembers, int rowIndex) {
/* 128 */     String[] tmpStrs = StringUtils.split(aMembers, ',');
/* 129 */     return addMember(tmpStrs, rowIndex, "-1");
/*     */   }
/*     */ 
/*     */   public int addMember(Object[] aMembers, int rowIndex, String aLevelId)
/*     */   {
/* 137 */     String baseName = String.valueOf(aMembers[this.baseMemberIndex]);
/* 138 */     DimMember member = null;
/* 139 */     if (this.members.containsKey(baseName)) {
/* 140 */       member = (DimMember)this.members.get(baseName);
/* 141 */       if (rowIndex >= 0)
/* 142 */         member.membersRowIndexs.add(new Integer(rowIndex));
/*     */     } else {
/* 144 */       this.beforeSort.add(baseName);
/* 145 */       member = new DimMember();
/* 146 */       member.baseName = baseName;
/* 147 */       member.members = aMembers;
/* 148 */       member.serverLevelId = aLevelId;
/* 149 */       member.orgiIndex = (this.beforeSort.size() - 1);
/* 150 */       this.members.put(baseName, member);
/* 151 */       if (rowIndex >= 0)
/* 152 */         member.membersRowIndexs.add(new Integer(rowIndex));
/*     */     }
/* 154 */     return member.orgiIndex;
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 158 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getDataType(int index) {
/* 162 */     return this.dataTypes[index];
/*     */   }
/*     */ 
/*     */   public int getDimMemberCount() {
/* 166 */     return this.dimMemberNames.length;
/*     */   }
/*     */ 
/*     */   public int getDimDataCount() {
/* 170 */     return this.members.size();
/*     */   }
/*     */ 
/*     */   public String getDataID()
/*     */   {
/* 175 */     return this.serverDimId;
/*     */   }
/*     */   public String getCode() {
/* 178 */     return this.code;
/*     */   }
/*     */ 
/*     */   public String getLevelId(int index)
/*     */   {
/* 183 */     return getDimMember(index).serverLevelId;
/*     */   }
/*     */   public DimMember getDimMember(int index) {
/* 186 */     return getDimMember(this.beforeSort.get(index).toString());
/*     */   }
/*     */   public DimMember getDimMember(String baseName) {
/* 189 */     return (DimMember)this.members.get(baseName);
/*     */   }
/*     */ 
/*     */   public int count() {
/* 193 */     return getDimDataCount();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 197 */     StringBuilder buffer = new StringBuilder();
/* 198 */     int tmpCount = count();
/* 199 */     for (int i = 0; i < tmpCount; ++i) {
/* 200 */       if (i > 0) {
/* 201 */         buffer.append("\n");
/*     */       }
/* 203 */       String baseName = getDesc(i);
/* 204 */       buffer.append(i).append("\t").append(baseName).append("\t");
/* 205 */       DimMember member = (DimMember)this.members.get(baseName);
/* 206 */       for (int j = 0; j < member.members.length; ++j) {
/* 207 */         if (j > 0)
/* 208 */           buffer.append(",");
/* 209 */         buffer.append(member.members[j]);
/*     */       }
/* 211 */       buffer.append("\t");
/* 212 */       int[] rowIndexs = getRows(baseName);
/* 213 */       for (int j = 0; j < rowIndexs.length; ++j) {
/* 214 */         if (j > 0)
/* 215 */           buffer.append(",");
/* 216 */         buffer.append(rowIndexs[j]);
/*     */       }
/*     */     }
/* 219 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.Dimension
 * JD-Core Version:    0.5.4
 */