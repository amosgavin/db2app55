/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Meas
/*     */   implements DimensionOrMeas
/*     */ {
/*  15 */   public static int SUTTOTAL_TYPE_STATIC = 0;
/*  16 */   public static int SUTTOTAL_TYPE_DYNAMIC = 1;
/*  17 */   public static String MEAS_CODE = "meas";
/*  18 */   public static String MEAS_NAME = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.Meas.measname");
/*     */   private List realMembers;
/*     */   private List computerMembers;
/*     */   private List computerFormuals;
/*     */   private List computerFormualsAfterParse;
/*     */   private List dataTypes;
/*     */   private List codes;
/*     */   private List canSubtotals;
/*     */   private List subTotalType;
/*     */   private List serverIds;
/*     */ 
/*     */   public Meas()
/*     */   {
/*  40 */     this.realMembers = new ArrayList();
/*  41 */     this.codes = new ArrayList();
/*  42 */     this.computerMembers = new ArrayList();
/*  43 */     this.computerFormuals = new ArrayList();
/*  44 */     this.computerFormualsAfterParse = new ArrayList();
/*  45 */     this.dataTypes = new ArrayList();
/*  46 */     this.canSubtotals = new ArrayList();
/*  47 */     this.subTotalType = new ArrayList();
/*  48 */     this.serverIds = new ArrayList();
/*     */   }
/*     */   public void free() {
/*  51 */     this.realMembers.clear();
/*  52 */     this.codes.clear();
/*  53 */     this.computerMembers.clear();
/*  54 */     this.computerFormuals.clear();
/*  55 */     this.computerFormualsAfterParse.clear();
/*  56 */     this.dataTypes.clear();
/*  57 */     this.canSubtotals.clear();
/*  58 */     this.subTotalType.clear();
/*  59 */     this.serverIds.clear();
/*     */   }
/*     */ 
/*     */   public String getDesc(int index)
/*     */   {
/*  66 */     if (index < this.realMembers.size())
/*  67 */       return this.realMembers.get(index).toString();
/*  68 */     if (index < this.realMembers.size() + this.computerMembers.size())
/*  69 */       return this.computerMembers.get(index - this.realMembers.size()).toString();
/*  70 */     if (index == this.realMembers.size() + this.computerMembers.size())
/*  71 */       return SUBTOTAL_DESC;
/*  72 */     return AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.Meas.data_err");
/*     */   }
/*     */ 
/*     */   public int getRealDimIndex(int index, int aSortType) {
/*  76 */     return index;
/*     */   }
/*     */ 
/*     */   public String getCode() {
/*  80 */     return "Meas";
/*     */   }
/*     */   public String getCode(int index) {
/*  83 */     return this.codes.get(index).toString();
/*     */   }
/*     */ 
/*     */   public String getFormual(int index)
/*     */   {
/*  89 */     return this.computerFormuals.get(index).toString();
/*     */   }
/*     */ 
/*     */   public Object[] getFormualAfterParse(int index) {
/*  93 */     return (Object[])(Object[])this.computerFormualsAfterParse.get(index);
/*     */   }
/*     */ 
/*     */   public int indexOfByCode(String code) {
/*  97 */     for (int i = 0; i < this.codes.size(); ++i) {
/*  98 */       if (this.codes.get(i).toString().equalsIgnoreCase(code))
/*  99 */         return i;
/*     */     }
/* 101 */     return -1;
/*     */   }
/*     */ 
/*     */   public int indexOf(String value)
/*     */   {
/* 106 */     for (int i = 0; i < this.realMembers.size(); ++i) {
/* 107 */       if (this.realMembers.get(i).toString().equalsIgnoreCase(value))
/* 108 */         return i;
/*     */     }
/* 110 */     for (int i = 0; i < this.computerMembers.size(); ++i) {
/* 111 */       if (this.computerMembers.get(i).toString().equalsIgnoreCase(value))
/* 112 */         return i + this.realMembers.size();
/*     */     }
/* 114 */     return -1;
/*     */   }
/*     */ 
/*     */   public int[] getRows(int index)
/*     */   {
/* 121 */     return new int[0];
/*     */   }
/*     */ 
/*     */   public int addMember(String aDataID, String name, String code, String aDataType, boolean aCanSubTotal)
/*     */   {
/* 130 */     this.serverIds.add(aDataID);
/* 131 */     this.codes.add(code);
/* 132 */     this.canSubtotals.add(new Boolean(aCanSubTotal));
/* 133 */     this.dataTypes.add(aDataType);
/* 134 */     this.realMembers.add(name);
/* 135 */     return this.realMembers.size() - 1;
/*     */   }
/*     */ 
/*     */   public int addComputerMeas(CrossOperation operation, String aServerID, String name, String code, String formual, String aDataType, boolean aCanSubTotal, int aSubTotalType)
/*     */     throws Exception
/*     */   {
/* 145 */     this.serverIds.add(aServerID);
/* 146 */     this.codes.add(code);
/* 147 */     this.canSubtotals.add(new Boolean(aCanSubTotal));
/* 148 */     this.subTotalType.add(new Integer(aSubTotalType));
/* 149 */     this.dataTypes.add(aDataType);
/* 150 */     this.computerFormuals.add(formual);
/* 151 */     Object[] tmpList = operation.getOpObjectList(formual + ";");
/* 152 */     this.computerFormualsAfterParse.add(tmpList);
/* 153 */     this.computerMembers.add(name);
/* 154 */     return this.realMembers.size() + this.computerMembers.size() - 1;
/*     */   }
/*     */ 
/*     */   public String getDataType(int index)
/*     */   {
/* 160 */     return this.dataTypes.get(index).toString();
/*     */   }
/*     */ 
/*     */   public int getDimDataCount()
/*     */   {
/* 165 */     return this.realMembers.size() + this.computerMembers.size();
/*     */   }
/*     */ 
/*     */   public String getDataID(int index)
/*     */   {
/* 170 */     return this.serverIds.get(index).toString();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 175 */     return "量";
/*     */   }
/*     */ 
/*     */   public int count() {
/* 179 */     return getDimDataCount();
/*     */   }
/*     */ 
/*     */   public int getComputerMeasCount() {
/* 183 */     return this.computerMembers.size();
/*     */   }
/*     */ 
/*     */   public int getRealMeasCount()
/*     */   {
/* 188 */     return this.realMembers.size();
/*     */   }
/*     */ 
/*     */   public boolean isCanSubTotal(int index)
/*     */   {
/* 194 */     return ((Boolean)this.canSubtotals.get(index)).booleanValue();
/*     */   }
/*     */   public int getSubTotalType(int index) {
/* 197 */     return ((Integer)this.subTotalType.get(index)).intValue();
/*     */   }
/*     */   public String toString() {
/* 200 */     StringBuilder buffer = new StringBuilder();
/* 201 */     for (int i = 0; i < this.codes.size(); ++i) {
/* 202 */       if (i > 0)
/* 203 */         buffer.append("\n");
/* 204 */       buffer.append(i).append("\t");
/* 205 */       if (i < this.realMembers.size())
/* 206 */         buffer.append(this.realMembers.get(i).toString());
/*     */       else
/* 208 */         buffer.append(this.computerMembers.get(i - this.realMembers.size()));
/* 209 */       buffer.append("(" + this.codes.get(i) + ")").append("[" + this.dataTypes.get(i).toString() + "]").append("\t");
/* 210 */       buffer.append("是否可以小计[" + this.canSubtotals.get(i).toString() + "]");
/* 211 */       if (i >= this.realMembers.size())
/* 212 */         buffer.append("\t").append(this.computerFormuals.get(i - this.realMembers.size()));
/*     */     }
/* 214 */     return buffer.toString();
/*     */   }
/*     */   public static void main(String[] args) {
/* 217 */     Meas m = new Meas();
/* 218 */     m.addMember("1", "用户数量", "usercount", "Integer", true);
/* 219 */     m.addMember("1", "月租费", "monthfee", "Double", true);
/*     */ 
/* 221 */     System.out.println(m.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.Meas
 * JD-Core Version:    0.5.4
 */