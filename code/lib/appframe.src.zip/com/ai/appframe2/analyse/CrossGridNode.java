/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class CrossGridNode
/*     */ {
/*     */   List m_list;
/*     */   int m_range;
/*     */   int m_dimIndex;
/*     */   int m_dimValueIndex;
/*     */   CrossGridNode m_parent;
/*     */ 
/*     */   public CrossGridNode(int dimIndex, int dimValueIndex)
/*     */   {
/*  15 */     this.m_dimIndex = dimIndex;
/*  16 */     this.m_dimValueIndex = dimValueIndex;
/*  17 */     this.m_range = 1;
/*     */   }
/*     */ 
/*     */   public void getListByLevel(int level, List aList) {
/*  21 */     if (this.m_list != null)
/*  22 */       if (level == 0) {
/*  23 */         aList.addAll(this.m_list);
/*     */       }
/*     */       else
/*  26 */         for (int i = 0; i < this.m_list.size(); ++i)
/*  27 */           ((CrossGridNode)this.m_list.get(i)).getListByLevel(level - 1, aList);
/*     */   }
/*     */ 
/*     */   public CrossGridNode getObject(int row, int level) throws Exception
/*     */   {
/*  32 */     int count = 0;
/*     */ 
/*  34 */     CrossGridNode result = null;
/*  35 */     for (int i = 0; i < this.m_list.size(); ++i) {
/*  36 */       result = (CrossGridNode)this.m_list.get(i);
/*  37 */       if (row < count + result.m_range) {
/*     */         break;
/*     */       }
/*  40 */       count += result.m_range;
/*     */     }
/*  42 */     if (result == null) {
/*  43 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.CrossGridNode.outof_range", new String[] { row + "" });
/*  44 */       throw new Exception(msg);
/*     */     }
/*     */ 
/*  47 */     if (level == 0) {
/*  48 */       return result;
/*     */     }
/*  50 */     return result.getObject(row - count, level - 1);
/*     */   }
/*     */ 
/*     */   public int get(int row, int level) throws Exception
/*     */   {
/*  55 */     return getObject(row, level).m_dimValueIndex;
/*     */   }
/*     */   public int getDimIndex() {
/*  58 */     return this.m_dimIndex;
/*     */   }
/*     */   public int getDimValueIndex() {
/*  61 */     return this.m_dimValueIndex;
/*     */   }
/*     */   public void clear() {
/*  64 */     this.m_range = 0;
/*  65 */     this.m_dimIndex = -1;
/*  66 */     this.m_dimValueIndex = -1;
/*  67 */     if (this.m_list != null)
/*  68 */       this.m_list.clear();
/*  69 */     this.m_list = null;
/*     */   }
/*     */   public void setParent(CrossGridNode parent) {
/*  72 */     this.m_parent = parent;
/*     */   }
/*     */   public CrossGridNode getParent() {
/*  75 */     return this.m_parent;
/*     */   }
/*     */   public void setChilds(List value) {
/*  78 */     this.m_list = value;
/*     */   }
/*     */   public List getChilds() {
/*  81 */     return this.m_list;
/*     */   }
/*     */   public void addChild(CrossGridNode node) {
/*  84 */     if (this.m_list == null)
/*  85 */       this.m_list = new ArrayList();
/*  86 */     this.m_list.add(node);
/*     */   }
/*     */   public int getRange() {
/*  89 */     return this.m_range;
/*     */   }
/*     */   public void setRange(int value) {
/*  92 */     this.m_range = value;
/*     */   }
/*     */   public void setAllChildCount(int value) {
/*  95 */     this.m_range = value;
/*     */   }
/*     */ 
/*     */   public CrossGridNode getChildAt(int childIndex) {
/*  99 */     if (this.m_list == null)
/* 100 */       return null;
/* 101 */     return (CrossGridNode)this.m_list.get(childIndex);
/*     */   }
/*     */ 
/*     */   public int getChildCount() {
/* 105 */     if (this.m_list == null)
/* 106 */       return 0;
/* 107 */     return this.m_list.size();
/*     */   }
/*     */ 
/*     */   public int getIndex(CrossGridNode node)
/*     */   {
/* 112 */     if (this.m_list == null)
/* 113 */       return -1;
/* 114 */     return this.m_list.indexOf(node);
/*     */   }
/*     */ 
/*     */   public boolean getAllowsChildren() {
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isLeaf() {
/* 122 */     return (this.m_list == null) || (this.m_list.size() == 0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridNode
 * JD-Core Version:    0.5.4
 */