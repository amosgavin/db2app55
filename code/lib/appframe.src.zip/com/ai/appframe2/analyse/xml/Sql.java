/*    */ package com.ai.appframe2.analyse.xml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class Sql extends TextElement
/*    */ {
/* 16 */   public static String _tagName = "sql";
/*    */ 
/*    */   public Sql()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Sql(String text)
/*    */   {
/* 31 */     super(text);
/*    */   }
/*    */ 
/*    */   public static Sql unmarshal(Element elem)
/*    */   {
/* 40 */     Sql __objSql = (Sql)TextElement.unmarshal(elem, new Sql());
/* 41 */     return __objSql;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 51 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Sql
 * JD-Core Version:    0.5.4
 */