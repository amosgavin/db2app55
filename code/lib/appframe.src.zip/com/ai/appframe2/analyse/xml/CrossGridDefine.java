/*      */ package com.ai.appframe2.analyse.xml;
/*      */ 
/*      */ import com.borland.xml.toolkit.Comment;
/*      */ import com.borland.xml.toolkit.DOMAdapterNotFoundException;
/*      */ import com.borland.xml.toolkit.Element;
/*      */ import com.borland.xml.toolkit.ElementError;
/*      */ import com.borland.xml.toolkit.ErrorList;
/*      */ import com.borland.xml.toolkit.Outputter;
/*      */ import com.borland.xml.toolkit.XmlObject;
/*      */ import com.borland.xml.toolkit.XmlUtil;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.xml.sax.DTDHandler;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ 
/*      */ public class CrossGridDefine extends XmlObject
/*      */ {
/*   18 */   public static String _tagName = "CrossGrid";
/*      */   protected Dimensions _objDimensions;
/*      */   protected Meass _objMeass;
/*      */   protected ComputerMeass _objComputerMeass;
/*      */   protected Pivots _objPivots;
/*      */   protected FetchData _objFetchData;
/*   30 */   protected String publicId = "";
/*      */ 
/*   32 */   protected String systemId = "";
/*      */ 
/*   34 */   protected Outputter _outputter = null;
/*      */ 
/*      */   public Dimensions getDimensions()
/*      */   {
/*   49 */     return this._objDimensions;
/*      */   }
/*      */ 
/*      */   public void setDimensions(Dimensions obj)
/*      */   {
/*   60 */     this._objDimensions = obj;
/*   61 */     if (obj == null) {
/*   62 */       return;
/*      */     }
/*   64 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public Meass getMeass()
/*      */   {
/*   71 */     return this._objMeass;
/*      */   }
/*      */ 
/*      */   public void setMeass(Meass obj)
/*      */   {
/*   82 */     this._objMeass = obj;
/*   83 */     if (obj == null) {
/*   84 */       return;
/*      */     }
/*   86 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public ComputerMeass getComputerMeass()
/*      */   {
/*   93 */     return this._objComputerMeass;
/*      */   }
/*      */ 
/*      */   public void setComputerMeass(ComputerMeass obj)
/*      */   {
/*  104 */     this._objComputerMeass = obj;
/*  105 */     if (obj == null) {
/*  106 */       return;
/*      */     }
/*  108 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public Pivots getPivots()
/*      */   {
/*  115 */     return this._objPivots;
/*      */   }
/*      */ 
/*      */   public void setPivots(Pivots obj)
/*      */   {
/*  126 */     this._objPivots = obj;
/*  127 */     if (obj == null) {
/*  128 */       return;
/*      */     }
/*  130 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public FetchData getFetchData()
/*      */   {
/*  137 */     return this._objFetchData;
/*      */   }
/*      */ 
/*      */   public void setFetchData(FetchData obj)
/*      */   {
/*  148 */     this._objFetchData = obj;
/*  149 */     if (obj == null) {
/*  150 */       return;
/*      */     }
/*  152 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  162 */     Element elem = marshal();
/*  163 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent)
/*      */     throws IOException
/*      */   {
/*  185 */     Element elem = marshal();
/*  186 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  209 */     Element elem = marshal();
/*  210 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  243 */     Element elem = marshal();
/*  244 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  261 */     Element elem = marshal();
/*  262 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName)
/*      */     throws IOException
/*      */   {
/*  274 */     Element elem = marshal();
/*  275 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent)
/*      */     throws IOException
/*      */   {
/*  298 */     Element elem = marshal();
/*  299 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  322 */     Element elem = marshal();
/*  323 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  356 */     Element elem = marshal();
/*  357 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  374 */     Element elem = marshal();
/*  375 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(File file)
/*      */     throws IOException
/*      */   {
/*  387 */     Element elem = marshal();
/*  388 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent)
/*      */     throws IOException
/*      */   {
/*  411 */     Element elem = marshal();
/*  412 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  435 */     Element elem = marshal();
/*  436 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  469 */     Element elem = marshal();
/*  470 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  487 */     Element elem = marshal();
/*  488 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer)
/*      */     throws IOException
/*      */   {
/*  500 */     Element elem = marshal();
/*  501 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent)
/*      */     throws IOException
/*      */   {
/*  524 */     Element elem = marshal();
/*  525 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  548 */     Element elem = marshal();
/*  549 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  582 */     Element elem = marshal();
/*  583 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  600 */     Element elem = marshal();
/*  601 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(InputStream in, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  626 */     Element elem = XmlUtil.getDocRootElement(in, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  629 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(InputStream in, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  647 */     Element elem = XmlUtil.getDocRootElement(in, domParserClass, validation);
/*      */ 
/*  649 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(InputStream in)
/*      */   {
/*  658 */     return unmarshal(XmlUtil.getDocRootElement(in));
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(File file, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  682 */     Element elem = XmlUtil.getDocRootElement(file, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  685 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(File file, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  703 */     Element elem = XmlUtil.getDocRootElement(file, domParserClass, validation);
/*      */ 
/*  705 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(File file)
/*      */   {
/*  714 */     return unmarshal(XmlUtil.getDocRootElement(file));
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(String fileName, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  738 */     Element elem = XmlUtil.getDocRootElement(fileName, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  741 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(String fileName, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  759 */     Element elem = XmlUtil.getDocRootElement(fileName, domParserClass, validation);
/*      */ 
/*  761 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(String fileName)
/*      */   {
/*  770 */     return unmarshal(XmlUtil.getDocRootElement(fileName));
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(URL url, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  794 */     Element elem = XmlUtil.getDocRootElement(url, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  797 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(URL url, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  815 */     Element elem = XmlUtil.getDocRootElement(url, domParserClass, validation);
/*      */ 
/*  817 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(URL url)
/*      */   {
/*  826 */     return unmarshal(XmlUtil.getDocRootElement(url));
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(Reader reader, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  850 */     Element elem = XmlUtil.getDocRootElement(reader, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  853 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(Reader reader)
/*      */   {
/*  862 */     return unmarshal(XmlUtil.getDocRootElement(reader));
/*      */   }
/*      */ 
/*      */   public void _setOutputter(Outputter outputter)
/*      */   {
/*  870 */     this._outputter = outputter;
/*      */   }
/*      */ 
/*      */   public Outputter _getOutputter()
/*      */   {
/*  878 */     return this._outputter;
/*      */   }
/*      */ 
/*      */   public void _setIndent(String indent)
/*      */   {
/*  888 */     if (this._outputter == null) {
/*  889 */       this._outputter = new Outputter();
/*      */     }
/*  891 */     this._outputter.setIndent(indent);
/*      */   }
/*      */ 
/*      */   public void _setIndentSize(int indentSize)
/*      */   {
/*  900 */     if (this._outputter == null) {
/*  901 */       this._outputter = new Outputter();
/*      */     }
/*  903 */     this._outputter.setIndentSize(indentSize);
/*      */   }
/*      */ 
/*      */   public void _setNewlines(boolean newlines)
/*      */   {
/*  913 */     if (this._outputter == null) {
/*  914 */       this._outputter = new Outputter();
/*      */     }
/*  916 */     this._outputter.setNewlines(newlines);
/*      */   }
/*      */ 
/*      */   public void _setEncoding(String encoding)
/*      */   {
/*  924 */     if (this._outputter == null) {
/*  925 */       this._outputter = new Outputter();
/*      */     }
/*  927 */     this._outputter.setEncoding(encoding);
/*      */   }
/*      */ 
/*      */   public void _setPrintEncoding(boolean printEncoding)
/*      */   {
/*  936 */     if (this._outputter == null) {
/*  937 */       this._outputter = new Outputter();
/*      */     }
/*  939 */     this._outputter.setPrintEncoding(printEncoding);
/*      */   }
/*      */ 
/*      */   public void _setPrintXMLDeclaration(boolean printXMLDeclaration)
/*      */   {
/*  947 */     if (this._outputter == null) {
/*  948 */       this._outputter = new Outputter();
/*      */     }
/*  950 */     this._outputter.setPrintXMLDeclaration(printXMLDeclaration);
/*      */   }
/*      */ 
/*      */   public String getPublicId()
/*      */   {
/*  958 */     return this.publicId;
/*      */   }
/*      */ 
/*      */   public void setPublicId(String publicId)
/*      */   {
/*  966 */     this.publicId = publicId;
/*      */   }
/*      */ 
/*      */   public String getSystemId()
/*      */   {
/*  974 */     return this.systemId;
/*      */   }
/*      */ 
/*      */   public void setSystemId(String systemId)
/*      */   {
/*  982 */     this.systemId = systemId;
/*      */   }
/*      */ 
/*      */   public Element marshal()
/*      */   {
/*  990 */     Element elem = new Element(get_TagName());
/*      */ 
/*  992 */     if (this._objDimensions != null)
/*      */     {
/*  994 */       elem.addComment(this._objDimensions._marshalCommentList());
/*  995 */       elem.addContent(this._objDimensions.marshal());
/*      */     }
/*      */ 
/*  998 */     if (this._objMeass != null)
/*      */     {
/* 1000 */       elem.addComment(this._objMeass._marshalCommentList());
/* 1001 */       elem.addContent(this._objMeass.marshal());
/*      */     }
/*      */ 
/* 1004 */     if (this._objComputerMeass != null)
/*      */     {
/* 1006 */       elem.addComment(this._objComputerMeass._marshalCommentList());
/* 1007 */       elem.addContent(this._objComputerMeass.marshal());
/*      */     }
/*      */ 
/* 1010 */     if (this._objPivots != null)
/*      */     {
/* 1012 */       elem.addComment(this._objPivots._marshalCommentList());
/* 1013 */       elem.addContent(this._objPivots.marshal());
/*      */     }
/*      */ 
/* 1016 */     if (this._objFetchData != null)
/*      */     {
/* 1018 */       elem.addComment(this._objFetchData._marshalCommentList());
/* 1019 */       elem.addContent(this._objFetchData.marshal());
/*      */     }
/*      */ 
/* 1022 */     elem.addComment(_marshalBottomCommentList());
/* 1023 */     return elem;
/*      */   }
/*      */ 
/*      */   public static CrossGridDefine unmarshal(Element elem)
/*      */   {
/* 1031 */     if (elem == null) {
/* 1032 */       return null;
/*      */     }
/* 1034 */     CrossGridDefine __objCrossGridDefine = new CrossGridDefine();
/*      */ 
/* 1036 */     ArrayList __comments = null;
/* 1037 */     Iterator it = elem.getChildObjects().iterator();
/* 1038 */     while (it.hasNext())
/*      */     {
/* 1040 */       Object __obj = it.next();
/* 1041 */       if (__obj instanceof Comment)
/*      */       {
/* 1043 */         if (__comments == null) {
/* 1044 */           __comments = new ArrayList(2);
/*      */         }
/* 1046 */         __comments.add(__obj);
/*      */       }
/* 1048 */       else if (__obj instanceof Element)
/*      */       {
/* 1050 */         Element __e = (Element)__obj;
/* 1051 */         String __name = __e.getName();
/* 1052 */         if (__name.equals(Dimensions._tagName))
/*      */         {
/* 1055 */           Dimensions __objDimensions = Dimensions.unmarshal(__e);
/* 1056 */           __objCrossGridDefine.setDimensions(__objDimensions);
/* 1057 */           __objDimensions._unmarshalCommentList(__comments);
/*      */         }
/* 1059 */         if (__name.equals(Meass._tagName))
/*      */         {
/* 1062 */           Meass __objMeass = Meass.unmarshal(__e);
/* 1063 */           __objCrossGridDefine.setMeass(__objMeass);
/* 1064 */           __objMeass._unmarshalCommentList(__comments);
/*      */         }
/* 1066 */         if (__name.equals(ComputerMeass._tagName))
/*      */         {
/* 1069 */           ComputerMeass __objComputerMeass = ComputerMeass.unmarshal(__e);
/* 1070 */           __objCrossGridDefine.setComputerMeass(__objComputerMeass);
/* 1071 */           __objComputerMeass._unmarshalCommentList(__comments);
/*      */         }
/* 1073 */         if (__name.equals(Pivots._tagName))
/*      */         {
/* 1076 */           Pivots __objPivots = Pivots.unmarshal(__e);
/* 1077 */           __objCrossGridDefine.setPivots(__objPivots);
/* 1078 */           __objPivots._unmarshalCommentList(__comments);
/*      */         }
/* 1080 */         if (__name.equals(FetchData._tagName))
/*      */         {
/* 1083 */           FetchData __objFetchData = FetchData.unmarshal(__e);
/* 1084 */           __objCrossGridDefine.setFetchData(__objFetchData);
/* 1085 */           __objFetchData._unmarshalCommentList(__comments);
/*      */         }
/*      */ 
/* 1088 */         __comments = null;
/*      */       }
/*      */     }
/* 1091 */     __objCrossGridDefine._unmarshalBottomCommentList(__comments);
/* 1092 */     return __objCrossGridDefine;
/*      */   }
/*      */ 
/*      */   public ErrorList validate(boolean firstError)
/*      */   {
/* 1109 */     ErrorList errors = new ErrorList();
/*      */ 
/* 1112 */     if (this._objDimensions != null)
/* 1113 */       errors.add(this._objDimensions.validate(firstError));
/*      */     else
/* 1115 */       errors.add(new ElementError(this, Dimensions.class));
/* 1116 */     if ((firstError) && (errors.size() > 0)) {
/* 1117 */       return errors;
/*      */     }
/* 1119 */     if (this._objMeass != null)
/* 1120 */       errors.add(this._objMeass.validate(firstError));
/*      */     else
/* 1122 */       errors.add(new ElementError(this, Meass.class));
/* 1123 */     if ((firstError) && (errors.size() > 0)) {
/* 1124 */       return errors;
/*      */     }
/* 1126 */     if (this._objComputerMeass != null)
/* 1127 */       errors.add(this._objComputerMeass.validate(firstError));
/*      */     else
/* 1129 */       errors.add(new ElementError(this, ComputerMeass.class));
/* 1130 */     if ((firstError) && (errors.size() > 0)) {
/* 1131 */       return errors;
/*      */     }
/* 1133 */     if (this._objPivots != null)
/* 1134 */       errors.add(this._objPivots.validate(firstError));
/*      */     else
/* 1136 */       errors.add(new ElementError(this, Pivots.class));
/* 1137 */     if ((firstError) && (errors.size() > 0)) {
/* 1138 */       return errors;
/*      */     }
/* 1140 */     if (this._objFetchData != null)
/* 1141 */       errors.add(this._objFetchData.validate(firstError));
/*      */     else
/* 1143 */       errors.add(new ElementError(this, FetchData.class));
/* 1144 */     if ((firstError) && (errors.size() > 0)) {
/* 1145 */       return errors;
/*      */     }
/* 1147 */     return (errors.size() == 0) ? null : errors;
/*      */   }
/*      */ 
/*      */   public List _getChildren()
/*      */   {
/* 1156 */     List children = new ArrayList();
/*      */ 
/* 1158 */     if (this._objDimensions != null) {
/* 1159 */       children.add(this._objDimensions);
/*      */     }
/* 1161 */     if (this._objMeass != null) {
/* 1162 */       children.add(this._objMeass);
/*      */     }
/* 1164 */     if (this._objComputerMeass != null) {
/* 1165 */       children.add(this._objComputerMeass);
/*      */     }
/* 1167 */     if (this._objPivots != null) {
/* 1168 */       children.add(this._objPivots);
/*      */     }
/* 1170 */     if (this._objFetchData != null)
/* 1171 */       children.add(this._objFetchData);
/* 1172 */     return children;
/*      */   }
/*      */ 
/*      */   public String get_TagName()
/*      */   {
/* 1181 */     return _tagName;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.CrossGridDefine
 * JD-Core Version:    0.5.4
 */