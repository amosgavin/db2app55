/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.EmptyElement;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ 
/*     */ public class Pivot extends EmptyElement
/*     */ {
/*  16 */   public static String _tagName = "Pivot";
/*     */ 
/*  18 */   public Attribute order = new Attribute("order", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  20 */   public Attribute isSuppress = new Attribute("isSuppress", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  22 */   public Attribute selectValueIndex = new Attribute("selectValueIndex", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  24 */   public Attribute area = new Attribute("area", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  26 */   public Attribute isSubtotal = new Attribute("isSubtotal", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  28 */   public Attribute dimName = new Attribute("dimName", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Pivot()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Pivot(boolean state)
/*     */   {
/*  44 */     super(state);
/*     */   }
/*     */ 
/*     */   public String getOrder()
/*     */   {
/*  52 */     return this.order.getValue();
/*     */   }
/*     */ 
/*     */   public void setOrder(String value_)
/*     */   {
/*  61 */     this.order.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getIsSuppress()
/*     */   {
/*  69 */     return this.isSuppress.getValue();
/*     */   }
/*     */ 
/*     */   public void setIsSuppress(String value_)
/*     */   {
/*  78 */     this.isSuppress.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getSelectValueIndex()
/*     */   {
/*  86 */     return this.selectValueIndex.getValue();
/*     */   }
/*     */ 
/*     */   public void setSelectValueIndex(String value_)
/*     */   {
/*  95 */     this.selectValueIndex.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getArea()
/*     */   {
/* 103 */     return this.area.getValue();
/*     */   }
/*     */ 
/*     */   public void setArea(String value_)
/*     */   {
/* 112 */     this.area.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getIsSubtotal()
/*     */   {
/* 120 */     return this.isSubtotal.getValue();
/*     */   }
/*     */ 
/*     */   public void setIsSubtotal(String value_)
/*     */   {
/* 129 */     this.isSubtotal.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getDimName()
/*     */   {
/* 137 */     return this.dimName.getValue();
/*     */   }
/*     */ 
/*     */   public void setDimName(String value_)
/*     */   {
/* 146 */     this.dimName.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 154 */     Element elem = super.marshal();
/*     */ 
/* 156 */     elem.addAttribute(this.order.marshal());
/*     */ 
/* 158 */     elem.addAttribute(this.isSuppress.marshal());
/*     */ 
/* 160 */     elem.addAttribute(this.selectValueIndex.marshal());
/*     */ 
/* 162 */     elem.addAttribute(this.area.marshal());
/*     */ 
/* 164 */     elem.addAttribute(this.isSubtotal.marshal());
/*     */ 
/* 166 */     elem.addAttribute(this.dimName.marshal());
/* 167 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Pivot unmarshal(Element elem)
/*     */   {
/* 175 */     Pivot __objPivot = (Pivot)EmptyElement.unmarshal(elem, new Pivot());
/* 176 */     if (__objPivot != null)
/*     */     {
/* 179 */       __objPivot.order.setValue(elem.getAttribute("order"));
/*     */ 
/* 181 */       __objPivot.isSuppress.setValue(elem.getAttribute("isSuppress"));
/*     */ 
/* 183 */       __objPivot.selectValueIndex.setValue(elem.getAttribute("selectValueIndex"));
/*     */ 
/* 185 */       __objPivot.area.setValue(elem.getAttribute("area"));
/*     */ 
/* 187 */       __objPivot.isSubtotal.setValue(elem.getAttribute("isSubtotal"));
/*     */ 
/* 189 */       __objPivot.dimName.setValue(elem.getAttribute("dimName"));
/*     */     }
/* 191 */     return __objPivot;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 208 */     ErrorList errors = new ErrorList();
/*     */ 
/* 211 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 220 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Pivot
 * JD-Core Version:    0.5.4
 */