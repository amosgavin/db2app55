/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Arglist extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "arglist";
/*     */ 
/*  20 */   protected ArrayList _objArg = new ArrayList();
/*     */ 
/*     */   public Arg[] getArg()
/*     */   {
/*  36 */     return (Arg[])(Arg[])this._objArg.toArray(new Arg[0]);
/*     */   }
/*     */ 
/*     */   public void setArg(Arg[] objArray)
/*     */   {
/*  46 */     if ((objArray == null) || (objArray.length == 0)) {
/*  47 */       this._objArg.clear();
/*     */     }
/*     */     else {
/*  50 */       this._objArg = new ArrayList(Arrays.asList(objArray));
/*  51 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  53 */         if (objArray[i] != null)
/*  54 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Arg getArg(int index)
/*     */   {
/*  66 */     return (Arg)this._objArg.get(index);
/*     */   }
/*     */ 
/*     */   public void setArg(int index, Arg obj)
/*     */   {
/*  77 */     if (obj == null) {
/*  78 */       removeArg(index);
/*     */     }
/*     */     else {
/*  81 */       this._objArg.set(index, obj);
/*  82 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getArgCount()
/*     */   {
/*  91 */     return this._objArg.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoArg()
/*     */   {
/* 100 */     return this._objArg.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getArgList()
/*     */   {
/* 108 */     return Collections.unmodifiableList(this._objArg);
/*     */   }
/*     */ 
/*     */   public boolean addArg(Arg obj)
/*     */   {
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     obj._setParent(this);
/* 122 */     return this._objArg.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addArg(Collection coArg)
/*     */   {
/* 132 */     if (coArg == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Iterator it = coArg.iterator();
/* 136 */     while (it.hasNext())
/*     */     {
/* 138 */       Object obj = it.next();
/* 139 */       if ((obj != null) && (obj instanceof XmlObject))
/* 140 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 142 */     return this._objArg.addAll(coArg);
/*     */   }
/*     */ 
/*     */   public Arg removeArg(int index)
/*     */   {
/* 151 */     return (Arg)this._objArg.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeArg(Arg obj)
/*     */   {
/* 161 */     return this._objArg.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearArgList()
/*     */   {
/* 169 */     this._objArg.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 177 */     Element elem = new Element(get_TagName());
/*     */ 
/* 179 */     Iterator it1 = this._objArg.iterator();
/* 180 */     while (it1.hasNext())
/*     */     {
/* 182 */       Arg obj = (Arg)it1.next();
/* 183 */       if (obj != null)
/*     */       {
/* 185 */         elem.addComment(obj._marshalCommentList());
/* 186 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 190 */     elem.addComment(_marshalBottomCommentList());
/* 191 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Arglist unmarshal(Element elem)
/*     */   {
/* 199 */     if (elem == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     Arglist __objArglist = new Arglist();
/*     */ 
/* 204 */     ArrayList __comments = null;
/* 205 */     Iterator it = elem.getChildObjects().iterator();
/* 206 */     while (it.hasNext())
/*     */     {
/* 208 */       Object __obj = it.next();
/* 209 */       if (__obj instanceof Comment)
/*     */       {
/* 211 */         if (__comments == null) {
/* 212 */           __comments = new ArrayList(2);
/*     */         }
/* 214 */         __comments.add(__obj);
/*     */       }
/* 216 */       else if (__obj instanceof Element)
/*     */       {
/* 218 */         Element __e = (Element)__obj;
/* 219 */         String __name = __e.getName();
/* 220 */         if (__name.equals(Arg._tagName))
/*     */         {
/* 223 */           Arg __objArg = Arg.unmarshal(__e);
/* 224 */           __objArglist.addArg(__objArg);
/* 225 */           __objArg._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 228 */         __comments = null;
/*     */       }
/*     */     }
/* 231 */     __objArglist._unmarshalBottomCommentList(__comments);
/* 232 */     return __objArglist;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 249 */     ErrorList errors = new ErrorList();
/*     */ 
/* 252 */     if (this._objArg.size() == 0)
/*     */     {
/* 254 */       errors.add(new ElementError(this, Arg.class));
/* 255 */       if (firstError)
/* 256 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 260 */       Iterator it1 = this._objArg.iterator();
/* 261 */       while (it1.hasNext())
/*     */       {
/* 263 */         Arg obj = (Arg)it1.next();
/* 264 */         if (obj != null)
/*     */         {
/* 266 */           errors.add(obj.validate(firstError));
/* 267 */           if ((firstError) && (errors.size() > 0)) {
/* 268 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 282 */     List children = new ArrayList();
/*     */ 
/* 284 */     if ((this._objArg != null) && (this._objArg.size() > 0))
/* 285 */       children.add(this._objArg);
/* 286 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 295 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Arglist
 * JD-Core Version:    0.5.4
 */