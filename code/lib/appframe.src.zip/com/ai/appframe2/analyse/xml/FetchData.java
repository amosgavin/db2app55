/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class FetchData extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "FetchData";
/*     */   protected Arglist _objArglist;
/*     */   protected Sql _objSql;
/*     */ 
/*     */   public Arglist getArglist()
/*     */   {
/*  37 */     return this._objArglist;
/*     */   }
/*     */ 
/*     */   public void setArglist(Arglist obj)
/*     */   {
/*  48 */     this._objArglist = obj;
/*  49 */     if (obj == null) {
/*  50 */       return;
/*     */     }
/*  52 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public String getSqlText()
/*     */   {
/*  59 */     return (this._objSql == null) ? null : this._objSql.getText();
/*     */   }
/*     */ 
/*     */   public void setSqlText(String text)
/*     */   {
/*  70 */     if (text == null)
/*     */     {
/*  72 */       this._objSql = null;
/*  73 */       return;
/*     */     }
/*     */ 
/*  76 */     if (this._objSql == null) {
/*  77 */       this._objSql = new Sql();
/*     */     }
/*  79 */     this._objSql.setText(text);
/*  80 */     this._objSql._setParent(this);
/*     */   }
/*     */ 
/*     */   public Sql getSql()
/*     */   {
/*  88 */     return this._objSql;
/*     */   }
/*     */ 
/*     */   public void setSql(Sql obj)
/*     */   {
/*  99 */     this._objSql = obj;
/* 100 */     if (obj == null) {
/* 101 */       return;
/*     */     }
/* 103 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 111 */     Element elem = new Element(get_TagName());
/*     */ 
/* 113 */     if (this._objArglist != null)
/*     */     {
/* 115 */       elem.addComment(this._objArglist._marshalCommentList());
/* 116 */       elem.addContent(this._objArglist.marshal());
/*     */     }
/*     */ 
/* 119 */     if (this._objSql != null)
/*     */     {
/* 121 */       elem.addComment(this._objSql._marshalCommentList());
/* 122 */       elem.addContent(this._objSql.marshal());
/*     */     }
/*     */ 
/* 125 */     elem.addComment(_marshalBottomCommentList());
/* 126 */     return elem;
/*     */   }
/*     */ 
/*     */   public static FetchData unmarshal(Element elem)
/*     */   {
/* 134 */     if (elem == null) {
/* 135 */       return null;
/*     */     }
/* 137 */     FetchData __objFetchData = new FetchData();
/*     */ 
/* 139 */     ArrayList __comments = null;
/* 140 */     Iterator it = elem.getChildObjects().iterator();
/* 141 */     while (it.hasNext())
/*     */     {
/* 143 */       Object __obj = it.next();
/* 144 */       if (__obj instanceof Comment)
/*     */       {
/* 146 */         if (__comments == null) {
/* 147 */           __comments = new ArrayList(2);
/*     */         }
/* 149 */         __comments.add(__obj);
/*     */       }
/* 151 */       else if (__obj instanceof Element)
/*     */       {
/* 153 */         Element __e = (Element)__obj;
/* 154 */         String __name = __e.getName();
/* 155 */         if (__name.equals(Arglist._tagName))
/*     */         {
/* 158 */           Arglist __objArglist = Arglist.unmarshal(__e);
/* 159 */           __objFetchData.setArglist(__objArglist);
/* 160 */           __objArglist._unmarshalCommentList(__comments);
/*     */         }
/* 162 */         if (__name.equals(Sql._tagName))
/*     */         {
/* 165 */           Sql __objSql = Sql.unmarshal(__e);
/* 166 */           __objFetchData.setSql(__objSql);
/* 167 */           __objSql._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 170 */         __comments = null;
/*     */       }
/*     */     }
/* 173 */     __objFetchData._unmarshalBottomCommentList(__comments);
/* 174 */     return __objFetchData;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 191 */     ErrorList errors = new ErrorList();
/*     */ 
/* 194 */     if (this._objArglist != null)
/* 195 */       errors.add(this._objArglist.validate(firstError));
/*     */     else
/* 197 */       errors.add(new ElementError(this, Arglist.class));
/* 198 */     if ((firstError) && (errors.size() > 0)) {
/* 199 */       return errors;
/*     */     }
/* 201 */     if (this._objSql != null)
/* 202 */       errors.add(this._objSql.validate(firstError));
/*     */     else
/* 204 */       errors.add(new ElementError(this, Sql.class));
/* 205 */     if ((firstError) && (errors.size() > 0)) {
/* 206 */       return errors;
/*     */     }
/* 208 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 217 */     List children = new ArrayList();
/*     */ 
/* 219 */     if (this._objArglist != null) {
/* 220 */       children.add(this._objArglist);
/*     */     }
/* 222 */     if (this._objSql != null)
/* 223 */       children.add(this._objSql);
/* 224 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 233 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.FetchData
 * JD-Core Version:    0.5.4
 */