/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.EmptyElement;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ 
/*     */ public class Arg extends EmptyElement
/*     */ {
/*  16 */   public static String _tagName = "arg";
/*     */ 
/*  18 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  20 */   public Attribute datatype = new Attribute("datatype", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Arg()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Arg(boolean state)
/*     */   {
/*  36 */     super(state);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  44 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  53 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getDatatype()
/*     */   {
/*  61 */     return this.datatype.getValue();
/*     */   }
/*     */ 
/*     */   public void setDatatype(String value_)
/*     */   {
/*  70 */     this.datatype.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/*  78 */     Element elem = super.marshal();
/*     */ 
/*  80 */     elem.addAttribute(this.name.marshal());
/*     */ 
/*  82 */     elem.addAttribute(this.datatype.marshal());
/*  83 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Arg unmarshal(Element elem)
/*     */   {
/*  91 */     Arg __objArg = (Arg)EmptyElement.unmarshal(elem, new Arg());
/*  92 */     if (__objArg != null)
/*     */     {
/*  95 */       __objArg.name.setValue(elem.getAttribute("name"));
/*     */ 
/*  97 */       __objArg.datatype.setValue(elem.getAttribute("datatype"));
/*     */     }
/*  99 */     return __objArg;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 116 */     ErrorList errors = new ErrorList();
/*     */ 
/* 119 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 128 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Arg
 * JD-Core Version:    0.5.4
 */