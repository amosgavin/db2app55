/*    */ package com.ai.appframe2.analyse.xml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class RootElement extends TextElement
/*    */ {
/* 16 */   public static String _tagName = "root-element";
/*    */ 
/*    */   public RootElement()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RootElement(String text)
/*    */   {
/* 31 */     super(text);
/*    */   }
/*    */ 
/*    */   public static RootElement unmarshal(Element elem)
/*    */   {
/* 40 */     RootElement __objRootElement = (RootElement)TextElement.unmarshal(elem, new RootElement());
/* 41 */     return __objRootElement;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 51 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.RootElement
 * JD-Core Version:    0.5.4
 */