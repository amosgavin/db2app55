/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Meass extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "Meass";
/*     */ 
/*  20 */   protected ArrayList _objMeas = new ArrayList();
/*     */ 
/*     */   public Meas[] getMeas()
/*     */   {
/*  36 */     return (Meas[])(Meas[])this._objMeas.toArray(new Meas[0]);
/*     */   }
/*     */ 
/*     */   public void setMeas(Meas[] objArray)
/*     */   {
/*  46 */     if ((objArray == null) || (objArray.length == 0)) {
/*  47 */       this._objMeas.clear();
/*     */     }
/*     */     else {
/*  50 */       this._objMeas = new ArrayList(Arrays.asList(objArray));
/*  51 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  53 */         if (objArray[i] != null)
/*  54 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Meas getMeas(int index)
/*     */   {
/*  66 */     return (Meas)this._objMeas.get(index);
/*     */   }
/*     */ 
/*     */   public void setMeas(int index, Meas obj)
/*     */   {
/*  77 */     if (obj == null) {
/*  78 */       removeMeas(index);
/*     */     }
/*     */     else {
/*  81 */       this._objMeas.set(index, obj);
/*  82 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMeasCount()
/*     */   {
/*  91 */     return this._objMeas.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoMeas()
/*     */   {
/* 100 */     return this._objMeas.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getMeasList()
/*     */   {
/* 108 */     return Collections.unmodifiableList(this._objMeas);
/*     */   }
/*     */ 
/*     */   public boolean addMeas(Meas obj)
/*     */   {
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     obj._setParent(this);
/* 122 */     return this._objMeas.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addMeas(Collection coMeas)
/*     */   {
/* 132 */     if (coMeas == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Iterator it = coMeas.iterator();
/* 136 */     while (it.hasNext())
/*     */     {
/* 138 */       Object obj = it.next();
/* 139 */       if ((obj != null) && (obj instanceof XmlObject))
/* 140 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 142 */     return this._objMeas.addAll(coMeas);
/*     */   }
/*     */ 
/*     */   public Meas removeMeas(int index)
/*     */   {
/* 151 */     return (Meas)this._objMeas.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeMeas(Meas obj)
/*     */   {
/* 161 */     return this._objMeas.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearMeasList()
/*     */   {
/* 169 */     this._objMeas.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 177 */     Element elem = new Element(get_TagName());
/*     */ 
/* 179 */     Iterator it1 = this._objMeas.iterator();
/* 180 */     while (it1.hasNext())
/*     */     {
/* 182 */       Meas obj = (Meas)it1.next();
/* 183 */       if (obj != null)
/*     */       {
/* 185 */         elem.addComment(obj._marshalCommentList());
/* 186 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 190 */     elem.addComment(_marshalBottomCommentList());
/* 191 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Meass unmarshal(Element elem)
/*     */   {
/* 199 */     if (elem == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     Meass __objMeass = new Meass();
/*     */ 
/* 204 */     ArrayList __comments = null;
/* 205 */     Iterator it = elem.getChildObjects().iterator();
/* 206 */     while (it.hasNext())
/*     */     {
/* 208 */       Object __obj = it.next();
/* 209 */       if (__obj instanceof Comment)
/*     */       {
/* 211 */         if (__comments == null) {
/* 212 */           __comments = new ArrayList(2);
/*     */         }
/* 214 */         __comments.add(__obj);
/*     */       }
/* 216 */       else if (__obj instanceof Element)
/*     */       {
/* 218 */         Element __e = (Element)__obj;
/* 219 */         String __name = __e.getName();
/* 220 */         if (__name.equals(Meas._tagName))
/*     */         {
/* 223 */           Meas __objMeas = Meas.unmarshal(__e);
/* 224 */           __objMeass.addMeas(__objMeas);
/* 225 */           __objMeas._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 228 */         __comments = null;
/*     */       }
/*     */     }
/* 231 */     __objMeass._unmarshalBottomCommentList(__comments);
/* 232 */     return __objMeass;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 249 */     ErrorList errors = new ErrorList();
/*     */ 
/* 252 */     if (this._objMeas.size() == 0)
/*     */     {
/* 254 */       errors.add(new ElementError(this, Meas.class));
/* 255 */       if (firstError)
/* 256 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 260 */       Iterator it1 = this._objMeas.iterator();
/* 261 */       while (it1.hasNext())
/*     */       {
/* 263 */         Meas obj = (Meas)it1.next();
/* 264 */         if (obj != null)
/*     */         {
/* 266 */           errors.add(obj.validate(firstError));
/* 267 */           if ((firstError) && (errors.size() > 0)) {
/* 268 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 282 */     List children = new ArrayList();
/*     */ 
/* 284 */     if ((this._objMeas != null) && (this._objMeas.size() > 0))
/* 285 */       children.add(this._objMeas);
/* 286 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 295 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Meass
 * JD-Core Version:    0.5.4
 */