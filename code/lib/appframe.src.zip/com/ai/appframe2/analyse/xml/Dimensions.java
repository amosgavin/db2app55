/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Dimensions extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "Dimensions";
/*     */ 
/*  20 */   protected ArrayList _objDimension = new ArrayList();
/*     */ 
/*     */   public Dimension[] getDimension()
/*     */   {
/*  36 */     return (Dimension[])(Dimension[])this._objDimension.toArray(new Dimension[0]);
/*     */   }
/*     */ 
/*     */   public void setDimension(Dimension[] objArray)
/*     */   {
/*  46 */     if ((objArray == null) || (objArray.length == 0)) {
/*  47 */       this._objDimension.clear();
/*     */     }
/*     */     else {
/*  50 */       this._objDimension = new ArrayList(Arrays.asList(objArray));
/*  51 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  53 */         if (objArray[i] != null)
/*  54 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Dimension getDimension(int index)
/*     */   {
/*  66 */     return (Dimension)this._objDimension.get(index);
/*     */   }
/*     */ 
/*     */   public void setDimension(int index, Dimension obj)
/*     */   {
/*  77 */     if (obj == null) {
/*  78 */       removeDimension(index);
/*     */     }
/*     */     else {
/*  81 */       this._objDimension.set(index, obj);
/*  82 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getDimensionCount()
/*     */   {
/*  91 */     return this._objDimension.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoDimension()
/*     */   {
/* 100 */     return this._objDimension.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getDimensionList()
/*     */   {
/* 108 */     return Collections.unmodifiableList(this._objDimension);
/*     */   }
/*     */ 
/*     */   public boolean addDimension(Dimension obj)
/*     */   {
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     obj._setParent(this);
/* 122 */     return this._objDimension.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addDimension(Collection coDimension)
/*     */   {
/* 132 */     if (coDimension == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Iterator it = coDimension.iterator();
/* 136 */     while (it.hasNext())
/*     */     {
/* 138 */       Object obj = it.next();
/* 139 */       if ((obj != null) && (obj instanceof XmlObject))
/* 140 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 142 */     return this._objDimension.addAll(coDimension);
/*     */   }
/*     */ 
/*     */   public Dimension removeDimension(int index)
/*     */   {
/* 151 */     return (Dimension)this._objDimension.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeDimension(Dimension obj)
/*     */   {
/* 161 */     return this._objDimension.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearDimensionList()
/*     */   {
/* 169 */     this._objDimension.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 177 */     Element elem = new Element(get_TagName());
/*     */ 
/* 179 */     Iterator it1 = this._objDimension.iterator();
/* 180 */     while (it1.hasNext())
/*     */     {
/* 182 */       Dimension obj = (Dimension)it1.next();
/* 183 */       if (obj != null)
/*     */       {
/* 185 */         elem.addComment(obj._marshalCommentList());
/* 186 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 190 */     elem.addComment(_marshalBottomCommentList());
/* 191 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Dimensions unmarshal(Element elem)
/*     */   {
/* 199 */     if (elem == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     Dimensions __objDimensions = new Dimensions();
/*     */ 
/* 204 */     ArrayList __comments = null;
/* 205 */     Iterator it = elem.getChildObjects().iterator();
/* 206 */     while (it.hasNext())
/*     */     {
/* 208 */       Object __obj = it.next();
/* 209 */       if (__obj instanceof Comment)
/*     */       {
/* 211 */         if (__comments == null) {
/* 212 */           __comments = new ArrayList(2);
/*     */         }
/* 214 */         __comments.add(__obj);
/*     */       }
/* 216 */       else if (__obj instanceof Element)
/*     */       {
/* 218 */         Element __e = (Element)__obj;
/* 219 */         String __name = __e.getName();
/* 220 */         if (__name.equals(Dimension._tagName))
/*     */         {
/* 223 */           Dimension __objDimension = Dimension.unmarshal(__e);
/* 224 */           __objDimensions.addDimension(__objDimension);
/* 225 */           __objDimension._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 228 */         __comments = null;
/*     */       }
/*     */     }
/* 231 */     __objDimensions._unmarshalBottomCommentList(__comments);
/* 232 */     return __objDimensions;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 249 */     ErrorList errors = new ErrorList();
/*     */ 
/* 252 */     if (this._objDimension.size() == 0)
/*     */     {
/* 254 */       errors.add(new ElementError(this, Dimension.class));
/* 255 */       if (firstError)
/* 256 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 260 */       Iterator it1 = this._objDimension.iterator();
/* 261 */       while (it1.hasNext())
/*     */       {
/* 263 */         Dimension obj = (Dimension)it1.next();
/* 264 */         if (obj != null)
/*     */         {
/* 266 */           errors.add(obj.validate(firstError));
/* 267 */           if ((firstError) && (errors.size() > 0)) {
/* 268 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 282 */     List children = new ArrayList();
/*     */ 
/* 284 */     if ((this._objDimension != null) && (this._objDimension.size() > 0))
/* 285 */       children.add(this._objDimension);
/* 286 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 295 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Dimensions
 * JD-Core Version:    0.5.4
 */