/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.EmptyElement;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ 
/*     */ public class ComputerMeas extends EmptyElement
/*     */ {
/*  16 */   public static String _tagName = "ComputerMeas";
/*     */ 
/*  18 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  20 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  22 */   public Attribute canSubTotal = new Attribute("canSubTotal", "NMTOKEN", "REQUIRED", "");
/*  23 */   public Attribute subTotalType = new Attribute("subTotalType", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  25 */   public Attribute formual = new Attribute("formual", "CDATA", "REQUIRED", "");
/*     */ 
/*     */   public ComputerMeas()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ComputerMeas(boolean state)
/*     */   {
/*  41 */     super(state);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  49 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  58 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  66 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  75 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getCanSubTotal()
/*     */   {
/*  83 */     return this.canSubTotal.getValue();
/*     */   }
/*     */ 
/*     */   public String getSubTotalType() {
/*  87 */     return this.subTotalType.getValue();
/*     */   }
/*     */ 
/*     */   public void setCanSubTotal(String value_)
/*     */   {
/*  97 */     this.canSubTotal.setValue(value_);
/*     */   }
/*     */ 
/*     */   public void setSubTotalType(String value_) {
/* 101 */     this.subTotalType.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getFormual()
/*     */   {
/* 109 */     return this.formual.getValue();
/*     */   }
/*     */ 
/*     */   public void setFormual(String value_)
/*     */   {
/* 118 */     this.formual.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 126 */     Element elem = super.marshal();
/*     */ 
/* 128 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 130 */     elem.addAttribute(this.type.marshal());
/*     */ 
/* 132 */     elem.addAttribute(this.canSubTotal.marshal());
/* 133 */     elem.addAttribute(this.subTotalType.marshal());
/*     */ 
/* 135 */     elem.addAttribute(this.formual.marshal());
/* 136 */     return elem;
/*     */   }
/*     */ 
/*     */   public static ComputerMeas unmarshal(Element elem)
/*     */   {
/* 144 */     ComputerMeas __objComputerMeas = (ComputerMeas)EmptyElement.unmarshal(elem, new ComputerMeas());
/* 145 */     if (__objComputerMeas != null)
/*     */     {
/* 148 */       __objComputerMeas.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 150 */       __objComputerMeas.type.setValue(elem.getAttribute("type"));
/*     */ 
/* 152 */       __objComputerMeas.canSubTotal.setValue(elem.getAttribute("canSubTotal"));
/* 153 */       __objComputerMeas.subTotalType.setValue(elem.getAttribute("subTotalType"));
/*     */ 
/* 155 */       __objComputerMeas.formual.setValue(elem.getAttribute("formual"));
/*     */     }
/* 157 */     return __objComputerMeas;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 174 */     ErrorList errors = new ErrorList();
/*     */ 
/* 177 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 186 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.ComputerMeas
 * JD-Core Version:    0.5.4
 */