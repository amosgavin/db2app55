/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.EmptyElement;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ 
/*     */ public class Meas extends EmptyElement
/*     */ {
/*  16 */   public static String _tagName = "Meas";
/*     */ 
/*  18 */   public Attribute attr = new Attribute("attr", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  20 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  22 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  24 */   public Attribute canSubTotal = new Attribute("canSubTotal", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Meas()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Meas(boolean state)
/*     */   {
/*  40 */     super(state);
/*     */   }
/*     */ 
/*     */   public String getAttr()
/*     */   {
/*  48 */     return this.attr.getValue();
/*     */   }
/*     */ 
/*     */   public void setAttr(String value_)
/*     */   {
/*  57 */     this.attr.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  65 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  74 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  82 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  91 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getCanSubTotal()
/*     */   {
/*  99 */     return this.canSubTotal.getValue();
/*     */   }
/*     */ 
/*     */   public void setCanSubTotal(String value_)
/*     */   {
/* 108 */     this.canSubTotal.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 116 */     Element elem = super.marshal();
/*     */ 
/* 118 */     elem.addAttribute(this.attr.marshal());
/*     */ 
/* 120 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 122 */     elem.addAttribute(this.type.marshal());
/*     */ 
/* 124 */     elem.addAttribute(this.canSubTotal.marshal());
/* 125 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Meas unmarshal(Element elem)
/*     */   {
/* 133 */     Meas __objMeas = (Meas)EmptyElement.unmarshal(elem, new Meas());
/* 134 */     if (__objMeas != null)
/*     */     {
/* 137 */       __objMeas.attr.setValue(elem.getAttribute("attr"));
/*     */ 
/* 139 */       __objMeas.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 141 */       __objMeas.type.setValue(elem.getAttribute("type"));
/*     */ 
/* 143 */       __objMeas.canSubTotal.setValue(elem.getAttribute("canSubTotal"));
/*     */     }
/* 145 */     return __objMeas;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 162 */     ErrorList errors = new ErrorList();
/*     */ 
/* 165 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 174 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Meas
 * JD-Core Version:    0.5.4
 */