/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ComputerMeass extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "ComputerMeass";
/*     */ 
/*  20 */   protected ArrayList _objComputerMeas = new ArrayList();
/*     */ 
/*     */   public ComputerMeas[] getComputerMeas()
/*     */   {
/*  36 */     return (ComputerMeas[])(ComputerMeas[])this._objComputerMeas.toArray(new ComputerMeas[0]);
/*     */   }
/*     */ 
/*     */   public void setComputerMeas(ComputerMeas[] objArray)
/*     */   {
/*  46 */     if ((objArray == null) || (objArray.length == 0)) {
/*  47 */       this._objComputerMeas.clear();
/*     */     }
/*     */     else {
/*  50 */       this._objComputerMeas = new ArrayList(Arrays.asList(objArray));
/*  51 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  53 */         if (objArray[i] != null)
/*  54 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public ComputerMeas getComputerMeas(int index)
/*     */   {
/*  66 */     return (ComputerMeas)this._objComputerMeas.get(index);
/*     */   }
/*     */ 
/*     */   public void setComputerMeas(int index, ComputerMeas obj)
/*     */   {
/*  77 */     if (obj == null) {
/*  78 */       removeComputerMeas(index);
/*     */     }
/*     */     else {
/*  81 */       this._objComputerMeas.set(index, obj);
/*  82 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getComputerMeasCount()
/*     */   {
/*  91 */     return this._objComputerMeas.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoComputerMeas()
/*     */   {
/* 100 */     return this._objComputerMeas.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getComputerMeasList()
/*     */   {
/* 108 */     return Collections.unmodifiableList(this._objComputerMeas);
/*     */   }
/*     */ 
/*     */   public boolean addComputerMeas(ComputerMeas obj)
/*     */   {
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     obj._setParent(this);
/* 122 */     return this._objComputerMeas.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addComputerMeas(Collection coComputerMeas)
/*     */   {
/* 132 */     if (coComputerMeas == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Iterator it = coComputerMeas.iterator();
/* 136 */     while (it.hasNext())
/*     */     {
/* 138 */       Object obj = it.next();
/* 139 */       if ((obj != null) && (obj instanceof XmlObject))
/* 140 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 142 */     return this._objComputerMeas.addAll(coComputerMeas);
/*     */   }
/*     */ 
/*     */   public ComputerMeas removeComputerMeas(int index)
/*     */   {
/* 151 */     return (ComputerMeas)this._objComputerMeas.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeComputerMeas(ComputerMeas obj)
/*     */   {
/* 161 */     return this._objComputerMeas.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearComputerMeasList()
/*     */   {
/* 169 */     this._objComputerMeas.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 177 */     Element elem = new Element(get_TagName());
/*     */ 
/* 179 */     Iterator it1 = this._objComputerMeas.iterator();
/* 180 */     while (it1.hasNext())
/*     */     {
/* 182 */       ComputerMeas obj = (ComputerMeas)it1.next();
/* 183 */       if (obj != null)
/*     */       {
/* 185 */         elem.addComment(obj._marshalCommentList());
/* 186 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 190 */     elem.addComment(_marshalBottomCommentList());
/* 191 */     return elem;
/*     */   }
/*     */ 
/*     */   public static ComputerMeass unmarshal(Element elem)
/*     */   {
/* 199 */     if (elem == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     ComputerMeass __objComputerMeass = new ComputerMeass();
/*     */ 
/* 204 */     ArrayList __comments = null;
/* 205 */     Iterator it = elem.getChildObjects().iterator();
/* 206 */     while (it.hasNext())
/*     */     {
/* 208 */       Object __obj = it.next();
/* 209 */       if (__obj instanceof Comment)
/*     */       {
/* 211 */         if (__comments == null) {
/* 212 */           __comments = new ArrayList(2);
/*     */         }
/* 214 */         __comments.add(__obj);
/*     */       }
/* 216 */       else if (__obj instanceof Element)
/*     */       {
/* 218 */         Element __e = (Element)__obj;
/* 219 */         String __name = __e.getName();
/* 220 */         if (__name.equals(ComputerMeas._tagName))
/*     */         {
/* 223 */           ComputerMeas __objComputerMeas = ComputerMeas.unmarshal(__e);
/* 224 */           __objComputerMeass.addComputerMeas(__objComputerMeas);
/* 225 */           __objComputerMeas._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 228 */         __comments = null;
/*     */       }
/*     */     }
/* 231 */     __objComputerMeass._unmarshalBottomCommentList(__comments);
/* 232 */     return __objComputerMeass;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 249 */     ErrorList errors = new ErrorList();
/*     */ 
/* 252 */     if (this._objComputerMeas.size() == 0)
/*     */     {
/* 254 */       errors.add(new ElementError(this, ComputerMeas.class));
/* 255 */       if (firstError)
/* 256 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 260 */       Iterator it1 = this._objComputerMeas.iterator();
/* 261 */       while (it1.hasNext())
/*     */       {
/* 263 */         ComputerMeas obj = (ComputerMeas)it1.next();
/* 264 */         if (obj != null)
/*     */         {
/* 266 */           errors.add(obj.validate(firstError));
/* 267 */           if ((firstError) && (errors.size() > 0)) {
/* 268 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 282 */     List children = new ArrayList();
/*     */ 
/* 284 */     if ((this._objComputerMeas != null) && (this._objComputerMeas.size() > 0))
/* 285 */       children.add(this._objComputerMeas);
/* 286 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 295 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.ComputerMeass
 * JD-Core Version:    0.5.4
 */