/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.EmptyElement;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ 
/*     */ public class Dimension extends EmptyElement
/*     */ {
/*  16 */   public static String _tagName = "Dimension";
/*     */ 
/*  18 */   public Attribute attr = new Attribute("attr", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  20 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  22 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Dimension()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Dimension(boolean state)
/*     */   {
/*  38 */     super(state);
/*     */   }
/*     */ 
/*     */   public String getAttr()
/*     */   {
/*  46 */     return this.attr.getValue();
/*     */   }
/*     */ 
/*     */   public void setAttr(String value_)
/*     */   {
/*  55 */     this.attr.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  63 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  72 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  80 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  89 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/*  97 */     Element elem = super.marshal();
/*     */ 
/*  99 */     elem.addAttribute(this.attr.marshal());
/*     */ 
/* 101 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 103 */     elem.addAttribute(this.type.marshal());
/* 104 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Dimension unmarshal(Element elem)
/*     */   {
/* 112 */     Dimension __objDimension = (Dimension)EmptyElement.unmarshal(elem, new Dimension());
/* 113 */     if (__objDimension != null)
/*     */     {
/* 116 */       __objDimension.attr.setValue(elem.getAttribute("attr"));
/*     */ 
/* 118 */       __objDimension.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 120 */       __objDimension.type.setValue(elem.getAttribute("type"));
/*     */     }
/* 122 */     return __objDimension;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 139 */     ErrorList errors = new ErrorList();
/*     */ 
/* 142 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 151 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Dimension
 * JD-Core Version:    0.5.4
 */