/*     */ package com.ai.appframe2.analyse.xml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Pivots extends XmlObject
/*     */ {
/*  18 */   public static String _tagName = "Pivots";
/*     */ 
/*  20 */   protected ArrayList _objPivot = new ArrayList();
/*     */ 
/*     */   public Pivot[] getPivot()
/*     */   {
/*  36 */     return (Pivot[])(Pivot[])this._objPivot.toArray(new Pivot[0]);
/*     */   }
/*     */ 
/*     */   public void setPivot(Pivot[] objArray)
/*     */   {
/*  46 */     if ((objArray == null) || (objArray.length == 0)) {
/*  47 */       this._objPivot.clear();
/*     */     }
/*     */     else {
/*  50 */       this._objPivot = new ArrayList(Arrays.asList(objArray));
/*  51 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  53 */         if (objArray[i] != null)
/*  54 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Pivot getPivot(int index)
/*     */   {
/*  66 */     return (Pivot)this._objPivot.get(index);
/*     */   }
/*     */ 
/*     */   public void setPivot(int index, Pivot obj)
/*     */   {
/*  77 */     if (obj == null) {
/*  78 */       removePivot(index);
/*     */     }
/*     */     else {
/*  81 */       this._objPivot.set(index, obj);
/*  82 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getPivotCount()
/*     */   {
/*  91 */     return this._objPivot.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoPivot()
/*     */   {
/* 100 */     return this._objPivot.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getPivotList()
/*     */   {
/* 108 */     return Collections.unmodifiableList(this._objPivot);
/*     */   }
/*     */ 
/*     */   public boolean addPivot(Pivot obj)
/*     */   {
/* 118 */     if (obj == null) {
/* 119 */       return false;
/*     */     }
/* 121 */     obj._setParent(this);
/* 122 */     return this._objPivot.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addPivot(Collection coPivot)
/*     */   {
/* 132 */     if (coPivot == null) {
/* 133 */       return false;
/*     */     }
/* 135 */     Iterator it = coPivot.iterator();
/* 136 */     while (it.hasNext())
/*     */     {
/* 138 */       Object obj = it.next();
/* 139 */       if ((obj != null) && (obj instanceof XmlObject))
/* 140 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 142 */     return this._objPivot.addAll(coPivot);
/*     */   }
/*     */ 
/*     */   public Pivot removePivot(int index)
/*     */   {
/* 151 */     return (Pivot)this._objPivot.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removePivot(Pivot obj)
/*     */   {
/* 161 */     return this._objPivot.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearPivotList()
/*     */   {
/* 169 */     this._objPivot.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 177 */     Element elem = new Element(get_TagName());
/*     */ 
/* 179 */     Iterator it1 = this._objPivot.iterator();
/* 180 */     while (it1.hasNext())
/*     */     {
/* 182 */       Pivot obj = (Pivot)it1.next();
/* 183 */       if (obj != null)
/*     */       {
/* 185 */         elem.addComment(obj._marshalCommentList());
/* 186 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 190 */     elem.addComment(_marshalBottomCommentList());
/* 191 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Pivots unmarshal(Element elem)
/*     */   {
/* 199 */     if (elem == null) {
/* 200 */       return null;
/*     */     }
/* 202 */     Pivots __objPivots = new Pivots();
/*     */ 
/* 204 */     ArrayList __comments = null;
/* 205 */     Iterator it = elem.getChildObjects().iterator();
/* 206 */     while (it.hasNext())
/*     */     {
/* 208 */       Object __obj = it.next();
/* 209 */       if (__obj instanceof Comment)
/*     */       {
/* 211 */         if (__comments == null) {
/* 212 */           __comments = new ArrayList(2);
/*     */         }
/* 214 */         __comments.add(__obj);
/*     */       }
/* 216 */       else if (__obj instanceof Element)
/*     */       {
/* 218 */         Element __e = (Element)__obj;
/* 219 */         String __name = __e.getName();
/* 220 */         if (__name.equals(Pivot._tagName))
/*     */         {
/* 223 */           Pivot __objPivot = Pivot.unmarshal(__e);
/* 224 */           __objPivots.addPivot(__objPivot);
/* 225 */           __objPivot._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 228 */         __comments = null;
/*     */       }
/*     */     }
/* 231 */     __objPivots._unmarshalBottomCommentList(__comments);
/* 232 */     return __objPivots;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 249 */     ErrorList errors = new ErrorList();
/*     */ 
/* 252 */     if (this._objPivot.size() == 0)
/*     */     {
/* 254 */       errors.add(new ElementError(this, Pivot.class));
/* 255 */       if (firstError)
/* 256 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 260 */       Iterator it1 = this._objPivot.iterator();
/* 261 */       while (it1.hasNext())
/*     */       {
/* 263 */         Pivot obj = (Pivot)it1.next();
/* 264 */         if (obj != null)
/*     */         {
/* 266 */           errors.add(obj.validate(firstError));
/* 267 */           if ((firstError) && (errors.size() > 0)) {
/* 268 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 273 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 282 */     List children = new ArrayList();
/*     */ 
/* 284 */     if ((this._objPivot != null) && (this._objPivot.size() > 0))
/* 285 */       children.add(this._objPivot);
/* 286 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 295 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.xml.Pivots
 * JD-Core Version:    0.5.4
 */