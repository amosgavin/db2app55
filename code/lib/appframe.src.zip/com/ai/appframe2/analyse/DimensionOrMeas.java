/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ 
/*    */ public abstract interface DimensionOrMeas
/*    */ {
/* 14 */   public static final String SUBTOTAL_DESC = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.DimensionOrMeas.subtotal");
/*    */   public static final int SORT_TYPE_DESC = -1;
/*    */   public static final int SORT_TYPE_ORGI = 0;
/*    */   public static final int SORT_TYPE_ASC = 1;
/*    */ 
/*    */   public abstract String getDesc(int paramInt);
/*    */ 
/*    */   public abstract int[] getRows(int paramInt);
/*    */ 
/*    */   public abstract String getName();
/*    */ 
/*    */   public abstract String getCode();
/*    */ 
/*    */   public abstract String getDataType(int paramInt);
/*    */ 
/*    */   public abstract int getDimDataCount();
/*    */ 
/*    */   public abstract int count();
/*    */ 
/*    */   public abstract int getRealDimIndex(int paramInt1, int paramInt2);
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.DimensionOrMeas
 * JD-Core Version:    0.5.4
 */