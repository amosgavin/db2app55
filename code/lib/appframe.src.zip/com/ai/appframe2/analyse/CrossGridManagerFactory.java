/*    */ package com.ai.appframe2.analyse;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class CrossGridManagerFactory
/*    */ {
/* 11 */   private static CrossGridManager manager = null;
/* 12 */   private static transient Log log = LogFactory.getLog(CrossGridManagerFactory.class);
/*    */ 
/*    */   public static void initial(HttpServletRequest req) throws Exception
/*    */   {
/*    */     try {
/* 17 */       manager = new CrossGridManagerImpl();
/* 18 */       manager.setContextPath(req.getContextPath());
/*    */ 
/* 20 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.initialization_OK"));
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 24 */       throw ex;
/*    */     }
/*    */   }
/*    */ 
/*    */   public static CrossGridManager getManager(HttpServletRequest req) throws Exception {
/* 28 */     if (manager == null) {
/* 29 */       initial(req);
/*    */     }
/*    */ 
/* 32 */     return manager;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridManagerFactory
 * JD-Core Version:    0.5.4
 */