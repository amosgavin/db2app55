/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.common.ChainNode;
/*     */ import com.ai.appframe2.analyse.web.tag.common.CoordinateSystem;
/*     */ import com.ai.appframe2.analyse.web.tag.common.InputData;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmlLine extends BodyTagSupport
/*     */ {
/*  16 */   private static transient Log log = LogFactory.getLog(VmlPie.class);
/*     */   private double dbBaseX;
/*     */   private double dbBaseY;
/*     */   private String strShowX;
/*     */   private double dbCellY;
/*     */   private String strShowY;
/*     */   private String strOutDiv;
/*     */   private String strPercent;
/*     */   private InputData[] arrayArrayData;
/*     */   private String strClickEventFun;
/*     */   private String strDblClickEventFun;
/*     */   private String strPieDataSourceImplClassName;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  32 */       System.out.println("Starting tag......");
/*  33 */       Writer writer = this.pageContext.getOut();
/*  34 */       String str = createBars(this.dbBaseX, this.dbBaseY, this.strShowX, this.dbCellY, this.strShowY, this.strOutDiv, this.strPercent, getArrayArrayData(), this.strClickEventFun, this.strDblClickEventFun);
/*     */ 
/*  38 */       writer.write(str);
/*  39 */       System.out.println(str);
/*     */     }
/*     */     catch (Throwable ex) {
/*  42 */       log.error(ex);
/*  43 */       ex.printStackTrace();
/*     */     }
/*  45 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  56 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createBars(double baseX, double baseY, String showX, double cellY, String showY, String outDiv, String percent, InputData[] arrayData, String clickEventFun, String dblClickEventFun)
/*     */     throws Throwable
/*     */   {
/*  77 */     String vColorHX = "blue";
/*  78 */     String vColorXX = "red";
/*  79 */     int vFontSize = 10;
/*  80 */     int vWidth = 5000;
/*  81 */     int vHeight = 5000;
/*     */ 
/*  85 */     if (baseX <= 0.0D) {
/*  86 */       baseX = 0.08D;
/*     */     }
/*  88 */     if (baseX <= 1.0D) {
/*  89 */       baseX *= vWidth;
/*     */     }
/*     */ 
/*  94 */     if (baseY <= 0.0D) {
/*  95 */       baseY = 0.08D;
/*     */     }
/*  97 */     if (baseY <= 1.0D) {
/*  98 */       baseY *= vHeight;
/*     */     }
/* 100 */     double zeroX = baseX;
/* 101 */     double zeroY = vHeight - baseY;
/* 102 */     double originFontX = 0.0D;
/* 103 */     double originFontY = zeroY;
/*     */ 
/* 106 */     if (percent == null) {
/* 107 */       percent = "100%";
/*     */     }
/*     */ 
/* 110 */     if (showX == null) {
/* 111 */       showX = " ";
/*     */     }
/* 113 */     if (showY == null) {
/* 114 */       showY = " ";
/*     */     }
/*     */ 
/* 117 */     CoordinateSystem coordinate = new CoordinateSystem(arrayData, vWidth, vHeight, vColorHX, vColorXX, vFontSize, baseX, baseY, originFontX, originFontY, cellY, percent, showX, showY, clickEventFun, dblClickEventFun);
/*     */ 
/* 119 */     ChainNode strChain = coordinate.draw();
/* 120 */     coordinate.drawLines(strChain);
/* 121 */     return strChain.toString();
/*     */   }
/*     */ 
/*     */   public InputData[] getArrayArrayData() throws Throwable
/*     */   {
/* 126 */     if (this.arrayArrayData == null) {
/* 127 */       this.arrayArrayData = CoordinateSystem.getVmlDataSource(this.strPieDataSourceImplClassName);
/*     */     }
/* 129 */     return this.arrayArrayData;
/*     */   }
/*     */ 
/*     */   public double getDbBaseX() {
/* 133 */     return this.dbBaseX;
/*     */   }
/*     */ 
/*     */   public double getDbBaseY() {
/* 137 */     return this.dbBaseY;
/*     */   }
/*     */ 
/*     */   public double getDbCellY() {
/* 141 */     return this.dbCellY;
/*     */   }
/*     */ 
/*     */   public String getStrClickEventFun() {
/* 145 */     return this.strClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrDblClickEventFun() {
/* 149 */     return this.strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrOutDiv() {
/* 153 */     return this.strOutDiv;
/*     */   }
/*     */ 
/*     */   public String getStrPercent() {
/* 157 */     return this.strPercent;
/*     */   }
/*     */ 
/*     */   public String getStrPieDataSourceImplClassName() {
/* 161 */     return this.strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public String getStrShowX() {
/* 165 */     return this.strShowX;
/*     */   }
/*     */ 
/*     */   public String getStrShowY() {
/* 169 */     return this.strShowY;
/*     */   }
/*     */ 
/*     */   public void setArrayArrayData(InputData[] arrayArrayData) {
/* 173 */     this.arrayArrayData = arrayArrayData;
/*     */   }
/*     */ 
/*     */   public void setDbBaseX(double dbBaseX) {
/* 177 */     this.dbBaseX = dbBaseX;
/*     */   }
/*     */ 
/*     */   public void setDbBaseY(double dbBaseY) {
/* 181 */     this.dbBaseY = dbBaseY;
/*     */   }
/*     */ 
/*     */   public void setDbCellY(double dbCellY) {
/* 185 */     this.dbCellY = dbCellY;
/*     */   }
/*     */ 
/*     */   public void setStrShowY(String strShowY) {
/* 189 */     if (strShowY == null)
/* 190 */       this.strShowY = "";
/*     */     else
/* 192 */       this.strShowY = strShowY;
/*     */   }
/*     */ 
/*     */   public void setStrPieDataSourceImplClassName(String strPieDataSourceImplClassName)
/*     */   {
/* 198 */     this.strPieDataSourceImplClassName = strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public void setStrShowX(String strShowX) {
/* 202 */     if (strShowX == null)
/* 203 */       this.strShowX = "";
/*     */     else
/* 205 */       this.strShowX = strShowX;
/*     */   }
/*     */ 
/*     */   public void setStrPercent(String strPercent)
/*     */   {
/* 210 */     this.strPercent = strPercent;
/*     */   }
/*     */ 
/*     */   public void setStrDblClickEventFun(String strDblClickEventFun) {
/* 214 */     this.strDblClickEventFun = strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrOutDiv(String strOutDiv) {
/* 218 */     this.strOutDiv = strOutDiv;
/*     */   }
/*     */ 
/*     */   public void setStrClickEventFun(String strClickEventFun) {
/* 222 */     this.strClickEventFun = strClickEventFun;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlLine
 * JD-Core Version:    0.5.4
 */