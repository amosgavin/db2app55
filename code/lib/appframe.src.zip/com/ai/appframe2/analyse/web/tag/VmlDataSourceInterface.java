package com.ai.appframe2.analyse.web.tag;

import com.ai.appframe2.analyse.web.tag.common.InputData;

public abstract interface VmlDataSourceInterface
{
  public abstract InputData[] getVmlData()
    throws Throwable;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlDataSourceInterface
 * JD-Core Version:    0.5.4
 */