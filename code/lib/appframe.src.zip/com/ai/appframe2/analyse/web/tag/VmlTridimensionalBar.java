/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.common.CoordinateSystem;
/*     */ import com.ai.appframe2.analyse.web.tag.common.InputData;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmlTridimensionalBar extends BodyTagSupport
/*     */ {
/*  13 */   private static transient Log log = LogFactory.getLog(VmlPie.class);
/*     */   private String strOutDiv;
/*     */   private InputData[] arrayArrayData;
/*     */   private String strClickEventFun;
/*     */   private String strDblClickEventFun;
/*     */   private String strPieDataSourceImplClassName;
/*     */   private String strTitle;
/*     */   private int intNumberPerLine;
/*     */   private String strPercent;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  27 */       System.out.println("Starting doEndTag...");
/*  28 */       Writer writer = this.pageContext.getOut();
/*  29 */       String str = createBars(this.strTitle, this.intNumberPerLine, this.strOutDiv, getArrayArrayData(), this.strClickEventFun, this.strDblClickEventFun, this.strPercent);
/*     */ 
/*  32 */       writer.write(str);
/*  33 */       System.out.println(str);
/*     */     }
/*     */     catch (Throwable ex) {
/*  36 */       log.error(ex);
/*  37 */       ex.printStackTrace();
/*     */     }
/*  39 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  50 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createBars(String strTitle, int iNumber, String outDiv, InputData[] arrayData, String clickEventFun, String dblClickEventFun, String percent)
/*     */     throws Throwable
/*     */   {
/*  68 */     String vColorHX = "blue";
/*  69 */     String vColorXX = "red";
/*  70 */     int vFontSize = 10;
/*  71 */     int vWidth = 5000;
/*  72 */     int vHeight = 5000;
/*  73 */     double baseX = 400.0D;
/*  74 */     double baseY = 400.0D;
/*  75 */     double zeroX = baseX;
/*  76 */     double zeroY = vHeight - baseY;
/*  77 */     double originFontX = 0.0D;
/*  78 */     double originFontY = zeroY;
/*     */ 
/*  80 */     String showX = " ";
/*  81 */     String showY = " ";
/*  82 */     int cellY = 0;
/*     */ 
/*  87 */     if (percent == null) {
/*  88 */       percent = "100%";
/*     */     }
/*     */ 
/*  91 */     CoordinateSystem coordinate = new CoordinateSystem(arrayData, vWidth, vHeight, vColorHX, vColorXX, vFontSize, baseX, baseY, originFontX, originFontY, cellY, percent, showX, showY, clickEventFun, dblClickEventFun);
/*     */ 
/*  93 */     int iMaxSerial = coordinate.getSerialMax();
/*  94 */     if (iMaxSerial < 1) {
/*  95 */       throw new Exception("Dimension is less than 1.The current max value is ：" + iMaxSerial);
/*     */     }
/*     */ 
/*  98 */     StringBuilder strOutputBuffer = new StringBuilder();
/*  99 */     strOutputBuffer.append("<script language=\"javascript\">").append("var objBar3D=null;").append("arrayData = new Array();").append("function DrawBar3D(){").append("var temp;");
/*     */ 
/* 105 */     if (iMaxSerial == 1) {
/* 106 */       for (int i = 0; i < this.arrayArrayData.length; ++i) {
/* 107 */         strOutputBuffer.append("temp = new Array();").append("temp.x = \"").append(this.arrayArrayData[i].x).append("\";").append("temp.y = ").append(this.arrayArrayData[i].y).append(";").append("temp.color = \"").append(this.arrayArrayData[i].color).append("\";").append("temp.toolTipText= \"").append(this.arrayArrayData[i].x).append(" ").append(this.arrayArrayData[i].y).append("\";").append("arrayData[").append(i).append("] =  temp;");
/*     */       }
/*     */ 
/* 114 */       strOutputBuffer.append("objBar3D = new VMLBar3D(arrayData,").append(this.strOutDiv).append(",").append("\"" + this.strTitle + "\"").append(",").append("\"" + this.strClickEventFun + "\"").append(",").append("\"" + this.strDblClickEventFun + "\"").append(",").append(this.intNumberPerLine).append(");");
/*     */     }
/*     */     else
/*     */     {
/* 121 */       ArrayList xArray = coordinate.getX_Array();
/* 122 */       int iLength = xArray.size();
/* 123 */       strOutputBuffer.append("var aSerialObj = new Array();").append("var aSerTitle = new Array();").append("var aSerColor = new Array();");
/*     */ 
/* 126 */       for (int i = 0; i < iMaxSerial; ++i) {
/* 127 */         for (int j = 0; j < this.arrayArrayData.length; ++j) {
/* 128 */           if (this.arrayArrayData[j].serialNum == i) {
/* 129 */             strOutputBuffer.append("aSerTitle[").append(i).append("]=").append("\"" + this.arrayArrayData[j].serialInfo + "\"").append(";").append("aSerColor[").append(i).append("]=\"").append(this.arrayArrayData[j].color).append("\";");
/*     */ 
/* 132 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 137 */       strOutputBuffer.append("aSerialObj.title=aSerTitle;").append("aSerialObj.color=aSerColor;").append("aSerialObj.toolTipText=\"NTV\";");
/*     */ 
/* 141 */       for (int i = 0; i < iLength; ++i) {
/* 142 */         strOutputBuffer.append("temp = new Array();").append("temp.x = \"").append(xArray.get(i)).append("\";").append("var aSerValue = new Array();");
/*     */ 
/* 145 */         for (int k = 0; k < this.arrayArrayData.length; ++k) {
/* 146 */           if (xArray.get(i).equals(this.arrayArrayData[k].x)) {
/* 147 */             strOutputBuffer.append("aSerValue[").append(this.arrayArrayData[k].serialNum).append("]=").append(this.arrayArrayData[k].y).append(";");
/*     */           }
/*     */         }
/* 150 */         strOutputBuffer.append("temp.y=aSerValue;").append("arrayData[").append(i).append("] =  temp;");
/*     */       }
/*     */ 
/* 153 */       strOutputBuffer.append("objBar3D = new VMLBar3D(arrayData,").append(this.strOutDiv).append(",").append("\"" + this.strTitle + "\"").append(",").append("\"" + this.strClickEventFun + "\"").append(",").append("\"" + this.strDblClickEventFun + "\"").append(",").append(this.intNumberPerLine).append(",aSerialObj);");
/*     */     }
/*     */ 
/* 161 */     strOutputBuffer.append("}").append("DrawBar3D();").append("objBar3D.Zoom(").append(Double.parseDouble(percent.substring(0, percent.length() - 1)) / 100.0D).append(");").append("</script>");
/*     */ 
/* 165 */     return strOutputBuffer.toString();
/*     */   }
/*     */ 
/*     */   public InputData[] getArrayArrayData() throws Throwable
/*     */   {
/* 170 */     if (this.arrayArrayData == null) {
/* 171 */       this.arrayArrayData = CoordinateSystem.getVmlDataSource(this.strPieDataSourceImplClassName);
/*     */     }
/* 173 */     return this.arrayArrayData;
/*     */   }
/*     */ 
/*     */   public String getStrClickEventFun() {
/* 177 */     return this.strClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrDblClickEventFun() {
/* 181 */     return this.strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrOutDiv() {
/* 185 */     return this.strOutDiv;
/*     */   }
/*     */ 
/*     */   public String getStrPieDataSourceImplClassName() {
/* 189 */     return this.strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public String getStrTitle() {
/* 193 */     return this.strTitle;
/*     */   }
/*     */ 
/*     */   public int getIntNumberPerLine() {
/* 197 */     return this.intNumberPerLine;
/*     */   }
/*     */ 
/*     */   public String getStrPercent() {
/* 201 */     return this.strPercent;
/*     */   }
/*     */ 
/*     */   public void setArrayArrayData(InputData[] arrayArrayData) {
/* 205 */     this.arrayArrayData = arrayArrayData;
/*     */   }
/*     */ 
/*     */   public void setStrClickEventFun(String strClickEventFun) {
/* 209 */     this.strClickEventFun = strClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrDblClickEventFun(String strDblClickEventFun) {
/* 213 */     this.strDblClickEventFun = strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrOutDiv(String strOutDiv) {
/* 217 */     this.strOutDiv = strOutDiv;
/*     */   }
/*     */ 
/*     */   public void setStrPieDataSourceImplClassName(String strPieDataSourceImplClassName)
/*     */   {
/* 222 */     this.strPieDataSourceImplClassName = strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public void setStrTitle(String strTitle) {
/* 226 */     this.strTitle = strTitle;
/*     */   }
/*     */ 
/*     */   public void setIntNumberPerLine(int intNumberPerLine) {
/* 230 */     this.intNumberPerLine = intNumberPerLine;
/*     */   }
/*     */ 
/*     */   public void setStrPercent(String strPercent) {
/* 234 */     this.strPercent = strPercent;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlTridimensionalBar
 * JD-Core Version:    0.5.4
 */