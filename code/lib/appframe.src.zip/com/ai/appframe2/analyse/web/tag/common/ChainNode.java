/*    */ package com.ai.appframe2.analyse.web.tag.common;
/*    */ 
/*    */ public class ChainNode
/*    */ {
/*    */   public String nowStr;
/*    */   public ChainNode next;
/*    */ 
/*    */   public void addNode(String addBeforeNodeString, ChainNode node)
/*    */   {
/* 23 */     ChainNode nextNode = this;
/* 24 */     ChainNode currentNode = this;
/* 25 */     while (nextNode != null) {
/* 26 */       if (nextNode.nowStr == addBeforeNodeString) {
/* 27 */         currentNode.next = node;
/* 28 */         node.next.next = nextNode;
/* 29 */         return;
/*    */       }
/* 31 */       currentNode = nextNode;
/* 32 */       nextNode = nextNode.next;
/*    */     }
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 41 */     ChainNode nextNode = this;
/* 42 */     StringBuilder strBuffer = new StringBuilder();
/* 43 */     int i = 0;
/* 44 */     while (nextNode != null) {
/* 45 */       if (nextNode.nowStr != null) {
/* 46 */         strBuffer.append(nextNode.nowStr);
/*    */       }
/* 48 */       nextNode = nextNode.next;
/*    */     }
/* 50 */     return strBuffer.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.common.ChainNode
 * JD-Core Version:    0.5.4
 */