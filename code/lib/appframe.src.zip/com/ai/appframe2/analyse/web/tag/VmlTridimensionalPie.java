/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.common.CoordinateSystem;
/*     */ import com.ai.appframe2.analyse.web.tag.common.InputData;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmlTridimensionalPie extends BodyTagSupport
/*     */ {
/*  15 */   private static transient Log log = LogFactory.getLog(VmlPie.class);
/*     */   private String strOutDiv;
/*     */   private String strPercent;
/*     */   private InputData[] arrayArrayData;
/*     */   private String strClickEventFun;
/*     */   private String strDblClickEventFun;
/*     */   private String strPieDataSourceImplClassName;
/*     */   private long longWidth;
/*     */   private long longHeight;
/*     */   private String initHeight;
/*     */ 
/*     */   public String getInitHeight()
/*     */   {
/*  27 */     return this.initHeight;
/*     */   }
/*     */ 
/*     */   public void setInitHeight(String initHeight) {
/*  31 */     this.initHeight = initHeight;
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException {
/*     */     try {
/*  36 */       System.out.println("Starting doEndTag...");
/*  37 */       Writer writer = this.pageContext.getOut();
/*  38 */       String str = createTridimensionalPies(this.strOutDiv, this.strPercent, getArrayArrayData(), this.strClickEventFun, this.strDblClickEventFun);
/*  39 */       writer.write(str);
/*  40 */       System.out.println(str);
/*     */     }
/*     */     catch (Throwable ex) {
/*  43 */       log.error(ex);
/*  44 */       ex.printStackTrace();
/*     */     }
/*  46 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  57 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createTridimensionalPies(String outDiv, String percent, InputData[] arrayData, String clickEventFun, String dblClickEventFun)
/*     */   {
/*  75 */     if ((arrayData == null) || (arrayData.length == 0)) {
/*  76 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.no_record");
/*  77 */       String nullResult = "<Script language='javascript'>alert('" + msg + "！')</script>";
/*  78 */       return nullResult;
/*     */     }
/*     */ 
/*  81 */     int vWidth = 5000;
/*  82 */     int vHeight = 5000;
/*     */ 
/*  84 */     double zh = 4.32D;
/*     */ 
/*  86 */     int vFontSize = 10;
/*  87 */     double r = vWidth * zh / 2.0D * 0.6D;
/*  88 */     double rate = 0.8D;
/*  89 */     double zeroX = 0.0D;
/*  90 */     double zeroY = 2000.0D;
/*     */ 
/*  92 */     if (percent == null) {
/*  93 */       percent = "100%";
/*     */     }
/*     */ 
/*  97 */     long tempPer = Math.round(Double.parseDouble(percent.substring(0, percent.length() - 1)));
/*  98 */     long gWidth = Math.round(this.longWidth * tempPer / 100.0D * 8.0D / 10.0D);
/*  99 */     long gHeight = Math.round(this.longHeight * tempPer / 100.0D * 8.0D / 10.0D);
/*     */ 
/* 102 */     int i = 0;
/* 103 */     for (i = 0; i < arrayData.length; ++i) {
/* 104 */       arrayData[i].serialNum = i;
/*     */     }
/* 106 */     CoordinateSystem.addRondamColor(arrayData);
/* 107 */     StringBuilder divB = new StringBuilder();
/* 108 */     divB.append("<DIV  style='WIDTH:").append(percent).append(";HEIGHT:").append(percent).append("' >");
/* 109 */     String divE = "</DIV>";
/*     */ 
/* 111 */     StringBuilder shapeTypeCake = new StringBuilder();
/* 112 */     shapeTypeCake.append("<v:shapetype id='Cake_3D' coordsize='").append(vWidth * zh).append(",").append(vHeight * zh).append("' o:spt='95' adj='11796480,5400' path='al10800,10800@0@0@2@14,10800,10800,10800,10800@3@15xe'/>");
/* 113 */     StringBuilder shapeTypeText = new StringBuilder();
/* 114 */     shapeTypeText.append("<v:shapetype id='3dtxt' coordsize='").append(vWidth * zh).append(",").append(vHeight * zh).append("' o:spt='136' adj='10800' path='m@7,l@8,m@5,21600l@6,21600e'>");
/* 115 */     shapeTypeText.append("<v:path textpathok='t' o:connecttype='custom' o:connectlocs='@9,0;@10,10800;@11,21600;@12,10800' o:connectangles='270,180,90,0'/>");
/* 116 */     shapeTypeText.append("<v:textpath on='t' fitshape='t'/>");
/* 117 */     shapeTypeText.append("<o:lock v:ext='edit' text='t' shapetype='t'/>");
/* 118 */     shapeTypeText.append("</v:shapetype>  ");
/*     */ 
/* 121 */     StringBuilder groupB = new StringBuilder();
/* 122 */     groupB.append("<v:group  style='WIDTH:98%;HEIGHT:98%'  coordsize = '").append(vWidth * zh).append(",").append(vHeight * zh).append("' ><v:rect style='WIDTH: 98%; HEIGHT: 98%' fillcolor='white' strokecolor='black'><v:shadow on='t' type='single' color='silver' offset='4pt,3pt'/></v:rect>");
/* 123 */     String groupE = "</v:group>";
/* 124 */     double total = 0.0D;
/* 125 */     for (i = 0; i < arrayData.length; ++i) {
/* 126 */       total += arrayData[i].y;
/*     */     }
/* 128 */     StringBuilder pie = new StringBuilder();
/* 129 */     long last = 0L;
/* 130 */     StringBuilder remarks = new StringBuilder();
/* 131 */     StringBuilder rects = new StringBuilder();
/*     */ 
/* 133 */     double remarkslength = ((100 * arrayData.length > vWidth * zh * rate) ? 100 * arrayData.length : vWidth * zh * rate) / arrayData.length;
/*     */ 
/* 135 */     int k1 = 180;
/* 136 */     int k4 = 10;
/* 137 */     int k6 = 0;
/* 138 */     int k7 = 90;
/* 139 */     long[] tempParaArray = new long[4];
/* 140 */     tempParaArray[0] = k1;
/* 141 */     tempParaArray[1] = k4;
/* 142 */     tempParaArray[2] = k6;
/* 143 */     tempParaArray[3] = k7;
/* 144 */     for (i = 0; i < arrayData.length; ++i) {
/* 145 */       if (arrayData[i].y != 0L) {
/* 146 */         double per = arrayData[i].y / total;
/* 147 */         long current = Math.round(last + per * 360.0D);
/*     */ 
/* 149 */         pie.append(createTridimensionalPie(last, current, arrayData[i].x, arrayData[i].y, arrayData[i].color, per, r, clickEventFun, dblClickEventFun, gWidth, gHeight, tempParaArray));
/* 150 */         last = current;
/*     */       }
/*     */ 
/* 154 */       String xValue = arrayData[i].x;
/* 155 */       String xValue_modify = "";
/*     */       int k;
/* 156 */       if (xValue.length() > 3) {
/* 157 */         for (k = 0; k < xValue.length(); )
/*     */         {
/*     */           String tempValue;
/*     */           String tempValue;
/* 159 */           if (xValue.length() > k + 3)
/* 160 */             tempValue = xValue.substring(k, k + 3);
/*     */           else {
/* 162 */             tempValue = xValue.substring(k, xValue.length());
/*     */           }
/* 164 */           if (tempValue.getBytes().length == tempValue.length()) {
/* 165 */             xValue_modify = xValue_modify + tempValue + "<br>";
/* 166 */             k += 3;
/*     */           } else {
/* 168 */             xValue_modify = xValue_modify + xValue.substring(k, k + 1);
/* 169 */             ++k;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 174 */       long position_x = Math.round(vWidth * zh * (1.0D - rate) / 2.0D + remarkslength * i - zeroX);
/* 175 */       long position_y = Math.round(vHeight * zh - vHeight * zh * 0.2D - zeroY - Long.parseLong(this.initHeight) * 20L);
/* 176 */       rects.append("<v:rect style='position:relative;left:").append(position_x).append(";top:").append(position_y).append(";WIDTH: ").append(1000).append("; HEIGHT: ").append(1000).append("' fillcolor='").append(arrayData[i].color).append("' strokecolor='black'></v:rect>");
/* 177 */       remarks.append("<v:shape style='position:relative;left:").append(position_x).append(";top:").append(position_y + 1100L).append(";WIDTH:").append(arrayData[i].x.length() * vFontSize).append(";HEIGHT:").append(vFontSize * 20).append("pt;z-index:8'  fillcolor='white'><v:textbox   style='font-size:").append(vFontSize).append("pt;v-text-anchor:bottom-top-baseline' align='right'>").append(xValue_modify).append("</v:textbox></v:shape>");
/*     */     }
/*     */ 
/* 183 */     StringBuilder jsBuffer = new StringBuilder();
/* 184 */     jsBuffer.append("<script language=javascript> ").append("var onit=true ;").append("var num=0 ;").append("var Stop;").append("function moveup(iteam,top,txt,rec){").append(" //alert('moveup');").append(" temp=eval(iteam);").append(" tempat=eval(top);").append(" temptxt=eval(txt);").append(" //temprec=eval(rec);").append(" at=parseInt(temp.style.top);").append("  //temprec.style.display = '';").append(" if (num>27){").append("  temptxt.style.display = '';").append(" }").append(" if(at>(tempat-28)&&onit){").append("  num++;").append("  temp.style.top=at-1;").append("  Stop=setTimeout(\"moveup(temp,tempat,temptxt,'')\",10);").append(" }else{").append("  return;").append(" }").append("}").append("function movedown(iteam,top,txt,rec){").append(" //alert('movedown');").append(" temp=eval(iteam);").append(" temptxt=eval(txt);").append(" //temprec=eval(rec);").append(" clearTimeout(Stop);").append(" temp.style.top=top;").append(" num=0;").append(" temptxt.style.display = 'none';").append(" //temprec.style.display = 'none';").append("}").append("function ontxt(iteam,top,txt,rec){").append(" //alert('ontxt');").append(" temp = eval(iteam);").append(" temptxt = eval(txt);").append(" //temprec = eval(rec);").append(" if (onit){").append("  temp.style.top = top-28;").append("  temptxt.style.display = '';").append("  //temprec.style.display = '';").append(" }").append("}").append("function movereset(over){").append(" //alert('movereset');").append(" if (over==1){").append("  onit=false;").append(" }else{").append("  onit=true;").append(" }").append("}").append("</script>");
/*     */ 
/* 239 */     divB.append(shapeTypeCake).append(shapeTypeText).append(groupB).append(rects).append(remarks).append(groupE).append(pie).append(divE);
/* 240 */     return divB.toString();
/*     */   }
/*     */ 
/*     */   private String createTridimensionalPie(double beginAngle, double endAngle, String x, long y, String color, double percent, double r, String clickEventFun, String dblClickEventFun, long vWidth, long vHeight, long[] paraArray)
/*     */   {
/* 272 */     r = vHeight / 2L;
/* 273 */     long k2 = Math.round(360.0D * percent / 2.0D);
/*     */ 
/* 275 */     long k3 = paraArray[0] + k2;
/* 276 */     long k8 = Math.round(paraArray[3] - 360.0D * percent / 2.0D);
/* 277 */     if (k8 < 0L) k8 = 360L + k8;
/* 278 */     paraArray[3] = Math.round(k8 - 360.0D * percent / 2.0D);
/*     */ 
/* 280 */     k3 %= 360L;
/* 281 */     long kkk = Math.round(-11796480.0D * percent + 5898240.0D);
/* 282 */     double k5 = 6.2829852D * k8 / 360.0D;
/*     */ 
/* 285 */     long heightPlus = Long.parseLong(this.initHeight);
/*     */ 
/* 287 */     long txt_x = Math.round(vWidth / 10.0D + r - r / 9.0D + r * Math.cos(k5) * 0.5D);
/*     */ 
/* 289 */     long txt_y = Math.round(vHeight / 10.0D - heightPlus + r - r / 5.0D - r * Math.sin(k5) * 0.2D);
/*     */ 
/* 292 */     long heightY = Math.round(vHeight / 10.0D - heightPlus);
/*     */ 
/* 298 */     paraArray[2] = Math.round(Math.random() * 10000.0D);
/*     */ 
/* 301 */     StringBuilder strVmlBuffer = new StringBuilder();
/* 302 */     strVmlBuffer.append(" <v:shape id='cake").append(paraArray[2]).append("' type='#Cake_3D' ").append(" style='position:absolute;left:").append(Math.round(vWidth / 10.0D)).append(";top:").append(Math.round((float)heightY)).append(";WIDTH:").append(Math.round(vWidth * 9L / 10.0D)).append(";HEIGHT:").append(Math.round(vHeight * 9L / 10.0D)).append(";rotation:").append(k3).append(";z-index:").append(paraArray[1]).append("' adj='").append(kkk).append(",0' fillcolor='").append(color).append("'");
/*     */ 
/* 306 */     if ((clickEventFun != null) && (clickEventFun.length() > 0)) {
/* 307 */       strVmlBuffer.append(" onclick=\"").append(clickEventFun).append("('").append(x).append("','").append(y).append("') \" ");
/*     */     }
/* 309 */     if ((dblClickEventFun != null) && (dblClickEventFun.length() > 0)) {
/* 310 */       strVmlBuffer.append(" ondblclick=\"").append(dblClickEventFun).append("('").append(x).append("','").append(y).append("') \" ");
/*     */     }
/*     */ 
/* 313 */     strVmlBuffer.append(" onmouseover='moveup(cake").append(paraArray[2]).append(",").append(Math.round((float)heightY)).append(",txt").append(paraArray[2]).append(",\"rec").append(paraArray[2]).append("\")' onmouseout='movedown(cake").append(paraArray[2]).append(",").append(Math.round((float)heightY)).append(",txt").append(paraArray[2]).append(",\"rec").append(paraArray[2]).append("\")'>");
/*     */ 
/* 316 */     strVmlBuffer.append(" <v:fill opacity='60293f' color2='fill lighten(120)' o:opacity2='60293f' rotate='t' angle='-135' method='linear sigma' focus='100%' type='gradient'/>").append(" <o:extrusion v:ext='view' on='t' backdepth='25' rotationangle='60' viewpoint='0,0' viewpointorigin='0,0' skewamt='0' lightposition='-50000,-50000' lightposition2='50000'/>").append(" </v:shape>");
/*     */ 
/* 320 */     String fontFamily = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.font_family");
/* 321 */     strVmlBuffer.append(" <v:shape id='txt").append(paraArray[2]).append("' type='#3dtxt' style='position:absolute;left:").append(txt_x).append(";top:").append(txt_y).append(";z-index:20;display:none;width:50; height:18;' fillcolor='#ffffff'").append(" onmouseover='ontxt(cake").append(paraArray[2]).append(",").append(Math.round((float)heightY)).append(",txt").append(paraArray[2]).append(",\"rec").append(paraArray[2]).append("\")'>");
/*     */ 
/* 325 */     strVmlBuffer.append(" <v:fill opacity='60293f' color2='fill lighten(120)' o:opacity2='60293f' rotate='t' angle='-135' method='linear sigma' focus='100%' type='gradient'/>").append(" <v:textpath style='font-family:\"" + fontFamily + "\";v-text-kern:t' trim='t' fitpath='t' string='").append(x).append(" ").append(y).append(" ").append(Math.round(percent * 100.0D)).append("%'/>").append(" <o:extrusion v:ext='view' backdepth='8pt' on='t' lightposition='0,0' lightposition2='0,0'/>").append(" </v:shape>");
/*     */ 
/* 330 */     paraArray[0] += k2 * 2L;
/* 331 */     if (paraArray[0] >= 360L) {
/* 332 */       paraArray[0] -= 360L;
/*     */     }
/* 334 */     if (paraArray[0] > 180L)
/* 335 */       paraArray[1] += 1L;
/*     */     else {
/* 337 */       paraArray[1] -= 1L;
/*     */     }
/* 339 */     paraArray[2] += 1L;
/*     */ 
/* 341 */     return strVmlBuffer.toString();
/*     */   }
/*     */ 
/*     */   public InputData[] getArrayArrayData()
/*     */     throws Throwable
/*     */   {
/* 354 */     this.arrayArrayData = CoordinateSystem.getVmlDataSource(this.strPieDataSourceImplClassName);
/* 355 */     return this.arrayArrayData;
/*     */   }
/*     */ 
/*     */   public String getStrClickEventFun() {
/* 359 */     return this.strClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrDblClickEventFun() {
/* 363 */     return this.strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrOutDiv() {
/* 367 */     return this.strOutDiv;
/*     */   }
/*     */ 
/*     */   public String getStrPercent() {
/* 371 */     return this.strPercent;
/*     */   }
/*     */ 
/*     */   public String getStrPieDataSourceImplClassName() {
/* 375 */     return this.strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public long getLongHeight() {
/* 379 */     return this.longHeight;
/*     */   }
/*     */ 
/*     */   public long getLongWidth() {
/* 383 */     return this.longWidth;
/*     */   }
/*     */ 
/*     */   public void setArrayArrayData(InputData[] arrayArrayData) {
/* 387 */     this.arrayArrayData = arrayArrayData;
/*     */   }
/*     */ 
/*     */   public void setStrClickEventFun(String strClickEventFun) {
/* 391 */     this.strClickEventFun = strClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrDblClickEventFun(String strDblClickEventFun) {
/* 395 */     this.strDblClickEventFun = strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrOutDiv(String strOutDiv) {
/* 399 */     this.strOutDiv = strOutDiv;
/*     */   }
/*     */ 
/*     */   public void setStrPercent(String strPercent) {
/* 403 */     this.strPercent = strPercent;
/*     */   }
/*     */ 
/*     */   public void setStrPieDataSourceImplClassName(String strPieDataSourceImplClassName)
/*     */   {
/* 408 */     this.strPieDataSourceImplClassName = strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public void setLongHeight(long longHeight) {
/* 412 */     this.longHeight = longHeight;
/*     */   }
/*     */ 
/*     */   public void setLongWidth(long longWidth) {
/* 416 */     this.longWidth = longWidth;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlTridimensionalPie
 * JD-Core Version:    0.5.4
 */