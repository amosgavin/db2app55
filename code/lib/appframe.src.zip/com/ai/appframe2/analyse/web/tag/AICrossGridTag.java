/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.CrossGridManager;
/*     */ import com.ai.appframe2.analyse.CrossGridManagerFactory;
/*     */ import com.ai.appframe2.analyse.McGridInterface;
/*     */ import com.ai.appframe2.analyse.PivotList;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import com.ai.appframe2.web.tag.JSHelper;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class AICrossGridTag extends BodyTagSupport
/*     */ {
/*     */   private String id;
/*     */   private String configname;
/*  34 */   private String showtype = "crossgrid";
/*  35 */   private String width = "500";
/*  36 */   private String height = "600";
/*  37 */   private String onrowselect = "";
/*  38 */   private String oncolselect = "";
/*  39 */   private boolean isshowselect = true;
/*     */ 
/*  41 */   private long pk = -1L;
/*     */ 
/*  43 */   private PivotList pivotList = null;
/*     */ 
/*  46 */   private static transient Log log = LogFactory.getLog(AICrossGridTag.class);
/*     */   private String datamodel;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  61 */       CrossGridManager manager = CrossGridManagerFactory.getManager((HttpServletRequest)this.pageContext.getRequest());
/*  62 */       McGridInterface mcGrid = manager.getNewCrossGridInstance((HttpServletRequest)this.pageContext.getRequest(), this.configname, this.datamodel, this.pivotList, false, this.showtype);
/*  63 */       Writer writer = this.pageContext.getOut();
/*     */ 
/*  65 */       writer.write("<?xml version ='1.0' encoding = 'GB2312'?>\n\n");
/*  66 */       writer.write("<xml id=\"CrossGrid_ConfigInfo_" + getId() + "\">");
/*  67 */       writer.write("<root>");
/*  68 */       writer.write("<pk>");
/*  69 */       writer.write("" + mcGrid.getPk());
/*  70 */       writer.write("</pk>");
/*  71 */       writer.write("<configstr>");
/*  72 */       writer.write("<![CDATA[");
/*  73 */       writer.write(manager.getPovitsConfigStr(mcGrid));
/*  74 */       writer.write("]]>");
/*  75 */       writer.write("</configstr>");
/*  76 */       writer.write("<showtype>");
/*  77 */       writer.write(this.showtype);
/*  78 */       writer.write("</showtype>");
/*     */ 
/*  80 */       writer.write("<event>");
/*  81 */       if (!StringUtils.isBlank(this.onrowselect))
/*     */       {
/*  83 */         writer.write("<onrowselect>");
/*  84 */         writer.write(this.onrowselect);
/*  85 */         writer.write("</onrowselect>");
/*     */       }
/*  87 */       if (!StringUtils.isBlank(this.oncolselect)) {
/*  88 */         writer.write("<oncolselect>");
/*  89 */         writer.write(this.oncolselect);
/*  90 */         writer.write("</oncolselect>");
/*     */       }
/*     */ 
/*  94 */       writer.write("</event>");
/*  95 */       writer.write("</root>");
/*  96 */       writer.write("</xml>");
/*  97 */       writer.write("<div id=\"CrossGrid_SelectArea_" + getId() + "\"");
/*  98 */       if (!this.isshowselect) {
/*  99 */         writer.write(" style=\"display:none\"");
/*     */       }
/* 101 */       writer.write(">");
/* 102 */       manager.toHtmlSelectArea(writer, mcGrid);
/* 103 */       writer.write("</div>");
/*     */ 
/* 110 */       writer.write("<DIV id=\"CrossGrid_GridData_" + getId() + "\" style='BORDER-RIGHT: #808080 2px solid; BORDER-TOP: " + "#808080 2px solid; DISPLAY: inline; OVERFLOW: auto; BORDER-LEFT: #808080 2px solid; " + "CURSOR: default; BORDER-BOTTOM: #808080 2px solid;" + "HEIGHT: " + this.height + "px;WIDTH:" + this.width + "; '>");
/*     */ 
/* 117 */       manager.toHtmlGrid(writer, getId(), mcGrid);
/* 118 */       writer.write("</div>");
/*     */ 
/* 121 */       this.pivotList = null;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 126 */       log.error(ex);
/* 127 */       throw new JspException(ex);
/*     */     }
/* 129 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/* 143 */     JSHelper.processJS(this.pageContext, (HttpServletRequest)this.pageContext.getRequest(), "AICrossGrid_Tag_Js");
/*     */ 
/* 145 */     if ((getId() == null) || (StringUtils.isBlank(getId()))) {
/* 146 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.id_null_error"));
/* 147 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.id_null_error"));
/*     */     }
/* 149 */     if ((this.configname == null) || (StringUtils.isBlank(this.configname))) {
/* 150 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "configname" }));
/* 151 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "configname" }));
/*     */     }
/*     */ 
/* 154 */     if ((this.showtype == null) || (StringUtils.isBlank(this.showtype))) {
/* 155 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "showtype" }));
/* 156 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "showtype" }));
/*     */     }
/*     */ 
/* 161 */     if ((this.datamodel == null) || (StringUtils.isBlank(this.datamodel))) {
/* 162 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "datamodel" }));
/* 163 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.attribute_null_error", new String[] { "datamodel" }));
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 171 */       this.pivotList = new PivotList();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 176 */       log.error(ex);
/* 177 */       throw new JspException(ex);
/*     */     }
/*     */ 
/* 180 */     return 6;
/*     */   }
/*     */ 
/*     */   public void setConfigname(String configname)
/*     */   {
/* 188 */     this.configname = configname;
/*     */   }
/*     */ 
/*     */   public void setShowtype(String showtype) {
/* 192 */     this.showtype = showtype;
/*     */   }
/*     */ 
/*     */   public void setWidth(String width)
/*     */   {
/* 198 */     this.width = width;
/*     */   }
/*     */ 
/*     */   public void setHeight(String height) {
/* 202 */     this.height = height;
/*     */   }
/*     */ 
/*     */   public void setOnrowselect(String onrowselect) {
/* 206 */     this.onrowselect = onrowselect;
/*     */   }
/*     */   public void setOncolselect(String oncolselect) {
/* 209 */     this.oncolselect = oncolselect;
/*     */   }
/*     */ 
/*     */   public void setDatamodel(String datamodel)
/*     */   {
/* 214 */     this.datamodel = datamodel;
/*     */   }
/*     */ 
/*     */   public void addPivot(int area, String pCode, int selectValueIndex, boolean isSubTotal, boolean aIsSuppressRepeat, String aOrderType)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 224 */       this.pivotList.addPivot(area, -1, pCode, selectValueIndex, isSubTotal, aIsSuppressRepeat, aOrderType);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 228 */       log.error(ex);
/* 229 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public PivotList getPivotList() {
/* 233 */     return this.pivotList;
/*     */   }
/*     */ 
/*     */   public void setIsshowselect(String pIsShowSelect) {
/* 237 */     if ((!StringUtils.isBlank(pIsShowSelect)) && (pIsShowSelect.equalsIgnoreCase("false")))
/* 238 */       this.isshowselect = false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.AICrossGridTag
 * JD-Core Version:    0.5.4
 */