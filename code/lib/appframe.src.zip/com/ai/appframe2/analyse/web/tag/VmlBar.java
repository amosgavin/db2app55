/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.common.ChainNode;
/*     */ import com.ai.appframe2.analyse.web.tag.common.CoordinateSystem;
/*     */ import com.ai.appframe2.analyse.web.tag.common.InputData;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmlBar extends BodyTagSupport
/*     */ {
/*  19 */   private static transient Log log = LogFactory.getLog(VmlPie.class);
/*     */   private double dbBaseX;
/*     */   private double dbBaseY;
/*     */   private String strShowX;
/*     */   private double dbCellY;
/*     */   private String strShowY;
/*     */   private String strOutDiv;
/*     */   private String strPercent;
/*     */   private InputData[] arrayArrayData;
/*     */   private String strClickEventFun;
/*     */   private String strDblClickEventFun;
/*     */   private String strPieDataSourceImplClassName;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  35 */       System.out.println("Starting doEndTag...");
/*  36 */       Writer writer = this.pageContext.getOut();
/*  37 */       String str = createBars(this.dbBaseX, this.dbBaseY, this.strShowX, this.dbCellY, this.strShowY, this.strOutDiv, this.strPercent, getArrayArrayData(), this.strClickEventFun, this.strDblClickEventFun);
/*     */ 
/*  41 */       writer.write(str);
/*  42 */       System.out.println(str);
/*     */     }
/*     */     catch (Throwable ex) {
/*  45 */       log.error(ex);
/*  46 */       ex.printStackTrace();
/*     */     }
/*  48 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  59 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createBars(double baseX, double baseY, String showX, double cellY, String showY, String outDiv, String percent, InputData[] arrayData, String clickEventFun, String dblClickEventFun)
/*     */     throws Throwable
/*     */   {
/*  79 */     if ((arrayData == null) || (arrayData.length == 0)) {
/*  80 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.no_record");
/*  81 */       String nullResult = "<Script language='javascript'>alert('" + msg + "！')</script>";
/*  82 */       return nullResult;
/*     */     }
/*     */ 
/*  85 */     String vColorHX = "blue";
/*  86 */     String vColorXX = "red";
/*  87 */     int vFontSize = 10;
/*     */ 
/*  90 */     int vWidth = 10000;
/*  91 */     int vHeight = 10000;
/*     */ 
/*  95 */     if (baseX <= 0.0D) {
/*  96 */       baseX = 0.08D;
/*     */     }
/*  98 */     if (baseX <= 1.0D) {
/*  99 */       baseX *= vWidth;
/*     */     }
/*     */ 
/* 104 */     if (baseY <= 0.0D) {
/* 105 */       baseY = 0.08D;
/*     */     }
/* 107 */     if (baseY <= 1.0D) {
/* 108 */       baseY *= vHeight;
/*     */     }
/* 110 */     double zeroX = baseX;
/* 111 */     double zeroY = vHeight - baseY;
/* 112 */     double originFontX = 0.0D;
/* 113 */     double originFontY = zeroY;
/*     */ 
/* 115 */     double barWidthper = 0.6D;
/*     */ 
/* 117 */     if (percent == null) {
/* 118 */       percent = "100%";
/*     */     }
/*     */ 
/* 121 */     if (showX == null) {
/* 122 */       showX = " ";
/*     */     }
/* 124 */     if (showY == null) {
/* 125 */       showY = " ";
/*     */     }
/*     */ 
/* 128 */     CoordinateSystem coordinate = new CoordinateSystem(arrayData, vWidth, vHeight, vColorHX, vColorXX, vFontSize, baseX, baseY, originFontX, originFontY, cellY, percent, showX, showY, clickEventFun, dblClickEventFun);
/*     */ 
/* 130 */     ChainNode strChain = coordinate.draw();
/* 131 */     coordinate.drawBars(strChain, barWidthper);
/* 132 */     return strChain.toString();
/*     */   }
/*     */ 
/*     */   public InputData[] getArrayArrayData()
/*     */     throws Throwable
/*     */   {
/* 143 */     this.arrayArrayData = CoordinateSystem.getVmlDataSource(this.strPieDataSourceImplClassName);
/* 144 */     return this.arrayArrayData;
/*     */   }
/*     */ 
/*     */   public double getDbBaseX() {
/* 148 */     return this.dbBaseX;
/*     */   }
/*     */ 
/*     */   public double getDbBaseY() {
/* 152 */     return this.dbBaseY;
/*     */   }
/*     */ 
/*     */   public double getDbCellY() {
/* 156 */     return this.dbCellY;
/*     */   }
/*     */ 
/*     */   public String getStrClickEventFun() {
/* 160 */     return this.strClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrDblClickEventFun() {
/* 164 */     return this.strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrOutDiv() {
/* 168 */     return this.strOutDiv;
/*     */   }
/*     */ 
/*     */   public String getStrPercent() {
/* 172 */     return this.strPercent;
/*     */   }
/*     */ 
/*     */   public String getStrPieDataSourceImplClassName() {
/* 176 */     return this.strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public String getStrShowX() {
/* 180 */     return this.strShowX;
/*     */   }
/*     */ 
/*     */   public String getStrShowY() {
/* 184 */     return this.strShowY;
/*     */   }
/*     */ 
/*     */   public void setArrayArrayData(InputData[] arrayArrayData) {
/* 188 */     this.arrayArrayData = arrayArrayData;
/*     */   }
/*     */ 
/*     */   public void setDbBaseX(double dbBaseX) {
/* 192 */     this.dbBaseX = dbBaseX;
/*     */   }
/*     */ 
/*     */   public void setDbBaseY(double dbBaseY) {
/* 196 */     this.dbBaseY = dbBaseY;
/*     */   }
/*     */ 
/*     */   public void setDbCellY(double dbCellY) {
/* 200 */     this.dbCellY = dbCellY;
/*     */   }
/*     */ 
/*     */   public void setStrShowY(String strShowY) {
/* 204 */     if (strShowY == null)
/* 205 */       this.strShowY = "";
/*     */     else
/* 207 */       this.strShowY = strShowY;
/*     */   }
/*     */ 
/*     */   public void setStrPieDataSourceImplClassName(String strPieDataSourceImplClassName)
/*     */   {
/* 213 */     this.strPieDataSourceImplClassName = strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public void setStrShowX(String strShowX) {
/* 217 */     if (strShowX == null)
/* 218 */       this.strShowX = "";
/*     */     else
/* 220 */       this.strShowX = strShowX;
/*     */   }
/*     */ 
/*     */   public void setStrPercent(String strPercent)
/*     */   {
/* 225 */     this.strPercent = strPercent;
/*     */   }
/*     */ 
/*     */   public void setStrDblClickEventFun(String strDblClickEventFun) {
/* 229 */     this.strDblClickEventFun = strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrOutDiv(String strOutDiv) {
/* 233 */     this.strOutDiv = strOutDiv;
/*     */   }
/*     */ 
/*     */   public void setStrClickEventFun(String strClickEventFun) {
/* 237 */     this.strClickEventFun = strClickEventFun;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlBar
 * JD-Core Version:    0.5.4
 */