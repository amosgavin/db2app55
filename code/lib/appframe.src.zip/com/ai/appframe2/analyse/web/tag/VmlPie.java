/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.common.CoordinateSystem;
/*     */ import com.ai.appframe2.analyse.web.tag.common.InputData;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class VmlPie extends BodyTagSupport
/*     */ {
/*  16 */   private static transient Log log = LogFactory.getLog(VmlPie.class);
/*     */   private String strOutDiv;
/*     */   private String strPercent;
/*     */   private InputData[] arrayArrayData;
/*     */   private String strClickEventFun;
/*     */   private String strDblClickEventFun;
/*     */   private String strPieDataSourceImplClassName;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*     */     try
/*     */     {
/*  26 */       System.out.println("Starting tag......");
/*  27 */       Writer writer = this.pageContext.getOut();
/*  28 */       String str = createPies(this.strOutDiv, this.strPercent, getArrayArrayData(), this.strClickEventFun, this.strDblClickEventFun);
/*  29 */       writer.write(str);
/*  30 */       System.out.println(str);
/*     */     }
/*     */     catch (Throwable ex) {
/*  33 */       log.error(ex);
/*  34 */       ex.printStackTrace();
/*     */     }
/*  36 */     return 6;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/*  47 */     return 6;
/*     */   }
/*     */ 
/*     */   private String createPie(double beginAngle, double endAngle, String x, long y, String color, double r, String clickEventFun, String dblClickEventFun, int vWidth, int vHeight)
/*     */   {
/*  65 */     double fs = 6.283185307179586D * beginAngle / 360.0D;
/*  66 */     double fe = 6.283185307179586D * endAngle / 360.0D;
/*  67 */     long sx = Math.round(r * Math.sin(fs));
/*  68 */     long sy = Math.round(-r * Math.cos(fs));
/*  69 */     long ex = Math.round(r * Math.sin(fe));
/*  70 */     long ey = Math.round(-r * Math.cos(fe));
/*  71 */     StringBuilder newPie = new StringBuilder();
/*  72 */     newPie.append("<v:shape  style='position:relative;z-index:8;width:").append(2.0D * r).append(";height:").append(2.0D * r).append("' coordsize = '").append(vWidth).append(",").append(vHeight).append("' strokeweight='1pt' fillcolor='").append(color).append("' strokecolor='black' path='m0,0 l ").append(sx).append(",").append(sy).append(" ar -").append(Math.round(r)).append(",-").append(Math.round(r)).append(",").append(Math.round(r)).append(",").append(Math.round(r)).append(",").append(ex).append(",").append(ey).append(",").append(sx).append(",").append(sy).append(" l0,0 x e' ");
/*     */ 
/*  77 */     if ((clickEventFun != null) && (clickEventFun.length() > 0)) {
/*  78 */       newPie.append(" onclick=\"" + clickEventFun + "('" + x + "','" + y + "') \" ");
/*     */     }
/*  80 */     if ((dblClickEventFun != null) && (dblClickEventFun.length() > 0)) {
/*  81 */       newPie.append(" ondblclick=\"" + dblClickEventFun + "('" + x + "','" + y + "') \" ");
/*     */     }
/*  83 */     newPie.append("title='").append(x).append(" ").append(y).append("' />");
/*  84 */     return newPie.toString();
/*     */   }
/*     */ 
/*     */   private String createPies(String outDiv, String percent, InputData[] arrayData, String clickEventFun, String dblClickEventFun)
/*     */   {
/*  97 */     int vWidth = 5000;
/*  98 */     int vHeight = 5000;
/*  99 */     int vFontSize = 10;
/* 100 */     double r = vWidth / 2 * 0.8D;
/* 101 */     double rate = 0.8D;
/* 102 */     int zeroX = vWidth / 2;
/* 103 */     int zeroY = vHeight / 2;
/* 104 */     if (percent == null) {
/* 105 */       percent = "100%";
/*     */     }
/* 107 */     int i = 0;
/*     */ 
/* 109 */     for (i = 0; i < arrayData.length; ++i) {
/* 110 */       arrayData[i].serialNum = i;
/*     */     }
/* 112 */     CoordinateSystem.addRondamColor(arrayData);
/* 113 */     StringBuilder divB = new StringBuilder();
/* 114 */     divB.append("<DIV style='WIDTH:").append(percent).append(";HEIGHT:").append(percent).append("' >");
/* 115 */     String divE = "</DIV>";
/* 116 */     StringBuilder groupB = new StringBuilder();
/* 117 */     groupB.append("<v:group  style='WIDTH:100%;HEIGHT:100%' coordorigin='-").append(zeroX).append(",-").append(zeroY).append("' coordsize = '").append(vWidth).append(",").append(vHeight).append("' ><v:rect style='WIDTH: 98%; HEIGHT: 98%' fillcolor='white' strokecolor='black'><v:shadow on='t' type='single' color='silver' offset='4pt,3pt'/></v:rect>");
/*     */ 
/* 120 */     String groupE = "</v:group>";
/* 121 */     double total = 0.0D;
/* 122 */     for (i = 0; i < arrayData.length; ++i) {
/* 123 */       total += arrayData[i].y;
/*     */     }
/* 125 */     StringBuilder pie = new StringBuilder();
/* 126 */     double last = 0.0D;
/* 127 */     StringBuilder remarks = new StringBuilder();
/* 128 */     StringBuilder rects = new StringBuilder();
/*     */ 
/* 130 */     double remarkslength = ((100 * arrayData.length > vWidth * rate) ? 100 * arrayData.length : vWidth * rate) / arrayData.length;
/* 131 */     for (i = 0; i < arrayData.length; ++i) {
/* 132 */       if (arrayData[i].y != 0L) {
/* 133 */         double current = last + arrayData[i].y / total * 360.0D;
/* 134 */         pie.append(createPie(last, current, arrayData[i].x, arrayData[i].y, arrayData[i].color, r, clickEventFun, dblClickEventFun, vWidth, vHeight));
/* 135 */         last = current;
/*     */       }
/* 137 */       double position_x = vWidth * (1.0D - rate) / 2.0D + remarkslength * i - zeroX;
/* 138 */       double position_y = vHeight - vHeight * 0.1D - zeroY;
/* 139 */       rects.append("<v:rect style='position:relative;left:").append(position_x).append(";top:").append(position_y).append(";WIDTH: 100; HEIGHT: 100' fillcolor='").append(arrayData[i].color).append("' strokecolor='black'></v:rect>");
/*     */ 
/* 141 */       remarks.append("<v:shape style='position:relative;left:").append(position_x).append(";top:").append(position_y + 110.0D).append(";WIDTH:").append(arrayData[i].x.length() * vFontSize).append("pt;HEIGHT:").append(vFontSize).append("pt;z-index:8'  fillcolor='white'><v:textbox   style='font-size:").append(vFontSize).append("pt;v-text-anchor:bottom-top-baseline' align='right'>").append(arrayData[i].x).append("</v:textbox></v:shape>");
/*     */     }
/*     */ 
/* 148 */     return groupB + pie + rects + remarks + groupE + divE;
/*     */   }
/*     */ 
/*     */   public InputData[] getArrayArrayData() throws Throwable {
/* 152 */     if (this.arrayArrayData == null) {
/* 153 */       this.arrayArrayData = CoordinateSystem.getVmlDataSource(this.strPieDataSourceImplClassName);
/*     */     }
/* 155 */     return this.arrayArrayData;
/*     */   }
/*     */ 
/*     */   public String getStrClickEventFun() {
/* 159 */     return this.strClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrDblClickEventFun() {
/* 163 */     return this.strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public String getStrOutDiv() {
/* 167 */     return this.strOutDiv;
/*     */   }
/*     */ 
/*     */   public String getStrPercent() {
/* 171 */     return this.strPercent;
/*     */   }
/*     */ 
/*     */   public String getStrPieDataSourceImplClassName() {
/* 175 */     return this.strPieDataSourceImplClassName;
/*     */   }
/*     */ 
/*     */   public void setArrayArrayData(InputData[] arrayArrayData) {
/* 179 */     this.arrayArrayData = arrayArrayData;
/*     */   }
/*     */ 
/*     */   public void setStrClickEventFun(String strClickEventFun) {
/* 183 */     this.strClickEventFun = strClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrDblClickEventFun(String strDblClickEventFun) {
/* 187 */     this.strDblClickEventFun = strDblClickEventFun;
/*     */   }
/*     */ 
/*     */   public void setStrOutDiv(String strOutDiv) {
/* 191 */     this.strOutDiv = strOutDiv;
/*     */   }
/*     */ 
/*     */   public void setStrPercent(String strPercent) {
/* 195 */     this.strPercent = strPercent;
/*     */   }
/*     */ 
/*     */   public void setStrPieDataSourceImplClassName(String strPieDataSourceImplClassName)
/*     */   {
/* 200 */     this.strPieDataSourceImplClassName = strPieDataSourceImplClassName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.VmlPie
 * JD-Core Version:    0.5.4
 */