package com.ai.appframe2.analyse.web.tag.common;

public class InputData
{
  public String x;
  public long y;
  public String color;
  public String serialInfo;
  public int serialNum;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.common.InputData
 * JD-Core Version:    0.5.4
 */