/*     */ package com.ai.appframe2.analyse.web;
/*     */ 
/*     */ import com.ai.appframe2.analyse.CrossGridFactory;
/*     */ import com.ai.appframe2.analyse.CrossGridImpl;
/*     */ import com.ai.appframe2.analyse.CrossGridManager;
/*     */ import com.ai.appframe2.analyse.CrossGridManagerFactory;
/*     */ import com.ai.appframe2.util.charset.CharsetFactory;
/*     */ import com.ai.appframe2.web.HttpUtil;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.BitSet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class CrossGricAction extends HttpServlet
/*     */ {
/*     */   private static final String CONTENT_TYPE = "text/html; charset=GBK";
/*     */   private static final String XML_CONTENT_TYPE = "text/xml; charset=GBK";
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response)
/*     */     throws ServletException, IOException
/*     */   {
/*  21 */     String action = request.getParameter("action");
/*     */     try {
/*  23 */       if (action.equalsIgnoreCase("refresh") == true)
/*  24 */         refresh(request, response);
/*  25 */       else if (action.equalsIgnoreCase("toexcel") == true)
/*  26 */         toexcel(request, response);
/*  27 */       else if (action.equalsIgnoreCase("initial") == true)
/*  28 */         initial(request, response);
/*  29 */       else if (action.equalsIgnoreCase("readdata") == true) {
/*  30 */         readData(request, response);
/*     */       }
/*  32 */       else if (action.equalsIgnoreCase("refreshconfig") == true) {
/*  33 */         refreshConfig(request, response);
/*     */       }
/*  35 */       else if (action.equalsIgnoreCase("refreshselectarea") == true) {
/*  36 */         refreshSelectArea(request, response);
/*     */       }
/*  38 */       else if (action.equalsIgnoreCase("reloaddata") == true) {
/*  39 */         reloadCrossGridImpl(request, response);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  44 */       ex.printStackTrace();
/*  45 */       throw new IOException(ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void refresh(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*  49 */     response.setContentType("text/xml; charset=GBK");
/*  50 */     long s = System.currentTimeMillis();
/*  51 */     long pk = Long.parseLong(request.getParameter("pk"));
/*  52 */     String selectIndexs = request.getParameter("selectindexs");
/*  53 */     String pivotListStr = new String(request.getParameter("configstr").getBytes("ISO-8859-1"), CharsetFactory.getDefaultCharset());
/*  54 */     String clientID = request.getParameter("id");
/*  55 */     String showType = HttpUtil.getParameter(request, "showtype");
/*     */ 
/*  57 */     CrossGridManager manager = CrossGridManagerFactory.getManager(request);
/*  58 */     Writer writer = response.getWriter();
/*  59 */     manager.refresh(writer, clientID, pk, selectIndexs, pivotListStr, false, showType);
/*     */   }
/*     */ 
/*     */   public void reloadCrossGridImpl(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/*  64 */     response.setContentType("text/xml; charset=GBK");
/*  65 */     long s = System.currentTimeMillis();
/*  66 */     long pk = Long.parseLong(request.getParameter("pk"));
/*  67 */     String selectIndexs = request.getParameter("selectindexs");
/*  68 */     String pivotListStr = new String(request.getParameter("configstr").getBytes("ISO-8859-1"), "GBK");
/*  69 */     String clientID = request.getParameter("id");
/*  70 */     String showType = HttpUtil.getParameter(request, "showtype");
/*     */ 
/*  72 */     CrossGridManager manager = CrossGridManagerFactory.getManager(request);
/*  73 */     Writer writer = response.getWriter();
/*  74 */     manager.reloadCrossGridImpl(writer, clientID, pk, selectIndexs, pivotListStr, false, showType, request);
/*     */   }
/*     */ 
/*     */   public void toexcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
/*  78 */     long s = System.currentTimeMillis();
/*  79 */     long pk = Long.parseLong(request.getParameter("pk"));
/*  80 */     String filename = HttpUtil.getAsString(request, "filename");
/*  81 */     if ((filename == null) || (filename.trim().equals(""))) {
/*  82 */       filename = "anareport";
/*     */     }
/*  84 */     String selectIndexs = request.getParameter("selectindexs");
/*  85 */     String pivotListStr = new String(request.getParameter("configstr").getBytes("ISO-8859-1"), CharsetFactory.getDefaultCharset());
/*  86 */     String clientID = request.getParameter("id");
/*  87 */     String showType = HttpUtil.getParameter(request, "showtype");
/*  88 */     CrossGridManager manager = CrossGridManagerFactory.getManager(request);
/*  89 */     response.addHeader("Content-Disposition", "attachment; filename=" + encode(filename, "utf-8") + ".xls");
/*     */ 
/*  91 */     response.setContentType("application/ms-excel");
/*  92 */     ServletOutputStream aOutputStream = response.getOutputStream();
/*  93 */     manager.toExcel(aOutputStream, clientID, pk, selectIndexs, pivotListStr, false, showType);
/*  94 */     aOutputStream.close();
/*     */   }
/*     */ 
/*     */   public void initial(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void readData(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 103 */     response.setContentType("text/xml; charset=GBK");
/* 104 */     long pk = Long.parseLong(request.getParameter("pk"));
/*     */ 
/* 106 */     String dimValues = HttpUtil.getAsString(request, "dimvalues");
/* 107 */     String meas = HttpUtil.getAsString(request, "meas");
/*     */ 
/* 109 */     CrossGridImpl grid = CrossGridFactory.getCrossGridFactory().getInstance(pk);
/* 110 */     Object[][] list = grid.getFactData(dimValues, meas);
/* 111 */     StringWriter writer = new StringWriter();
/* 112 */     writer.write(HttpUtil.getXmlDeclare());
/* 113 */     writer.write("<root>");
/* 114 */     for (int i = 0; (list != null) && (i < list.length); ++i) {
/* 115 */       writer.write("<row>");
/* 116 */       for (int j = 0; j < list[i].length; ++j) {
/* 117 */         if (j > 0)
/* 118 */           writer.write(",");
/* 119 */         writer.write(list[i][j].toString());
/*     */       }
/* 121 */       writer.write("</row>");
/*     */     }
/* 123 */     writer.write("</root>");
/* 124 */     response.getWriter().write(writer.getBuffer().toString());
/*     */   }
/*     */ 
/*     */   public void refreshConfig(HttpServletRequest request, HttpServletResponse response) throws Exception {
/* 128 */     String configStr = HttpUtil.getParameter(request, "configstr");
/* 129 */     String id = HttpUtil.getParameter(request, "id");
/* 130 */     long pk = Long.parseLong(HttpUtil.getParameter(request, "pk"));
/* 131 */     String showType = HttpUtil.getParameter(request, "showtype");
/* 132 */     CrossGridManager manager = CrossGridManagerFactory.getManager(request);
/* 133 */     response.setContentType("text/html; charset=GBK");
/* 134 */     Writer writer = response.getWriter();
/* 135 */     manager.refreshConfig(writer, id, pk, configStr, false, showType);
/*     */   }
/*     */ 
/*     */   public void refreshSelectArea(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public static String encode(String s, String enc)
/*     */     throws Exception
/*     */   {
/* 148 */     int caseDiff = 32;
/*     */ 
/* 150 */     BitSet dontNeedEncoding = new BitSet(256);
/*     */ 
/* 152 */     for (int i = 97; i <= 122; ++i) {
/* 153 */       dontNeedEncoding.set(i);
/*     */     }
/* 155 */     for (i = 65; i <= 90; ++i) {
/* 156 */       dontNeedEncoding.set(i);
/*     */     }
/* 158 */     for (i = 48; i <= 57; ++i) {
/* 159 */       dontNeedEncoding.set(i);
/*     */     }
/* 161 */     dontNeedEncoding.set(32);
/*     */ 
/* 163 */     dontNeedEncoding.set(45);
/* 164 */     dontNeedEncoding.set(95);
/* 165 */     dontNeedEncoding.set(46);
/* 166 */     dontNeedEncoding.set(42);
/*     */ 
/* 170 */     boolean needToChange = false;
/* 171 */     boolean wroteUnencodedChar = false;
/* 172 */     int maxBytesPerChar = 10;
/* 173 */     StringBuilder out = new StringBuilder(s.length());
/* 174 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/*     */ 
/* 176 */     OutputStreamWriter writer = new OutputStreamWriter(buf, enc);
/*     */ 
/* 178 */     for (i = 0; i < s.length(); ++i) {
/* 179 */       int c = s.charAt(i);
/*     */ 
/* 181 */       if (dontNeedEncoding.get(c)) {
/* 182 */         if (c == 32) {
/* 183 */           c = 43;
/* 184 */           needToChange = true;
/*     */         }
/*     */ 
/* 187 */         out.append((char)c);
/* 188 */         label439: wroteUnencodedChar = true;
/*     */       }
/*     */       else {
/*     */         try {
/* 192 */           if (wroteUnencodedChar) {
/* 193 */             writer = new OutputStreamWriter(buf, enc);
/* 194 */             wroteUnencodedChar = false;
/*     */           }
/* 196 */           writer.write(c);
/*     */ 
/* 205 */           if ((c >= 55296) && (c <= 56319) && 
/* 210 */             (i + 1 < s.length())) {
/* 211 */             int d = s.charAt(i + 1);
/*     */ 
/* 216 */             if ((d >= 56320) && (d <= 57343))
/*     */             {
/* 222 */               writer.write(d);
/* 223 */               ++i;
/*     */             }
/*     */           }
/*     */ 
/* 227 */           writer.flush();
/*     */         } catch (IOException e) {
/* 229 */           buf.reset();
/* 230 */           break label439:
/*     */         }
/* 232 */         byte[] ba = buf.toByteArray();
/* 233 */         for (int j = 0; j < ba.length; ++j) {
/* 234 */           out.append('%');
/* 235 */           char ch = Character.forDigit(ba[j] >> 4 & 0xF, 16);
/*     */ 
/* 238 */           if (Character.isLetter(ch)) {
/* 239 */             ch = (char)(ch - caseDiff);
/*     */           }
/* 241 */           out.append(ch);
/* 242 */           ch = Character.forDigit(ba[j] & 0xF, 16);
/* 243 */           if (Character.isLetter(ch)) {
/* 244 */             ch = (char)(ch - caseDiff);
/*     */           }
/* 246 */           out.append(ch);
/*     */         }
/* 248 */         buf.reset();
/* 249 */         needToChange = true;
/*     */       }
/*     */     }
/*     */ 
/* 253 */     return (needToChange) ? out.toString() : s;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.CrossGricAction
 * JD-Core Version:    0.5.4
 */