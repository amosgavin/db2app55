/*     */ package com.ai.appframe2.analyse.web.tag;
/*     */ 
/*     */ import com.ai.appframe2.analyse.PivotList;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class AICrossGridPivotTag extends BodyTagSupport
/*     */ {
/*     */   public static final String AREA_SELECT = "SELECT";
/*     */   public static final String AREA_ROW = "ROW";
/*     */   public static final String AREA_COL = "COL";
/*  18 */   private static transient Log log = LogFactory.getLog(AICrossGridPivotTag.class);
/*     */   private String area;
/*  20 */   private String name = "";
/*  21 */   private String issubtotal = "false";
/*  22 */   private String issuppress = "true";
/*  23 */   private String selectvalue = null;
/*     */   private String ordertype;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*  37 */     if ((this.area == null) || (StringUtils.isBlank(this.area)))
/*     */     {
/*  39 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.area_null_error"));
/*     */ 
/*  41 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.area_null_error"));
/*     */     }
/*     */ 
/*  44 */     if ((this.name == null) || (StringUtils.isBlank(this.name)))
/*     */     {
/*  46 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.name_null_error"));
/*     */ 
/*  48 */       throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.name_null_error"));
/*     */     }
/*     */ 
/*  52 */     int areaIndex = 0;
/*     */ 
/*  54 */     boolean isSuppress = true;
/*  55 */     boolean isSubTotal = false;
/*  56 */     String orderType = "0";
/*     */ 
/*  58 */     if (this.area.equalsIgnoreCase("ROW")) {
/*  59 */       areaIndex = 1;
/*     */     }
/*  61 */     else if (this.area.equalsIgnoreCase("COL")) {
/*  62 */       areaIndex = 2;
/*     */     }
/*     */ 
/*  67 */     if (StringUtils.isBlank(this.selectvalue) == true) {
/*  68 */       this.selectvalue = null;
/*     */     }
/*     */ 
/*  75 */     if ((this.issubtotal != null) && ("true".equalsIgnoreCase(this.issubtotal))) {
/*  76 */       isSubTotal = true;
/*     */     }
/*     */ 
/*  79 */     if ((this.ordertype != null) && (!StringUtils.isBlank(this.ordertype)) && ((
/*  80 */       (this.ordertype.equalsIgnoreCase("asc")) || (this.ordertype.equalsIgnoreCase("desc")) || (this.ordertype.equalsIgnoreCase("0"))))) {
/*  81 */       orderType = this.ordertype;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  86 */       if (this.selectvalue == null) {
/*  87 */         ((AICrossGridTag)getParent()).getPivotList().addPivot(areaIndex, -1, this.name, 0, isSubTotal, isSuppress, orderType);
/*     */       }
/*     */       else {
/*  90 */         ((AICrossGridTag)getParent()).getPivotList().addPivot(areaIndex, -1, this.name, this.selectvalue, isSubTotal, isSuppress, orderType);
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  97 */       log.error(ex);
/*  98 */       throw new JspException(ex);
/*     */     }
/* 100 */     return 0;
/*     */   }
/*     */ 
/*     */   public int doStartTag()
/*     */     throws JspException
/*     */   {
/* 111 */     if (getParent() instanceof AICrossGridTag) {
/* 112 */       return 6;
/*     */     }
/*     */ 
/* 116 */     log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.CrossGridPivotTag_outOf_AICrossGridTag_error"));
/*     */ 
/* 118 */     throw new JspException(AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.web.tag.CrossGridPivotTag_outOf_AICrossGridTag_error"));
/*     */   }
/*     */ 
/*     */   public void setArea(String area)
/*     */   {
/* 126 */     this.area = area;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/* 130 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setIssubtotal(String issubtotal) {
/* 134 */     this.issubtotal = issubtotal;
/*     */   }
/*     */ 
/*     */   public void setIssuppress(String issuppress) {
/* 138 */     this.issuppress = issuppress;
/*     */   }
/*     */ 
/*     */   public void setSelectvalue(String selectvalue) {
/* 142 */     this.selectvalue = selectvalue;
/*     */   }
/*     */ 
/*     */   public void setOrdertype(String ordertype) {
/* 146 */     this.ordertype = ordertype;
/*     */   }
/*     */ 
/*     */   public String getOrdertype() {
/* 150 */     return this.ordertype;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.AICrossGridPivotTag
 * JD-Core Version:    0.5.4
 */