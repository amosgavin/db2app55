/*     */ package com.ai.appframe2.analyse.web.tag.common;
/*     */ 
/*     */ import com.ai.appframe2.analyse.web.tag.VmlDataSourceInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class CoordinateSystem
/*     */ {
/*     */   public InputData[] arrayData;
/*     */   public HashMap x_map;
/*     */   public String vColorHX;
/*     */   public String vColorXX;
/*     */   public int vFontSize;
/*     */   public long maxXI;
/*     */   public long maxYI;
/*     */   public int vWidth;
/*     */   public int vHeight;
/*     */   public double zeroX;
/*     */   public double zeroY;
/*     */   public double baseX;
/*     */   public double baseY;
/*     */   public double cellXlength;
/*     */   public double cellYlength;
/*     */   public double originFontX;
/*     */   public double originFontY;
/*     */   public double cellY;
/*     */   public ArrayList x_Array;
/*     */   public String vPercent;
/*     */   public String clickEventFun;
/*     */   public String dblClickEventFun;
/*     */   public String showX;
/*     */   public String showY;
/*  34 */   public int serialMax = 0;
/*     */   public double beginY;
/*     */   private static final long defaultMaxYI = 10L;
/*     */   private static final String defaultZeroColor = "black";
/*     */ 
/*     */   public CoordinateSystem(InputData[] gArrayData, int gWidth, int gHeight, String gColorHX, String gColorXX, int gFontSize, double gBaseX, double gBaseY, double gOriginFontX, double gOriginFontY, double gCellY, String gPercent, String gShowX, String gShowY, String gClickEventFun, String gDblClickEventFun)
/*     */   {
/*  51 */     this.arrayData = gArrayData;
/*  52 */     this.x_map = null;
/*  53 */     this.vColorHX = gColorHX;
/*  54 */     this.vColorXX = gColorXX;
/*  55 */     this.vFontSize = gFontSize;
/*  56 */     this.maxXI = 0L;
/*  57 */     this.maxYI = 0L;
/*  58 */     this.vWidth = gWidth;
/*  59 */     this.vHeight = gHeight;
/*  60 */     this.zeroX = gBaseX;
/*  61 */     this.zeroY = (gHeight - gBaseY);
/*  62 */     this.baseX = gBaseX;
/*  63 */     this.baseY = gBaseY;
/*  64 */     this.cellXlength = 0.0D;
/*  65 */     this.cellYlength = 0.0D;
/*  66 */     this.originFontX = gOriginFontX;
/*  67 */     this.originFontY = gOriginFontY;
/*  68 */     this.cellY = gCellY;
/*  69 */     this.x_Array = null;
/*  70 */     this.vPercent = gPercent;
/*  71 */     this.clickEventFun = gClickEventFun;
/*  72 */     this.dblClickEventFun = gDblClickEventFun;
/*  73 */     this.showX = gShowX;
/*  74 */     this.showY = gShowY;
/*  75 */     this.serialMax = 0;
/*     */ 
/*  77 */     this.beginY = 0.0D;
/*  78 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */   {
/*  83 */     this.x_Array = new ArrayList();
/*  84 */     HashMap tempArray = new HashMap();
/*     */ 
/*  86 */     long maxY = 0L;
/*  87 */     long minY = 0L;
/*  88 */     int tempArrayLength = 0;
/*  89 */     int i = 0;
/*  90 */     for (i = 0; i < this.arrayData.length; ++i) {
/*  91 */       maxY = (maxY < this.arrayData[i].y) ? this.arrayData[i].y : maxY;
/*  92 */       minY = (minY > this.arrayData[i].y) ? this.arrayData[i].y : minY;
/*  93 */       if (tempArray.get(this.arrayData[i].x) == null) {
/*  94 */         this.x_Array.add(tempArrayLength++, this.arrayData[i].x);
/*  95 */         tempArray.put(this.arrayData[i].x, this.arrayData[i].x);
/*     */       }
/*     */     }
/*  98 */     int iXArrayLength = this.x_Array.size();
/*  99 */     this.maxXI = (iXArrayLength + 1);
/*     */ 
/* 102 */     if (minY < 0L)
/*     */     {
/* 104 */       if (this.cellY == 0.0D) {
/* 105 */         this.maxYI = 10L;
/* 106 */         float rate = (float)(maxY / -minY);
/* 107 */         long max = maxY;
/* 108 */         if (rate < 1.0F) {
/* 109 */           rate = (float)(-minY / maxY);
/* 110 */           max = -minY;
/*     */         }
/* 112 */         int positiveYI = Math.round((float)(this.maxYI - 1L) * rate / (rate + 1.0F)) - 1;
/* 113 */         float tempCellY = (float)(max / positiveYI);
/* 114 */         int digit = 0;
/* 115 */         while (tempCellY > 10.0F) {
/* 116 */           tempCellY /= 10.0F;
/* 117 */           ++digit;
/*     */         }
/* 119 */         long longPer = 1L;
/* 120 */         tempCellY = Math.round(tempCellY);
/* 121 */         for (i = 0; i < digit; ++i) {
/* 122 */           tempCellY *= 10.0F;
/* 123 */           longPer *= 10L;
/*     */         }
/* 125 */         if (tempCellY * positiveYI >= (float)max) {
/* 126 */           this.cellY = tempCellY;
/*     */         }
/*     */         else {
/* 129 */           this.cellY = (tempCellY + (float)longPer);
/*     */         }
/* 131 */         this.beginY = (-(this.maxYI - 1L - positiveYI) * this.cellY);
/*     */       }
/*     */       else
/*     */       {
/* 135 */         double tempUp = maxY / this.cellY + 1.0D;
/* 136 */         double tempDown = -minY / this.cellY + 1.0D;
/* 137 */         long positiveYI = 0L;
/* 138 */         long negativeYI = 0L;
/* 139 */         if (tempUp % 1.0D >= 0.5D) {
/* 140 */           positiveYI = Math.round(tempUp);
/*     */         }
/*     */         else {
/* 143 */           positiveYI = Math.round(tempUp) + 1L;
/*     */         }
/* 145 */         if (tempDown % 1.0D >= 0.5D) {
/* 146 */           negativeYI = Math.round(tempDown);
/*     */         }
/*     */         else {
/* 149 */           negativeYI = Math.round(tempDown) + 1L;
/*     */         }
/* 151 */         this.maxYI = (positiveYI + negativeYI + 1L);
/* 152 */         this.beginY = (-(this.maxYI - 1L - positiveYI) * this.cellY);
/*     */       }
/*     */     }
/* 155 */     else if (this.cellY == 0.0D) {
/* 156 */       this.maxYI = 10L;
/*     */ 
/* 158 */       float tempCellY = (float)(maxY / (this.maxYI - 1L));
/* 159 */       int digit = 0;
/* 160 */       while (tempCellY > 10.0F) {
/* 161 */         tempCellY /= 10.0F;
/* 162 */         ++digit;
/*     */       }
/* 164 */       long longPer = 1L;
/* 165 */       tempCellY = Math.round(tempCellY);
/* 166 */       for (i = 0; i < digit; ++i) {
/* 167 */         tempCellY *= 10.0F;
/* 168 */         longPer *= 10L;
/*     */       }
/* 170 */       if (tempCellY * (float)(this.maxYI - 1L) >= (float)maxY) {
/* 171 */         this.cellY = tempCellY;
/*     */       }
/*     */       else {
/* 174 */         this.cellY = (tempCellY + (float)longPer);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 187 */       double temp = (maxY + 0.0D) / this.cellY + 1.0D;
/* 188 */       if (temp % 1.0D >= 0.5D) {
/* 189 */         this.maxYI = Math.round(temp);
/*     */       }
/*     */       else {
/* 192 */         this.maxYI = (Math.round(temp) + 1L);
/*     */       }
/* 194 */       this.maxYI += 1L;
/*     */     }
/*     */ 
/* 200 */     this.cellXlength = ((this.vWidth - this.baseX) / this.maxXI);
/* 201 */     this.cellYlength = ((this.vHeight - this.baseY) / this.maxYI);
/*     */ 
/* 203 */     this.x_map = new HashMap(iXArrayLength);
/* 204 */     for (i = 0; i < iXArrayLength; ++i) {
/* 205 */       this.x_map.put(this.x_Array.get(i), String.valueOf(this.zeroX + (i + 1) * this.cellXlength));
/*     */     }
/*     */ 
/* 210 */     initSerialInfo();
/*     */ 
/* 212 */     addRondamColor(this.arrayData);
/*     */   }
/*     */ 
/*     */   public long getX(String dataX)
/*     */     throws Throwable
/*     */   {
/* 218 */     if (this.x_map == null)
/*     */     {
/* 220 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.web.tag.common.coordinate_uninitial");
/* 221 */       throw new Exception(msg);
/*     */     }
/* 223 */     String x = String.valueOf(this.x_map.get(dataX));
/* 224 */     if (x == null)
/*     */     {
/* 226 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.web.tag.common.coordinate_notexist");
/* 227 */       throw new Exception(msg);
/*     */     }
/* 229 */     return Math.round(Double.parseDouble(x));
/*     */   }
/*     */ 
/*     */   public long getY(long dataY) {
/* 233 */     return Math.round(this.zeroY - (dataY - this.beginY) * this.cellYlength / this.cellY);
/*     */   }
/*     */ 
/*     */   public long getMaxX()
/*     */   {
/* 238 */     return Math.round(this.zeroX + this.maxXI * this.cellXlength);
/*     */   }
/*     */ 
/*     */   public long getMaxY() {
/* 242 */     return Math.round(this.zeroY - this.maxYI * this.cellYlength);
/*     */   }
/*     */ 
/*     */   public void initSerialInfo() {
/* 246 */     HashMap serial_map = new HashMap();
/* 247 */     for (int i = 0; i < this.arrayData.length; ++i)
/* 248 */       if (serial_map.get(this.arrayData[i].serialInfo) == null) {
/* 249 */         serial_map.put(this.arrayData[i].serialInfo, String.valueOf(this.serialMax));
/*     */ 
/* 251 */         this.arrayData[i].serialNum = this.serialMax;
/* 252 */         this.serialMax += 1;
/*     */       }
/*     */       else {
/* 255 */         this.arrayData[i].serialNum = Integer.parseInt(String.valueOf(serial_map.get(this.arrayData[i].serialInfo)));
/*     */       }
/*     */   }
/*     */ 
/*     */   public ChainNode draw()
/*     */   {
/* 265 */     StringBuilder divB = new StringBuilder();
/* 266 */     divB.append("<DIV style='WIDTH:").append(this.vPercent).append(";HEIGHT:").append(this.vPercent).append("' >");
/* 267 */     String divE = "</DIV>";
/*     */ 
/* 269 */     ChainNode beginNode = new ChainNode();
/* 270 */     ChainNode endNode = new ChainNode();
/* 271 */     beginNode.nowStr = divB.toString();
/* 272 */     beginNode.next = endNode;
/* 273 */     endNode.nowStr = divE;
/* 274 */     endNode.next = null;
/* 275 */     ChainNode strChain = beginNode;
/*     */ 
/* 277 */     StringBuilder groupB = new StringBuilder();
/* 278 */     groupB.append("<v:group  style='WIDTH:100%;HEIGHT:100%' coordorigin='0,0' coordsize = '").append(this.vWidth).append(",").append(this.vHeight).append("'  >");
/*     */ 
/* 280 */     String groupE = "</v:group>";
/* 281 */     beginNode = new ChainNode();
/* 282 */     endNode = new ChainNode();
/* 283 */     beginNode.nowStr = groupB.toString();
/* 284 */     beginNode.next = endNode;
/* 285 */     endNode.nowStr = groupE;
/* 286 */     endNode.next = null;
/* 287 */     strChain.addNode(divE, beginNode);
/*     */ 
/* 302 */     StringBuilder newYB = new StringBuilder();
/* 303 */     newYB.append("<v:line style='Z-INDEX: 8; POSITION: relative' from = '").append(this.zeroX).append(",").append(getMaxY()).append("' to = '").append(this.zeroX).append(",").append(this.zeroY).append("' strokeweight = '1pt'><v:stroke StartArrow = 'classic'></v:stroke>");
/*     */ 
/* 306 */     String newYE = "</v:line>";
/* 307 */     beginNode = new ChainNode();
/* 308 */     endNode = new ChainNode();
/* 309 */     beginNode.nowStr = newYB.toString();
/* 310 */     beginNode.next = endNode;
/* 311 */     endNode.nowStr = newYE;
/* 312 */     endNode.next = null;
/* 313 */     strChain.addNode(groupE, beginNode);
/*     */ 
/* 315 */     StringBuilder newXB = new StringBuilder();
/* 316 */     newXB.append("<v:line style='Z-INDEX: 8; POSITION: relative' from = '").append(this.zeroX).append(",").append(this.zeroY).append("' to = '").append(getMaxX()).append(",").append(this.zeroY).append("' strokeweight = '1pt'><v:stroke EndArrow = 'classic'></v:stroke>");
/*     */ 
/* 318 */     String newXE = "</v:line>";
/* 319 */     beginNode = new ChainNode();
/* 320 */     endNode = new ChainNode();
/* 321 */     beginNode.nowStr = newXB.toString();
/* 322 */     beginNode.next = endNode;
/* 323 */     endNode.nowStr = newXE;
/* 324 */     endNode.next = null;
/* 325 */     strChain.addNode(groupE, beginNode);
/*     */ 
/* 327 */     StringBuilder newZeroShapeB = new StringBuilder();
/* 328 */     newZeroShapeB.append("<v:shape style='position:relative;left:").append(this.originFontX).append(";top:").append(this.originFontY).append(";WIDTH:").append(Math.round(String.valueOf(this.beginY).length() * this.vFontSize)).append("pt;HEIGHT:").append(this.vFontSize).append("pt;z-index:8' fillcolor='white'><v:textbox  style=' FONT-SIZE: ").append(this.vFontSize).append("pt;' align='center' >").append(Math.round(this.beginY)).append("</v:textbox>");
/*     */ 
/* 335 */     String newZeroShapeE = "</v:shape>";
/* 336 */     beginNode = new ChainNode();
/* 337 */     endNode = new ChainNode();
/* 338 */     beginNode.nowStr = newZeroShapeB.toString();
/* 339 */     beginNode.next = endNode;
/* 340 */     endNode.nowStr = newZeroShapeE;
/* 341 */     endNode.next = null;
/* 342 */     strChain.addNode(groupE, beginNode);
/*     */ 
/* 345 */     for (int i = 1; i <= this.maxYI; ++i) {
/* 346 */       long py = Math.round(this.zeroY - i * this.cellYlength);
/* 347 */       String strTo = Math.round(this.zeroX + this.maxXI * this.cellXlength) + " " + py;
/* 348 */       if (i + 1 > this.maxYI) {
/* 349 */         StringBuilder newShapeB = new StringBuilder();
/* 350 */         newShapeB.append("<v:shape style='position:relative;left:").append(this.originFontX).append(";top:").append(py).append(";WIDTH:").append(Math.round(this.showY.length() * this.vFontSize)).append("pt;HEIGHT:").append(this.vFontSize).append("pt;z-index:8'  fillcolor='white'><v:textbox  style='font-size:").append(this.vFontSize).append("pt;v-text-anchor:bottom-up-baseline' align='right'>").append(this.showY).append("</v:textbox>");
/*     */ 
/* 354 */         String newShapeE = "</v:shape>";
/* 355 */         beginNode = new ChainNode();
/* 356 */         endNode = new ChainNode();
/* 357 */         beginNode.nowStr = newShapeB.toString();
/* 358 */         beginNode.next = endNode;
/* 359 */         endNode.nowStr = newShapeE;
/* 360 */         strChain.addNode(groupE, beginNode);
/*     */       } else {
/* 362 */         StringBuilder newLineB = new StringBuilder();
/* 363 */         newLineB.append("<v:line from='").append(this.zeroX).append(" ").append(py).append("' to='").append(strTo).append("' style='position:relative;z-index:8'>");
/*     */ 
/* 365 */         String newLineE = "</v:line>";
/*     */ 
/* 367 */         if (Math.round(this.beginY + i * this.cellY) == 0L) {
/* 368 */           newLineB.append("<v:stroke  color='").append("black").append("'/>");
/*     */         }
/* 370 */         else if ((i + 1) % 2 != 0) {
/* 371 */           newLineB.append("<v:stroke dashstyle='dot' color='").append(this.vColorHX).append("'/>");
/*     */         }
/*     */         else {
/* 374 */           newLineB.append("<v:stroke dashstyle='dot' color='").append(this.vColorXX).append("'/>");
/*     */         }
/*     */ 
/* 377 */         beginNode = new ChainNode();
/* 378 */         endNode = new ChainNode();
/* 379 */         beginNode.nowStr = newLineB.toString();
/* 380 */         beginNode.next = endNode;
/* 381 */         endNode.nowStr = newLineE;
/* 382 */         endNode.next = null;
/* 383 */         strChain.addNode(groupE, beginNode);
/*     */ 
/* 385 */         StringBuilder newShapeB = new StringBuilder();
/* 386 */         newShapeB.append("<v:shape style='position:relative;left:").append(this.originFontX).append(";top:").append(py).append(";WIDTH:").append(Math.round(String.valueOf(this.beginY + i * this.cellY).length() * this.vFontSize)).append("pt;HEIGHT:").append(this.vFontSize).append("pt;z-index:8'  fillcolor='white'><v:textbox   style='font-size:").append(this.vFontSize).append("pt;v-text-anchor:bottom-up-baseline' align='right'>").append(Math.round(this.beginY + i * this.cellY)).append("</v:textbox>");
/*     */ 
/* 393 */         String newShapeE = "</v:shape>";
/* 394 */         beginNode = new ChainNode();
/* 395 */         endNode = new ChainNode();
/* 396 */         beginNode.nowStr = newShapeB.toString();
/* 397 */         beginNode.next = endNode;
/* 398 */         endNode.nowStr = newShapeE;
/* 399 */         endNode.next = null;
/* 400 */         strChain.addNode(groupE, beginNode);
/*     */       }
/*     */     }
/*     */ 
/* 404 */     int i = 0;
/* 405 */     for (i = 0; i < this.x_Array.size(); ++i) {
/* 406 */       String xValue = String.valueOf(this.x_Array.get(i));
/*     */ 
/* 409 */       String xValue_modify = "";
/*     */       int k;
/* 410 */       if (xValue.length() > 3) {
/* 411 */         for (k = 0; k < xValue.length(); )
/*     */         {
/*     */           String tempValue;
/*     */           String tempValue;
/* 413 */           if (xValue.length() > k + 3)
/* 414 */             tempValue = xValue.substring(k, k + 3);
/*     */           else {
/* 416 */             tempValue = xValue.substring(k, xValue.length());
/*     */           }
/* 418 */           if (tempValue.getBytes().length == tempValue.length()) {
/* 419 */             xValue_modify = xValue_modify + tempValue + "<br>";
/* 420 */             k += 3;
/*     */           } else {
/* 422 */             xValue_modify = xValue_modify + xValue.substring(k, k + 1);
/* 423 */             ++k;
/*     */           }
/*     */         }
/*     */       }
/* 427 */       long px = Math.round(this.zeroX + (i + 1) * this.cellXlength);
/* 428 */       StringBuilder newLineB = new StringBuilder();
/* 429 */       newLineB.append("<v:line from='").append(px).append(" ").append(this.zeroY).append("' to='").append(px).append(" ").append(this.zeroY + 50.0D).append("' style='position:relative;z-index:8'><v:stroke color='black'/>");
/*     */ 
/* 431 */       String newLineE = "</v:line>";
/* 432 */       beginNode = new ChainNode();
/* 433 */       endNode = new ChainNode();
/* 434 */       beginNode.nowStr = newLineB.toString();
/* 435 */       beginNode.next = endNode;
/* 436 */       endNode.nowStr = newLineE;
/* 437 */       endNode.next = null;
/* 438 */       strChain.addNode(groupE, beginNode);
/*     */ 
/* 440 */       StringBuilder newShapeB = new StringBuilder();
/* 441 */       newShapeB.append("<v:shape style='position:relative;left:").append(px - 100L).append(";top:").append(this.zeroY).append(";WIDTH:").append(Math.round(xValue.length() * this.vFontSize)).append(";HEIGHT:").append(this.vFontSize * 10).append("pt;z-index:8'  fillcolor='white'><v:textbox  style='font-size:").append(this.vFontSize).append("pt;v-text-anchor:bottom-right-baseline' align='right'>").append(xValue_modify).append("</v:textbox>");
/*     */ 
/* 445 */       String newShapeE = "</v:shape>";
/* 446 */       beginNode = new ChainNode();
/* 447 */       endNode = new ChainNode();
/* 448 */       beginNode.nowStr = newShapeB.toString();
/* 449 */       beginNode.next = endNode;
/* 450 */       endNode.nowStr = newShapeE;
/* 451 */       endNode.next = null;
/* 452 */       strChain.addNode(groupE, beginNode);
/*     */     }
/*     */ 
/* 457 */     long px = Math.round(this.zeroX + (i + 1) * this.cellXlength - this.cellXlength / 2.0D);
/*     */ 
/* 459 */     StringBuilder newShapeB = new StringBuilder();
/* 460 */     newShapeB.append("<v:shape style='position:relative;left:").append(px - 100L).append(";top:").append(this.zeroY).append(";WIDTH:").append(Math.round(this.showX.length() * this.vFontSize)).append("pt;HEIGHT:").append(this.vFontSize).append("pt;z-index:8'  fillcolor='white'><v:textbox   style='font-size:").append(this.vFontSize).append("pt;v-text-anchor:bottom-right-baseline' align='right'>").append(this.showX).append("</v:textbox>");
/*     */ 
/* 464 */     String newShapeE = "</v:shape>";
/* 465 */     beginNode = new ChainNode();
/* 466 */     endNode = new ChainNode();
/* 467 */     beginNode.nowStr = newShapeB.toString();
/* 468 */     beginNode.next = endNode;
/* 469 */     endNode.nowStr = newShapeE;
/* 470 */     endNode.next = null;
/* 471 */     strChain.addNode(groupE, beginNode);
/*     */ 
/* 473 */     return strChain;
/*     */   }
/*     */ 
/*     */   public void drawBars(ChainNode strChain, double barWidthper)
/*     */     throws Throwable
/*     */   {
/* 479 */     double vBarWidthper = barWidthper / this.serialMax;
/* 480 */     for (int i = 0; i < this.arrayData.length; ++i)
/*     */     {
/* 482 */       long px = Math.round(getX(this.arrayData[i].x) - this.cellXlength * vBarWidthper * (this.serialMax / 2.0D - this.arrayData[i].serialNum));
/* 483 */       long py = Math.round((float)getY(this.arrayData[i].y));
/* 484 */       long tempWidth = Math.round(vBarWidthper * this.cellXlength);
/* 485 */       long tempHeight = 0L;
/*     */ 
/* 487 */       long tempZeroY = getY(0L);
/* 488 */       if (tempZeroY < py) {
/* 489 */         tempHeight = Math.round((float)(py - tempZeroY));
/* 490 */         py = tempZeroY;
/*     */       } else {
/* 492 */         tempHeight = Math.round((float)(tempZeroY - py));
/*     */       }
/*     */ 
/* 498 */       StringBuilder rectB = new StringBuilder();
/* 499 */       rectB.append("<v:rect style='position:relative;left:").append(px).append(";top:").append(py).append(";WIDTH: ").append(tempWidth).append("; HEIGHT: ").append(tempHeight).append("'  fillcolor='").append(this.arrayData[i].color).append("' strokecolor = 'black' ");
/*     */ 
/* 502 */       if ((this.clickEventFun != null) && (this.clickEventFun.length() > 0)) {
/* 503 */         rectB.append(" onclick=\"").append(this.clickEventFun).append("('").append(this.arrayData[i].x).append("','").append(this.arrayData[i].y).append("')\"");
/*     */       }
/*     */ 
/* 506 */       if ((this.dblClickEventFun != null) && (this.dblClickEventFun.length() > 0)) {
/* 507 */         rectB.append(" ondblclick=\"").append(this.dblClickEventFun).append("('").append(this.arrayData[i].x).append("','").append(this.arrayData[i].y).append("')\"");
/*     */       }
/*     */ 
/* 510 */       rectB.append("title='").append(this.arrayData[i].serialInfo + " ").append(this.arrayData[i].x).append(" ").append(this.arrayData[i].y).append(this.showY).append("' >");
/* 511 */       String rectE = "</v:rect>";
/* 512 */       ChainNode beginNode = new ChainNode();
/* 513 */       ChainNode endNode = new ChainNode();
/* 514 */       beginNode.nowStr = rectB.toString();
/* 515 */       beginNode.next = endNode;
/* 516 */       endNode.nowStr = rectE;
/* 517 */       endNode.next = null;
/* 518 */       strChain.addNode("</v:group>", beginNode);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void drawLines(ChainNode strChain)
/*     */     throws Throwable
/*     */   {
/* 525 */     int i = 0;
/* 526 */     HashMap flagArray = new HashMap();
/* 527 */     for (int j = 0; j < this.serialMax; ++j) {
/* 528 */       StringBuilder polyLineB = new StringBuilder();
/* 529 */       polyLineB.append("<v:polyLine style='z-index:9' filled=f strokeweight=1.5pt ");
/* 530 */       String polyLineE = "</v:polyLine>";
/* 531 */       for (i = 0; i < this.arrayData.length; ++i) {
/* 532 */         if (this.arrayData[i].serialNum == j) {
/* 533 */           if (flagArray.get(String.valueOf(j)) == null) {
/* 534 */             flagArray.put(String.valueOf(j), String.valueOf(j));
/* 535 */             polyLineB.append("strokecolor='").append(this.arrayData[i].color).append("'  points='");
/*     */           }
/* 537 */           long px = getX(this.arrayData[i].x);
/*     */ 
/* 539 */           long py = getY(this.arrayData[i].y);
/* 540 */           polyLineB.append(px).append(",").append(py).append(" ");
/*     */         }
/*     */       }
/* 543 */       polyLineB.append("'>");
/* 544 */       ChainNode beginNode = new ChainNode();
/* 545 */       ChainNode endNode = new ChainNode();
/* 546 */       beginNode.nowStr = polyLineB.toString();
/* 547 */       beginNode.next = endNode;
/* 548 */       endNode.nowStr = polyLineE;
/* 549 */       endNode.next = null;
/* 550 */       strChain.addNode("</v:group>", beginNode);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final void addRondamColor(InputData[] arrayData)
/*     */   {
/* 561 */     HashMap ColorArray = new HashMap();
/* 562 */     for (int i = 0; i < arrayData.length; ++i)
/* 563 */       if (arrayData[i].color == null) {
/* 564 */         if (ColorArray.get(String.valueOf(arrayData[i].serialNum)) == null) {
/* 565 */           ColorArray.put(String.valueOf(arrayData[i].serialNum), "rgb(" + Math.round(Math.random() * 255.0D) + "," + Math.round(Math.random() * 255.0D) + "," + Math.round(Math.random() * 255.0D) + ")");
/*     */         }
/*     */ 
/* 570 */         arrayData[i].color = String.valueOf(ColorArray.get(String.valueOf(arrayData[i].serialNum)));
/*     */       }
/*     */   }
/*     */ 
/*     */   public static final InputData[] getVmlDataSource(String strImplClassName) throws Throwable
/*     */   {
/* 576 */     Class dataSourceClass = Class.forName(strImplClassName);
/* 577 */     VmlDataSourceInterface objDataSource = (VmlDataSourceInterface)dataSourceClass.newInstance();
/* 578 */     return objDataSource.getVmlData();
/*     */   }
/*     */ 
/*     */   public int getSerialMax() {
/* 582 */     return this.serialMax;
/*     */   }
/*     */ 
/*     */   public ArrayList getX_Array() {
/* 586 */     return this.x_Array;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.web.tag.common.CoordinateSystem
 * JD-Core Version:    0.5.4
 */