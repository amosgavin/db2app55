/*     */ package com.ai.appframe2.analyse;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCell;
/*     */ import org.apache.poi.hssf.usermodel.HSSFCellStyle;
/*     */ import org.apache.poi.hssf.usermodel.HSSFFont;
/*     */ import org.apache.poi.hssf.usermodel.HSSFRow;
/*     */ import org.apache.poi.hssf.usermodel.HSSFSheet;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.hssf.util.Region;
/*     */ 
/*     */ public class McGrid
/*     */   implements McGridInterface
/*     */ {
/*     */   protected CrossGridImpl m_crossGrid;
/*     */   protected PivotList m_pivots;
/*  31 */   protected boolean isDKE = false;
/*     */   protected int rowCount;
/*     */   protected int colCount;
/*     */   protected int rowHeadCount;
/*     */   protected int tableHeadCount;
/*  41 */   protected CrossGridNode tableHead = new CrossGridNode(-1, -1);
/*     */ 
/*  43 */   protected CrossGridNode rowHead = new CrossGridNode(-1, -1);
/*     */ 
/*  45 */   protected List tableHeadSubTotal = new ArrayList();
/*     */ 
/*  47 */   protected List rowHeadSubTotal = new ArrayList();
/*     */   protected int measIndex;
/*     */   protected int[] indexRec;
/*  53 */   public static String CONTEXT_PATH = "";
/*     */ 
/* 903 */   private short currentRow = -1;
/*     */ 
/* 906 */   private short currentCol = 0;
/*     */   private HSSFWorkbook workBook;
/*     */   private HSSFSheet sheet;
/*     */ 
/*     */   public void setPivots(PivotList aPivots)
/*     */   {
/*  60 */     this.m_pivots = aPivots;
/*     */   }
/*     */ 
/*     */   public PivotList getPivots() {
/*  64 */     return this.m_pivots;
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  68 */     this.rowCount = 0;
/*  69 */     this.colCount = 0;
/*  70 */     this.rowHeadCount = this.m_pivots.size(Pivot.ROW_AREA);
/*  71 */     this.tableHeadCount = this.m_pivots.size(Pivot.COL_AREA);
/*     */ 
/*  73 */     this.tableHead.clear();
/*  74 */     this.rowHead.clear();
/*  75 */     this.tableHeadSubTotal.clear();
/*  76 */     this.rowHeadSubTotal.clear();
/*  77 */     this.measIndex = -1;
/*  78 */     this.indexRec = new int[this.m_crossGrid.getDimCount()];
/*     */   }
/*     */ 
/*     */   public int getDimValueIndex(int rowIndex, int colIndex)
/*     */     throws Exception
/*     */   {
/*  86 */     int result = -1;
/*  87 */     if ((rowIndex >= this.tableHeadCount) && (colIndex < this.rowHeadCount))
/*  88 */       result = this.rowHead.get(rowIndex - this.tableHeadCount, colIndex);
/*  89 */     else if ((rowIndex < this.tableHeadCount) && (colIndex >= this.rowHeadCount))
/*     */     {
/*  91 */       result = this.tableHead.get(colIndex - this.rowHeadCount, rowIndex);
/*  92 */     }return result;
/*     */   }
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/*     */     int result;
/*     */     int result;
/*  97 */     if ((this.rowCount == 0) && (this.colCount == 0)) {
/*  98 */       result = 1;
/*     */     }
/*     */     else
/*     */     {
/*     */       int result;
/*  99 */       if (this.rowCount == 0)
/* 100 */         result = 1 + this.tableHeadCount;
/*     */       else
/* 102 */         result = this.rowCount + this.tableHeadCount; 
/*     */     }
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   public int getColCount()
/*     */   {
/*     */     int result;
/*     */     int result;
/* 108 */     if ((this.rowCount == 0) && (this.colCount == 0)) {
/* 109 */       result = 1;
/*     */     }
/*     */     else
/*     */     {
/*     */       int result;
/* 110 */       if (this.colCount == 0)
/* 111 */         result = this.rowHeadCount + 1;
/*     */       else
/* 113 */         result = this.rowHeadCount + this.colCount; 
/*     */     }
/* 114 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean rowIsSubTotal(int rowIndex)
/*     */   {
/*     */     boolean result;
/*     */     boolean result;
/* 120 */     if (rowIndex < this.tableHeadCount) {
/* 121 */       result = false;
/*     */     }
/*     */     else
/*     */     {
/*     */       boolean result;
/* 122 */       if (this.rowCount == 0)
/* 123 */         result = false;
/*     */       else
/* 125 */         result = ((Boolean)this.rowHeadSubTotal.get(rowIndex - this.tableHeadCount)).booleanValue();
/*     */     }
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean colIsSubTotal(int colIndex)
/*     */   {
/*     */     boolean result;
/*     */     boolean result;
/* 133 */     if (colIndex < this.rowHeadCount) {
/* 134 */       result = false;
/*     */     }
/*     */     else
/*     */     {
/*     */       boolean result;
/* 135 */       if (this.colCount == 0)
/* 136 */         result = false;
/*     */       else
/* 138 */         result = ((Boolean)this.tableHeadSubTotal.get(colIndex - this.rowHeadCount)).booleanValue();
/*     */     }
/* 140 */     return result;
/*     */   }
/*     */ 
/*     */   private Pivot getPivot(List[] aPivots, int aAreaIndex, int index) throws Exception
/*     */   {
/* 145 */     return (Pivot)aPivots[aAreaIndex].get(index);
/*     */   }
/*     */ 
/*     */   public void initial(String contextPath, CrossGridImpl aCrossGrid, PivotList aPivots, boolean aIsDKE) throws Exception
/*     */   {
/* 150 */     this.isDKE = true;
/* 151 */     this.m_crossGrid = aCrossGrid;
/* 152 */     this.m_pivots = aPivots;
/*     */ 
/* 154 */     clear();
/* 155 */     int[] tmpRows = null;
/* 156 */     boolean isIncComputer = true;
/* 157 */     CONTEXT_PATH = contextPath;
/*     */ 
/* 159 */     if (!this.isDKE) {
/* 160 */       boolean isAllSubTotal = true;
/* 161 */       List rowsArray = new ArrayList();
/* 162 */       for (int i = 0; i < this.m_pivots.size(Pivot.SELECT_AREA); ++i) {
/* 163 */         Pivot p = this.m_pivots.getPivot(this.m_crossGrid, Pivot.SELECT_AREA, i);
/*     */ 
/* 165 */         DimensionOrMeas obj = this.m_crossGrid.getDimOrMeasByIndex(p.dimIndex);
/*     */ 
/* 168 */         if (p.selectValueIndex != obj.count()) {
/* 169 */           isAllSubTotal = false;
/*     */         }
/* 171 */         int[] t = obj.getRows(p.selectValueIndex);
/* 172 */         if ((t != null) && (t.length > 0))
/* 173 */           rowsArray.add(t);
/*     */       }
/* 175 */       if (rowsArray.size() > 0)
/* 176 */         tmpRows = this.m_crossGrid.intersection(rowsArray);
/* 177 */       rowsArray.clear();
/* 178 */       if ((!isAllSubTotal) && (((tmpRows == null) || (tmpRows.length == 0))))
/*     */       {
/* 180 */         isIncComputer = false;
/*     */       }
/*     */     }
/* 183 */     if (isIncComputer == true) {
/* 184 */       if (this.m_pivots.size(Pivot.COL_AREA) > 0) {
/* 185 */         List tmpList = new ArrayList();
/* 186 */         this.tableHead.setRange(this.m_crossGrid.incMcGridIndexTreeNode(this.m_pivots, tmpList, null, Pivot.COL_AREA, 0, tmpRows, this.tableHeadSubTotal));
/*     */ 
/* 189 */         this.tableHead.setChilds(tmpList);
/* 190 */         tmpList = null;
/*     */       }
/*     */ 
/* 193 */       if (this.m_pivots.size(Pivot.ROW_AREA) > 0) {
/* 194 */         List tmpList = new ArrayList();
/* 195 */         this.rowHead.setRange(this.m_crossGrid.incMcGridIndexTreeNode(this.m_pivots, tmpList, null, Pivot.ROW_AREA, 0, tmpRows, this.rowHeadSubTotal));
/*     */ 
/* 198 */         this.rowHead.setChilds(tmpList);
/* 199 */         tmpList = null;
/*     */       }
/*     */     }
/*     */ 
/* 203 */     this.rowCount = this.rowHead.getRange();
/* 204 */     this.colCount = this.tableHead.getRange();
/*     */ 
/* 207 */     for (int i = 0; i < this.m_pivots.size(Pivot.SELECT_AREA); ++i) {
/* 208 */       Pivot p = this.m_pivots.getPivot(this.m_crossGrid, Pivot.SELECT_AREA, i);
/*     */ 
/* 210 */       if (p.dimIndex == this.m_crossGrid.getDimCount())
/* 211 */         this.measIndex = p.selectValueIndex;
/*     */       else
/* 213 */         this.indexRec[p.dimIndex] = p.selectValueIndex;
/*     */     }
/*     */   }
/*     */ 
/*     */   public CrossGridNode getRowHead() {
/* 218 */     return this.rowHead;
/*     */   }
/*     */ 
/*     */   public CrossGridImpl getCrossGridImpl() {
/* 222 */     return this.m_crossGrid;
/*     */   }
/*     */ 
/*     */   public long getPk() {
/* 226 */     return this.m_crossGrid.getPk();
/*     */   }
/*     */ 
/*     */   protected void toHtmlRowData(Writer writer, int level) throws Exception {
/* 230 */     if (level == 0) {
/* 231 */       writer.write("<tr height='25' borderColor=\"#000000\"");
/* 232 */       writer.write(" isRowTotal=\"false\"");
/* 233 */       writer.write(">");
/*     */     }
/*     */ 
/* 237 */     if (this.tableHead.getRange() > 0) {
/* 238 */       for (int i = 0; i < this.tableHead.getRange(); ++i) {
/* 239 */         for (int j = 0; j < this.m_pivots.pivots[Pivot.COL_AREA].size(); ++j) {
/* 240 */           CrossGridNode tmpNode = this.tableHead.getObject(i, j);
/* 241 */           if (tmpNode.getDimIndex() == this.m_crossGrid.getDimCount())
/* 242 */             this.measIndex = tmpNode.getDimValueIndex();
/*     */           else {
/* 244 */             this.indexRec[tmpNode.getDimIndex()] = tmpNode.getDimValueIndex();
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 249 */         writer.write("<td class='CrossGrid_Data' style='BORDER-RIGHT: #000 1px solid; BORDER-TOP: #000 0px solid; BORDER-LEFT: #000 0px solid; BORDER-BOTTOM: #000 1px solid; WHITE-SPACE: nowrap'>");
/*     */ 
/* 254 */         Object obj = this.m_crossGrid.getFactData(this.indexRec, this.measIndex);
/*     */ 
/* 256 */         if (obj != null) {
/* 257 */           writer.write(obj.toString());
/*     */         }
/*     */         else
/*     */         {
/* 261 */           writer.write("&nbsp;");
/*     */         }
/* 263 */         writer.write("</td>");
/*     */       }
/* 265 */     } else if (this.measIndex >= 0) {
/* 266 */       writer.write("<td width='100' class='CrossGrid_Data'>");
/* 267 */       Object obj = this.m_crossGrid.getFactData(this.indexRec, this.measIndex);
/* 268 */       if (obj != null)
/* 269 */         writer.write(obj.toString());
/* 270 */       writer.write("</td>");
/*     */     }
/* 272 */     if (level == 0)
/* 273 */       writer.write("</tr>");
/*     */   }
/*     */ 
/*     */   protected void toXlsRowData(int level) throws Exception
/*     */   {
/* 278 */     HSSFCellStyle aCellStyle = this.workBook.createCellStyle();
/* 279 */     aCellStyle.setAlignment(3);
/* 280 */     aCellStyle.setVerticalAlignment(1);
/* 281 */     aCellStyle.setBorderBottom(1);
/* 282 */     aCellStyle.setBorderTop(1);
/* 283 */     aCellStyle.setBorderLeft(1);
/* 284 */     aCellStyle.setBorderRight(1);
/*     */ 
/* 286 */     if (level == 0)
/*     */     {
/* 291 */       this.currentRow = (short)(this.currentRow + 1);
/* 292 */       this.currentCol = 0;
/*     */     }
/*     */ 
/* 296 */     if (this.tableHead.getRange() > 0) {
/* 297 */       for (int i = 0; i < this.tableHead.getRange(); ++i) {
/* 298 */         for (int j = 0; j < this.m_pivots.pivots[Pivot.COL_AREA].size(); ++j) {
/* 299 */           CrossGridNode tmpNode = this.tableHead.getObject(i, j);
/* 300 */           if (tmpNode.getDimIndex() == this.m_crossGrid.getDimCount())
/* 301 */             this.measIndex = tmpNode.getDimValueIndex();
/*     */           else {
/* 303 */             this.indexRec[tmpNode.getDimIndex()] = tmpNode.getDimValueIndex();
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 309 */         Object obj = this.m_crossGrid.getFactData(this.indexRec, this.measIndex);
/*     */ 
/* 311 */         if (obj != null) {
/* 312 */           setValueByRowCol(this.currentRow, this.currentCol, obj.toString(), aCellStyle);
/*     */ 
/* 314 */           this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */         }
/*     */         else
/*     */         {
/* 318 */           setValueByRowCol(this.currentRow, this.currentCol, "", aCellStyle);
/*     */ 
/* 320 */           this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */         }
/*     */ 
/* 324 */         this.currentCol = (short)(this.currentCol + 1);
/*     */       }
/*     */     }
/*     */     else {
/* 328 */       Object obj = this.m_crossGrid.getFactData(this.indexRec, this.measIndex);
/* 329 */       if (obj != null) {
/* 330 */         setValueByRowCol(this.currentRow, this.currentCol, obj.toString(), aCellStyle);
/*     */ 
/* 332 */         this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */       }
/*     */ 
/* 338 */       this.currentCol = (short)(this.currentCol + 1);
/*     */     }
/* 340 */     if (level != 0)
/*     */       return;
/*     */   }
/*     */ 
/*     */   private void toHtmlRowHead(Writer writer, CrossGridNode node, int level, int startRow, boolean parentIsSubTotal, String parentRows)
/*     */     throws Exception
/*     */   {
/* 349 */     List tmpList = node.getChilds();
/* 350 */     if (tmpList == null) {
/* 351 */       toHtmlRowData(writer, level);
/* 352 */       return;
/*     */     }
/*     */ 
/* 357 */     for (int i = 0; i < tmpList.size(); ++i) {
/* 358 */       CrossGridNode tmpNode = (CrossGridNode)tmpList.get(i);
/* 359 */       String tmpParentRows = parentRows;
/*     */ 
/* 361 */       if ((level == 0) || (i > 0))
/*     */       {
/* 364 */         writer.write("<tr parentRows=\"" + parentRows + "\" height='25'>");
/*     */ 
/* 366 */         tmpParentRows = "" + startRow;
/* 367 */         if (level > 0) {
/* 368 */           tmpParentRows = parentRows + "," + startRow;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 375 */       writer.write("<td class='CrossGridRowHead_Value' style='BORDER-RIGHT: #808080 2px solid; BORDER-BOTTOM: black 1px solid; FONT-WEIGHT: bold;LEFT: expression(this.parentElement.offsetParent.parentElement.scrollLeft);POSITION: relative;BORDER-LEFT: black 0px solid; COLOR: #004080; WHITE-SPACE: nowrap; ' dimValueIndex=\"" + tmpNode.getDimValueIndex() + "\" rowlevel=\"" + level + "\" rowspan=\"" + tmpNode.getRange() + "\">");
/*     */ 
/* 383 */       Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.ROW_AREA, level);
/* 384 */       DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 386 */       if (tmpNode.getDimIndex() == this.m_crossGrid.getDimCount())
/* 387 */         this.measIndex = tmpNode.getDimValueIndex();
/*     */       else {
/* 389 */         this.indexRec[tmpNode.getDimIndex()] = tmpNode.getDimValueIndex();
/*     */       }
/*     */ 
/* 392 */       boolean tmpParentIsSubTotal = parentIsSubTotal;
/* 393 */       if (!parentIsSubTotal) {
/* 394 */         writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/* 395 */         tmpParentIsSubTotal = tmpNode.getDimValueIndex() == tmpDim.count();
/*     */       }
/*     */       else
/*     */       {
/* 400 */         writer.write("&nbsp;");
/*     */       }
/* 402 */       writer.write("</td>");
/*     */ 
/* 404 */       toHtmlRowHead(writer, tmpNode, level + 1, startRow, tmpParentIsSubTotal, tmpParentRows);
/*     */ 
/* 407 */       startRow += tmpNode.getRange();
/* 408 */       if ((level == 0) || (i > 0))
/* 409 */         writer.write("</tr>\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void toXlsRowHead(CrossGridNode node, int level, int startRow, boolean parentIsSubTotal, String parentRows)
/*     */     throws Exception
/*     */   {
/* 417 */     List tmpList = node.getChilds();
/* 418 */     HSSFCellStyle aCellStyle = this.workBook.createCellStyle();
/* 419 */     aCellStyle.setAlignment(2);
/* 420 */     aCellStyle.setVerticalAlignment(1);
/* 421 */     aCellStyle.setBorderBottom(1);
/* 422 */     aCellStyle.setBorderTop(1);
/* 423 */     aCellStyle.setBorderLeft(1);
/* 424 */     aCellStyle.setBorderRight(1);
/*     */ 
/* 427 */     if (tmpList == null) {
/* 428 */       toXlsRowData(level);
/* 429 */       return;
/*     */     }
/*     */ 
/* 434 */     for (int i = 0; i < tmpList.size(); ++i) {
/* 435 */       CrossGridNode tmpNode = (CrossGridNode)tmpList.get(i);
/* 436 */       String tmpParentRows = parentRows;
/*     */ 
/* 438 */       if ((level == 0) || (i > 0)) {
/* 439 */         this.currentRow = (short)(this.currentRow + 1);
/*     */ 
/* 444 */         tmpParentRows = "" + startRow;
/* 445 */         if (level > 0) {
/* 446 */           tmpParentRows = parentRows + "," + startRow;
/*     */         }
/*     */       }
/*     */ 
/* 450 */       this.currentCol = (short)level;
/* 451 */       int mStartRow = this.currentRow;
/* 452 */       int mEndRow = this.currentRow;
/* 453 */       short mStartCol = this.currentCol;
/* 454 */       short mEndCol = this.currentCol;
/* 455 */       short aRowSpan = (short)tmpNode.getRange();
/* 456 */       if (aRowSpan > 1) {
/* 457 */         mEndRow = (short)(mStartRow + aRowSpan - 1);
/* 458 */         Region aMergedRegion = new Region(mStartRow, mStartCol, mEndRow, mEndCol);
/*     */ 
/* 460 */         this.sheet.addMergedRegion(aMergedRegion);
/*     */ 
/* 462 */         for (short k = this.currentRow; k < this.currentRow + aRowSpan; k = (short)(k + 1)) {
/* 463 */           setValueByRowCol(k, this.currentCol, "", aCellStyle);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 471 */       this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/* 472 */       Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.ROW_AREA, level);
/*     */ 
/* 474 */       DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 477 */       if (tmpNode.getDimIndex() == this.m_crossGrid.getDimCount())
/* 478 */         this.measIndex = tmpNode.getDimValueIndex();
/*     */       else {
/* 480 */         this.indexRec[tmpNode.getDimIndex()] = tmpNode.getDimValueIndex();
/*     */       }
/*     */ 
/* 484 */       boolean tmpParentIsSubTotal = parentIsSubTotal;
/* 485 */       if (!parentIsSubTotal)
/*     */       {
/* 487 */         setValueByRowCol(this.currentRow, this.currentCol, tmpDim.getDesc(tmpNode.getDimValueIndex()), aCellStyle);
/*     */ 
/* 489 */         tmpParentIsSubTotal = tmpNode.getDimValueIndex() == tmpDim.count();
/*     */       }
/*     */ 
/* 493 */       this.currentCol = (short)(this.currentCol + 1);
/*     */ 
/* 495 */       toXlsRowHead(tmpNode, level + 1, startRow, tmpParentIsSubTotal, tmpParentRows);
/*     */ 
/* 498 */       startRow += tmpNode.getRange();
/* 499 */       if ((level == 0) || (i <= 0))
/*     */         continue;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void toHtmlTableHead(Writer writer)
/*     */     throws Exception
/*     */   {
/* 509 */     List tmpList = new ArrayList();
/*     */ 
/* 515 */     if (this.tableHeadCount == 0) {
/* 516 */       if (getPivots().size(Pivot.ROW_AREA) <= 0) {
/*     */         return;
/*     */       }
/*     */ 
/* 520 */       writer.write("<TR style='FONT-WEIGHT: bold; Z-INDEX: 5; POSITION: relative;TOP: expression(this.offsetParent.scrollTop)' colPivot='0' class=\"G-TableHead\">");
/*     */ 
/* 523 */       for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j)
/*     */       {
/* 526 */         writer.write("<td class='CrossGridRowHead_Name' style='BORDER-RIGHT: #808080 2px solid; BORDER-LEFT-WIDTH: 0px; Z-INDEX: 10;LEFT: expression(this.parentElement.offsetParent.scrollLeft); WHITE-SPACE: nowrap; POSITION: relative;BORDER-BOTTOM: #808080 2px solid'>" + this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName() + "</td>");
/*     */       }
/*     */ 
/* 533 */       if (this.measIndex >= 0)
/*     */       {
/* 536 */         writer.write("<td class='CrossGridColHead' style='BORDER-LEFT: #000000 0px solid; COLOR: #800000; BORDER-BOTTOM: #000000 1px solid;WHITE-SPACE: nowrap; POSITION: relative' collevel='1'>" + this.m_crossGrid.getMeas().getDesc(this.measIndex) + "</td>");
/*     */       }
/*     */       else
/*     */       {
/* 543 */         String strData = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.McGrid.data");
/* 544 */         writer.write("<td class='CrossGridColHead' style='BORDER-LEFT: #000000 0px solid; COLOR: #800000; BORDER-BOTTOM: #000000 1px solid;WHITE-SPACE: nowrap; POSITION: relative;' collevel='1'>" + strData + "</td>");
/*     */       }
/*     */ 
/* 547 */       writer.write("</tr>");
/*     */     }
/*     */     else
/*     */     {
/* 553 */       for (int i = 0; i < this.tableHeadCount; ++i)
/*     */       {
/* 556 */         writer.write("<TR style='FONT-WEIGHT: bold; Z-INDEX: 5; POSITION: relative;TOP: expression(this.offsetParent.scrollTop)' colPivot='0' class=\"G-TableHead\">");
/*     */ 
/* 559 */         if (getPivots().size(Pivot.ROW_AREA) > 0) {
/* 560 */           if (i == this.tableHeadCount - 1) {
/* 561 */             for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j)
/*     */             {
/* 564 */               writer.write("<td class='CrossGridRowHead_Name' style='BORDER-RIGHT: #808080 2px solid; BORDER-LEFT-WIDTH: 0px; Z-INDEX: 10;LEFT: expression(this.parentElement.offsetParent.scrollLeft);WHITE-SPACE: nowrap; POSITION: relative;BORDER-BOTTOM: #808080 2px solid'>" + this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName() + "</td>");
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 578 */             writer.write("<td style='BORDER-RIGHT: #808080 2px solid; BORDER-LEFT-WIDTH: 0px; Z-INDEX: 10;LEFT: expression(this.parentElement.offsetParent.scrollLeft); WHITE-SPACE: nowrap; POSITION: relative; BORDER-BOTTOM: #808080 2px solid'  class='CrossGridRowHead_Name' colspan=\"" + getPivots().size(Pivot.ROW_AREA) + "\" width=\"" + getPivots().size(Pivot.ROW_AREA) * 100 + "\">&nbsp;</td>");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 594 */         tmpList.clear();
/* 595 */         this.tableHead.getListByLevel(i, tmpList);
/* 596 */         Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.COL_AREA, i);
/*     */ 
/* 598 */         DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 601 */         for (int j = 0; j < tmpList.size(); ++j) {
/* 602 */           CrossGridNode tmpNode = (CrossGridNode)tmpList.get(j);
/* 603 */           CrossGridNode parentNode = tmpNode.getParent();
/* 604 */           boolean parentIsSubTotal = false;
/* 605 */           if ((parentNode != null) && (parentNode.getDimValueIndex() == this.m_crossGrid.getDimOrMeasByIndex(parentNode.getDimIndex()).count()))
/*     */           {
/* 609 */             parentIsSubTotal = true;
/*     */           }
/*     */ 
/* 612 */           if (tmpPivot.IsSuppressRepeat == true)
/*     */           {
/* 617 */             writer.write("<td class='CrossGridColHead' align=center style='BORDER-RIGHT: #000000 1px solid; COLOR: #800000; BORDER-BOTTOM: #000000 1px solid;WHITE-SPACE: nowrap; POSITION: relative' colspan='" + tmpNode.getRange() + "' width='" + tmpNode.getRange() * 100 + "' collevel=\"" + i + "\">");
/*     */ 
/* 622 */             if (!parentIsSubTotal) {
/* 623 */               writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/*     */             }
/*     */             else
/*     */             {
/* 628 */               writer.write("&nbsp;");
/*     */             }
/*     */ 
/* 631 */             writer.write("</td>");
/*     */           } else {
/* 633 */             for (int k = 0; k < tmpNode.getRange(); ++k)
/*     */             {
/* 636 */               writer.write("<td class='CrossGridColHead' style='BORDER-RIGHT: #000000 1px solid; COLOR: #800000; BORDER-BOTTOM: #000000 1px solid;WHITE-SPACE: nowrap; POSITION: relative' collevel=\"" + i + "\">");
/*     */ 
/* 639 */               if (!parentIsSubTotal) {
/* 640 */                 writer.write(tmpDim.getDesc(tmpNode.getDimValueIndex()));
/*     */               }
/*     */               else
/*     */               {
/* 645 */                 writer.write("&nbsp;");
/*     */               }
/*     */ 
/* 648 */               writer.write("</td>");
/*     */             }
/*     */           }
/*     */         }
/* 652 */         writer.write("</tr>");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void toXlsTableHead() throws Exception
/*     */   {
/* 659 */     List tmpList = new ArrayList();
/* 660 */     HSSFCellStyle aCellStyle = this.workBook.createCellStyle();
/* 661 */     aCellStyle.setAlignment(2);
/* 662 */     aCellStyle.setVerticalAlignment(1);
/* 663 */     aCellStyle.setBorderBottom(1);
/* 664 */     aCellStyle.setBorderTop(1);
/* 665 */     aCellStyle.setBorderLeft(1);
/* 666 */     aCellStyle.setBorderRight(1);
/* 667 */     aCellStyle.setFillForegroundColor(24);
/* 668 */     aCellStyle.setFillPattern(1);
/*     */ 
/* 670 */     HSSFFont littleFont = this.workBook.createFont();
/*     */ 
/* 672 */     littleFont.setFontHeightInPoints(10);
/* 673 */     littleFont.setBoldweight(700);
/* 674 */     littleFont.setColor(8);
/* 675 */     aCellStyle.setFont(littleFont);
/*     */ 
/* 681 */     this.currentRow = -1;
/* 682 */     if (this.tableHeadCount == 0) {
/* 683 */       if (getPivots().size(Pivot.ROW_AREA) > 0) {
/* 684 */         this.currentRow = (short)(this.currentRow + 1);
/* 685 */         this.currentCol = 0;
/*     */ 
/* 689 */         for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j) {
/* 690 */           setValueByRowCol(this.currentRow, this.currentCol, this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName(), aCellStyle);
/*     */ 
/* 699 */           this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */ 
/* 708 */           this.currentCol = (short)(this.currentCol + 1);
/*     */         }
/* 710 */         if (this.measIndex >= 0) {
/* 711 */           setValueByRowCol(this.currentRow, this.currentCol, this.m_crossGrid.getMeas().getDesc(this.measIndex), aCellStyle);
/*     */ 
/* 714 */           this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */         }
/*     */         else
/*     */         {
/* 720 */           String strData = AppframeLocaleFactory.getResource("com.ai.appframe2.analyse.McGrid.data");
/* 721 */           setValueByRowCol(this.currentRow, this.currentCol, strData, aCellStyle);
/*     */ 
/* 723 */           this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */         }
/*     */ 
/* 728 */         this.currentCol = (short)(this.currentCol + 1);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/* 733 */       for (int i = 0; i < this.tableHeadCount; ++i)
/*     */       {
/* 738 */         this.currentRow = (short)(this.currentRow + 1);
/* 739 */         this.currentCol = 0;
/* 740 */         if (getPivots().size(Pivot.ROW_AREA) > 0) {
/* 741 */           if (i == this.tableHeadCount - 1) {
/* 742 */             for (int j = 0; j < getPivots().size(Pivot.ROW_AREA); ++j) {
/* 743 */               setValueByRowCol(this.currentRow, this.currentCol, this.m_crossGrid.getDimOrMeasByIndex(((Pivot)getPivots().pivots[Pivot.ROW_AREA].get(j)).dimIndex).getName(), aCellStyle);
/*     */ 
/* 753 */               this.sheet.setColumnWidth(this.currentCol, htmlSizeToXlsSize(100));
/*     */ 
/* 762 */               this.currentCol = (short)(this.currentCol + 1);
/*     */             }
/*     */           }
/*     */           else {
/* 766 */             int mStartRow = this.currentRow;
/* 767 */             int mEndRow = this.currentRow;
/* 768 */             short mStartCol = this.currentCol;
/* 769 */             short mEndCol = this.currentCol;
/* 770 */             short aColSpan = (short)getPivots().size(Pivot.ROW_AREA);
/*     */ 
/* 772 */             if (aColSpan > 1) {
/* 773 */               mEndCol = (short)(mStartCol + aColSpan - 1);
/* 774 */               Region aMergedRegion = new Region(mStartRow, mStartCol, mEndRow, mEndCol);
/*     */ 
/* 776 */               this.sheet.addMergedRegion(aMergedRegion);
/* 777 */               this.sheet.setColumnWidth(this.currentCol, (short)(100 * aColSpan));
/*     */             }
/*     */ 
/* 781 */             for (short k = this.currentCol; k < this.currentCol + aColSpan; k = (short)(k + 1)) {
/* 782 */               setValueByRowCol(this.currentRow, k, "", aCellStyle);
/*     */             }
/*     */ 
/* 790 */             this.currentCol = (short)(this.currentCol + aColSpan);
/*     */           }
/*     */         }
/*     */ 
/* 794 */         tmpList.clear();
/* 795 */         this.tableHead.getListByLevel(i, tmpList);
/* 796 */         Pivot tmpPivot = this.m_pivots.getPivot(this.m_crossGrid, Pivot.COL_AREA, i);
/*     */ 
/* 798 */         DimensionOrMeas tmpDim = this.m_crossGrid.getDimOrMeasByIndex(tmpPivot.dimIndex);
/*     */ 
/* 801 */         for (int j = 0; j < tmpList.size(); ++j) {
/* 802 */           CrossGridNode tmpNode = (CrossGridNode)tmpList.get(j);
/* 803 */           CrossGridNode parentNode = tmpNode.getParent();
/* 804 */           boolean parentIsSubTotal = false;
/* 805 */           if ((parentNode != null) && (parentNode.getDimValueIndex() == this.m_crossGrid.getDimOrMeasByIndex(parentNode.getDimIndex()).count()))
/*     */           {
/* 809 */             parentIsSubTotal = true;
/*     */           }
/*     */ 
/* 812 */           if (tmpPivot.IsSuppressRepeat == true)
/*     */           {
/* 814 */             int mStartRow = this.currentRow;
/* 815 */             int mEndRow = this.currentRow;
/* 816 */             short mStartCol = this.currentCol;
/* 817 */             short mEndCol = this.currentCol;
/* 818 */             short aColSpan = (short)tmpNode.getRange();
/* 819 */             if (aColSpan > 1) {
/* 820 */               mEndCol = (short)(mStartCol + aColSpan - 1);
/* 821 */               Region aMergedRegion = new Region(mStartRow, mStartCol, mEndRow, mEndCol);
/*     */ 
/* 823 */               this.sheet.addMergedRegion(aMergedRegion);
/* 824 */               this.sheet.setColumnWidth(this.currentCol, (short)(100 * aColSpan));
/*     */             }
/*     */ 
/* 828 */             for (short k = this.currentCol; k < this.currentCol + aColSpan; k = (short)(k + 1)) {
/* 829 */               setValueByRowCol(this.currentRow, k, "", aCellStyle);
/*     */             }
/*     */ 
/* 836 */             if (!parentIsSubTotal) {
/* 837 */               setValueByRowCol(this.currentRow, this.currentCol, tmpDim.getDesc(tmpNode.getDimValueIndex()), aCellStyle);
/*     */             }
/*     */             else
/*     */             {
/* 842 */               setValueByRowCol(this.currentRow, this.currentCol, "", aCellStyle);
/*     */             }
/*     */ 
/* 846 */             this.currentCol = (short)(this.currentCol + aColSpan);
/*     */           } else {
/* 848 */             for (int k = 0; k < tmpNode.getRange(); ++k)
/*     */             {
/* 850 */               if (!parentIsSubTotal) {
/* 851 */                 setValueByRowCol(this.currentRow, this.currentCol, tmpDim.getDesc(tmpNode.getDimValueIndex()), aCellStyle);
/*     */ 
/* 855 */                 this.sheet.setColumnWidth(this.currentCol, 100);
/*     */               }
/*     */               else {
/* 858 */                 setValueByRowCol(this.currentRow, this.currentCol, "", aCellStyle);
/*     */               }
/*     */ 
/* 863 */               this.currentCol = (short)(this.currentCol + 1);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public void toHtmlGrid(Writer writer, String id)
/*     */     throws Exception
/*     */   {
/* 884 */     writer.write("<table id=\"crosshead\" style='DISPLAY: inline; BORDER-COLLAPSE: collapse' cellSpacing=0 cellPadding=2 width='100%' border=0 onclick=\"CrossGrid_GridData_OnClick('" + id + "')\">");
/*     */ 
/* 893 */     toHtmlTableHead(writer);
/*     */ 
/* 897 */     toHtmlRowHead(writer, this.rowHead, 0, this.tableHeadCount, false, "");
/*     */ 
/* 899 */     writer.write("</table>\n");
/*     */   }
/*     */ 
/*     */   public void toExcel(OutputStream aOutputStream, String id)
/*     */     throws Exception
/*     */   {
/* 914 */     this.workBook = new HSSFWorkbook();
/*     */ 
/* 916 */     this.sheet = this.workBook.createSheet("sheet1");
/*     */ 
/* 918 */     this.currentRow = 0;
/*     */ 
/* 920 */     this.currentCol = 0;
/*     */ 
/* 936 */     toXlsTableHead();
/*     */ 
/* 940 */     toXlsRowHead(this.rowHead, 0, this.tableHeadCount, false, "");
/*     */ 
/* 948 */     this.workBook.write(aOutputStream);
/*     */   }
/*     */ 
/*     */   public void setValueByRowCol(short aRow, short aCol, String aValue, HSSFCellStyle aStyle)
/*     */     throws Exception
/*     */   {
/* 955 */     HSSFRow row = this.sheet.getRow(aRow);
/* 956 */     if (row == null) {
/* 957 */       row = this.sheet.createRow(aRow);
/*     */     }
/* 959 */     HSSFCell cell = row.getCell(aCol);
/* 960 */     if (cell == null) {
/* 961 */       cell = row.createCell(aCol);
/*     */     }
/* 963 */     cell.setEncoding(1);
/* 964 */     cell.setCellValue(aValue);
/* 965 */     cell.setCellStyle(aStyle);
/*     */   }
/*     */ 
/*     */   public short htmlSizeToXlsSize(short htmlSize) {
/* 969 */     return (short)(htmlSize * 40);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.McGrid
 * JD-Core Version:    0.5.4
 */