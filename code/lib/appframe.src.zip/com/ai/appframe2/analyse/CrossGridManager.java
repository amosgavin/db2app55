package com.ai.appframe2.analyse;

import java.io.OutputStream;
import java.io.Writer;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

public abstract interface CrossGridManager
{
  public abstract McGridInterface getInstance(long paramLong, PivotList paramPivotList, boolean paramBoolean, String paramString)
    throws Exception;

  public abstract McGridInterface getNewCrossGridInstance(HttpServletRequest paramHttpServletRequest, String paramString1, String paramString2, PivotList paramPivotList, boolean paramBoolean, String paramString3)
    throws Exception;

  public abstract void toHtmlSelectArea(Writer paramWriter, McGridInterface paramMcGridInterface)
    throws Exception;

  public abstract void toHtmlGrid(Writer paramWriter, String paramString, McGridInterface paramMcGridInterface)
    throws Exception;

  public abstract void toExcel(OutputStream paramOutputStream, String paramString1, long paramLong, String paramString2, String paramString3, boolean paramBoolean, String paramString4)
    throws Exception;

  public abstract String getPovitsConfigStr(McGridInterface paramMcGridInterface)
    throws Exception;

  public abstract void refresh(Writer paramWriter, String paramString1, long paramLong, String paramString2, String paramString3, boolean paramBoolean, String paramString4)
    throws Exception;

  public abstract void refreshConfig(Writer paramWriter, String paramString1, long paramLong, String paramString2, boolean paramBoolean, String paramString3)
    throws Exception;

  public abstract void reloadCrossGridImpl(Writer paramWriter, String paramString1, long paramLong, String paramString2, String paramString3, boolean paramBoolean, String paramString4, ServletRequest paramServletRequest)
    throws Exception;

  public abstract String getContextPath();

  public abstract void setContextPath(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.analyse.CrossGridManager
 * JD-Core Version:    0.5.4
 */