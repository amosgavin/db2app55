/*    */ package com.ai.appframe2.event;
/*    */ 
/*    */ import com.ai.appframe2.common.AIRootConfig;
/*    */ import com.ai.appframe2.common.Util;
/*    */ import com.ai.appframe2.util.XmlUtil;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.InputStream;
/*    */ import java.io.StringWriter;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class EventConfigRuntime extends EventConfigDefine
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(EventConfigRuntime.class);
/*    */ 
/* 24 */   Map m_runtime_events = new TreeMap();
/*    */ 
/* 26 */   public static void main(String[] args) throws Exception { InputStream in = AIRootConfig.getConfigInfo("event-config.xml");
/* 27 */     EventConfigRuntime define = new EventConfigRuntime(in);
/* 28 */     StringWriter writer = new StringWriter();
/* 29 */     XmlUtil.writerXml(writer, define.createElement());
/* 30 */     log.info(writer.toString());
/* 31 */     String[] keys = (String[])(String[])define.m_runtime_events.keySet().toArray(new String[0]);
/* 32 */     for (int i = 0; i < keys.length; ++i)
/* 33 */       log.debug(keys[i] + "=" + define.m_runtime_events.get(keys[i])); }
/*    */ 
/*    */   public static EventConfigRuntime createInstance(String configFileName)
/*    */     throws Exception
/*    */   {
/* 38 */     InputStream in = AIRootConfig.getConfigInfo(configFileName);
/* 39 */     EventConfigRuntime result = new EventConfigRuntime(in);
/* 40 */     in.close();
/* 41 */     return result;
/*    */   }
/*    */ 
/*    */   public EventConfigRuntime(InputStream in) throws Exception {
/* 45 */     super(in);
/* 46 */     for (int i = 0; i < this.modules.size(); ++i)
/* 47 */       initialModule((EventConfigDefine.Module)this.modules.get(i));
/*    */   }
/*    */ 
/*    */   public void addModule(String fileName) throws Exception {
/* 51 */     EventConfigDefine.Module module = new EventConfigDefine.Module(this, fileName, true);
/* 52 */     this.modules.add(module);
/* 53 */     initialModule(module);
/*    */   }
/*    */ 
/*    */   protected void initialModule(EventConfigDefine.Module module) throws Exception {
/* 57 */     if (module.isUse == true) {
/* 58 */       InputStream in = Util.getResourceAsStream(EventConfigRuntime.class, module.file);
/*    */ 
/* 60 */       if (in == null)
/*    */       {
/* 62 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.not_load_file");
/* 63 */         throw new RuntimeException(msg + module.file);
/*    */       }
/*    */ 
/* 66 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.DAO_double_define", new String[] { module.file, Util.getResource(EventConfigRuntime.class, module.file).getPath() }));
/*    */ 
/* 68 */       EventModuleDefine define = new EventModuleDefine(in);
/* 69 */       List l = define.getEvents();
/* 70 */       for (int i = 0; i < l.size(); ++i) {
/* 71 */         EventModuleDefine.EventDefine item = (EventModuleDefine.EventDefine)l.get(i);
/* 72 */         if (this.m_runtime_events.containsKey(item.getEventId())) {
/* 73 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.DAO_double_define", new String[] { item.getEventId(), module.file }));
/*    */         }
/*    */ 
/* 77 */         this.m_runtime_events.put(item.getEventId(), item);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public EventModuleDefine.EventDefine getEvent(String id) {
/* 82 */     return (EventModuleDefine.EventDefine)this.m_runtime_events.get(id);
/*    */   }
/*    */ 
/*    */   public String[] getEvents(String likeId) {
/* 86 */     List result = new ArrayList();
/* 87 */     String eventId = "";
/* 88 */     Iterator it = this.m_runtime_events.keySet().iterator();
/* 89 */     while (it.hasNext()) {
/* 90 */       eventId = (String)it.next();
/* 91 */       if (eventId.indexOf(likeId) >= 0);
/* 92 */       result.add(eventId);
/*    */     }
/*    */ 
/* 95 */     return (String[])(String[])result.toArray(new String[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.event.EventConfigRuntime
 * JD-Core Version:    0.5.4
 */