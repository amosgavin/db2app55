/*     */ package com.ai.appframe2.event;
/*     */ 
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.module.ModuleFactory;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class EventFactory
/*     */ {
/*  14 */   private static transient Log log = LogFactory.getLog(EventFactory.class);
/*     */ 
/*  16 */   private static String m_configName = "event-config.xml";
/*     */   static EventConfigRuntime m_config;
/*     */ 
/*     */   public static void reload()
/*     */     throws Exception
/*     */   {
/*  30 */     m_config = EventConfigRuntime.createInstance(m_configName);
/*     */   }
/*     */   public static synchronized void addModule(String fileName) {
/*     */     try {
/*  34 */       m_config.addModule(fileName);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  38 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.load_service_m_error", new String[] { fileName });
/*  39 */       throw new RuntimeException(msg + e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String[] getEvents(String likeId) {
/*  44 */     return m_config.getEvents(likeId);
/*     */   }
/*     */ 
/*     */   public static void triggerEventNoWait(String eventId, Object eventObject)
/*     */     throws Exception
/*     */   {
/*  50 */     EventModuleDefine.EventDefine eventDefine = m_config.getEvent(eventId);
/*  51 */     EventFireThread thread = new EventFireThread(eventDefine, eventObject);
/*  52 */     thread.start();
/*     */   }
/*     */ 
/*     */   private static void triggerEventNoWait(EventModuleDefine.EventDefine event, Object eventObject) throws Exception
/*     */   {
/*  57 */     EventFireThread thread = new EventFireThread(event, eventObject);
/*  58 */     thread.start();
/*     */   }
/*     */ 
/*     */   public static void triggerEvent(String eventId, Object eventObject) throws Exception
/*     */   {
/*  63 */     EventModuleDefine.EventDefine eventDefine = m_config.getEvent(eventId);
/*  64 */     if ((eventDefine.getTriggerType() != null) && (eventDefine.getTriggerType().equalsIgnoreCase(EventConfigDefine.TRIGGER_TYPE_ASYN)))
/*     */     {
/*  66 */       triggerEventNoWait(eventDefine, eventObject);
/*     */     }
/*  68 */     else triggerEvent(eventDefine, eventObject); 
/*     */   }
/*     */ 
/*     */   protected static void triggerEvent(EventModuleDefine.EventDefine eventDefine, Object eventObject)
/*     */     throws Exception
/*     */   {
/*  73 */     EventModuleDefine.ListenerDefine[] listener = (EventModuleDefine.ListenerDefine[])(EventModuleDefine.ListenerDefine[])eventDefine.listeners.toArray(new EventModuleDefine.ListenerDefine[0]);
/*     */ 
/*  76 */     for (int i = 0; i < listener.length; ++i) {
/*  77 */       Object obj = null;
/*  78 */       String action = listener[i].getAction();
/*  79 */       if (EventModuleDefine.LISTENER_TYPE_SERVICE.equalsIgnoreCase(listener[i].getType()) == true)
/*     */       {
/*  81 */         obj = ServiceFactory.getService(listener[i].getId());
/*     */       }
/*     */       else {
/*  84 */         obj = Class.forName(listener[i].getId()).newInstance();
/*     */       }
/*  86 */       Class parameterClass = Object.class;
/*  87 */       if (eventObject != null) {
/*  88 */         parameterClass = eventObject.getClass();
/*     */       }
/*  90 */       Method m = DataType.findMethod(obj.getClass(), action, new Class[] { parameterClass }, true, false);
/*  91 */       if (m == null) {
/*  92 */         parameterClass = DataType.getSimpleClass(parameterClass);
/*  93 */         m = DataType.findMethod(obj.getClass(), action, new Class[] { parameterClass }, true, false);
/*     */       }
/*  95 */       if (m == null) {
/*  96 */         if (eventObject != null)
/*     */         {
/*  98 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.no_method");
/*  99 */           throw new RuntimeException(msg + obj.getClass().getName() + "." + action + "(" + eventObject.getClass().getName() + ")");
/*     */         }
/*     */ 
/* 105 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.no_method");
/* 106 */         throw new RuntimeException(msg + obj.getClass().getName() + "." + action + "(java.lang.Object)");
/*     */       }
/*     */ 
/* 110 */       m.invoke(obj, new Object[] { eventObject });
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  21 */       m_config = EventConfigRuntime.createInstance(m_configName);
/*  22 */       ModuleFactory.initail();
/*     */     }
/*     */     catch (Exception e) {
/*  25 */       log.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class EventFireThread extends Thread
/*     */   {
/*     */     private EventModuleDefine.EventDefine event;
/*     */     private Object eventObject;
/*     */ 
/*     */     public EventFireThread(EventModuleDefine.EventDefine event, Object eventObject)
/*     */     {
/* 121 */       this.event = event;
/* 122 */       this.eventObject = eventObject;
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 127 */         EventFactory.triggerEvent(this.event, this.eventObject);
/*     */       }
/*     */       catch (Exception e) {
/* 130 */         EventFactory.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.event.EventFactory.asynchronous_trigger_error", new String[] { this.event.getId() }), e);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.event.EventFactory
 * JD-Core Version:    0.5.4
 */