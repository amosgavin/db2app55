/*    */ package com.ai.appframe2.event;
/*    */ 
/*    */ import com.ai.appframe2.common.AIRootConfig;
/*    */ import com.ai.appframe2.util.XmlUtil;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.io.StringWriter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.dom4j.Element;
/*    */ 
/*    */ public class EventConfigDefine
/*    */ {
/* 14 */   public static String TRIGGER_TYPE_SYN = "SYN";
/* 15 */   public static String TRIGGER_TYPE_ASYN = "ASYN";
/*    */ 
/* 26 */   protected List modules = new ArrayList();
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 17 */     InputStream in = AIRootConfig.getConfigInfo("event-config.xml");
/* 18 */     EventConfigDefine define = new EventConfigDefine(in);
/* 19 */     StringWriter writer = new StringWriter();
/* 20 */     XmlUtil.writerXml(writer, define.createElement());
/* 21 */     System.out.println(writer.toString());
/*    */   }
/*    */ 
/*    */   public EventConfigDefine()
/*    */   {
/*    */   }
/*    */ 
/*    */   public EventConfigDefine(InputStream in)
/*    */     throws Exception
/*    */   {
/* 32 */     Element root = XmlUtil.parseXml(in);
/* 33 */     List l = root.elements("module");
/* 34 */     for (int i = 0; i < l.size(); ++i)
/* 35 */       this.modules.add(new Module((Element)l.get(i)));
/*    */   }
/*    */ 
/*    */   public Element createElement() {
/* 39 */     Element e = XmlUtil.createElement("events", "");
/*    */ 
/* 41 */     for (int i = 0; i < this.modules.size(); ++i) {
/* 42 */       e.add(((Module)this.modules.get(i)).createElement());
/*    */     }
/* 44 */     return e;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 48 */     return XmlUtil.formatElement(createElement());
/*    */   }
/*    */   public List getModules() {
/* 51 */     return this.modules;
/*    */   }
/*    */   public void setModules(List modules) {
/* 54 */     this.modules = modules;
/*    */   }
/*    */   public class Module {
/*    */     public String file;
/*    */     public boolean isUse;
/*    */ 
/*    */     public Module(Element e) {
/* 61 */       this.file = e.attributeValue("file");
/* 62 */       String s = e.attributeValue("use");
/* 63 */       if ((s == null) || (s.trim().length() == 0))
/* 64 */         this.isUse = false;
/*    */       else
/* 66 */         this.isUse = Boolean.valueOf(s).booleanValue();
/*    */     }
/*    */ 
/*    */     public Module(String aFile, boolean aIsUse)
/*    */     {
/* 71 */       this.file = aFile;
/* 72 */       this.isUse = aIsUse;
/*    */     }
/*    */ 
/*    */     public Element createElement() {
/* 76 */       Element e = XmlUtil.createElement("module", "");
/* 77 */       e.addAttribute("file", this.file);
/* 78 */       e.addAttribute("use", Boolean.toString(this.isUse));
/* 79 */       return e;
/*    */     }
/*    */ 
/*    */     public String toString() {
/* 83 */       return XmlUtil.formatElement(createElement());
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.event.EventConfigDefine
 * JD-Core Version:    0.5.4
 */