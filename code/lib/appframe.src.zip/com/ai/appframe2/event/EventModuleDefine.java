/*     */ package com.ai.appframe2.event;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StringWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class EventModuleDefine
/*     */ {
/*  12 */   public static String LISTENER_TYPE_SERVICE = "service";
/*     */ 
/*  14 */   public static String LISTENER_TYPE_POJO = "pojo";
/*     */ 
/*  16 */   public static String ACTION_DEFAULT = "execute";
/*     */   String id;
/*     */   String name;
/*  22 */   List events = new ArrayList();
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/*  25 */     InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("so.event");
/*     */ 
/*  27 */     EventModuleDefine define = new EventModuleDefine(in);
/*  28 */     StringWriter writer = new StringWriter();
/*  29 */     XmlUtil.writerXml(writer, define.createElement());
/*  30 */     System.out.println(writer.toString());
/*     */   }
/*     */ 
/*     */   public EventModuleDefine(InputStream in) throws Exception {
/*  34 */     Element root = XmlUtil.parseXml(in);
/*  35 */     this.id = root.attributeValue("id");
/*  36 */     this.name = root.attributeValue("name");
/*  37 */     List l = root.elements("event");
/*  38 */     for (int i = 0; i < l.size(); ++i)
/*  39 */       this.events.add(new EventDefine(this, (Element)l.get(i)));
/*     */   }
/*     */ 
/*     */   public EventModuleDefine(String id, String name)
/*     */   {
/*  44 */     this.id = id;
/*  45 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public Element createElement() {
/*  49 */     Element e = XmlUtil.createElement("module", "");
/*  50 */     e.addAttribute("id", this.id);
/*  51 */     e.addAttribute("name", this.name);
/*  52 */     for (int i = 0; i < this.events.size(); ++i) {
/*  53 */       e.add(((EventDefine)this.events.get(i)).createElement());
/*     */     }
/*  55 */     return e;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  59 */     return XmlUtil.formatElement(createElement());
/*     */   }
/*     */ 
/*     */   public List getEvents() {
/*  63 */     return this.events;
/*     */   }
/*     */ 
/*     */   public void setEvents(List events) {
/*  67 */     this.events = events;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  71 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String id) {
/*  75 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  83 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public class ListenerDefine
/*     */   {
/*     */     protected String id;
/*     */     protected String name;
/*     */     protected String type;
/*     */     protected String action;
/*     */     protected String eventAction;
/*     */ 
/*     */     public ListenerDefine(Element e)
/*     */     {
/* 209 */       this.id = e.attributeValue("id");
/* 210 */       this.name = e.attributeValue("name");
/* 211 */       this.type = e.attributeValue("type");
/* 212 */       this.action = e.attributeValue("action");
/*     */     }
/*     */ 
/*     */     public ListenerDefine(String id, String name, String type, String action)
/*     */     {
/* 217 */       this.id = id;
/* 218 */       this.name = name;
/* 219 */       this.type = type;
/* 220 */       this.action = action;
/*     */     }
/*     */ 
/*     */     public Element createElement() {
/* 224 */       Element e = XmlUtil.createElement("listener", "");
/* 225 */       e.addAttribute("id", this.id);
/* 226 */       e.addAttribute("name", this.name);
/* 227 */       e.addAttribute("type", this.type);
/* 228 */       e.addAttribute("action", this.action);
/* 229 */       return e;
/*     */     }
/*     */ 
/*     */     public void setType(String type) {
/* 233 */       this.type = type;
/*     */     }
/*     */ 
/*     */     public String getType() {
/* 237 */       return this.type;
/*     */     }
/*     */ 
/*     */     public String getId() {
/* 241 */       return this.id;
/*     */     }
/*     */ 
/*     */     public void setId(String id) {
/* 245 */       this.id = id;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 249 */       return this.name;
/*     */     }
/*     */ 
/*     */     public void setName(String name) {
/* 253 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String getEventAction() {
/* 257 */       if ((this.eventAction == null) || (this.eventAction.trim().length() == 0)) {
/* 258 */         this.eventAction = EventModuleDefine.ACTION_DEFAULT;
/*     */       }
/* 260 */       return this.eventAction;
/*     */     }
/*     */ 
/*     */     public String getAction() {
/* 264 */       return this.action;
/*     */     }
/*     */ 
/*     */     public void setAction(String action) {
/* 268 */       this.action = action;
/*     */     }
/*     */   }
/*     */ 
/*     */   public class EventDefine
/*     */   {
/*     */     String id;
/*     */     String name;
/*     */     String description;
/*     */     String triggerType;
/*  95 */     List listeners = new ArrayList();
/*     */     EventModuleDefine module;
/* 100 */     String eventId = null;
/*     */ 
/*     */     public EventDefine(EventModuleDefine aModule, Element e) {
/* 103 */       this.module = aModule;
/* 104 */       this.id = e.attributeValue("id");
/* 105 */       this.name = e.attributeValue("name");
/* 106 */       this.triggerType = e.attributeValue("triggertype");
/* 107 */       this.description = e.elementText("description");
/* 108 */       List l = e.elements("listener");
/* 109 */       for (int i = 0; i < l.size(); ++i)
/* 110 */         this.listeners.add(new EventModuleDefine.ListenerDefine(EventModuleDefine.this, (Element)l.get(i)));
/*     */     }
/*     */ 
/*     */     public EventDefine(EventModuleDefine aModule)
/*     */     {
/* 115 */       this.module = aModule;
/*     */     }
/*     */ 
/*     */     public String getEventId() {
/* 119 */       if (this.eventId == null) {
/* 120 */         if ((this.module.getId() != null) && (this.module.getId().length() > 0))
/*     */         {
/* 122 */           this.eventId = (this.module.getId() + "." + this.id);
/*     */         }
/* 124 */         else this.eventId = this.id;
/*     */       }
/* 126 */       return this.eventId;
/*     */     }
/*     */ 
/*     */     public Element createElement()
/*     */     {
/* 131 */       Element e = XmlUtil.createElement("event", "");
/* 132 */       e.addAttribute("id", this.id);
/* 133 */       e.addAttribute("name", this.name);
/* 134 */       e.addAttribute("triggertype", this.triggerType);
/* 135 */       e.addElement("description").addCDATA(this.description);
/* 136 */       for (int i = 0; i < this.listeners.size(); ++i) {
/* 137 */         e.add(((EventModuleDefine.ListenerDefine)this.listeners.get(i)).createElement());
/*     */       }
/* 139 */       return e;
/*     */     }
/*     */ 
/*     */     public EventModuleDefine getModule() {
/* 143 */       return this.module;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 147 */       return XmlUtil.formatElement(createElement());
/*     */     }
/*     */ 
/*     */     public void setId(String id) {
/* 151 */       this.id = id;
/*     */     }
/*     */ 
/*     */     public String getId() {
/* 155 */       return this.id;
/*     */     }
/*     */ 
/*     */     public String getDescription() {
/* 159 */       return this.description;
/*     */     }
/*     */ 
/*     */     public void setDescription(String description) {
/* 163 */       this.description = description;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 167 */       return this.name;
/*     */     }
/*     */ 
/*     */     public void setName(String name) {
/* 171 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String getTriggerType() {
/* 175 */       return this.triggerType;
/*     */     }
/*     */ 
/*     */     public void setTriggerType(String triggerType) {
/* 179 */       this.triggerType = triggerType;
/*     */     }
/*     */ 
/*     */     public void setModule(EventModuleDefine module) {
/* 183 */       this.module = module;
/*     */     }
/*     */ 
/*     */     public List getListeners() {
/* 187 */       return this.listeners;
/*     */     }
/*     */ 
/*     */     public void setListeners(List listeners) {
/* 191 */       this.listeners = listeners;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.event.EventModuleDefine
 * JD-Core Version:    0.5.4
 */