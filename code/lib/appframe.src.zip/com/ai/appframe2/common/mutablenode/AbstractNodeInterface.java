package com.ai.appframe2.common.mutablenode;

import java.io.Serializable;

public abstract interface AbstractNodeInterface extends Serializable
{
  public abstract String getRemark();

  public abstract String getName();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.mutablenode.AbstractNodeInterface
 * JD-Core Version:    0.5.4
 */