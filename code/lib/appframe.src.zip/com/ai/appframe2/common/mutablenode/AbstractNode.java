/*     */ package com.ai.appframe2.common.mutablenode;
/*     */ 
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.io.Serializable;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.collections.comparators.ComparableComparator;
/*     */ 
/*     */ public class AbstractNode
/*     */   implements Serializable
/*     */ {
/*  16 */   private String name = null;
/*  17 */   private String remark = null;
/*  18 */   private TreeMap childSet = null;
/*  19 */   private Object nodeObject = null;
/*  20 */   private AbstractNode parentNode = null;
/*  21 */   private AbstractNode rootNode = null;
/*     */ 
/*     */   public AbstractNode(AbstractNode aSuper, AbstractNode aParent, String aName)
/*     */   {
/*  25 */     this.name = aName;
/*  26 */     this.parentNode = aParent;
/*  27 */     this.rootNode = aSuper;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  31 */     return this.name;
/*     */   }
/*     */   public void setName(String aName) {
/*  34 */     if (this.parentNode != null) {
/*  35 */       AbstractNode objTempNode = this.parentNode.getChild(this.name);
/*  36 */       if (objTempNode != null) {
/*  37 */         this.parentNode.removeChild(this.name);
/*  38 */         this.parentNode.addChild(aName, this);
/*     */       }
/*     */     }
/*  41 */     this.name = aName;
/*     */   }
/*     */   public void setRemark(String remark) {
/*  44 */     this.remark = remark;
/*     */   }
/*     */   public String getRemark() {
/*  47 */     return this.remark;
/*     */   }
/*     */   public TreeMap getChildSet() {
/*  50 */     return this.childSet;
/*     */   }
/*     */   public void setNodeObject(Object nodeObject) {
/*  53 */     this.nodeObject = nodeObject;
/*     */   }
/*     */   public Object getNodeObject() {
/*  56 */     return this.nodeObject;
/*     */   }
/*     */   public void addChild(String aKey, AbstractNode aNode) {
/*  59 */     if (this.childSet == null) {
/*  60 */       this.childSet = new TreeMap(ComparableComparator.getInstance());
/*     */     }
/*  62 */     this.childSet.put(aKey.trim().toUpperCase(), aNode);
/*     */   }
/*     */   public AbstractNode getChild(String aKey) {
/*  65 */     if (this.childSet != null) {
/*  66 */       return (AbstractNode)this.childSet.get(aKey.trim().toUpperCase());
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */   public AbstractNode removeChild(String aKey) {
/*  71 */     if (this.childSet != null) {
/*  72 */       return (AbstractNode)this.childSet.remove(aKey.trim().toUpperCase());
/*     */     }
/*     */ 
/*  75 */     return null;
/*     */   }
/*     */ 
/*     */   public void removeAllChild()
/*     */   {
/*  80 */     if (this.childSet != null) {
/*  81 */       this.childSet.clear();
/*     */     }
/*  83 */     this.childSet = null;
/*     */   }
/*     */ 
/*     */   public void toXML(Object obj)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void buildTree(XmlObject aNode)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setParentNode(AbstractNode parentNode)
/*     */   {
/*  96 */     this.parentNode = parentNode;
/*     */   }
/*     */   public AbstractNode getParentNode() {
/*  99 */     return this.parentNode;
/*     */   }
/*     */   public void setRootNode(AbstractNode aRootNode) {
/* 102 */     this.rootNode = aRootNode;
/*     */   }
/*     */   public AbstractNode getRootNode() {
/* 105 */     return this.rootNode;
/*     */   }
/*     */   public String toString() {
/* 108 */     return this.name;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.mutablenode.AbstractNode
 * JD-Core Version:    0.5.4
 */