package com.ai.appframe2.common;

import java.util.HashMap;

public abstract interface CorbaBoEngine
{
  public abstract DataContainerInterface[] getDcs(HashMap paramHashMap)
    throws Exception;

  public abstract void save(DataContainerInterface paramDataContainerInterface)
    throws Exception;

  public abstract void save(DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.CorbaBoEngine
 * JD-Core Version:    0.5.4
 */