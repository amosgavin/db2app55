package com.ai.appframe2.common;

import javax.servlet.ServletRequest;

public abstract interface DBGridDataModelInterface
{
  public abstract void init(ServletRequest paramServletRequest, DBGFInterface paramDBGFInterface)
    throws Exception;

  public abstract int count()
    throws Exception;

  public abstract Object getGridData(int paramInt1, int paramInt2)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBGridDataModelInterface
 * JD-Core Version:    0.5.4
 */