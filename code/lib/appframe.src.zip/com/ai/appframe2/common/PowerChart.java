/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.PrintWriter;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class PowerChart
/*    */ {
/*    */   public static void createChart(String contextPath, String swfTemplate, String data, int width, int height, String msg, HttpServletResponse response)
/*    */     throws Exception
/*    */   {
/* 19 */     if ((swfTemplate == null) || (swfTemplate.trim().equals(""))) {
/* 20 */       String error = AppframeLocaleFactory.getResource("com.ai.appframe2.common.PowerChart.template_null");
/* 21 */       throw new Exception("chart " + error);
/*    */     }
/* 23 */     if ((data == null) || (data.trim().equals(""))) {
/* 24 */       String error = AppframeLocaleFactory.getResource("com.ai.appframe2.common.PowerChart.data_null");
/* 25 */       throw new Exception(error);
/*    */     }
/* 27 */     if (width <= 0) {
/* 28 */       width = 600;
/*    */     }
/* 30 */     if (height <= 0) {
/* 31 */       height = 350;
/*    */     }
/* 33 */     data = data.replaceAll("\r", "");
/* 34 */     data = data.replaceAll("\n", "");
/* 35 */     data = data.replace('"', '\'');
/*    */ 
/* 37 */     StringBuilder sb = new StringBuilder();
/* 38 */     sb.append("<%@ page contentType=\"text/html; charset=GBK\" %>\n").append("<script language=\"JavaScript\" src=\"").append(contextPath).append("/chart/js/FusionCharts.js\"></script>\n").append("<html>\n<head><title>chart</title></head>\n").append("<body><div id=\"divChart\"></div>").append("<br>").append(msg).append("</body></html>\n").append("<script language=\"javascript\">\n").append("init();\n").append("function init(){\n").append("var chart = new FusionCharts(\"").append(contextPath).append(swfTemplate).append("\", \"ChartId\", \"" + width + "\", \"" + height + "\", \"0\", \"0\");\n").append("chart.setDataXML(\"").append(data).append("\");\n").append("chart.render(\"divChart\");\n").append("}\n").append("</script>");
/*    */ 
/* 55 */     response.setContentType("text/html; charset=GBK");
/* 56 */     response.getWriter().print(sb.toString());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.PowerChart
 * JD-Core Version:    0.5.4
 */