package com.ai.appframe2.common;

import java.io.Writer;
import javax.servlet.ServletRequest;

public abstract interface DBFormInterface extends DBGFInterface
{
  public static final String MO_DEAL_TYPE_NO_DISPLAY = "no";
  public static final String MO_DEAL_TYPE_HIDDEN = "hidden";
  public static final String MO_DEAL_TYPE_MASK = "mask";
  public static final String DEFAULT_DATAMODEL = "com.ai.appframe2.web.tag.DefaultDataModel";

  public abstract String getFormid();

  public abstract String getDatamodel();

  public abstract String getOnvalchange();

  public abstract String getOndblink();

  public abstract void refresh(Writer paramWriter, ServletRequest paramServletRequest)
    throws Exception;

  public abstract boolean isFormEditable();

  public abstract String getConditionname();

  public abstract String getOnfocusin();

  public abstract String getOnfocusout();

  public abstract String getOnkeypress();

  public abstract String getModealtype();

  public abstract String getMo();

  public abstract String getOperator();

  public abstract String getCacheid();

  public abstract String getOnkeydown();

  public abstract String getOnbeforepaste();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBFormInterface
 * JD-Core Version:    0.5.4
 */