/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import java.io.FileWriter;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class AIRootConfig
/*     */ {
/*  26 */   private static transient Log log = LogFactory.getLog(AIRootConfig.class);
/*     */   public static final String S_ROOT_CONFIG_FILE = "AIRootConfig.xml";
/*     */   public static final String S_FETCH_TYPE_LOCALFILE = "LOCALFILE";
/*     */   public static final String S_FETCH_TYPE_HTTP = "HTTP";
/*     */   public static final String S_FETCH_TYPE_RMI = "RMI";
/*     */   public static final String S_FETCH_TYPE_CLASSPATH = "CLASSPATH";
/*  32 */   private static AIRootConfig s_instance = null;
/*  33 */   private String uniqueServerId = null;
/*  34 */   private Map attrMap = new HashMap();
/*  35 */   private List attrList = new ArrayList();
/*     */ 
/*     */   private AIRootConfig() {
/*     */     try {
/*  39 */       InputStream in = Util.getResourceAsStream(AIRootConfig.class, "AIRootConfig.xml");
/*     */ 
/*  41 */       Element e = XmlUtil.parseXml(in);
/*  42 */       initial(e);
/*     */     }
/*     */     catch (Throwable ex) {
/*  45 */       log.error("ERROR:RootConfig-InitialError Initialization configuration file AIRootConfig.xml failed:", ex);
/*  46 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static AIRootConfig getInstance() {
/*  51 */     if (s_instance == null) {
/*  52 */       synchronized (AIRootConfig.class) {
/*  53 */         if (s_instance == null) {
/*  54 */           s_instance = new AIRootConfig();
/*     */         }
/*     */       }
/*     */     }
/*  58 */     return s_instance;
/*     */   }
/*     */ 
/*     */   public static InputStream getConfigInfo(String configInfoName) {
/*  62 */     return getInstance()._getConfigInfo(configInfoName);
/*     */   }
/*     */ 
/*     */   private InputStream _getConfigInfo(String configInfoName) {
/*  66 */     InputStream result = null;
/*  67 */     result = getConfigInfoClassPath(configInfoName);
/*  68 */     if (result == null) {
/*  69 */       throw new RuntimeException("ERROR:ConfigReader-NotFindConfigInfo : " + configInfoName);
/*     */     }
/*  71 */     return result;
/*     */   }
/*     */ 
/*     */   private InputStream getConfigInfoClassPath(String configInfoName) {
/*  75 */     URL configFileURL = Util.getResource(AIRootConfig.class, configInfoName);
/*  76 */     if (configFileURL == null)
/*     */     {
/*  78 */       return null;
/*     */     }
/*  80 */     InputStream in = Util.getResourceAsStream(AIRootConfig.class, configInfoName);
/*     */ 
/*  84 */     return in;
/*     */   }
/*     */ 
/*     */   public void initial(Element e) {
/*  88 */     List list = e.elements("item");
/*  89 */     for (int i = 0; i < list.size(); ++i) {
/*  90 */       ConfigItem item = new ConfigItem((Element)list.get(i));
/*  91 */       this.attrList.add(item);
/*  92 */       this.attrMap.put(item.name, item);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Element createElement() {
/*  96 */     Element e = XmlUtil.createElement("AIRootConfig", "");
/*  97 */     for (int i = 0; i < this.attrList.size(); ++i) {
/*  98 */       ConfigItem item = (ConfigItem)this.attrList.get(i);
/*  99 */       e.add(item.createElement());
/*     */     }
/* 101 */     return e;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 105 */     return XmlUtil.formatElement(createElement());
/*     */   }
/*     */ 
/* 109 */   public String save2ConfigFile() { URL configFileURL = null;
/*     */     String tmpFileName;
/*     */     try {
/* 111 */       configFileURL = Util.getResource(AIRootConfig.class, "AIRootConfig.xml");
/* 112 */       FileWriter writer = null;
/*     */       String tmpFileName;
/* 113 */       if (configFileURL == null) {
/* 114 */         writer = new FileWriter("AIRootConfig.xml");
/* 115 */         tmpFileName = "AIRootConfig.xml";
/*     */       } else {
/* 117 */         writer = new FileWriter(configFileURL.getFile());
/* 118 */         tmpFileName = configFileURL.getFile();
/*     */       }
/* 120 */       XmlUtil.writerXml(writer, createElement());
/* 121 */       writer.close();
/*     */     }
/*     */     catch (Exception ex) {
/* 124 */       log.error("Information persistent failure: " + configFileURL.getFile(), ex);
/* 125 */       return "Information persistent failure: " + configFileURL.getFile();
/*     */     }
/*     */ 
/* 128 */     String msg = "Information persistence to file: " + tmpFileName + " successfully";
/* 129 */     return msg; }
/*     */ 
/*     */   public String getConfigServerURL()
/*     */   {
/* 133 */     ConfigItem item = (ConfigItem)this.attrMap.get("ConfigServerURL");
/* 134 */     if (item == null) {
/* 135 */       return "";
/*     */     }
/* 137 */     return item.value;
/*     */   }
/*     */ 
/*     */   public String getApplicationOfConfig() {
/* 141 */     ConfigItem item = (ConfigItem)getInstance().attrMap.get("Application");
/* 142 */     if (item == null) {
/* 143 */       return "";
/*     */     }
/* 145 */     return item.value;
/*     */   }
/*     */ 
/*     */   public String getRegisterDataSource() {
/* 149 */     ConfigItem item = (ConfigItem)this.attrMap.get("RegisterDataSource");
/* 150 */     if (item == null) {
/* 151 */       return "";
/*     */     }
/* 153 */     return item.value;
/*     */   }
/*     */   public String getLocalJmxRmiURL() {
/* 156 */     String result = System.getProperty("appframe.LocalJmxRmiURL");
/* 157 */     if (result == null) {
/* 158 */       ConfigItem item = (ConfigItem)this.attrMap.get("LocalJmxRmiURL");
/* 159 */       if ((item == null) || (item.value == null) || (item.value.length() == 0)) {
/* 160 */         result = "0";
/*     */       }
/*     */       else {
/* 163 */         result = item.value;
/*     */       }
/*     */     }
/* 166 */     return result;
/*     */   }
/*     */   public int getLocalJmxHttpPort() {
/* 169 */     String result = System.getProperty("appframe.LocalJmxHttpPort");
/* 170 */     if (result == null) {
/* 171 */       ConfigItem item = (ConfigItem)this.attrMap.get("LocalJmxHttpPort");
/* 172 */       if ((item == null) || (item.value == null) || (item.value.length() == 0)) {
/* 173 */         result = "0";
/*     */       }
/*     */       else {
/* 176 */         result = item.value;
/*     */       }
/*     */     }
/* 179 */     return Integer.parseInt(result);
/*     */   }
/*     */ 
/*     */   public boolean isRegister() {
/* 183 */     ConfigItem item = (ConfigItem)this.attrMap.get("IsRegister");
/*     */ 
/* 185 */     return (item != null) && (item.value.equalsIgnoreCase("true") == true);
/*     */   }
/*     */ 
/*     */   public boolean isOpenJmx()
/*     */   {
/* 190 */     ConfigItem item = (ConfigItem)this.attrMap.get("IsOpenJmx");
/*     */ 
/* 192 */     return (item == null) || (item.value.equalsIgnoreCase("false") != true);
/*     */   }
/*     */ 
/*     */   public long getRegisterRate()
/*     */   {
/* 198 */     ConfigItem item = (ConfigItem)this.attrMap.get("RegisterRate");
/* 199 */     if (item == null) {
/* 200 */       return 0L;
/*     */     }
/* 202 */     return Long.parseLong(item.value);
/*     */   }
/*     */   public long getAppframeServerDeadInterval() {
/* 205 */     ConfigItem item = (ConfigItem)this.attrMap.get("AppframeServerDeadInterval");
/* 206 */     if (item == null) {
/* 207 */       return 0L;
/*     */     }
/* 209 */     return Long.parseLong(item.value);
/*     */   }
/*     */ 
/*     */   public String getFetchConfigType() {
/* 213 */     ConfigItem item = (ConfigItem)this.attrMap.get("FetchConfigType");
/* 214 */     if (item == null) {
/* 215 */       return "";
/*     */     }
/* 217 */     return item.value;
/*     */   }
/*     */   public String getJmxBeanName() {
/* 220 */     ConfigItem item = (ConfigItem)this.attrMap.get("JxmBeanName");
/* 221 */     if (item == null) {
/* 222 */       return "";
/*     */     }
/* 224 */     return item.value;
/*     */   }
/*     */ 
/*     */   public void setJmxBeanName(String beanName) {
/* 228 */     ConfigItem item = (ConfigItem)this.attrMap.get("JmxBeanName");
/* 229 */     if (item == null) {
/* 230 */       item = new ConfigItem("JmxBeanName");
/* 231 */       this.attrList.add(item);
/* 232 */       this.attrMap.put(item.name, item);
/*     */     }
/* 234 */     item.value = beanName;
/*     */   }
/*     */   public void setLocalDirector(String localDirector) {
/* 237 */     ConfigItem item = (ConfigItem)this.attrMap.get("LocalDirector");
/* 238 */     if (item == null) {
/* 239 */       item = new ConfigItem("LocalDirector");
/* 240 */       this.attrList.add(item);
/* 241 */       this.attrMap.put(item.name, item);
/*     */     }
/* 243 */     item.value = localDirector;
/*     */   }
/*     */ 
/*     */   public void setConfigServerURL(String configServerURL) {
/* 247 */     ConfigItem item = (ConfigItem)this.attrMap.get("ConfigServerURL");
/* 248 */     if (item == null) {
/* 249 */       item = new ConfigItem("ConfigServerURL");
/* 250 */       this.attrList.add(item);
/* 251 */       this.attrMap.put(item.name, item);
/*     */     }
/* 253 */     item.value = configServerURL;
/*     */   }
/*     */ 
/*     */   public void setFetchConfigType(String fetchConfigType) {
/* 257 */     ConfigItem item = (ConfigItem)this.attrMap.get("FetchConfigType");
/* 258 */     if (item == null) {
/* 259 */       item = new ConfigItem("FetchConfigType");
/* 260 */       this.attrList.add(item);
/* 261 */       this.attrMap.put(item.name, item);
/*     */     }
/* 263 */     item.value = fetchConfigType;
/*     */   }
/*     */ 
/*     */   public String getUniqueServerId() {
/* 267 */     if (this.uniqueServerId == null) {
/* 268 */       this.uniqueServerId = JVM.getUUID();
/*     */     }
/* 270 */     return this.uniqueServerId;
/*     */   }
/*     */ 
/*     */   public static InputStream getServerInfo() throws Exception
/*     */   {
/* 275 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIRootConfig
 * JD-Core Version:    0.5.4
 */