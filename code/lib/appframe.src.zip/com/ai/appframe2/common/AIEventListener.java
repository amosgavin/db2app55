package com.ai.appframe2.common;

import java.util.EventListener;

public abstract interface AIEventListener extends EventListener
{
  public abstract void execute(Object paramObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIEventListener
 * JD-Core Version:    0.5.4
 */