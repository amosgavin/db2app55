/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Inet4Address;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.URL;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Util
/*     */ {
/*  22 */   private static transient Log log = LogFactory.getLog(Util.class);
/*     */   public static final String DEFAULT_CHARSET = "GB2312";
/*     */   public static String localIP;
/*     */ 
/*     */   public static Log getLogger(Class logClass)
/*     */   {
/*  29 */     return LogFactory.getLog(logClass);
/*     */   }
/*     */ 
/*     */   public static Date getSysDate(String dataSourceName) throws Exception {
/*  33 */     return new Date(ServiceManager.getIdGenerator().getSysDate(dataSourceName).getTime());
/*     */   }
/*     */ 
/*     */   public static Date getSysDate() throws Exception {
/*  37 */     Connection conn = null;
/*  38 */     Date rq = null;
/*     */     try {
/*  40 */       conn = ServiceManager.getSession().getConnection();
/*  41 */       rq = new Date(DialectFactory.getDialect().getSysDate(conn));
/*     */     }
/*     */     finally {
/*  44 */       if (conn != null) {
/*  45 */         conn.close();
/*     */       }
/*     */     }
/*  48 */     return rq;
/*     */   }
/*     */   public static String getSysDateString() throws Exception {
/*  51 */     return DataType.transferToString(getSysDate(), "Date");
/*     */   }
/*     */   public static String getSysDateTimeString() throws Exception {
/*  54 */     return DataType.transferToString(getSysDate(), "DateTime");
/*     */   }
/*     */ 
/*     */   public static String unionWhereSql(String aCond1, String aCond2)
/*     */   {
/*  59 */     if ((aCond1 == null) || (aCond1.trim().length() == 0))
/*  60 */       return aCond2;
/*  61 */     if ((aCond2 == null) || (aCond2.trim().length() == 0)) {
/*  62 */       return aCond1;
/*     */     }
/*  64 */     String[] sqls = splitString(aCond1, "order by");
/*  65 */     String strAnd1 = sqls[0];
/*  66 */     String strOrderBy1 = sqls[1];
/*     */ 
/*  68 */     sqls = splitString(aCond2, "order by");
/*  69 */     String strAnd2 = sqls[0];
/*  70 */     String strOrderBy2 = sqls[1];
/*     */ 
/*  72 */     StringBuilder buffer = new StringBuilder();
/*  73 */     if ((strAnd1 != "") && (strAnd2 != "")) {
/*  74 */       buffer.append("(").append(strAnd1).append(") and (").append(strAnd2).append(")");
/*     */     }
/*  76 */     else if (strAnd1 != "")
/*  77 */       buffer.append(strAnd1);
/*  78 */     else if (strAnd2 != "") {
/*  79 */       buffer.append(strAnd2);
/*     */     }
/*  81 */     if ((strOrderBy1 != "") && (strOrderBy2 != "")) {
/*  82 */       buffer.append(" order by ").append(strOrderBy2).append(",").append(strOrderBy1);
/*     */     }
/*  84 */     else if (strOrderBy1 != "")
/*  85 */       buffer.append(" order by ").append(strOrderBy1);
/*  86 */     else if (strOrderBy2 != "")
/*  87 */       buffer.append(" order by ").append(strOrderBy2);
/*  88 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static String[] splitString(String s, String tag) {
/*  92 */     String[] result = new String[2];
/*  93 */     result[0] = "";
/*  94 */     result[1] = "";
/*  95 */     if ((s == null) || (tag == null))
/*  96 */       return result;
/*  97 */     s = s.trim();
/*  98 */     tag = tag.trim();
/*  99 */     int index = s.toLowerCase().indexOf(tag.toLowerCase());
/*     */ 
/* 101 */     if (index == -1) {
/* 102 */       result[0] = s;
/* 103 */     } else if (index != 0) {
/* 104 */       result[0] = s.substring(0, index);
/* 105 */       result[1] = s.substring(index + tag.length(), s.length());
/*     */     }
/*     */     else {
/* 108 */       result[1] = s.substring(tag.length(), s.length());
/* 109 */     }return result;
/*     */   }
/*     */ 
/*     */   public static String checkAndTransStr(String str)
/*     */   {
/* 119 */     if ((str == null) || (str.equals(""))) {
/* 120 */       return str;
/*     */     }
/* 122 */     if ((str.indexOf("&") < 0) && (str.indexOf(">") < 0) && (str.indexOf("<") < 0) && (str.indexOf("'") < 0) && (str.indexOf('"') < 0))
/*     */     {
/* 126 */       return str;
/*     */     }
/* 128 */     if (str.indexOf("&") >= 0) {
/* 129 */       str = StringUtils.replace(str, "&", "&amp;");
/*     */     }
/* 131 */     if (str.indexOf(">") >= 0) {
/* 132 */       str = StringUtils.replace(str, ">", "&gt;");
/*     */     }
/* 134 */     if (str.indexOf("<") >= 0) {
/* 135 */       str = StringUtils.replace(str, "<", "&lt;");
/*     */     }
/* 137 */     if (str.indexOf("\"") >= 0) {
/* 138 */       str = StringUtils.replace(str, "\"", "&quot;");
/*     */     }
/* 140 */     return str;
/*     */   }
/*     */ 
/*     */   public static String checkAndTransStrForHTML(String str)
/*     */   {
/* 145 */     if ((str == null) || (str.equals(""))) {
/* 146 */       return str;
/*     */     }
/* 148 */     if ((str.indexOf("&") < 0) && (str.indexOf(">") < 0) && (str.indexOf("<") < 0) && (str.indexOf("'") < 0) && (str.indexOf('"') < 0) && (str.indexOf(" ") < 0))
/*     */     {
/* 153 */       return str;
/*     */     }
/* 155 */     if (str.indexOf("&") >= 0) {
/* 156 */       str = StringUtils.replace(str, "&", "&amp;");
/*     */     }
/* 158 */     if (str.indexOf(">") >= 0) {
/* 159 */       str = StringUtils.replace(str, ">", "&gt;");
/*     */     }
/* 161 */     if (str.indexOf("<") >= 0) {
/* 162 */       str = StringUtils.replace(str, "<", "&lt;");
/*     */     }
/* 164 */     if (str.indexOf("\"") >= 0) {
/* 165 */       str = StringUtils.replace(str, "\"", "&quot;");
/*     */     }
/* 167 */     if (str.indexOf(" ") >= 0) {
/* 168 */       str = StringUtils.replace(str, " ", "&nbsp;");
/*     */     }
/*     */ 
/* 171 */     return str;
/*     */   }
/*     */ 
/*     */   public static String checkAndTransSqlStr(String str)
/*     */   {
/* 181 */     StringUtils.replace(str, "'", "''");
/* 182 */     return str;
/*     */   }
/*     */ 
/*     */   public static AIDataBase warpAIDataBase(Object obj) {
/* 186 */     if (obj instanceof AIDataBase) {
/* 187 */       return (AIDataBase)obj;
/*     */     }
/* 189 */     return new AIDataBaseImpl(obj);
/*     */   }
/*     */ 
/*     */   public static AIDataBase[] warpAIDataBase(Object[] objs) {
/* 193 */     if (objs == null)
/* 194 */       return null;
/* 195 */     if (objs instanceof AIDataBase[]) {
/* 196 */       return (AIDataBase[])(AIDataBase[])objs;
/*     */     }
/* 198 */     AIDataBaseImpl[] result = new AIDataBaseImpl[objs.length];
/* 199 */     for (int i = 0; i < objs.length; ++i) {
/* 200 */       result[i] = new AIDataBaseImpl(objs[i]);
/*     */     }
/* 202 */     return result;
/*     */   }
/*     */ 
/*     */   public static InputStream getResourceAsStream(Class aClass, String fileName) {
/* 206 */     InputStream result = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/* 207 */     if (result == null) {
/* 208 */       result = aClass.getClassLoader().getResourceAsStream(fileName);
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */   public static URL getResource(Class aClass, String fileName) {
/* 213 */     URL result = Thread.currentThread().getContextClassLoader().getResource(fileName);
/* 214 */     if (result == null) {
/* 215 */       result = aClass.getClassLoader().getResource(fileName);
/*     */     }
/* 217 */     return result;
/*     */   }
/*     */ 
/*     */   public static byte[] getResourceAsBytes(Class aClass, String fileName) throws Exception {
/* 221 */     InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/* 222 */     if (in == null) {
/* 223 */       in = aClass.getClassLoader().getResourceAsStream(fileName);
/*     */     }
/* 225 */     return getResourceAsBytes(in);
/*     */   }
/*     */ 
/*     */   public static byte[] getResourceAsBytes(InputStream in) throws Exception {
/* 229 */     if (in == null)
/* 230 */       return null;
/* 231 */     ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
/*     */     try
/*     */     {
/* 234 */       while ((ch = in.read()) != -1)
/*     */       {
/*     */         int ch;
/* 235 */         bytestream.write(ch);
/*     */       }
/* 237 */       byte[] imgdata = bytestream.toByteArray();
/* 238 */       byte[] arrayOfByte1 = imgdata;
/*     */ 
/* 241 */       return arrayOfByte1; } finally { bytestream.close(); }
/*     */ 
/*     */   }
/*     */ 
/*     */   public static String[] arrayIntersection(String[] a1, String[] a2)
/*     */   {
/* 251 */     if ((a1 == null) || (a2 == null))
/* 252 */       return new String[0];
/* 253 */     ArrayList list = new ArrayList();
/* 254 */     for (int i = 0; i < a1.length; ++i) {
/* 255 */       for (int j = 0; j < a2.length; ++j)
/* 256 */         if (a1[i].toUpperCase() == a2[j].toUpperCase())
/* 257 */           list.add(a1[i]);
/*     */     }
/* 259 */     return (String[])(String[])list.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public static String[] arrayUnion(String[] a1, String[] a2)
/*     */   {
/* 268 */     if ((a1 == null) && (a2 == null))
/* 269 */       return new String[0];
/* 270 */     if (a1 == null)
/* 271 */       return a2;
/* 272 */     if (a2 == null)
/* 273 */       return a1;
/* 274 */     ArrayList list = new ArrayList();
/* 275 */     for (int i = 0; i < a1.length; ++i) {
/* 276 */       list.add(a1[i]);
/*     */     }
/* 278 */     for (int i = 0; i < a2.length; ++i) {
/* 279 */       boolean isfind = false;
/* 280 */       for (int j = 0; j < a1.length; ++j)
/* 281 */         if (a2[i].equalsIgnoreCase(a1[j])) {
/* 282 */           isfind = true;
/* 283 */           break;
/*     */         }
/* 285 */       if (!isfind)
/* 286 */         list.add(a2[i]);
/*     */     }
/* 288 */     return (String[])(String[])list.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public static String getLocalIP() {
/* 292 */     if (localIP != null) {
/* 293 */       return localIP;
/*     */     }
/*     */     try
/*     */     {
/* 297 */       Enumeration allNetInterfaces = NetworkInterface.getNetworkInterfaces();
/* 298 */       InetAddress ip = null;
/* 299 */       while (allNetInterfaces.hasMoreElements()) {
/* 300 */         NetworkInterface netInterface = (NetworkInterface)allNetInterfaces.nextElement();
/*     */ 
/* 302 */         Enumeration addresses = netInterface.getInetAddresses();
/* 303 */         String ipPrefix = AIConfigManager.getConfigItem("HostIPPrefix");
/*     */         do { do { if (!addresses.hasMoreElements()) break label145;
/* 305 */             ip = (InetAddress)addresses.nextElement(); }
/* 306 */           while ((ip == null) || (!ip instanceof Inet4Address));
/* 307 */           log.info("LocalIP = " + ip.getHostAddress()); }
/* 308 */         while ((ipPrefix != null) && (ipPrefix.trim().length() != 0) && (!ip.getHostAddress().startsWith(ipPrefix)));
/*     */ 
/* 310 */         label145: localIP = ip.getHostAddress();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 318 */       log.error(e.getMessage(), e);
/*     */     }
/* 320 */     return localIP;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 327 */     System.out.println(new DataContainerInterface[100] instanceof AIDataBase[]);
/*     */   }
/*     */ 
/*     */   public static int getFreeSocketPort()
/*     */   {
/*     */     try
/*     */     {
/* 336 */       ServerSocket ss = new ServerSocket(0);
/* 337 */       int freePort = ss.getLocalPort();
/* 338 */       ss.close();
/* 339 */       return freePort;
/*     */     }
/*     */     catch (Exception ex) {
/* 342 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isValidUtf8(byte[] b, int aMaxCount) {
/* 347 */     int lLen = b.length; int lCharCount = 0;
/* 348 */     for (int i = 0; (i < lLen) && (lCharCount < aMaxCount); ++lCharCount) {
/* 349 */       byte lByte = b[(i++)];
/*     */ 
/* 351 */       if (lByte >= 0)
/*     */         continue;
/* 353 */       if ((lByte < -64) || (lByte > -3))
/* 354 */         return false;
/* 355 */       int lCount = (lByte > -32) ? 2 : (lByte > -16) ? 3 : (lByte > -8) ? 4 : (lByte > -4) ? 5 : 1;
/*     */ 
/* 357 */       if (i + lCount > lLen)
/* 358 */         return false;
/* 359 */       for (int j = 0; j < lCount; ++i) {
/* 360 */         if (b[i] >= -64)
/* 361 */           return false;
/* 359 */         ++j;
/*     */       }
/*     */     }
/*     */ 
/* 363 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Util
 * JD-Core Version:    0.5.4
 */