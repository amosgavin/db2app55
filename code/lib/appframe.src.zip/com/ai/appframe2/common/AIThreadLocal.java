/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class AIThreadLocal extends ThreadLocal
/*    */ {
/* 21 */   private static List threadLocalList = new ArrayList();
/* 22 */   private static ThreadLocal isClearMap = new ThreadLocal() {
/*    */     public Object initialValue() {
/* 24 */       return new HashMap();
/*    */     }
/* 22 */   };
/*    */ 
/*    */   public AIThreadLocal()
/*    */   {
/* 29 */     threadLocalList.add(this);
/*    */   }
/*    */   public void set(Object obj) {
/* 32 */     super.set(obj);
/* 33 */     ((Map)isClearMap.get()).remove(this);
/*    */   }
/*    */   public Object get() {
/* 36 */     Object result = super.get();
/* 37 */     if ((result == null) && (((Map)isClearMap.get()).containsKey(this))) {
/* 38 */       result = initialValue();
/* 39 */       set(result);
/*    */     }
/* 41 */     return result;
/*    */   }
/*    */ 
/*    */   public static void clearAll() {
/* 45 */     for (int i = 0; i < threadLocalList.size(); ++i) {
/* 46 */       ((ThreadLocal)threadLocalList.get(i)).set(null);
/* 47 */       ((Map)isClearMap.get()).put(threadLocalList.get(i), new Boolean(true));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIThreadLocal
 * JD-Core Version:    0.5.4
 */