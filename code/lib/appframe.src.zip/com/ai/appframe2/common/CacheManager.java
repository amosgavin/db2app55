package com.ai.appframe2.common;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public abstract interface CacheManager extends Serializable
{
  public abstract void put(String paramString, Object paramObject1, Object paramObject2);

  public abstract Object get(String paramString, Object paramObject);

  public abstract Map getMap(String paramString);

  public abstract void remove(String paramString, Object paramObject);

  public abstract void remove(String paramString);

  public abstract boolean containsKey(String paramString, Object paramObject);

  public abstract String[] getTypes();

  public abstract Object[] getKeys(String paramString);

  public abstract List query(String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.CacheManager
 * JD-Core Version:    0.5.4
 */