package com.ai.appframe2.common;

import com.ai.appframe2.privilege.UserInfoInterface;
import java.rmi.RemoteException;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.Map;

public abstract interface RemoteDataStore
{
  public abstract void save(UserInfoInterface paramUserInfoInterface, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws RemoteException, Exception;

  public abstract int retrieveCount(ObjectType paramObjectType, String paramString, Map paramMap, String[] paramArrayOfString)
    throws RemoteException, Exception;

  public abstract DataContainerInterface[] retrieve(Class paramClass, ObjectType paramObjectType, String[] paramArrayOfString1, String paramString, Map paramMap, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws RemoteException, Exception;

  public abstract DataContainerInterface[] retrieve(String paramString, Map paramMap)
    throws RemoteException, Exception;

  public abstract int execute(String paramString, Map paramMap)
    throws RemoteException, Exception;

  public abstract long getNewId(String paramString)
    throws RemoteException, Exception;

  public abstract ResultSet retrieve(ObjectType paramObjectType, String[] paramArrayOfString1, String paramString, Map paramMap, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws RemoteException, Exception;

  public abstract void fillDataContainerFromBoClass(ResultSet paramResultSet, DataContainerInterface paramDataContainerInterface, Property[] paramArrayOfProperty, boolean paramBoolean)
    throws RemoteException, Exception;

  public abstract DataContainerInterface[] createDtaContainerFromResultSet(Class paramClass, ObjectType paramObjectType, ResultSet paramResultSet, String[] paramArrayOfString, boolean paramBoolean)
    throws RemoteException, Exception;

  public abstract Date getSysDate()
    throws RemoteException, Exception;

  public abstract void registerAppframeServerInfo(JVM paramJVM, Date paramDate)
    throws Exception;

  public abstract void removeAppframeServerRegisterInfo(String paramString)
    throws Exception;

  public abstract JVM[] getAppframeServerInfo()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.RemoteDataStore
 * JD-Core Version:    0.5.4
 */