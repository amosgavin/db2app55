package com.ai.appframe2.common;

public abstract interface DataSourceFactory extends DataSourceManager
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataSourceFactory
 * JD-Core Version:    0.5.4
 */