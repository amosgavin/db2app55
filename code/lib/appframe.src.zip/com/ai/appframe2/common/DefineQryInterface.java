package com.ai.appframe2.common;

public abstract interface DefineQryInterface
{
  public static final char ORDER_SEPARATOR = '^';

  public abstract long getFuncId();

  public abstract long getQueryId();

  public abstract long getStaffId();

  public abstract String getQryName();

  public abstract String getSetName();

  public abstract String getOrderFlds();

  public abstract String getDisplayFlds();

  public abstract String getWhereSql();

  public abstract boolean isDefaultQry();

  public abstract boolean isSysQry();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DefineQryInterface
 * JD-Core Version:    0.5.4
 */