package com.ai.appframe2.common;

import javax.servlet.ServletRequest;

public abstract interface DBFormDataModelInterface
{
  public abstract void init(ServletRequest paramServletRequest, DBGFInterface paramDBGFInterface)
    throws Exception;

  public abstract Object getFormData()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBFormDataModelInterface
 * JD-Core Version:    0.5.4
 */