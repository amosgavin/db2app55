/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ class PrivateKey
/*     */ {
/*     */   private long key;
/*     */ 
/*     */   PrivateKey()
/*     */   {
/* 158 */     this.key = 0L;
/*     */   }
/* 160 */   public synchronized Long getNewKey() { this.key += 1L;
/* 161 */     return new Long(System.currentTimeMillis() + this.key); }
/*     */ 
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.PrivateKey
 * JD-Core Version:    0.5.4
 */