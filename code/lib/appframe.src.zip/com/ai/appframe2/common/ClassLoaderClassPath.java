/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.net.URL;
/*    */ import javassist.ClassPath;
/*    */ 
/*    */ class ClassLoaderClassPath
/*    */   implements ClassPath
/*    */ {
/*    */   private ClassLoader thisClassLoader;
/*    */ 
/*    */   public ClassLoaderClassPath(ClassLoader loader)
/*    */   {
/* 21 */     this.thisClassLoader = loader;
/*    */   }
/*    */   public InputStream openClassfile(String classname) {
/* 24 */     String jarname = classname.replace('.', '/') + ".class";
/* 25 */     return this.thisClassLoader.getResourceAsStream(jarname);
/*    */   }
/*    */   public URL find(String classname) {
/* 28 */     String jarname = classname.replace('.', '/') + ".class";
/* 29 */     return this.thisClassLoader.getResource(jarname);
/*    */   }
/*    */   public void close() {
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return "ClassLoader:" + this.thisClassLoader.getClass().getName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ClassLoaderClassPath
 * JD-Core Version:    0.5.4
 */