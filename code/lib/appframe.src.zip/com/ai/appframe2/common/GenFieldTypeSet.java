package com.ai.appframe2.common;

import com.ai.appframe2.util.AIExcelWriter;
import java.io.OutputStream;
import java.io.Writer;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.List;

public abstract interface GenFieldTypeSet
{
  public abstract void getDefineString(Writer paramWriter, String[] paramArrayOfString, boolean paramBoolean)
    throws Exception;

  public abstract void getHeaderString(Writer paramWriter)
    throws Exception;

  public abstract HashMap getHeaderString(Writer paramWriter, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetAsHTMLTableStr(Writer paramWriter, String[] paramArrayOfString1, HashMap paramHashMap, AIDataBase[] paramArrayOfAIDataBase, String[] paramArrayOfString2)
    throws Exception;

  public abstract void getFieldTypeSetString(Writer paramWriter, String[] paramArrayOfString, boolean paramBoolean)
    throws Exception;

  public abstract void getRowSetString(Writer paramWriter, AIDataBase[] paramArrayOfAIDataBase, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetString(Writer paramWriter, AIDataBase paramAIDataBase, String[] paramArrayOfString)
    throws Exception;

  public abstract void setCustomListSource(String paramString1, AIDataBase[] paramArrayOfAIDataBase, String paramString2, String paramString3);

  public abstract void setCustomListSource(String paramString, HashMap paramHashMap);

  public abstract void setCustomListSource(String paramString1, String paramString2);

  public abstract void clearCustomListSource();

  public abstract void getRowSetAsHTMLTableStr(Writer paramWriter, DBGridInterface paramDBGridInterface, AIDataBase[] paramArrayOfAIDataBase, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetAsHTMLTableStr(Writer paramWriter, DBGridInterface paramDBGridInterface, ResultSet paramResultSet, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetAsHTMLTableStr(Writer paramWriter, DBGridInterface paramDBGridInterface, AIResult paramAIResult, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetAsExcel(OutputStream paramOutputStream, DBGridInterface paramDBGridInterface, AIResult paramAIResult, String[] paramArrayOfString, HashMap paramHashMap, List paramList)
    throws Exception;

  public abstract void getRowSetAsExcelByVM(Writer paramWriter, DBGridInterface paramDBGridInterface, AIResult paramAIResult, String[] paramArrayOfString, HashMap paramHashMap, List paramList, boolean paramBoolean)
    throws Exception;

  public abstract void getRowSetAsTXT(Writer paramWriter, DBGridInterface paramDBGridInterface, AIResult paramAIResult, String[] paramArrayOfString, HashMap paramHashMap, List paramList, boolean paramBoolean)
    throws Exception;

  public abstract void getRowSetAsExcelBinary(AIExcelWriter paramAIExcelWriter, DBGridInterface paramDBGridInterface, AIResult paramAIResult, String[] paramArrayOfString, HashMap paramHashMap, List paramList)
    throws Exception;

  public abstract List getShowCols(DBGridInterface paramDBGridInterface, String[] paramArrayOfString)
    throws Exception;

  public abstract void toString(Writer paramWriter, AIDataBase[] paramArrayOfAIDataBase, String[] paramArrayOfString)
    throws Exception;

  public abstract void toString(Writer paramWriter, AIDataBase paramAIDataBase, String[] paramArrayOfString)
    throws Exception;

  public abstract void toString(Writer paramWriter, ResultSet paramResultSet, String[] paramArrayOfString)
    throws Exception;

  public abstract void toString(Writer paramWriter, String paramString, HashMap paramHashMap, String[] paramArrayOfString, int paramInt1, int paramInt2, boolean paramBoolean)
    throws Exception;

  public abstract void getRowSetString(Writer paramWriter, ResultSet paramResultSet, String[] paramArrayOfString)
    throws Exception;

  public abstract void getRowSetString(Writer paramWriter, String paramString, HashMap paramHashMap, String[] paramArrayOfString, int paramInt1, int paramInt2, boolean paramBoolean)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.GenFieldTypeSet
 * JD-Core Version:    0.5.4
 */