package com.ai.appframe2.common;

public abstract interface ListDataSourceInterface
{
  public abstract boolean IsStatic();

  public abstract String getOptListText(String paramString);

  public abstract String getValueAttr();

  public abstract int getTextAttrLength();

  public abstract String getTextAttr(int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ListDataSourceInterface
 * JD-Core Version:    0.5.4
 */