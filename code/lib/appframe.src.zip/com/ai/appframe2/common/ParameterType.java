package com.ai.appframe2.common;

public abstract interface ParameterType
{
  public abstract String getName();

  public abstract String getJavaDataType();

  public abstract String getType();

  public abstract String getValue();

  public abstract String getRemark();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ParameterType
 * JD-Core Version:    0.5.4
 */