package com.ai.appframe2.common;

public abstract interface ManagerObjectType
{
  public abstract String getName();

  public abstract String getFullName();

  public abstract String[] getPropertyNames();

  public abstract Property getProperty(String paramString);

  public abstract String[] getManagerOperatorNames();

  public abstract String getManagerOperatorTitle(String paramString);

  public abstract boolean isQueryOperator(String paramString)
    throws AIException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ManagerObjectType
 * JD-Core Version:    0.5.4
 */