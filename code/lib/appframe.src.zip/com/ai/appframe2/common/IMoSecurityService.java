package com.ai.appframe2.common;

import com.ai.appframe2.privilege.QueryCondition;
import com.ai.appframe2.privilege.UserInfoInterface;
import java.rmi.RemoteException;

public abstract interface IMoSecurityService
{
  public abstract QueryCondition getQueryCondition(String paramString1, UserInfoInterface paramUserInfoInterface, String paramString2)
    throws RemoteException, Exception;

  public abstract String[] getOperatorNames(String paramString, UserInfoInterface paramUserInfoInterface, ManagerObject paramManagerObject)
    throws Exception;

  public abstract void clearAllHistoryObj()
    throws RemoteException, Exception;

  public abstract boolean checkPermission(String paramString1, String paramString2, UserInfoInterface paramUserInfoInterface, ManagerObject paramManagerObject)
    throws Exception, RemoteException;

  public abstract boolean isNeedPermissionCheck(String paramString1, String paramString2, UserInfoInterface paramUserInfoInterface)
    throws Exception, RemoteException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.IMoSecurityService
 * JD-Core Version:    0.5.4
 */