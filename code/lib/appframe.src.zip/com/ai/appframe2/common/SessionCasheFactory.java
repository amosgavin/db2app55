/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ public class SessionCasheFactory
/*    */ {
/*  4 */   private static CacheManager m_cacheManager = BaseSessionManager.getCacheManager();
/*    */   private static final String S_SESSION_CASHENAME = "com.ai.appframe2.common.SessionCasheFactory";
/*    */ 
/*    */   public static SessionCashe getInstance(String name)
/*    */   {
/*  8 */     SessionCashe result = (SessionCashe)m_cacheManager.get("com.ai.appframe2.common.SessionCasheFactory", name);
/*  9 */     if (result == null) {
/* 10 */       result = new SessionCasheImpl(name);
/* 11 */       m_cacheManager.put("com.ai.appframe2.common.SessionCasheFactory", name, result);
/*    */     }
/* 13 */     return result;
/*    */   }
/*    */ 
/*    */   public static void clear(String sessionId)
/*    */   {
/* 18 */     Object[] keys = m_cacheManager.getKeys("com.ai.appframe2.common.SessionCasheFactory");
/* 19 */     for (int i = 0; (keys != null) && (i < keys.length); ++i)
/* 20 */       ((SessionCashe)m_cacheManager.get("com.ai.appframe2.common.SessionCasheFactory", keys[i])).clear(sessionId);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.SessionCasheFactory
 * JD-Core Version:    0.5.4
 */