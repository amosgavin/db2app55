package com.ai.appframe2.common;

public abstract interface AIResult
{
  public abstract boolean next()
    throws Exception;

  public abstract void close()
    throws Exception;

  public abstract Object getObject(String paramString)
    throws Exception;

  public abstract Object getDispalyAttr(String paramString1, String paramString2)
    throws Exception;

  public abstract int getChildCount();

  public abstract int getLevel();

  public abstract String getChildRowIndexs();

  public abstract boolean ifLastChild();

  public abstract boolean lastNode();

  public abstract long getId();

  public abstract long getParentId();

  public abstract boolean ifOffspringOfRoot();

  public abstract int getLineNum();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIResult
 * JD-Core Version:    0.5.4
 */