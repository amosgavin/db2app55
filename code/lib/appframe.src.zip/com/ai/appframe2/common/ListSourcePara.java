/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ public class ListSourcePara
/*    */ {
/* 15 */   private String name = "";
/* 16 */   private String type = "";
/* 17 */   private String value = "";
/*    */ 
/*    */   public String getName() {
/* 20 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 24 */     return this.type;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 28 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setName(String aName) {
/* 32 */     this.name = ((aName == null) ? "" : aName);
/*    */   }
/*    */ 
/*    */   public void setType(String aType) {
/* 36 */     this.type = ((aType == null) ? "" : aType);
/*    */   }
/*    */ 
/*    */   public void setValue(String aValue) {
/* 40 */     this.value = ((aValue == null) ? "" : aValue);
/*    */   }
/*    */ 
/*    */   public ListSourcePara(String aName, String aType, String aValue) {
/* 44 */     this.name = aName;
/* 45 */     this.type = aType;
/* 46 */     this.value = aValue;
/*    */   }
/*    */   public ListSourcePara() {
/* 49 */     this("", "", "");
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 54 */     ListSourcePara listSourcePara1 = new ListSourcePara();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ListSourcePara
 * JD-Core Version:    0.5.4
 */