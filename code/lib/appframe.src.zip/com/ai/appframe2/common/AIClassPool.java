/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import javassist.ClassPool;
/*    */ import javassist.CtClass;
/*    */ 
/*    */ public class AIClassPool extends ClassPool
/*    */ {
/*    */   public AIClassPool()
/*    */   {
/*  9 */     appendClassPath(new ClassLoaderClassPath(super.getClass().getClassLoader()));
/* 10 */     appendClassPath(new ClassLoaderClassPath(Thread.currentThread().getContextClassLoader()));
/*    */   }
/*    */   public CtClass removeCached(String className) {
/* 13 */     return super.removeCached(className);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIClassPool
 * JD-Core Version:    0.5.4
 */