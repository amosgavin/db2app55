/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ class ConfigItem
/*     */ {
/*     */   String name;
/*     */   String value;
/*     */   String desc;
/*     */ 
/*     */   public ConfigItem(String name)
/*     */   {
/* 285 */     this.name = name;
/*     */   }
/*     */   public ConfigItem(Element e) {
/* 288 */     this.name = e.attributeValue("name");
/* 289 */     this.value = e.attributeValue("value");
/* 290 */     this.desc = e.attributeValue("desc");
/*     */   }
/*     */   public Element createElement() {
/* 293 */     Element e = XmlUtil.createElement("item", "");
/* 294 */     e.addAttribute("name", this.name);
/* 295 */     e.addAttribute("value", this.value);
/* 296 */     e.addAttribute("desc", this.desc);
/* 297 */     return e;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 301 */     return XmlUtil.formatElement(createElement());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ConfigItem
 * JD-Core Version:    0.5.4
 */