package com.ai.appframe2.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.Map;

public abstract interface DataStore
{
  public abstract void save(Connection paramConnection, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception;

  public abstract void saveBatch(Connection paramConnection, DataContainerInterface[] paramArrayOfDataContainerInterface)
    throws Exception;

  public abstract void save(Connection paramConnection, DataContainerInterface paramDataContainerInterface)
    throws Exception;

  public abstract int retrieveCount(Connection paramConnection, ObjectType paramObjectType, String paramString, Map paramMap, String[] paramArrayOfString)
    throws Exception;

  public abstract void retrieve(Connection paramConnection, DataContainerInterface paramDataContainerInterface, String[] paramArrayOfString1, String paramString, Map paramMap, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws Exception;

  public abstract ResultSet retrieve(Connection paramConnection, ObjectType paramObjectType, String[] paramArrayOfString1, String paramString, Map paramMap, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws Exception;

  public abstract ResultSet retrieve(Connection paramConnection, String paramString, Map paramMap)
    throws Exception;

  public abstract DataContainerInterface[] retrieve(Connection paramConnection, Class paramClass, ObjectType paramObjectType, String[] paramArrayOfString1, String paramString, Map paramMap, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws Exception;

  public abstract DataContainerInterface[] exeOperation(Connection paramConnection, DataContainerInterface paramDataContainerInterface, String paramString, Map paramMap)
    throws Exception;

  public abstract DataContainerInterface[] retrieveRelation(Connection paramConnection, DataContainerInterface paramDataContainerInterface, String paramString, Class paramClass, String[] paramArrayOfString1, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws Exception;

  public abstract void fillDataContainerFromBoClass(ResultSet paramResultSet, DataContainerInterface paramDataContainerInterface, Property[] paramArrayOfProperty, boolean paramBoolean)
    throws Exception;

  public abstract DataContainerInterface[] crateDtaContainerFromResultSet(Class paramClass, ObjectType paramObjectType, ResultSet paramResultSet, String[] paramArrayOfString, boolean paramBoolean)
    throws Exception;

  public abstract int execute(Connection paramConnection, String paramString, Map paramMap)
    throws Exception;

  public abstract Timestamp getSysDateFromDB()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataStore
 * JD-Core Version:    0.5.4
 */