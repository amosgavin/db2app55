package com.ai.appframe2.common;

public abstract interface SequenceDeal
{
  public abstract long transferNewId(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.SequenceDeal
 * JD-Core Version:    0.5.4
 */