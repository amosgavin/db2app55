package com.ai.appframe2.common;

import java.io.Serializable;

public abstract interface AIDataBase extends Serializable
{
  public abstract Object get(String paramString);

  public abstract Object getDispalyAttr(String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIDataBase
 * JD-Core Version:    0.5.4
 */