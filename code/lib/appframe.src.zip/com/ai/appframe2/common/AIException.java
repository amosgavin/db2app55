/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ public class AIException extends Exception
/*    */ {
/*    */   public AIException(String msg)
/*    */   {
/* 18 */     super(msg);
/*    */   }
/*    */   public AIException(String msg, Throwable e) {
/* 21 */     super(msg, e);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIException
 * JD-Core Version:    0.5.4
 */