/*    */ package com.ai.appframe2.common.chart;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Date;
/*    */ import org.jfree.chart.ChartFactory;
/*    */ import org.jfree.chart.ChartUtilities;
/*    */ import org.jfree.chart.JFreeChart;
/*    */ import org.jfree.data.time.Second;
/*    */ import org.jfree.data.time.TimeSeries;
/*    */ import org.jfree.data.time.TimeSeriesCollection;
/*    */ 
/*    */ public class TimeSeriasChart
/*    */ {
/*    */   private String title;
/*    */   private String xlabel;
/*    */   private String ylabel;
/* 30 */   private TimeSeriesCollection dataset = new TimeSeriesCollection();
/*    */   private Color color;
/*    */ 
/*    */   public TimeSeriasChart(String title, String xlabel, String ylabel)
/*    */   {
/* 34 */     this.title = title;
/* 35 */     this.xlabel = xlabel;
/* 36 */     this.ylabel = ylabel;
/*    */   }
/*    */ 
/*    */   public void setColor(Color color) {
/* 40 */     this.color = color;
/*    */   }
/*    */ 
/*    */   public void addLine(String name, Date[] date, long[] value)
/*    */   {
/* 50 */     TimeSeries ts = new TimeSeries(name, Second.class);
/* 51 */     for (int i = 0; i < date.length; ++i) {
/* 52 */       ts.add(new Second(date[i]), value[i]);
/*    */     }
/* 54 */     this.dataset.addSeries(ts);
/*    */   }
/*    */ 
/*    */   public void addLine(String name, Date[] date, double[] value) {
/* 58 */     TimeSeries ts = new TimeSeries(name, Second.class);
/* 59 */     for (int i = 0; i < date.length; ++i) {
/* 60 */       ts.add(new Second(date[i]), value[i]);
/*    */     }
/* 62 */     this.dataset.addSeries(ts);
/*    */   }
/*    */ 
/*    */   public void draw(OutputStream out, int width, int height)
/*    */     throws IOException
/*    */   {
/* 73 */     JFreeChart chart = ChartFactory.createTimeSeriesChart(this.title, this.xlabel, this.ylabel, this.dataset, true, true, false);
/*    */ 
/* 75 */     if (this.color != null) {
/* 76 */       chart.setBackgroundPaint(this.color);
/*    */     }
/* 78 */     ChartUtilities.writeChartAsPNG(out, chart, width, height);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.chart.TimeSeriasChart
 * JD-Core Version:    0.5.4
 */