package com.ai.appframe2.common;

import java.io.OutputStream;
import java.io.Writer;
import java.util.HashMap;
import javax.servlet.ServletRequest;

public abstract interface DBGridInterface extends DBGFInterface
{
  public static final int DBGRID_DEFAULT_WIDTH = 600;
  public static final int DBGRID_DEFAULT_HEIGHT = 300;
  public static final int DBGRID_DEFAULT_COLWIDTH = 100;
  public static final int DBGRID_DEFUALT_ROWHEIGHT = 20;
  public static final int DBGRID_DEFAULT_SELECT_WIDTH = 25;
  public static final int DBGRID_DEFAULT_ROWSEQUENCE_WIDTH = 30;
  public static final String DBGRID_DSDefaultDisplayValue = "";
  public static final int TYPE_COL_SHOW = 1;
  public static final int TYPE_COL_HIDE = 2;
  public static final int TYPE_COL_ALL = 3;
  public static final int TYPE_COL_MASK = 4;
  public static final int TYPE_COL_CANMODIFY = 5;
  public static final String MO_DEAL_TYPE_NO_DISPLAY = "no";
  public static final String MO_DEAL_TYPE_HIDDEN = "hidden";
  public static final String MO_DEAL_TYPE_MASK = "mask";
  public static final String MO_MASK_STRING = "***";
  public static final String TRUE_STR = "TRUE";
  public static final String FALSE_STR = "FALSE";
  public static final String DBGRID_DEFAULT_TABLEMODEL = "com.ai.appframe2.web.tag.DefaultDataModel";

  public abstract String getTableid();

  public abstract String getGridWidth();

  public abstract int getGridHeight();

  public abstract int getRowHeight();

  public abstract String getDSDefaultDisplayValue();

  public abstract HashMap getColWidths();

  public abstract String[] getColTotals();

  public abstract String[] getCols(int paramInt);

  public abstract boolean isMultiSel();

  public abstract boolean isRowSequence();

  public abstract boolean isGridEditable();

  public abstract String getColEditable(String paramString);

  public abstract String getOndbclick();

  public abstract String getOnrowchange();

  public abstract String getOncellchange();

  public abstract String getOnvalchange();

  public abstract String getOncontextmenu();

  public abstract String getOndblink();

  public abstract String getOnbeforeturnpage();

  public abstract String getOnafterturnpage();

  public abstract String getOnrowselected();

  public abstract String getOnresize();

  public abstract int getPageCount();

  public abstract int getCurrPage();

  public abstract int getRowCount();

  public abstract String getCacheid();

  public abstract String getFootdisplay();

  public abstract void turnPage(Writer paramWriter, int paramInt)
    throws Exception;

  public abstract void setPagesize(String paramString);

  public abstract void toExcel(OutputStream paramOutputStream)
    throws Exception;

  public abstract void toExcel(OutputStream paramOutputStream, int paramInt1, HashMap paramHashMap, int paramInt2)
    throws Exception;

  public abstract void toTXT(OutputStream paramOutputStream, int paramInt1, HashMap paramHashMap, int paramInt2)
    throws Exception;

  public abstract void refresh(Writer paramWriter, ServletRequest paramServletRequest)
    throws Exception;

  public abstract void refreshByDefineQry(Writer paramWriter, long paramLong, ServletRequest paramServletRequest)
    throws Exception;

  public abstract DefineQryInterface getDeDefineQry();

  public abstract DBGridDataModelInterface getDBGridDataModel();

  public abstract String getModealtype();

  public abstract void setColEditType(String paramString1, String paramString2);

  public abstract String getColEditType(String paramString);

  public abstract void setColTitle(String paramString1, String paramString2);

  public abstract String getColTitle(String paramString);

  public abstract String getTabletitle();

  public abstract void setTabletitle(String paramString);

  public abstract String getHassubtitle();

  public abstract void setHassubtitle(String paramString);

  public abstract String getTablesubtitle();

  public abstract void setTablesubtitle(String paramString);

  public abstract String getOnfocusout();

  public abstract void setOnfocusout(String paramString);

  public abstract void setOnlyquery(boolean paramBoolean);

  public abstract boolean getOnlyquery();

  public abstract String getOntitledbclick();

  public abstract void setColPrompt(String paramString1, String paramString2);

  public abstract String getColPrompt(String paramString);

  public abstract String getGridTmpPercentWidth();

  public abstract void toExcel(OutputStream paramOutputStream, int paramInt1, HashMap paramHashMap, int paramInt2, String paramString)
    throws Exception;

  public abstract void toExcel(OutputStream paramOutputStream, int paramInt1, HashMap paramHashMap, int paramInt2, String[] paramArrayOfString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBGridInterface
 * JD-Core Version:    0.5.4
 */