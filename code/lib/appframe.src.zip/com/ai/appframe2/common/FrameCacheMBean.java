package com.ai.appframe2.common;

import java.util.List;

public abstract interface FrameCacheMBean
{
  public static final String S_MBEAN_NAME = "Appframe:name=FrameCache";

  public abstract void remove(String paramString, Object paramObject);

  public abstract void remove(String paramString);

  public abstract String[] fetchTypes();

  public abstract List query(String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.FrameCacheMBean
 * JD-Core Version:    0.5.4
 */