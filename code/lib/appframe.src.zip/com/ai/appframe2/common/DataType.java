/*      */ package com.ai.appframe2.common;
/*      */ 
/*      */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*      */ import java.io.StringReader;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.NumberFormat;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Vector;
/*      */ import sun.jdbc.rowset.CachedRowSet;
/*      */ 
/*      */ public class DataType
/*      */ {
/*      */   public static final String DATATYPE_STRING = "String";
/*      */   public static final String DATATYPE_SHORT = "Short";
/*      */   public static final String DATATYPE_INTEGER = "Integer";
/*      */   public static final String DATATYPE_LONG = "Long";
/*      */   public static final String DATATYPE_DOUBLE = "Double";
/*      */   public static final String DATATYPE_FLOAT = "Float";
/*      */   public static final String DATATYPE_BYTE = "Byte";
/*      */   public static final String DATATYPE_CHAR = "Char";
/*      */   public static final String DATATYPE_BOOLEAN = "Boolean";
/*      */   public static final String DATATYPE_DATE = "Date";
/*      */   public static final String DATATYPE_TIME = "Time";
/*      */   public static final String DATATYPE_DATETIME = "DateTime";
/*      */   public static final String DATATYPE_OBJECT = "Object";
/*      */   public static final String DATATYPE_short = "short";
/*      */   public static final String DATATYPE_int = "int";
/*      */   public static final String DATATYPE_long = "long";
/*      */   public static final String DATATYPE_double = "double";
/*      */   public static final String DATATYPE_float = "float";
/*      */   public static final String DATATYPE_byte = "byte";
/*      */   public static final String DATATYPE_char = "char";
/*      */   public static final String DATATYPE_boolean = "boolean";
/*      */ 
/*      */   public static boolean isNeedFullClassName(String type)
/*      */   {
/*   62 */     if (type.equals("String")) return false;
/*   63 */     if (type.equals("Short")) return false;
/*   64 */     if (type.equals("Integer")) return false;
/*   65 */     if (type.equals("Long")) return false;
/*   66 */     if (type.equals("Double")) return false;
/*   67 */     if (type.equals("Float")) return false;
/*   68 */     if (type.equals("Byte")) return false;
/*   69 */     if (type.equals("Char")) return false;
/*   70 */     if (type.equals("Boolean")) return false;
/*   71 */     if (type.equals("Date")) return true;
/*   72 */     if (type.equals("Time")) return true;
/*   73 */     if (type.equals("DateTime")) return true;
/*      */ 
/*   75 */     if (type.equals("Object")) return false;
/*      */ 
/*   77 */     if (type.equals("short")) return false;
/*   78 */     if (type.equals("int")) return false;
/*   79 */     if (type.equals("long")) return false;
/*   80 */     if (type.equals("double")) return false;
/*   81 */     if (type.equals("float")) return false;
/*   82 */     if (type.equals("byte")) return false;
/*   83 */     if (type.equals("char")) return false;
/*   84 */     return !type.equals("boolean");
/*      */   }
/*      */ 
/*      */   public int getDatabaseDataType(String type)
/*      */     throws AIException
/*      */   {
/*   91 */     if (type.equalsIgnoreCase("String")) return 12;
/*   92 */     if (type.equalsIgnoreCase("Short")) return 4;
/*   93 */     if (type.equalsIgnoreCase("Integer")) return 4;
/*   94 */     if (type.equalsIgnoreCase("Long")) return 4;
/*   95 */     if (type.equalsIgnoreCase("Double")) return 8;
/*   96 */     if (type.equalsIgnoreCase("Float")) return 6;
/*   97 */     if (type.equalsIgnoreCase("Byte")) return 4;
/*   98 */     if (type.equalsIgnoreCase("Char")) return 12;
/*   99 */     if (type.equalsIgnoreCase("Boolean")) return 4;
/*  100 */     if (type.equalsIgnoreCase("Date")) return 91;
/*  101 */     if (type.equalsIgnoreCase("Time")) return 92;
/*  102 */     if (type.equalsIgnoreCase("DateTime")) return 93;
/*      */ 
/*  104 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.DataType.no_type", new String[] { type });
/*  105 */     throw new AIException(msg);
/*      */   }
/*      */   public static String getJavaObjectType(String type) {
/*  108 */     if (type.equalsIgnoreCase("String")) return "String";
/*  109 */     if ((type.equalsIgnoreCase("Short")) || (type.equalsIgnoreCase("short"))) return "Short";
/*  110 */     if ((type.equalsIgnoreCase("Integer")) || (type.equalsIgnoreCase("int"))) return "Integer";
/*  111 */     if ((type.equalsIgnoreCase("Long")) || (type.equalsIgnoreCase("long"))) return "Long";
/*  112 */     if ((type.equalsIgnoreCase("Double")) || (type.equalsIgnoreCase("double"))) return "Double";
/*  113 */     if ((type.equalsIgnoreCase("Float")) || (type.equalsIgnoreCase("float"))) return "Float";
/*  114 */     if ((type.equalsIgnoreCase("Byte")) || (type.equalsIgnoreCase("byte"))) return "Byte";
/*  115 */     if ((type.equalsIgnoreCase("Char")) || (type.equalsIgnoreCase("char"))) return "Character";
/*  116 */     if ((type.equalsIgnoreCase("Boolean")) || (type.equalsIgnoreCase("boolean"))) return "Boolean";
/*  117 */     if (type.equalsIgnoreCase("Date")) return "Date";
/*  118 */     if (type.equalsIgnoreCase("Time")) return "Time";
/*  119 */     if (type.equalsIgnoreCase("DateTime")) return "Timestamp";
/*  120 */     return type;
/*      */   }
/*      */ 
/*      */   public static Class getJavaClass(String type)
/*      */   {
/*  127 */     int index = type.indexOf("[]");
/*  128 */     if (index < 0) {
/*  129 */       return getJavaClassInner(type);
/*      */     }
/*  131 */     String arrayString = "[";
/*  132 */     String baseType = type.substring(0, index);
/*  133 */     while ((index = type.indexOf("[]", index + 2)) >= 0) {
/*  134 */       arrayString = arrayString + "[";
/*      */     }
/*  136 */     Class baseClass = getJavaClassInner(baseType);
/*      */     try
/*      */     {
/*  139 */       String baseName = "";
/*  140 */       if (!baseClass.isPrimitive()) {
/*  141 */         return ClassLoaderUtil.loadClass(arrayString + "L" + baseClass.getName() + ";");
/*      */       }
/*  143 */       if (baseClass.equals(Boolean.TYPE))
/*  144 */         baseName = "Z";
/*  145 */       else if (baseClass.equals(Byte.TYPE))
/*  146 */         baseName = "B";
/*  147 */       else if (baseClass.equals(Character.TYPE))
/*  148 */         baseName = "C";
/*  149 */       else if (baseClass.equals(Double.TYPE))
/*  150 */         baseName = "D";
/*  151 */       else if (baseClass.equals(Float.TYPE))
/*  152 */         baseName = "F";
/*  153 */       else if (baseClass.equals(Integer.TYPE))
/*  154 */         baseName = "I";
/*  155 */       else if (baseClass.equals(Long.TYPE))
/*  156 */         baseName = "J";
/*  157 */       else if (baseClass.equals(Short.TYPE)) {
/*  158 */         baseName = "S";
/*      */       }
/*  160 */       return ClassLoaderUtil.loadClass(arrayString + baseName);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  163 */       throw new RuntimeException(ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected static Class getJavaClassInner(String type)
/*      */   {
/*  171 */     if (type.equals("String")) return String.class;
/*  172 */     if (type.equals("Short")) return Short.class;
/*  173 */     if (type.equals("Integer")) return Integer.class;
/*  174 */     if (type.equals("Long")) return Long.class;
/*  175 */     if (type.equals("Double")) return Double.class;
/*  176 */     if (type.equals("Float")) return Float.class;
/*  177 */     if (type.equals("Byte")) return Byte.class;
/*  178 */     if ((type.equals("Char")) || (type.equals("Character"))) return Character.class;
/*  179 */     if (type.equals("Boolean")) return Boolean.class;
/*  180 */     if (type.equals("Date")) return java.sql.Date.class;
/*  181 */     if (type.equals("Time")) return Time.class;
/*  182 */     if (type.equals("DateTime")) return Timestamp.class;
/*      */ 
/*  184 */     if (type.equals("Object")) return Object.class;
/*      */ 
/*  186 */     if (type.equals("short")) return Short.TYPE;
/*  187 */     if (type.equals("int")) return Integer.TYPE;
/*  188 */     if (type.equals("long")) return Long.TYPE;
/*  189 */     if (type.equals("double")) return Double.TYPE;
/*  190 */     if (type.equals("float")) return Float.TYPE;
/*  191 */     if (type.equals("byte")) return Byte.TYPE;
/*  192 */     if (type.equals("char")) return Character.TYPE;
/*  193 */     if (type.equals("boolean")) return Boolean.TYPE; try
/*      */     {
/*  195 */       return ClassLoaderUtil.loadClass(type);
/*      */     }
/*      */     catch (ClassNotFoundException ex) {
/*  198 */       throw new RuntimeException(ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String getTypeDefine(String type) throws AIException
/*      */   {
/*  204 */     if (type.equalsIgnoreCase("String")) return "DataType.DATATYPE_STRING";
/*  205 */     if (type.equalsIgnoreCase("Short")) return "DataType.DATATYPE_SHORT";
/*  206 */     if (type.equalsIgnoreCase("Integer")) return "DataType.DATATYPE_INTEGER";
/*  207 */     if (type.equalsIgnoreCase("Long")) return "DataType.DATATYPE_LONG";
/*  208 */     if (type.equalsIgnoreCase("Double")) return "DataType.DATATYPE_DOUBLE";
/*  209 */     if (type.equalsIgnoreCase("Float")) return "DataType.DATATYPE_FLOAT";
/*  210 */     if (type.equalsIgnoreCase("Byte")) return "DataType.DATATYPE_BYTE";
/*  211 */     if (type.equalsIgnoreCase("Char")) return "DataType.DATATYPE_CHAR";
/*  212 */     if (type.equalsIgnoreCase("Boolean")) return "DataType.DATATYPE_BOOLEAN";
/*  213 */     if (type.equalsIgnoreCase("Date")) return "DataType.DATATYPE_DATE";
/*  214 */     if (type.equalsIgnoreCase("Time")) return "DataType.DATATYPE_TIME";
/*  215 */     if (type.equalsIgnoreCase("DateTime")) return "DataType.DATATYPE_DATETIME";
/*      */ 
/*  217 */     return type;
/*      */   }
/*      */ 
/*      */   public static String getTransFunc(String type)
/*      */     throws AIException
/*      */   {
/*  223 */     if (type.equalsIgnoreCase("String")) return "getAsString";
/*  224 */     if (type.equalsIgnoreCase("Short")) return "getAsShort";
/*  225 */     if (type.equalsIgnoreCase("Integer")) return "getAsInt";
/*  226 */     if (type.equalsIgnoreCase("Long")) return "getAsLong";
/*  227 */     if (type.equalsIgnoreCase("Double")) return "getAsDouble";
/*  228 */     if (type.equalsIgnoreCase("Float")) return "getAsFloat";
/*  229 */     if (type.equalsIgnoreCase("Byte")) return "getAsByte";
/*  230 */     if (type.equalsIgnoreCase("Char")) return "getAsChar";
/*  231 */     if (type.equalsIgnoreCase("Boolean")) return "getAsBoolean";
/*  232 */     if (type.equalsIgnoreCase("Date")) return "getAsDate";
/*  233 */     if (type.equalsIgnoreCase("Time")) return "getAsTime";
/*  234 */     if (type.equalsIgnoreCase("DateTime")) return "getAsDateTime";
/*  235 */     return "getObject";
/*      */   }
/*      */ 
/*      */   public static String getSimpleDataType(String type) throws AIException
/*      */   {
/*  240 */     if (type.equalsIgnoreCase("String")) return "String";
/*  241 */     if (type.equalsIgnoreCase("Short")) return "short";
/*  242 */     if (type.equalsIgnoreCase("Integer")) return "int";
/*  243 */     if (type.equalsIgnoreCase("Long")) return "long";
/*  244 */     if (type.equalsIgnoreCase("Double")) return "double";
/*  245 */     if (type.equalsIgnoreCase("Float")) return "float";
/*  246 */     if (type.equalsIgnoreCase("Byte")) return "byte";
/*  247 */     if (type.equalsIgnoreCase("Char")) return "char";
/*  248 */     if (type.equalsIgnoreCase("Boolean")) return "boolean";
/*  249 */     if (type.equalsIgnoreCase("Date")) return "Date";
/*  250 */     if (type.equalsIgnoreCase("Time")) return "Time";
/*  251 */     if (type.equalsIgnoreCase("DateTime")) return "Timestamp";
/*  252 */     return type;
/*      */   }
/*      */ 
/*      */   public static String getDataTypeBySimple(String type) throws AIException {
/*  256 */     if (type.equalsIgnoreCase("short")) return "Short";
/*  257 */     if (type.equalsIgnoreCase("int")) return "Integer";
/*  258 */     if (type.equalsIgnoreCase("long")) return "Long";
/*  259 */     if (type.equalsIgnoreCase("double")) return "Double";
/*  260 */     if (type.equalsIgnoreCase("float")) return "Float";
/*  261 */     if (type.equalsIgnoreCase("byte")) return "Byte";
/*  262 */     if (type.equalsIgnoreCase("char")) return "Char";
/*  263 */     if (type.equalsIgnoreCase("boolean")) return "Boolean";
/*  264 */     if (type.equalsIgnoreCase("Date")) return "Date";
/*  265 */     if (type.equalsIgnoreCase("Time")) return "Time";
/*  266 */     if (type.equalsIgnoreCase("Timestamp")) return "DateTime";
/*  267 */     if (type.equalsIgnoreCase("java.sql.Timestamp")) return "DateTime";
/*  268 */     if (type.equalsIgnoreCase("java.util.Date")) return "Date";
/*  269 */     return type;
/*      */   }
/*      */ 
/*      */   public static boolean isSimpleDataType(String type) {
/*  273 */     if (type.equalsIgnoreCase("String")) return false;
/*  274 */     if (type.equalsIgnoreCase("Short")) return true;
/*  275 */     if (type.equalsIgnoreCase("short")) return true;
/*  276 */     if (type.equalsIgnoreCase("Integer")) return true;
/*  277 */     if (type.equalsIgnoreCase("int")) return true;
/*  278 */     if (type.equalsIgnoreCase("Long")) return true;
/*  279 */     if (type.equalsIgnoreCase("long")) return true;
/*  280 */     if (type.equalsIgnoreCase("Double")) return true;
/*  281 */     if (type.equalsIgnoreCase("double")) return true;
/*  282 */     if (type.equalsIgnoreCase("Float")) return true;
/*  283 */     if (type.equalsIgnoreCase("float")) return true;
/*  284 */     if (type.equalsIgnoreCase("Byte")) return true;
/*  285 */     if (type.equalsIgnoreCase("byte")) return true;
/*  286 */     if (type.equalsIgnoreCase("Char")) return true;
/*  287 */     if (type.equalsIgnoreCase("char")) return true;
/*  288 */     if (type.equalsIgnoreCase("Boolean")) return true;
/*  289 */     if (type.equalsIgnoreCase("boolean")) return true;
/*  290 */     if (type.equalsIgnoreCase("Date")) return false;
/*  291 */     if (type.equalsIgnoreCase("Time")) return false;
/*  292 */     return !type.equalsIgnoreCase("DateTime");
/*      */   }
/*      */ 
/*      */   public static Class getSimpleDataType(Class aClass)
/*      */   {
/*  297 */     if (Integer.class.equals(aClass)) return Integer.TYPE;
/*  298 */     if (Short.class.equals(aClass)) return Short.TYPE;
/*  299 */     if (Long.class.equals(aClass)) return Long.TYPE;
/*  300 */     if (Double.class.equals(aClass)) return Double.TYPE;
/*  301 */     if (Float.class.equals(aClass)) return Float.TYPE;
/*  302 */     if (Byte.class.equals(aClass)) return Byte.TYPE;
/*  303 */     if (Character.class.equals(aClass)) return Character.TYPE;
/*  304 */     if (Boolean.class.equals(aClass)) return Boolean.TYPE;
/*  305 */     return aClass;
/*      */   }
/*      */   public static String getNullValueString(String type) {
/*  308 */     if (type.equalsIgnoreCase("String")) return "null";
/*  309 */     if (type.equalsIgnoreCase("Short")) return "(short)0";
/*  310 */     if (type.equalsIgnoreCase("Integer")) return "0";
/*  311 */     if (type.equalsIgnoreCase("Long")) return "0";
/*  312 */     if (type.equalsIgnoreCase("Double")) return "0";
/*  313 */     if (type.equalsIgnoreCase("Float")) return "0";
/*  314 */     if (type.equalsIgnoreCase("Byte")) return "((byte)0)";
/*  315 */     if (type.equalsIgnoreCase("Char")) return "((char)0)";
/*  316 */     if (type.equalsIgnoreCase("Boolean")) return "false";
/*  317 */     if (type.equalsIgnoreCase("Date")) return "null";
/*  318 */     if (type.equalsIgnoreCase("Time")) return "null";
/*  319 */     if (type.equalsIgnoreCase("DateTime")) return "null";
/*  320 */     return "null";
/*      */   }
/*      */ 
/*      */   public static String getNullValueString(Class type) {
/*  324 */     if (type.equals(Short.TYPE)) return "(short)0";
/*  325 */     if (type.equals(Integer.TYPE)) return "0";
/*  326 */     if (type.equals(Long.TYPE)) return "0";
/*  327 */     if (type.equals(Double.TYPE)) return "0";
/*  328 */     if (type.equals(Float.TYPE)) return "0";
/*  329 */     if (type.equals(Byte.TYPE)) return "((byte)0)";
/*  330 */     if (type.equals(Character.TYPE)) return "((char)0)";
/*  331 */     if (type.equals(Boolean.TYPE)) return "false";
/*      */ 
/*  333 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.DataType.no_null", new String[] { type.getName() });
/*  334 */     throw new RuntimeException(msg);
/*      */   }
/*      */ 
/*      */   public static String getToSimpleDataTypeFunction(String type) {
/*  338 */     if (type.equalsIgnoreCase("String")) return "";
/*  339 */     if ((type.equalsIgnoreCase("Short")) || (type.equalsIgnoreCase("short"))) return "shortValue";
/*  340 */     if ((type.equalsIgnoreCase("Integer")) || (type.equalsIgnoreCase("int"))) return "intValue";
/*  341 */     if ((type.equalsIgnoreCase("Long")) || (type.equalsIgnoreCase("long"))) return "longValue";
/*  342 */     if ((type.equalsIgnoreCase("Double")) || (type.equalsIgnoreCase("double"))) return "doubleValue";
/*  343 */     if ((type.equalsIgnoreCase("Float")) || (type.equalsIgnoreCase("float"))) return "floatValue";
/*  344 */     if ((type.equalsIgnoreCase("Byte")) || (type.equalsIgnoreCase("byte"))) return "byteValue";
/*  345 */     if ((type.equalsIgnoreCase("Char")) || (type.equalsIgnoreCase("char"))) return "charValue";
/*  346 */     if ((type.equalsIgnoreCase("Boolean")) || (type.equalsIgnoreCase("boolean"))) return "booleanValue";
/*  347 */     if (type.equalsIgnoreCase("Date")) return "";
/*  348 */     if (type.equalsIgnoreCase("Time")) return "";
/*  349 */     if (type.equalsIgnoreCase("DateTime")) return "";
/*  350 */     return "";
/*      */   }
/*      */ 
/*      */   public static String getToSimpleDataTypeFunction(Class type) {
/*  354 */     if ((type.equals(Short.class)) || (type.equals(Short.TYPE))) return "shortValue";
/*  355 */     if ((type.equals(Integer.class)) || (type.equals(Integer.TYPE))) return "intValue";
/*  356 */     if ((type.equals(Long.class)) || (type.equals(Long.TYPE))) return "longValue";
/*  357 */     if ((type.equals(Double.class)) || (type.equals(Double.TYPE))) return "doubleValue";
/*  358 */     if ((type.equals(Float.class)) || (type.equals(Float.TYPE))) return "floatValue";
/*  359 */     if ((type.equals(Byte.class)) || (type.equals(Byte.TYPE))) return "byteValue";
/*  360 */     if ((type.equals(Character.class)) || (type.equals(Character.TYPE))) return "charValue";
/*  361 */     if ((type.equals(Boolean.class)) || (type.equals(Boolean.TYPE))) return "booleanValue";
/*  362 */     return "";
/*      */   }
/*      */ 
/*      */   public static void setPrepareStatementParameter(PreparedStatement stmt, int index, String type, Object value) throws SQLException
/*      */   {
/*  367 */     if (type.equalsIgnoreCase("String")) {
/*  368 */       String content = value.toString();
/*  369 */       if (content.length() > 2000) {
/*  370 */         stmt.setCharacterStream(index, new StringReader(content), content.length());
/*      */       }
/*      */       else
/*  373 */         stmt.setString(index, content);
/*      */     }
/*  375 */     else if (type.equalsIgnoreCase("Short")) { stmt.setShort(index, Short.parseShort(value.toString()));
/*  376 */     } else if (type.equalsIgnoreCase("Integer")) { stmt.setInt(index, Integer.parseInt(value.toString()));
/*  377 */     } else if (type.equalsIgnoreCase("Long")) { stmt.setLong(index, Long.parseLong(value.toString()));
/*  378 */     } else if (type.equalsIgnoreCase("Double")) { stmt.setDouble(index, Double.parseDouble(value.toString()));
/*  379 */     } else if (type.equalsIgnoreCase("Float")) { stmt.setFloat(index, Float.parseFloat(value.toString()));
/*  380 */     } else if (type.equalsIgnoreCase("Byte")) { stmt.setByte(index, Byte.parseByte(value.toString()));
/*  381 */     } else if (type.equalsIgnoreCase("Char")) { stmt.setString(index, value.toString());
/*  382 */     } else if (type.equalsIgnoreCase("Boolean")) { stmt.setBoolean(index, Boolean.getBoolean(value.toString()));
/*  383 */     } else if (type.equalsIgnoreCase("Date")) {
/*  384 */       if (value instanceof java.sql.Date)
/*  385 */         stmt.setDate(index, (java.sql.Date)(java.sql.Date)value);
/*      */       else
/*  387 */         stmt.setDate(index, java.sql.Date.valueOf(value.toString()));
/*  388 */     } else if (type.equalsIgnoreCase("Time")) {
/*  389 */       if (value instanceof Time)
/*  390 */         stmt.setTime(index, (Time)(Time)value);
/*      */       else
/*  392 */         stmt.setTime(index, Time.valueOf(value.toString()));
/*  393 */     } else if (type.equalsIgnoreCase("DateTime")) {
/*  394 */       if (value instanceof Timestamp)
/*  395 */         stmt.setTimestamp(index, (Timestamp)(Timestamp)value);
/*  396 */       else if (value instanceof java.sql.Date)
/*  397 */         stmt.setTimestamp(index, new Timestamp(((java.sql.Date)value).getTime()));
/*      */       else
/*  399 */         stmt.setTimestamp(index, Timestamp.valueOf(value.toString()));
/*      */     }
/*  401 */     else if (value instanceof Character) {
/*  402 */       stmt.setString(index, value.toString());
/*      */     } else {
/*  404 */       stmt.setObject(index, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void setPrepareStatementParameter(CachedRowSet stmt, int index, String type, Object value) throws SQLException {
/*  409 */     if (type.equalsIgnoreCase("String")) stmt.setString(index, value.toString());
/*  410 */     else if (type.equalsIgnoreCase("Short")) stmt.setInt(index, Short.parseShort(value.toString()));
/*  411 */     else if (type.equalsIgnoreCase("Integer")) stmt.setInt(index, Integer.parseInt(value.toString()));
/*  412 */     else if (type.equalsIgnoreCase("Long")) stmt.setLong(index, Long.parseLong(value.toString()));
/*  413 */     else if (type.equalsIgnoreCase("Double")) stmt.setDouble(index, Double.parseDouble(value.toString()));
/*  414 */     else if (type.equalsIgnoreCase("Float")) stmt.setFloat(index, Float.parseFloat(value.toString()));
/*  415 */     else if (type.equalsIgnoreCase("Byte")) stmt.setByte(index, Byte.parseByte(value.toString()));
/*  416 */     else if (type.equalsIgnoreCase("Char")) stmt.setString(index, value.toString());
/*  417 */     else if (type.equalsIgnoreCase("Boolean")) stmt.setBoolean(index, Boolean.getBoolean(value.toString()));
/*  418 */     else if (type.equalsIgnoreCase("Date"))
/*  419 */       if (value instanceof java.sql.Date)
/*  420 */         stmt.setDate(index, (java.sql.Date)(java.sql.Date)value);
/*      */       else
/*  422 */         stmt.setDate(index, java.sql.Date.valueOf(value.toString()));
/*  423 */     else if (type.equalsIgnoreCase("Time"))
/*  424 */       if (value instanceof Time)
/*  425 */         stmt.setTime(index, (Time)(Time)value);
/*      */       else
/*  427 */         stmt.setTime(index, Time.valueOf(value.toString()));
/*  428 */     else if (type.equalsIgnoreCase("DateTime")) {
/*  429 */       if (value instanceof Timestamp)
/*  430 */         stmt.setTimestamp(index, (Timestamp)(Timestamp)value);
/*  431 */       else if (value instanceof java.sql.Date)
/*  432 */         stmt.setTimestamp(index, new Timestamp(((java.sql.Date)value).getTime()));
/*      */       else
/*  434 */         stmt.setTimestamp(index, Timestamp.valueOf(value.toString()));
/*      */     }
/*  436 */     else if (value instanceof Character)
/*  437 */       stmt.setString(index, value.toString());
/*      */     else
/*  439 */       stmt.setObject(index, value);
/*      */   }
/*      */ 
/*      */   public static String transferToString(Object value, String type, int precision)
/*      */   {
/*  447 */     if (value == null)
/*  448 */       return "";
/*  449 */     String result = "";
/*  450 */     if (type.equalsIgnoreCase("Date")) {
/*  451 */       if ((value instanceof java.util.Date) || (value instanceof Timestamp)) {
/*      */         try {
/*  453 */           SimpleDateFormat DATA_FORMAT_yyyyMMdd = new SimpleDateFormat("yyyy-MM-dd");
/*  454 */           result = DATA_FORMAT_yyyyMMdd.format(value);
/*      */         } catch (Exception e) {
/*  456 */           e.printStackTrace();
/*  457 */           result = "";
/*      */         }
/*      */       }
/*      */       else
/*  461 */         result = value.toString();
/*      */     }
/*  463 */     else if (type.equalsIgnoreCase("Time")) {
/*  464 */       if ((value instanceof java.util.Date) || (value instanceof Time) || (value instanceof Timestamp)) {
/*      */         try {
/*  466 */           SimpleDateFormat DATA_FORMAT_HHmmss = new SimpleDateFormat("HH:mm:ss");
/*  467 */           result = DATA_FORMAT_HHmmss.format(value);
/*      */         }
/*      */         catch (Exception e) {
/*  470 */           e.printStackTrace();
/*  471 */           result = "";
/*      */         }
/*      */       }
/*      */       else
/*  475 */         result = value.toString();
/*      */     }
/*  477 */     else if (type.equalsIgnoreCase("DateTime")) {
/*  478 */       if ((value instanceof java.util.Date) || (value instanceof Timestamp)) {
/*      */         try {
/*  480 */           SimpleDateFormat DATA_FORMAT_yyyyMMddHHmmss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  481 */           result = DATA_FORMAT_yyyyMMddHHmmss.format(value);
/*      */         } catch (Exception e) {
/*  483 */           e.printStackTrace();
/*  484 */           result = "";
/*      */         }
/*      */       }
/*      */       else
/*  488 */         result = value.toString();
/*      */     }
/*  490 */     else if ((type.equalsIgnoreCase("Double")) || (type.equalsIgnoreCase("Float"))) {
/*  491 */       NumberFormat nf = NumberFormat.getInstance();
/*  492 */       if (precision >= 0) {
/*      */         try {
/*  494 */           nf.setMaximumFractionDigits(precision);
/*  495 */           nf.setGroupingUsed(false);
/*  496 */           result = nf.format(nf.parse(value.toString()).doubleValue());
/*      */         }
/*      */         catch (Exception ex) {
/*  499 */           ex.printStackTrace();
/*  500 */           result = value.toString();
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*  506 */         result = value.toString();
/*      */       }
/*      */     }
/*      */     else {
/*  510 */       result = value.toString();
/*  511 */     }return result;
/*      */   }
/*      */ 
/*      */   public static Object transfer(Object value, Class type)
/*      */   {
/*  516 */     if (value == null) return null;
/*  517 */     if ((value instanceof String) && (value.toString().trim().equals(""))) {
/*  518 */       if (String.class.equals(type)) {
/*  519 */         return value;
/*      */       }
/*  521 */       return null;
/*      */     }
/*      */ 
/*  524 */     if ((type.equals(Short.class)) || (type.equals(Short.TYPE))) {
/*  525 */       if (value instanceof Short) {
/*  526 */         return value;
/*      */       }
/*  528 */       return new Short(new BigDecimal(value.toString()).shortValue());
/*  529 */     }if ((type.equals(Integer.class)) || (type.equals(Integer.TYPE))) {
/*  530 */       if (value instanceof Integer) {
/*  531 */         return value;
/*      */       }
/*  533 */       return new Integer(new BigDecimal(value.toString()).intValue());
/*  534 */     }if ((type.equals(Character.class)) || (type.equals(Character.TYPE))) {
/*  535 */       if (value instanceof Character) {
/*  536 */         return value;
/*      */       }
/*  538 */       return new Character(value.toString().charAt(0));
/*  539 */     }if ((type.equals(Long.class)) || (type.equals(Long.TYPE))) {
/*  540 */       if (value instanceof Long) {
/*  541 */         return value;
/*      */       }
/*  543 */       return new Long(new BigDecimal(value.toString()).longValue());
/*  544 */     }if (type.equals(String.class)) {
/*  545 */       if (value instanceof String) {
/*  546 */         return value;
/*      */       }
/*  548 */       return value.toString();
/*  549 */     }if (type.equals(java.sql.Date.class)) {
/*  550 */       if (value instanceof java.sql.Date)
/*  551 */         return value;
/*  552 */       if (value instanceof java.util.Date)
/*  553 */         return new java.sql.Date(((java.util.Date)value).getTime());
/*      */       try
/*      */       {
/*  556 */         SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd");
/*  557 */         return new java.sql.Date(a.parse(value.toString()).getTime());
/*      */       } catch (Exception e) {
/*  559 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Date" });
/*  560 */         throw new RuntimeException(msg);
/*      */       }
/*      */     }
/*  563 */     if (type.equals(Time.class)) {
/*  564 */       if (value instanceof Time)
/*  565 */         return value;
/*  566 */       if (value instanceof java.util.Date)
/*  567 */         return new Time(((java.util.Date)value).getTime());
/*      */       try
/*      */       {
/*  570 */         SimpleDateFormat a = new SimpleDateFormat("HH:mm:ss");
/*  571 */         return new Time(a.parse(value.toString()).getTime());
/*      */       } catch (Exception e) {
/*  573 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Time" });
/*  574 */         throw new RuntimeException(msg);
/*      */       }
/*      */     }
/*  577 */     if (type.equals(Timestamp.class)) {
/*  578 */       if (value instanceof Timestamp)
/*  579 */         return value;
/*  580 */       if (value instanceof java.util.Date)
/*  581 */         return new Timestamp(((java.util.Date)value).getTime());
/*      */       try
/*      */       {
/*  584 */         SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  585 */         String tmpstr = value.toString();
/*  586 */         if (tmpstr.trim().length() <= 10)
/*  587 */           tmpstr = tmpstr + " 00:00:00";
/*  588 */         return new Timestamp(a.parse(tmpstr).getTime());
/*      */       } catch (Exception e) {
/*  590 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "DateTime" });
/*  591 */         throw new RuntimeException(msg);
/*      */       }
/*      */     }
/*  594 */     if ((type.equals(Double.class)) || (type.equals(Double.TYPE))) {
/*  595 */       if (value instanceof Double) {
/*  596 */         return value;
/*      */       }
/*  598 */       return new Double(new BigDecimal(value.toString()).doubleValue());
/*  599 */     }if ((type.equals(Float.class)) || (type.equals(Float.TYPE))) {
/*  600 */       if (value instanceof Float) {
/*  601 */         return value;
/*      */       }
/*  603 */       return new Float(new BigDecimal(value.toString()).floatValue());
/*  604 */     }if ((type.equals(Byte.class)) || (type.equals(Byte.TYPE))) {
/*  605 */       if (value instanceof Byte) {
/*  606 */         return value;
/*      */       }
/*  608 */       return new Byte(new BigDecimal(value.toString()).byteValue());
/*  609 */     }if ((type.equals(Boolean.class)) || (type.equals(Boolean.TYPE))) {
/*  610 */       if (value instanceof Boolean)
/*  611 */         return value;
/*  612 */       if (value instanceof Number) {
/*  613 */         if (((Number)value).doubleValue() > 0.0D) {
/*  614 */           return new Boolean(true);
/*      */         }
/*  616 */         return new Boolean(false);
/*  617 */       }if (value instanceof String) {
/*  618 */         if ((((String)value).equalsIgnoreCase("true")) || (((String)value).equalsIgnoreCase("y"))) {
/*  619 */           return new Boolean(true);
/*      */         }
/*  621 */         return new Boolean(false);
/*      */       }
/*  623 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Boolean" });
/*  624 */       throw new RuntimeException(msg);
/*      */     }
/*      */ 
/*  627 */     return value;
/*      */   }
/*      */ 
/*      */   public static String transferToString(Object value, String type)
/*      */   {
/*  633 */     return transferToString(value, type, -1);
/*      */   }
/*      */ 
/*      */   public static Object transfer(Object value, String type)
/*      */   {
/*  638 */     if (value == null) return null;
/*  639 */     if ((value instanceof String) && (value.toString().trim().equals(""))) {
/*  640 */       if ("String".equalsIgnoreCase(type)) {
/*  641 */         return value;
/*      */       }
/*  643 */       return null;
/*      */     }
/*      */ 
/*  646 */     if ((type.equalsIgnoreCase("Short")) || (type.equalsIgnoreCase("short"))) {
/*  647 */       if (value instanceof Short) {
/*  648 */         return value;
/*      */       }
/*  650 */       return new Short(new BigDecimal(value.toString()).shortValue());
/*  651 */     }if ((type.equalsIgnoreCase("Integer")) || (type.equalsIgnoreCase("int"))) {
/*  652 */       if (value instanceof Integer) {
/*  653 */         return value;
/*      */       }
/*  655 */       return new Integer(new BigDecimal(value.toString()).intValue());
/*  656 */     }if ((type.equalsIgnoreCase("Char")) || (type.equalsIgnoreCase("char"))) {
/*  657 */       if (value instanceof Character) {
/*  658 */         return value;
/*      */       }
/*  660 */       return new Character(value.toString().charAt(0));
/*  661 */     }if ((type.equalsIgnoreCase("Long")) || (type.equalsIgnoreCase("long"))) {
/*  662 */       if (value instanceof Long) {
/*  663 */         return value;
/*      */       }
/*  665 */       return new Long(new BigDecimal(value.toString()).longValue());
/*  666 */     }if (type.equalsIgnoreCase("String")) {
/*  667 */       if (value instanceof String) {
/*  668 */         return value;
/*      */       }
/*  670 */       return value.toString();
/*  671 */     }if (type.equalsIgnoreCase("Date")) {
/*  672 */       if (value instanceof java.sql.Date)
/*  673 */         return value;
/*  674 */       if (value instanceof Timestamp)
/*  675 */         return new java.sql.Date(((Timestamp)value).getTime());
/*      */       try
/*      */       {
/*  678 */         String tmpstr = value.toString().replace('/', '-');
/*  679 */         SimpleDateFormat DATA_FORMAT_yyyyMMdd = new SimpleDateFormat("yyyy-MM-dd");
/*  680 */         return new java.sql.Date(DATA_FORMAT_yyyyMMdd.parse(tmpstr).getTime());
/*      */       } catch (Exception ex) {
/*  682 */         if (ex instanceof RuntimeException) {
/*  683 */           throw ((RuntimeException)ex);
/*      */         }
/*  685 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Date" });
/*  686 */         throw new RuntimeException(msg, ex);
/*      */       }
/*      */     }
/*      */ 
/*  690 */     if (type.equalsIgnoreCase("Time")) {
/*  691 */       if (value instanceof Time)
/*  692 */         return value;
/*  693 */       if (value instanceof Timestamp)
/*  694 */         return new Time(((Timestamp)value).getTime());
/*      */       try
/*      */       {
/*  697 */         SimpleDateFormat DATA_FORMAT_HHmmss = new SimpleDateFormat("HH:mm:ss");
/*  698 */         return new Time(DATA_FORMAT_HHmmss.parse(value.toString()).getTime());
/*      */       } catch (Exception e) {
/*  700 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Time" });
/*  701 */         throw new RuntimeException(msg, e);
/*      */       }
/*      */     }
/*  704 */     if (type.equalsIgnoreCase("DateTime")) {
/*  705 */       if (value instanceof Timestamp)
/*  706 */         return value;
/*  707 */       if (value instanceof java.util.Date)
/*  708 */         return new Timestamp(((java.util.Date)value).getTime());
/*      */       try
/*      */       {
/*  711 */         SimpleDateFormat a = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  712 */         String tmpstr = value.toString();
/*  713 */         if (tmpstr.trim().length() <= 10)
/*  714 */           tmpstr = tmpstr + " 00:00:00";
/*  715 */         return new Timestamp(a.parse(tmpstr).getTime());
/*      */       } catch (Exception e) {
/*  717 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "DateTime" });
/*  718 */         throw new RuntimeException(msg);
/*      */       }
/*      */     }
/*  721 */     if ((type.equalsIgnoreCase("Double")) || (type.equalsIgnoreCase("double"))) {
/*  722 */       if (value instanceof Double) {
/*  723 */         return value;
/*      */       }
/*  725 */       return new Double(new BigDecimal(value.toString()).doubleValue());
/*  726 */     }if ((type.equalsIgnoreCase("Float")) || (type.equalsIgnoreCase("float"))) {
/*  727 */       if (value instanceof Float) {
/*  728 */         return value;
/*      */       }
/*  730 */       return new Float(new BigDecimal(value.toString()).floatValue());
/*  731 */     }if ((type.equalsIgnoreCase("Byte")) || (type.equalsIgnoreCase("byte"))) {
/*  732 */       if (value instanceof Byte) {
/*  733 */         return value;
/*      */       }
/*  735 */       return new Byte(new BigDecimal(value.toString()).byteValue());
/*  736 */     }if ((type.equalsIgnoreCase("Boolean")) || (type.equalsIgnoreCase("boolean"))) {
/*  737 */       if (value instanceof Boolean)
/*  738 */         return value;
/*  739 */       if (value instanceof Number) {
/*  740 */         if (((Number)value).doubleValue() > 0.0D) {
/*  741 */           return new Boolean(true);
/*      */         }
/*  743 */         return new Boolean(false);
/*  744 */       }if (value instanceof String) {
/*  745 */         if ((((String)value).equalsIgnoreCase("true")) || (((String)value).equalsIgnoreCase("y"))) {
/*  746 */           return new Boolean(true);
/*      */         }
/*  748 */         return new Boolean(false);
/*      */       }
/*  750 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Boolean" });
/*  751 */       throw new RuntimeException(msg);
/*      */     }
/*      */ 
/*  754 */     return value;
/*      */   }
/*      */ 
/*      */   public static String getAsString(Object obj)
/*      */   {
/*  761 */     if (obj == null) {
/*  762 */       return null;
/*      */     }
/*  764 */     return obj.toString();
/*      */   }
/*      */   public static short getAsShort(Object obj) {
/*  767 */     if (obj == null)
/*  768 */       return 0;
/*  769 */     if (obj instanceof Number) {
/*  770 */       return ((Number)obj).shortValue();
/*      */     }
/*  772 */     return ((Short)transfer(obj, Short.class)).shortValue();
/*      */   }
/*      */   public static int getAsInt(Object obj) {
/*  775 */     if (obj == null)
/*  776 */       return 0;
/*  777 */     if (obj instanceof Number) {
/*  778 */       return ((Number)obj).intValue();
/*      */     }
/*  780 */     return ((Integer)transfer(obj, Integer.class)).intValue();
/*      */   }
/*      */   public static long getAsLong(Object obj) {
/*  783 */     if (obj == null)
/*  784 */       return 0L;
/*  785 */     if (obj instanceof Number) {
/*  786 */       return ((Number)obj).longValue();
/*      */     }
/*  788 */     return ((Long)transfer(obj, Long.class)).longValue();
/*      */   }
/*      */ 
/*      */   public static double getAsDouble(Object obj) {
/*  792 */     if (obj == null)
/*  793 */       return 0.0D;
/*  794 */     if (obj instanceof Number) {
/*  795 */       return ((Number)obj).doubleValue();
/*      */     }
/*  797 */     return ((Double)transfer(obj, Double.class)).doubleValue();
/*      */   }
/*      */   public static float getAsFloat(Object obj) {
/*  800 */     if (obj == null)
/*  801 */       return 0.0F;
/*  802 */     if (obj instanceof Number) {
/*  803 */       return ((Number)obj).floatValue();
/*      */     }
/*  805 */     return ((Float)transfer(obj, Float.class)).floatValue();
/*      */   }
/*      */   public static byte getAsByte(Object obj) {
/*  808 */     if (obj == null)
/*  809 */       return 0;
/*  810 */     if (obj instanceof Number) {
/*  811 */       return ((Number)obj).byteValue();
/*      */     }
/*  813 */     return ((Byte)transfer(obj, Byte.class)).byteValue();
/*      */   }
/*      */   public static boolean getAsBoolean(Object obj) {
/*  816 */     if (obj == null)
/*  817 */       return false;
/*  818 */     if (obj instanceof Boolean) {
/*  819 */       return ((Boolean)obj).booleanValue();
/*      */     }
/*  821 */     return ((Boolean)transfer(obj, Boolean.class)).booleanValue();
/*      */   }
/*      */ 
/*      */   public static char getAsChar(Object obj) {
/*  825 */     if (obj == null)
/*  826 */       return '\000';
/*  827 */     if (obj instanceof Character)
/*  828 */       return ((Character)obj).charValue();
/*  829 */     if ((obj instanceof String) && (((String)obj).length() == 1)) {
/*  830 */       return ((String)obj).charAt(0);
/*      */     }
/*  832 */     return ((Character)transfer(obj, Character.class)).charValue();
/*      */   }
/*      */   public static java.sql.Date getAsDate(Object obj) {
/*  835 */     if (obj == null)
/*  836 */       return null;
/*  837 */     if (obj instanceof java.sql.Date)
/*  838 */       return (java.sql.Date)obj;
/*  839 */     if (obj instanceof Timestamp)
/*      */     {
/*  841 */       return new java.sql.Date(((Timestamp)obj).getTime());
/*      */     }
/*      */ 
/*  844 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { obj.toString(), "Date" });
/*  845 */     throw new RuntimeException(msg);
/*      */   }
/*      */ 
/*      */   public static Time getAsTime(Object obj) {
/*  849 */     if (obj == null)
/*  850 */       return null;
/*  851 */     if (obj instanceof Time)
/*  852 */       return (Time)obj;
/*  853 */     if (obj instanceof Timestamp)
/*      */     {
/*  855 */       return new Time(((Timestamp)obj).getTime());
/*      */     }
/*      */ 
/*  858 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { obj.toString(), "Time" });
/*  859 */     throw new RuntimeException(msg);
/*      */   }
/*      */ 
/*      */   public static Timestamp getAsDateTime(Object obj)
/*      */   {
/*  864 */     if (obj == null)
/*  865 */       return null;
/*  866 */     if (obj instanceof Timestamp)
/*  867 */       return (Timestamp)obj;
/*  868 */     if (obj instanceof java.sql.Date)
/*      */     {
/*  870 */       return new Timestamp(((java.sql.Date)obj).getTime());
/*      */     }
/*      */ 
/*  873 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { obj.toString(), "DateTime" });
/*  874 */     throw new RuntimeException(msg);
/*      */   }
/*      */ 
/*      */   public static String getModifyName(int mod)
/*      */   {
/*  885 */     StringBuilder sb = new StringBuilder();
/*      */ 
/*  888 */     if ((mod & 0x1) != 0) sb.append("public ");
/*  889 */     if ((mod & 0x4) != 0) sb.append("protected ");
/*  890 */     if ((mod & 0x2) != 0) sb.append("private ");
/*      */ 
/*  892 */     if ((mod & 0x10) != 0) sb.append("final ");
/*      */ 
/*  894 */     if (Modifier.isStatic(mod)) sb.append(" static ");
/*      */     int len;
/*  897 */     if ((len = sb.length()) > 0)
/*  898 */       return sb.toString().substring(0, len - 1);
/*  899 */     return "";
/*      */   }
/*      */ 
/*      */   public static String getClassName(Class className) {
/*  903 */     String name = className.getName();
/*  904 */     return getClassName(name);
/*      */   }
/*      */   public static String getClassName(String name) {
/*  907 */     String arrays = "";
/*  908 */     if (name.indexOf("[") >= 0) {
/*  909 */       int point = 0;
/*  910 */       while (name.charAt(point) == '[') {
/*  911 */         arrays = arrays + "[]";
/*  912 */         ++point;
/*      */       }
/*  914 */       if (name.charAt(point) == 'L')
/*  915 */         name = name.substring(point + 1, name.length() - 1);
/*  916 */       else if (name.charAt(point) == 'Z')
/*  917 */         name = "boolean";
/*  918 */       else if (name.charAt(point) == 'B')
/*  919 */         name = "byte";
/*  920 */       else if (name.charAt(point) == 'C')
/*  921 */         name = "char";
/*  922 */       else if (name.charAt(point) == 'D')
/*  923 */         name = "double";
/*  924 */       else if (name.charAt(point) == 'F')
/*  925 */         name = "float";
/*  926 */       else if (name.charAt(point) == 'I')
/*  927 */         name = "int";
/*  928 */       else if (name.charAt(point) == 'J')
/*  929 */         name = "long";
/*  930 */       else if (name.charAt(point) == 'S') {
/*  931 */         name = "short";
/*      */       }
/*      */     }
/*  934 */     int index = name.lastIndexOf('.');
/*  935 */     if ((index > 0) && (name.substring(0, index).equals("java.lang") == true)) {
/*  936 */       name = name.substring(index + 1);
/*      */     }
/*  938 */     name = name + arrays;
/*  939 */     return name;
/*      */   }
/*      */ 
/*      */   public static String[] getDataTypeNames() {
/*  943 */     return new String[] { "String", "Short", "Integer", "Long", "Double", "Float", "Byte", "Char", "Boolean", "Date", "Time", "DateTime", "Object", "short", "int", "long", "long", "float", "byte", "char", "boolean", "UserInfoInterface" };
/*      */   }
/*      */ 
/*      */   public static Class getPrimitiveClass(Class type)
/*      */   {
/*  971 */     if (type.equals(Short.TYPE)) return Short.class;
/*  972 */     if (type.equals(Integer.TYPE)) return Integer.class;
/*  973 */     if (type.equals(Long.TYPE)) return Long.class;
/*  974 */     if (type.equals(Double.TYPE)) return Double.class;
/*  975 */     if (type.equals(Float.TYPE)) return Float.class;
/*  976 */     if (type.equals(Byte.TYPE)) return Byte.class;
/*  977 */     if (type.equals(Character.TYPE)) return Character.class;
/*  978 */     if (type.equals(Boolean.TYPE)) return Boolean.class;
/*  979 */     return type;
/*      */   }
/*      */ 
/*      */   public static Class getSimpleClass(Class type) {
/*  983 */     if (type.equals(Short.class)) return Short.TYPE;
/*  984 */     if (type.equals(Integer.class)) return Integer.TYPE;
/*  985 */     if (type.equals(Long.class)) return Long.TYPE;
/*  986 */     if (type.equals(Double.class)) return Double.TYPE;
/*  987 */     if (type.equals(Float.class)) return Float.TYPE;
/*  988 */     if (type.equals(Byte.class)) return Byte.TYPE;
/*  989 */     if (type.equals(Character.class)) return Character.TYPE;
/*  990 */     if (type.equals(Boolean.class)) return Boolean.TYPE;
/*  991 */     return type;
/*      */   }
/*      */ 
/*      */   public static String getPrimitiveClass(String type)
/*      */   {
/*  996 */     if (type.equals("short")) return Short.class.getName();
/*  997 */     if (type.equals("int")) return Integer.class.getName();
/*  998 */     if (type.equals("long")) return Long.class.getName();
/*  999 */     if (type.equals("double")) return Double.class.getName();
/* 1000 */     if (type.equals("float")) return Float.class.getName();
/* 1001 */     if (type.equals("byte")) return Byte.class.getName();
/* 1002 */     if (type.equals("char")) return Character.class.getName();
/* 1003 */     if (type.equals("boolean")) return Boolean.class.getName();
/* 1004 */     return type;
/*      */   }
/*      */ 
/*      */   public static Method findMethod(Class baseClass, String methodName, Class[] types, boolean publicOnly, boolean isStatic)
/*      */   {
/* 1012 */     Vector candidates = gatherMethodsRecursive(baseClass, methodName, types.length, publicOnly, isStatic, null);
/*      */ 
/* 1014 */     Method method = findMostSpecificMethod(types, (Method[])(Method[])candidates.toArray(new Method[0]));
/*      */ 
/* 1018 */     return method;
/*      */   }
/*      */ 
/*      */   static Constructor findConstructor(Class baseClass, Class[] types) {
/* 1022 */     Constructor[] constructors = baseClass.getConstructors();
/* 1023 */     Class[][] candidateSigs = new Class[constructors.length][];
/* 1024 */     List list = new ArrayList();
/* 1025 */     for (int i = 0; i < constructors.length; ++i) {
/* 1026 */       if (constructors[i].getParameterTypes().length == types.length) {
/* 1027 */         list.add(constructors[i].getParameterTypes());
/*      */       }
/*      */     }
/*      */ 
/* 1031 */     int match = findMostSpecificSignature(types, (Class[][])(Class[][])list.toArray(new Class[0][]));
/* 1032 */     return (match == -1) ? null : constructors[match];
/*      */   }
/*      */   static int findMostSpecificSignature(Class[] idealMatch, Class[][] candidates) {
/* 1035 */     Class[] bestMatch = null;
/* 1036 */     int bestMatchIndex = -1;
/*      */ 
/* 1038 */     for (int i = candidates.length - 1; i >= 0; --i) {
/* 1039 */       Class[] targetMatch = candidates[i];
/* 1040 */       if ((!isSignatureAssignable(idealMatch, targetMatch)) || ((bestMatch != null) && (!isSignatureAssignable(targetMatch, bestMatch)))) {
/*      */         continue;
/*      */       }
/* 1043 */       bestMatch = targetMatch;
/* 1044 */       bestMatchIndex = i;
/*      */     }
/*      */ 
/* 1048 */     if (bestMatch != null) {
/* 1049 */       return bestMatchIndex;
/*      */     }
/* 1051 */     return -1;
/*      */   }
/*      */ 
/*      */   static boolean isSignatureAssignable(Class[] from, Class[] to) {
/* 1055 */     for (int i = 0; i < from.length; ++i)
/* 1056 */       if (!isAssignable(to[i], from[i]))
/* 1057 */         return false;
/* 1058 */     return true;
/*      */   }
/*      */   public static boolean isAssignable(Class dest, Class sour) {
/* 1061 */     if (dest == sour) {
/* 1062 */       return true;
/*      */     }
/* 1064 */     if (dest == null)
/* 1065 */       return false;
/* 1066 */     if (sour == null) {
/* 1067 */       return !dest.isPrimitive();
/*      */     }
/* 1069 */     if ((dest.isPrimitive()) && (sour.isPrimitive())) {
/* 1070 */       if (dest == sour) {
/* 1071 */         return true;
/*      */       }
/* 1073 */       if ((sour == Byte.TYPE) && (((dest == Short.TYPE) || (dest == Integer.TYPE) || (dest == Long.TYPE) || (dest == Float.TYPE) || (dest == Double.TYPE))))
/*      */       {
/* 1077 */         return true;
/*      */       }
/* 1079 */       if ((sour == Short.TYPE) && (((dest == Integer.TYPE) || (dest == Long.TYPE) || (dest == Float.TYPE) || (dest == Double.TYPE))))
/*      */       {
/* 1082 */         return true;
/*      */       }
/* 1084 */       if ((sour == Character.TYPE) && (((dest == Integer.TYPE) || (dest == Long.TYPE) || (dest == Float.TYPE) || (dest == Double.TYPE))))
/*      */       {
/* 1087 */         return true;
/*      */       }
/* 1089 */       if ((sour == Integer.TYPE) && (((dest == Long.TYPE) || (dest == Float.TYPE) || (dest == Double.TYPE))))
/*      */       {
/* 1092 */         return true;
/*      */       }
/* 1094 */       if ((sour == Long.TYPE) && (((dest == Float.TYPE) || (dest == Double.TYPE))))
/*      */       {
/* 1096 */         return true;
/*      */       }
/* 1098 */       if ((sour == Float.TYPE) && (dest == Double.TYPE)) {
/* 1099 */         return true;
/*      */       }
/*      */     }
/* 1102 */     else if (dest.isAssignableFrom(sour)) {
/* 1103 */       return true;
/*      */     }
/*      */ 
/* 1106 */     return false;
/*      */   }
/*      */ 
/*      */   static Method findMostSpecificMethod(Class[] idealMatch, Method[] methods)
/*      */   {
/* 1111 */     Class[][] candidateSigs = new Class[methods.length][];
/* 1112 */     for (int i = 0; i < methods.length; ++i) {
/* 1113 */       candidateSigs[i] = methods[i].getParameterTypes();
/*      */     }
/* 1115 */     int match = findMostSpecificSignature(idealMatch, candidateSigs);
/* 1116 */     return (match == -1) ? null : methods[match];
/*      */   }
/*      */ 
/*      */   private static Vector gatherMethodsRecursive(Class baseClass, String methodName, int numArgs, boolean publicOnly, boolean isStatic, Vector candidates)
/*      */   {
/* 1123 */     if (candidates == null) {
/* 1124 */       candidates = new Vector();
/*      */     }
/*      */ 
/* 1127 */     addCandidates(baseClass.getDeclaredMethods(), methodName, numArgs, publicOnly, isStatic, candidates);
/*      */ 
/* 1130 */     Class[] intfs = baseClass.getInterfaces();
/* 1131 */     for (int i = 0; i < intfs.length; ++i) {
/* 1132 */       gatherMethodsRecursive(intfs[i], methodName, numArgs, publicOnly, isStatic, candidates);
/*      */     }
/*      */ 
/* 1136 */     Class superclass = baseClass.getSuperclass();
/* 1137 */     if (superclass != null) {
/* 1138 */       gatherMethodsRecursive(superclass, methodName, numArgs, publicOnly, isStatic, candidates);
/*      */     }
/*      */ 
/* 1141 */     return candidates;
/*      */   }
/*      */ 
/*      */   private static Vector addCandidates(Method[] methods, String methodName, int numArgs, boolean publicOnly, boolean isStatic, Vector candidates)
/*      */   {
/* 1147 */     for (int i = 0; i < methods.length; ++i) {
/* 1148 */       Method m = methods[i];
/* 1149 */       if ((!m.getName().equals(methodName)) || (m.getParameterTypes().length != numArgs) || ((publicOnly) && (((!isPublic(m)) || ((isStatic) && (!isStatic(m)))))))
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1154 */       candidates.add(m);
/*      */     }
/* 1156 */     return candidates;
/*      */   }
/*      */ 
/*      */   private static boolean isPublic(Class c) {
/* 1160 */     return Modifier.isPublic(c.getModifiers());
/*      */   }
/*      */ 
/*      */   private static boolean isPublic(Method m) {
/* 1164 */     return Modifier.isPublic(m.getModifiers());
/*      */   }
/*      */   private static boolean isStatic(Method m) {
/* 1167 */     return Modifier.isStatic(m.getModifiers());
/*      */   }
/*      */ 
/*      */   public static void main(String[] args)
/*      */     throws Exception
/*      */   {
/* 1173 */     String abc = "2099-1-1 01:30:30";
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataType
 * JD-Core Version:    0.5.4
 */