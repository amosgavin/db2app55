/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class AIConfigManager
/*     */ {
/*     */   public static final String CONFIG_FILE = "AIConfig.xml";
/*  16 */   public static Element root = null;
/*     */   public static final String ITEM_IS_LOGIN_CHECK_FLAG = "IS_LOGIN_CHECK_FLAG";
/*     */   public static final String ITEM_URL_PERMISSION_SERVICE_SRV_NAME = "URL_PERMISSION_SERVICE_SRV_NAME";
/*     */   public static final String ITEM_IS_URL_CHECK_FLAG = "IS_URL_CHECK_FLAG";
/*     */ 
/*     */   public static void initConfig()
/*     */     throws Exception
/*     */   {
/*  35 */     if (root == null)
/*  36 */       synchronized (AIConfigManager.class) {
/*  37 */         if (root == null) {
/*  38 */           root = XmlUtil.parseXml(AIRootConfig.getConfigInfo("AIConfig.xml"));
/*  39 */           if (!root.getName().equals("AIConfig")) {
/*  40 */             root = null;
/*     */ 
/*  42 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.AIConfigManager.root_tag");
/*  43 */             throw new Exception(msg);
/*     */           }
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public static HashMap getConfigItemsByKind(String pKindName)
/*     */     throws Exception
/*     */   {
/*  52 */     initConfig();
/*  53 */     HashMap map = new HashMap();
/*     */ 
/*  55 */     List kindElements = root.elements("ConfigKind");
/*  56 */     for (int i = 0; i < kindElements.size(); ++i) {
/*  57 */       if (!((Element)kindElements.get(i)).attributeValue("name").equals(pKindName))
/*     */         continue;
/*  59 */       for (int j = 0; j < ((Element)kindElements.get(i)).elements().size(); )
/*     */       {
/*  61 */         Element itemElement = (Element)((Element)kindElements.get(i)).elements().get(j);
/*     */ 
/*  63 */         map.put(itemElement.attributeValue("name"), itemElement.getTextTrim());
/*     */ 
/*  60 */         ++j;
/*     */       }
/*     */ 
/*  67 */       break;
/*     */     }
/*     */ 
/*  71 */     return map;
/*     */   }
/*     */ 
/*     */   private static String getConfigItem(Element parentElement, String pItemName)
/*     */     throws Exception
/*     */   {
/*  77 */     String reVal = null;
/*  78 */     List childList = parentElement.elements();
/*  79 */     for (int i = 0; i < childList.size(); ++i) {
/*  80 */       if (((Element)childList.get(i)).getName().equals("ConfigKind")) {
/*  81 */         reVal = getConfigItem((Element)childList.get(i), pItemName);
/*  82 */         if (reVal == null) continue;
/*  83 */         break;
/*     */       }
/*  85 */       if ((!((Element)childList.get(i)).getName().equals("ConfigItem")) || 
/*  86 */         (!((Element)childList.get(i)).attributeValue("name").equals(pItemName)))
/*     */         continue;
/*  88 */       reVal = ((Element)childList.get(i)).getTextTrim();
/*  89 */       break;
/*     */     }
/*     */ 
/*  94 */     return reVal;
/*     */   }
/*     */ 
/*     */   public static String getConfigItem(String pItemName) throws Exception {
/*  98 */     initConfig();
/*  99 */     return getConfigItem(root, pItemName);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 105 */       HashMap map = getConfigItemsByKind("DBTreePic");
/* 106 */       for (Iterator iter = map.values().iterator(); iter.hasNext(); ) {
/* 107 */         String y = (String)iter.next();
/* 108 */         System.out.println(y);
/*     */       }
/*     */ 
/* 111 */       String x = getConfigItem("FoldCloseImgUrl");
/* 112 */       System.err.println(x);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 116 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIConfigManager
 * JD-Core Version:    0.5.4
 */