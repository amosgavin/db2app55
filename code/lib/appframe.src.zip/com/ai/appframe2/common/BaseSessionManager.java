/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.IOException;
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BaseSessionManager
/*     */ {
/*  35 */   private static transient Log log = LogFactory.getLog(BaseSessionManager.class);
/*     */ 
/*  39 */   private static String SERVICE_ID_REMOTEDATASTORE = "RemoteDataStore";
/*  40 */   private static boolean m_isInitial = false;
/*  41 */   private static URL m_dbDataSourceIniUrl = null;
/*  42 */   private static String m_idGeneratorClass = null;
/*  43 */   private static String m_dataStoreClass = null;
/*  44 */   private static String m_objectTypeFactoryClass = "com.ai.appframe2.bo.ObjectTypeFactoryFromFileImpl";
/*  45 */   private static String m_fieldTypeSetFactoryClass = "com.ai.appframe2.set.GenFieldTypeSetFactoryImpl";
/*  46 */   private static String m_listDataSourceFactoryClass = "com.ai.appframe2.listdatasource.UIDataSourceFactory";
/*     */ 
/*  48 */   private static String m_userManagerImplClass = null;
/*     */ 
/*  50 */   private static String m_mainWebPageUrl = null;
/*  51 */   private static String m_loginOutPageUrl = null;
/*  52 */   private static String m_loginInPageUrl = null;
/*     */ 
/*  54 */   private static String m_securityFactoryServiceName = null;
/*  55 */   private static String m_securityFactorySRVServiceName = null;
/*     */   private static final String DOMAIN_ID = "DOMAIN_ID";
/*  59 */   private static DataStore m_dataStore = null;
/*  60 */   private static IdGenerator m_idgenerator = null;
/*  61 */   private static ObjectTypeFactory m_objectTypeFactory = null;
/*  62 */   private static GenFieldTypeSetFactory m_fieldTypeSetFactory = null;
/*  63 */   private static ListDataSourceFactory m_listDataSourceFactory = null;
/*  64 */   private static Constructor m_session = null;
/*  65 */   private static LogAction m_userLoginAction = null;
/*  66 */   private static String m_contextName = "";
/*  67 */   private static CacheManager m_cacheManager = new CacheManagerImpl();
/*  68 */   private static ThreadLocal s_locale = new ThreadLocal();
/*  69 */   private static ThreadLocal s_user = new ThreadLocal();
/*     */   private static final String CURRENT_DOMAIN_ID = "Current_Domain_Id";
/*  73 */   private static ThreadLocal s_request = new ThreadLocal();
/*  74 */   private static ThreadLocal s_session = new ThreadLocal() {
/*     */     public Object initialValue() {
/*  76 */       Object result = null;
/*     */       try {
/*  78 */         result = BaseSessionManager.m_session.newInstance(new Object[0]);
/*     */       }
/*     */       catch (Exception ex) {
/*  81 */         if (ex instanceof RuntimeException) throw ((RuntimeException)ex);
/*  82 */         throw new RuntimeException(ex);
/*     */       }
/*  84 */       return result;
/*     */     }
/*  74 */   };
/*     */ 
/*     */   private static void readConfigInfo()
/*     */     throws IOException, Exception
/*     */   {
/* 103 */     HashMap propertyMap = AIConfigManager.getConfigItemsByKind("AppFrameInit");
/*     */ 
/* 105 */     String tmpString = (String)propertyMap.get("DbDataSourceIniFile");
/* 106 */     if (tmpString != null) {
/* 107 */       m_dbDataSourceIniUrl = Thread.currentThread().getContextClassLoader().getResource(tmpString);
/* 108 */       if (m_dbDataSourceIniUrl == null)
/* 109 */         m_dbDataSourceIniUrl = BaseSessionManager.class.getClassLoader().getResource(tmpString);
/* 110 */       if (m_dbDataSourceIniUrl == null)
/*     */       {
/* 112 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.no_file");
/* 113 */         throw new IOException(msg + tmpString);
/*     */       }
/*     */     }
/*     */ 
/* 117 */     m_idGeneratorClass = (String)propertyMap.get("IdGeneratorClass");
/* 118 */     m_dataStoreClass = (String)propertyMap.get("DataStoreClass");
/* 119 */     m_userManagerImplClass = (String)propertyMap.get("UserManagerClass");
/* 120 */     m_mainWebPageUrl = (String)propertyMap.get("MainWebPageUrl");
/* 121 */     m_loginOutPageUrl = (String)propertyMap.get("LoginOutPageUrl");
/* 122 */     m_loginInPageUrl = (String)propertyMap.get("LoginInPageUrl");
/*     */   }
/*     */ 
/*     */   public static void initial()
/*     */   {
/*     */     try
/*     */     {
/* 133 */       readConfigInfo();
/*     */ 
/* 135 */       if ((XMLHelper.getInstance().getDefaults().getTransaction() != null) && (!StringUtils.isBlank(XMLHelper.getInstance().getDefaults().getTransaction().getClazz().getName())))
/*     */       {
/* 137 */         m_session = Class.forName(XMLHelper.getInstance().getDefaults().getTransaction().getClazz().getName().trim()).getConstructor(new Class[0]);
/* 138 */         if (log.isDebugEnabled())
/*     */         {
/* 140 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "Session", XMLHelper.getInstance().getDefaults().getTransaction().getClazz().getName().trim() }));
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 146 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.no_transaction_impl"));
/*     */       }
/*     */ 
/* 149 */       if ((m_objectTypeFactoryClass != null) && (!m_objectTypeFactoryClass.trim().equalsIgnoreCase("")))
/*     */       {
/* 152 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "Data Type", m_objectTypeFactoryClass }));
/*     */ 
/* 154 */         m_objectTypeFactory = (ObjectTypeFactory)Class.forName(m_objectTypeFactoryClass).newInstance();
/*     */       }
/*     */ 
/* 157 */       if ((m_idGeneratorClass != null) && (!m_idGeneratorClass.trim().equalsIgnoreCase("")))
/*     */       {
/* 159 */         m_idgenerator = (IdGenerator)Class.forName(m_idGeneratorClass).newInstance();
/*     */ 
/* 162 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "object unique identifier", m_idGeneratorClass }));
/*     */       }
/*     */ 
/* 166 */       if ((m_fieldTypeSetFactoryClass != null) && (!m_fieldTypeSetFactoryClass.trim().equalsIgnoreCase("")))
/*     */       {
/* 168 */         m_fieldTypeSetFactory = (GenFieldTypeSetFactory)Class.forName(m_fieldTypeSetFactoryClass).newInstance();
/*     */ 
/* 171 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "RowSet", m_fieldTypeSetFactoryClass }));
/*     */       }
/*     */ 
/* 174 */       if ((m_listDataSourceFactoryClass != null) && (!m_listDataSourceFactoryClass.trim().equalsIgnoreCase("")))
/*     */       {
/* 176 */         m_listDataSourceFactory = (ListDataSourceFactory)Class.forName(m_listDataSourceFactoryClass).newInstance();
/*     */ 
/* 179 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "enumeration data", m_listDataSourceFactoryClass }));
/*     */       }
/*     */ 
/* 182 */       if ((m_dataStoreClass != null) && (!m_dataStoreClass.trim().equalsIgnoreCase("")))
/*     */       {
/* 184 */         m_dataStore = (DataStore)Class.forName(m_dataStoreClass).newInstance();
/*     */ 
/* 187 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_manager", new String[] { "data Storage", m_dataStoreClass }));
/*     */       }
/*     */ 
/* 197 */       if ((m_mainWebPageUrl != null) && (!m_mainWebPageUrl.trim().equalsIgnoreCase("")))
/*     */       {
/* 199 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_mainURL_success", new String[] { m_mainWebPageUrl }));
/*     */       }
/* 201 */       if ((m_loginOutPageUrl != null) && (!m_loginOutPageUrl.trim().equalsIgnoreCase("")))
/*     */       {
/* 203 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_logoutURL_success", new String[] { m_loginOutPageUrl }));
/*     */       }
/* 205 */       if ((m_loginInPageUrl != null) && (!m_loginInPageUrl.trim().equalsIgnoreCase("")))
/*     */       {
/* 208 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.init_loginURL_success", new String[] { m_loginInPageUrl }));
/*     */       }
/*     */ 
/* 212 */       m_isInitial = true;
/*     */     }
/*     */     catch (Exception ex) {
/* 215 */       log.error(ex.getMessage(), ex);
/* 216 */       if (ex instanceof RuntimeException) throw ((RuntimeException)ex);
/* 217 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static ObjectTypeFactory getObjectTypeFactory()
/*     */   {
/* 226 */     return m_objectTypeFactory;
/*     */   }
/*     */ 
/*     */   public static ListDataSourceFactory getListSrcFactory()
/*     */   {
/* 234 */     return m_listDataSourceFactory;
/*     */   }
/*     */ 
/*     */   public static GenFieldTypeSetFactory getSetFactory()
/*     */   {
/* 242 */     return m_fieldTypeSetFactory;
/*     */   }
/*     */ 
/*     */   public static IdGenerator getIdGenerator()
/*     */   {
/* 250 */     return m_idgenerator;
/*     */   }
/*     */ 
/*     */   public static DataStore getDataStore()
/*     */   {
/* 258 */     return m_dataStore;
/*     */   }
/*     */ 
/*     */   public static Session getSession()
/*     */   {
/* 266 */     return (Session)s_session.get();
/*     */   }
/*     */ 
/*     */   public static void setSession(Session session)
/*     */   {
/* 274 */     s_session.set(session);
/*     */   }
/*     */ 
/*     */   public static Session getSession(String defaultDataSource)
/*     */   {
/* 283 */     Session session = (Session)s_session.get();
/* 284 */     return session;
/*     */   }
/*     */ 
/*     */   public static void setModuleName(String moduleName, UserInfoInterface user)
/*     */   {
/* 292 */     if (user != null)
/* 293 */       Thread.currentThread().setName("Thread-" + Thread.currentThread().hashCode() + "$" + moduleName + "{" + user.getCode() + "}");
/*     */     else
/* 295 */       Thread.currentThread().setName("Thread-" + Thread.currentThread().hashCode() + "$" + moduleName);
/*     */   }
/*     */ 
/*     */   public static String getModuleName()
/*     */   {
/* 303 */     return Thread.currentThread().getName();
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface getUser()
/*     */   {
/* 311 */     UserInfoInterface user = (UserInfoInterface)s_user.get();
/* 312 */     if ((user == null) && 
/* 313 */       (log.isDebugEnabled()))
/*     */     {
/* 315 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.set_user_before_use"));
/*     */     }
/*     */ 
/* 318 */     return user;
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface __getUserWithOutLog()
/*     */   {
/* 327 */     return (UserInfoInterface)s_user.get();
/*     */   }
/*     */ 
/*     */   public static void setUser(UserInfoInterface user)
/*     */   {
/* 335 */     s_user.set(user);
/*     */   }
/*     */ 
/*     */   public static Locale getLocale() {
/* 339 */     if ((s_locale == null) || (s_locale.get() == null)) {
/* 340 */       return null;
/*     */     }
/* 342 */     Locale locale = (Locale)s_locale.get();
/* 343 */     return locale;
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale) {
/* 347 */     s_locale.set(locale);
/*     */   }
/*     */ 
/*     */   public static HttpServletRequest getRequest() {
/* 351 */     HttpServletRequest request = (HttpServletRequest)s_request.get();
/* 352 */     if ((request == null) && 
/* 353 */       (log.isDebugEnabled())) {
/* 354 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.set_user_before_use"));
/*     */     }
/*     */ 
/* 357 */     return request;
/*     */   }
/*     */ 
/*     */   public static void setRequest(HttpServletRequest request)
/*     */   {
/* 365 */     s_request.set(request);
/*     */   }
/*     */ 
/*     */   public static String getUserManagerImplClass() {
/* 369 */     return m_userManagerImplClass;
/*     */   }
/*     */ 
/*     */   public static CacheManager getCacheManager() {
/* 373 */     return m_cacheManager;
/*     */   }
/*     */ 
/*     */   public static LogAction getLoginAction()
/*     */   {
/* 381 */     return m_userLoginAction;
/*     */   }
/*     */ 
/*     */   public static void setContextName(String contextName) {
/* 385 */     m_contextName = contextName;
/*     */   }
/*     */ 
/*     */   public static String getContextName() {
/* 389 */     return m_contextName;
/*     */   }
/*     */ 
/*     */   public static LogAction getLogOutAction()
/*     */   {
/* 397 */     return m_userLoginAction;
/*     */   }
/*     */ 
/*     */   public static String getMainWebPageUrl() {
/* 401 */     return m_mainWebPageUrl;
/*     */   }
/*     */ 
/*     */   public static String getLoginOutWebPageUrl() {
/* 405 */     return m_loginOutPageUrl;
/*     */   }
/*     */ 
/*     */   public static String getLoginInWebPageUrl() {
/* 409 */     return m_loginInPageUrl;
/*     */   }
/*     */ 
/*     */   public static void setCurrentDomainId(long domain_id)
/*     */   {
/* 417 */     HttpServletRequest request = getRequest();
/* 418 */     request.getSession().setAttribute("DOMAIN_ID", new Long(domain_id));
/*     */   }
/*     */ 
/*     */   public static IMoSecurityService getSecurityFactoryForWeb()
/*     */     throws Exception
/*     */   {
/* 427 */     String servName = AIConfigManager.getConfigItem("SECURITY_SERVICE_NAME");
/* 428 */     if (StringUtils.isBlank(servName)) {
/* 429 */       if ("Y".equalsIgnoreCase(AIConfigManager.getConfigItem("IS_MO_PERMISSION")))
/*     */       {
/* 431 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.no_sec_srv", new String[] { "AIConfig.xml", "SECURITY_SERVICE_SRV_NAME" });
/* 432 */         throw new AIException(msg);
/*     */       }
/*     */ 
/* 435 */       return null;
/*     */     }
/*     */ 
/* 439 */     String local = AIConfigManager.getConfigItem("SECURITY_SERVICE_LOCAL");
/* 440 */     if ((!StringUtils.isBlank(local)) && (local.trim().equalsIgnoreCase("Y"))) {
/* 441 */       return (IMoSecurityService)ServiceFactory.getSeviceOfLocal(servName);
/*     */     }
/*     */ 
/* 444 */     return (IMoSecurityService)ServiceFactory.getService(servName);
/*     */   }
/*     */ 
/*     */   public static IMoSecurityService getSecurityFactoryForServer()
/*     */     throws Exception
/*     */   {
/* 450 */     String servName = AIConfigManager.getConfigItem("SECURITY_SERVICE_NAME");
/* 451 */     if (StringUtils.isBlank(servName)) {
/* 452 */       if ("Y".equalsIgnoreCase(AIConfigManager.getConfigItem("IS_MO_PERMISSION")))
/*     */       {
/* 454 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.BaseSessionManager.no_sec_srv", new String[] { "AIConfig.xml", "SECURITY_SERVICE_NAME" });
/* 455 */         throw new AIException(msg);
/*     */       }
/*     */ 
/* 458 */       return null;
/*     */     }
/*     */ 
/* 461 */     return (IMoSecurityService)ServiceFactory.getService(servName);
/*     */   }
/*     */ 
/*     */   public static RemoteDataStore getRemoteDataStore() {
/* 465 */     return (RemoteDataStore)ServiceFactory.getService(SERVICE_ID_REMOTEDATASTORE);
/*     */   }
/*     */ 
/*     */   public static String getThreadLocals(Thread thread) throws Exception
/*     */   {
/* 470 */     Field threadLocalsField = Thread.class.getDeclaredField("threadLocals");
/* 471 */     threadLocalsField.setAccessible(true);
/*     */ 
/* 474 */     Object map = threadLocalsField.get(thread);
/*     */ 
/* 477 */     Field tableField = Class.forName("java.lang.ThreadLocal$ThreadLocalMap").getDeclaredField("table");
/*     */ 
/* 479 */     tableField.setAccessible(true);
/*     */ 
/* 481 */     Object tableObj = tableField.get(map);
/*     */ 
/* 484 */     Field valueField = Class.forName("java.lang.ThreadLocal$ThreadLocalMap$Entry").getDeclaredField("value");
/*     */ 
/* 486 */     valueField.setAccessible(true);
/*     */ 
/* 488 */     int length = Array.getLength(tableObj);
/* 489 */     StringBuilder buffer = new StringBuilder();
/* 490 */     for (int i = 0; i < length; ++i) {
/* 491 */       Object entry = Array.get(tableObj, i);
/* 492 */       if (entry != null) {
/* 493 */         Object value = valueField.get(entry);
/* 494 */         if ((value != null) && (!value instanceof SoftReference)) {
/* 495 */           buffer.append(value).append("\n");
/* 496 */           valueField.set(entry, null);
/*     */         }
/*     */       }
/*     */     }
/* 500 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void clearThreadLocals(Thread thread) throws Exception
/*     */   {
/* 505 */     Field threadLocalsField = Thread.class.getDeclaredField("threadLocals");
/* 506 */     threadLocalsField.setAccessible(true);
/*     */ 
/* 509 */     Object map = threadLocalsField.get(thread);
/*     */ 
/* 512 */     Field tableField = Class.forName("java.lang.ThreadLocal$ThreadLocalMap").getDeclaredField("table");
/*     */ 
/* 514 */     tableField.setAccessible(true);
/*     */ 
/* 516 */     Object tableObj = tableField.get(map);
/*     */ 
/* 519 */     Field valueField = Class.forName("java.lang.ThreadLocal$ThreadLocalMap$Entry").getDeclaredField("value");
/*     */ 
/* 521 */     valueField.setAccessible(true);
/*     */ 
/* 523 */     int length = Array.getLength(tableObj);
/* 524 */     for (int i = 0; i < length; ++i) {
/* 525 */       Object entry = Array.get(tableObj, i);
/* 526 */       if (entry != null) {
/* 527 */         Object value = valueField.get(entry);
/* 528 */         if ((value != null) && (!value instanceof SoftReference))
/* 529 */           valueField.set(entry, null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  91 */     initial();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.BaseSessionManager
 * JD-Core Version:    0.5.4
 */