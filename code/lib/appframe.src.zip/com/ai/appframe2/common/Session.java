package com.ai.appframe2.common;

import com.ai.appframe2.monitor.MonitorItem;
import java.sql.Connection;
import java.sql.SQLException;

public abstract interface Session
{
  public abstract boolean isStartTransaction();

  public abstract void startTransaction()
    throws Exception;

  public abstract void startTransaction(String paramString)
    throws Exception;

  public abstract void commitTransaction()
    throws Exception;

  public abstract void rollbackTransaction()
    throws Exception;

  public abstract Connection getConnection()
    throws SQLException;

  public abstract Connection getNewConnection()
    throws SQLException;

  public abstract Connection getNewConnection(String paramString)
    throws SQLException;

  public abstract Connection getConnection(String paramString)
    throws SQLException;

  public abstract void suspend()
    throws Exception;

  public abstract void resume()
    throws Exception;

  public abstract String debuger();

  public abstract MonitorItem[] getOpenTransaction();

  public abstract void forceRollbackTransaction(String paramString)
    throws Exception;

  public abstract void suspendDataSource(String paramString);

  public abstract void resumeDataSource();

  public abstract String getCurrentTransactionName();

  public abstract String getDefualtDataSourceOfCurrentTransaction();

  public abstract String getDefualtDataSourceByTransactionName(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Session
 * JD-Core Version:    0.5.4
 */