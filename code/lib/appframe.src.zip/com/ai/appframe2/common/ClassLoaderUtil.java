/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import com.sun.tools.javac.Main;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import javassist.ClassPool;
/*     */ import javassist.CtClass;
/*     */ import javassist.CtMethod;
/*     */ import javassist.NotFoundException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ClassLoaderUtil
/*     */ {
/*  26 */   private static transient Log log = LogFactory.getLog(ClassLoaderUtil.class);
/*  27 */   public static String tmpDir = "AppframeTemp";
/*  28 */   public static String CLASS_PATH = null;
/*     */ 
/*     */   public String getTmpDir()
/*     */   {
/*  44 */     return System.getProperty("user.dir") + "/" + tmpDir;
/*     */   }
/*     */ 
/*     */   public static Class parentLoadClass(ClassLoader loader, String name) throws ClassNotFoundException
/*     */   {
/*  49 */     Class clasz = null;
/*  50 */     if (clasz == null)
/*     */       try {
/*  52 */         clasz = loader.getClass().getClassLoader().loadClass(name);
/*     */       }
/*     */       catch (Throwable e) {
/*     */       }
/*  56 */     if (clasz == null)
/*     */       try {
/*  58 */         clasz = Thread.currentThread().getContextClassLoader().loadClass(name);
/*     */       } catch (Throwable e) {
/*     */       }
/*  61 */     return clasz;
/*     */   }
/*     */ 
/*     */   public static Class findLoadedClass(ClassLoader loader, String name) throws ClassNotFoundException {
/*  65 */     Method m = null;
/*     */     try {
/*  67 */       m = ClassLoader.class.getDeclaredMethod("findLoadedClass", new Class[] { String.class });
/*     */ 
/*  69 */       m.setAccessible(true);
/*  70 */       Class result = (Class)m.invoke(loader, new Object[] { name });
/*  71 */       if (result == null) {
/*  72 */         result = (Class)m.invoke(loader.getClass().getClassLoader(), new Object[] { name });
/*     */       }
/*  74 */       if (result == null) {
/*  75 */         result = (Class)m.invoke(Thread.currentThread().getContextClassLoader(), new Object[] { name });
/*     */       }
/*  77 */       Class localClass1 = result;
/*     */ 
/*  85 */       return localClass1;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  84 */       if (m != null)
/*  85 */         m.setAccessible(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] enhanceClass(ClassPool pool, String className)
/*     */   {
/*     */     try {
/*  92 */       CtClass implClass = pool.get(className);
/*     */ 
/*  94 */       if (implClass.isInterface() == true) {
/*  95 */         return null;
/*     */       }
/*  97 */       CtMethod[] methods = implClass.getDeclaredMethods();
/*     */ 
/*  99 */       for (int i = 0; i < methods.length; ++i) {
/* 100 */         CtMethod tmpMethod = methods[i];
/* 101 */         String newFunction = getProxyMethodSource(implClass, tmpMethod);
/*     */ 
/* 103 */         tmpMethod.setName(tmpMethod.getName() + "$impl");
/* 104 */         CtMethod ctMethod = CtMethod.make(newFunction, implClass);
/* 105 */         implClass.addMethod(ctMethod);
/*     */       }
/*     */ 
/* 108 */       return implClass.toBytecode();
/*     */     }
/*     */     catch (Throwable ex) {
/* 111 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.enhance_error", new String[] { className }), ex);
/*     */ 
/* 113 */       if (ex instanceof RuntimeException) throw ((RuntimeException)ex);
/* 114 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Class[] sortExceptions(Class[] exceptions) {
/* 119 */     Arrays.sort(exceptions, new Comparator() {
/*     */       public int compare(Object o1, Object o2) {
/* 121 */         if (o1.equals(o2))
/* 122 */           return 0;
/* 123 */         if (((Class)o1).isAssignableFrom((Class)o2)) {
/* 124 */           return 1;
/*     */         }
/* 126 */         return -1;
/*     */       }
/*     */ 
/*     */       public boolean equals(Object obj) {
/* 130 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.no_impl");
/* 131 */         throw new RuntimeException(msg + "equals(Object obj)");
/*     */       }
/*     */     });
/* 134 */     return exceptions;
/*     */   }
/*     */ 
/*     */   public static CtClass[] sortExceptions(CtClass[] exceptions) {
/* 138 */     Arrays.sort(exceptions, new Comparator() {
/*     */       public int compare(Object o1, Object o2) {
/* 140 */         CtClass c1 = (CtClass)o1;
/* 141 */         CtClass c2 = (CtClass)o2;
/* 142 */         if (o1.equals(o2))
/* 143 */           return 0;
/*     */         while (true)
/*     */         {
/*     */           CtClass parent;
/*     */           try {
/* 148 */             parent = c1.getSuperclass();
/*     */           }
/*     */           catch (NotFoundException ex) {
/* 151 */             throw new RuntimeException(ex);
/*     */           }
/* 153 */           if (parent == null) {
/*     */             break;
/*     */           }
/* 156 */           if (parent.equals(c2))
/* 157 */             return -1;
/* 158 */           c1 = parent;
/*     */         }
/* 160 */         return 1;
/*     */       }
/*     */ 
/*     */       public boolean equals(Object obj) {
/* 164 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.no_impl");
/* 165 */         throw new RuntimeException(msg + "equals(Object obj)");
/*     */       }
/*     */     });
/* 168 */     return exceptions;
/*     */   }
/*     */ 
/*     */   public static String getMethodStatement(String className, CtMethod m) throws Exception
/*     */   {
/* 173 */     StringBuilder buffer = new StringBuilder();
/* 174 */     buffer.append(className).append(".").append(m.getName());
/* 175 */     CtClass[] pList = m.getParameterTypes();
/* 176 */     buffer.append("(");
/* 177 */     for (int i = 0; i < pList.length; ++i) {
/* 178 */       if (i > 0) {
/* 179 */         buffer.append(",");
/*     */       }
/* 181 */       buffer.append(pList[i].getName());
/*     */     }
/* 183 */     buffer.append(")");
/* 184 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getProxyMethodSource(CtClass ctProxyClass, CtMethod method) throws Exception {
/* 188 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 190 */     sb.append(DataType.getModifyName(method.getModifiers()) + " ");
/* 191 */     sb.append(DataType.getClassName(method.getReturnType().getName()) + " ");
/* 192 */     sb.append(method.getName() + "(");
/* 193 */     CtClass[] parameterClazz = method.getParameterTypes();
/* 194 */     boolean hasResult = true;
/* 195 */     if (method.getReturnType().getName().equals("void")) {
/* 196 */       hasResult = false;
/*     */     }
/*     */ 
/* 199 */     String tmpCallVarStr = "";
/* 200 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 201 */       if (j > 0) {
/* 202 */         sb.append(",");
/* 203 */         tmpCallVarStr = tmpCallVarStr + ",";
/*     */       }
/* 205 */       tmpCallVarStr = tmpCallVarStr + "var" + j;
/* 206 */       sb.append(DataType.getClassName(parameterClazz[j].getName()) + " " + "var" + j);
/*     */     }
/* 208 */     sb.append(")");
/*     */ 
/* 210 */     CtClass[] exceptionClazz = method.getExceptionTypes();
/* 211 */     sortExceptions(exceptionClazz);
/* 212 */     if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 213 */       sb.append("throws ");
/* 214 */       for (int j = 0; j < exceptionClazz.length; ++j) {
/* 215 */         sb.append(exceptionClazz[j].getName());
/* 216 */         if (j != exceptionClazz.length - 1) {
/* 217 */           sb.append(",");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 222 */     sb.append("{\n");
/*     */ 
/* 228 */     sb.append("String[] argTypes = new String[" + parameterClazz.length + "];\n");
/* 229 */     sb.append("Object[] args = new Object[" + parameterClazz.length + "];\n");
/* 230 */     sb.append("String returnType = \"" + DataType.getClassName(method.getReturnType().getName()) + "\";\n");
/*     */ 
/* 232 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 233 */       sb.append("argTypes[" + j + "] = \"" + DataType.getClassName(parameterClazz[j].getName()) + "\";\n");
/* 234 */       if (parameterClazz[j].isPrimitive() == true) {
/* 235 */         sb.append("args[" + j + "] = new " + DataType.getPrimitiveClass(parameterClazz[j].getName()) + "(var" + j + ");\n");
/*     */       }
/*     */       else {
/* 238 */         sb.append("args[" + j + "] = var" + j + ";\n");
/*     */       }
/*     */     }
/*     */ 
/* 242 */     sb.append("Object result = null;\n");
/* 243 */     sb.append("Throwable resultException = null;\n");
/* 244 */     if (hasResult == true) {
/* 245 */       sb.append(DataType.getClassName(method.getReturnType().getName()) + " resultReal;\n");
/*     */     }
/*     */ 
/* 250 */     sb.append("try{\n");
/*     */ 
/* 252 */     if (hasResult == true) {
/* 253 */       sb.append("resultReal = " + method.getName() + "$impl(" + tmpCallVarStr + ");\n");
/* 254 */       if (method.getReturnType().isPrimitive()) {
/* 255 */         sb.append("result = new " + DataType.getPrimitiveClass(method.getReturnType().getName()) + "(resultReal);\n");
/*     */       }
/*     */       else
/*     */       {
/* 260 */         sb.append("result = resultReal;\n");
/*     */       }
/*     */ 
/* 265 */       sb.append("return resultReal;\n");
/*     */     }
/*     */     else
/*     */     {
/* 270 */       sb.append(method.getName() + "$impl(" + tmpCallVarStr + ");\n");
/*     */     }
/* 272 */     boolean hasThrowable = false;
/* 273 */     for (int i = 0; i < exceptionClazz.length; ++i)
/*     */     {
/* 275 */       if (exceptionClazz[i].getName().equalsIgnoreCase(RemoteException.class.getName())) {
/*     */         continue;
/*     */       }
/*     */ 
/* 279 */       sb.append("}catch(" + exceptionClazz[i].getName() + " e" + i + " ){\n");
/* 280 */       sb.append("resultException = e" + i + ";\n");
/*     */ 
/* 283 */       sb.append("throw e" + i + ";\n");
/* 284 */       if (exceptionClazz[i].getName().equals(Throwable.class.getName())) {
/* 285 */         hasThrowable = true;
/*     */       }
/*     */     }
/* 288 */     if (!hasThrowable) {
/* 289 */       sb.append("}catch(Throwable e ){\n");
/* 290 */       sb.append("resultException = e;\n");
/*     */ 
/* 293 */       sb.append("if(e instanceof RuntimeException){\n throw e ;\n} else {\n throw new RuntimeException(e);\n};\n");
/*     */     }
/* 295 */     sb.append("}");
/*     */ 
/* 301 */     sb.append("}\n");
/* 302 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static Class loadClass(String name) throws ClassNotFoundException {
/* 306 */     Class result = null;
/*     */     try {
/* 308 */       result = Thread.currentThread().getContextClassLoader().loadClass(name);
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/* 313 */     if (result == null) {
/* 314 */       result = Class.forName(name);
/*     */     }
/* 316 */     return result;
/*     */   }
/*     */ 
/*     */   public static String getClassPath() {
/* 320 */     if (CLASS_PATH != null) {
/* 321 */       return CLASS_PATH;
/*     */     }
/* 323 */     StringBuilder sb = new StringBuilder();
/* 324 */     ClassLoader parent = ClassLoaderUtil.class.getClassLoader();
/* 325 */     List tmpClassLoader = new ArrayList();
/* 326 */     List urls = new ArrayList();
/*     */ 
/* 328 */     while (parent != null) {
/* 329 */       if (tmpClassLoader.contains(parent)) {
/*     */         break;
/*     */       }
/* 332 */       if (parent instanceof URLClassLoader) {
/* 333 */         if (log.isDebugEnabled()) {
/* 334 */           log.debug("ClassLoader:" + parent.getClass().getName());
/*     */         }
/* 336 */         URLClassLoader uL = (URLClassLoader)parent;
/* 337 */         URL[] path = uL.getURLs();
/* 338 */         if (path != null) {
/* 339 */           for (int i = 0; i < path.length; ++i) {
/* 340 */             sb.append(File.pathSeparator).append(path[i].getPath());
/* 341 */             urls.add(path[i].getFile());
/*     */ 
/* 343 */             if (log.isDebugEnabled()) {
/* 344 */               log.debug(path[i].getPath());
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 350 */       else if (log.isDebugEnabled())
/*     */       {
/* 352 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.handle_classloader_error", new String[] { parent.getClass().getName() }));
/*     */       }
/*     */ 
/* 356 */       tmpClassLoader.add(parent);
/* 357 */       parent = parent.getParent();
/*     */     }
/* 359 */     parent = Thread.currentThread().getContextClassLoader();
/* 360 */     while (parent != null) {
/* 361 */       if (tmpClassLoader.contains(parent)) {
/*     */         break;
/*     */       }
/* 364 */       if (parent instanceof URLClassLoader) {
/* 365 */         if (log.isDebugEnabled()) {
/* 366 */           log.debug("ClassLoader:" + parent.getClass().getName());
/*     */         }
/*     */ 
/* 369 */         URLClassLoader uL = (URLClassLoader)parent;
/* 370 */         URL[] path = uL.getURLs();
/* 371 */         if (path != null) {
/* 372 */           for (int i = 0; i < path.length; ++i) {
/* 373 */             sb.append(File.pathSeparator).append(path[i].getPath());
/* 374 */             urls.add(path[i].getFile());
/*     */ 
/* 376 */             if (log.isDebugEnabled()) {
/* 377 */               log.debug(path[i].getPath());
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 383 */       else if (log.isDebugEnabled())
/*     */       {
/* 385 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.handle_classloader_error", new String[] { parent.getClass().getName() }));
/*     */       }
/*     */ 
/* 388 */       tmpClassLoader.add(parent);
/* 389 */       parent = parent.getParent();
/*     */     }
/* 391 */     String path = Util.getResource(ClassLoaderUtil.class, "com/ai/appframe2/service/proxy/BaseProxyCreate.class").getPath();
/* 392 */     if (path.indexOf("jar") < 0) {
/* 393 */       path = Util.getResource(LogFactory.class, "org/apache/commons/logging/LogFactory.class").getPath();
/*     */     }
/* 395 */     path = path.replaceAll("%3A", ":");
/* 396 */     if (log.isDebugEnabled()) {
/* 397 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.path", new String[] { path }));
/*     */     }
/* 399 */     int index = path.indexOf("!");
/* 400 */     if (index > 0) {
/* 401 */       String tmp = path.substring(0, index);
/* 402 */       index = tmp.lastIndexOf("/");
/* 403 */       if (index == -1) {
/* 404 */         index = tmp.lastIndexOf(File.separator);
/*     */       }
/* 406 */       tmp = tmp.substring(0, index);
/* 407 */       if (!urls.contains(tmp)) {
/*     */         try {
/* 409 */           String[] files = com.ai.appframe2.util.FileUtils.getFileArray(tmp, new String[] { "jar" }, true);
/*     */ 
/* 411 */           for (int i = 0; i < files.length; ++i) {
/* 412 */             sb.append(File.pathSeparator).append(files[i]);
/* 413 */             log.debug(files[i]);
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 417 */           log.error(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/* 421 */     path = Util.getResource(ClassLoaderUtil.class, "AIConfig.xml").getPath();
/* 422 */     path = path.replaceAll("%3A", ":");
/* 423 */     if (log.isDebugEnabled()) {
/* 424 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.path", new String[] { path }));
/*     */     }
/* 426 */     index = path.indexOf("!");
/* 427 */     if (index > 0) {
/* 428 */       String tmp = path.substring(0, index);
/* 429 */       if (log.isDebugEnabled()) {
/* 430 */         log.debug(tmp);
/*     */       }
/*     */ 
/* 433 */       sb.append(File.pathSeparator).append(tmp);
/* 434 */       if (!tmp.endsWith("jar")) {
/* 435 */         tmp = tmp + File.separator + "WEB-INF" + File.separator + "classes";
/* 436 */         log.debug(tmp);
/* 437 */         sb.append(File.pathSeparator).append(tmp);
/*     */       }
/*     */     }
/*     */     else {
/* 441 */       index = path.indexOf("classes");
/* 442 */       if (index > 0) {
/* 443 */         String tmp = path.substring(0, index + 7);
/* 444 */         log.debug(tmp);
/* 445 */         sb.append(File.pathSeparator).append(tmp);
/*     */       }
/*     */     }
/* 448 */     CLASS_PATH = sb.toString();
/* 449 */     return CLASS_PATH;
/*     */   }
/*     */ 
/*     */   public static void writeJavaFile(String className, String javaCode) throws Exception
/*     */   {
/* 454 */     File dirFile = new File(System.getProperty("user.dir") + "/" + tmpDir);
/* 455 */     int index = className.lastIndexOf(".");
/* 456 */     if (index >= 0) {
/* 457 */       String packageName = className.substring(0, index);
/* 458 */       createDependDir(packageName);
/*     */     }
/*     */ 
/* 461 */     File file = new File(dirFile, className.replace('.', '/') + ".java");
/*     */ 
/* 463 */     PrintWriter out = null;
/*     */     try {
/* 465 */       out = new PrintWriter(new FileOutputStream(file));
/* 466 */       out.write(javaCode.toString());
/* 467 */       out.flush();
/*     */     }
/*     */     catch (Exception e) {
/* 470 */       log.error(e.getMessage(), e);
/*     */     }
/*     */     finally {
/* 473 */       if (out != null)
/* 474 */         out.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] complieJavaCode(String className, String javaCode) throws Exception
/*     */   {
/* 480 */     File dirFile = new File(System.getProperty("user.dir") + "/" + tmpDir);
/* 481 */     writeJavaFile(className, javaCode);
/* 482 */     StringBuilder sbClassPath = new StringBuilder();
/* 483 */     sbClassPath.append(getClassPath()).append(File.pathSeparatorChar).append(System.getProperty("user.dir")).append(File.separator).append(tmpDir);
/*     */ 
/* 487 */     String[] args = { "-classpath", sbClassPath.toString(), "-d", System.getProperty("user.dir") + "/" + tmpDir, tmpDir + "/" + className.replace('.', '/') + ".java" };
/*     */ 
/* 493 */     int status = Main.compile(args);
/*     */ 
/* 495 */     if (status != 0)
/*     */     {
/* 497 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.compile_error");
/* 498 */       throw new AIException(msg + className);
/*     */     }
/* 500 */     File classFile = new File(dirFile, className.replace('.', '/') + ".class");
/*     */ 
/* 502 */     if (log.isDebugEnabled()) {
/* 503 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.ClassLoaderUtil.gen_proxy_error", new String[] { className }));
/*     */     }
/* 505 */     return org.apache.commons.io.FileUtils.readFileToByteArray(classFile);
/*     */   }
/*     */ 
/*     */   public static void createDependDir(String packageName)
/*     */     throws Exception
/*     */   {
/* 511 */     File parentDir = new File(System.getProperty("user.dir") + "/" + tmpDir);
/*     */ 
/* 513 */     String[] list = StringUtils.split(packageName, '.');
/* 514 */     for (int i = 0; i < list.length; ++i) {
/* 515 */       parentDir = new File(parentDir, list[i]);
/* 516 */       if (!parentDir.exists())
/* 517 */         parentDir.mkdir();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void deleteTempDir() throws Exception
/*     */   {
/* 523 */     File parentDir = new File(System.getProperty("user.dir") + "/" + tmpDir);
/* 524 */     if (parentDir.exists() == true)
/* 525 */       org.apache.commons.io.FileUtils.forceDelete(parentDir);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       deleteTempDir();
/*  33 */       File parentDir = new File(System.getProperty("user.dir") + "/" + tmpDir);
/*  34 */       if (!parentDir.exists())
/*  35 */         parentDir.mkdir();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*  39 */       log.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ClassLoaderUtil
 * JD-Core Version:    0.5.4
 */