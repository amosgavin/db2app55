package com.ai.appframe2.common;

import java.util.HashMap;

public abstract interface Operator
{
  public abstract String getName();

  public abstract String getOperationType();

  public abstract String getCommandRemark();

  public abstract String[] getCommandArray();

  public abstract HashMap getParameterTypes();

  public abstract String getResultDataType();

  public abstract boolean isCollectionOfResult();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Operator
 * JD-Core Version:    0.5.4
 */