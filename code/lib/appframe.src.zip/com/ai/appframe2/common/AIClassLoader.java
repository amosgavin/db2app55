/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class AIClassLoader extends URLClassLoader
/*     */ {
/*  12 */   private static transient Log log = LogFactory.getLog(AIClassLoader.class);
/*  13 */   private static AIClassLoader m_instance = null;
/*     */   String[] enhancePackages;
/*  15 */   AIClassPool pool = null;
/*     */ 
/*     */   public static AIClassLoader getInstance() {
/*  18 */     if (m_instance == null) {
/*     */       try {
/*  20 */         synchronized (AIClassLoader.class) {
/*  21 */           if (m_instance == null) {
/*  22 */             URL url = new URL("file:///" + System.getProperty("user.dir") + "/" + ClassLoaderUtil.tmpDir + "/");
/*     */ 
/*  24 */             m_instance = new AIClassLoader(new URL[] { url }, AIClassLoader.class.getClassLoader());
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (MalformedURLException ex)
/*     */       {
/*  30 */         throw new RuntimeException(ex);
/*     */       }
/*     */     }
/*  33 */     return m_instance;
/*     */   }
/*     */   public static void clearCache() {
/*  36 */     m_instance = null;
/*     */   }
/*     */   public AIClassLoader(URL[] urls, ClassLoader parent) {
/*  39 */     super(urls, parent);
/*     */     try {
/*  41 */       String tmpStr = AIConfigManager.getConfigItem("ENHANCE_PACKAGE");
/*  42 */       if ((tmpStr != null) && (tmpStr.trim().length() > 0))
/*  43 */         this.enhancePackages = tmpStr.split(";");
/*     */     }
/*     */     catch (Exception ex) {
/*  46 */       if (ex instanceof RuntimeException) {
/*  47 */         throw ((RuntimeException)ex);
/*     */       }
/*  49 */       throw new RuntimeException(ex);
/*     */     }
/*  51 */     this.pool = new AIClassPool();
/*     */   }
/*     */ 
/*     */   public Class defineClassSelf(String name, byte[] b, int off, int len) {
/*  55 */     return defineClass(name, b, off, len);
/*     */   }
/*     */ 
/*     */   public synchronized Class loadClass(String name, boolean resolve) throws ClassNotFoundException
/*     */   {
/*  60 */     Class clasz = ClassLoaderUtil.findLoadedClass(this, name);
/*  61 */     if (clasz != null) {
/*  62 */       return clasz;
/*     */     }
/*     */ 
/*  65 */     if (needEnhance(name)) {
/*  66 */       byte[] classData = ClassLoaderUtil.enhanceClass(this.pool, name);
/*  67 */       if (classData != null) {
/*  68 */         clasz = defineClass(name, classData, 0, classData.length);
/*     */       }
/*     */     }
/*     */ 
/*  72 */     if (clasz == null) {
/*  73 */       clasz = ClassLoaderUtil.parentLoadClass(this, name);
/*     */     }
/*  75 */     if ((clasz == null) && (name.startsWith("["))) {
/*  76 */       int index = name.indexOf("L");
/*  77 */       String str = name.substring(0, index);
/*  78 */       String componentClassName = name.substring(index + 1, name.length() - 1);
/*  79 */       int[] dimes = new int[str.length()];
/*  80 */       for (int i = 0; i < dimes.length; ++i)
/*  81 */         dimes[i] = 0;
/*     */       try
/*     */       {
/*  84 */         Class componentType = loadClass(componentClassName);
/*  85 */         clasz = Array.newInstance(componentType, dimes).getClass();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/*     */     }
/*  91 */     if (clasz == null)
/*  92 */       throw new ClassNotFoundException(name);
/*  93 */     return clasz;
/*     */   }
/*     */   public boolean needEnhance(String name) {
/*  96 */     if (this.enhancePackages == null)
/*  97 */       return false;
/*  98 */     for (int i = 0; i < this.enhancePackages.length; ++i) {
/*  99 */       if (name.startsWith(this.enhancePackages[i])) {
/* 100 */         return true;
/*     */       }
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   public AIClassPool getAIClassPool() {
/* 107 */     return this.pool;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIClassLoader
 * JD-Core Version:    0.5.4
 */