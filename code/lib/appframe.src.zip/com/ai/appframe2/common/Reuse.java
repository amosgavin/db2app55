package com.ai.appframe2.common;

public abstract interface Reuse
{
  public abstract void free();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Reuse
 * JD-Core Version:    0.5.4
 */