package com.ai.appframe2.common;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;

public abstract interface DataContainerInterface extends DataStructInterface
{
  public abstract String getTypeName();

  public abstract String fetchTableName();

  public abstract void replaceTableName(String paramString);

  public abstract ObjectType getObjectType()
    throws AIException;

  public abstract void setObjectType(ObjectType paramObjectType)
    throws AIException;

  public abstract void initProperty(String paramString, Object paramObject);

  public abstract void initPropertyNoUpperCase(String paramString, Object paramObject);

  public abstract void initPropertyNoUpperCase(String paramString, Object paramObject1, Object paramObject2);

  public abstract void clearProperty(String paramString);

  public abstract void set(String paramString, Object paramObject);

  public abstract Object get(String paramString);

  public abstract Object getOldObj(String paramString);

  public abstract String getAsString(String paramString);

  public abstract int getAsInt(String paramString);

  public abstract short getAsShort(String paramString);

  public abstract long getAsLong(String paramString);

  public abstract double getAsDouble(String paramString);

  public abstract float getAsFloat(String paramString);

  public abstract byte getAsByte(String paramString);

  public abstract boolean getAsBoolean(String paramString);

  public abstract char getAsChar(String paramString);

  public abstract Date getAsDate(String paramString);

  public abstract Timestamp getAsDateTime(String paramString);

  public abstract boolean hasProperty(String paramString);

  public abstract boolean hasPropertyName(String paramString);

  public abstract HashMap getKeyProperties();

  public abstract HashMap getProperties();

  public abstract HashMap getNewProperties();

  public abstract HashMap getOldProperties();

  public abstract void unDelete();

  public abstract boolean isPropertyInitial(String paramString);

  public abstract boolean isPropertyModified(String paramString);

  public abstract DataContainerInterface cloneMe()
    throws AIException;

  public abstract void setDiaplayAttr(String paramString1, String paramString2, Object paramObject);

  public abstract void setOldDiaplayAttr(String paramString1, String paramString2, Object paramObject);

  public abstract Object getDispalyAttr(String paramString1, String paramString2);

  public abstract Object getOldDispalyAttr(String paramString1, String paramString2);

  public abstract String[] getPropertyNames();

  public abstract String[] getKeyPropertyNames();

  public abstract String getPropertyType(String paramString)
    throws AIException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataContainerInterface
 * JD-Core Version:    0.5.4
 */