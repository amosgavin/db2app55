package com.ai.appframe2.common;

import com.ai.appframe2.privilege.QueryCondition;

public abstract interface DBGFInterface
{
  public abstract String getSetname();

  public abstract String[] getBOAttrCols();

  public abstract QueryCondition getQueryCondition()
    throws Exception;

  public abstract String getImplservice_name();

  public abstract void setImplservice_name(String paramString);

  public abstract String getImplservice_querymethod();

  public abstract void setImplservice_querymethod(String paramString);

  public abstract String getImplservice_countmethod();

  public abstract void setImplservice_countmethod(String paramString);

  public abstract void setIsquerycount(String paramString);

  public abstract String getIsquerycount();

  public abstract void setPagesize(String paramString);

  public abstract int getPagesize();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBGFInterface
 * JD-Core Version:    0.5.4
 */