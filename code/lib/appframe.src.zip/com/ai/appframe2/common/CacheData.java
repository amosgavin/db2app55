/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class CacheData
/*    */   implements Serializable
/*    */ {
/*  5 */   private String key = null;
/*  6 */   private String type = null;
/*  7 */   private Object obj = null;
/*    */ 
/*  9 */   public CacheData(String type, String key, Object obj) { this.key = key;
/* 10 */     this.type = type;
/* 11 */     if (obj != null)
/* 12 */       this.obj = obj.toString();
/*    */     else
/* 14 */       this.obj = null; }
/*    */ 
/*    */   public String getKey()
/*    */   {
/* 18 */     return this.key;
/*    */   }
/*    */   public Object getObj() {
/* 21 */     return this.obj;
/*    */   }
/*    */   public String getType() {
/* 24 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 27 */     this.type = type;
/*    */   }
/*    */   public void setObj(Object obj) {
/* 30 */     this.obj = obj;
/*    */   }
/*    */   public void setKey(String key) {
/* 33 */     this.key = key;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.CacheData
 * JD-Core Version:    0.5.4
 */