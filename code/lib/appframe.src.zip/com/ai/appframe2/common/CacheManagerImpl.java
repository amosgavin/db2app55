/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;
/*     */ import com.ai.appframe2.jmx.AIMBeanBase;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CacheManagerImpl extends AIMBeanBase
/*     */   implements CacheManager, FrameCacheMBean
/*     */ {
/*  32 */   private static transient Log log = LogFactory.getLog(CacheManagerImpl.class);
/*     */ 
/*  34 */   final Map m_list = new ConcurrentHashMap();
/*     */ 
/*     */   public void put(String type, Object key, Object value)
/*     */   {
/*  39 */     Map tmpMap = (Map)this.m_list.get(type);
/*  40 */     if (tmpMap == null) {
/*  41 */       tmpMap = new ConcurrentHashMap();
/*  42 */       this.m_list.put(type, tmpMap);
/*     */     }
/*  44 */     tmpMap.put(key, value);
/*     */   }
/*     */   public Object get(String type, Object key) {
/*  47 */     Map tmpMap = (Map)this.m_list.get(type);
/*  48 */     if (tmpMap == null)
/*  49 */       return null;
/*  50 */     return tmpMap.get(key);
/*     */   }
/*     */   public synchronized Map getMap(String type) {
/*  53 */     Map tmpMap = (Map)this.m_list.get(type);
/*  54 */     if (tmpMap == null) {
/*  55 */       tmpMap = new ConcurrentHashMap();
/*  56 */       this.m_list.put(type, tmpMap);
/*     */     }
/*  58 */     return tmpMap;
/*     */   }
/*     */   public boolean containsKey(String type, Object key) {
/*  61 */     Map tmpMap = (Map)this.m_list.get(type);
/*  62 */     if (tmpMap == null)
/*  63 */       return false;
/*  64 */     return tmpMap.containsKey(key);
/*     */   }
/*     */   public void remove(String type, Object key) {
/*  67 */     Map tmpMap = (Map)this.m_list.get(type);
/*  68 */     if (tmpMap == null)
/*  69 */       return;
/*  70 */     tmpMap.remove(key);
/*     */   }
/*     */   public void remove(String type) {
/*  73 */     Map tmpMap = (Map)this.m_list.get(type);
/*  74 */     if (tmpMap == null)
/*  75 */       return;
/*  76 */     tmpMap.clear();
/*     */   }
/*     */   public String[] getTypes() {
/*  79 */     TreeMap map = new TreeMap();
/*  80 */     String[] ll = (String[])(String[])this.m_list.keySet().toArray(new String[0]);
/*  81 */     for (int i = 0; i < ll.length; ++i) {
/*  82 */       map.put(ll[i], null);
/*     */     }
/*  84 */     return (String[])(String[])map.keySet().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public String[] fetchTypes() {
/*  88 */     return getTypes();
/*     */   }
/*     */ 
/*     */   public String getCachestatus() {
/*  92 */     TreeMap map = new TreeMap();
/*  93 */     String[] ll = (String[])(String[])this.m_list.keySet().toArray(new String[0]);
/*  94 */     for (int i = 0; i < ll.length; ++i) {
/*  95 */       map.put(ll[i], null);
/*     */     }
/*  97 */     ll = (String[])(String[])map.keySet().toArray(new String[0]);
/*  98 */     StringBuilder buffer = new StringBuilder();
/*  99 */     for (int i = 0; i < ll.length; ++i) {
/* 100 */       if (i > 0) {
/* 101 */         buffer.append("\n");
/*     */       }
/* 103 */       buffer.append(ll[i]).append("[ total: " + ((Map)this.m_list.get(ll[i])).size() + " ]");
/*     */     }
/* 105 */     return buffer.toString();
/*     */   }
/*     */   public Object[] getKeys(String type) {
/* 108 */     Map tmpMap = (Map)this.m_list.get(type);
/* 109 */     if (tmpMap == null)
/* 110 */       return new Object[0];
/* 111 */     return tmpMap.keySet().toArray(); } 
/* 120 */   public List query(String type, String key) { List rtn = new ArrayList();
/*     */     boolean isTypeNull;
/*     */     boolean isKeyNull;
/*     */     Object value;
/*     */     Object item;
/*     */     Iterator iter;
/*     */     try { isTypeNull = StringUtils.isBlank(type);
/* 123 */       isKeyNull = StringUtils.isBlank(key);
/* 124 */       value = null;
/* 125 */       item = null;
/* 126 */       for (iter = this.m_list.keySet().iterator(); iter.hasNext(); ) {
/* 127 */         s_type = (String)iter.next();
/* 128 */         if ((isTypeNull) || (s_type.toLowerCase().indexOf(type.toLowerCase()) >= 0))
/*     */         {
/* 130 */           tmpMap = (Map)this.m_list.get(s_type);
/* 131 */           if (tmpMap != null)
/* 132 */             for (iter2 = tmpMap.keySet().iterator(); iter2.hasNext(); ) {
/* 133 */               item = iter2.next();
/* 134 */               if ((!isKeyNull) && (item.toString().toLowerCase().indexOf(key.toLowerCase()) < 0)) {
/*     */                 continue;
/*     */               }
/* 137 */               value = tmpMap.get(item);
/* 138 */               if (value == null) {
/* 139 */                 rtn.add(new CacheData(s_type, item.toString(), ""));
/*     */               }
/*     */ 
/* 142 */               rtn.add(new CacheData(s_type, item.toString(), value.toString()));
/*     */             }
/*     */         }
/*     */       } }
/*     */     catch (Throwable e)
/*     */     {
/*     */       String s_type;
/*     */       Map tmpMap;
/*     */       Iterator iter2;
/* 150 */       log.fatal(e.getMessage(), e);
/*     */     }
/* 152 */     return rtn; }
/*     */ 
/*     */ 
/*     */   protected void buildDynamicMBeanInfo()
/*     */   {
/* 159 */     String getCacheInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.cache_info");
/*     */ 
/* 161 */     String clearByType = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.clear_by_type");
/*     */ 
/* 163 */     String clearByKey = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.clear_by_key");
/*     */ 
/* 165 */     String cacheType = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.cache_type");
/*     */ 
/* 167 */     String cacheKey = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.cache_key");
/*     */ 
/* 169 */     String cacheManager = AppframeLocaleFactory.getResource("com.ai.appframe2.common.CacheManagerImpl.cache_management");
/*     */ 
/* 171 */     MBeanAttributeInfo[] dAttributes = { new MBeanAttributeInfo("cachestatus", "java.lang.String", getCacheInfo, true, false, false) };
/*     */ 
/* 174 */     MBeanOperationInfo[] dOperations = { new MBeanOperationInfo("remove", clearByType, new MBeanParameterInfo[] { new MBeanParameterInfo("type", "java.lang.String", cacheType) }, "void", 1), new MBeanOperationInfo("remove", clearByKey, new MBeanParameterInfo[] { new MBeanParameterInfo("type", "java.lang.String", cacheType), new MBeanParameterInfo("key", "java.lang.String", cacheKey) }, "void", 1) };
/*     */ 
/* 184 */     this.dMBeanInfo = new MBeanInfo(super.getClass().getName(), cacheManager, dAttributes, null, dOperations, null);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.CacheManagerImpl
 * JD-Core Version:    0.5.4
 */