/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.InetAddress;
/*     */ import java.net.URL;
/*     */ import java.sql.Date;
/*     */ import java.util.Random;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class JVM
/*     */   implements Serializable
/*     */ {
/*  13 */   private static transient Log log = LogFactory.getLog(JVM.class);
/*  14 */   private static transient JVM jvm = createJVM();
/*     */   public String version;
/*     */   public String vendor;
/*     */   public String ip;
/*     */   public String hostName;
/*     */   public String application;
/*     */   public String serverName;
/*     */   public String serverId;
/*     */   public String uuid;
/*     */   public String jmxHttpUrl;
/*     */   public String jmxRmiUrl;
/*     */   public Date createDate;
/*     */   public Date lastRefreshDate;
/*     */ 
/*     */   private static JVM createJVM()
/*     */   {
/*  31 */     JVM result = new JVM();
/*     */     try {
/*  33 */       result.version = System.getProperty("java.specification.version");
/*  34 */       result.vendor = System.getProperty("java.vm.vendor");
/*  35 */       result.serverName = System.getProperty("appframe.ServerName");
/*  36 */       result.ip = InetAddress.getLocalHost().getHostAddress();
/*  37 */       result.hostName = InetAddress.getLocalHost().getHostName();
/*  38 */       result.application = System.getProperty("appframe.Application", AIRootConfig.getInstance().getApplicationOfConfig());
/*     */ 
/*  40 */       result.createDate = new Date(System.currentTimeMillis());
/*  41 */       result.serverId = initialServerId(result);
/*  42 */       result.uuid = (result.ip + ":" + result.hostName + ":" + result.application + ":" + result.serverId);
/*     */     }
/*     */     catch (Throwable ex) {
/*  45 */       log.error(ex.getMessage(), ex);
/*     */     }
/*  47 */     return result;
/*     */   }
/*     */   public static JVM getEmptyJVM() {
/*  50 */     return new JVM();
/*     */   }
/*     */   public static JVM converStr2JVM(String uuid) {
/*  53 */     String[] list = uuid.split(":");
/*  54 */     JVM result = new JVM();
/*  55 */     result.ip = list[0];
/*  56 */     result.hostName = list[1];
/*  57 */     result.application = list[2];
/*  58 */     result.serverId = list[3];
/*  59 */     result.uuid = uuid;
/*  60 */     return result;
/*     */   }
/*     */   public String toString() {
/*  63 */     return "ip = " + this.ip + "\n" + "hostName = " + this.hostName + "\n" + "applicationType = " + this.application + "\n" + "serverId = " + this.serverId + "\n" + "uuid = " + this.uuid + "\n";
/*     */   }
/*     */ 
/*     */   public static JVM getJVMInstance()
/*     */   {
/*  70 */     return jvm;
/*     */   }
/*     */ 
/*     */   public static String getUUID() {
/*  74 */     return jvm.uuid;
/*     */   }
/*     */ 
/*     */   protected static String initialServerId(JVM aJvm) throws Exception {
/*  78 */     String result = "";
/*  79 */     String directorySeparator = File.separator;
/*  80 */     String tmpPath = Util.getResource(AIRootConfig.class, "com/ai/appframe2/common/AIRootConfig.class").getPath();
/*     */ 
/*  82 */     tmpPath = StringUtils.replace(tmpPath, "\\", directorySeparator);
/*  83 */     tmpPath = StringUtils.replace(tmpPath, "/", directorySeparator);
/*  84 */     String besTag = directorySeparator + "domains" + directorySeparator + "base" + directorySeparator + "configurations" + directorySeparator;
/*     */ 
/*  86 */     String weblogicTag = directorySeparator + "domains" + directorySeparator;
/*  87 */     int startIndex = -1;
/*  88 */     if ((startIndex = tmpPath.indexOf(besTag)) >= 0) {
/*  89 */       startIndex += besTag.length();
/*  90 */       int endIndex = tmpPath.indexOf(directorySeparator, startIndex);
/*  91 */       String configName = tmpPath.substring(startIndex, endIndex);
/*  92 */       String mos = directorySeparator + "mos" + directorySeparator;
/*  93 */       startIndex = tmpPath.indexOf(mos) + mos.length();
/*  94 */       endIndex = tmpPath.indexOf(directorySeparator, startIndex);
/*  95 */       String partionName = tmpPath.substring(startIndex, endIndex);
/*  96 */       result = configName + "-" + partionName;
/*     */     }
/*  98 */     else if ((startIndex = tmpPath.indexOf(weblogicTag)) >= 0) {
/*  99 */       startIndex += weblogicTag.length();
/* 100 */       int endIndex = tmpPath.indexOf(directorySeparator, startIndex);
/* 101 */       String domain = tmpPath.substring(startIndex, endIndex);
/* 102 */       String tmp = directorySeparator + domain + directorySeparator;
/* 103 */       startIndex = tmpPath.indexOf(tmp) + tmp.length();
/* 104 */       endIndex = tmpPath.indexOf(directorySeparator, startIndex);
/* 105 */       String serverName = tmpPath.substring(startIndex, endIndex);
/* 106 */       result = domain + "-" + serverName;
/*     */     }
/*     */ 
/* 112 */     if (aJvm.serverName != null);
/* 118 */     result = result + Math.abs(new Random(new Object().hashCode() ^ System.currentTimeMillis()).nextInt());
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 123 */     System.out.println(getUUID());
/* 124 */     System.out.println("-----------------------");
/* 125 */     System.out.println(converStr2JVM(getUUID()));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.JVM
 * JD-Core Version:    0.5.4
 */