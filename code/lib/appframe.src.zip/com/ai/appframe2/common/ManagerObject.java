package com.ai.appframe2.common;

public abstract interface ManagerObject
{
  public abstract Object get(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ManagerObject
 * JD-Core Version:    0.5.4
 */