package com.ai.appframe2.common;

import com.ai.appframe2.privilege.QueryCondition;
import com.ai.appframe2.privilege.UserInfoInterface;

public abstract interface Permission
{
  public abstract boolean isQueryOperator(String paramString)
    throws Exception;

  public abstract ManagerObjectType getManagerObject();

  public abstract boolean checkPermission(UserInfoInterface paramUserInfoInterface, String paramString, ManagerObject paramManagerObject)
    throws Exception;

  public abstract void checkPermissionByException(UserInfoInterface paramUserInfoInterface, String paramString, ManagerObject paramManagerObject)
    throws Exception;

  public abstract String[] getOperatorNames(UserInfoInterface paramUserInfoInterface, ManagerObject paramManagerObject)
    throws Exception;

  public abstract QueryCondition getQueryCondition(UserInfoInterface paramUserInfoInterface, String paramString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Permission
 * JD-Core Version:    0.5.4
 */