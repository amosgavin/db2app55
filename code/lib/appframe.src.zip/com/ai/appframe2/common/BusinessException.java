/*   */ package com.ai.appframe2.common;
/*   */ 
/*   */ public class BusinessException extends Exception
/*   */ {
/*   */   public BusinessException(String msg)
/*   */   {
/* 5 */     super(msg);
/*   */   }
/*   */   public BusinessException(String msg, Throwable e) {
/* 8 */     super(msg, e);
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.BusinessException
 * JD-Core Version:    0.5.4
 */