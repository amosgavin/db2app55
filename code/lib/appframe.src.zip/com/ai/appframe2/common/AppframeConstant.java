package com.ai.appframe2.common;

public class AppframeConstant
{
  public static final String OUT_JOIN_LEFT = "left";
  public static final String OUT_JOIN_RIGHT = "right";
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AppframeConstant
 * JD-Core Version:    0.5.4
 */