package com.ai.appframe2.common;

import java.util.HashMap;

public abstract interface ObjectType
{
  public static final String OBJECTTYPE_NULL = "ObjectTypeNull";
  public static final String OBJECTTYPE_SINGLE = "ObjectTypeSingleValue";

  public abstract String getFullName();

  public abstract String getName();

  public abstract String getMapingEnty()
    throws AIException;

  public abstract String getMapingEntyType();

  public abstract String getDataFilter();

  public abstract String getDataSource();

  public abstract String getClassName();

  public abstract String getMainAttr();

  public abstract boolean isKeyProperty(String paramString);

  public abstract HashMap getKeyProperties();

  public abstract String[] getPropertyNames();

  public abstract HashMap getProperties();

  public abstract boolean hasProperty(String paramString);

  public abstract Property getProperty(String paramString);

  public abstract HashMap getRelations();

  public abstract boolean hasRelation(String paramString);

  public abstract Relation getRelation(String paramString);

  public abstract HashMap getOperators();

  public abstract boolean hasOperator(String paramString);

  public abstract Operator getOperator(String paramString);

  public abstract String debug();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ObjectType
 * JD-Core Version:    0.5.4
 */