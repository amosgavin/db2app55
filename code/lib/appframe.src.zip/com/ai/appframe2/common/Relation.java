package com.ai.appframe2.common;

public abstract interface Relation
{
  public abstract String getName();

  public abstract String getJavaDataType();

  public abstract String getChildBOName();

  public abstract boolean isCollection();

  public abstract String getRelationCondition();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Relation
 * JD-Core Version:    0.5.4
 */