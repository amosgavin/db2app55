package com.ai.appframe2.common;

import com.ai.appframe2.transaction.dbdatasource.DataSourceInterface;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;

public abstract interface DataSourceManager
{
  public abstract DataSource getDataSource(String paramString)
    throws SQLException;

  public abstract boolean isSelf(String paramString)
    throws SQLException;

  public abstract void reset();

  public abstract String getDataSourceDBType(String paramString)
    throws SQLException;

  public abstract DataSourceInterface getDataSourceConfigInfo(String paramString)
    throws SQLException;

  public abstract List getDataSourceList();

  public abstract Connection getConnection(String paramString)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataSourceManager
 * JD-Core Version:    0.5.4
 */