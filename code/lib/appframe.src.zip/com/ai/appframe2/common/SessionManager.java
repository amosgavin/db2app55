/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ 
/*     */ public class SessionManager
/*     */ {
/*     */   public static ObjectTypeFactory getObjectTypeFactory()
/*     */   {
/*  26 */     return BaseSessionManager.getObjectTypeFactory();
/*     */   }
/*     */ 
/*     */   public static ListDataSourceFactory getListSrcFactory()
/*     */   {
/*  34 */     return BaseSessionManager.getListSrcFactory();
/*     */   }
/*     */ 
/*     */   public static GenFieldTypeSetFactory getSetFactory()
/*     */   {
/*  42 */     return BaseSessionManager.getSetFactory();
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface getUser()
/*     */   {
/*  53 */     return BaseSessionManager.getUser();
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface __getUserWithOutLog() {
/*  57 */     return BaseSessionManager.__getUserWithOutLog();
/*     */   }
/*     */ 
/*     */   public static void setUser(UserInfoInterface user)
/*     */   {
/*  66 */     BaseSessionManager.setUser(user);
/*     */   }
/*     */ 
/*     */   public static Locale getLocale() {
/*  70 */     return BaseSessionManager.getLocale();
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale) {
/*  74 */     BaseSessionManager.setLocale(locale);
/*     */   }
/*     */ 
/*     */   public static HttpServletRequest getRequest() {
/*  78 */     return BaseSessionManager.getRequest();
/*     */   }
/*     */ 
/*     */   public static void setRequest(HttpServletRequest request)
/*     */   {
/*  86 */     BaseSessionManager.setRequest(request);
/*     */   }
/*     */ 
/*     */   public static CacheManager getCacheManager()
/*     */   {
/*  91 */     return BaseSessionManager.getCacheManager();
/*     */   }
/*     */ 
/*     */   public static LogAction getLoginAction()
/*     */   {
/*  99 */     return BaseSessionManager.getLoginAction();
/*     */   }
/*     */ 
/*     */   public static void setContextName(String contextName) {
/* 103 */     BaseSessionManager.setContextName(contextName);
/*     */   }
/*     */ 
/*     */   public static String getContextName() {
/* 107 */     return BaseSessionManager.getContextName();
/*     */   }
/*     */ 
/*     */   public static LogAction getLogOutAction()
/*     */   {
/* 115 */     return BaseSessionManager.getLogOutAction();
/*     */   }
/*     */ 
/*     */   public static String getMainWebPageUrl() {
/* 119 */     return BaseSessionManager.getMainWebPageUrl();
/*     */   }
/*     */ 
/*     */   public static String getLoginOutWebPageUrl() {
/* 123 */     return BaseSessionManager.getLoginOutWebPageUrl();
/*     */   }
/*     */ 
/*     */   public static String getLoginInWebPageUrl() {
/* 127 */     return BaseSessionManager.getLoginInWebPageUrl();
/*     */   }
/*     */ 
/*     */   public static void setCurrentDomainId(long domain_id)
/*     */   {
/* 133 */     BaseSessionManager.setCurrentDomainId(domain_id);
/*     */   }
/*     */ 
/*     */   public static IMoSecurityService getSecurityFactory()
/*     */     throws Exception
/*     */   {
/* 139 */     return BaseSessionManager.getSecurityFactoryForWeb();
/*     */   }
/*     */ 
/*     */   public static RemoteDataStore getRemoteDataStore() {
/* 143 */     return BaseSessionManager.getRemoteDataStore();
/*     */   }
/*     */ 
/*     */   public static void setModuleName(String moduleName) {
/* 147 */     BaseSessionManager.setModuleName(moduleName, getUser());
/*     */   }
/*     */   public static String getModuleName() {
/* 150 */     return BaseSessionManager.getModuleName();
/*     */   }
/*     */   public static String getThreadLocals(Thread thread) throws Exception {
/* 153 */     return BaseSessionManager.getThreadLocals(thread);
/*     */   }
/*     */ 
/*     */   public static void clearThreadLocals(Thread thread) throws Exception {
/* 157 */     BaseSessionManager.clearThreadLocals(thread);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.SessionManager
 * JD-Core Version:    0.5.4
 */