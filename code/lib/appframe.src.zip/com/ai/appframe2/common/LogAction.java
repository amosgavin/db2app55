package com.ai.appframe2.common;

import com.ai.appframe2.privilege.UserInfoInterface;

public abstract interface LogAction
{
  public abstract void execute(UserInfoInterface paramUserInfoInterface)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.LogAction
 * JD-Core Version:    0.5.4
 */