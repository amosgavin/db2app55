package com.ai.appframe2.common;

import java.io.Writer;
import java.util.HashMap;

public abstract interface ListDataSourceFactory
{
  public abstract String getDynamicOutput(String paramString1, String paramString2, String paramString3, ListSourcePara[] paramArrayOfListSourcePara);

  public abstract String getDynamicOutput(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, ListSourcePara[] paramArrayOfListSourcePara);

  public abstract String getStaticOutput(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, boolean paramBoolean, String paramString4, String paramString5)
    throws Exception;

  public abstract void getStaticOutputOptions(Writer paramWriter, String paramString1, HashMap paramHashMap, boolean paramBoolean, String paramString2, String paramString3)
    throws Exception;

  public abstract String getStaticOutputByObj(String paramString1, String paramString2, String paramString3, Object paramObject, boolean paramBoolean, String paramString4, String paramString5)
    throws Exception;

  public abstract void getStaticOutputOptionsByObj(Writer paramWriter, String paramString1, Object paramObject, boolean paramBoolean, String paramString2, String paramString3)
    throws Exception;

  public abstract String getHTMLOutput(String paramString1, String paramString2, String paramString3, HashMap paramHashMap, boolean paramBoolean, String paramString4, String paramString5)
    throws Exception;

  public abstract String[] getUIDataSrcNames();

  public abstract ListDataSourceInterface getListDataSource(String paramString);

  public abstract Object getDataSourceObject(String paramString, HashMap paramHashMap)
    throws Exception;

  public abstract void removeCacheList();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ListDataSourceFactory
 * JD-Core Version:    0.5.4
 */