/*   */ package com.ai.appframe2.common;
/*   */ 
/*   */ import java.util.EventObject;
/*   */ 
/*   */ public class AIEventObject extends EventObject
/*   */ {
/*   */   public AIEventObject(Object source)
/*   */   {
/* 7 */     super(source);
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIEventObject
 * JD-Core Version:    0.5.4
 */