package com.ai.appframe2.common;

import java.io.Writer;
import javax.servlet.ServletRequest;

public abstract interface DBTreeInterface extends DBGFInterface
{
  public static final String TRUE_STR = "TRUE";
  public static final String FALSE_STR = "FALSE";
  public static final String DEFAULT_DATAMODEL = "com.ai.appframe2.web.tag.DefaultDataModel";

  public abstract String getTreeid();

  public abstract String getDatamodel();

  public abstract void refresh(Writer paramWriter, ServletRequest paramServletRequest)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DBTreeInterface
 * JD-Core Version:    0.5.4
 */