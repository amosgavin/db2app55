package com.ai.appframe2.common;

public abstract interface ObjectTypeFactory
{
  public abstract ObjectType getInstance()
    throws AIException;

  public abstract ObjectType getInstance(String paramString)
    throws AIException;

  public abstract String[] getObjectTypeNames();

  public abstract DataContainerInterface[] createDCArray(Class paramClass, int paramInt)
    throws AIException;

  public abstract DataContainerInterface createDCInstance(Class paramClass, ObjectType paramObjectType)
    throws AIException;

  public abstract void copy(DataContainerInterface paramDataContainerInterface1, DataContainerInterface paramDataContainerInterface2)
    throws AIException;

  public abstract Class getDefaultDCClass();

  public abstract ObjectType getObjectTypeByClass(Class paramClass)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ObjectTypeFactory
 * JD-Core Version:    0.5.4
 */