/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.privilege.UserManager;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ServiceManager
/*     */ {
/*  14 */   private static transient Log log = LogFactory.getLog(ServiceManager.class);
/*  15 */   private static String DONE_CODE_TABLE_NAME = "DONE_CODE";
/*  16 */   private static ThreadLocal s_doneCode = new ThreadLocal();
/*  17 */   private static ThreadLocal s_doneDate = new ThreadLocal();
/*  18 */   private static ThreadLocal s_domainId = new ThreadLocal();
/*     */ 
/*     */   public static ObjectTypeFactory getObjectTypeFactory()
/*     */   {
/*  25 */     return BaseSessionManager.getObjectTypeFactory();
/*     */   }
/*     */ 
/*     */   public static String getUserManagerImplClass() {
/*  29 */     return BaseSessionManager.getUserManagerImplClass();
/*     */   }
/*     */ 
/*     */   public static DataStore getDataStore()
/*     */   {
/*  38 */     return BaseSessionManager.getDataStore();
/*     */   }
/*     */ 
/*     */   public static Session getSession()
/*     */   {
/*  49 */     return BaseSessionManager.getSession();
/*     */   }
/*     */ 
/*     */   public static void setSession(Session session)
/*     */   {
/*  58 */     BaseSessionManager.setSession(session);
/*     */   }
/*     */ 
/*     */   public static Session getSession(String defaultDataSource)
/*     */   {
/*  69 */     return BaseSessionManager.getSession(defaultDataSource);
/*     */   }
/*     */ 
/*     */   public static CacheManager getCacheManager() {
/*  73 */     return BaseSessionManager.getCacheManager();
/*     */   }
/*     */ 
/*     */   public static void setServiceUserInfo(UserInfoInterface userinfo) {
/*  77 */     BaseSessionManager.setUser(userinfo);
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface getUser() {
/*  81 */     return BaseSessionManager.getUser();
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface __getUserWithOutLog() {
/*  85 */     return BaseSessionManager.__getUserWithOutLog();
/*     */   }
/*     */ 
/*     */   public static Locale getLocale() {
/*  89 */     return BaseSessionManager.getLocale();
/*     */   }
/*     */ 
/*     */   public static void setLocale(Locale locale) {
/*  93 */     BaseSessionManager.setLocale(locale);
/*     */   }
/*     */ 
/*     */   public static IMoSecurityService getSecurityFactory() throws Exception
/*     */   {
/*  98 */     return BaseSessionManager.getSecurityFactoryForServer();
/*     */   }
/*     */ 
/*     */   public static IdGenerator getIdGenerator()
/*     */   {
/* 106 */     return BaseSessionManager.getIdGenerator();
/*     */   }
/*     */ 
/*     */   public static long getDoneCode()
/*     */   {
/* 112 */     Long done_code = (Long)s_doneCode.get();
/* 113 */     if (done_code == null) {
/*     */       try
/*     */       {
/* 116 */         done_code = new Long(getIdGenerator().getNewId(DONE_CODE_TABLE_NAME).longValue());
/*     */ 
/* 118 */         s_doneCode.set(done_code);
/*     */       }
/*     */       catch (Exception ex) {
/* 121 */         if (ex instanceof RuntimeException) throw ((RuntimeException)ex);
/* 122 */         throw new RuntimeException(ex);
/*     */       }
/*     */     }
/* 125 */     return done_code.longValue();
/*     */   }
/*     */ 
/*     */   public static void setDoneCode(Long aDoneCode) {
/* 129 */     s_doneCode.set(aDoneCode);
/*     */   }
/*     */ 
/*     */   public static long getDoneCodeNotInSession()
/*     */   {
/* 134 */     long result = -1L;
/*     */     try {
/* 136 */       result = getIdGenerator().getNewId(DONE_CODE_TABLE_NAME).longValue();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 140 */       if (ex instanceof RuntimeException) throw ((RuntimeException)ex);
/* 141 */       throw new RuntimeException(ex);
/*     */     }
/* 143 */     return result;
/*     */   }
/*     */ 
/*     */   public static void clearDoneCode()
/*     */   {
/* 150 */     s_doneCode.set(null);
/*     */   }
/*     */ 
/*     */   public static boolean hasDoneCode() {
/* 154 */     return s_doneCode.get() != null;
/*     */   }
/*     */ 
/*     */   public static Timestamp getOpDateTime() throws Exception
/*     */   {
/* 159 */     Timestamp done_date = (Timestamp)s_doneDate.get();
/* 160 */     if (done_date == null) {
/* 161 */       done_date = getIdGenerator().getSysDate();
/* 162 */       s_doneDate.set(done_date);
/*     */     }
/* 164 */     return done_date;
/*     */   }
/*     */ 
/*     */   public static void setOpDateTime(Timestamp aDoneDate) throws Exception {
/* 168 */     s_doneDate.set(aDoneDate);
/*     */   }
/*     */ 
/*     */   public static boolean hasOpDateTime() {
/* 172 */     return s_doneDate.get() != null;
/*     */   }
/*     */ 
/*     */   public static void clearOpDateTime() {
/* 176 */     s_doneDate.set(null);
/*     */   }
/*     */ 
/*     */   public static void setModuleName(String moduleName) {
/* 180 */     BaseSessionManager.setModuleName(moduleName, getUser());
/*     */   }
/*     */ 
/*     */   public static String getModuleName() {
/* 184 */     return BaseSessionManager.getModuleName();
/*     */   }
/*     */ 
/*     */   public static long getCurrentDomainId()
/*     */   {
/* 189 */     Long domainId = (Long)s_domainId.get();
/* 190 */     if (domainId == null) {
/* 191 */       return 11L;
/*     */     }
/*     */ 
/* 194 */     return domainId.longValue();
/*     */   }
/*     */ 
/*     */   public static String getThreadLocals(Thread thread) throws Exception
/*     */   {
/* 199 */     return BaseSessionManager.getThreadLocals(thread);
/*     */   }
/*     */ 
/*     */   public static void clearThreadLocals(Thread thread) throws Exception {
/* 203 */     BaseSessionManager.clearThreadLocals(thread);
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface getNewBlankUserInfo()
/*     */     throws Exception
/*     */   {
/* 212 */     String className = getUserManagerImplClass();
/* 213 */     UserManager objUserManager = (UserManager)Class.forName(className).newInstance();
/* 214 */     return objUserManager.getBlankUserInfo();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.ServiceManager
 * JD-Core Version:    0.5.4
 */