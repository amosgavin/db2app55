package com.ai.appframe2.common;

public abstract interface SessionCashe
{
  public abstract long add(String paramString, Object paramObject);

  public abstract long add(String paramString1, String paramString2, Object paramObject);

  public abstract void clear(String paramString);

  public abstract Object find(Object paramObject);

  public abstract void setMaxNumber(int paramInt);

  public abstract void remove(String paramString, long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.SessionCashe
 * JD-Core Version:    0.5.4
 */