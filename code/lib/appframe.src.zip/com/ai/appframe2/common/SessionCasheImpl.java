/*     */ package com.ai.appframe2.common;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SessionCasheImpl
/*     */   implements SessionCashe, Serializable
/*     */ {
/*  11 */   private static transient Log log = LogFactory.getLog(SessionCasheImpl.class);
/*     */   private String m_name;
/*  13 */   private PrivateKey m_pk_seq = new PrivateKey();
/*  14 */   private HashMap m_sessionsNoCachId = new HashMap();
/*  15 */   private HashMap m_sessionsCache = new HashMap();
/*  16 */   private Map m_list = Collections.synchronizedMap(new HashMap());
/*  17 */   private long m_maxNum = 20L;
/*  18 */   private static HashMap maxNumHash = null;
/*     */ 
/*     */   public SessionCasheImpl(String name) {
/*  21 */     if (maxNumHash == null) {
/*     */       try {
/*  23 */         maxNumHash = AIConfigManager.getConfigItemsByKind("TAG_SESSION_CASHE_NUM");
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*  27 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.common.SessionCasheImpl.get_cache_num_error"), ex);
/*     */       }
/*     */     }
/*  30 */     this.m_name = name;
/*  31 */     if (!maxNumHash.containsKey(name))
/*     */       return;
/*  33 */     String maxNumStr = (String)maxNumHash.get(name);
/*  34 */     if (StringUtils.isBlank(maxNumStr)) return;
/*     */     try {
/*  36 */       this.m_maxNum = Integer.parseInt(maxNumStr);
/*     */     }
/*     */     catch (Exception ex1)
/*     */     {
/*  40 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.DAO_double_define", new String[] { name }), ex1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  50 */     return this.m_name;
/*     */   }
/*     */   public long add(String sessionId, Object obj) {
/*  53 */     Long pk = this.m_pk_seq.getNewKey();
/*  54 */     ArrayList arrays = null;
/*  55 */     synchronized (this.m_sessionsNoCachId) {
/*  56 */       arrays = (ArrayList)this.m_sessionsNoCachId.get(sessionId);
/*  57 */       if (arrays == null) {
/*  58 */         arrays = new ArrayList();
/*  59 */         this.m_sessionsNoCachId.put(sessionId, arrays);
/*     */       }
/*     */     }
/*  62 */     Long removePK = null;
/*  63 */     synchronized (arrays) {
/*  64 */       if (arrays.size() >= this.m_maxNum - 1L) {
/*  65 */         removePK = (Long)arrays.remove(0);
/*     */       }
/*  67 */       arrays.add(pk);
/*     */     }
/*  69 */     this.m_list.put(pk, obj);
/*  70 */     if (removePK != null) {
/*  71 */       this.m_list.remove(removePK);
/*     */     }
/*  73 */     return pk.longValue();
/*     */   }
/*     */   public long add(String sessionId, String casheId, Object obj) {
/*  76 */     Long pk = this.m_pk_seq.getNewKey();
/*  77 */     HashMap arrays = null;
/*  78 */     synchronized (this.m_sessionsCache) {
/*  79 */       arrays = (HashMap)this.m_sessionsCache.get(sessionId);
/*  80 */       if (arrays == null) {
/*  81 */         arrays = new HashMap();
/*  82 */         this.m_sessionsCache.put(sessionId, arrays);
/*     */       }
/*     */     }
/*  85 */     Long removePK = null;
/*  86 */     synchronized (arrays) {
/*  87 */       removePK = (Long)arrays.remove(casheId);
/*  88 */       arrays.put(casheId, pk);
/*     */     }
/*  90 */     this.m_list.put(pk, obj);
/*  91 */     if (removePK != null) {
/*  92 */       this.m_list.remove(removePK);
/*     */     }
/*  94 */     return pk.longValue();
/*     */   }
/*     */ 
/*     */   public void remove(String sessionId, long pk)
/*     */   {
/*  99 */     Long pkObj = new Long(pk);
/* 100 */     ArrayList arrays = null;
/* 101 */     synchronized (this.m_sessionsNoCachId) {
/* 102 */       arrays = (ArrayList)this.m_sessionsNoCachId.get(sessionId);
/* 103 */       if (arrays == null) {
/* 104 */         return;
/*     */       }
/*     */     }
/* 107 */     boolean removeFlag = false;
/* 108 */     synchronized (arrays) {
/* 109 */       removeFlag = arrays.remove(pkObj);
/*     */     }
/* 111 */     if (removeFlag == true)
/* 112 */       this.m_list.remove(pkObj);
/*     */   }
/*     */ 
/*     */   public Object find(Object pk)
/*     */   {
/* 117 */     return this.m_list.get(pk);
/*     */   }
/*     */ 
/*     */   public void setMaxNumber(int value)
/*     */   {
/* 124 */     this.m_maxNum = value;
/*     */   }
/*     */ 
/*     */   public void clear(String sessionId)
/*     */   {
/* 131 */     if (log.isDebugEnabled()) {
/* 132 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.common.SessionCasheImpl.buffer_clear", new String[] { sessionId }));
/*     */     }
/* 134 */     ArrayList arrays = null;
/* 135 */     synchronized (this.m_sessionsNoCachId) {
/* 136 */       arrays = (ArrayList)this.m_sessionsNoCachId.remove(sessionId);
/*     */     }
/* 138 */     if (arrays != null) {
/* 139 */       Object obj = null;
/* 140 */       while (arrays.size() > 0) {
/* 141 */         obj = this.m_list.remove((Long)arrays.remove(0));
/*     */       }
/*     */     }
/*     */ 
/* 145 */     HashMap maps = null;
/* 146 */     synchronized (this.m_sessionsCache) {
/* 147 */       maps = (HashMap)this.m_sessionsCache.remove(sessionId);
/*     */     }
/* 149 */     if (maps != null) {
/* 150 */       for (Iterator it = maps.values().iterator(); it.hasNext(); ) {
/* 151 */         this.m_list.remove(it.next());
/*     */       }
/* 153 */       maps.clear();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.SessionCasheImpl
 * JD-Core Version:    0.5.4
 */