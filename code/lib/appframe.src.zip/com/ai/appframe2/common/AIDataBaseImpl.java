/*    */ package com.ai.appframe2.common;
/*    */ 
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ 
/*    */ public class AIDataBaseImpl
/*    */   implements AIDataBase
/*    */ {
/*    */   protected Object m_obj;
/*    */   protected transient PropertyUtils m_util;
/* 23 */   protected boolean m_needTransferName = true;
/*    */ 
/*    */   public AIDataBaseImpl(Object aObj) {
/* 26 */     this.m_obj = aObj;
/*    */   }
/*    */ 
/*    */   public AIDataBaseImpl(Object aObj, boolean needTransferName)
/*    */   {
/* 35 */     this.m_obj = aObj;
/* 36 */     this.m_needTransferName = needTransferName;
/*    */   }
/*    */ 
/*    */   public Object get(String name) {
/* 40 */     if ((name == null) || (name.trim().length() == 0)) {
/* 41 */       return null;
/*    */     }
/* 43 */     if (this.m_needTransferName)
/* 44 */       name = transferName(name);
/*    */     try {
/* 46 */       getPropertyUtils(); return PropertyUtils.getNestedProperty(this.m_obj, name);
/*    */     }
/*    */     catch (Exception ex) {
/* 49 */       if (ex instanceof RuntimeException) throw ((RuntimeException)ex); throw new RuntimeException(ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public Object getDispalyAttr(String fieldName, String attrName) {
/* 54 */     if ((attrName == null) || (attrName.trim().length() == 0)) {
/* 55 */       return null;
/*    */     }
/* 57 */     if (this.m_needTransferName)
/* 58 */       attrName = transferName(attrName);
/*    */     try
/*    */     {
/* 61 */       getPropertyUtils(); return PropertyUtils.getNestedProperty(this.m_obj, attrName);
/*    */     }
/*    */     catch (Exception ex) {
/* 64 */       if (ex instanceof RuntimeException) throw ((RuntimeException)ex); throw new RuntimeException(ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected static String transferName(String name)
/*    */   {
/* 70 */     StringBuilder result = new StringBuilder();
/* 71 */     String[] tmpArray = StringUtils.split(name, '_');
/* 72 */     if (tmpArray != null) {
/* 73 */       for (int i = 0; i < tmpArray.length; ++i)
/* 74 */         if (i == 0) {
/* 75 */           result.append(tmpArray[i].toLowerCase());
/*    */         }
/*    */         else {
/* 78 */           result.append(tmpArray[i].substring(0, 1).toUpperCase());
/* 79 */           result.append(tmpArray[i].substring(1).toLowerCase());
/*    */         }
/*    */     }
/* 82 */     return result.toString();
/*    */   }
/*    */ 
/*    */   protected PropertyUtils getPropertyUtils() {
/* 86 */     if (this.m_util == null)
/* 87 */       this.m_util = new PropertyUtils();
/* 88 */     return this.m_util;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.AIDataBaseImpl
 * JD-Core Version:    0.5.4
 */