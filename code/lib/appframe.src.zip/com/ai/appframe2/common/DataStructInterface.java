package com.ai.appframe2.common;

import java.io.Serializable;
import java.util.HashMap;

public abstract interface DataStructInterface extends AIDataBase, Serializable
{
  public abstract void initProperty(String paramString, Object paramObject)
    throws AIException;

  public abstract void set(String paramString, Object paramObject)
    throws AIException;

  public abstract Object get(String paramString);

  public abstract Object getOldObj(String paramString);

  public abstract boolean hasProperty(String paramString)
    throws AIException;

  public abstract HashMap getKeyProperties();

  public abstract HashMap getProperties();

  public abstract HashMap getNewProperties();

  public abstract HashMap getOldProperties();

  public abstract boolean isModified();

  public abstract boolean isDeleted();

  public abstract void setStsToNew();

  public abstract void setStsToOld();

  public abstract void copy(DataStructInterface paramDataStructInterface)
    throws AIException;

  public abstract boolean isPropertyInitial(String paramString)
    throws AIException;

  public abstract boolean isPropertyModified(String paramString)
    throws AIException;

  public abstract boolean isNew();

  public abstract String[] getPropertyNames();

  public abstract String[] getKeyPropertyNames();

  public abstract String getPropertyType(String paramString)
    throws AIException;

  public abstract void setDiaplayAttr(String paramString1, String paramString2, Object paramObject);

  public abstract Object getDispalyAttr(String paramString1, String paramString2);

  public abstract HashMap getDisplayAttrHashMap();

  public abstract HashMap getOldDisplayAttrHashMap();

  public abstract void clear();

  public abstract void delete();

  public abstract ObjectType getObjectType()
    throws AIException;

  public abstract void setExtAttr(String paramString, Object paramObject);

  public abstract Object getExtAttr(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.DataStructInterface
 * JD-Core Version:    0.5.4
 */