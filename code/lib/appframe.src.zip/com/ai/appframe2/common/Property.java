package com.ai.appframe2.common;

public abstract interface Property
{
  public abstract String getName();

  public abstract String getType();

  public abstract String getMapingColName();

  public abstract String getJavaDataType();

  public abstract String getDatabaseDataType();

  public abstract int getMaxLength();

  public abstract int getFloatLength();

  public abstract String getRemark();

  public abstract String getDefaultValue();

  public abstract boolean isCollection();

  public abstract String getRelationObjectTypeName();

  public abstract String getRelationCondition();

  public abstract String[] getDisplayColNames();

  public abstract String getRelationObjectTypeOutJoin();

  public abstract boolean hasAlias();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.common.Property
 * JD-Core Version:    0.5.4
 */