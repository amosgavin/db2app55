/*    */ package com.ai.appframe2.complex.exceptions;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.JVMID;
/*    */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*    */ 
/*    */ public class EJBCheckedException extends Exception
/*    */ {
/*    */   static final long serialVersionUID = -9182210000000000001L;
/* 18 */   private String serverName = null;
/* 19 */   private String jvmid = null;
/*    */ 
/*    */   public EJBCheckedException()
/*    */   {
/* 27 */     this.serverName = RuntimeServerUtil.getServerName();
/* 28 */     this.jvmid = JVMID.getLocalJVMID();
/*    */   }
/*    */ 
/*    */   public EJBCheckedException(String message)
/*    */   {
/* 40 */     super(message);
/* 41 */     this.serverName = RuntimeServerUtil.getServerName();
/* 42 */     this.jvmid = JVMID.getLocalJVMID();
/*    */   }
/*    */ 
/*    */   public EJBCheckedException(String message, Throwable cause)
/*    */   {
/* 60 */     super(message, cause);
/* 61 */     this.serverName = RuntimeServerUtil.getServerName();
/* 62 */     this.jvmid = JVMID.getLocalJVMID();
/*    */   }
/*    */ 
/*    */   public EJBCheckedException(Throwable cause)
/*    */   {
/* 80 */     super(cause);
/* 81 */     this.serverName = RuntimeServerUtil.getServerName();
/* 82 */     this.jvmid = JVMID.getLocalJVMID();
/*    */   }
/*    */ 
/*    */   public String getServerName()
/*    */   {
/* 90 */     return this.serverName;
/*    */   }
/*    */ 
/*    */   public String getJvmid()
/*    */   {
/* 98 */     return this.jvmid;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.exceptions.EJBCheckedException
 * JD-Core Version:    0.5.4
 */