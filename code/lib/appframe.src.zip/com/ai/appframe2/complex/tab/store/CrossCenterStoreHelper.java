/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceTemplate;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class CrossCenterStoreHelper
/*     */ {
/*  32 */   private static transient Log log = LogFactory.getLog(CrossCenterStoreHelper.class);
/*     */ 
/*  34 */   private static ICenterRegion CENTER_REGION_INSTANCE = null;
/*     */ 
/*  36 */   private static ThreadLocal TMP_REGIONID = new ThreadLocal();
/*     */ 
/*     */   public static DataContainerInterface[] getBeans(String destRegionId, Class clazz, ObjectType objObjectType, String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  88 */     DataContainerInterface[] rtn = null;
/*  89 */     Connection conn = null;
/*     */     try {
/*  91 */       if (isSameCenter(destRegionId, CenterFactory.getCenterInfo().getRegion())) {
/*  92 */         conn = ServiceManager.getSession().getConnection();
/*     */       }
/*     */       else {
/*  95 */         String newds = null;
/*  96 */         String template = DataSourceTemplate.getCurrentTemplate();
/*  97 */         if (StringUtils.contains(template, "{CENTER}")) {
/*  98 */           newds = StringUtils.replace(template, "{CENTER}", getCenterByRegionId(destRegionId));
/*     */         }
/* 100 */         conn = ServiceManager.getSession().getConnection(newds);
/*     */       }
/*     */ 
/* 104 */       parameter.put("REGION_ID", destRegionId);
/* 105 */       parameter.put("REGION_CODE", destRegionId);
/*     */ 
/* 107 */       rtn = ServiceManager.getDataStore().retrieve(conn, clazz, objObjectType, null, condition, parameter, -1, -1, false, false, null);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 113 */       if (conn != null) {
/* 114 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 118 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static DataContainerInterface[] getBeansFromSql(String destRegionId, Class clazz, ObjectType objObjectType, String sql, Map parameter)
/*     */     throws Exception
/*     */   {
/* 133 */     DataContainerInterface[] rtn = null;
/* 134 */     Connection conn = null;
/* 135 */     ResultSet rs = null;
/*     */     try {
/* 137 */       if (isSameCenter(destRegionId, CenterFactory.getCenterInfo().getRegion())) {
/* 138 */         conn = ServiceManager.getSession().getConnection();
/*     */       }
/*     */       else {
/* 141 */         String newds = null;
/* 142 */         String template = DataSourceTemplate.getCurrentTemplate();
/* 143 */         if (StringUtils.contains(template, "{CENTER}")) {
/* 144 */           newds = StringUtils.replace(template, "{CENTER}", getCenterByRegionId(destRegionId));
/*     */         }
/* 146 */         conn = ServiceManager.getSession().getConnection(newds);
/*     */       }
/*     */ 
/* 150 */       parameter.put("REGION_ID", destRegionId);
/* 151 */       parameter.put("REGION_CODE", destRegionId);
/*     */ 
/* 153 */       rs = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 154 */       rtn = ServiceManager.getDataStore().crateDtaContainerFromResultSet(clazz, objObjectType, rs, null, true);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 160 */       if (conn != null) {
/* 161 */         conn.close();
/*     */       }
/* 163 */       if (rs != null) {
/* 164 */         rs.close();
/*     */       }
/*     */     }
/*     */ 
/* 168 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId(String destRegionId, ObjectType objObjectType)
/*     */     throws Exception
/*     */   {
/* 179 */     return getNewId(destRegionId, objObjectType.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId(String destRegionId, String tableName)
/*     */     throws Exception
/*     */   {
/* 190 */     BigDecimal rtn = null;
/*     */ 
/* 192 */     Connection conn = null;
/*     */     try {
/* 194 */       if (isSameCenter(destRegionId, CenterFactory.getCenterInfo().getRegion())) {
/* 195 */         conn = ServiceManager.getSession().getConnection();
/*     */       }
/*     */       else {
/* 198 */         String newds = null;
/* 199 */         String template = DataSourceTemplate.getCurrentTemplate();
/* 200 */         if (StringUtils.contains(template, "{CENTER}")) {
/* 201 */           newds = StringUtils.replace(template, "{CENTER}", getCenterByRegionId(destRegionId));
/*     */         }
/* 203 */         conn = ServiceManager.getSession().getConnection(newds);
/*     */       }
/*     */ 
/* 207 */       rtn = ServiceManager.getIdGenerator().getDirectNewId(conn, tableName);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 213 */       if (conn != null) {
/* 214 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 218 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static void saveBatch(DataContainerInterface[] objDataContainerInterface)
/*     */     throws Exception
/*     */   {
/* 227 */     BatchSaveHelper.saveListBeansWithBatch(objDataContainerInterface);
/*     */   }
/*     */ 
/*     */   public static HashMap getCenterMapping(HashMap regionIdMap)
/*     */     throws Exception
/*     */   {
/* 237 */     HashMap rtn = new HashMap();
/*     */ 
/* 239 */     Set key = regionIdMap.keySet();
/* 240 */     for (Iterator iter = key.iterator(); iter.hasNext(); ) {
/* 241 */       String item = (String)iter.next();
/* 242 */       String cen1 = getCenterByRegionId(item);
/* 243 */       rtn.put(cen1, item);
/*     */     }
/* 245 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static HashMap getReserveCenterMapping(HashMap regionIdMap)
/*     */     throws Exception
/*     */   {
/* 255 */     HashMap rtn = new HashMap();
/*     */ 
/* 257 */     Set key = regionIdMap.keySet();
/* 258 */     for (Iterator iter = key.iterator(); iter.hasNext(); ) {
/* 259 */       String item = (String)iter.next();
/* 260 */       String cen1 = getCenterByRegionId(item);
/* 261 */       rtn.put(item, cen1);
/*     */     }
/* 263 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static boolean isSameCenter(String srcRegionId, String destRegionId)
/*     */     throws Exception
/*     */   {
/* 274 */     boolean rtn = false;
/* 275 */     if (srcRegionId.equalsIgnoreCase(destRegionId)) {
/* 276 */       rtn = true;
/*     */     }
/*     */     else
/*     */     {
/* 280 */       String cen1 = getCenterByRegionId(srcRegionId);
/* 281 */       String cen2 = getCenterByRegionId(destRegionId);
/* 282 */       if (cen1.equalsIgnoreCase(cen2)) {
/* 283 */         rtn = true;
/*     */       }
/*     */     }
/* 286 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static String getCenterByRegionId(String regionId)
/*     */     throws Exception
/*     */   {
/* 296 */     return CENTER_REGION_INSTANCE.getCenterByRegionId(regionId);
/*     */   }
/*     */ 
/*     */   public static void setTmpRegionId(String regionId)
/*     */     throws Exception
/*     */   {
/* 306 */     TMP_REGIONID.set(regionId);
/*     */   }
/*     */ 
/*     */   public static String getTmpRegionId()
/*     */     throws Exception
/*     */   {
/* 315 */     return (String)TMP_REGIONID.get();
/*     */   }
/*     */ 
/*     */   public static void clearTmpRegionId()
/*     */     throws Exception
/*     */   {
/* 323 */     TMP_REGIONID.set(null);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  40 */       String strCenterRegionImplClass = AIConfigManager.getConfigItem("CENTER_REGION_IMPL_CLASS");
/*  41 */       if (!StringUtils.isBlank(strCenterRegionImplClass)) {
/*     */         try {
/*  43 */           Object custObject = Class.forName(strCenterRegionImplClass.trim()).newInstance();
/*  44 */           if (custObject instanceof ICenterRegion) {
/*  45 */             CENTER_REGION_INSTANCE = (ICenterRegion)custObject;
/*     */           }
/*     */           else
/*  48 */             CENTER_REGION_INSTANCE = null;
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*  52 */           CENTER_REGION_INSTANCE = null;
/*  53 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.cross_center_store.impl_class_error"), ex);
/*     */         }
/*     */       }
/*     */       else
/*  57 */         CENTER_REGION_INSTANCE = new DefaultCenterRegionImpl();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  61 */       CENTER_REGION_INSTANCE = null;
/*  62 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.cross_center_store.impl_class_error"), ex);
/*     */     }
/*     */     finally {
/*  65 */       if (CENTER_REGION_INSTANCE != null) {
/*  66 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.cross_center_store.impl_class", new String[] { CENTER_REGION_INSTANCE.getClass().toString() }));
/*     */       }
/*     */       else
/*  69 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.cross_center_store.impl_class_not_config"));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.CrossCenterStoreHelper
 * JD-Core Version:    0.5.4
 */