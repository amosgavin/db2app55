/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.bo.DataContainerFactory;
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceTemplate;
/*     */ import com.ai.appframe2.complex.tab.split.SplitTableFactory;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class HisRecordHelper
/*     */ {
/*  39 */   private static transient Log log = LogFactory.getLog(HisRecordHelper.class);
/*     */ 
/*  42 */   private static String HIS_TABLE_PK = "H_ID";
/*     */ 
/*  44 */   private static String DONE_CODE = "DONE_CODE";
/*  45 */   private static String CREATE_DATE = "CREATE_DATE";
/*  46 */   private static String VALID_DATE = "VALID_DATE";
/*  47 */   private static String DONE_DATE = "DONE_DATE";
/*  48 */   private static String EXPIRE_DATE = "EXPIRE_DATE";
/*  49 */   private static String OP_ID = "OP_ID";
/*  50 */   private static String ORG_ID = "ORG_ID";
/*     */ 
/*  53 */   private static String STATE = "STATE";
/*     */ 
/*  56 */   private static Timestamp MAX_EXPIRE_DATE = Timestamp.valueOf("2099-12-31 23:59:59");
/*     */ 
/*  59 */   private static Map HIS_COLUMNS_MAP = new HashMap();
/*     */ 
/*     */   public static Timestamp getMaxExpireDate()
/*     */   {
/* 167 */     return MAX_EXPIRE_DATE;
/*     */   }
/*     */ 
/*     */   public static Map getHisColumns()
/*     */   {
/* 175 */     return HIS_COLUMNS_MAP;
/*     */   }
/*     */ 
/*     */   public static void recordHisForBatch(Connection conn, DataContainerInterface[] dc)
/*     */     throws Exception
/*     */   {
/* 185 */     if ((dc != null) && (dc.length != 0)) {
/* 186 */       String tab = StringUtils.replace(StringUtils.replace(dc[0].fetchTableName(), "{", ""), "}", "").trim();
/*     */ 
/* 189 */       boolean hisDataFlag = ServiceManager.getIdGenerator().getHisDataFlag(tab);
/* 190 */       boolean hisDoneCodeFlag = ServiceManager.getIdGenerator().getHisDoneCodeFlag(tab);
/* 191 */       if ((hisDataFlag) || (hisDoneCodeFlag))
/* 192 */         for (int i = 0; i < dc.length; ++i)
/* 193 */           if (dc[i].isNew()) {
/* 194 */             whenInsert(conn, dc[i], hisDataFlag, hisDoneCodeFlag);
/*     */           }
/* 196 */           else if (dc[i].isModified()) {
/* 197 */             whenUpdate(conn, dc[i], hisDataFlag, hisDoneCodeFlag);
/*     */           }
/* 199 */           else if (dc[i].isDeleted())
/* 200 */             whenDelete(conn, dc[i], hisDataFlag, hisDoneCodeFlag);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void recordHis(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/* 214 */     String tab = StringUtils.replace(StringUtils.replace(dc.fetchTableName(), "{", ""), "}", "").trim();
/*     */ 
/* 217 */     boolean hisDataFlag = ServiceManager.getIdGenerator().getHisDataFlag(tab);
/* 218 */     boolean hisDoneCodeFlag = ServiceManager.getIdGenerator().getHisDoneCodeFlag(tab);
/*     */ 
/* 220 */     if ((hisDataFlag) || (hisDoneCodeFlag))
/* 221 */       if (dc.isNew()) {
/* 222 */         whenInsert(conn, dc, hisDataFlag, hisDoneCodeFlag);
/*     */       }
/* 224 */       else if (dc.isModified()) {
/* 225 */         whenUpdate(conn, dc, hisDataFlag, hisDoneCodeFlag);
/*     */       }
/* 227 */       else if (dc.isDeleted())
/* 228 */         whenDelete(conn, dc, hisDataFlag, hisDoneCodeFlag);
/*     */   }
/*     */ 
/*     */   private static void whenInsert(Connection conn, DataContainerInterface dc, boolean hisDataFlag, boolean doneCodeFlag)
/*     */     throws Exception
/*     */   {
/* 242 */     if (!doneCodeFlag)
/*     */       return;
/* 244 */     dc.set(DONE_DATE, ServiceManager.getOpDateTime());
/*     */ 
/* 246 */     dc.set(DONE_CODE, new Long(ServiceManager.getDoneCode()));
/*     */ 
/* 248 */     if (dc.get(CREATE_DATE) == null) {
/* 249 */       dc.set(CREATE_DATE, ServiceManager.getOpDateTime());
/*     */     }
/* 251 */     if ((dc.hasPropertyName(VALID_DATE)) && (dc.get(VALID_DATE) == null)) {
/* 252 */       dc.set(VALID_DATE, ServiceManager.getOpDateTime());
/*     */     }
/* 254 */     if (dc.get(EXPIRE_DATE) == null) {
/* 255 */       dc.set(EXPIRE_DATE, MAX_EXPIRE_DATE);
/*     */     }
/* 257 */     if ((dc.get(OP_ID) == null) && (ServiceManager.getUser() != null)) {
/* 258 */       dc.set(OP_ID, new Long(ServiceManager.getUser().getID()));
/*     */     }
/* 260 */     if ((dc.get(ORG_ID) == null) && (ServiceManager.getUser() != null))
/* 261 */       dc.set(ORG_ID, new Long(ServiceManager.getUser().getOrgId()));
/*     */   }
/*     */ 
/*     */   private static void whenUpdate(Connection conn, DataContainerInterface dc, boolean hisDataFlag, boolean doneCodeFlag)
/*     */     throws Exception
/*     */   {
/* 276 */     if (hisDataFlag)
/*     */     {
/* 278 */       DataContainerInterface his = cloneOld(dc);
/* 279 */       String curTableName = StringUtils.replace(StringUtils.replace(dc.fetchTableName(), "{", ""), "}", "").trim();
/*     */ 
/* 281 */       String hisTableName = ServiceManager.getIdGenerator().getHisTableName(curTableName).trim();
/* 282 */       if (StringUtils.isBlank(hisTableName))
/*     */       {
/* 284 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_his_tbname", new String[] { dc.fetchTableName() }));
/*     */       }
/* 286 */       if (his.fetchTableName().equalsIgnoreCase(hisTableName))
/*     */       {
/* 288 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.same_tbname_error", new String[] { dc.fetchTableName(), hisTableName }));
/*     */       }
/*     */ 
/* 293 */       if (doneCodeFlag)
/*     */       {
/* 295 */         his.set(DONE_DATE, ServiceManager.getOpDateTime());
/* 296 */         if (his.get(EXPIRE_DATE) == null) {
/* 297 */           his.set(EXPIRE_DATE, ServiceManager.getOpDateTime());
/*     */         }
/*     */       }
/*     */ 
/* 301 */       String realHisTableName = null;
/* 302 */       if (SplitTableFactory.isTableSplit(hisTableName)) {
/* 303 */         realHisTableName = SplitTableFactory.createTableName("{" + hisTableName + "}", his);
/*     */       }
/*     */       else {
/* 306 */         realHisTableName = hisTableName;
/*     */       }
/* 308 */       his.replaceTableName(realHisTableName);
/*     */ 
/* 310 */       his.setStsToNew();
/* 311 */       insert(conn, his, ServiceManager.getIdGenerator().getHisTableNewId(curTableName).longValue());
/*     */     }
/*     */ 
/* 315 */     if (doneCodeFlag) {
/* 316 */       dc.set(DONE_CODE, new Long(ServiceManager.getDoneCode()));
/*     */ 
/* 318 */       dc.set(DONE_DATE, ServiceManager.getOpDateTime());
/*     */ 
/* 320 */       if ((dc.hasPropertyName(VALID_DATE)) && (dc.get(VALID_DATE) == null)) {
/* 321 */         dc.set(VALID_DATE, ServiceManager.getOpDateTime());
/*     */       }
/* 323 */       if (dc.get(EXPIRE_DATE) == null) {
/* 324 */         dc.set(EXPIRE_DATE, MAX_EXPIRE_DATE);
/*     */       }
/* 326 */       if ((dc.get(OP_ID) == null) && (ServiceManager.getUser() != null)) {
/* 327 */         dc.set(OP_ID, new Long(ServiceManager.getUser().getID()));
/*     */       }
/* 329 */       if ((dc.get(ORG_ID) == null) && (ServiceManager.getUser() != null))
/* 330 */         dc.set(ORG_ID, new Long(ServiceManager.getUser().getOrgId()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void whenDelete(Connection conn, DataContainerInterface dc, boolean hisDataFlag, boolean doneCodeFlag)
/*     */     throws Exception
/*     */   {
/* 345 */     if (!hisDataFlag) {
/*     */       return;
/*     */     }
/* 348 */     DataContainerInterface his1 = cloneOld(dc);
/* 349 */     String curTableName = StringUtils.replace(StringUtils.replace(dc.fetchTableName(), "{", ""), "}", "").trim();
/*     */ 
/* 351 */     String hisTableName = ServiceManager.getIdGenerator().getHisTableName(curTableName);
/* 352 */     if (StringUtils.isBlank(hisTableName))
/*     */     {
/* 354 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_his_tbname", new String[] { dc.fetchTableName() }));
/*     */     }
/* 356 */     if (his1.fetchTableName().equalsIgnoreCase(hisTableName))
/*     */     {
/* 358 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.same_tbname_error", new String[] { dc.fetchTableName(), hisTableName }));
/*     */     }
/*     */ 
/* 363 */     his1.set(DONE_DATE, ServiceManager.getOpDateTime());
/* 364 */     if ((doneCodeFlag) && 
/* 365 */       (his1.get(EXPIRE_DATE) == null)) {
/* 366 */       his1.set(EXPIRE_DATE, ServiceManager.getOpDateTime());
/*     */     }
/*     */ 
/* 370 */     String realHis1TableName = null;
/* 371 */     if (SplitTableFactory.isTableSplit(hisTableName)) {
/* 372 */       realHis1TableName = SplitTableFactory.createTableName("{" + hisTableName + "}", his1);
/*     */     }
/*     */     else {
/* 375 */       realHis1TableName = hisTableName;
/*     */     }
/* 377 */     his1.replaceTableName(realHis1TableName);
/*     */ 
/* 379 */     his1.setStsToNew();
/* 380 */     insert(conn, his1, ServiceManager.getIdGenerator().getHisTableNewId(curTableName).longValue());
/*     */   }
/*     */ 
/*     */   private static void insert(Connection conn, DataContainerInterface dc, long pk)
/*     */     throws Exception
/*     */   {
/* 395 */     boolean hasRegionColumn = false;
/* 396 */     if (dc.hasPropertyName("REGION_ID")) {
/* 397 */       hasRegionColumn = true;
/*     */     }
/*     */ 
/* 402 */     if (!hasRegionColumn) {
/* 403 */       __insert(conn, dc, pk);
/*     */     }
/*     */     else
/*     */     {
/* 407 */       String regionId = null;
/* 408 */       if (dc != null) {
/* 409 */         String tmpRegionId = dc.getAsString("REGION_ID");
/* 410 */         if (!StringUtils.isBlank(tmpRegionId)) {
/* 411 */           regionId = tmpRegionId;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 416 */       if ((!StringUtils.isBlank(regionId)) && (CenterFactory.isSetCenterInfo())) {
/* 417 */         if (CrossCenterStoreHelper.isSameCenter(CenterFactory.getCenterInfo().getRegion(), regionId))
/*     */         {
/* 419 */           __insert(conn, dc, pk);
/*     */         }
/*     */         else
/*     */         {
/* 423 */           String newds = null;
/* 424 */           Connection cenConnection = null;
/*     */           try {
/* 426 */             String center = CrossCenterStoreHelper.getCenterByRegionId(regionId);
/*     */ 
/* 429 */             String template = DataSourceTemplate.getCurrentTemplate();
/* 430 */             if (StringUtils.contains(template, "{CENTER}")) {
/* 431 */               newds = StringUtils.replace(template, "{CENTER}", center);
/*     */             }
/*     */             else
/*     */             {
/* 435 */               newds = DataSourceTemplate.getCurrentDataSource();
/*     */             }
/*     */ 
/* 438 */             if (StringUtils.isBlank(newds))
/*     */             {
/* 440 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_ds_error"));
/*     */             }
/*     */ 
/* 443 */             cenConnection = ServiceManager.getSession().getConnection(newds);
/* 444 */             __insert(cenConnection, dc, pk);
/*     */           }
/*     */           finally {
/* 447 */             if (cenConnection != null)
/* 448 */               cenConnection.close();
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 453 */         if (StringUtils.isBlank(regionId))
/*     */         {
/* 455 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_region_id"));
/*     */         }
/* 457 */         if (!CenterFactory.isSetCenterInfo())
/*     */         {
/* 459 */           __insert(conn, dc, pk);
/*     */         }
/*     */         else
/*     */         {
/* 463 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.op_histable_error"));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void __insert(Connection conn, DataContainerInterface dc, long pk)
/*     */     throws Exception
/*     */   {
/* 476 */     ArrayList plist = new ArrayList();
/* 477 */     ArrayList ptype = new ArrayList();
/*     */ 
/* 479 */     ArrayList col_list = new ArrayList();
/*     */ 
/* 481 */     StringBuilder sql = new StringBuilder();
/* 482 */     StringBuilder value = new StringBuilder();
/*     */ 
/* 485 */     String tableName = dc.fetchTableName();
/* 486 */     sql.append("insert into ").append(tableName).append("(");
/* 487 */     value.append("values(");
/*     */ 
/* 489 */     col_list.add(HIS_TABLE_PK);
/* 490 */     sql.append(HIS_TABLE_PK + ",");
/* 491 */     value.append("?,");
/* 492 */     ptype.add("Long");
/* 493 */     plist.add(new Long(pk));
/*     */ 
/* 495 */     boolean isfirst = true;
/*     */ 
/* 498 */     ObjectType type = dc.getObjectType();
/* 499 */     int intertCount = 0;
/* 500 */     for (Iterator it = dc.getProperties().entrySet().iterator(); it.hasNext(); ) {
/* 501 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/* 502 */       String key = (String)me.getKey();
/* 503 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*     */         continue;
/*     */       }
/*     */ 
/* 507 */       Object obj = me.getValue();
/*     */ 
/* 509 */       if (isfirst == true) {
/* 510 */         isfirst = false;
/*     */       } else {
/* 512 */         sql.append(",");
/* 513 */         value.append(",");
/*     */       }
/*     */ 
/* 516 */       String colName = type.getProperty(key).getMapingColName();
/* 517 */       col_list.add(colName);
/* 518 */       sql.append(colName);
/*     */ 
/* 520 */       if (obj == null) {
/* 521 */         value.append("null");
/*     */       }
/*     */       else {
/* 524 */         value.append("?");
/* 525 */         ptype.add(dc.getPropertyType(key));
/* 526 */         plist.add(obj);
/* 527 */         if (log.isDebugEnabled()) {
/* 528 */           log.debug(key + " = " + obj);
/*     */         }
/*     */       }
/* 531 */       intertCount += 1;
/*     */     }
/*     */ 
/* 534 */     if (intertCount == 0) {
/* 535 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.HisRecordHelper.insert_nodata_warn"));
/* 536 */       return;
/*     */     }
/*     */ 
/* 539 */     sql.append(")");
/* 540 */     value.append(")");
/* 541 */     String strSql = sql.toString() + value.toString();
/*     */ 
/* 543 */     if (log.isDebugEnabled()) {
/* 544 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.HisRecordHelper.history_table", new String[] { strSql }));
/*     */     }
/*     */ 
/* 547 */     PreparedStatement ptmt = null;
/* 548 */     long startTime = 0L;
/*     */     try {
/* 550 */       ptmt = conn.prepareStatement(strSql);
/* 551 */       for (int i = 0; i < plist.size(); ++i) {
/* 552 */         if (plist.get(i) instanceof String) {
/* 553 */           String content = (String)plist.get(i);
/* 554 */           if (content.length() > 2000) {
/* 555 */             ptmt.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */           }
/*     */           else
/*     */           {
/* 559 */             ptmt.setString(i + 1, content);
/*     */           }
/*     */         }
/*     */         else {
/* 563 */           DataType.setPrepareStatementParameter(ptmt, i + 1, (String)ptype.get(i), plist.get(i));
/*     */         }
/*     */       }
/* 566 */       startTime = System.currentTimeMillis();
/*     */ 
/* 568 */       ptmt.execute();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 572 */       throw ex;
/*     */     }
/*     */     finally {
/* 575 */       if (ptmt != null) {
/* 576 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/* 580 */     if (log.isDebugEnabled())
/* 581 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.HisRecordHelper.insert_info", new String[] { Thread.currentThread().getName(), String.valueOf(System.currentTimeMillis() - startTime) }));
/*     */   }
/*     */ 
/*     */   private static DataContainerInterface cloneOld(DataContainerInterface obj)
/*     */     throws Exception
/*     */   {
/* 593 */     if (obj == null) {
/* 594 */       return null;
/*     */     }
/*     */ 
/* 597 */     if (!obj instanceof DataContainer)
/*     */     {
/* 599 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.not_data_container"));
/*     */     }
/*     */ 
/* 603 */     DataContainerInterface dc = DataContainerFactory.createDataContainerInstance(((DataContainer)obj).getClass(), ((DataContainer)obj).getType());
/*     */ 
/* 605 */     String[] propertyNames = obj.getPropertyNames();
/* 606 */     for (int i = 0; i < propertyNames.length; ++i) {
/* 607 */       dc.set(propertyNames[i], obj.getOldObj(propertyNames[i]));
/*     */     }
/*     */ 
/* 610 */     return dc;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  62 */     boolean isModified = false;
/*     */     try {
/*  64 */       String his_table_pk = AIConfigManager.getConfigItem("AUTORECORD_HIS_TABLE_PK");
/*  65 */       if (!StringUtils.isBlank(his_table_pk)) {
/*  66 */         HIS_TABLE_PK = his_table_pk.trim().toUpperCase();
/*  67 */         isModified = true;
/*     */       }
/*     */ 
/*  70 */       String done_code = AIConfigManager.getConfigItem("AUTORECORD_DONE_CODE");
/*  71 */       if (!StringUtils.isBlank(done_code)) {
/*  72 */         DONE_CODE = done_code.trim().toUpperCase();
/*  73 */         isModified = true;
/*     */       }
/*     */ 
/*  76 */       String create_date = AIConfigManager.getConfigItem("AUTORECORD_CREATE_DATE");
/*  77 */       if (!StringUtils.isBlank(create_date)) {
/*  78 */         CREATE_DATE = create_date.trim().toUpperCase();
/*  79 */         isModified = true;
/*     */       }
/*     */ 
/*  82 */       String valid_date = AIConfigManager.getConfigItem("AUTORECORD_VALID_DATE");
/*  83 */       if (!StringUtils.isBlank(valid_date)) {
/*  84 */         VALID_DATE = valid_date.trim().toUpperCase();
/*  85 */         isModified = true;
/*     */       }
/*     */ 
/*  88 */       String done_date = AIConfigManager.getConfigItem("AUTORECORD_DONE_DATE");
/*  89 */       if (!StringUtils.isBlank(done_date)) {
/*  90 */         DONE_DATE = done_date.trim().toUpperCase();
/*  91 */         isModified = true;
/*     */       }
/*     */ 
/*  94 */       String expire_date = AIConfigManager.getConfigItem("AUTORECORD_EXPIRE_DATE");
/*  95 */       if (!StringUtils.isBlank(expire_date)) {
/*  96 */         EXPIRE_DATE = expire_date.trim().toUpperCase();
/*  97 */         isModified = true;
/*     */       }
/*     */ 
/* 100 */       String op_id = AIConfigManager.getConfigItem("AUTORECORD_OP_ID");
/* 101 */       if (!StringUtils.isBlank(op_id)) {
/* 102 */         OP_ID = op_id.trim().toUpperCase();
/* 103 */         isModified = true;
/*     */       }
/*     */ 
/* 106 */       String org_id = AIConfigManager.getConfigItem("AUTORECORD_ORG_ID");
/* 107 */       if (!StringUtils.isBlank(org_id)) {
/* 108 */         ORG_ID = org_id.trim().toUpperCase();
/* 109 */         isModified = true;
/*     */       }
/*     */ 
/* 112 */       String state = AIConfigManager.getConfigItem("AUTORECORD_STATE");
/* 113 */       if (!StringUtils.isBlank(state)) {
/* 114 */         STATE = state.trim().toUpperCase();
/* 115 */         isModified = true;
/*     */       }
/*     */ 
/* 118 */       String max_expire_date = AIConfigManager.getConfigItem("AUTORECORD_MAX_EXPIRE_DATE");
/* 119 */       if (!StringUtils.isBlank(max_expire_date)) {
/* 120 */         MAX_EXPIRE_DATE = Timestamp.valueOf(max_expire_date);
/* 121 */         isModified = true;
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 125 */       log.error("Init autorecord error,use default value", ex);
/* 126 */       HIS_TABLE_PK = "H_ID";
/* 127 */       DONE_CODE = "DONE_CODE";
/* 128 */       CREATE_DATE = "CREATE_DATE";
/* 129 */       VALID_DATE = "VALID_DATE";
/* 130 */       DONE_DATE = "DONE_DATE";
/* 131 */       EXPIRE_DATE = "EXPIRE_DATE";
/* 132 */       OP_ID = "OP_ID";
/* 133 */       ORG_ID = "ORG_ID";
/* 134 */       STATE = "STATE";
/* 135 */       MAX_EXPIRE_DATE = Timestamp.valueOf("2099-12-31 23:59:59");
/* 136 */       isModified = false;
/*     */     }
/*     */     finally {
/* 139 */       if (isModified) {
/* 140 */         log.error("HIS_TABLE_PK=" + HIS_TABLE_PK + ",DONE_CODE=" + DONE_CODE + ",CREATE_DATE=" + CREATE_DATE + ",VALID_DATE=" + VALID_DATE + ",DONE_DATE=" + DONE_DATE + ",EXPIRE_DATE=" + EXPIRE_DATE + ",OP_ID=" + OP_ID + ",ORG_ID=" + ORG_ID + ",STATE=" + STATE + ",MAX_EXPIRE_DATE=" + MAX_EXPIRE_DATE);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 147 */     HIS_COLUMNS_MAP.put(HIS_TABLE_PK, HIS_TABLE_PK);
/* 148 */     HIS_COLUMNS_MAP.put(DONE_CODE, DONE_CODE);
/* 149 */     HIS_COLUMNS_MAP.put(CREATE_DATE, CREATE_DATE);
/* 150 */     HIS_COLUMNS_MAP.put(VALID_DATE, VALID_DATE);
/* 151 */     HIS_COLUMNS_MAP.put(DONE_DATE, DONE_DATE);
/* 152 */     HIS_COLUMNS_MAP.put(EXPIRE_DATE, EXPIRE_DATE);
/* 153 */     HIS_COLUMNS_MAP.put(OP_ID, OP_ID);
/* 154 */     HIS_COLUMNS_MAP.put(ORG_ID, ORG_ID);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.HisRecordHelper
 * JD-Core Version:    0.5.4
 */