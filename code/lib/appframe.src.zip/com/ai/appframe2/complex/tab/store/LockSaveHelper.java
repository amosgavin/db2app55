/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.tab.split.SplitTableFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.StringReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class LockSaveHelper
/*     */ {
/*  33 */   private static transient Log log = LogFactory.getLog(LockSaveHelper.class);
/*     */ 
/*     */   public static void saveWithClause(DataContainerInterface[] dc, HashMap[] whereMap)
/*     */     throws Exception
/*     */   {
/*  45 */     if ((dc == null) || (whereMap == null))
/*     */     {
/*  48 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.null_parameter_error"));
/*     */     }
/*  50 */     if (dc.length != whereMap.length)
/*     */     {
/*  53 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.unequal_dc_size"));
/*     */     }
/*     */ 
/*  56 */     Connection conn = null;
/*     */     try {
/*  58 */       conn = ServiceManager.getSession().getConnection();
/*  59 */       for (int i = 0; i < dc.length; ++i)
/*  60 */         saveWithClause(conn, dc[i], whereMap[i]);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  64 */       throw ex;
/*     */     }
/*     */     finally {
/*  67 */       if (conn != null)
/*  68 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveWithClause(DataContainerInterface dc, HashMap whereMap)
/*     */     throws Exception
/*     */   {
/*  80 */     Connection conn = null;
/*     */     try {
/*  82 */       conn = ServiceManager.getSession().getConnection();
/*  83 */       saveWithClause(conn, dc, whereMap);
/*     */     }
/*     */     catch (Exception ex) {
/*  86 */       throw ex;
/*     */     }
/*     */     finally {
/*  89 */       if (conn != null)
/*  90 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveWithClause(Connection conn, DataContainerInterface dc, HashMap whereMap)
/*     */     throws Exception
/*     */   {
/* 103 */     String tableName = dc.fetchTableName();
/*     */ 
/* 106 */     HisRecordHelper.recordHis(conn, dc);
/*     */ 
/* 109 */     String newTableName = SplitTableFactory.createTableName(tableName, dc);
/* 110 */     dc.replaceTableName(newTableName);
/*     */ 
/* 112 */     if (dc.isModified()) {
/* 113 */       update(conn, dc, whereMap);
/*     */     }
/* 115 */     else if (dc.isDeleted()) {
/* 116 */       delete(conn, dc, whereMap);
/*     */     } else {
/* 118 */       if (!dc.isNew()) {
/*     */         return;
/*     */       }
/* 121 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.undo_lock_insert"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void update(Connection conn, DataContainerInterface dc, HashMap whereMap)
/*     */     throws Exception
/*     */   {
/* 133 */     ArrayList plist = new ArrayList();
/* 134 */     ArrayList ptype = new ArrayList();
/*     */ 
/* 137 */     StringBuilder sql_update = new StringBuilder();
/* 138 */     String tableName = dc.fetchTableName();
/*     */ 
/* 140 */     sql_update.append("update ").append(tableName).append(" set ");
/* 141 */     boolean isfirst = true;
/*     */ 
/* 144 */     int intertCount = 0;
/* 145 */     for (Iterator it = dc.getNewProperties().entrySet().iterator(); it.hasNext(); ) {
/* 146 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/* 147 */       String key = (String)me.getKey();
/* 148 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*     */         continue;
/*     */       }
/*     */ 
/* 152 */       Object obj = me.getValue();
/*     */ 
/* 154 */       if (isfirst == true) {
/* 155 */         isfirst = false;
/*     */       }
/*     */       else {
/* 158 */         sql_update.append(",");
/*     */       }
/*     */ 
/* 161 */       sql_update.append(key).append(" = ");
/* 162 */       if (obj == null) {
/* 163 */         sql_update.append("null");
/*     */       } else {
/* 165 */         sql_update.append("?");
/* 166 */         ptype.add(dc.getPropertyType(key));
/* 167 */         plist.add(obj);
/* 168 */         if (log.isDebugEnabled()) {
/* 169 */           log.debug(key + " = " + obj);
/*     */         }
/*     */       }
/*     */ 
/* 173 */       intertCount += 1;
/*     */     }
/* 175 */     if (intertCount == 0) {
/* 176 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.LockSaveHelper.update_nodata_warn"));
/* 177 */       return;
/*     */     }
/*     */ 
/* 181 */     isfirst = true;
/*     */ 
/* 183 */     StringBuilder where_sql = new StringBuilder(" where  ");
/*     */ 
/* 185 */     Map keys = dc.getKeyProperties();
/* 186 */     if (keys.size() == 0)
/*     */     {
/* 189 */       throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.undo_up_withoutkey"));
/*     */     }
/* 191 */     for (Iterator it = keys.keySet().iterator(); it.hasNext(); ) {
/* 192 */       String key = (String)it.next();
/* 193 */       Object obj = dc.getOldObj(key);
/* 194 */       if (isfirst == true)
/* 195 */         isfirst = false;
/*     */       else {
/* 197 */         where_sql.append(" and ");
/*     */       }
/* 199 */       where_sql.append(key).append(" = ");
/* 200 */       if (obj == null)
/*     */       {
/* 203 */         throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_key_error"));
/*     */       }
/*     */ 
/* 206 */       where_sql.append("?");
/* 207 */       ptype.add(dc.getPropertyType(key));
/* 208 */       plist.add(obj);
/*     */ 
/* 210 */       if (log.isDebugEnabled());
/* 211 */       log.debug(key + " = " + obj);
/*     */     }
/*     */     Iterator iter;
/* 215 */     if (whereMap != null) {
/* 216 */       Set whereSet = whereMap.keySet();
/* 217 */       for (iter = whereSet.iterator(); iter.hasNext(); ) {
/* 218 */         String whereKey = (String)iter.next();
/* 219 */         if (!dc.hasProperty(whereKey))
/*     */         {
/* 222 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.no_column", new String[] { dc.getObjectType().getMapingEnty(), whereKey }));
/*     */         }
/* 224 */         where_sql.append(" and ").append(whereKey).append(" = ? ");
/* 225 */         ptype.add(dc.getPropertyType(whereKey));
/* 226 */         plist.add(whereMap.get(whereKey));
/*     */ 
/* 228 */         if (log.isDebugEnabled()) {
/* 229 */           log.debug(whereKey + " = " + whereMap.get(whereKey));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 236 */     String strSql = where_sql;
/* 237 */     if (log.isDebugEnabled()) {
/* 238 */       log.debug(strSql);
/*     */     }
/* 240 */     long startTime = System.currentTimeMillis();
/* 241 */     PreparedStatement statement = null;
/*     */     try {
/* 243 */       statement = conn.prepareStatement(strSql);
/* 244 */       for (int i = 0; i < plist.size(); ++i) {
/* 245 */         if (plist.get(i) instanceof String) {
/* 246 */           String content = (String)plist.get(i);
/* 247 */           if (content.length() > 2000) {
/* 248 */             statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */           }
/*     */           else
/*     */           {
/* 252 */             statement.setString(i + 1, content);
/*     */           }
/*     */         }
/*     */         else {
/* 256 */           DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*     */         }
/*     */       }
/* 259 */       int count = statement.executeUpdate();
/* 260 */       if (count != 1)
/*     */       {
/* 263 */         throw new Exception("SQL:" + strSql + "," + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.up_datacount_error", new String[] { plist.toString() }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 267 */       throw ex;
/*     */     }
/*     */     finally {
/* 270 */       if (statement != null) {
/* 271 */         statement.close();
/*     */       }
/*     */     }
/*     */ 
/* 275 */     if (log.isDebugEnabled())
/* 276 */       log.debug("Thread " + Thread.currentThread().getName() + " update time :" + (System.currentTimeMillis() - startTime));
/*     */   }
/*     */ 
/*     */   private static void delete(Connection conn, DataContainerInterface dc, HashMap whereMap)
/*     */     throws Exception
/*     */   {
/* 291 */     ArrayList plist = new ArrayList();
/* 292 */     ArrayList ptype = new ArrayList();
/*     */ 
/* 294 */     StringBuilder where_sql = new StringBuilder(" where ");
/*     */ 
/* 296 */     String tableName = dc.fetchTableName();
/*     */ 
/* 298 */     String key = null;
/* 299 */     Object obj = null;
/* 300 */     boolean isfirst = true;
/* 301 */     Iterator it = dc.getObjectType().getKeyProperties().keySet().iterator();
/* 302 */     while (it.hasNext()) {
/* 303 */       key = (String)it.next();
/* 304 */       obj = dc.getOldObj(key);
/*     */ 
/* 306 */       if (isfirst == true)
/* 307 */         isfirst = false;
/*     */       else {
/* 309 */         where_sql.append(" and ");
/*     */       }
/* 311 */       where_sql.append(key).append(" = ");
/* 312 */       if (obj == null)
/*     */       {
/* 315 */         throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_key_error"));
/*     */       }
/*     */ 
/* 319 */       where_sql.append("?");
/* 320 */       ptype.add(dc.getPropertyType(key));
/* 321 */       plist.add(obj);
/* 322 */       if (log.isDebugEnabled());
/* 323 */       log.debug(key + " = " + obj);
/*     */     }
/*     */     Iterator iter;
/* 327 */     if (whereMap != null) {
/* 328 */       Set whereSet = whereMap.keySet();
/* 329 */       for (iter = whereSet.iterator(); iter.hasNext(); ) {
/* 330 */         String whereKey = (String)iter.next();
/* 331 */         if (!dc.hasProperty(whereKey))
/*     */         {
/* 334 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.no_column", new String[] { dc.getObjectType().getMapingEnty(), whereKey }));
/*     */         }
/* 336 */         where_sql.append(" and ").append(whereKey).append(" = ? ");
/* 337 */         ptype.add(dc.getPropertyType(whereKey));
/* 338 */         plist.add(whereMap.get(whereKey));
/*     */ 
/* 340 */         if (log.isDebugEnabled()) {
/* 341 */           log.debug(whereKey + " = " + whereMap.get(whereKey));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 348 */     String strDelete_Sql = where_sql.insert(0, tableName).insert(0, "delete from ").toString();
/*     */ 
/* 350 */     if (log.isDebugEnabled()) {
/* 351 */       log.debug(strDelete_Sql);
/*     */     }
/* 353 */     long startTime = System.currentTimeMillis();
/* 354 */     PreparedStatement statement = null;
/*     */     try {
/* 356 */       statement = conn.prepareStatement(strDelete_Sql);
/* 357 */       for (int i = 0; i < plist.size(); ++i) {
/* 358 */         if (plist.get(i) instanceof String) {
/* 359 */           String content = (String)plist.get(i);
/* 360 */           if (content.length() > 2000) {
/* 361 */             statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */           }
/*     */           else
/*     */           {
/* 365 */             statement.setString(i + 1, content);
/*     */           }
/*     */         }
/*     */         else {
/* 369 */           DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*     */         }
/*     */       }
/* 372 */       int count = statement.executeUpdate();
/* 373 */       if (count != 1)
/*     */       {
/* 377 */         throw new Exception("SQL:" + strDelete_Sql + "," + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.del_datacount_error", new String[] { plist.toString() }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 381 */       throw ex;
/*     */     }
/*     */     finally {
/* 384 */       if (statement != null) {
/* 385 */         statement.close();
/*     */       }
/*     */     }
/*     */ 
/* 389 */     if (log.isDebugEnabled())
/* 390 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.LockSaveHelper.delete_info", new String[] { Thread.currentThread().getName(), String.valueOf(System.currentTimeMillis() - startTime) }));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.LockSaveHelper
 * JD-Core Version:    0.5.4
 */