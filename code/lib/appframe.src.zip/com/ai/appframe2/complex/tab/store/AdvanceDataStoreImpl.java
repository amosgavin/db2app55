/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataStoreImpl;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceTemplate;
/*     */ import com.ai.appframe2.complex.tab.split.SplitTableFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class AdvanceDataStoreImpl extends DataStoreImpl
/*     */ {
/*     */   public void save(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  34 */     String tableName = dc.fetchTableName();
/*     */ 
/*  37 */     HisRecordHelper.recordHis(conn, dc);
/*     */ 
/*  40 */     String newTableName = SplitTableFactory.createTableName(tableName, dc);
/*  41 */     dc.replaceTableName(newTableName);
/*  42 */     super.save(conn, dc);
/*     */   }
/*     */ 
/*     */   protected ResultSet retrieveByResultLevel(Connection aConn, String strSql, Map aParameterList, int resultLevel)
/*     */     throws Exception
/*     */   {
/* 110 */     ResultSet rtn = null;
/* 111 */     if (CrossCenterStoreHelper.getTmpRegionId() == null) {
/* 112 */       rtn = super.retrieveByResultLevel(aConn, SplitTableFactory.createQuerySQL(strSql, aParameterList), aParameterList, resultLevel);
/*     */     }
/*     */     else
/*     */     {
/* 117 */       String tmpRegionId = CrossCenterStoreHelper.getTmpRegionId();
/* 118 */       String newds = null;
/* 119 */       Connection cenConnection = null;
/*     */       try {
/* 121 */         String center = CrossCenterStoreHelper.getCenterByRegionId(tmpRegionId);
/*     */ 
/* 124 */         String template = DataSourceTemplate.getCurrentTemplate();
/* 125 */         if (StringUtils.contains(template, "{CENTER}")) {
/* 126 */           newds = StringUtils.replace(template, "{CENTER}", center);
/*     */         }
/*     */         else
/*     */         {
/* 130 */           newds = DataSourceTemplate.getCurrentDataSource();
/*     */         }
/*     */ 
/* 133 */         if (StringUtils.isBlank(newds))
/*     */         {
/* 135 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_ds_error"));
/*     */         }
/*     */ 
/* 138 */         cenConnection = ServiceManager.getSession().getConnection(newds);
/*     */ 
/* 141 */         aParameterList.put("REGION_ID", tmpRegionId);
/* 142 */         rtn = super.retrieveByResultLevel(cenConnection, SplitTableFactory.createQuerySQL(strSql, aParameterList), aParameterList, resultLevel);
/*     */       }
/*     */       finally {
/* 145 */         if (cenConnection != null) {
/* 146 */           cenConnection.close();
/*     */         }
/*     */       }
/*     */     }
/* 150 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int retrieveCount(Connection aConn, ObjectType aType, String aCondition, Map aParameterList, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 164 */     int count = 0;
/*     */ 
/* 167 */     if (CrossCenterStoreHelper.getTmpRegionId() == null) {
/* 168 */       SplitTableFactory.createQueryTable(aType.getMapingEnty(), aParameterList);
/* 169 */       count = super.retrieveCount(aConn, aType, aCondition, aParameterList, aExtenBOArray);
/*     */     }
/*     */     else
/*     */     {
/* 174 */       String tmpRegionId = CrossCenterStoreHelper.getTmpRegionId();
/* 175 */       String newds = null;
/* 176 */       Connection cenConnection = null;
/*     */       try {
/* 178 */         String center = CrossCenterStoreHelper.getCenterByRegionId(tmpRegionId);
/*     */ 
/* 181 */         String template = DataSourceTemplate.getCurrentTemplate();
/* 182 */         if (StringUtils.contains(template, "{CENTER}")) {
/* 183 */           newds = StringUtils.replace(template, "{CENTER}", center);
/*     */         }
/*     */         else
/*     */         {
/* 187 */           newds = DataSourceTemplate.getCurrentDataSource();
/*     */         }
/*     */ 
/* 190 */         if (StringUtils.isBlank(newds))
/*     */         {
/* 193 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_ds_error"));
/*     */         }
/* 195 */         cenConnection = ServiceManager.getSession().getConnection(newds);
/*     */ 
/* 198 */         aParameterList.put("REGION_ID", tmpRegionId);
/* 199 */         SplitTableFactory.createQueryTable(aType.getMapingEnty(), aParameterList);
/* 200 */         count = super.retrieveCount(cenConnection, aType, aCondition, aParameterList, aExtenBOArray);
/*     */       }
/*     */       finally {
/* 203 */         if (cenConnection != null) {
/* 204 */           cenConnection.close();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 209 */     return count;
/*     */   }
/*     */ 
/*     */   public void save(Connection conn, DataContainerInterface[] dcs)
/*     */     throws Exception
/*     */   {
/* 220 */     saveBatch(conn, dcs);
/*     */   }
/*     */ 
/*     */   public void saveBatch(Connection conn, DataContainerInterface[] dcs)
/*     */     throws Exception
/*     */   {
/* 230 */     if ((dcs == null) || (dcs.length < 1)) {
/* 231 */       return;
/*     */     }
/*     */ 
/* 234 */     BatchSaveHelper.saveListBeansWithBatch(conn, dcs);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.AdvanceDataStoreImpl
 * JD-Core Version:    0.5.4
 */