/*    */ package com.ai.appframe2.complex.tab.split;
/*    */ 
/*    */ public class DyncSplitRule
/*    */ {
/* 13 */   private String groupName = null;
/* 14 */   private Object value = null;
/*    */ 
/*    */   public DyncSplitRule(String groupName, Object value)
/*    */   {
/* 22 */     this.groupName = groupName;
/* 23 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getGroupName() {
/* 27 */     return this.groupName;
/*    */   }
/*    */ 
/*    */   public Object getValue() {
/* 31 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(Object value) {
/* 35 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public void setGroupName(String groupName) {
/* 39 */     this.groupName = groupName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.split.DyncSplitRule
 * JD-Core Version:    0.5.4
 */