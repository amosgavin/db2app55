package com.ai.appframe2.complex.tab.id;

public abstract interface IIdGeneratorWrapper
{
  public abstract long wrapper(long paramLong);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.id.IIdGeneratorWrapper
 * JD-Core Version:    0.5.4
 */