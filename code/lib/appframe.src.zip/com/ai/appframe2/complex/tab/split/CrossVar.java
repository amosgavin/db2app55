/*    */ package com.ai.appframe2.complex.tab.split;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class CrossVar
/*    */ {
/*    */   private String tableName;
/*    */   private HashMap value;
/*    */ 
/*    */   public CrossVar()
/*    */   {
/* 15 */     this.tableName = null;
/* 16 */     this.value = new HashMap();
/*    */   }
/*    */   public String getTableName() {
/* 19 */     return this.tableName;
/*    */   }
/*    */   public void setTableName(String tableName) {
/* 22 */     this.tableName = tableName;
/*    */   }
/*    */ 
/*    */   public void addColAndValue(String columnName, String strValues) {
/* 26 */     this.value.put(columnName, strValues);
/*    */   }
/*    */   public String getValueByCol(String columnName) {
/* 29 */     return (String)this.value.get(columnName);
/*    */   }
/*    */   public HashMap getColsAndValues() {
/* 32 */     return this.value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.split.CrossVar
 * JD-Core Version:    0.5.4
 */