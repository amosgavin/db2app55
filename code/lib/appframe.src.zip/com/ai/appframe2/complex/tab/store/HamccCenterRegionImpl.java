/*    */ package com.ai.appframe2.complex.tab.store;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class HamccCenterRegionImpl
/*    */   implements ICenterRegion
/*    */ {
/* 16 */   private static Object LOCK = new Object();
/* 17 */   private static Method GET_CENTER_BY_REGION_ID = null;
/*    */ 
/*    */   public String getCenterByRegionId(String regionId)
/*    */     throws Exception
/*    */   {
/* 29 */     if (GET_CENTER_BY_REGION_ID == null) {
/* 30 */       synchronized (LOCK) {
/* 31 */         if (GET_CENTER_BY_REGION_ID == null) {
/* 32 */           Class clazz = Class.forName("com.asiainfo.boss.common.util.DistrictUtil");
/* 33 */           GET_CENTER_BY_REGION_ID = clazz.getMethod("getCenterByRegionId", new Class[] { String.class });
/*    */         }
/*    */       }
/*    */     }
/* 37 */     String center = (String)GET_CENTER_BY_REGION_ID.invoke(null, new Object[] { regionId });
/* 38 */     return center;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.HamccCenterRegionImpl
 * JD-Core Version:    0.5.4
 */