/*     */ package com.ai.appframe2.complex.tab.id;
/*     */ 
/*     */ import com.ai.appframe2.bo.ObjectTypeNull;
/*     */ import com.ai.appframe2.bo.ObjectTypeSingleValue;
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.impl.BatchIdGeneratorCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.IdGeneratorCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.IdGeneratorWrapperCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.SysDateCacheImpl;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorBean;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.IMutilTransactionDatasource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionDatasource;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Timestamp;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class AdvanceIdGeneratorImpl
/*     */   implements IdGenerator
/*     */ {
/*  42 */   private static transient Log log = LogFactory.getLog(AdvanceIdGeneratorImpl.class);
/*     */ 
/*     */   private IdGeneratorBean getIdGeneratorBean(String tableName)
/*     */   {
/*  50 */     IdGeneratorBean rtn = null;
/*     */     try {
/*  52 */       rtn = (IdGeneratorBean)CacheFactory.get(IdGeneratorCacheImpl.class, tableName.toUpperCase());
/*     */     }
/*     */     catch (Exception ex) {
/*  55 */       throw new RuntimeException(ex);
/*     */     }
/*  57 */     return rtn;
/*     */   }
/*     */ 
/*     */   private BatchSequence getBatchIdGeneratorBean(String tableName)
/*     */   {
/*  66 */     BatchSequence rtn = null;
/*     */     try {
/*  68 */       rtn = (BatchSequence)CacheFactory.get(BatchIdGeneratorCacheImpl.class, tableName.toUpperCase());
/*     */     }
/*     */     catch (Exception ex) {
/*  71 */       throw new RuntimeException(ex);
/*     */     }
/*  73 */     return rtn;
/*     */   }
/*     */ 
/*     */   private BatchSequence getBatchSequenceInstance(String tableName)
/*     */   {
/*  83 */     return getBatchIdGeneratorBean(tableName.toUpperCase());
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(ObjectType type)
/*     */     throws AIException
/*     */   {
/*  94 */     if ((type instanceof ObjectTypeNull) || (type instanceof ObjectTypeSingleValue))
/*     */     {
/*  97 */       throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.undo_getNewId", new String[] { type.getFullName() }));
/*     */     }
/*     */ 
/* 100 */     return getNewId(type.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public long getNewId(String dataSourceName, String tableName)
/*     */     throws AIException
/*     */   {
/* 111 */     BigDecimal rtn = null;
/*     */ 
/* 113 */     String tmp = StringUtils.replace(StringUtils.replace(tableName, "{", ""), "}", "");
/*     */ 
/* 115 */     BatchSequence objBatchSequence = getBatchSequenceInstance(tmp);
/* 116 */     if (objBatchSequence != null)
/*     */       try {
/* 118 */         rtn = BigDecimal.valueOf(objBatchSequence.getNewId(dataSourceName));
/*     */       }
/*     */       catch (Exception ex) {
/* 121 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.AdvanceIdGeneratorImpl.getsequence_failed", new String[] { tmp }), ex);
/* 122 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */     else {
/*     */       try
/*     */       {
/* 127 */         rtn = getRealNewId(dataSourceName, tmp);
/*     */       }
/*     */       catch (Exception ex) {
/* 130 */         log.error(ex.getMessage(), ex);
/* 131 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 136 */     long id = 0L;
/*     */     try {
/* 138 */       id = wrapperId(tmp, rtn.longValue());
/*     */     }
/*     */     catch (Exception ex) {
/* 141 */       log.error("error", ex);
/* 142 */       throw new AIException(ex.getMessage(), ex);
/*     */     }
/*     */ 
/* 145 */     return id;
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewIdByConnection(Connection conn, String tableName)
/*     */     throws AIException
/*     */   {
/* 156 */     BigDecimal rtn = null;
/*     */ 
/* 158 */     String tmp = StringUtils.replace(StringUtils.replace(tableName, "{", ""), "}", "").trim();
/*     */ 
/* 160 */     BatchSequence objBatchSequence = getBatchSequenceInstance(tmp);
/* 161 */     if (objBatchSequence != null)
/*     */       try {
/* 163 */         rtn = BigDecimal.valueOf(objBatchSequence.getNewId(conn));
/*     */       }
/*     */       catch (Exception ex) {
/* 166 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.AdvanceIdGeneratorImpl.getsequence_failed", new String[] { tmp }), ex);
/* 167 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */     else {
/*     */       try
/*     */       {
/* 172 */         rtn = getRealNewIdByConnection(conn, tmp);
/*     */       }
/*     */       catch (Exception ex) {
/* 175 */         log.error(ex.getMessage(), ex);
/* 176 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 181 */     long id = 0L;
/*     */     try {
/* 183 */       id = wrapperId(tmp, rtn.longValue());
/*     */     }
/*     */     catch (Exception ex) {
/* 186 */       log.error("error", ex);
/* 187 */       throw new AIException(ex.getMessage(), ex);
/*     */     }
/*     */ 
/* 190 */     return BigDecimal.valueOf(id);
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(String tableName)
/*     */     throws AIException
/*     */   {
/* 200 */     return new BigDecimal(getNewId((String)null, tableName));
/*     */   }
/*     */ 
/*     */   public BigDecimal getRealNewId(String dataSource, String tableName)
/*     */     throws Exception
/*     */   {
/* 211 */     BigDecimal rtn = null;
/*     */ 
/* 213 */     Connection conn = null;
/*     */     try
/*     */     {
/* 216 */       if (StringUtils.isBlank(dataSource)) {
/* 217 */         conn = ServiceManager.getSession().getConnection();
/*     */       }
/*     */       else {
/* 220 */         conn = ServiceManager.getSession().getConnection(dataSource);
/*     */       }
/*     */ 
/* 223 */       rtn = getRealNewIdByConnection(conn, tableName);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 230 */       if (conn != null) {
/* 231 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 235 */     return rtn;
/*     */   }
/*     */ 
/*     */   public BigDecimal getRealNewIdByConnection(Connection conn, String tableName)
/*     */     throws Exception
/*     */   {
/* 246 */     BigDecimal rtn = null;
/*     */     try
/*     */     {
/* 250 */       IdGeneratorBean objIdGeneratorBean = getIdGeneratorBean(tableName);
/* 251 */       if ((objIdGeneratorBean == null) || (StringUtils.isBlank(objIdGeneratorBean.getSequenceName())))
/*     */       {
/* 253 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.miss_sequence", new String[] { tableName }));
/*     */       }
/*     */ 
/* 256 */       rtn = new BigDecimal(DialectFactory.getDialect().getNewId(conn, objIdGeneratorBean.getSequenceName()));
/*     */     }
/*     */     catch (Exception e) {
/* 259 */       throw e;
/*     */     }
/*     */ 
/* 262 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean getHisDataFlag(String tableName)
/*     */   {
/* 271 */     boolean flag = false;
/* 272 */     IdGeneratorBean bean = getIdGeneratorBean(tableName);
/* 273 */     if (bean == null) {
/* 274 */       return false;
/*     */     }
/* 276 */     String his_flag = bean.getHisDataFlag();
/* 277 */     if ((his_flag != null) && (his_flag.equalsIgnoreCase("Y"))) {
/* 278 */       flag = true;
/*     */     }
/* 280 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean getHisDoneCodeFlag(String tableName)
/*     */   {
/* 289 */     boolean flag = false;
/* 290 */     IdGeneratorBean bean = getIdGeneratorBean(tableName);
/* 291 */     if (bean == null) {
/* 292 */       return false;
/*     */     }
/*     */ 
/* 295 */     String his_doneCode_flag = bean.getHisDonecodeFlag();
/* 296 */     if ((his_doneCode_flag != null) && (his_doneCode_flag.equalsIgnoreCase("Y"))) {
/* 297 */       flag = true;
/*     */     }
/* 299 */     return flag;
/*     */   }
/*     */ 
/*     */   public String getHisTableName(String tableName)
/*     */   {
/* 308 */     String hisTableName = null;
/* 309 */     IdGeneratorBean bean = getIdGeneratorBean(tableName);
/* 310 */     if (bean == null) {
/* 311 */       return null;
/*     */     }
/* 313 */     hisTableName = bean.getHisTableName();
/* 314 */     return hisTableName;
/*     */   }
/*     */ 
/*     */   public BigDecimal getHisTableNewId(ObjectType type)
/*     */     throws AIException
/*     */   {
/* 324 */     if ((type instanceof ObjectTypeNull) || (type instanceof ObjectTypeSingleValue))
/*     */     {
/* 328 */       throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.undo_getNewId", new String[] { type.getFullName() }));
/*     */     }
/* 330 */     return getHisTableNewId(type.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public BigDecimal getHisTableNewId(String tableName)
/*     */     throws AIException
/*     */   {
/* 340 */     BigDecimal rtn = null;
/*     */ 
/* 343 */     String srcTableName = StringUtils.replace(StringUtils.replace(tableName, "{", ""), "}", "").trim();
/*     */ 
/* 345 */     IdGeneratorBean objIdGeneratorBean = getIdGeneratorBean(srcTableName);
/*     */ 
/* 347 */     String hisTableName = objIdGeneratorBean.getHisTableName();
/*     */ 
/* 349 */     if (StringUtils.isBlank(hisTableName))
/*     */     {
/* 352 */       throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.miss_his_sequence", new String[] { srcTableName }));
/*     */     }
/*     */ 
/* 356 */     BatchSequence objBatchSequence = getBatchSequenceInstance(hisTableName);
/* 357 */     if (objBatchSequence != null)
/*     */       try {
/* 359 */         rtn = BigDecimal.valueOf(objBatchSequence.getNewId());
/*     */       }
/*     */       catch (Exception ex) {
/* 362 */         log.error(ex.getMessage(), ex);
/* 363 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */     else {
/*     */       try
/*     */       {
/* 368 */         rtn = getRealHisTableNewId(objIdGeneratorBean.getHisSequenceName());
/*     */       }
/*     */       catch (Exception ex) {
/* 371 */         log.error(ex.getMessage(), ex);
/* 372 */         throw new AIException(ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 377 */     long id = 0L;
/*     */     try {
/* 379 */       id = wrapperHisId(srcTableName, rtn.longValue());
/*     */     }
/*     */     catch (Exception ex) {
/* 382 */       log.error("error", ex);
/* 383 */       throw new AIException(ex.getMessage(), ex);
/*     */     }
/*     */ 
/* 386 */     return BigDecimal.valueOf(id);
/*     */   }
/*     */ 
/*     */   public BigDecimal getRealHisTableNewId(String sequenceName)
/*     */     throws Exception
/*     */   {
/* 397 */     BigDecimal rtn = null;
/*     */ 
/* 399 */     Connection conn = null;
/*     */     try {
/* 401 */       if (sequenceName == null)
/*     */       {
/* 404 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.no_his_sequence", new String[] { sequenceName }));
/*     */       }
/* 406 */       conn = ServiceManager.getSession().getConnection();
/*     */ 
/* 408 */       rtn = new BigDecimal(DialectFactory.getDialect().getNewId(conn, sequenceName));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 414 */       if (conn != null) {
/* 415 */         conn.close();
/*     */       }
/*     */     }
/* 418 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(ObjectType type)
/*     */     throws Exception
/*     */   {
/* 428 */     return getSysDate();
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate()
/*     */     throws Exception
/*     */   {
/* 437 */     return getSysDate((String)null);
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(String dataSourceName)
/*     */     throws Exception
/*     */   {
/* 447 */     String ds = null;
/* 448 */     if (!StringUtils.isBlank(dataSourceName)) {
/* 449 */       ds = dataSourceName;
/*     */     }
/*     */     else {
/* 452 */       ds = (String)IDataSource.CUR_DATASOURCE.get();
/* 453 */       if (ds == null) {
/* 454 */         if (ServiceManager.getSession() instanceof ITransactionDatasource) {
/* 455 */           ITransactionDatasource objITransactionDatasource = (ITransactionDatasource)ServiceManager.getSession();
/* 456 */           ds = objITransactionDatasource.getTxDataSource();
/* 457 */           if (log.isInfoEnabled())
/*     */           {
/* 459 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.AdvanceIdGeneratorImpl.getdate_nods_warn1", new String[] { ds }));
/*     */           }
/*     */         }
/* 462 */         else if (ServiceManager.getSession() instanceof IMutilTransactionDatasource) {
/* 463 */           IMutilTransactionDatasource objIMutilTransactionDatasource = (IMutilTransactionDatasource)ServiceManager.getSession();
/* 464 */           ds = objIMutilTransactionDatasource.getCurDataSource();
/* 465 */           if (log.isInfoEnabled())
/*     */           {
/* 467 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.AdvanceIdGeneratorImpl.getdate_nods_warn2", new String[] { ds }));
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 473 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.no_datasource"));
/*     */         }
/*     */       }
/*     */ 
/* 477 */       if (ds == null)
/*     */       {
/* 480 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.no_datasource"));
/*     */       }
/*     */     }
/*     */ 
/* 484 */     long time = 0L;
/* 485 */     Long diff = (Long)CacheFactory.get(SysDateCacheImpl.class, ds);
/* 486 */     if (diff.longValue() == -99999999L)
/*     */     {
/* 488 */       time = getRealSysDate(ds);
/*     */     }
/*     */     else
/*     */     {
/* 492 */       time = System.currentTimeMillis() + diff.longValue();
/*     */     }
/*     */ 
/* 495 */     if (time == 0L)
/*     */     {
/* 497 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.fail_get_time"));
/*     */     }
/*     */ 
/* 500 */     return new Timestamp(time);
/*     */   }
/*     */ 
/*     */   private long getRealSysDate(String ds)
/*     */     throws Exception
/*     */   {
/* 510 */     long rtn = 0L;
/* 511 */     Connection conn = null;
/*     */     try {
/* 513 */       conn = ServiceManager.getSession().getConnection(ds);
/* 514 */       rtn = DialectFactory.getDialect().getSysDate(conn);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 520 */       if (conn != null) {
/* 521 */         conn.close();
/*     */       }
/*     */     }
/* 524 */     return rtn;
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(Connection conn, ObjectType type)
/*     */     throws Exception
/*     */   {
/* 536 */     return getNewIdByConnection(conn, type.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(Connection conn, String tableName)
/*     */     throws Exception
/*     */   {
/* 547 */     return getNewIdByConnection(conn, tableName);
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(Connection conn, ObjectType type)
/*     */     throws Exception
/*     */   {
/* 558 */     return getSysDate(type);
/*     */   }
/*     */ 
/*     */   public BigDecimal getDirectNewId(Connection conn, ObjectType type)
/*     */     throws Exception
/*     */   {
/* 570 */     String tableName = type.getMapingEnty();
/* 571 */     return getDirectNewId(conn, tableName);
/*     */   }
/*     */ 
/*     */   public BigDecimal getDirectNewId(Connection conn, String tableName)
/*     */     throws Exception
/*     */   {
/* 583 */     BigDecimal rtn = null;
/*     */     try
/*     */     {
/* 586 */       String tmp = StringUtils.replace(StringUtils.replace(tableName, "{", ""), "}", "");
/*     */ 
/* 588 */       IdGeneratorBean objIdGeneratorBean = getIdGeneratorBean(tmp);
/* 589 */       if ((objIdGeneratorBean == null) || (StringUtils.isBlank(objIdGeneratorBean.getSequenceName())))
/*     */       {
/* 592 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.miss_sequence", new String[] { tableName }));
/*     */       }
/*     */ 
/* 595 */       rtn = new BigDecimal(DialectFactory.getDialect().getNewId(conn, objIdGeneratorBean.getSequenceName()));
/*     */     }
/*     */     catch (Exception e) {
/* 598 */       throw e;
/*     */     }
/*     */ 
/* 601 */     return rtn;
/*     */   }
/*     */ 
/*     */   private long wrapperId(String tableName, long id)
/*     */     throws Exception
/*     */   {
/* 612 */     IdGeneratorWrapperBean objIdGeneratorWrapperBean = (IdGeneratorWrapperBean)CacheFactory.get(IdGeneratorWrapperCacheImpl.class, tableName);
/* 613 */     if (objIdGeneratorWrapperBean == null) {
/* 614 */       return id;
/*     */     }
/*     */ 
/* 617 */     IIdGeneratorWrapper objIIdGeneratorWrapper = (IIdGeneratorWrapper)objIdGeneratorWrapperBean.getTableSeqWrapperObj();
/* 618 */     if (objIIdGeneratorWrapper != null) {
/* 619 */       return objIIdGeneratorWrapper.wrapper(id);
/*     */     }
/*     */ 
/* 622 */     return id;
/*     */   }
/*     */ 
/*     */   private long wrapperHisId(String tableName, long id)
/*     */     throws Exception
/*     */   {
/* 635 */     IdGeneratorWrapperBean objIdGeneratorWrapperBean = (IdGeneratorWrapperBean)CacheFactory.get(IdGeneratorWrapperCacheImpl.class, tableName);
/* 636 */     if (objIdGeneratorWrapperBean == null) {
/* 637 */       return id;
/*     */     }
/*     */ 
/* 640 */     IIdGeneratorWrapper objIIdGeneratorWrapper = (IIdGeneratorWrapper)objIdGeneratorWrapperBean.getHisTableSeqWrapperObj();
/* 641 */     if (objIIdGeneratorWrapper != null) {
/* 642 */       return objIIdGeneratorWrapper.wrapper(id);
/*     */     }
/*     */ 
/* 645 */     return id;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 651 */     String a = (String)null;
/* 652 */     if (a == null) {
/* 653 */       System.out.println("kong");
/*     */     }
/*     */     else
/*     */     {
/* 657 */       System.out.println(a);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.id.AdvanceIdGeneratorImpl
 * JD-Core Version:    0.5.4
 */