/*     */ package com.ai.appframe2.complex.tab.id;
/*     */ 
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public final class BatchSequence
/*     */ {
/*  20 */   private String seqName = null;
/*  21 */   private long start = -1L;
/*  22 */   private long position = -1L;
/*  23 */   private long stepBy = -1L;
/*     */ 
/*     */   public BatchSequence(String seqName, long stepBy)
/*     */     throws Exception
/*     */   {
/*  32 */     this.seqName = seqName;
/*  33 */     this.stepBy = stepBy;
/*     */ 
/*  35 */     if (StringUtils.isBlank(this.seqName))
/*     */     {
/*  38 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.seq_step_error", new String[] { seqName }));
/*     */     }
/*  40 */     if (this.stepBy > 0L) {
/*     */       return;
/*     */     }
/*  43 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.seq_step_error", new String[] { seqName }));
/*     */   }
/*     */ 
/*     */   public synchronized long getNewId()
/*     */     throws Exception
/*     */   {
/*  53 */     if ((this.position >= this.stepBy - 1L) || (this.position == -1L)) {
/*  54 */       getBatchNewId(null);
/*  55 */       this.position = 0L;
/*  56 */       return this.start;
/*     */     }
/*     */ 
/*  59 */     this.position += 1L;
/*  60 */     return this.start + this.position;
/*     */   }
/*     */ 
/*     */   public synchronized long getNewId(String dataSource)
/*     */     throws Exception
/*     */   {
/*  71 */     if ((this.position >= this.stepBy - 1L) || (this.position == -1L)) {
/*  72 */       getBatchNewId(dataSource);
/*  73 */       this.position = 0L;
/*  74 */       return this.start;
/*     */     }
/*     */ 
/*  77 */     this.position += 1L;
/*  78 */     return this.start + this.position;
/*     */   }
/*     */ 
/*     */   public synchronized long getNewId(Connection conn)
/*     */     throws Exception
/*     */   {
/*  89 */     if ((this.position >= this.stepBy - 1L) || (this.position == -1L)) {
/*  90 */       getBatchNewIdByConnection(conn);
/*  91 */       this.position = 0L;
/*  92 */       return this.start;
/*     */     }
/*     */ 
/*  95 */     this.position += 1L;
/*  96 */     return this.start + this.position;
/*     */   }
/*     */ 
/*     */   private void getBatchNewId(String dataSource)
/*     */     throws Exception
/*     */   {
/* 106 */     Connection conn = null;
/*     */     try {
/* 108 */       if (StringUtils.isBlank(dataSource)) {
/* 109 */         conn = ServiceManager.getSession().getConnection();
/*     */       }
/*     */       else {
/* 112 */         conn = ServiceManager.getSession().getConnection(dataSource);
/*     */       }
/* 114 */       getBatchNewIdByConnection(conn);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 120 */       if (conn != null)
/* 121 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void getBatchNewIdByConnection(Connection conn)
/*     */     throws Exception
/*     */   {
/* 132 */     this.start = DialectFactory.getDialect().getNewId(conn, this.seqName);
/* 133 */     if (this.start < 0L)
/* 134 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.id.BatchSequence.getsequence_failed"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.id.BatchSequence
 * JD-Core Version:    0.5.4
 */