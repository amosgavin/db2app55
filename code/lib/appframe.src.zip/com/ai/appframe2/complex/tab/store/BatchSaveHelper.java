/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.bo.ObjectTypeNull;
/*     */ import com.ai.appframe2.bo.ObjectTypeSingleValue;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceTemplate;
/*     */ import com.ai.appframe2.complex.tab.split.SplitTableFactory;
/*     */ import com.ai.appframe2.complex.transaction.impl.LocalMutilTransactionImpl;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class BatchSaveHelper
/*     */ {
/*  43 */   private static transient Log log = LogFactory.getLog(BatchSaveHelper.class);
/*     */ 
/*  45 */   private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
/*     */ 
/*     */   public static void saveListBeansWithBatch(Connection conn, DataContainerInterface[] dcs)
/*     */     throws Exception
/*     */   {
/*  54 */     if ((dcs == null) || (dcs.length == 0)) {
/*  55 */       return;
/*     */     }
/*     */ 
/*  58 */     long start = 0L;
/*  59 */     long groupCount = 0L;
/*  60 */     long recordCount = 0L;
/*     */ 
/*  62 */     if (log.isInfoEnabled()) {
/*  63 */       start = System.currentTimeMillis();
/*     */     }
/*     */ 
/*  67 */     HisRecordHelper.recordHisForBatch(conn, dcs);
/*     */ 
/*  70 */     executePreparedSql(conn, dcs);
/*     */ 
/*  72 */     groupCount += 1L;
/*  73 */     recordCount += dcs.length;
/*     */ 
/*  75 */     if (!log.isInfoEnabled())
/*     */       return;
/*  77 */     log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.succeed", new String[] { recordCount + "", groupCount + "", System.currentTimeMillis() - start + "" }));
/*     */   }
/*     */ 
/*     */   public static void saveListBeansWithBatch(DataContainerInterface[] dcs)
/*     */     throws Exception
/*     */   {
/*  87 */     Connection conn = null;
/*     */     try {
/*  89 */       conn = ServiceManager.getSession().getConnection();
/*  90 */       saveListBeansWithBatch(conn, dcs);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/*  96 */       if (conn != null)
/*  97 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void saveListBeansWithBatch(List beanList)
/*     */     throws Exception
/*     */   {
/* 108 */     if ((beanList == null) || (beanList.isEmpty())) {
/* 109 */       return;
/*     */     }
/* 111 */     Connection conn = null;
/*     */     try {
/* 113 */       conn = ServiceManager.getSession().getConnection();
/* 114 */       long start = 0L;
/* 115 */       long groupCount = 0L;
/* 116 */       long recordCount = 0L;
/*     */ 
/* 118 */       if (log.isInfoEnabled()) {
/* 119 */         start = System.currentTimeMillis();
/*     */       }
/*     */ 
/* 122 */       for (int i = 0; i < beanList.size(); ++i) {
/* 123 */         DataContainerInterface[] dcs = null;
/* 124 */         if (beanList.get(i).getClass().isArray()) {
/* 125 */           dcs = (DataContainerInterface[])(DataContainerInterface[])beanList.get(i);
/*     */         }
/*     */         else {
/* 128 */           dcs = new DataContainerInterface[1];
/* 129 */           dcs[0] = ((DataContainerInterface)beanList.get(i));
/*     */         }
/*     */ 
/* 133 */         HisRecordHelper.recordHisForBatch(conn, dcs);
/*     */ 
/* 136 */         executePreparedSql(conn, dcs);
/*     */ 
/* 138 */         groupCount += 1L;
/* 139 */         recordCount += dcs.length;
/*     */       }
/* 141 */       if (log.isInfoEnabled()) {
/* 142 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.succeed", new String[] { recordCount + "", groupCount + "", System.currentTimeMillis() - start + "" }));
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 150 */       if (conn != null)
/* 151 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void executePreparedSql(Connection conn, DataContainerInterface[] datas)
/*     */     throws Exception
/*     */   {
/* 162 */     if ((datas == null) || (datas.length == 0)) {
/* 163 */       return;
/*     */     }
/*     */ 
/* 170 */     DataContainerInterface tmpDataContainer = datas[0];
/* 171 */     if ((tmpDataContainer.getObjectType() instanceof ObjectTypeNull) || (tmpDataContainer.getObjectType() instanceof ObjectTypeSingleValue))
/*     */     {
/* 175 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.undo_save_action"));
/*     */     }
/* 177 */     ObjectType type = tmpDataContainer.getObjectType();
/*     */ 
/* 182 */     boolean hasRegionColumn = false;
/* 183 */     if (tmpDataContainer.hasPropertyName("REGION_ID")) {
/* 184 */       hasRegionColumn = true;
/*     */     }
/*     */ 
/* 189 */     HashMap crossRegion = new HashMap();
/*     */ 
/* 192 */     List sqlAndPtmt = new ArrayList();
/* 193 */     for (int i = 0; i < datas.length; ++i) {
/* 194 */       DataContainerInterface dc = datas[i];
/*     */ 
/* 196 */       String tableName = SplitTableFactory.createTableName(tmpDataContainer.fetchTableName(), dc);
/*     */ 
/* 201 */       if (hasRegionColumn) {
/* 202 */         String regionId = dc.getAsString("REGION_ID");
/* 203 */         if (!StringUtils.isBlank(regionId)) {
/* 204 */           crossRegion.put(regionId, regionId);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 209 */       StringBuilder sql = new StringBuilder();
/* 210 */       StringBuilder value = new StringBuilder();
/*     */ 
/* 212 */       boolean isfirst = true;
/* 213 */       Iterator it = dc.getNewProperties().entrySet().iterator();
/*     */ 
/* 215 */       PtmtList objPtmtList = new PtmtList();
/* 216 */       if (dc.isNew()) {
/* 217 */         sql.append("insert into ").append(tableName).append("(");
/* 218 */         value.append("values(");
/*     */ 
/* 220 */         while (it.hasNext())
/*     */         {
/* 222 */           Map.Entry me = (Map.Entry)it.next();
/* 223 */           String key = (String)me.getKey();
/* 224 */           if (!type.getProperty(key).getType().equalsIgnoreCase("VIRTUAL"))
/*     */           {
/* 226 */             Object obj = me.getValue();
/* 227 */             if (isfirst) {
/* 228 */               isfirst = false;
/*     */             }
/*     */             else {
/* 231 */               sql.append(",");
/* 232 */               value.append(",");
/*     */             }
/* 234 */             String colName = type.getProperty(key).getMapingColName();
/* 235 */             sql.append(colName);
/*     */ 
/* 237 */             value.append("?");
/*     */ 
/* 239 */             if (obj == null) {
/* 240 */               objPtmtList.add(dc.getPropertyType(key), key, "null");
/*     */             }
/*     */             else {
/* 243 */               objPtmtList.add(dc.getPropertyType(key), key, obj);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 248 */         sql.append(")");
/* 249 */         value.append(")");
/* 250 */         sql.append(value);
/*     */ 
/* 253 */         if (hasRegionColumn) {
/* 254 */           objPtmtList.setRegionId(dc);
/*     */         }
/*     */       }
/* 257 */       else if (dc.isDeleted()) {
/* 258 */         sql.append("delete from ").append(tableName).append(" where ");
/*     */ 
/* 262 */         if ((dc instanceof DataContainer) && (((DataContainer)dc).isHasRowId())) {
/* 263 */           sql.append(" ROWID = ? ");
/* 264 */           objPtmtList.add("String", "ROWID", ((DataContainer)dc).getMRowId());
/*     */         }
/*     */         else {
/* 267 */           StringBuilder where_sql = new StringBuilder();
/* 268 */           Map keys = dc.getKeyProperties();
/* 269 */           if (keys.size() == 0)
/*     */           {
/* 272 */             throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_key_col"));
/*     */           }
/* 274 */           Iterator itb = keys.keySet().iterator();
/*     */ 
/* 276 */           while (itb.hasNext())
/*     */           {
/* 278 */             String key = (String)itb.next();
/* 279 */             Object obj = dc.getOldObj(key);
/* 280 */             if (isfirst) {
/* 281 */               isfirst = false;
/*     */             }
/*     */             else {
/* 284 */               where_sql.append(" and ");
/*     */             }
/* 286 */             where_sql.append(key).append(" = ");
/* 287 */             if (obj == null)
/*     */             {
/* 290 */               throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_key_col"));
/*     */             }
/* 292 */             where_sql.append("?");
/*     */ 
/* 294 */             if (obj == null) {
/* 295 */               objPtmtList.add(dc.getPropertyType(key), key, "null");
/*     */             }
/*     */             else {
/* 298 */               objPtmtList.add(dc.getPropertyType(key), key, obj);
/*     */             }
/*     */           }
/*     */ 
/* 302 */           sql.append(where_sql);
/*     */         }
/*     */ 
/* 307 */         if (hasRegionColumn) {
/* 308 */           objPtmtList.setRegionId(dc);
/*     */         }
/*     */       }
/* 311 */       else if (dc.isModified()) {
/* 312 */         sql.append("update ").append(tableName).append(" set ");
/*     */ 
/* 314 */         while (it.hasNext())
/*     */         {
/* 316 */           Map.Entry me = (Map.Entry)it.next();
/* 317 */           String key = (String)me.getKey();
/* 318 */           if (!type.getProperty(key).getType().equalsIgnoreCase("VIRTUAL"))
/*     */           {
/* 320 */             Object obj = me.getValue();
/* 321 */             if (isfirst) {
/* 322 */               isfirst = false;
/*     */             }
/*     */             else {
/* 325 */               sql.append(",");
/*     */             }
/* 327 */             sql.append(key).append(" = ");
/*     */ 
/* 329 */             if (obj == null) {
/* 330 */               objPtmtList.add(dc.getPropertyType(key), key, "null");
/*     */             }
/*     */             else {
/* 333 */               objPtmtList.add(dc.getPropertyType(key), key, obj);
/*     */             }
/*     */ 
/* 336 */             sql.append("?");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 342 */         if ((dc instanceof DataContainer) && (((DataContainer)dc).isHasRowId())) {
/* 343 */           objPtmtList.add("String", "ROWID", ((DataContainer)dc).getMRowId());
/* 344 */           sql.append(" where ROWID = ? ");
/*     */         }
/*     */         else
/*     */         {
/* 348 */           isfirst = true;
/* 349 */           StringBuilder where_sql = new StringBuilder(" where  ");
/* 350 */           Map keys = dc.getKeyProperties();
/* 351 */           if (keys.size() == 0)
/*     */           {
/* 354 */             throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_key_col"));
/*     */           }
/* 356 */           Iterator itb = keys.keySet().iterator();
/*     */ 
/* 358 */           while (itb.hasNext())
/*     */           {
/* 360 */             String key = (String)itb.next();
/* 361 */             Object obj = dc.getOldObj(key);
/* 362 */             if (isfirst) {
/* 363 */               isfirst = false;
/*     */             }
/*     */             else {
/* 366 */               where_sql.append(" and ");
/*     */             }
/* 368 */             where_sql.append(key).append(" = ");
/* 369 */             if (obj == null)
/*     */             {
/* 372 */               throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.blank_key_col"));
/*     */             }
/* 374 */             where_sql.append("?");
/*     */ 
/* 376 */             if (obj == null) {
/* 377 */               objPtmtList.add(dc.getPropertyType(key), key, "null");
/*     */             }
/*     */             else {
/* 380 */               objPtmtList.add(dc.getPropertyType(key), key, obj);
/*     */             }
/*     */           }
/*     */ 
/* 384 */           sql.append(where_sql);
/*     */         }
/*     */ 
/* 388 */         if (hasRegionColumn)
/* 389 */           objPtmtList.setRegionId(dc);
/*     */       }
/*     */       else
/*     */       {
/* 393 */         log.warn(dc + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.nodata_warn"));
/* 394 */         continue;
/*     */       }
/*     */ 
/* 398 */       objPtmtList.setSQL(sql.toString());
/*     */ 
/* 400 */       sqlAndPtmt.add(objPtmtList);
/*     */     }
/*     */ 
/* 404 */     if (sqlAndPtmt.size() == 0) {
/* 405 */       log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.nodata_serious_warn"));
/* 406 */       return;
/*     */     }
/*     */ 
/* 411 */     HashMap distinct = new HashMap();
/* 412 */     for (Iterator iter = sqlAndPtmt.iterator(); iter.hasNext(); ) {
/* 413 */       PtmtList item = (PtmtList)iter.next();
/* 414 */       if (distinct.containsKey(item.getSQL())) {
/* 415 */         List tmp = (List)distinct.get(item.getSQL());
/* 416 */         tmp.add(item);
/* 417 */         distinct.put(item.getSQL(), tmp);
/*     */       }
/*     */       else {
/* 420 */         List tmp = new ArrayList();
/* 421 */         tmp.add(item);
/* 422 */         distinct.put(item.getSQL(), tmp);
/*     */       }
/*     */     }
/*     */     HashMap _cenMap;
/*     */     Iterator iter;
/* 428 */     if ((hasRegionColumn) && (crossRegion.size() > 0)) {
/* 429 */       boolean isCrossCenter = false;
/*     */ 
/* 431 */       if (crossRegion.size() == 1) {
/* 432 */         if (CenterFactory.isSetCenterInfo())
/*     */         {
/* 434 */           String regionId = (String)crossRegion.keySet().iterator().next();
/*     */ 
/* 437 */           String curRegionId = CenterFactory.getCenterInfo().getRegion();
/* 438 */           if (!CrossCenterStoreHelper.isSameCenter(regionId.toUpperCase(), curRegionId))
/* 439 */             isCrossCenter = true;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 444 */         HashMap mapping = CrossCenterStoreHelper.getCenterMapping(crossRegion);
/* 445 */         if ((mapping == null) || (mapping.size() == 0)) {
/* 446 */           log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.norelat_center_data"));
/* 447 */           return;
/*     */         }
/* 449 */         if (mapping.size() > 1) {
/* 450 */           isCrossCenter = true;
/*     */         }
/*     */       }
/*     */ 
/* 454 */       if (!isCrossCenter)
/*     */       {
/* 456 */         executeInternal(conn, distinct);
/*     */       }
/*     */       else {
/* 459 */         if (!ServiceManager.getSession() instanceof LocalMutilTransactionImpl)
/*     */         {
/* 462 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.transact_impl_error"));
/*     */         }
/*     */ 
/* 466 */         HashMap _reservMapping = CrossCenterStoreHelper.getReserveCenterMapping(crossRegion);
/*     */ 
/* 468 */         _cenMap = new HashMap();
/*     */ 
/* 470 */         Set _key = distinct.keySet();
/* 471 */         for (Iterator iter = _key.iterator(); iter.hasNext(); ) {
/* 472 */           String _sql = (String)iter.next();
/* 473 */           List _l = (List)distinct.get(_sql);
/*     */ 
/* 476 */           PtmtList _objPtmtList = (PtmtList)_l.get(0);
/* 477 */           String _center = (String)_reservMapping.get(_objPtmtList.getRegionId());
/* 478 */           if (_cenMap.containsKey(_center)) {
/* 479 */             HashMap _map = (HashMap)_cenMap.get(_center);
/* 480 */             _map.put(_sql, _l);
/* 481 */             _cenMap.put(_center, _map);
/*     */           }
/*     */           else {
/* 484 */             HashMap _map = new HashMap();
/* 485 */             _map.put(_sql, _l);
/* 486 */             _cenMap.put(_center, _map);
/*     */           }
/*     */         }
/*     */ 
/* 490 */         Set set = _cenMap.keySet();
/* 491 */         for (iter = set.iterator(); iter.hasNext(); ) {
/* 492 */           String item = (String)iter.next();
/* 493 */           HashMap newdistinct = (HashMap)_cenMap.get(item);
/* 494 */           Connection cenConnection = null;
/*     */           try {
/* 496 */             String newds = null;
/*     */ 
/* 499 */             String template = DataSourceTemplate.getCurrentTemplate();
/* 500 */             if (StringUtils.contains(template, "{CENTER}")) {
/* 501 */               newds = StringUtils.replace(template, "{CENTER}", item);
/*     */             }
/*     */             else
/*     */             {
/* 505 */               newds = DataSourceTemplate.getCurrentDataSource();
/*     */             }
/*     */ 
/* 508 */             if (StringUtils.isBlank(newds))
/*     */             {
/* 511 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.null_ds_error"));
/*     */             }
/* 513 */             cenConnection = ServiceManager.getSession().getConnection(newds);
/* 514 */             executeInternal(cenConnection, newdistinct);
/*     */           }
/*     */           finally {
/* 517 */             if (cenConnection != null) {
/* 518 */               cenConnection.close();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 526 */       executeInternal(conn, distinct);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void executeInternal(Connection conn, HashMap distinct)
/*     */     throws Exception
/*     */   {
/* 540 */     Set keySet = distinct.keySet();
/* 541 */     for (Iterator iter = keySet.iterator(); iter.hasNext(); ) {
/* 542 */       String sql = (String)iter.next();
/* 543 */       PreparedStatement ptmt = null;
/*     */       try {
/* 545 */         ptmt = conn.prepareStatement(sql);
/*     */ 
/* 547 */         long start2 = System.currentTimeMillis();
/* 548 */         if (log.isDebugEnabled()) {
/* 549 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.batchdata_info", new String[] { sql }));
/*     */         }
/* 551 */         List tmp = (List)distinct.get(sql);
/*     */ 
/* 553 */         int recordOffset = 1;
/* 554 */         for (Iterator iterator = tmp.iterator(); iterator.hasNext(); ) {
/* 555 */           PtmtList objPtmtList = (PtmtList)iterator.next();
/*     */ 
/* 557 */           objPtmtList.populate(ptmt, recordOffset);
/* 558 */           ptmt.addBatch();
/* 559 */           ++recordOffset;
/*     */         }
/* 561 */         ptmt.executeBatch();
/* 562 */         if (log.isDebugEnabled())
/*     */         {
/* 564 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.batchdata_spent_info", new String[] { sql, System.currentTimeMillis() - start2 + "" }));
/*     */         }
/*     */ 
/* 567 */         if (System.currentTimeMillis() - start2 > 3000L)
/*     */         {
/* 569 */           log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.warn", new String[] { sql, System.currentTimeMillis() - start2 + "" }), new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.save.warn_exception")));
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 575 */         throw e;
/*     */       }
/*     */       finally {
/* 578 */         if (ptmt != null)
/* 579 */           ptmt.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PtmtList
/*     */   {
/* 595 */     private String sql = null;
/* 596 */     private List types = new ArrayList();
/* 597 */     private List values = new ArrayList();
/* 598 */     private List keys = new ArrayList();
/* 599 */     private String regionId = null;
/*     */ 
/*     */     public void setSQL(String sql)
/*     */     {
/* 606 */       this.sql = sql;
/*     */     }
/*     */ 
/*     */     public String getSQL() {
/* 610 */       return this.sql;
/*     */     }
/*     */ 
/*     */     public void add(String type, String key, Object value)
/*     */     {
/* 620 */       this.types.add(type);
/* 621 */       this.values.add(value);
/* 622 */       this.keys.add(key);
/*     */     }
/*     */ 
/*     */     public String getRegionId() {
/* 626 */       return this.regionId;
/*     */     }
/*     */ 
/*     */     public void setRegionId(DataContainerInterface objDataContainerInterface) {
/* 630 */       if (objDataContainerInterface != null) {
/* 631 */         String tmpRegionId = objDataContainerInterface.getAsString("REGION_ID");
/* 632 */         if (!StringUtils.isBlank(tmpRegionId))
/* 633 */           this.regionId = tmpRegionId;
/*     */       }
/*     */     }
/*     */ 
/*     */     public void populate(PreparedStatement ptmt, int length)
/*     */       throws Exception
/*     */     {
/* 645 */       if (this.types.size() != this.values.size())
/*     */       {
/* 648 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.size_unequal"));
/*     */       }
/*     */ 
/* 651 */       for (int i = 0; i < this.types.size(); ++i) {
/* 652 */         String item = (String)this.types.get(i);
/* 653 */         if (BatchSaveHelper.log.isDebugEnabled()) {
/* 654 */           String tmpValue = null;
/* 655 */           if (this.values.get(i) instanceof java.util.Date) {
/* 656 */             tmpValue = BatchSaveHelper.DATE_FORMAT.format(this.values.get(i));
/*     */           }
/*     */           else {
/* 659 */             tmpValue = this.values.get(i).toString();
/*     */           }
/*     */ 
/* 662 */           BatchSaveHelper.log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.populate.info", new String[] { length + "", String.valueOf(i + 1), item, this.keys.get(i).toString(), tmpValue }));
/*     */         }
/*     */ 
/* 666 */         if (item.equals("String")) {
/* 667 */           if ((this.values.get(i) == null) || (this.values.get(i).toString().equalsIgnoreCase("null"))) {
/* 668 */             ptmt.setString(i + 1, null);
/*     */           }
/*     */           else {
/* 671 */             ptmt.setString(i + 1, this.values.get(i).toString());
/*     */           }
/*     */         }
/* 674 */         else if ((item.equals("Date")) || (item.equals("DateTime"))) {
/* 675 */           Object tmp = this.values.get(i);
/* 676 */           if (tmp != null) {
/* 677 */             if (tmp instanceof java.util.Date) {
/* 678 */               ptmt.setTimestamp(i + 1, new Timestamp(((java.util.Date)(java.util.Date)this.values.get(i)).getTime())); break label562:
/*     */             }
/* 680 */             if (tmp instanceof java.sql.Date) {
/* 681 */               ptmt.setTimestamp(i + 1, new Timestamp(((java.sql.Date)(java.sql.Date)this.values.get(i)).getTime())); break label562:
/*     */             }
/* 683 */             if (tmp instanceof Timestamp) {
/* 684 */               ptmt.setTimestamp(i + 1, (Timestamp)tmp); break label562:
/*     */             }
/* 686 */             if (tmp instanceof String) {
/* 687 */               if (((String)tmp).equalsIgnoreCase("null")) {
/* 688 */                 ptmt.setTimestamp(i + 1, null); break label562:
/*     */               }
/*     */ 
/* 693 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.unknown_type") + " : " + tmp.getClass());
/*     */             }
/*     */ 
/* 699 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.unknown_type") + " : " + tmp.getClass());
/*     */           }
/*     */ 
/* 703 */           label562: ptmt.setTimestamp(i + 1, null);
/*     */         }
/* 706 */         else if (item.equals("Long")) {
/* 707 */           Object tmp = this.values.get(i);
/* 708 */           if (tmp instanceof BigDecimal) {
/* 709 */             ptmt.setLong(i + 1, ((BigDecimal)tmp).longValue());
/*     */           }
/*     */           else {
/* 712 */             ptmt.setLong(i + 1, ((Long)tmp).longValue());
/*     */           }
/*     */         }
/* 715 */         else if (item.equals("Integer")) {
/* 716 */           Object tmp = this.values.get(i);
/* 717 */           if (tmp instanceof BigDecimal) {
/* 718 */             ptmt.setInt(i + 1, ((BigDecimal)tmp).intValue());
/*     */           }
/*     */           else {
/* 721 */             ptmt.setInt(i + 1, ((Integer)tmp).intValue());
/*     */           }
/*     */         }
/* 724 */         else if (item.equals("Short")) {
/* 725 */           Object tmp = this.values.get(i);
/* 726 */           if (tmp instanceof BigDecimal) {
/* 727 */             ptmt.setShort(i + 1, ((BigDecimal)tmp).shortValue());
/*     */           }
/*     */           else {
/* 730 */             ptmt.setShort(i + 1, ((Short)tmp).shortValue());
/*     */           }
/*     */         }
/* 733 */         else if (item.equals("Float")) {
/* 734 */           Object tmp = this.values.get(i);
/* 735 */           if (tmp instanceof BigDecimal) {
/* 736 */             ptmt.setFloat(i + 1, ((BigDecimal)tmp).floatValue());
/*     */           }
/*     */           else {
/* 739 */             ptmt.setFloat(i + 1, ((Float)tmp).floatValue());
/*     */           }
/*     */         }
/* 742 */         else if (item.equals("Double")) {
/* 743 */           Object tmp = this.values.get(i);
/* 744 */           if (tmp instanceof BigDecimal) {
/* 745 */             ptmt.setDouble(i + 1, ((BigDecimal)tmp).doubleValue());
/*     */           }
/*     */           else {
/* 748 */             ptmt.setDouble(i + 1, ((Double)tmp).doubleValue());
/*     */           }
/*     */         }
/* 751 */         else if (item.equals("Number")) {
/* 752 */           ptmt.setLong(i + 1, ((Long)(Long)this.values.get(i)).longValue());
/*     */         }
/*     */         else
/*     */         {
/* 757 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.unimpl_type", new String[] { item }));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.BatchSaveHelper
 * JD-Core Version:    0.5.4
 */