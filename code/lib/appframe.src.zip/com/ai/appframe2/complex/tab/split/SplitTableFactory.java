/*     */ package com.ai.appframe2.complex.tab.split;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.impl.DyncTableSplitCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.TableSplitCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.TableSplitFunctionCacheImpl;
/*     */ import com.ai.appframe2.complex.cache.impl.TableSplitMappingCacheImpl;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.self.po.DyncTableSplit;
/*     */ import com.ai.appframe2.complex.self.po.TableSplit;
/*     */ import com.ai.appframe2.complex.self.po.TableSplitMapping;
/*     */ import com.ai.appframe2.complex.tab.split.function.IFunction;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SplitTableFactory
/*     */ {
/*  37 */   private static transient Log log = LogFactory.getLog(SplitTableFactory.class);
/*     */ 
/*  40 */   private static ThreadLocal DYNC_SPLIT = new ThreadLocal();
/*     */   public static final String REGION_ID = "REGION_ID";
/*     */   public static final String REGION_CODE = "REGION_CODE";
/*     */ 
/*     */   public static void setDyncSplitRule(String groupName, Object value)
/*     */     throws Exception
/*     */   {
/*  58 */     if (DYNC_SPLIT.get() == null) {
/*  59 */       if (log.isDebugEnabled())
/*     */       {
/*  61 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.splitgroup_info", new String[] { groupName, value + "" }));
/*     */       }
/*     */ 
/*  64 */       DYNC_SPLIT.set(new DyncSplitRule(groupName, value));
/*     */     }
/*     */     else
/*     */     {
/*  69 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.check_rule_conf"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void clearDyncSplitRule()
/*     */   {
/*  77 */     if (log.isDebugEnabled()) {
/*  78 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.clear_split_info"));
/*     */     }
/*     */ 
/*  81 */     DYNC_SPLIT.set(null);
/*     */   }
/*     */ 
/*     */   private static String getDyncTableName(String oldTableName, String newTableName)
/*     */     throws Exception
/*     */   {
/*  92 */     DyncSplitRule objDyncSplitRule = (DyncSplitRule)DYNC_SPLIT.get();
/*  93 */     if (objDyncSplitRule == null)
/*     */     {
/*  95 */       return newTableName;
/*     */     }
/*     */ 
/*  98 */     String groupName = objDyncSplitRule.getGroupName();
/*     */ 
/* 101 */     HashMap map = (HashMap)CacheFactory.get(DyncTableSplitCacheImpl.class, groupName);
/* 102 */     DyncTableSplit objDyncTableSplit = (DyncTableSplit)map.get(oldTableName);
/* 103 */     if (objDyncTableSplit != null)
/*     */     {
/* 105 */       IFunction objFunction = (IFunction)CacheFactory.get(TableSplitFunctionCacheImpl.class, objDyncTableSplit.getConvertClass());
/* 106 */       String value = objFunction.convert(objDyncSplitRule.getValue());
/*     */ 
/* 108 */       String expr = org.apache.commons.lang.StringUtils.replace(objDyncTableSplit.getTableNameExpr(), "T[TABLE]", newTableName);
/* 109 */       expr = org.apache.commons.lang.StringUtils.replace(expr, "[D]", value);
/*     */ 
/* 111 */       if (log.isDebugEnabled())
/*     */       {
/* 113 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.dync_splittable_info", new String[] { oldTableName, newTableName, expr }));
/*     */       }
/*     */ 
/* 116 */       return expr;
/*     */     }
/*     */ 
/* 120 */     return newTableName;
/*     */   }
/*     */ 
/*     */   public static boolean isTableSplit(String tableName)
/*     */     throws Exception
/*     */   {
/* 132 */     return CacheFactory.containsKey(TableSplitCacheImpl.class, tableName);
/*     */   }
/*     */ 
/*     */   public static void createQueryTable(String oldTableName, Map parameters)
/*     */     throws Exception
/*     */   {
/* 142 */     String[] tmpTableName = com.ai.appframe2.util.StringUtils.getParamFromString(oldTableName, "{", "}");
/*     */ 
/* 144 */     if ((tmpTableName == null) || (tmpTableName.length == 0)) {
/* 145 */       return;
/*     */     }
/* 147 */     if (tmpTableName.length != 1)
/*     */     {
/* 150 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.tbname_duplicate", new String[] { oldTableName }));
/*     */     }
/*     */ 
/* 154 */     String tableName = tmpTableName[0];
/*     */ 
/* 156 */     if (parameters == null) {
/* 157 */       parameters = new HashMap();
/*     */     }
/*     */ 
/* 160 */     if (log.isDebugEnabled()) {
/* 161 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.oldtable_info", new String[] { tableName, map2String(parameters) }));
/*     */     }
/*     */ 
/* 164 */     TableSplit objTableSplit = (TableSplit)CacheFactory.get(TableSplitCacheImpl.class, tableName);
/* 165 */     if (objTableSplit == null)
/*     */     {
/* 168 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.miss_table_conf", new String[] { tableName }));
/*     */     }
/*     */ 
/* 171 */     TableSplitMapping[] objTableSplitMapping = (TableSplitMapping[])(TableSplitMapping[])CacheFactory.get(TableSplitMappingCacheImpl.class, tableName);
/* 172 */     if ((objTableSplitMapping == null) || (objTableSplitMapping.length == 0))
/*     */     {
/* 175 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.miss_table_map", new String[] { tableName }));
/*     */     }
/*     */ 
/* 178 */     CrossVar objCrossVar = new CrossVar();
/* 179 */     objCrossVar.setTableName(objTableSplit.getTableName());
/*     */ 
/* 181 */     for (int i = 0; i < objTableSplitMapping.length; ++i) {
/* 182 */       IFunction objFunction = (IFunction)CacheFactory.get(TableSplitFunctionCacheImpl.class, objTableSplitMapping[i].getColumnConvertClass());
/*     */ 
/* 184 */       Object obj = parameters.get(objTableSplitMapping[i].getColumnName());
/* 185 */       if (obj == null) {
/* 186 */         if (objTableSplitMapping[i].getColumnName().equals("REGION_ID")) {
/* 187 */           obj = CenterFactory.getCenterInfo().getRegion();
/* 188 */           if (obj == null)
/*     */           {
/* 191 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */           }
/*     */         }
/* 194 */         else if (objTableSplitMapping[i].getColumnName().equals("REGION_CODE")) {
/* 195 */           obj = CenterFactory.getCenterInfo().getRegion();
/* 196 */           if (obj == null)
/*     */           {
/* 199 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 205 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */         }
/*     */       }
/*     */ 
/* 209 */       String value = objFunction.convert(obj);
/* 210 */       if (value == null)
/*     */       {
/* 213 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */       }
/* 215 */       objCrossVar.addColAndValue(objTableSplitMapping[i].getColumnName(), value);
/*     */     }
/*     */ 
/* 218 */     String newTableName = getTableNameByCrossVar(objCrossVar);
/*     */ 
/* 220 */     if (log.isDebugEnabled()) {
/* 221 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.newtable_info", new String[] { newTableName }));
/*     */     }
/*     */ 
/* 225 */     parameters.put(tableName, newTableName);
/*     */   }
/*     */ 
/*     */   public static String createQuerySQL(String sql, Map parameters)
/*     */     throws Exception
/*     */   {
/* 236 */     String[] tmpTableNames = com.ai.appframe2.util.StringUtils.getParamFromString(sql, "{", "}");
/*     */ 
/* 239 */     if ((tmpTableNames == null) || (tmpTableNames.length == 0)) {
/* 240 */       if (log.isDebugEnabled()) {
/* 241 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.create_sql_info", new String[] { sql }));
/*     */       }
/* 243 */       return sql;
/*     */     }
/*     */ 
/* 246 */     if (parameters == null) {
/* 247 */       parameters = new HashMap();
/*     */     }
/*     */ 
/* 251 */     if (log.isDebugEnabled()) {
/* 252 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.primitive_sql_info", new String[] { sql, map2String(parameters) }));
/*     */     }
/*     */ 
/* 258 */     List crossList = new ArrayList();
/* 259 */     for (int i = 0; i < tmpTableNames.length; ++i) {
/* 260 */       CrossVar objCrossVar = new CrossVar();
/*     */ 
/* 262 */       TableSplit objTableSplit = (TableSplit)CacheFactory.get(TableSplitCacheImpl.class, tmpTableNames[i]);
/* 263 */       if (objTableSplit == null)
/*     */       {
/* 266 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.sql_conf_error", new String[] { tmpTableNames[i], sql }));
/*     */       }
/*     */ 
/* 269 */       TableSplitMapping[] objTableSplitMapping = (TableSplitMapping[])(TableSplitMapping[])CacheFactory.get(TableSplitMappingCacheImpl.class, tmpTableNames[i]);
/* 270 */       if ((objTableSplitMapping == null) || (objTableSplitMapping.length == 0))
/*     */       {
/* 273 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.table_map_error", new String[] { tmpTableNames[i], sql }));
/*     */       }
/*     */ 
/* 276 */       for (int j = 0; j < objTableSplitMapping.length; ++j) {
/* 277 */         IFunction objFunction = (IFunction)CacheFactory.get(TableSplitFunctionCacheImpl.class, objTableSplitMapping[j].getColumnConvertClass());
/*     */ 
/* 279 */         Object obj = parameters.get(objTableSplitMapping[j].getColumnName());
/*     */ 
/* 281 */         if (obj == null) {
/* 282 */           if (objTableSplitMapping[j].getColumnName().equals("REGION_ID")) {
/* 283 */             obj = CenterFactory.getCenterInfo().getRegion();
/* 284 */             if (obj == null)
/*     */             {
/* 287 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[j].getColumnName() }));
/*     */             }
/*     */           }
/* 290 */           else if (objTableSplitMapping[i].getColumnName().equals("REGION_CODE")) {
/* 291 */             obj = CenterFactory.getCenterInfo().getRegion();
/* 292 */             if (obj == null)
/*     */             {
/* 295 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 301 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[j].getColumnName() }));
/*     */           }
/*     */         }
/*     */ 
/* 305 */         String value = objFunction.convert(obj);
/* 306 */         if (value == null)
/*     */         {
/* 309 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[j].getColumnName() }));
/*     */         }
/*     */ 
/* 312 */         objCrossVar.addColAndValue(objTableSplitMapping[j].getColumnName(), value);
/*     */       }
/*     */ 
/* 315 */       objCrossVar.setTableName(objTableSplit.getTableName());
/*     */ 
/* 317 */       crossList.add(objCrossVar);
/*     */     }
/*     */ 
/* 320 */     String newSQL = cross(sql, crossList);
/*     */ 
/* 322 */     if (log.isDebugEnabled()) {
/* 323 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.transforming_sql_info", new String[] { newSQL }));
/*     */     }
/*     */ 
/* 326 */     return newSQL;
/*     */   }
/*     */ 
/*     */   public static String createTableName(String oldTableName, DataContainerInterface objDataContainerInterface)
/*     */     throws Exception
/*     */   {
/* 340 */     String[] tmpTableName = com.ai.appframe2.util.StringUtils.getParamFromString(oldTableName, "{", "}");
/*     */ 
/* 342 */     if ((tmpTableName == null) || (tmpTableName.length == 0)) {
/* 343 */       return oldTableName;
/*     */     }
/* 345 */     if (tmpTableName.length != 1)
/*     */     {
/* 348 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.tbname_duplicate", new String[] { oldTableName }));
/*     */     }
/*     */ 
/* 352 */     String tableName = tmpTableName[0];
/*     */ 
/* 354 */     if (log.isDebugEnabled()) {
/* 355 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.oldtable_info", new String[] { tableName, "" }));
/*     */ 
/* 357 */       StringBuilder sb = new StringBuilder();
/* 358 */       String[] names = objDataContainerInterface.getPropertyNames();
/* 359 */       for (int i = 0; i < names.length; ++i) {
/* 360 */         sb.append("[" + names[i] + " = " + objDataContainerInterface.get(names[i]) + "]  ");
/*     */       }
/* 362 */       log.debug("DC data:" + sb.toString());
/*     */     }
/*     */ 
/* 365 */     TableSplit objTableSplit = (TableSplit)CacheFactory.get(TableSplitCacheImpl.class, tableName);
/* 366 */     if (objTableSplit == null)
/*     */     {
/* 369 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.miss_table_conf", new String[] { tableName }));
/*     */     }
/*     */ 
/* 372 */     TableSplitMapping[] objTableSplitMapping = (TableSplitMapping[])(TableSplitMapping[])CacheFactory.get(TableSplitMappingCacheImpl.class, tableName);
/* 373 */     if ((objTableSplitMapping == null) || (objTableSplitMapping.length == 0))
/*     */     {
/* 376 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.miss_table_map", new String[] { tableName }));
/*     */     }
/*     */ 
/* 379 */     CrossVar objCrossVar = new CrossVar();
/* 380 */     objCrossVar.setTableName(objTableSplit.getTableName());
/*     */ 
/* 382 */     for (int i = 0; i < objTableSplitMapping.length; ++i) {
/* 383 */       IFunction objFunction = (IFunction)CacheFactory.get(TableSplitFunctionCacheImpl.class, objTableSplitMapping[i].getColumnConvertClass());
/*     */ 
/* 385 */       Object obj = objDataContainerInterface.get(objTableSplitMapping[i].getColumnName());
/* 386 */       if (obj == null) {
/* 387 */         if (objTableSplitMapping[i].getColumnName().equals("REGION_ID")) {
/* 388 */           obj = CenterFactory.getCenterInfo().getRegion();
/* 389 */           if (obj == null)
/*     */           {
/* 392 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */           }
/*     */         }
/* 395 */         else if (objTableSplitMapping[i].getColumnName().equals("REGION_CODE")) {
/* 396 */           obj = CenterFactory.getCenterInfo().getRegion();
/* 397 */           if (obj == null)
/*     */           {
/* 400 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column_value", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 406 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */         }
/*     */       }
/*     */ 
/* 410 */       String value = objFunction.convert(obj);
/* 411 */       if (value == null)
/*     */       {
/* 414 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.blank_column", new String[] { objTableSplitMapping[i].getColumnName() }));
/*     */       }
/*     */ 
/* 417 */       if (objTableSplitMapping[i].getColumnName().equals("REGION_ID"))
/*     */       {
/* 419 */         if (objDataContainerInterface.get("REGION_ID") == null) {
/* 420 */           objDataContainerInterface.set("REGION_ID", value);
/*     */         }
/*     */       }
/* 423 */       else if ((objTableSplitMapping[i].getColumnName().equals("REGION_CODE")) && 
/* 425 */         (objDataContainerInterface.get("REGION_CODE") == null)) {
/* 426 */         objDataContainerInterface.set("REGION_CODE", new Long(value));
/*     */       }
/*     */ 
/* 430 */       objCrossVar.addColAndValue(objTableSplitMapping[i].getColumnName(), value);
/*     */     }
/*     */ 
/* 433 */     String newTableName = getTableNameByCrossVar(objCrossVar);
/*     */ 
/* 435 */     if (log.isDebugEnabled()) {
/* 436 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.newtable_info", new String[] { newTableName }));
/*     */     }
/*     */ 
/* 439 */     return newTableName;
/*     */   }
/*     */ 
/*     */   public static String createQuerySQL(String sql, TableVars objSplitVar)
/*     */     throws Exception
/*     */   {
/* 450 */     if (log.isDebugEnabled()) {
/* 451 */       log.debug("The old SQL:" + sql);
/*     */     }
/*     */ 
/* 454 */     String newSQL = cross(sql, objSplitVar.getCrossVar());
/*     */ 
/* 456 */     if (log.isDebugEnabled()) {
/* 457 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.SplitTableFactory.transforming_sql_info", new String[] { newSQL }));
/*     */     }
/*     */ 
/* 460 */     return newSQL;
/*     */   }
/*     */ 
/*     */   private static String cross(String sql, List crossList)
/*     */     throws Exception
/*     */   {
/* 471 */     for (Iterator iter = crossList.iterator(); iter.hasNext(); ) {
/* 472 */       CrossVar item = (CrossVar)iter.next();
/* 473 */       String tableName = getTableNameByCrossVar(item);
/* 474 */       sql = org.apache.commons.lang.StringUtils.replace(sql, "{" + item.getTableName() + "}", tableName);
/*     */     }
/* 476 */     return sql;
/*     */   }
/*     */ 
/*     */   private static String getTableNameByCrossVar(CrossVar objCrossVar)
/*     */     throws Exception
/*     */   {
/* 486 */     TableSplit objTableSplit = (TableSplit)CacheFactory.get(TableSplitCacheImpl.class, objCrossVar.getTableName());
/* 487 */     if (objTableSplit == null)
/*     */     {
/* 490 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.miss_table_conf", new String[] { objCrossVar.getTableName() }));
/*     */     }
/*     */ 
/* 493 */     String expr = objTableSplit.getTableNameExpr();
/*     */ 
/* 495 */     if (expr.indexOf("T[TABLE]") != -1) {
/* 496 */       expr = org.apache.commons.lang.StringUtils.replace(expr, "T[TABLE]", objCrossVar.getTableName());
/*     */     }
/*     */     else {
/* 499 */       String[] customTableNameArray = com.ai.appframe2.util.StringUtils.getParamFromString(expr, "T[", "]");
/* 500 */       if ((customTableNameArray != null) && (customTableNameArray.length == 1)) {
/* 501 */         String customTableName = customTableNameArray[0];
/* 502 */         expr = org.apache.commons.lang.StringUtils.replace(expr, "T[" + customTableName + "]", customTableName.trim());
/*     */       }
/*     */       else {
/* 505 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.split.custom_table_conf", new String[] { objCrossVar.getTableName() }));
/*     */       }
/*     */     }
/*     */ 
/* 509 */     HashMap map = objCrossVar.getColsAndValues();
/* 510 */     Set cols = map.keySet();
/* 511 */     for (Iterator iter = cols.iterator(); iter.hasNext(); ) {
/* 512 */       String item = (String)iter.next();
/* 513 */       expr = org.apache.commons.lang.StringUtils.replace(expr, "C[" + item + "]", (String)map.get(item));
/*     */     }
/*     */ 
/* 519 */     String realTableName = getDyncTableName(objCrossVar.getTableName(), expr);
/*     */ 
/* 521 */     return realTableName;
/*     */   }
/*     */ 
/*     */   private static String map2String(Map map)
/*     */   {
/* 530 */     StringBuilder sb = new StringBuilder();
/*     */     Iterator iter;
/* 531 */     if (map == null) {
/* 532 */       sb.append("No parameter.");
/*     */     }
/* 534 */     else if (map.size() == 0) {
/* 535 */       sb.append("Empty parameters.");
/*     */     }
/*     */     else {
/* 538 */       sb.append("Parameter | ");
/* 539 */       Set key = map.keySet();
/* 540 */       for (iter = key.iterator(); iter.hasNext(); ) {
/* 541 */         Object item = iter.next();
/* 542 */         Object value = map.get(item);
/* 543 */         sb.append(((item == null) ? " null" : item.toString()) + "=" + ((value == null) ? " null" : value.toString()) + ",Class type:" + ((value == null) ? " null" : value.getClass().toString()) + " | ");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 551 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static void main2(String[] args) throws Exception {
/* 555 */     String str = "abc = :bb and deg = :aa and dd = :bb ";
/* 556 */     String[] list = com.ai.appframe2.util.StringUtils.getParamFromString(str, ":", " ");
/* 557 */     String result = com.ai.appframe2.util.StringUtils.replaceParamString(str, list, " ? ", ":", " ");
/* 558 */     System.out.println(str);
/* 559 */     for (int i = 0; i < list.length; ++i)
/* 560 */       System.out.println(list[i].toString());
/* 561 */     System.out.println(result);
/*     */   }
/*     */ 
/*     */   public static void main3(String[] args) throws Exception {
/* 565 */     String sql = "select * from {INSTANCE_PRODUCT} a,{CUSTOMER} c where a=:a";
/* 566 */     TableVars obj = new TableVars();
/* 567 */     obj.add("INSTANCE_PRODUCT", "REGION_ID", "371").add("INSTANCE_PRODUCT", "INSTANCE_PRODUCT_ID", "12345670").add("CUSTOMER", "REGION_ID", "372").add("CUSTOMER", "REGION_ID", "379");
/*     */ 
/* 571 */     createQuerySQL(sql, obj);
/*     */ 
/* 573 */     long start = System.currentTimeMillis();
/*     */ 
/* 575 */     for (int i = 0; i < 10000; ++i) {
/* 576 */       createQuerySQL(sql, obj);
/*     */     }
/* 578 */     System.out.println("Time-consuming:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 582 */     String sql = "select * from {TEST_ACCT} a where a=:a";
/* 583 */     HashMap map = new HashMap();
/* 584 */     map.put("REGION_ID", "371");
/* 585 */     map.put("INSTANCE_PRODUCT_ID", "12345670");
/* 586 */     createQuerySQL(sql, map);
/*     */   }
/*     */ 
/*     */   public static void main1(String[] args)
/*     */     throws Exception
/*     */   {
/* 597 */     String sql = "{INSTANCE_PRODUCT}";
/* 598 */     DataContainer map = new DataContainer();
/* 599 */     map.set("REGION_ID", "371");
/* 600 */     map.set("INSTANCE_PRODUCT_ID", "12345670");
/* 601 */     System.out.println(createTableName(sql, map));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.split.SplitTableFactory
 * JD-Core Version:    0.5.4
 */