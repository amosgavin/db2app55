/*    */ package com.ai.appframe2.complex.tab.store;
/*    */ 
/*    */ public class DefaultCenterRegionImpl
/*    */   implements ICenterRegion
/*    */ {
/*    */   public String getCenterByRegionId(String regionId)
/*    */     throws Exception
/*    */   {
/* 27 */     return "";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.DefaultCenterRegionImpl
 * JD-Core Version:    0.5.4
 */