/*     */ package com.ai.appframe2.complex.tab.store;
/*     */ 
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataSaveBean
/*     */ {
/*  25 */   private static transient Log log = LogFactory.getLog(DataSaveBean.class);
/*     */ 
/*  27 */   private Map tempMap = null;
/*     */ 
/*     */   public DataSaveBean() {
/*  30 */     this.tempMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public void add(Object key, DataContainerInterface dc)
/*     */   {
/*  40 */     if (this.tempMap.containsKey(key)) {
/*  41 */       ArrayList list = (ArrayList)this.tempMap.get(key);
/*  42 */       list.add(dc);
/*     */     }
/*     */     else {
/*  45 */       ArrayList list = new ArrayList();
/*  46 */       list.add(dc);
/*  47 */       this.tempMap.put(key, list);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Object key, DataContainerInterface[] dc)
/*     */   {
/*  58 */     if (this.tempMap.containsKey(key)) {
/*  59 */       ArrayList list = (ArrayList)this.tempMap.get(key);
/*  60 */       for (int i = 0; i < dc.length; ++i)
/*  61 */         list.add(dc[i]);
/*     */     }
/*     */     else
/*     */     {
/*  65 */       ArrayList list = new ArrayList();
/*  66 */       for (int i = 0; i < dc.length; ++i) {
/*  67 */         list.add(dc[i]);
/*     */       }
/*  69 */       this.tempMap.put(key, list);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void add(Object key, ArrayList tmpList)
/*     */   {
/*  82 */     if (this.tempMap.containsKey(key)) {
/*  83 */       ArrayList list = (ArrayList)this.tempMap.get(key);
/*  84 */       for (int i = 0; i < tmpList.size(); ++i)
/*  85 */         list.add(tmpList.get(i));
/*     */     }
/*     */     else
/*     */     {
/*  89 */       ArrayList list = new ArrayList();
/*  90 */       for (int i = 0; i < tmpList.size(); ++i) {
/*  91 */         list.add(tmpList.get(i));
/*     */       }
/*  93 */       this.tempMap.put(key, list);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear(Object key)
/*     */   {
/* 102 */     if (this.tempMap.containsKey(key)) {
/* 103 */       ((List)this.tempMap.get(key)).clear();
/*     */     }
/*     */     else
/* 106 */       log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.tab.store.DataSaveBean.container_warn", new String[] { key.toString() }));
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 114 */     this.tempMap.clear();
/*     */   }
/*     */ 
/*     */   public int save()
/*     */     throws Exception
/*     */   {
/* 123 */     int size = 0;
/*     */     try {
/* 125 */       ArrayList[] list = (ArrayList[])(ArrayList[])this.tempMap.values().toArray(new ArrayList[0]);
/*     */ 
/* 127 */       for (int i = 0; i < list.length; ++i) {
/* 128 */         DataContainerInterface[] obj = (DataContainerInterface[])(DataContainerInterface[])list[i].toArray(new DataContainerInterface[0]);
/* 129 */         if ((obj != null) && (obj.length != 0)) {
/* 130 */           BatchSaveHelper.saveListBeansWithBatch(obj);
/* 131 */           size += obj.length;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 138 */       throw e;
/*     */     }
/*     */     finally {
/* 141 */       clear();
/*     */     }
/* 143 */     return size;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 151 */     StringBuilder sb = new StringBuilder();
/* 152 */     ArrayList[] list = (ArrayList[])(ArrayList[])this.tempMap.values().toArray(new ArrayList[0]);
/*     */ 
/* 155 */     for (int i = 0; i < list.length; ++i) {
/* 156 */       sb.append("Element:[").append(list[i].get(0).getClass().getName()).append("]Size[").append(list[i].size()).append("]\n");
/*     */     }
/*     */ 
/* 160 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.store.DataSaveBean
 * JD-Core Version:    0.5.4
 */