/*    */ package com.ai.appframe2.complex.tab.split;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class TableVars
/*    */ {
/* 22 */   private HashMap map = new HashMap();
/*    */ 
/*    */   public TableVars add(String tablePrefixName, String columnName, String value)
/*    */     throws Exception
/*    */   {
/* 36 */     if ((StringUtils.isBlank(tablePrefixName)) || (StringUtils.isBlank(columnName)) || (StringUtils.isBlank(value)))
/*    */     {
/* 39 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.null_parameter_error") + ".tablePrefixName[" + tablePrefixName + "] columnName[" + columnName + "] value[" + value + "]");
/*    */     }
/*    */ 
/* 42 */     if (this.map.containsKey(tablePrefixName)) {
/* 43 */       CrossVar obj = (CrossVar)this.map.get(tablePrefixName);
/* 44 */       obj.addColAndValue(columnName, value);
/* 45 */       this.map.put(tablePrefixName, obj);
/*    */     }
/*    */     else {
/* 48 */       CrossVar obj = new CrossVar();
/* 49 */       obj.setTableName(tablePrefixName);
/* 50 */       obj.addColAndValue(columnName, value);
/* 51 */       this.map.put(tablePrefixName, obj);
/*    */     }
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   public List getCrossVar()
/*    */   {
/* 61 */     return new ArrayList(this.map.values());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.split.TableVars
 * JD-Core Version:    0.5.4
 */