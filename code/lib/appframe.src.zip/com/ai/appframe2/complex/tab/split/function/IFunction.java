package com.ai.appframe2.complex.tab.split.function;

public abstract interface IFunction
{
  public abstract String convert(Object paramObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.tab.split.function.IFunction
 * JD-Core Version:    0.5.4
 */