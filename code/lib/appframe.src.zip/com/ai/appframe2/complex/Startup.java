/*     */ package com.ai.appframe2.complex;
/*     */ 
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.self.service.check.interfaces.ICheckSV;
/*     */ import com.ai.appframe2.complex.service.impl.DefaultClientServiceInvokeImpl;
/*     */ import com.ai.appframe2.complex.service.impl.DefaultServerServiceInvokeImpl;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Proxy;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.ClassUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Startup
/*     */ {
/*  29 */   private static transient Log log = LogFactory.getLog(Startup.class);
/*     */   private static final String CLASS_TYPE = "CLASS";
/*     */   private static final String ID_TYPE = "ID";
/*     */ 
/*     */   public static void startupByAsyn()
/*     */   {
/*  41 */     Thread t = new StartupThread(null);
/*     */ 
/*  43 */     t.setName(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.pre"));
/*  44 */     t.setDaemon(true);
/*  45 */     t.start();
/*     */   }
/*     */ 
/*     */   public static void startup()
/*     */   {
/*  52 */     if (log.isDebugEnabled()) {
/*  53 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init"));
/*     */     }
/*     */ 
/*  59 */     for (int i = 0; i < 50; ++i) {
/*     */       try {
/*  61 */         ICheckSV objICheckSV = (ICheckSV)ServiceFactory.getService(ICheckSV.class);
/*  62 */         objICheckSV.heartbeat();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*  66 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_error"), ex);
/*  67 */         return;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  72 */     String clazzName = null;
/*     */     try {
/*  74 */       clazzName = XMLHelper.getInstance().getDefaults().getProxy().getClazz().getName();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  78 */       log.error(AppframeLocaleFactory.getResource("om.ai.appframe2.complex.Startup.init_serivce_obtain_error"), ex);
/*  79 */       return;
/*     */     }
/*     */     try
/*     */     {
/*  83 */       if ((!StringUtils.isBlank(clazzName)) && (ClassUtils.isAssignable(Class.forName(clazzName), DefaultClientServiceInvokeImpl.class)))
/*     */       {
/*  85 */         for (int i = 0; i < 20; ++i) {
/*     */           try {
/*  87 */             ICheckSV objICheckSV = (ICheckSV)ServiceFactory.getCrossCenterService(ICheckSV.class);
/*  88 */             objICheckSV.heartbeat();
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/*  92 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_error"), ex);
/*  93 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 100 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_error"), ex);
/* 101 */       return;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 106 */       if ((!StringUtils.isBlank(clazzName)) && (ClassUtils.isAssignable(Class.forName(clazzName), DefaultServerServiceInvokeImpl.class))) {
/*     */         Iterator iter;
/*     */         try {
/* 109 */           Properties p1 = new Properties();
/* 110 */           InputStream init1 = Thread.currentThread().getContextClassLoader().getResourceAsStream("sv_init_class.txt");
/* 111 */           if (init1 != null) {
/* 112 */             System.out.println("Use sv_init_class.txt file");
/* 113 */             p1.load(init1);
/*     */           }
/*     */           else {
/* 116 */             InputStream i1 = Thread.currentThread().getContextClassLoader().getResourceAsStream("sv_class.txt");
/* 117 */             if (i1 != null) {
/* 118 */               p1.load(i1);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 123 */           Properties p2 = new Properties();
/* 124 */           InputStream init2 = Thread.currentThread().getContextClassLoader().getResourceAsStream("sv_init_id.txt");
/* 125 */           if (init2 != null) {
/* 126 */             System.out.println("Use sv_init_id.txt file");
/* 127 */             p2.load(init2);
/*     */           }
/*     */           else {
/* 130 */             InputStream i2 = Thread.currentThread().getContextClassLoader().getResourceAsStream("sv_id.txt");
/* 131 */             if (i2 != null) {
/* 132 */               p2.load(i2);
/*     */             }
/*     */           }
/*     */ 
/* 136 */           if ((p1.size() != 0) && (p2.size() != 0)) {
/* 137 */             Set keys_p1 = p1.keySet();
/* 138 */             for (Iterator iter = keys_p1.iterator(); iter.hasNext(); ) {
/* 139 */               String item = (String)iter.next();
/* 140 */               ejbCall("CLASS", item);
/*     */             }
/*     */ 
/* 143 */             Set keys_p2 = p2.keySet();
/* 144 */             for (iter = keys_p2.iterator(); iter.hasNext(); ) {
/* 145 */               String item = (String)iter.next();
/* 146 */               ejbCall("ID", item);
/*     */             }
/*     */           }
/*     */         }
/*     */         catch (Throwable ex) {
/* 151 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_ejb_error"), ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 156 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_ejb_error"), ex);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 161 */       Class.forName(CacheFactory.class.getName());
/*     */     }
/*     */     catch (Exception ex) {
/* 164 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_cache_error", new String[] { CacheFactory.class.getName() }), ex);
/* 165 */       return;
/*     */     }
/*     */ 
/* 168 */     if (log.isDebugEnabled()) {
/* 169 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_cahce_complete"));
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 174 */       Class.forName(CenterFactory.class.getName());
/*     */     }
/*     */     catch (Exception ex) {
/* 177 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_center_error", new String[] { CenterFactory.class.getName() }), ex);
/* 178 */       return;
/*     */     }
/*     */ 
/* 181 */     if (log.isDebugEnabled()) {
/* 182 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_center_complete"));
/*     */     }
/*     */ 
/* 185 */     if (!log.isDebugEnabled())
/*     */       return;
/* 187 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.init_serivce_complete"));
/*     */   }
/*     */ 
/*     */   private static void ejbCall(String type, String obj)
/*     */   {
/*     */     try
/*     */     {
/* 201 */       if (type.equalsIgnoreCase("CLASS")) {
/* 202 */         ServiceFactory.getService(Class.forName(obj.trim()));
/* 203 */         if (log.isDebugEnabled()) {
/* 204 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.ejbCall.success", new String[] { obj.trim() }));
/*     */         }
/*     */ 
/*     */       }
/* 208 */       else if (type.equalsIgnoreCase("ID")) {
/* 209 */         ServiceFactory.getService(obj.trim());
/* 210 */         if (log.isDebugEnabled())
/* 211 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.ejbCall.success", new String[] { obj.trim() }));
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 216 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.ejbCall.error"), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 243 */     startupByAsyn();
/* 244 */     System.out.println("===============");
/* 245 */     Thread.currentThread(); Thread.sleep(100000L);
/*     */   }
/*     */ 
/*     */   private static class StartupThread extends Thread
/*     */   {
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/* 232 */         Startup.startup();
/*     */       }
/*     */       catch (Throwable ex) {
/* 235 */         Startup.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.Startup.run.error"), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.Startup
 * JD-Core Version:    0.5.4
 */