/*    */ package com.ai.appframe2.complex.center.mc.function;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ 
/*    */ public class NumberFunctionImpl
/*    */   implements IFunction
/*    */ {
/*    */   public String getValue(Object obj)
/*    */     throws Exception
/*    */   {
/* 29 */     if (obj == null) {
/* 30 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.function.in_para_is_null"));
/*    */     }
/*    */ 
/* 33 */     return obj.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.mc.function.NumberFunctionImpl
 * JD-Core Version:    0.5.4
 */