package com.ai.appframe2.complex.center.interfaces;

import com.ai.appframe2.complex.center.CenterInfo;

public abstract interface ICenter
{
  public abstract CenterInfo getCenterByValue(String paramString)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.interfaces.ICenter
 * JD-Core Version:    0.5.4
 */