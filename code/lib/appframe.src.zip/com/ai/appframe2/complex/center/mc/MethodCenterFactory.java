/*    */ package com.ai.appframe2.complex.center.mc;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class MethodCenterFactory
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(MethodCenterFactory.class);
/*    */ 
/* 26 */   private static IMethodCenter METHOD_CENTER_INSTANCE = null;
/*    */ 
/*    */   public static IMethodCenter getMethodCenter()
/*    */   {
/* 74 */     return METHOD_CENTER_INSTANCE;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 31 */       String strSrvControlImplClass = AIConfigManager.getConfigItem("METHOD_CENTER_IMPL_CLASS");
/* 32 */       if (!StringUtils.isBlank(strSrvControlImplClass)) {
/*    */         try {
/* 34 */           Object custObject = Class.forName(strSrvControlImplClass.trim()).newInstance();
/* 35 */           if (custObject instanceof IMethodCenter) {
/* 36 */             METHOD_CENTER_INSTANCE = (IMethodCenter)custObject;
/*    */           }
/*    */           else
/* 39 */             METHOD_CENTER_INSTANCE = null;
/*    */         }
/*    */         catch (Throwable ex)
/*    */         {
/* 43 */           METHOD_CENTER_INSTANCE = null;
/* 44 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.factory.method_center_impl_error"), ex);
/*    */         }
/*    */       }
/*    */       else
/* 48 */         METHOD_CENTER_INSTANCE = null;
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 52 */       METHOD_CENTER_INSTANCE = null;
/* 53 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.factory.method_center_impl_error"), ex);
/*    */     }
/*    */     finally {
/* 56 */       if (METHOD_CENTER_INSTANCE != null) {
/* 57 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.factory.method_center_impl_class", new String[] { METHOD_CENTER_INSTANCE.getClass().toString() }));
/*    */       }
/*    */       else
/* 60 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.factory.method_center_impl_class_not_config"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.mc.MethodCenterFactory
 * JD-Core Version:    0.5.4
 */