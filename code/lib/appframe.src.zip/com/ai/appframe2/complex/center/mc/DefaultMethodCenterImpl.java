/*     */ package com.ai.appframe2.complex.center.mc;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.impl.MethodCenterCacheImpl;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.center.mc.function.IFunction;
/*     */ import com.ai.appframe2.complex.self.po.MethodCenter;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultMethodCenterImpl
/*     */   implements IMethodCenter
/*     */ {
/*  31 */   private static transient Log log = LogFactory.getLog(DefaultMethodCenterImpl.class);
/*  32 */   private static Map FUNCTION_MAP = new HashMap();
/*  33 */   private static Boolean IS_LOCAL = null;
/*     */ 
/*     */   public Object startMethodCenter(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/*  81 */     MethodCenterObject rtn = new MethodCenterObject(null);
/*     */ 
/*  83 */     if ((objectArray == null) || (objectArray.length == 0)) {
/*  84 */       return rtn;
/*     */     }
/*     */ 
/*  87 */     if (IS_LOCAL.equals(Boolean.TRUE))
/*     */     {
/*  90 */       String key = getKey(obj, methodName, objectArray);
/*  91 */       MethodCenter objMethodCenter = (MethodCenter)CacheFactory.get(MethodCenterCacheImpl.class, key);
/*  92 */       if (objMethodCenter != null) {
/*  93 */         if (CenterFactory.isSetCenterInfo()) {
/*  94 */           MethodCenterObject.access$102(rtn, true);
/*  95 */           MethodCenterObject.access$202(rtn, CenterFactory.getCenterInfo());
/*     */         }
/*     */         else {
/*  98 */           MethodCenterObject.access$102(rtn, true);
/*  99 */           MethodCenterObject.access$202(rtn, null);
/*     */         }
/*     */ 
/* 102 */         if (log.isDebugEnabled()) {
/* 103 */           if (rtn.oldCenterInfo != null) {
/* 104 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.local_before_method_1", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)), MethodCenterObject.access$200(rtn).toString() }));
/*     */           }
/*     */           else
/*     */           {
/* 108 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.local_before_method_2", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)) }));
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 113 */         CenterFactory.setCenterInfoByTypeAndValue(objMethodCenter.getCenterType(), getCenterValue(objMethodCenter, objectArray));
/*     */ 
/* 115 */         if (log.isDebugEnabled()) {
/* 116 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.local_after_method", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)), CenterFactory.getCenterInfo().toString() }));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 138 */       String key = getKey(obj, methodName, objectArray);
/* 139 */       MethodCenter objMethodCenter = (MethodCenter)CacheFactory.get(MethodCenterCacheImpl.class, key);
/* 140 */       if (objMethodCenter != null) {
/* 141 */         if (CenterFactory.isSetCenterInfo()) {
/* 142 */           MethodCenterObject.access$102(rtn, true);
/* 143 */           MethodCenterObject.access$202(rtn, CenterFactory.getCenterInfo());
/*     */         }
/*     */         else {
/* 146 */           MethodCenterObject.access$102(rtn, true);
/* 147 */           MethodCenterObject.access$202(rtn, null);
/*     */         }
/*     */ 
/* 150 */         if (log.isDebugEnabled()) {
/* 151 */           if (rtn.oldCenterInfo != null) {
/* 152 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.server_before_method_1", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)), MethodCenterObject.access$200(rtn).toString() }));
/*     */           }
/*     */           else {
/* 155 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.server_before_method_2", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)) }));
/*     */           }
/*     */         }
/*     */ 
/* 159 */         CenterFactory.setCenterInfoByTypeAndValue(objMethodCenter.getCenterType(), getCenterValue(objMethodCenter, objectArray));
/*     */ 
/* 161 */         if (log.isDebugEnabled()) {
/* 162 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.server_after_method", new String[] { obj.getClass().getName(), methodName, String.valueOf(getParametersLength(objectArray)), CenterFactory.getCenterInfo().toString() }));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 178 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void endMethodCenter(Object obj)
/*     */     throws Exception
/*     */   {
/* 187 */     MethodCenterObject objMethodCenterObject = (MethodCenterObject)obj;
/* 188 */     if (objMethodCenterObject.isNeedMethodCenter) {
/* 189 */       CenterInfo centerInfo = objMethodCenterObject.oldCenterInfo;
/* 190 */       if (centerInfo != null) {
/* 191 */         CenterFactory.setDirectCenterInfo(centerInfo);
/*     */       }
/*     */       else
/* 194 */         CenterFactory.setCenterInfoEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String getKey(Object obj, String methodName, Object[] objectArray)
/*     */   {
/* 209 */     StringBuilder sb = new StringBuilder();
/* 210 */     return obj.getClass().getName() + "." + methodName + "." + getParametersLength(objectArray);
/*     */   }
/*     */ 
/*     */   private static int getParametersLength(Object[] objectArray)
/*     */   {
/* 219 */     if ((objectArray == null) || (objectArray.length == 0)) {
/* 220 */       return 0;
/*     */     }
/*     */ 
/* 223 */     return objectArray.length;
/*     */   }
/*     */ 
/*     */   private static String getCenterValue(MethodCenter objMethodCenter, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 235 */     if (objMethodCenter.getParameterIndex() > getParametersLength(objectArray) - 1) {
/* 236 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.parameter_length_error"));
/*     */     }
/*     */ 
/* 239 */     IFunction objIFunction = (IFunction)FUNCTION_MAP.get(objMethodCenter.getParameterFunction());
/* 240 */     if (objIFunction == null) {
/* 241 */       synchronized (FUNCTION_MAP) {
/* 242 */         if (!FUNCTION_MAP.containsKey(objMethodCenter.getParameterFunction())) {
/* 243 */           IFunction tmp = (IFunction)Class.forName(objMethodCenter.getParameterFunction()).newInstance();
/* 244 */           FUNCTION_MAP.put(objMethodCenter.getParameterFunction(), tmp);
/*     */         }
/* 246 */         objIFunction = (IFunction)FUNCTION_MAP.get(objMethodCenter.getParameterFunction());
/*     */       }
/*     */     }
/*     */ 
/* 250 */     if (objIFunction == null) {
/* 251 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.not_found_function", new String[] { objMethodCenter.getParameterFunction() }));
/*     */     }
/*     */ 
/* 254 */     return objIFunction.getValue(objectArray[objMethodCenter.getParameterIndex()]);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  37 */       String methodCenterType = AIConfigManager.getConfigItem("METHOD_CENTER_TYPE");
/*  38 */       if (!StringUtils.isBlank(methodCenterType)) {
/*  39 */         if (methodCenterType.trim().equalsIgnoreCase("local")) {
/*  40 */           IS_LOCAL = Boolean.TRUE; break label112:
/*     */         }
/*  42 */         if (methodCenterType.trim().equalsIgnoreCase("server")) {
/*  43 */           IS_LOCAL = Boolean.FALSE; break label112:
/*     */         }
/*     */ 
/*  46 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.in_local_server", new String[] { methodCenterType }));
/*     */       }
/*     */ 
/*  50 */       label112: throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.no_method_center_type"));
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  58 */       if (IS_LOCAL != null)
/*  59 */         if (IS_LOCAL.equals(Boolean.TRUE)) {
/*  60 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.is_local"));
/*     */         }
/*     */         else
/*  63 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.mc.is_server"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MethodCenterObject
/*     */   {
/*     */     private boolean isNeedMethodCenter;
/*     */     private CenterInfo oldCenterInfo;
/*     */ 
/*     */     private MethodCenterObject()
/*     */     {
/* 258 */       this.isNeedMethodCenter = false;
/* 259 */       this.oldCenterInfo = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.mc.DefaultMethodCenterImpl
 * JD-Core Version:    0.5.4
 */