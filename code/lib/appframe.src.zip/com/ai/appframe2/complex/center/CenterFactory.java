/*     */ package com.ai.appframe2.complex.center;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.complex.center.interfaces.ICenter;
/*     */ import com.ai.appframe2.complex.secframe.ICenterUserInfo;
/*     */ import com.ai.appframe2.complex.secframe.NullCenterUserInfoImpl;
/*     */ import com.ai.appframe2.complex.util.JVMID;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Center;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class CenterFactory
/*     */ {
/*  30 */   private static transient Log log = LogFactory.getLog(CenterFactory.class);
/*     */   public static final String SPLIT = ":";
/*     */   public static final String CENTER_TYPE = "CenterType";
/*     */   public static final String CENTER_VALUE = "CenterValue";
/*     */   public static final String CROSS_CENTER = "CrossCenter";
/*  37 */   private static final HashMap INSTANCE = new HashMap();
/*  38 */   private static final ThreadLocal CENTER_INFO = new ThreadLocal();
/*     */ 
/*     */   public static void setCenterInfoEmpty()
/*     */   {
/*  93 */     CENTER_INFO.set(null);
/*  94 */     if (!log.isDebugEnabled())
/*     */       return;
/*  96 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.setcenter_empty"));
/*     */   }
/*     */ 
/*     */   public static void setCenterInfoByTypeAndValue(String type, String value)
/*     */     throws Exception
/*     */   {
/* 107 */     ICenter centerImpl = (ICenter)INSTANCE.get(type);
/* 108 */     if (centerImpl == null)
/*     */     {
/* 111 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.no_center_impl", new String[] { type }));
/*     */     }
/* 113 */     CENTER_INFO.set(centerImpl.getCenterByValue(value));
/* 114 */     if (!log.isDebugEnabled())
/*     */       return;
/* 116 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.setcenter_bytype", new String[] { type, value, getCenterInfo().toString() }));
/*     */   }
/*     */ 
/*     */   public static void setDirectCenterInfo(CenterInfo objCenterInfo)
/*     */   {
/* 126 */     CENTER_INFO.set(objCenterInfo);
/* 127 */     if (!log.isDebugEnabled())
/*     */       return;
/* 129 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.setcenter", new String[] { getCenterInfo().toString() }));
/*     */   }
/*     */ 
/*     */   public static CenterInfo getCenterInfo()
/*     */   {
/* 138 */     if (CENTER_INFO.get() == null)
/*     */     {
/* 141 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.notset_center_conf"));
/*     */     }
/* 143 */     return (CenterInfo)CENTER_INFO.get();
/*     */   }
/*     */ 
/*     */   public static boolean isSetCenterInfo()
/*     */   {
/* 151 */     boolean rtn = false;
/* 152 */     if (CENTER_INFO.get() != null) {
/* 153 */       rtn = true;
/*     */     }
/* 155 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static UserInfoInterface _centerInfoJoinUserInfo(UserInfoInterface objUserInfoInterface)
/*     */   {
/* 168 */     if (objUserInfoInterface == null) {
/* 169 */       objUserInfoInterface = new NullCenterUserInfoImpl();
/*     */     }
/*     */ 
/* 172 */     ICenterUserInfo objICenterUserInfo = (ICenterUserInfo)objUserInfoInterface;
/*     */ 
/* 176 */     if (isSetCenterInfo()) {
/* 177 */       objICenterUserInfo.setCenterInfo(getCenterInfo());
/*     */     }
/*     */     else {
/* 180 */       objICenterUserInfo.setCenterInfo(null);
/*     */     }
/*     */ 
/* 184 */     objICenterUserInfo.setJvmid(JVMID.getLocalJVMID());
/*     */ 
/* 186 */     return (UserInfoInterface)objICenterUserInfo;
/*     */   }
/*     */ 
/*     */   public static void _centerInfoLeavUserInfo(UserInfoInterface objUserInfoInterface)
/*     */   {
/* 194 */     ICenterUserInfo objICenterUserInfo = (ICenterUserInfo)objUserInfoInterface;
/*     */ 
/* 196 */     if (JVMID.getLocalJVMID().equals(objICenterUserInfo.getJvmid()))
/*     */     {
/* 198 */       if (!log.isDebugEnabled())
/*     */         return;
/* 200 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.server_call_server_noset"));
/*     */     }
/*     */     else
/*     */     {
/* 205 */       if (log.isDebugEnabled())
/*     */       {
/* 207 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.clinet_call_server_noset"));
/*     */       }
/*     */ 
/* 211 */       if (isSetCenterInfo()) {
/* 212 */         if (log.isInfoEnabled())
/*     */         {
/* 214 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.exec_over_centerinfo"));
/*     */         }
/* 216 */         setCenterInfoEmpty();
/*     */       }
/*     */ 
/* 220 */       ServiceManager.setServiceUserInfo(null);
/*     */ 
/* 223 */       if (!objUserInfoInterface instanceof NullCenterUserInfoImpl) {
/* 224 */         ServiceManager.setServiceUserInfo(objUserInfoInterface);
/*     */       }
/*     */       else {
/* 227 */         ServiceManager.setServiceUserInfo(null);
/*     */       }
/*     */ 
/* 231 */       CenterInfo centerInfo = ((ICenterUserInfo)objUserInfoInterface).getCenterInfo();
/* 232 */       if (centerInfo != null)
/* 233 */         setDirectCenterInfo(centerInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static CenterInfo createCenterInfoByTypeAndValue(String type, String value)
/*     */     throws Exception
/*     */   {
/* 248 */     ICenter centerImpl = (ICenter)INSTANCE.get(type);
/* 249 */     if (centerImpl == null)
/*     */     {
/* 252 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.no_center_impl", new String[] { type }));
/*     */     }
/*     */ 
/* 255 */     return centerImpl.getCenterByValue(value);
/*     */   }
/*     */ 
/*     */   public static void pushCenterInfoDirect(CenterInfo objCenterInfo)
/*     */   {
/* 263 */     setDirectCenterInfo(objCenterInfo);
/*     */   }
/*     */ 
/*     */   public static CenterInfo peekCenterInfo()
/*     */   {
/* 271 */     return getCenterInfo();
/*     */   }
/*     */ 
/*     */   public static void popCenterInfo()
/*     */   {
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  42 */       Center center = XMLHelper.getInstance().getDefaults().getCenter();
/*  43 */       Property[] property = center.getProperties();
/*  44 */       for (int i = 0; i < property.length; ++i)
/*     */       {
/*  46 */         if (StringUtils.contains(property[i].getName(), ":")) {
/*  47 */           String[] types = StringUtils.split(property[i].getName(), ":");
/*  48 */           Object object = Class.forName(property[i].getValue().trim()).newInstance();
/*  49 */           for (int j = 0; j < types.length; ++j)
/*  50 */             if (!INSTANCE.containsKey(types[j].trim())) {
/*  51 */               INSTANCE.put(types[j].trim(), object);
/*  52 */               if (!log.isDebugEnabled())
/*     */                 continue;
/*  54 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.instance_start_log", new String[] { types[j].trim(), property[i].getValue().trim(), object.toString() }));
/*     */             }
/*     */             else
/*     */             {
/*  59 */               log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.instanced_log", new String[] { property[i].getName().trim() }));
/*     */             }
/*     */         }
/*     */         else
/*     */         {
/*  64 */           Object object = Class.forName(property[i].getValue().trim()).newInstance();
/*  65 */           if (!INSTANCE.containsKey(property[i].getName().trim())) {
/*  66 */             INSTANCE.put(property[i].getName().trim(), object);
/*  67 */             if (!log.isDebugEnabled())
/*     */               continue;
/*  69 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.instance_start_log", new String[] { property[i].getName().trim(), property[i].getValue().trim(), object.toString() }));
/*     */           }
/*     */           else
/*     */           {
/*  74 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.instanced_log", new String[] { property[i].getName().trim() }));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  81 */       log.error(ex.getMessage(), ex);
/*  82 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.CenterFactory
 * JD-Core Version:    0.5.4
 */