package com.ai.appframe2.complex.center.mc;

public abstract interface IMethodCenter
{
  public abstract Object startMethodCenter(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;

  public abstract void endMethodCenter(Object paramObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.mc.IMethodCenter
 * JD-Core Version:    0.5.4
 */