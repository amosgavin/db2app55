package com.ai.appframe2.complex.center.mc.function;

public abstract interface IFunction
{
  public abstract String getValue(Object paramObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.mc.function.IFunction
 * JD-Core Version:    0.5.4
 */