/*    */ package com.ai.appframe2.complex.center;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.JVMID;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class CenterInfo
/*    */   implements Serializable
/*    */ {
/* 18 */   private String center = null;
/* 19 */   private String regionId = null;
/* 20 */   private String jvmid = null;
/*    */ 
/*    */   public CenterInfo(String center, String regionId)
/*    */   {
/* 28 */     this.center = center;
/* 29 */     this.regionId = regionId;
/* 30 */     this.jvmid = JVMID.getLocalJVMID();
/*    */   }
/*    */ 
/*    */   public String getCenter()
/*    */   {
/* 39 */     return this.center;
/*    */   }
/*    */ 
/*    */   public String getRegion()
/*    */   {
/* 47 */     return this.regionId;
/*    */   }
/*    */ 
/*    */   public String getJVMID()
/*    */   {
/* 55 */     return this.jvmid;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 59 */     String rtn = null;
/* 60 */     if (JVMID.getLocalJVMID().equals(this.jvmid))
/*    */     {
/* 62 */       rtn = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.self_set_center", new String[] { this.center, this.regionId });
/*    */     }
/*    */     else
/*    */     {
/* 66 */       rtn = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.notset_center_self", new String[] { this.center, this.regionId });
/*    */     }
/* 68 */     return rtn;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.center.CenterInfo
 * JD-Core Version:    0.5.4
 */