/*     */ package com.ai.appframe2.complex.service.proxy.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.trace.TraceFactory;
/*     */ import com.ai.appframe2.complex.trace.impl.DaoTrace;
/*     */ import com.ai.appframe2.complex.util.StringLengthDescComparator;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.DataSource;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Mapping;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DAODataSourceInterceptorImpl
/*     */   implements AroundMethodInterceptor
/*     */ {
/*  38 */   private static transient Log log = LogFactory.getLog(DAODataSourceInterceptorImpl.class);
/*     */ 
/*  41 */   private static final ThreadLocal TMP_MAPPING = new ThreadLocal();
/*     */   private static final String NULL = "NULL";
/*  46 */   private static Map CLAZZ_DATASOURCE_CACHE = new HashMap();
/*     */ 
/*  48 */   private static final HashMap DAO_SCOPE = new HashMap();
/*  49 */   private static String[] KEYS = null;
/*     */ 
/*  51 */   private String previousDataSource = null;
/*     */ 
/*  54 */   private DaoTrace objDaoTrace = null;
/*  55 */   private long startTime = 0L;
/*     */ 
/*     */   public void beforeInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 105 */     if (TraceFactory.isEnableTrace()) {
/* 106 */       this.startTime = System.currentTimeMillis();
/* 107 */       this.objDaoTrace = new DaoTrace();
/* 108 */       this.objDaoTrace.setCreateTime(System.currentTimeMillis());
/* 109 */       this.objDaoTrace.setClassName(obj.getClass().getName());
/* 110 */       this.objDaoTrace.setMethodName(methodName);
/*     */ 
/* 112 */       if (CenterFactory.isSetCenterInfo()) {
/* 113 */         String tmp = CenterFactory.getCenterInfo().getRegion() + "," + CenterFactory.getCenterInfo().getCenter();
/* 114 */         this.objDaoTrace.setCenter(tmp);
/*     */       }
/*     */ 
/* 117 */       TraceFactory.addTraceInfo(this.objDaoTrace);
/*     */ 
/* 120 */       TraceFactory.pushTraceLevel(this.objDaoTrace);
/*     */     }
/*     */ 
/* 125 */     this.previousDataSource = ((String)IDataSource.CUR_DATASOURCE.get());
/* 126 */     if ((log.isDebugEnabled()) && 
/* 127 */       (!StringUtils.isBlank(this.previousDataSource))) {
/* 128 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource", new String[] { this.previousDataSource }));
/*     */     }
/*     */ 
/* 133 */     IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 135 */     String ds = getDataSourceByClass(obj.getClass());
/* 136 */     if (ds != null) {
/* 137 */       if (StringUtils.contains(ds, "{CENTER}")) {
/* 138 */         ds = StringUtils.replace(ds, "{CENTER}", CenterFactory.getCenterInfo().getCenter());
/*     */       }
/* 140 */       IDataSource.CUR_DATASOURCE.set(ds);
/*     */     }
/*     */     else {
/* 143 */       IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 146 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.dao_impl_error", new String[] { obj.getClass().getName() }));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 160 */     if (this.objDaoTrace != null) {
/* 161 */       this.objDaoTrace.setSuccess(true);
/* 162 */       this.objDaoTrace.setUseTime((int)(System.currentTimeMillis() - this.startTime));
/*     */ 
/* 164 */       TraceFactory.popTraceLevel();
/*     */     }
/*     */ 
/* 169 */     IDataSource.CUR_DATASOURCE.set(this.previousDataSource);
/* 170 */     if ((!log.isDebugEnabled()) || 
/* 171 */       (StringUtils.isBlank(this.previousDataSource))) return;
/* 172 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource_resume", new String[] { this.previousDataSource }));
/*     */   }
/*     */ 
/*     */   public void exceptionInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 186 */     if (this.objDaoTrace != null) {
/* 187 */       this.objDaoTrace.setSuccess(true);
/* 188 */       this.objDaoTrace.setUseTime((int)(System.currentTimeMillis() - this.startTime));
/*     */ 
/* 190 */       TraceFactory.popTraceLevel();
/*     */     }
/*     */ 
/* 195 */     IDataSource.CUR_DATASOURCE.set(this.previousDataSource);
/* 196 */     if ((!log.isDebugEnabled()) || 
/* 197 */       (StringUtils.isBlank(this.previousDataSource))) return;
/* 198 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource_resume", new String[] { this.previousDataSource }));
/*     */   }
/*     */ 
/*     */   private static String getDataSourceByClass(Class clazz)
/*     */   {
/* 209 */     String dataSource = (String)CLAZZ_DATASOURCE_CACHE.get(clazz);
/* 210 */     if (dataSource == null) {
/* 211 */       synchronized (CLAZZ_DATASOURCE_CACHE) {
/* 212 */         if (!CLAZZ_DATASOURCE_CACHE.containsKey(clazz)) {
/* 213 */           for (int i = 0; i < KEYS.length; ++i) {
/* 214 */             if (clazz.getPackage().getName().indexOf(KEYS[i]) == -1)
/*     */               continue;
/* 216 */             dataSource = (String)DAO_SCOPE.get(KEYS[i]);
/* 217 */             break;
/*     */           }
/*     */ 
/* 221 */           if (dataSource != null) {
/* 222 */             CLAZZ_DATASOURCE_CACHE.put(clazz, dataSource);
/*     */           }
/*     */           else {
/* 225 */             CLAZZ_DATASOURCE_CACHE.put(clazz, "NULL");
/*     */           }
/*     */         }
/* 228 */         dataSource = (String)CLAZZ_DATASOURCE_CACHE.get(clazz);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 233 */     if ((dataSource == null) || (dataSource.equals("NULL"))) {
/* 234 */       dataSource = getTmpMappingDataSource(clazz);
/*     */     }
/*     */ 
/* 237 */     return dataSource;
/*     */   }
/*     */ 
/*     */   private static String getTmpMappingDataSource(Class clazz)
/*     */   {
/* 246 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 247 */     if (stack == null) {
/* 248 */       return null;
/*     */     }
/*     */ 
/* 251 */     Map tmp = (Map)stack.peek();
/* 252 */     if (tmp == null) {
/* 253 */       return null;
/*     */     }
/*     */ 
/* 256 */     String dataSource = null;
/* 257 */     Set set = tmp.keySet();
/* 258 */     for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/* 259 */       String item = (String)iter.next();
/* 260 */       if (clazz.getPackage().getName().indexOf(item) != -1)
/*     */       {
/* 262 */         dataSource = (String)tmp.get(item);
/* 263 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 267 */     if (log.isDebugEnabled()) {
/* 268 */       log.debug("tmp mapping datasource clazz=" + clazz + ",datasource:" + dataSource);
/*     */     }
/*     */ 
/* 272 */     return dataSource;
/*     */   }
/*     */ 
/*     */   public static void pushTmpMapping(Map map)
/*     */     throws Exception
/*     */   {
/* 281 */     Map treeMap = new TreeMap(new StringLengthDescComparator());
/* 282 */     treeMap.putAll(map);
/*     */ 
/* 284 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 285 */     if (stack == null) {
/* 286 */       stack = new Stack();
/* 287 */       TMP_MAPPING.set(stack);
/*     */     }
/*     */ 
/* 290 */     stack.push(treeMap);
/*     */ 
/* 292 */     if (log.isDebugEnabled())
/* 293 */       log.debug("push tmp mapping datasource:" + map);
/*     */   }
/*     */ 
/*     */   public static void popTmpMapping()
/*     */     throws Exception
/*     */   {
/* 303 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 304 */     if (stack != null) {
/* 305 */       Map map = (Map)stack.pop();
/* 306 */       if (log.isDebugEnabled())
/* 307 */         log.debug("pop tmp mapping datasource:" + map);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  59 */       Property[] property = XMLHelper.getInstance().getDefaults().getDatasource().getMapping().getProperties();
/*     */ 
/*  61 */       List list = new ArrayList();
/*  62 */       for (int i = 0; i < property.length; ++i) {
/*  63 */         DAO_SCOPE.put(property[i].getName().trim(), property[i].getValue().trim());
/*  64 */         list.add(property[i].getName().trim());
/*     */       }
/*     */ 
/*  68 */       KEYS = (String[])(String[])list.toArray(new String[0]);
/*  69 */       Arrays.sort(KEYS, new StringLengthDescComparator());
/*     */ 
/*  71 */       if (log.isDebugEnabled()) {
/*  72 */         AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource");
/*  73 */         log.debug("The data after sorting:");
/*  74 */         for (int i = 0; i < KEYS.length; ++i) {
/*  75 */           log.debug(KEYS[i]);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  84 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.initial_fail"), ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.impl.DAODataSourceInterceptorImpl
 * JD-Core Version:    0.5.4
 */