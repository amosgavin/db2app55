package com.ai.appframe2.complex.service.control;

public abstract interface ISrvControl
{
  public abstract void refreshControlData();

  public abstract Object startControl(Object paramObject, String paramString, Object[] paramArrayOfObject);

  public abstract void endControl(Object paramObject1, Object paramObject2, String paramString, Object[] paramArrayOfObject);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.control.ISrvControl
 * JD-Core Version:    0.5.4
 */