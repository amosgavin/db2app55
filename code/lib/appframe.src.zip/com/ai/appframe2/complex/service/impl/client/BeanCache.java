/*     */ package com.ai.appframe2.complex.service.impl.client;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanCache
/*     */ {
/*  23 */   private static transient Log log = LogFactory.getLog(BeanCache.class);
/*     */ 
/*  25 */   private static final HashMap NORMAL_BEAN_CACHE = new HashMap();
/*  26 */   private static final HashMap CROSS_BEAN_CACHE = new HashMap();
/*     */ 
/*     */   public static Object getRemoteObject(EnvCache objEnvCache, String center, String jndi, Class homeClass)
/*     */     throws Exception
/*     */   {
/*  38 */     Object remote = null;
/*     */ 
/*  40 */     if (log.isInfoEnabled()) {
/*  41 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.invoke.ejb.jndi", new String[] { jndi }));
/*     */     }
/*     */ 
/*  44 */     String key = jndi + "_" + center;
/*     */ 
/*  46 */     if (!NORMAL_BEAN_CACHE.containsKey(key)) {
/*  47 */       synchronized (NORMAL_BEAN_CACHE) {
/*  48 */         if (!NORMAL_BEAN_CACHE.containsKey(key)) {
/*  49 */           EJBHome home = (EJBHome)PortableRemoteObject.narrow(objEnvCache.getContext(center).lookup(jndi), homeClass);
/*  50 */           Object obj = homeClass.getMethod("create", new Class[0]).invoke(home, null);
/*  51 */           NORMAL_BEAN_CACHE.put(key, obj);
/*     */         }
/*  53 */         remote = NORMAL_BEAN_CACHE.get(key);
/*     */       }
/*     */     }
/*     */     else {
/*  57 */       remote = NORMAL_BEAN_CACHE.get(key);
/*     */     }
/*  59 */     return remote;
/*     */   }
/*     */ 
/*     */   public static Object getRemoteObjectOnBigDistrict(EnvCache objEnvCache, String bigdistrict, String jndi, Class homeClass)
/*     */     throws Exception
/*     */   {
/*  72 */     Object remote = null;
/*     */ 
/*  74 */     if (log.isInfoEnabled()) {
/*  75 */       log.info("调用EJB的JNDI:" + jndi);
/*     */     }
/*     */ 
/*  78 */     String key = jndi + "_bd_" + bigdistrict;
/*     */ 
/*  80 */     if (!NORMAL_BEAN_CACHE.containsKey(key)) {
/*  81 */       synchronized (NORMAL_BEAN_CACHE) {
/*  82 */         if (!NORMAL_BEAN_CACHE.containsKey(key)) {
/*  83 */           EJBHome home = (EJBHome)PortableRemoteObject.narrow(objEnvCache.getContextOnBigDistrict(bigdistrict).lookup(jndi), homeClass);
/*  84 */           Object obj = homeClass.getMethod("create", new Class[0]).invoke(home, null);
/*  85 */           NORMAL_BEAN_CACHE.put(key, obj);
/*     */         }
/*  87 */         remote = NORMAL_BEAN_CACHE.get(key);
/*     */       }
/*     */     }
/*     */     else {
/*  91 */       remote = NORMAL_BEAN_CACHE.get(key);
/*     */     }
/*  93 */     return remote;
/*     */   }
/*     */ 
/*     */   public static Object getCrossCenterRemoteObject(EnvCache objEnvCache, String jndi, Class homeClass)
/*     */     throws Exception
/*     */   {
/* 105 */     Object remote = null;
/* 106 */     if (!CROSS_BEAN_CACHE.containsKey(jndi)) {
/* 107 */       synchronized (CROSS_BEAN_CACHE) {
/* 108 */         if (!CROSS_BEAN_CACHE.containsKey(jndi)) {
/* 109 */           EJBHome home = (EJBHome)PortableRemoteObject.narrow(objEnvCache.getCrossCenterContext().lookup(jndi), homeClass);
/* 110 */           Object obj = homeClass.getMethod("create", new Class[0]).invoke(home, null);
/* 111 */           CROSS_BEAN_CACHE.put(jndi, obj);
/*     */         }
/* 113 */         remote = CROSS_BEAN_CACHE.get(jndi);
/*     */       }
/*     */     }
/*     */     else {
/* 117 */       remote = CROSS_BEAN_CACHE.get(jndi);
/*     */     }
/* 119 */     return remote;
/*     */   }
/*     */ 
/*     */   public static synchronized void clear()
/*     */   {
/* 126 */     NORMAL_BEAN_CACHE.clear();
/* 127 */     CROSS_BEAN_CACHE.clear();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.BeanCache
 * JD-Core Version:    0.5.4
 */