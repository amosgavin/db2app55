package com.ai.appframe2.complex.service.interfaces;

import java.util.Map;

public abstract interface IServiceClientControl
{
  public abstract void reconnect()
    throws Exception;

  public abstract void connect(String paramString)
    throws Exception;

  public abstract Map listGroups()
    throws Exception;

  public abstract String getCurrentAppCluster()
    throws Exception;

  public abstract String getOldAppCluster()
    throws Exception;

  public abstract Object getRemoteObject(Class paramClass, boolean paramBoolean);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.interfaces.IServiceClientControl
 * JD-Core Version:    0.5.4
 */