/*     */ package com.ai.appframe2.complex.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.service.interfaces.ISelfManagedService;
/*     */ import com.ai.appframe2.complex.service.interfaces.ISelfManagedServiceWithRequiredTransaction;
/*     */ import com.ai.appframe2.complex.service.interfaces.IServiceInvoke;
/*     */ import com.ai.appframe2.complex.service.proxy.ProxyInvocationHandler;
/*     */ import com.ai.appframe2.complex.service.proxy.impl.DAODataSourceInterceptorImpl;
/*     */ import com.ai.appframe2.complex.service.proxy.impl.MethodMonitorInterceptorImpl;
/*     */ import com.ai.appframe2.complex.service.proxy.impl.TransactionDataSourceInterceptorImpl;
/*     */ import com.ai.appframe2.complex.service.proxy.impl.TransactionInterceptorImpl;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.util.ProxyUtil;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.daos.Dao;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocalServiceInvokeImpl
/*     */   implements IServiceInvoke
/*     */ {
/*  39 */   private static transient Log log = LogFactory.getLog(LocalServiceInvokeImpl.class);
/*     */ 
/*  41 */   private static HashMap SERVICES_DEFINE = new HashMap();
/*  42 */   private static HashMap DAOS_DEFINE = new HashMap();
/*     */ 
/*  45 */   private static int CHECK_DAO_IN_SERVICE = 0;
/*     */ 
/*     */   public Object getCrossCenterService(Class interfaceClass)
/*     */   {
/* 113 */     if (log.isInfoEnabled()) {
/* 114 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.warn"));
/*     */     }
/*     */ 
/* 117 */     return getService(interfaceClass, true);
/*     */   }
/*     */ 
/*     */   public Object getCrossCenterService(String serviceId)
/*     */   {
/* 126 */     if (log.isInfoEnabled()) {
/* 127 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.warn"));
/*     */     }
/* 129 */     return getService(serviceId, true);
/*     */   }
/*     */ 
/*     */   public Object getService(Class interfaceClass)
/*     */   {
/* 138 */     return getService(interfaceClass, false);
/*     */   }
/*     */ 
/*     */   private Object getService(Class interfaceClass, boolean isCross)
/*     */   {
/* 148 */     Object rtn = null;
/*     */     try {
/* 150 */       String interfaceName = interfaceClass.getName();
/* 151 */       if (StringUtils.lastIndexOf(interfaceName, "DAO") != -1) {
/* 152 */         rtn = getDAOObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass));
/*     */       }
/* 154 */       else if (StringUtils.lastIndexOf(interfaceName, "SV") != -1) {
/* 155 */         rtn = getSVObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass), isCross);
/*     */       }
/*     */       else
/* 158 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { interfaceName }));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 162 */       throw new RuntimeException(ex);
/*     */     }
/* 164 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Object getService(String serviceId)
/*     */   {
/* 173 */     return getService(serviceId, false);
/*     */   }
/*     */ 
/*     */   private Object getService(String serviceId, boolean isCross)
/*     */   {
/* 183 */     Object rtn = null;
/*     */     try {
/* 185 */       boolean isFound = false;
/*     */ 
/* 187 */       if (DAOS_DEFINE.containsKey(serviceId))
/*     */       {
/* 189 */         Dao dao = (Dao)DAOS_DEFINE.get(serviceId);
/* 190 */         Property[] properties = dao.getPropertys();
/* 191 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 192 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 193 */         rtn = getDAOObject(Class.forName(interfaceClass), Class.forName(implClass));
/* 194 */         isFound = true;
/*     */       }
/*     */ 
/* 197 */       if ((!isFound) && (SERVICES_DEFINE.containsKey(serviceId)))
/*     */       {
/* 199 */         Service service = (Service)SERVICES_DEFINE.get(serviceId);
/* 200 */         Property[] properties = service.getPropertys();
/* 201 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 202 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 203 */         rtn = getSVObject(Class.forName(interfaceClass), Class.forName(implClass), isCross);
/* 204 */         isFound = true;
/*     */       }
/*     */ 
/* 207 */       if (!isFound)
/*     */       {
/* 209 */         if (StringUtils.lastIndexOf(serviceId, "DAO") != -1) {
/* 210 */           rtn = getDAOObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId));
/*     */         }
/* 212 */         else if (StringUtils.lastIndexOf(serviceId, "SV") != -1) {
/* 213 */           rtn = getSVObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId), isCross);
/*     */         }
/*     */         else {
/* 216 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { serviceId }));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 222 */       throw new RuntimeException(ex);
/*     */     }
/* 224 */     return rtn;
/*     */   }
/*     */ 
/*     */   private Object getDAOObject(Class interfaceClass, Class implClass)
/*     */     throws Exception
/*     */   {
/* 236 */     checkDaoInService();
/*     */ 
/* 238 */     Object rtn = implClass.newInstance();
/* 239 */     ProxyInvocationHandler handler = new ProxyInvocationHandler(rtn, new Class[] { DAODataSourceInterceptorImpl.class });
/*     */ 
/* 242 */     rtn = ProxyUtil.getProxyObject(interfaceClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*     */ 
/* 245 */     return rtn;
/*     */   }
/*     */ 
/*     */   private Object getSVObject(Class interfaceClass, Class implClass, boolean isCross)
/*     */     throws Exception
/*     */   {
/* 257 */     Object rtn = implClass.newInstance();
/*     */ 
/* 259 */     if ((!rtn instanceof ISelfManagedService) && (!rtn instanceof ISelfManagedServiceWithRequiredTransaction))
/*     */     {
/* 263 */       Class[] clazz = null;
/* 264 */       if (!isCross) {
/* 265 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class, TransactionDataSourceInterceptorImpl.class };
/*     */       }
/*     */       else
/*     */       {
/* 271 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class, TransactionDataSourceInterceptorImpl.class };
/*     */       }
/*     */ 
/* 276 */       ProxyInvocationHandler handler = new ProxyInvocationHandler(rtn, clazz);
/*     */ 
/* 279 */       rtn = ProxyUtil.getProxyObject(implClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*     */     }
/* 282 */     else if (rtn instanceof ISelfManagedService) {
/* 283 */       if (log.isDebugEnabled())
/*     */       {
/* 285 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getSVObject.info", new String[] { rtn.getClass().getName(), "ISelfManagedService" }));
/*     */       }
/*     */ 
/* 288 */       Class[] clazz = null;
/* 289 */       if (!isCross) {
/* 290 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class };
/*     */       }
/*     */       else
/*     */       {
/* 294 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class };
/*     */       }
/*     */ 
/* 298 */       ProxyInvocationHandler handler = new ProxyInvocationHandler(rtn, clazz);
/*     */ 
/* 301 */       rtn = ProxyUtil.getProxyObject(implClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*     */     }
/* 303 */     else if (rtn instanceof ISelfManagedServiceWithRequiredTransaction) {
/* 304 */       if (log.isDebugEnabled())
/*     */       {
/* 306 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getSVObject.info", new String[] { rtn.getClass().getName(), "ISelfManagedServiceWithRequiredTransaction" }));
/*     */       }
/*     */ 
/* 309 */       Class[] clazz = null;
/* 310 */       if (!isCross) {
/* 311 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class };
/*     */       }
/*     */       else
/*     */       {
/* 317 */         clazz = new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class };
/*     */       }
/*     */ 
/* 322 */       ProxyInvocationHandler handler = new ProxyInvocationHandler(rtn, clazz);
/*     */ 
/* 325 */       rtn = ProxyUtil.getProxyObject(implClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*     */     }
/*     */ 
/* 330 */     return rtn;
/*     */   }
/*     */ 
/*     */   private void checkDaoInService()
/*     */     throws Exception
/*     */   {
/* 338 */     if (CHECK_DAO_IN_SERVICE == 0)
/*     */     {
/* 340 */       return;
/*     */     }
/* 342 */     if (CHECK_DAO_IN_SERVICE == 1) {
/* 343 */       if (ServiceManager.getSession().isStartTransaction()) {
/*     */         return;
/*     */       }
/* 346 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.checkDaoInService.errorMessage");
/*     */ 
/* 348 */       log.error(msg, new Exception(msg));
/*     */     }
/*     */     else {
/* 351 */       if ((CHECK_DAO_IN_SERVICE != 2) || 
/* 352 */         (ServiceManager.getSession().isStartTransaction())) return;
/* 353 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.checkDaoInService.errorMessage");
/*     */ 
/* 356 */       throw new Exception(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  51 */       Service[] services = XMLHelper.getInstance().getServices();
/*  52 */       for (int i = 0; i < services.length; ++i) {
/*  53 */         SERVICES_DEFINE.put(services[i].getId(), services[i]);
/*     */       }
/*     */ 
/*  57 */       Dao[] daos = XMLHelper.getInstance().getDaos();
/*  58 */       for (int i = 0; i < daos.length; ++i) {
/*  59 */         DAOS_DEFINE.put(daos[i].getId(), daos[i]);
/*     */       }
/*     */ 
/*  63 */       Set servicekeys = SERVICES_DEFINE.keySet();
/*  64 */       for (Iterator iter = servicekeys.iterator(); iter.hasNext(); ) {
/*  65 */         String item = (String)iter.next();
/*  66 */         if (DAOS_DEFINE.containsKey(item))
/*     */         {
/*  68 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.DAO_double_define", new String[] { item }));
/*     */         }
/*     */       }
/*     */ 
/*  72 */       String strCheckDaoInService = AIConfigManager.getConfigItem("CHECK_DAO_IN_SERVICE");
/*  73 */       if (!StringUtils.isBlank(strCheckDaoInService)) {
/*  74 */         if (StringUtils.isNumeric(strCheckDaoInService)) {
/*  75 */           int check = Integer.parseInt(strCheckDaoInService);
/*  76 */           if (check == 0) {
/*  77 */             CHECK_DAO_IN_SERVICE = 0;
/*     */           }
/*  79 */           else if (check == 1) {
/*  80 */             CHECK_DAO_IN_SERVICE = 1;
/*     */           }
/*  82 */           else if (check == 2) {
/*  83 */             CHECK_DAO_IN_SERVICE = 2;
/*     */           }
/*     */           else
/*  86 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.checkDaoInService.notFound", new String[] { "" + check }));
/*     */         }
/*     */         else
/*     */         {
/*  90 */           CHECK_DAO_IN_SERVICE = 0;
/*     */         }
/*     */       }
/*     */       else {
/*  94 */         CHECK_DAO_IN_SERVICE = 0;
/*     */       }
/*     */ 
/*  97 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.checkDaoInService.printLevel", new String[] { "" + CHECK_DAO_IN_SERVICE }));
/*     */     }
/*     */     catch (Throwable ex) {
/* 100 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.LocalServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */