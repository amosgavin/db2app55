/*    */ package com.ai.appframe2.complex.service.impl.xml;
/*    */ 
/*    */ public class Connect
/*    */ {
/*    */   private String name;
/*    */   private String type;
/*    */   private String appcluster;
/*    */   private String desc;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 20 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 23 */     this.name = name;
/*    */   }
/*    */   public String getType() {
/* 26 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 29 */     this.type = type;
/*    */   }
/*    */   public String getAppcluster() {
/* 32 */     return this.appcluster;
/*    */   }
/*    */   public void setAppcluster(String appcluster) {
/* 35 */     this.appcluster = appcluster;
/*    */   }
/*    */   public String getDesc() {
/* 38 */     return this.desc;
/*    */   }
/*    */   public void setDesc(String desc) {
/* 41 */     this.desc = desc;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.xml.Connect
 * JD-Core Version:    0.5.4
 */