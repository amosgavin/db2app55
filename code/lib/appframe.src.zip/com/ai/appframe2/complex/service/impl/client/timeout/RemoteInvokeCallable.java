/*    */ package com.ai.appframe2.complex.service.impl.client.timeout;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ public class RemoteInvokeCallable
/*    */   implements Callable
/*    */ {
/* 18 */   private Object object = null;
/* 19 */   private Method method = null;
/* 20 */   private Object[] objectArray = null;
/*    */ 
/*    */   public RemoteInvokeCallable(Object object, Method method, Object[] objectArray)
/*    */   {
/* 29 */     this.object = object;
/* 30 */     this.method = method;
/* 31 */     this.objectArray = objectArray;
/*    */   }
/*    */ 
/*    */   public Object call()
/*    */     throws Exception
/*    */   {
/* 40 */     Object rtn = this.method.invoke(this.object, this.objectArray);
/* 41 */     return rtn;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.timeout.RemoteInvokeCallable
 * JD-Core Version:    0.5.4
 */