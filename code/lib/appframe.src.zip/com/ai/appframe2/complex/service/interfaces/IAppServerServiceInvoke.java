package com.ai.appframe2.complex.service.interfaces;

public abstract interface IAppServerServiceInvoke
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.interfaces.IAppServerServiceInvoke
 * JD-Core Version:    0.5.4
 */