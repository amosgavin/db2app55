/*     */ package com.ai.appframe2.complex.service.impl.client;
/*     */ 
/*     */ import com.ai.appframe2.complex.service.impl.DefaultClientServiceInvokeImpl;
/*     */ import com.ai.appframe2.complex.service.impl.xml.Cluster;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Env;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.naming.InitialContext;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class EnvCache
/*     */ {
/*  28 */   private static transient Log log = LogFactory.getLog(EnvCache.class);
/*     */ 
/*  30 */   private static final HashMap NORMAL_CONTEXT_CACHE = new HashMap();
/*  31 */   private static final HashMap CROSS_CONTEXT_CACHE = new HashMap();
/*  32 */   private static final RoundRobin ROUND_ROBIN = new RoundRobin();
/*     */ 
/*  34 */   private Env[] env = null;
/*  35 */   private Cluster[] cluster = null;
/*  36 */   private String oldAppCluster = null;
/*  37 */   private String currentAppCluster = null;
/*     */ 
/*     */   public EnvCache(Env[] env, Cluster[] cluster, String appCluster)
/*     */     throws Exception
/*     */   {
/*  47 */     this.env = env;
/*  48 */     this.cluster = cluster;
/*  49 */     this.currentAppCluster = appCluster;
/*  50 */     this.oldAppCluster = appCluster;
/*  51 */     init();
/*     */   }
/*     */ 
/*     */   public EnvCache(Env[] env)
/*     */     throws Exception
/*     */   {
/*  60 */     this.env = env;
/*  61 */     init();
/*     */   }
/*     */ 
/*     */   private void init()
/*     */     throws Exception
/*     */   {
/*  69 */     for (int i = 0; i < this.env.length; ++i) {
/*  70 */       Hashtable objHashtable = new Hashtable();
/*     */ 
/*  72 */       Property[] properties = this.env[i].getProperties();
/*  73 */       for (int j = 0; j < properties.length; ++j) {
/*  74 */         if (StringUtils.isBlank(properties[j].getType())) {
/*  75 */           objHashtable.put(properties[j].getName(), properties[j].getValue());
/*     */         }
/*  77 */         else if (properties[j].getType().equals("java.lang.Short")) {
/*  78 */           objHashtable.put(properties[j].getName(), new Short(properties[j].getValue()));
/*     */         }
/*  80 */         else if (properties[j].getType().equals("java.lang.Integer")) {
/*  81 */           objHashtable.put(properties[j].getName(), new Integer(properties[j].getValue()));
/*     */         }
/*  83 */         else if (properties[j].getType().equals("java.lang.Long")) {
/*  84 */           objHashtable.put(properties[j].getName(), new Long(properties[j].getValue()));
/*     */         }
/*  86 */         else if (properties[j].getType().equals("java.lang.Double")) {
/*  87 */           objHashtable.put(properties[j].getName(), new Double(properties[j].getValue()));
/*     */         }
/*  89 */         else if (properties[j].getType().equals("java.lang.Boolean")) {
/*  90 */           objHashtable.put(properties[j].getName(), new Boolean(properties[j].getValue()));
/*     */         }
/*  92 */         else if (properties[j].getType().equals("java.util.Date")) {
/*  93 */           objHashtable.put(properties[j].getName(), new Date(properties[j].getValue()));
/*     */         }
/*     */         else {
/*  96 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.EnvCache.init_exception", new String[] { properties[j].getType() }));
/*     */         }
/*     */       }
/*  99 */       InitialContext context = new InitialContext(objHashtable);
/*     */ 
/* 101 */       if (this.env[i].getGroup().equalsIgnoreCase("normal")) {
/* 102 */         if (DefaultClientServiceInvokeImpl.BIG_DISTRICT_MODE)
/*     */         {
/* 104 */           if (StringUtils.isBlank(this.env[i].getBigdistrict())) {
/* 105 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.EnvCache.init_exception2"));
/*     */           }
/*     */ 
/* 108 */           NORMAL_CONTEXT_CACHE.put("_bd_" + this.env[i].getBigdistrict().trim(), context);
/* 109 */           ROUND_ROBIN.put(this.env[i].getBigdistrict());
/*     */         }
/*     */         else {
/* 112 */           NORMAL_CONTEXT_CACHE.put(this.env[i].getCenter(), context);
/* 113 */           ROUND_ROBIN.put(this.env[i].getCenter());
/*     */         }
/*     */       }
/* 116 */       else if (this.env[i].getGroup().equalsIgnoreCase("cross")) {
/* 117 */         CROSS_CONTEXT_CACHE.put(this.env[i].getCenter(), context);
/*     */       }
/*     */       else {
/* 120 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.EnvCache.init_unknown", new String[] { this.env[i].getGroup() }));
/*     */       }
/*     */     }
/* 123 */     if (log.isDebugEnabled())
/* 124 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.EnvCache.init_compelet"));
/*     */   }
/*     */ 
/*     */   public synchronized void reconnect()
/*     */     throws Exception
/*     */   {
/* 134 */     System.out.println("====================================");
/* 135 */     System.out.println("===========" + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.env_cache.reconnect") + "==========");
/* 136 */     System.out.println("====================================");
/* 137 */     for (int i = 0; i < this.env.length; ++i) {
/* 138 */       System.out.println(this.env[i].toString());
/*     */     }
/*     */ 
/* 141 */     NORMAL_CONTEXT_CACHE.clear();
/* 142 */     CROSS_CONTEXT_CACHE.clear();
/* 143 */     ROUND_ROBIN.clear();
/* 144 */     init();
/*     */   }
/*     */ 
/*     */   public synchronized void connect(String group)
/*     */     throws Exception
/*     */   {
/* 153 */     Env[] tmp = null;
/* 154 */     if ((this.cluster != null) && (this.cluster.length != 0)) {
/* 155 */       for (int i = 0; i < this.cluster.length; ++i) {
/* 156 */         if (this.cluster[i].getName().equalsIgnoreCase(group)) {
/* 157 */           tmp = this.cluster[i].getEnvs();
/* 158 */           this.currentAppCluster = group;
/* 159 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 164 */     if (tmp != null) {
/* 165 */       System.out.println("===============================================");
/* 166 */       System.out.println("==========" + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.env_cache.connect_group", new String[] { group }) + "=========");
/* 167 */       System.out.println("===============================================");
/* 168 */       for (int i = 0; i < tmp.length; ++i) {
/* 169 */         System.out.println(tmp[i].toString());
/*     */       }
/*     */ 
/* 172 */       NORMAL_CONTEXT_CACHE.clear();
/* 173 */       CROSS_CONTEXT_CACHE.clear();
/* 174 */       ROUND_ROBIN.clear();
/* 175 */       this.env = tmp;
/* 176 */       init();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map listGroups()
/*     */     throws Exception
/*     */   {
/* 186 */     Map rtn = new HashMap();
/* 187 */     if ((this.cluster != null) && (this.cluster.length != 0)) {
/* 188 */       for (int i = 0; i < this.cluster.length; ++i) {
/* 189 */         Env[] tmp = this.cluster[i].getEnvs();
/* 190 */         List list = new ArrayList();
/* 191 */         for (int j = 0; j < tmp.length; ++j) {
/* 192 */           list.add(tmp[j].toString());
/*     */         }
/* 194 */         rtn.put(this.cluster[i].getName(), StringUtils.join(list.iterator(), "\n"));
/*     */       }
/*     */     }
/* 197 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String getCurrentAppCluster()
/*     */   {
/* 205 */     return this.currentAppCluster;
/*     */   }
/*     */ 
/*     */   public String getOldAppCluster()
/*     */   {
/* 213 */     return this.oldAppCluster;
/*     */   }
/*     */ 
/*     */   public InitialContext getContext(String center)
/*     */   {
/* 223 */     return (InitialContext)NORMAL_CONTEXT_CACHE.get(center);
/*     */   }
/*     */ 
/*     */   public InitialContext getContextOnBigDistrict(String bigdistrict)
/*     */   {
/* 232 */     return (InitialContext)NORMAL_CONTEXT_CACHE.get("_bd_" + bigdistrict);
/*     */   }
/*     */ 
/*     */   public InitialContext getCrossCenterContext()
/*     */   {
/* 240 */     return (InitialContext)CROSS_CONTEXT_CACHE.get("0");
/*     */   }
/*     */ 
/*     */   public String getRoundRobinCenter()
/*     */   {
/* 248 */     return (String)ROUND_ROBIN.getByRoundRobin();
/*     */   }
/*     */ 
/*     */   public String getRoundRobinBigDistrict()
/*     */   {
/* 256 */     return (String)ROUND_ROBIN.getByRoundRobin();
/*     */   }
/*     */ 
/*     */   public static void removeBigDistrict(String bigdistrict)
/*     */   {
/* 264 */     ROUND_ROBIN.remove(bigdistrict);
/*     */   }
/*     */ 
/*     */   public static void resumeBigDistrict(String bigdistrict)
/*     */   {
/* 272 */     synchronized (ROUND_ROBIN) {
/* 273 */       ROUND_ROBIN.put(bigdistrict);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.EnvCache
 * JD-Core Version:    0.5.4
 */