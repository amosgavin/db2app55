/*    */ package com.ai.appframe2.complex.service.control;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class SrvControlFactory
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(SrvControlFactory.class);
/*    */ 
/* 26 */   private static ISrvControl SRV_CONTROL_INSTANCE = null;
/*    */ 
/*    */   public static ISrvControl getSrvControl()
/*    */   {
/* 74 */     return SRV_CONTROL_INSTANCE;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 31 */       String strSrvControlImplClass = AIConfigManager.getConfigItem("SRVCONTROL_IMPL_CLASS");
/* 32 */       if (!StringUtils.isBlank(strSrvControlImplClass)) {
/*    */         try {
/* 34 */           Object custObject = Class.forName(strSrvControlImplClass.trim()).newInstance();
/* 35 */           if (custObject instanceof ISrvControl) {
/* 36 */             SRV_CONTROL_INSTANCE = (ISrvControl)custObject;
/* 37 */             SRV_CONTROL_INSTANCE.refreshControlData();
/*    */           }
/*    */           else {
/* 40 */             SRV_CONTROL_INSTANCE = null;
/*    */           }
/*    */         }
/*    */         catch (Throwable ex) {
/* 44 */           SRV_CONTROL_INSTANCE = null;
/* 45 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.error"), ex);
/*    */         }
/*    */       }
/*    */       else
/* 49 */         SRV_CONTROL_INSTANCE = null;
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 53 */       SRV_CONTROL_INSTANCE = null;
/* 54 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.error"), ex);
/*    */     }
/*    */     finally {
/* 57 */       if (SRV_CONTROL_INSTANCE != null) {
/* 58 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.enabled", new String[] { SRV_CONTROL_INSTANCE.toString() }));
/*    */       }
/*    */       else
/* 61 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.disable"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.control.SrvControlFactory
 * JD-Core Version:    0.5.4
 */