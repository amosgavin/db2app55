/*    */ package com.ai.appframe2.complex.service.impl.client.timeout;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ 
/*    */ public class TimeoutExecThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/* 17 */   static final AtomicInteger poolNumber = new AtomicInteger(1);
/*    */   final ThreadGroup group;
/* 19 */   final AtomicInteger threadNumber = new AtomicInteger(1);
/*    */   final String namePrefix;
/*    */ 
/*    */   TimeoutExecThreadFactory()
/*    */   {
/* 26 */     SecurityManager s = System.getSecurityManager();
/* 27 */     this.group = ((s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup());
/* 28 */     this.namePrefix = ("timeout-pool-" + poolNumber.getAndIncrement() + "-thread-");
/*    */   }
/*    */ 
/*    */   public Thread newThread(Runnable r) {
/* 32 */     Thread t = new Thread(this.group, r, this.namePrefix + this.threadNumber.getAndIncrement(), 0L);
/*    */ 
/* 35 */     if (!t.isDaemon()) {
/* 36 */       t.setDaemon(true);
/*    */     }
/*    */ 
/* 39 */     if (t.getPriority() != 5) {
/* 40 */       t.setPriority(5);
/*    */     }
/* 42 */     return t;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.timeout.TimeoutExecThreadFactory
 * JD-Core Version:    0.5.4
 */