package com.ai.appframe2.complex.service.impl;

public class Was61ClientServiceInvokeImpl extends DefaultClientServiceInvokeImpl
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.Was61ClientServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */