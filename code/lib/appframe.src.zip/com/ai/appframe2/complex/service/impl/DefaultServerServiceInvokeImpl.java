/*     */ package com.ai.appframe2.complex.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.service.interfaces.IAppServerServiceInvoke;
/*     */ import com.ai.appframe2.complex.service.interfaces.IServiceInvoke;
/*     */ import com.ai.appframe2.complex.service.proxy.ProxyInvocationHandler;
/*     */ import com.ai.appframe2.complex.service.proxy.impl.DAODataSourceInterceptorImpl;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.util.ProxyUtil;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.daos.Dao;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.ejb.EJBHome;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.rmi.PortableRemoteObject;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultServerServiceInvokeImpl
/*     */   implements IServiceInvoke, IAppServerServiceInvoke
/*     */ {
/*  41 */   private static transient Log log = LogFactory.getLog(DefaultServerServiceInvokeImpl.class);
/*     */ 
/*  43 */   protected static HashMap servicesDefine = new HashMap();
/*  44 */   protected static HashMap daosDefine = new HashMap();
/*     */ 
/*  47 */   protected static InitialContext objInitialContext = null;
/*     */ 
/*     */   public Object getCrossCenterService(Class interfaceClass)
/*     */   {
/*  92 */     throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.nosupport_warn"));
/*     */   }
/*     */ 
/*     */   public Object getCrossCenterService(String serviceId)
/*     */   {
/* 104 */     throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.nosupport_warn"));
/*     */   }
/*     */ 
/*     */   public Object getService(Class interfaceClass)
/*     */   {
/* 116 */     Object rtn = null;
/*     */     try {
/* 118 */       String interfaceName = interfaceClass.getName();
/* 119 */       if (StringUtils.lastIndexOf(interfaceName, "SV") != -1) {
/* 120 */         rtn = getSVObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass));
/*     */       }
/* 122 */       else if (StringUtils.lastIndexOf(interfaceName, "DAO") != -1) {
/* 123 */         rtn = getDAOObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass));
/*     */       }
/*     */       else {
/* 126 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { interfaceName }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 131 */       throw new RuntimeException(ex);
/*     */     }
/* 133 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Object getService(String serviceId)
/*     */   {
/* 143 */     Object rtn = null;
/*     */     try {
/* 145 */       boolean isFound = false;
/*     */ 
/* 147 */       if (daosDefine.containsKey(serviceId))
/*     */       {
/* 149 */         Dao dao = (Dao)daosDefine.get(serviceId);
/* 150 */         Property[] properties = dao.getPropertys();
/* 151 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 152 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 153 */         rtn = getDAOObject(Class.forName(interfaceClass), Class.forName(implClass));
/* 154 */         isFound = true;
/*     */       }
/*     */ 
/* 157 */       if ((!isFound) && (servicesDefine.containsKey(serviceId)))
/*     */       {
/* 159 */         Service service = (Service)servicesDefine.get(serviceId);
/* 160 */         Property[] properties = service.getPropertys();
/* 161 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 162 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 163 */         rtn = getSVObject(Class.forName(interfaceClass), Class.forName(implClass));
/* 164 */         isFound = true;
/*     */       }
/*     */ 
/* 167 */       if (!isFound)
/*     */       {
/* 169 */         if (StringUtils.lastIndexOf(serviceId, "SV") != -1) {
/* 170 */           rtn = getSVObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId));
/*     */         }
/* 172 */         else if (StringUtils.lastIndexOf(serviceId, "DAO") != -1) {
/* 173 */           rtn = getDAOObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId));
/*     */         }
/*     */         else {
/* 176 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { serviceId }));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 182 */       throw new RuntimeException(ex);
/*     */     }
/* 184 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected Object getDAOObject(Class interfaceClass, Class implClass)
/*     */     throws Exception
/*     */   {
/* 195 */     Object rtn = implClass.newInstance();
/* 196 */     ProxyInvocationHandler handler = new ProxyInvocationHandler(rtn, new Class[] { DAODataSourceInterceptorImpl.class });
/*     */ 
/* 199 */     rtn = ProxyUtil.getProxyObject(interfaceClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*     */ 
/* 202 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected Object getSVObject(Class interfaceClass, Class implClass)
/*     */     throws Exception
/*     */   {
/* 216 */     Object remoteObject = getEJBObject(interfaceClass);
/*     */ 
/* 219 */     Constructor objConstructor = MiscHelper.getEJBClientConstructor(interfaceClass);
/*     */ 
/* 221 */     return objConstructor.newInstance(new Object[] { remoteObject });
/*     */   }
/*     */ 
/*     */   protected Object getEJBObject(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 231 */     Object obj = null;
/*     */ 
/* 233 */     String jndi = MiscHelper.getJndiNameByInterClassName(interfaceClass);
/*     */ 
/* 235 */     obj = objInitialContext.lookup(jndi);
/*     */ 
/* 237 */     if (log.isInfoEnabled()) {
/* 238 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.invoke.ejb.jndi", new String[] { jndi }));
/*     */     }
/*     */ 
/* 241 */     Class homeClass = MiscHelper.getHomeClassNameByInterClassName(interfaceClass);
/* 242 */     EJBHome home = (EJBHome)PortableRemoteObject.narrow(obj, homeClass);
/* 243 */     return homeClass.getMethod("create", new Class[0]).invoke(home, null);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  53 */       Service[] services = XMLHelper.getInstance().getServices();
/*  54 */       for (int i = 0; i < services.length; ++i) {
/*  55 */         servicesDefine.put(services[i].getId(), services[i]);
/*     */       }
/*     */ 
/*  59 */       Dao[] daos = XMLHelper.getInstance().getDaos();
/*  60 */       for (int i = 0; i < daos.length; ++i) {
/*  61 */         daosDefine.put(daos[i].getId(), daos[i]);
/*     */       }
/*     */ 
/*  65 */       Set servicekeys = servicesDefine.keySet();
/*  66 */       for (Iterator iter = servicekeys.iterator(); iter.hasNext(); ) {
/*  67 */         String item = (String)iter.next();
/*  68 */         if (daosDefine.containsKey(item)) {
/*  69 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.static_init.error", new String[] { item }));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  74 */       objInitialContext = new InitialContext();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  78 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.DefaultServerServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */