/*     */ package com.ai.appframe2.complex.service.proxy.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.SessionManager;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.center.mc.IMethodCenter;
/*     */ import com.ai.appframe2.complex.center.mc.MethodCenterFactory;
/*     */ import com.ai.appframe2.complex.mbean.standard.sv.SVMethodMonitor;
/*     */ import com.ai.appframe2.complex.mbean.standard.trace.AppTraceMonitor;
/*     */ import com.ai.appframe2.complex.service.control.ISrvControl;
/*     */ import com.ai.appframe2.complex.service.control.SrvControlFactory;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.CustomAroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.trace.TraceFactory;
/*     */ import com.ai.appframe2.complex.trace.impl.SvrTrace;
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Interceptor;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MethodMonitorInterceptorImpl
/*     */   implements AroundMethodInterceptor
/*     */ {
/*  36 */   private static transient Log log = LogFactory.getLog(MethodMonitorInterceptorImpl.class);
/*     */ 
/*  39 */   private static Class[] CUSTOM_INTERCEPTOR_CLASS = null;
/*  40 */   private static HashMap PROPERTY = new HashMap();
/*     */ 
/*  43 */   private CustomAroundMethodInterceptor[] customInterceptorObject = null;
/*     */ 
/*  45 */   private long startTime = 0L;
/*     */ 
/*  47 */   private long startCpuTime = 0L;
/*     */ 
/*  50 */   private boolean isCreateTrace = false;
/*     */ 
/*  52 */   private SvrTrace objSvrTrace = null;
/*     */ 
/*  55 */   private Object srvControlObject = null;
/*     */ 
/*  58 */   private Object methodCenterObject = null;
/*     */ 
/*     */   public MethodMonitorInterceptorImpl()
/*     */   {
/*  97 */     if ((CUSTOM_INTERCEPTOR_CLASS != null) && (CUSTOM_INTERCEPTOR_CLASS.length != 0)) {
/*  98 */       this.customInterceptorObject = new CustomAroundMethodInterceptor[CUSTOM_INTERCEPTOR_CLASS.length];
/*  99 */       for (int i = 0; i < CUSTOM_INTERCEPTOR_CLASS.length; ++i)
/*     */         try {
/* 101 */           this.customInterceptorObject[i] = ((CustomAroundMethodInterceptor)CUSTOM_INTERCEPTOR_CLASS[i].newInstance());
/* 102 */           this.customInterceptorObject[i].init((HashMap)PROPERTY.get(this.customInterceptorObject[i].getClass()));
/*     */         }
/*     */         catch (Throwable ex) {
/* 105 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.customed_interceptor_construct_failed"), ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void beforeInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 121 */     if (SrvControlFactory.getSrvControl() != null) {
/* 122 */       this.srvControlObject = SrvControlFactory.getSrvControl().startControl(obj, methodName, objectArray);
/*     */     }
/*     */ 
/* 126 */     if (MethodCenterFactory.getMethodCenter() != null) {
/* 127 */       this.methodCenterObject = MethodCenterFactory.getMethodCenter().startMethodCenter(obj, methodName, objectArray);
/*     */     }
/*     */ 
/* 132 */     if (!TraceFactory.isEnableTrace()) {
/* 133 */       this.isCreateTrace = TraceFactory.decideAppTrace(SessionManager.__getUserWithOutLog(), obj.getClass().getName(), methodName);
/*     */     }
/*     */ 
/* 136 */     if (TraceFactory.isEnableTrace()) {
/* 137 */       this.startTime = System.currentTimeMillis();
/*     */ 
/* 139 */       this.objSvrTrace = new SvrTrace();
/* 140 */       this.objSvrTrace.setCreateTime(System.currentTimeMillis());
/* 141 */       this.objSvrTrace.setClassName(obj.getClass().getName());
/* 142 */       this.objSvrTrace.setMethodName(methodName);
/*     */ 
/* 145 */       if (this.isCreateTrace) {
/* 146 */         this.objSvrTrace.setIn(objectArray);
/*     */       }
/*     */ 
/* 149 */       this.objSvrTrace.setAppIp(RuntimeServerUtil.getServerIP());
/* 150 */       this.objSvrTrace.setAppServerName(RuntimeServerUtil.getServerName());
/* 151 */       if (CenterFactory.isSetCenterInfo()) {
/* 152 */         String tmp = CenterFactory.getCenterInfo().getRegion() + "," + CenterFactory.getCenterInfo().getCenter();
/* 153 */         this.objSvrTrace.setCenter(tmp);
/*     */       }
/*     */ 
/* 156 */       if (SessionManager.__getUserWithOutLog() != null) {
/* 157 */         this.objSvrTrace.setCode(SessionManager.__getUserWithOutLog().getCode());
/*     */       }
/*     */ 
/* 160 */       TraceFactory.addTraceInfo(this.objSvrTrace);
/*     */ 
/* 163 */       TraceFactory.pushTraceLevel(this.objSvrTrace);
/*     */     }
/*     */ 
/* 167 */     if (SVMethodMonitor.isEnable()) {
/* 168 */       this.startTime = System.currentTimeMillis();
/* 169 */       this.startCpuTime = SVMethodMonitor.getCurrentThreadCpuTime();
/*     */     }
/*     */ 
/* 174 */     if ((this.customInterceptorObject != null) && (this.customInterceptorObject.length != 0))
/* 175 */       for (int i = 0; i < this.customInterceptorObject.length; ++i)
/*     */         try {
/* 177 */           this.customInterceptorObject[i].beforeInterceptor(obj, methodName, objectArray);
/*     */         }
/*     */         catch (Throwable ex) {
/* 180 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.customed_beforeinterceptor_construct_failed"), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public void afterInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 195 */     if (SrvControlFactory.getSrvControl() != null) {
/* 196 */       SrvControlFactory.getSrvControl().endControl(this.srvControlObject, obj, methodName, objectArray);
/*     */     }
/*     */ 
/* 200 */     if (MethodCenterFactory.getMethodCenter() != null) {
/* 201 */       MethodCenterFactory.getMethodCenter().endMethodCenter(this.methodCenterObject);
/*     */     }
/*     */ 
/* 205 */     if (this.objSvrTrace != null) {
/* 206 */       this.objSvrTrace.setSuccess(true);
/* 207 */       this.objSvrTrace.setUseTime((int)(System.currentTimeMillis() - this.startTime));
/*     */ 
/* 209 */       TraceFactory.popTraceLevel();
/*     */     }
/*     */ 
/* 213 */     if (this.isCreateTrace) {
/* 214 */       TraceFactory.writeTraceFile();
/* 215 */       TraceFactory.disableTrace();
/* 216 */       AppTraceMonitor.disableGlobalTrace();
/*     */     }
/*     */ 
/* 220 */     if ((SVMethodMonitor.isEnable()) && (this.startTime > 0L)) {
/* 221 */       SVMethodMonitor.methodInvoke(obj.getClass().getName(), methodName, true, System.currentTimeMillis() - this.startTime, SVMethodMonitor.getCurrentThreadCpuTime() - this.startCpuTime);
/*     */     }
/*     */ 
/* 227 */     if ((this.customInterceptorObject != null) && (this.customInterceptorObject.length != 0))
/* 228 */       for (int i = this.customInterceptorObject.length - 1; i >= 0; --i)
/*     */         try {
/* 230 */           this.customInterceptorObject[i].afterInterceptor(obj, methodName, objectArray);
/*     */         }
/*     */         catch (Throwable ex) {
/* 233 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.customed_afterinterceptor_construct_failed"), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public void exceptionInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 248 */     if (SrvControlFactory.getSrvControl() != null) {
/* 249 */       SrvControlFactory.getSrvControl().endControl(this.srvControlObject, obj, methodName, objectArray);
/*     */     }
/*     */ 
/* 253 */     if (MethodCenterFactory.getMethodCenter() != null) {
/* 254 */       MethodCenterFactory.getMethodCenter().endMethodCenter(this.methodCenterObject);
/*     */     }
/*     */ 
/* 258 */     if (this.objSvrTrace != null) {
/* 259 */       this.objSvrTrace.setSuccess(false);
/* 260 */       this.objSvrTrace.setUseTime((int)(System.currentTimeMillis() - this.startTime));
/*     */ 
/* 262 */       TraceFactory.popTraceLevel();
/*     */     }
/*     */ 
/* 266 */     if (this.isCreateTrace) {
/* 267 */       TraceFactory.writeTraceFile();
/* 268 */       TraceFactory.disableTrace();
/* 269 */       AppTraceMonitor.disableGlobalTrace();
/*     */     }
/*     */ 
/* 273 */     if ((SVMethodMonitor.isEnable()) && (this.startTime > 0L)) {
/* 274 */       SVMethodMonitor.methodInvoke(obj.getClass().getName(), methodName, false, System.currentTimeMillis() - this.startTime, SVMethodMonitor.getCurrentThreadCpuTime() - this.startCpuTime);
/*     */     }
/*     */ 
/* 280 */     if ((this.customInterceptorObject != null) && (this.customInterceptorObject.length != 0))
/* 281 */       for (int i = this.customInterceptorObject.length - 1; i >= 0; --i)
/*     */         try {
/* 283 */           this.customInterceptorObject[i].exceptionInterceptor(obj, methodName, objectArray);
/*     */         }
/*     */         catch (Throwable ex) {
/* 286 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.customed_exceptioninterceptor_construct_failed"), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  65 */       Interceptor objInterceptor = XMLHelper.getInstance().getDefaults().getInterceptor();
/*  66 */       if (objInterceptor != null) {
/*  67 */         Clazz[] clazzs = objInterceptor.getClazzs();
/*  68 */         if (clazzs != null) {
/*  69 */           CUSTOM_INTERCEPTOR_CLASS = new Class[clazzs.length];
/*  70 */           for (int i = 0; i < clazzs.length; ++i) {
/*  71 */             CUSTOM_INTERCEPTOR_CLASS[i] = Class.forName(clazzs[i].getName());
/*     */ 
/*  74 */             HashMap map = new HashMap();
/*  75 */             Property[] objProperty = clazzs[i].getProperties();
/*  76 */             for (int j = 0; j < objProperty.length; ++j) {
/*  77 */               map.put(objProperty[j].getName(), objProperty[j].getValue());
/*     */             }
/*  79 */             PROPERTY.put(CUSTOM_INTERCEPTOR_CLASS[i], map);
/*     */ 
/*  81 */             if (!log.isDebugEnabled())
/*     */               continue;
/*  83 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.customed_interceptor_succeed", new String[] { clazzs[i].getName() }));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  90 */       log.error("Failed to initialize");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.impl.MethodMonitorInterceptorImpl
 * JD-Core Version:    0.5.4
 */