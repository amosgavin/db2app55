/*    */ package com.ai.appframe2.complex.service.impl.client.check;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterFactory;
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ 
/*    */ public class DefaultCheckImpl
/*    */   implements ICheck
/*    */ {
/*    */   public static final String CHECK_THREAD_NAME = "BD-CLUSTER-HB";
/*    */ 
/*    */   public String getCheckThreadName()
/*    */   {
/* 29 */     return "BD-CLUSTER-HB";
/*    */   }
/*    */ 
/*    */   public int getCheckRetryCount()
/*    */   {
/* 37 */     return 8;
/*    */   }
/*    */ 
/*    */   public CenterInfo getCenterInfoByRegionId(String regionId)
/*    */   {
/*    */     try
/*    */     {
/* 47 */       return CenterFactory.createCenterInfoByTypeAndValue("RegionId", regionId);
/*    */     }
/*    */     catch (Exception ex) {
/* 50 */       throw new RuntimeException(ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.check.DefaultCheckImpl
 * JD-Core Version:    0.5.4
 */