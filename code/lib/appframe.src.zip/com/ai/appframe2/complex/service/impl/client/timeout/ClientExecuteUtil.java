/*     */ package com.ai.appframe2.complex.service.impl.client.timeout;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.impl.ClientTimeoutCacheImpl;
/*     */ import com.ai.appframe2.complex.secframe.ICenterUserInfo;
/*     */ import com.ai.appframe2.complex.self.po.ClientTimeout;
/*     */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.concurrent.TimeoutException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class ClientExecuteUtil
/*     */ {
/*  40 */   private static transient Log log = LogFactory.getLog(ClientExecuteUtil.class);
/*     */ 
/*  43 */   private static int GLOBAL_CLIENT_INVOKE_TIMEOUT = -1;
/*     */ 
/*  46 */   private static ExecutorService EXEPOOL = null;
/*     */ 
/*  49 */   private static final Map METHOD_CACHE = new HashMap();
/*     */ 
/*     */   private static String getKey(Class interfaceClass, String methodName, int configParameterCount)
/*     */   {
/* 135 */     return interfaceClass.getName() + "^" + methodName + "^" + configParameterCount;
/*     */   }
/*     */ 
/*     */   private static Method getMethod(Object object, String methodName, Class[] parameterType, String uniqCode)
/*     */     throws Exception
/*     */   {
/* 148 */     int parameterCount = 0;
/* 149 */     if (parameterType != null) {
/* 150 */       parameterCount = parameterType.length;
/*     */     }
/*     */ 
/* 153 */     String key = null;
/* 154 */     if (uniqCode == null) {
/* 155 */       key = object.getClass().getName() + "^" + methodName + "^" + parameterCount;
/*     */     }
/*     */     else {
/* 158 */       key = object.getClass().getName() + "^" + methodName + "^" + parameterCount + "^" + uniqCode;
/*     */     }
/*     */ 
/* 161 */     Method rtn = (Method)METHOD_CACHE.get(key);
/*     */ 
/* 163 */     if (rtn == null) {
/* 164 */       synchronized (METHOD_CACHE) {
/* 165 */         if (!METHOD_CACHE.containsKey(key)) {
/* 166 */           Method method = object.getClass().getMethod(methodName, parameterType);
/* 167 */           if (method == null) {
/* 168 */             String[] classesName = new String[parameterType.length];
/* 169 */             for (int i = 0; i < classesName.length; ++i) {
/* 170 */               classesName[i] = parameterType[i].getName();
/*     */             }
/*     */ 
/* 173 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.not_found_method", new Object[] { object.getClass().getName(), methodName, StringUtils.join(classesName, ",") }));
/*     */           }
/*     */ 
/* 176 */           METHOD_CACHE.put(key, method);
/*     */ 
/* 178 */           if (log.isDebugEnabled()) {
/* 179 */             log.debug("key=" + key + " not found in METHOD_CACHE");
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 184 */         rtn = (Method)METHOD_CACHE.get(key);
/*     */       }
/*     */     }
/*     */ 
/* 188 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static boolean isInvokeWithTimeout(Class interfaceClass, String methodName, int configParameterCount)
/*     */     throws Exception
/*     */   {
/* 201 */     if (GLOBAL_CLIENT_INVOKE_TIMEOUT <= 0) {
/* 202 */       return false;
/*     */     }
/*     */ 
/* 206 */     if (interfaceClass.equals(IBaseSV.class)) {
/* 207 */       return false;
/*     */     }
/*     */ 
/* 210 */     ClientTimeout objClientTimeout = (ClientTimeout)CacheFactory.get(ClientTimeoutCacheImpl.class, getKey(interfaceClass, methodName, configParameterCount));
/*     */ 
/* 212 */     return (objClientTimeout == null) || (objClientTimeout.getTimeoutSecond() > 0);
/*     */   }
/*     */ 
/*     */   public static Object invokeWithTimeout(Class interfaceClass, Object object, String methodName, int configParameterCount, Object[] objectArray, Class[] parameterType, String ptCode)
/*     */     throws Exception
/*     */   {
/* 232 */     Object result = null;
/* 233 */     FutureTask future = null;
/* 234 */     int timeoutSecond = 0;
/*     */     try
/*     */     {
/* 237 */       ClientTimeout objClientTimeout = (ClientTimeout)CacheFactory.get(ClientTimeoutCacheImpl.class, getKey(interfaceClass, methodName, configParameterCount));
/* 238 */       if (objClientTimeout == null)
/*     */       {
/* 240 */         timeoutSecond = GLOBAL_CLIENT_INVOKE_TIMEOUT;
/*     */       }
/*     */       else {
/* 243 */         timeoutSecond = objClientTimeout.getTimeoutSecond();
/*     */       }
/*     */ 
/* 247 */       Method method = getMethod(object, methodName, parameterType, ptCode);
/*     */ 
/* 249 */       if (method == null) {
/* 250 */         List list = new ArrayList();
/* 251 */         for (int i = 0; i < objectArray.length; ++i) {
/* 252 */           list.add(objectArray[i].getClass().getName());
/*     */         }
/*     */ 
/* 255 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.not_found_method", new Object[] { object.getClass().getName(), methodName, StringUtils.join(list.iterator(), ",") }));
/*     */       }
/*     */ 
/* 259 */       if ((objectArray != null) && (objectArray.length > 0) && 
/* 260 */         (objectArray[0] != null) && (objectArray[0] instanceof ICenterUserInfo)) {
/* 261 */         ((ICenterUserInfo)objectArray[0]).setTimeoutSecond(timeoutSecond);
/*     */       }
/*     */ 
/* 266 */       future = new FutureTask(new RemoteInvokeCallable(object, method, objectArray));
/*     */ 
/* 269 */       EXEPOOL.execute(future);
/*     */ 
/* 273 */       result = future.get(timeoutSecond + 1, TimeUnit.SECONDS);
/*     */     }
/*     */     catch (Exception ex) {
/* 276 */       if (future != null) {
/* 277 */         future.cancel(true);
/*     */       }
/*     */ 
/* 280 */       if (ex instanceof TimeoutException) {
/* 281 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.invoke_timeout", new Object[] { interfaceClass.getName(), methodName, "" + timeoutSecond });
/* 282 */         log.error(msg, ex);
/* 283 */         throw new RuntimeException(msg);
/*     */       }
/*     */ 
/* 286 */       throw ex;
/*     */     }
/*     */ 
/* 290 */     return result;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  52 */     boolean isPoolOk = true;
/*     */     try {
/*  54 */       String strPool = AIConfigManager.getConfigItem("CLIENT_INVOKE_TIMEOUT_POOL");
/*  55 */       if (!StringUtils.isBlank(strPool))
/*     */       {
/*  57 */         Map map = new HashMap();
/*  58 */         String[] tmp1 = strPool.split(";");
/*  59 */         if ((tmp1 != null) && (tmp1.length > 0)) {
/*  60 */           for (int i = 0; i < tmp1.length; ++i) {
/*  61 */             String[] tmp2 = tmp1[i].split("=");
/*  62 */             if ((tmp2 != null) && (tmp2.length == 2) && (!StringUtils.isBlank(tmp2[0])) && (!StringUtils.isBlank(tmp2[1]))) {
/*  63 */               map.put(tmp2[0], tmp2[1]);
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*  68 */         String type = (String)map.get("type");
/*  69 */         if (type.equalsIgnoreCase("fixed")) {
/*  70 */           EXEPOOL = Executors.newFixedThreadPool(Integer.parseInt((String)map.get("size")), new TimeoutExecThreadFactory());
/*  71 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.pool_config", new Object[] { map.toString() }));
/*     */         }
/*  73 */         else if (type.equalsIgnoreCase("pool")) {
/*  74 */           int min = Integer.parseInt((String)map.get("min"));
/*  75 */           int max = Integer.parseInt((String)map.get("max"));
/*  76 */           int bufferSize = Integer.parseInt((String)map.get("bufferSize"));
/*  77 */           int keepAliveSecond = Integer.parseInt((String)map.get("keepAliveSecond"));
/*  78 */           EXEPOOL = new ThreadPoolExecutor(min, max, keepAliveSecond, TimeUnit.SECONDS, new LinkedBlockingQueue(bufferSize), new TimeoutExecThreadFactory());
/*  79 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.pool_config", new Object[] { map.toString() }));
/*     */         }
/*     */         else {
/*  82 */           throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.invalid_type", new Object[] { type }));
/*     */         }
/*     */       }
/*     */       else {
/*  86 */         isPoolOk = false;
/*  87 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.no_pool"));
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/*  91 */       isPoolOk = false;
/*     */     }
/*     */ 
/*  96 */     if (isPoolOk) {
/*     */       try {
/*  98 */         String strClientInvokeTimeout = AIConfigManager.getConfigItem("CLIENT_INVOKE_TIMEOUT");
/*  99 */         if (!StringUtils.isBlank(strClientInvokeTimeout)) {
/* 100 */           if (StringUtils.isNumeric(strClientInvokeTimeout)) {
/* 101 */             GLOBAL_CLIENT_INVOKE_TIMEOUT = Integer.parseInt(strClientInvokeTimeout);
/*     */           }
/*     */         }
/*     */         else
/* 105 */           GLOBAL_CLIENT_INVOKE_TIMEOUT = -1;
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 109 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.config_error"), ex);
/* 110 */         GLOBAL_CLIENT_INVOKE_TIMEOUT = -1;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 115 */     if (GLOBAL_CLIENT_INVOKE_TIMEOUT > 0) {
/* 116 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.enable"));
/*     */     }
/*     */     else
/* 119 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil.disable"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil
 * JD-Core Version:    0.5.4
 */