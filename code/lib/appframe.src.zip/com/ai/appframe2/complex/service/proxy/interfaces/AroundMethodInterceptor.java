package com.ai.appframe2.complex.service.proxy.interfaces;

public abstract interface AroundMethodInterceptor
{
  public abstract void beforeInterceptor(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;

  public abstract void afterInterceptor(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;

  public abstract void exceptionInterceptor(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor
 * JD-Core Version:    0.5.4
 */