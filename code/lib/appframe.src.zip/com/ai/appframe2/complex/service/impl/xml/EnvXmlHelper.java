/*    */ package com.ai.appframe2.complex.service.impl.xml;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Env;
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.digester.Digester;
/*    */ 
/*    */ public final class EnvXmlHelper
/*    */ {
/*    */   public static App getApp(String path)
/*    */     throws Exception
/*    */   {
/* 29 */     App rtn = null;
/* 30 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
/*    */ 
/* 32 */     if (input == null)
/*    */     {
/* 35 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { path }));
/*    */     }
/*    */ 
/* 38 */     Digester digester = new Digester();
/*    */ 
/* 40 */     digester.setValidating(false);
/* 41 */     digester.addObjectCreate("app", App.class.getName());
/* 42 */     digester.addSetProperties("app");
/*    */ 
/* 44 */     digester.addObjectCreate("app/cluster", Cluster.class.getName());
/* 45 */     digester.addSetProperties("app/cluster");
/*    */ 
/* 47 */     digester.addObjectCreate("app/cluster/env", Env.class.getName());
/* 48 */     digester.addSetProperties("app/cluster/env");
/*    */ 
/* 50 */     digester.addObjectCreate("app/cluster/env/property", Property.class.getName());
/* 51 */     digester.addSetProperties("app/cluster/env/property");
/*    */ 
/* 54 */     digester.addSetNext("app/cluster", "addCluster", Cluster.class.getName());
/* 55 */     digester.addSetNext("app/cluster/env", "addEnv", Env.class.getName());
/* 56 */     digester.addSetNext("app/cluster/env/property", "addProperty", Property.class.getName());
/*    */ 
/* 58 */     rtn = (App)digester.parse(input);
/* 59 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static Client getClient(String path)
/*    */     throws Exception
/*    */   {
/* 71 */     Client rtn = null;
/* 72 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
/*    */ 
/* 74 */     if (input == null)
/*    */     {
/* 77 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { path }));
/*    */     }
/*    */ 
/* 80 */     Digester digester = new Digester();
/*    */ 
/* 82 */     digester.setValidating(false);
/* 83 */     digester.addObjectCreate("client", Client.class.getName());
/* 84 */     digester.addSetProperties("client");
/*    */ 
/* 86 */     digester.addObjectCreate("client/connect", Connect.class.getName());
/* 87 */     digester.addSetProperties("client/connect");
/*    */ 
/* 90 */     digester.addSetNext("client/connect", "addConnect", Connect.class.getName());
/*    */ 
/* 92 */     rtn = (Client)digester.parse(input);
/* 93 */     return rtn;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.xml.EnvXmlHelper
 * JD-Core Version:    0.5.4
 */