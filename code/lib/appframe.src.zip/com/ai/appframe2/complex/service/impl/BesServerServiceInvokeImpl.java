package com.ai.appframe2.complex.service.impl;

public class BesServerServiceInvokeImpl extends DefaultServerServiceInvokeImpl
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.BesServerServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */