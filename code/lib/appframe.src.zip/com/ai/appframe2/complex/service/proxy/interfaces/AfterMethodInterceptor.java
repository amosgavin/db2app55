package com.ai.appframe2.complex.service.proxy.interfaces;

public abstract interface AfterMethodInterceptor
{
  public abstract void interceptor(Object paramObject, String paramString, Object[] paramArrayOfObject)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.interfaces.AfterMethodInterceptor
 * JD-Core Version:    0.5.4
 */