/*     */ package com.ai.appframe2.complex.service.proxy;
/*     */ 
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AfterMethodInterceptor;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.BeforeMethodInterceptor;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class ProxyInvocationHandler
/*     */   implements InvocationHandler
/*     */ {
/*  26 */   private static transient Log log = LogFactory.getLog(ProxyInvocationHandler.class);
/*     */ 
/*  28 */   private Object _obj = null;
/*  29 */   private Class[] _interceptors_class = null;
/*     */ 
/*  31 */   public ProxyInvocationHandler(Object _obj, Class[] _interceptors_class) { this._obj = _obj;
/*  32 */     this._interceptors_class = _interceptors_class; }
/*     */ 
/*     */ 
/*     */   public Object invoke(Object object, Method method, Object[] objectArray)
/*     */     throws Throwable
/*     */   {
/*  47 */     Object[] _interceptors = new Object[this._interceptors_class.length];
/*  48 */     for (int i = 0; i < this._interceptors_class.length; ++i) {
/*  49 */       _interceptors[i] = this._interceptors_class[i].newInstance();
/*     */     }
/*     */ 
/*  54 */     boolean[] isBeforeSuccess = new boolean[_interceptors.length];
/*     */     try {
/*  56 */       for (int i = 0; i < _interceptors.length; ++i)
/*  57 */         if (_interceptors[i] instanceof BeforeMethodInterceptor) {
/*  58 */           ((BeforeMethodInterceptor)_interceptors[i]).interceptor(this._obj, method.getName(), objectArray);
/*  59 */           isBeforeSuccess[i] = true;
/*     */         }
/*  61 */         else if (_interceptors[i] instanceof AroundMethodInterceptor) {
/*  62 */           ((AroundMethodInterceptor)_interceptors[i]).beforeInterceptor(this._obj, method.getName(), objectArray);
/*  63 */           isBeforeSuccess[i] = true;
/*     */         }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  68 */       log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.failed"), ex);
/*     */ 
/*  71 */       for (int i = _interceptors.length - 1; i >= 0; --i) {
/*  72 */         if ((isBeforeSuccess[i] != 1) || 
/*  74 */           (!_interceptors[i] instanceof AroundMethodInterceptor)) continue;
/*  75 */         ((AroundMethodInterceptor)_interceptors[i]).exceptionInterceptor(this._obj, method.getName(), objectArray);
/*     */       }
/*     */ 
/*  80 */       throw ex;
/*     */     }
/*     */ 
/*  85 */     Object rtn = null;
/*     */     try {
/*  87 */       rtn = method.invoke(this._obj, objectArray);
/*     */     }
/*     */     catch (Throwable ex) {
/*     */       try {
/*  91 */         for (int i = _interceptors.length - 1; i >= 0; --i) {
/*  92 */           if (_interceptors[i] instanceof AroundMethodInterceptor)
/*  93 */             ((AroundMethodInterceptor)_interceptors[i]).exceptionInterceptor(this._obj, method.getName(), objectArray);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex2)
/*     */       {
/*  98 */         log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.exception"), ex2);
/*     */       }
/*     */ 
/* 102 */       Throwable root = null;
/*     */       try
/*     */       {
/* 105 */         root = ExceptionUtils.getRootCause(ex);
/*     */       }
/*     */       catch (Throwable ex3) {
/* 108 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.root_exception"), ex3);
/* 109 */         throw ex;
/*     */       }
/*     */ 
/* 112 */       if (root != null) {
/* 113 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.method_exception"), root);
/* 114 */         throw root;
/*     */       }
/*     */ 
/* 117 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.method_exception"), ex);
/* 118 */       throw ex;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 126 */       for (int i = _interceptors.length - 1; i >= 0; --i) {
/* 127 */         if (_interceptors[i] instanceof AfterMethodInterceptor) {
/* 128 */           ((AfterMethodInterceptor)_interceptors[i]).interceptor(this._obj, method.getName(), objectArray);
/*     */         }
/* 130 */         else if (_interceptors[i] instanceof AroundMethodInterceptor)
/* 131 */           ((AroundMethodInterceptor)_interceptors[i]).afterInterceptor(this._obj, method.getName(), objectArray);
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 136 */       log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.interceptor.triggered.after.failed"), ex);
/*     */     }
/*     */ 
/* 139 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.ProxyInvocationHandler
 * JD-Core Version:    0.5.4
 */