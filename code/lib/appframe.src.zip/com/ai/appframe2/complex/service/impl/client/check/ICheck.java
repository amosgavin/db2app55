package com.ai.appframe2.complex.service.impl.client.check;

import com.ai.appframe2.complex.center.CenterInfo;

public abstract interface ICheck
{
  public abstract String getCheckThreadName();

  public abstract int getCheckRetryCount();

  public abstract CenterInfo getCenterInfoByRegionId(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.check.ICheck
 * JD-Core Version:    0.5.4
 */