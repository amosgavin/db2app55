package com.ai.appframe2.complex.service.interfaces;

public abstract interface ISelfManagedServiceWithRequiredTransaction
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.interfaces.ISelfManagedServiceWithRequiredTransaction
 * JD-Core Version:    0.5.4
 */