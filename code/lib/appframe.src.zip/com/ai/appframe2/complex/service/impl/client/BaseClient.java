/*     */ package com.ai.appframe2.complex.service.impl.client;
/*     */ 
/*     */ import com.ai.appframe2.complex.service.impl.client.timeout.ClientExecuteUtil;
/*     */ import com.ai.appframe2.complex.service.interfaces.IServiceClientControl;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BaseClient
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(BaseClient.class);
/*     */ 
/*  26 */   private static int GLOBAL_VERSION = 0;
/*     */ 
/*  28 */   private Object remoteObject = null;
/*  29 */   private int version = 0;
/*     */ 
/*  31 */   private Class interfaceClass = null;
/*  32 */   private boolean isCrossCenter = false;
/*     */ 
/*     */   public BaseClient(Object remoteObject)
/*     */   {
/*  39 */     this.version = GLOBAL_VERSION;
/*  40 */     this.remoteObject = null;
/*  41 */     this.remoteObject = remoteObject;
/*     */   }
/*     */ 
/*     */   public void setInterfaceClass(Class interfaceClass)
/*     */   {
/*  49 */     this.interfaceClass = interfaceClass;
/*     */   }
/*     */ 
/*     */   public void setCrossCenter(boolean isCrossCenter)
/*     */   {
/*  57 */     this.isCrossCenter = isCrossCenter;
/*     */   }
/*     */ 
/*     */   public Object getRemoteObject()
/*     */   {
/*  65 */     if (this.version == GLOBAL_VERSION)
/*     */     {
/*  67 */       return this.remoteObject;
/*     */     }
/*     */ 
/*  71 */     Object obj = ServiceFactory.getServiceInvoke();
/*  72 */     if (obj instanceof IServiceClientControl) {
/*  73 */       synchronized (this) {
/*  74 */         if (this.version != GLOBAL_VERSION) {
/*  75 */           this.remoteObject = ((IServiceClientControl)obj).getRemoteObject(this.interfaceClass, this.isCrossCenter);
/*  76 */           this.version = GLOBAL_VERSION;
/*  77 */           if (log.isInfoEnabled()) {
/*  78 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.base_client.refetch_remote_object", new String[] { this.interfaceClass.toString(), Boolean.toString(this.isCrossCenter) }));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  83 */       return this.remoteObject;
/*     */     }
/*     */ 
/*  86 */     if (log.isInfoEnabled()) {
/*  87 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.base_client.object_not_impl", new String[] { obj.toString() }));
/*     */     }
/*     */ 
/*  90 */     this.version = GLOBAL_VERSION;
/*  91 */     return this.remoteObject;
/*     */   }
/*     */ 
/*     */   public static synchronized void incrementGlobalVersion()
/*     */   {
/* 100 */     GLOBAL_VERSION += 1;
/*     */   }
/*     */ 
/*     */   protected boolean isInvokeWithTimeout(String methodName, int configParameterCount)
/*     */     throws Exception
/*     */   {
/* 111 */     return ClientExecuteUtil.isInvokeWithTimeout(this.interfaceClass, methodName, configParameterCount);
/*     */   }
/*     */ 
/*     */   protected Object invokeWithTimeout(Object remoteObject, String methodName, int configParameterCount, Object[] objectArray, Class[] parameterType, String uniqCode)
/*     */     throws Exception
/*     */   {
/* 127 */     return ClientExecuteUtil.invokeWithTimeout(this.interfaceClass, remoteObject, methodName, configParameterCount, objectArray, parameterType, uniqCode);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.BaseClient
 * JD-Core Version:    0.5.4
 */