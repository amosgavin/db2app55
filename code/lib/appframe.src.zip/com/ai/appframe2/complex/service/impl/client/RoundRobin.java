/*    */ package com.ai.appframe2.complex.service.impl.client;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.LinkedList;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class RoundRobin
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(RoundRobin.class);
/*    */   private int position;
/*    */   private LinkedList list;
/*    */ 
/*    */   public RoundRobin()
/*    */   {
/* 21 */     this.position = 0;
/* 22 */     this.list = new LinkedList();
/*    */   }
/*    */ 
/*    */   public synchronized Object getByRoundRobin()
/*    */   {
/* 30 */     this.position += 1;
/* 31 */     int lsize = this.list.size();
/* 32 */     if (lsize > 0) {
/* 33 */       if (this.position > lsize - 1) {
/* 34 */         this.position = 0;
/*    */       }
/*    */     }
/*    */     else {
/* 38 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.RoundRobin.load.list.warn"));
/*    */     }
/*    */ 
/* 41 */     Object rtn = this.list.get(this.position);
/* 42 */     if (log.isDebugEnabled()) {
/* 43 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.RoundRobin.load.list.useinfo", new String[] { rtn + "" }));
/*    */     }
/*    */ 
/* 46 */     return rtn;
/*    */   }
/*    */ 
/*    */   public synchronized void put(Object key)
/*    */   {
/* 54 */     if (!this.list.contains(key))
/* 55 */       this.list.add(key);
/*    */   }
/*    */ 
/*    */   public void remove(Object key)
/*    */   {
/* 64 */     synchronized (this.list) {
/* 65 */       if (this.list.contains(key)) {
/* 66 */         this.list.remove(key);
/* 67 */         if (log.isDebugEnabled()) {
/* 68 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.RoundRobin.load.remove.error", new String[] { key + "" }));
/*    */         }
/*    */ 
/*    */       }
/* 72 */       else if (log.isDebugEnabled()) {
/* 73 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.RoundRobin.load.remove.warn", new String[] { key + "" }));
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public synchronized void clear()
/*    */   {
/* 83 */     this.position = 0;
/* 84 */     this.list.clear();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.RoundRobin
 * JD-Core Version:    0.5.4
 */