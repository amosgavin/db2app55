package com.ai.appframe2.complex.service.impl;

public class Was61ServerServiceInvokeImpl extends DefaultServerServiceInvokeImpl
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.Was61ServerServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */