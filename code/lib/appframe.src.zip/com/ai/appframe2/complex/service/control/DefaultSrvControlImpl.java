/*     */ package com.ai.appframe2.complex.service.control;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultSrvControlImpl
/*     */   implements ISrvControl
/*     */ {
/*  38 */   private static transient Log log = LogFactory.getLog(DefaultSrvControlImpl.class);
/*     */ 
/*  40 */   private static ThreadLocal THREAD_CONTROL = new ThreadLocal();
/*  41 */   private static int DEFAULT_LIMIT_COUNT = -1;
/*     */ 
/*  44 */   private static String[] CFG_SERVICE_DESC_KEY = null;
/*     */ 
/*  47 */   private static HashMap CFG_METHOD_DESC_KEY = new HashMap();
/*     */ 
/*  49 */   private static HashMap CFG_SERVICE_METHOD_MAPPING = new HashMap();
/*     */ 
/*  52 */   private static HashMap FULL_SRV_CONFIG_COUNT = new HashMap();
/*     */ 
/*  54 */   private static HashMap FULL_SRV_RUNTIME_COUNT = new HashMap();
/*     */ 
/*     */   public Object startControl(Object serviceObject, String methodName, Object[] objectArray)
/*     */   {
/*  70 */     if (isThreadControl())
/*     */     {
/*  72 */       return null;
/*     */     }
/*     */ 
/*  75 */     Object rtn = null;
/*  76 */     String serviceName = serviceObject.getClass().getName();
/*     */ 
/*  78 */     Integer configCount = getSrvConfigCount(serviceName, methodName);
/*  79 */     if (configCount.intValue() < 0)
/*     */     {
/*  81 */       rtn = null;
/*     */     }
/*     */     else {
/*  84 */       AtomicInteger runtimeCount = getSrvRuntimeCount(serviceName, methodName);
/*  85 */       int current = runtimeCount.incrementAndGet();
/*  86 */       if (current > configCount.intValue()) {
/*  87 */         runtimeCount.decrementAndGet();
/*  88 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.limit", new String[] { serviceName, "" + configCount.intValue() }));
/*  89 */         throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.limit", new String[] { serviceName, "" + configCount.intValue() }));
/*     */       }
/*     */ 
/*  94 */       rtn = runtimeCount;
/*     */     }
/*     */ 
/*  99 */     setThreadControl();
/*     */ 
/* 101 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void endControl(Object controlObject, Object serviceObject, String methodName, Object[] objectArray)
/*     */   {
/* 112 */     if (controlObject != null) {
/* 113 */       ((AtomicInteger)controlObject).decrementAndGet();
/*     */     }
/*     */ 
/* 116 */     removeThreadControl();
/*     */   }
/*     */ 
/*     */   private boolean isThreadControl()
/*     */   {
/* 125 */     return THREAD_CONTROL.get() != null;
/*     */   }
/*     */ 
/*     */   private void setThreadControl()
/*     */   {
/* 136 */     THREAD_CONTROL.set(Boolean.TRUE);
/*     */   }
/*     */ 
/*     */   private void removeThreadControl()
/*     */   {
/* 143 */     THREAD_CONTROL.set(null);
/*     */   }
/*     */ 
/*     */   private Integer getSrvConfigCount(String serviceName, String methodName)
/*     */   {
/* 153 */     Integer count = (Integer)FULL_SRV_CONFIG_COUNT.get(wrapper(serviceName, methodName));
/* 154 */     if (count == null) {
/* 155 */       synchronized (FULL_SRV_CONFIG_COUNT) {
/* 156 */         if (!FULL_SRV_CONFIG_COUNT.containsKey(wrapper(serviceName, methodName))) {
/* 157 */           Integer configCount = null;
/*     */ 
/* 160 */           for (int i = 0; i < CFG_SERVICE_DESC_KEY.length; ++i) {
/* 161 */             if (serviceName.indexOf(CFG_SERVICE_DESC_KEY[i]) != -1) {
/* 162 */               String[] method_desc_key = (String[])(String[])CFG_METHOD_DESC_KEY.get(CFG_SERVICE_DESC_KEY[i]);
/* 163 */               for (int j = 0; j < method_desc_key.length; ++j) {
/* 164 */                 if (methodName.indexOf(method_desc_key[i]) != -1) {
/* 165 */                   configCount = (Integer)CFG_SERVICE_METHOD_MAPPING.get(wrapper(CFG_SERVICE_DESC_KEY[i], method_desc_key[i]));
/* 166 */                   break;
/*     */                 }
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 172 */             if (configCount != null) {
/*     */               break;
/*     */             }
/*     */           }
/*     */ 
/* 177 */           if (configCount == null)
/*     */           {
/* 179 */             FULL_SRV_CONFIG_COUNT.put(wrapper(serviceName, methodName), new Integer(DEFAULT_LIMIT_COUNT));
/*     */           }
/*     */           else
/*     */           {
/* 183 */             FULL_SRV_CONFIG_COUNT.put(wrapper(serviceName, methodName), new Integer(configCount.intValue()));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 188 */       count = (Integer)FULL_SRV_CONFIG_COUNT.get(wrapper(serviceName, methodName));
/*     */     }
/*     */ 
/* 191 */     return count;
/*     */   }
/*     */ 
/*     */   private AtomicInteger getSrvRuntimeCount(String serviceName, String methodName)
/*     */   {
/* 201 */     AtomicInteger count = (AtomicInteger)FULL_SRV_RUNTIME_COUNT.get(wrapper(serviceName, methodName));
/* 202 */     if (count == null) {
/* 203 */       synchronized (FULL_SRV_RUNTIME_COUNT) {
/* 204 */         if (!FULL_SRV_RUNTIME_COUNT.containsKey(wrapper(serviceName, methodName)))
/*     */         {
/* 206 */           FULL_SRV_RUNTIME_COUNT.put(wrapper(serviceName, methodName), new AtomicInteger(0));
/*     */         }
/*     */       }
/* 209 */       count = (AtomicInteger)FULL_SRV_RUNTIME_COUNT.get(wrapper(serviceName, methodName));
/*     */     }
/*     */ 
/* 212 */     return count;
/*     */   }
/*     */ 
/*     */   public void refreshControlData()
/*     */   {
/*     */     try
/*     */     {
/* 220 */       SML defaultSML = getDefaultServiceControlConfig();
/* 221 */       SML[] detailSML = getDetailServiceControlConfig();
/* 222 */       List serviceDescList = new ArrayList();
/* 223 */       HashMap methodDescMap = new HashMap();
/* 224 */       HashMap serviceMethodMap = new HashMap();
/* 225 */       for (int i = 0; i < detailSML.length; ++i) {
/* 226 */         serviceDescList.add(detailSML[i].serviceName);
/* 227 */         serviceMethodMap.put(wrapper(detailSML[i].serviceName, detailSML[i].methodName), new Integer(detailSML[i].limitCount));
/*     */ 
/* 229 */         if (methodDescMap.containsKey(detailSML[i].serviceName)) {
/* 230 */           List l = (List)methodDescMap.get(detailSML[i].serviceName);
/* 231 */           l.add(detailSML[i].methodName);
/*     */         }
/*     */         else {
/* 234 */           List l = new ArrayList();
/* 235 */           l.add(detailSML[i].methodName);
/* 236 */           methodDescMap.put(detailSML[i].serviceName, l);
/*     */         }
/*     */       }
/*     */ 
/* 240 */       DEFAULT_LIMIT_COUNT = defaultSML.limitCount;
/* 241 */       CFG_SERVICE_DESC_KEY = (String[])(String[])serviceDescList.toArray(new String[0]);
/*     */ 
/* 243 */       Set key = methodDescMap.keySet();
/* 244 */       for (Iterator iter = key.iterator(); iter.hasNext(); ) {
/* 245 */         String item = (String)iter.next();
/* 246 */         List value = (List)methodDescMap.get(item);
/* 247 */         methodDescMap.put(item, (String[])(String[])value.toArray(new String[0]));
/*     */       }
/* 249 */       CFG_METHOD_DESC_KEY = methodDescMap;
/* 250 */       CFG_SERVICE_METHOD_MAPPING = serviceMethodMap;
/*     */     }
/*     */     catch (Throwable ex) {
/* 253 */       DEFAULT_LIMIT_COUNT = -1;
/* 254 */       CFG_SERVICE_DESC_KEY = null;
/* 255 */       CFG_METHOD_DESC_KEY = null;
/* 256 */       CFG_SERVICE_METHOD_MAPPING = null;
/* 257 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.refresh.exception"), ex);
/*     */     }
/*     */ 
/* 261 */     FULL_SRV_CONFIG_COUNT.clear();
/*     */   }
/*     */ 
/*     */   private SML getDefaultServiceControlConfig()
/*     */     throws Exception
/*     */   {
/* 270 */     SML rtn = null;
/* 271 */     List l = getSMLByDefault();
/* 272 */     if (l.size() == 0) {
/* 273 */       rtn = new SML(null, null, -1);
/*     */     }
/* 275 */     else if (l.size() == 1) {
/* 276 */       rtn = (SML)l.get(0);
/*     */     }
/*     */     else {
/* 279 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.control.data.not_only"));
/*     */     }
/* 281 */     return rtn;
/*     */   }
/*     */ 
/*     */   private SML[] getDetailServiceControlConfig()
/*     */     throws Exception
/*     */   {
/* 290 */     List list = new ArrayList();
/* 291 */     String currentServerName = RuntimeServerUtil.getServerName();
/*     */ 
/* 293 */     if (!StringUtils.isBlank(currentServerName)) {
/* 294 */       HashMap map = getAllSML();
/* 295 */       String[] all = (String[])(String[])map.keySet().toArray(new String[0]);
/* 296 */       for (int i = 0; i < all.length; ++i) {
/* 297 */         if (currentServerName.indexOf(all[i]) != -1) {
/* 298 */           list = (List)map.get(all[i]);
/* 299 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 304 */     return (SML[])(SML[])list.toArray(new SML[0]);
/*     */   }
/*     */ 
/*     */   private String wrapper(String serviceName, String methodName)
/*     */   {
/* 314 */     StringBuilder sb = new StringBuilder(20);
/* 315 */     sb.append(serviceName).append("^").append(methodName);
/* 316 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private HashMap getAllSML()
/*     */     throws Exception
/*     */   {
/* 325 */     HashMap map = new HashMap();
/* 326 */     Connection conn = null;
/* 327 */     PreparedStatement ptmt = null;
/* 328 */     ResultSet rs = null;
/*     */     try {
/* 330 */       conn = ServiceManager.getSession().getNewConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 331 */       ptmt = conn.prepareStatement("select * from cfg_service_control where state='U' order by length(server_name) desc,length(service_name) desc,length(method_name) desc");
/*     */ 
/* 333 */       rs = ptmt.executeQuery();
/* 334 */       while (rs.next()) {
/* 335 */         String serverName = rs.getString("SERVER_NAME");
/* 336 */         String serviceName = rs.getString("SERVICE_NAME");
/* 337 */         String methodName = rs.getString("METHOD_NAME");
/*     */ 
/* 340 */         if (methodName == null) {
/* 341 */           methodName = "";
/*     */         }
/*     */ 
/* 344 */         int limitCount = rs.getInt("LIMIT_COUNT");
/* 345 */         if (map.containsKey(serverName)) {
/* 346 */           List l = (List)map.get(serverName);
/* 347 */           l.add(new SML(serviceName, methodName, limitCount));
/*     */         }
/*     */         else {
/* 350 */           List l = new ArrayList();
/* 351 */           l.add(new SML(serviceName, methodName, limitCount));
/* 352 */           map.put(serverName, l);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 360 */       if (rs != null) {
/* 361 */         rs.close();
/*     */       }
/* 363 */       if (ptmt != null) {
/* 364 */         ptmt.close();
/*     */       }
/* 366 */       if (conn != null) {
/* 367 */         conn.close();
/*     */       }
/*     */     }
/* 370 */     return map;
/*     */   }
/*     */ 
/*     */   private List getSMLByDefault()
/*     */     throws Exception
/*     */   {
/* 379 */     List l = new ArrayList();
/* 380 */     Connection conn = null;
/* 381 */     PreparedStatement ptmt = null;
/* 382 */     ResultSet rs = null;
/*     */     try {
/* 384 */       conn = ServiceManager.getSession().getNewConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 385 */       ptmt = conn.prepareStatement("select * from cfg_service_control where server_name = ? and state='U' order by length(server_name) desc,length(service_name) desc,length(method_name) desc");
/*     */ 
/* 387 */       ptmt.setString(1, "DEFAULT");
/* 388 */       rs = ptmt.executeQuery();
/* 389 */       while (rs.next()) {
/* 390 */         String serviceName = rs.getString("SERVICE_NAME");
/* 391 */         String methodName = rs.getString("METHOD_NAME");
/* 392 */         int limitCount = rs.getInt("LIMIT_COUNT");
/* 393 */         l.add(new SML(serviceName, methodName, limitCount));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 400 */       if (rs != null) {
/* 401 */         rs.close();
/*     */       }
/* 403 */       if (ptmt != null) {
/* 404 */         ptmt.close();
/*     */       }
/* 406 */       if (conn != null) {
/* 407 */         conn.close();
/*     */       }
/*     */     }
/* 410 */     return l;
/*     */   }
/*     */ 
/*     */   static class SML
/*     */   {
/* 415 */     String serviceName = null;
/* 416 */     String methodName = null;
/* 417 */     int limitCount = -1;
/*     */ 
/* 419 */     SML(String serviceName, String methodName, int limitCount) { this.serviceName = serviceName;
/* 420 */       this.methodName = methodName;
/* 421 */       this.limitCount = limitCount; }
/*     */ 
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.control.DefaultSrvControlImpl
 * JD-Core Version:    0.5.4
 */