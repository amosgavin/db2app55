/*    */ package com.ai.appframe2.complex.service.impl.xml;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Env;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Cluster
/*    */ {
/* 17 */   private List list = new ArrayList();
/*    */   private String name;
/*    */   private String desc;
/*    */   private String bigdistrictflag;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 24 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 27 */     this.name = name;
/*    */   }
/*    */   public String getDesc() {
/* 30 */     return this.desc;
/*    */   }
/*    */   public void setDesc(String desc) {
/* 33 */     this.desc = desc;
/*    */   }
/*    */ 
/*    */   public void addEnv(Env env) {
/* 37 */     this.list.add(env);
/*    */   }
/*    */ 
/*    */   public Env[] getEnvs() {
/* 41 */     return (Env[])(Env[])this.list.toArray(new Env[0]);
/*    */   }
/*    */   public String getBigdistrictflag() {
/* 44 */     return this.bigdistrictflag;
/*    */   }
/*    */   public void setBigdistrictflag(String bigdistrictflag) {
/* 47 */     this.bigdistrictflag = bigdistrictflag;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.xml.Cluster
 * JD-Core Version:    0.5.4
 */