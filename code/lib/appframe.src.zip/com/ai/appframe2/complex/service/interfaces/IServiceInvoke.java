package com.ai.appframe2.complex.service.interfaces;

public abstract interface IServiceInvoke
{
  public abstract Object getService(Class paramClass);

  public abstract Object getService(String paramString);

  public abstract Object getCrossCenterService(Class paramClass);

  public abstract Object getCrossCenterService(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.interfaces.IServiceInvoke
 * JD-Core Version:    0.5.4
 */