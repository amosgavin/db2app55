/*     */ package com.ai.appframe2.complex.service.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.SessionManager;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.service.impl.client.BaseClient;
/*     */ import com.ai.appframe2.complex.service.impl.client.BeanCache;
/*     */ import com.ai.appframe2.complex.service.impl.client.CheckThread;
/*     */ import com.ai.appframe2.complex.service.impl.client.EnvCache;
/*     */ import com.ai.appframe2.complex.service.impl.xml.App;
/*     */ import com.ai.appframe2.complex.service.impl.xml.Client;
/*     */ import com.ai.appframe2.complex.service.impl.xml.Cluster;
/*     */ import com.ai.appframe2.complex.service.impl.xml.Connect;
/*     */ import com.ai.appframe2.complex.service.impl.xml.EnvXmlHelper;
/*     */ import com.ai.appframe2.complex.service.interfaces.IServiceClientControl;
/*     */ import com.ai.appframe2.complex.service.interfaces.IServiceInvoke;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.daos.Dao;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Env;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Proxy;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.Timer;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultClientServiceInvokeImpl
/*     */   implements IServiceInvoke, IServiceClientControl
/*     */ {
/*  48 */   private static transient Log log = LogFactory.getLog(DefaultClientServiceInvokeImpl.class);
/*     */ 
/*  50 */   protected static HashMap SERVICES_DEFINE = new HashMap();
/*  51 */   protected static HashMap DAOS_DEFINE = new HashMap();
/*     */ 
/*  54 */   protected static EnvCache ENV_CACHE = null;
/*     */ 
/*  57 */   public static String USE_APP_CLUSTER = null;
/*     */ 
/*  59 */   public static boolean BIG_DISTRICT_MODE = false;
/*     */ 
/*  61 */   protected static HashMap BIG_DISTRICT_MAPPING = new HashMap();
/*     */ 
/*     */   public Object getCrossCenterService(Class interfaceClass)
/*     */   {
/* 263 */     if (log.isInfoEnabled()) {
/* 264 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.warn"));
/*     */     }
/*     */ 
/* 268 */     Object rtn = null;
/*     */     try {
/* 270 */       if (StringUtils.lastIndexOf(interfaceClass.getName(), "SV") != -1) {
/* 271 */         rtn = getCrossCenterSVObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass));
/*     */       } else {
/* 273 */         if (StringUtils.lastIndexOf(interfaceClass.getName(), "DAO") != -1) {
/* 274 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.nosupport_dao"));
/*     */         }
/*     */ 
/* 277 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { interfaceClass.getName() }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 281 */       throw new RuntimeException(ex);
/*     */     }
/* 283 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Object getCrossCenterService(String serviceId)
/*     */   {
/* 292 */     if (log.isInfoEnabled()) {
/* 293 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.becare_use_getcross"));
/*     */     }
/*     */ 
/* 296 */     Object rtn = null;
/*     */     try {
/* 298 */       boolean isFound = false;
/*     */ 
/* 300 */       if (DAOS_DEFINE.containsKey(serviceId))
/*     */       {
/* 302 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.dao.warn"));
/*     */       }
/*     */ 
/* 305 */       if ((!isFound) && (SERVICES_DEFINE.containsKey(serviceId)))
/*     */       {
/* 307 */         Service service = (Service)SERVICES_DEFINE.get(serviceId);
/* 308 */         Property[] properties = service.getPropertys();
/* 309 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 310 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 311 */         rtn = getCrossCenterSVObject(Class.forName(interfaceClass), Class.forName(implClass));
/* 312 */         isFound = true;
/*     */       }
/*     */ 
/* 315 */       if (!isFound)
/*     */       {
/* 317 */         if (StringUtils.lastIndexOf(serviceId, "SV") != -1) {
/* 318 */           rtn = getCrossCenterSVObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId));
/*     */         } else {
/* 320 */           if (StringUtils.lastIndexOf(serviceId, "DAO") != -1) {
/* 321 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.dao.warn"));
/*     */           }
/*     */ 
/* 324 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { serviceId }));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 330 */       throw new RuntimeException(ex);
/*     */     }
/* 332 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Object getService(Class interfaceClass)
/*     */   {
/* 343 */     Object rtn = null;
/*     */     try {
/* 345 */       String interfaceName = interfaceClass.getName();
/* 346 */       if (StringUtils.lastIndexOf(interfaceName, "SV") != -1) {
/* 347 */         rtn = getSVObject(interfaceClass, MiscHelper.getImplClassByInterClassName(interfaceClass));
/*     */       } else {
/* 349 */         if (StringUtils.lastIndexOf(interfaceName, "DAO") != -1) {
/* 350 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.dao.warn"));
/*     */         }
/*     */ 
/* 353 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { interfaceName }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 358 */       throw new RuntimeException(ex);
/*     */     }
/* 360 */     return rtn;
/*     */   }
/*     */ 
/*     */   public Object getService(String serviceId)
/*     */   {
/* 370 */     Object rtn = null;
/*     */     try {
/* 372 */       boolean isFound = false;
/*     */ 
/* 374 */       if (DAOS_DEFINE.containsKey(serviceId))
/*     */       {
/* 376 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.dao.warn"));
/*     */       }
/*     */ 
/* 379 */       if ((!isFound) && (SERVICES_DEFINE.containsKey(serviceId)))
/*     */       {
/* 381 */         Service service = (Service)SERVICES_DEFINE.get(serviceId);
/* 382 */         Property[] properties = service.getPropertys();
/* 383 */         String interfaceClass = MiscHelper.getInterfaceClassByPropertyAndServiceId(serviceId, properties);
/* 384 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(serviceId, properties);
/* 385 */         rtn = getSVObject(Class.forName(interfaceClass), Class.forName(implClass));
/* 386 */         isFound = true;
/*     */       }
/*     */ 
/* 389 */       if (!isFound)
/*     */       {
/* 391 */         if (StringUtils.lastIndexOf(serviceId, "SV") != -1) {
/* 392 */           rtn = getSVObject(Class.forName(serviceId), MiscHelper.getImplClassByInterClassName(serviceId));
/*     */         } else {
/* 394 */           if (StringUtils.lastIndexOf(serviceId, "DAO") != -1) {
/* 395 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.dao.warn"));
/*     */           }
/*     */ 
/* 398 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getCrossCenterService.exception", new String[] { serviceId }));
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 404 */       throw new RuntimeException(ex);
/*     */     }
/* 406 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected Object getCrossCenterSVObject(Class interfaceClass, Class implClass)
/*     */     throws Exception
/*     */   {
/* 419 */     Object remoteObject = getEJBObject(interfaceClass, true);
/*     */ 
/* 422 */     Constructor objConstructor = MiscHelper.getEJBClientConstructor(interfaceClass);
/*     */ 
/* 424 */     Object rtn = objConstructor.newInstance(new Object[] { remoteObject });
/*     */ 
/* 426 */     if ((rtn != null) && (rtn instanceof BaseClient)) {
/* 427 */       ((BaseClient)rtn).setInterfaceClass(interfaceClass);
/* 428 */       ((BaseClient)rtn).setCrossCenter(true);
/*     */     }
/* 430 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected Object getSVObject(Class interfaceClass, Class implClass)
/*     */     throws Exception
/*     */   {
/* 443 */     Object remoteObject = getEJBObject(interfaceClass, false);
/*     */ 
/* 446 */     Constructor objConstructor = MiscHelper.getEJBClientConstructor(interfaceClass);
/*     */ 
/* 448 */     Object rtn = objConstructor.newInstance(new Object[] { remoteObject });
/*     */ 
/* 450 */     if ((rtn != null) && (rtn instanceof BaseClient)) {
/* 451 */       ((BaseClient)rtn).setInterfaceClass(interfaceClass);
/* 452 */       ((BaseClient)rtn).setCrossCenter(false);
/*     */     }
/* 454 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected Object getEJBObject(Class interfaceClass, boolean isCrossCenter)
/*     */     throws Exception
/*     */   {
/* 465 */     Object obj = null;
/*     */ 
/* 468 */     if (isCrossCenter) {
/* 469 */       obj = BeanCache.getCrossCenterRemoteObject(ENV_CACHE, MiscHelper.getJndiNameByInterClassName(interfaceClass), MiscHelper.getHomeClassNameByInterClassName(interfaceClass));
/*     */     }
/* 473 */     else if (BIG_DISTRICT_MODE)
/*     */     {
/* 475 */       String bigdistrict = null;
/*     */ 
/* 477 */       if (CenterFactory.isSetCenterInfo())
/*     */       {
/* 479 */         bigdistrict = (String)BIG_DISTRICT_MAPPING.get(CenterFactory.getCenterInfo().getRegion());
/* 480 */         if (StringUtils.isBlank(bigdistrict)) {
/* 481 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getEJBObject.bigdistrict.exception", new String[] { CenterFactory.getCenterInfo().getRegion() }));
/*     */         }
/*     */ 
/* 484 */         if (log.isDebugEnabled()) {
/* 485 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getEJBObject.bigdistrict.warn", new String[] { CenterFactory.getCenterInfo().getRegion(), bigdistrict }));
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 491 */         boolean isUseUserRegionId = false;
/*     */ 
/* 494 */         UserInfoInterface userInfo = SessionManager.__getUserWithOutLog();
/* 495 */         if (userInfo != null) {
/* 496 */           String userRegionId = userInfo.get("REGION_ID").toString();
/* 497 */           if ((!StringUtils.isBlank(userRegionId)) && (!userRegionId.trim().equalsIgnoreCase("X"))) {
/* 498 */             bigdistrict = (String)BIG_DISTRICT_MAPPING.get(userRegionId);
/* 499 */             if (bigdistrict != null) {
/* 500 */               isUseUserRegionId = true;
/* 501 */               if (log.isDebugEnabled()) {
/* 502 */                 log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getEJBObject.bigdistrict.region_error", new String[] { userRegionId, bigdistrict }));
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 509 */         if (!isUseUserRegionId) {
/* 510 */           bigdistrict = ENV_CACHE.getRoundRobinBigDistrict();
/*     */ 
/* 512 */           if (log.isDebugEnabled()) {
/* 513 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getEJBObject.bigdistrict.round_error", new String[] { bigdistrict }));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 518 */       obj = BeanCache.getRemoteObjectOnBigDistrict(ENV_CACHE, bigdistrict, MiscHelper.getJndiNameByInterClassName(interfaceClass), MiscHelper.getHomeClassNameByInterClassName(interfaceClass));
/*     */     }
/*     */     else
/*     */     {
/* 523 */       String center = null;
/*     */ 
/* 525 */       if (CenterFactory.isSetCenterInfo()) {
/* 526 */         if (log.isDebugEnabled()) {
/* 527 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.getEJBObject.bigdistrict.region_useinfo", new String[] { CenterFactory.getCenterInfo().getCenter() }));
/*     */         }
/*     */ 
/* 531 */         center = CenterFactory.getCenterInfo().getCenter();
/*     */       }
/*     */       else {
/* 534 */         center = ENV_CACHE.getRoundRobinCenter();
/*     */       }
/*     */ 
/* 537 */       obj = BeanCache.getRemoteObject(ENV_CACHE, center, MiscHelper.getJndiNameByInterClassName(interfaceClass), MiscHelper.getHomeClassNameByInterClassName(interfaceClass));
/*     */     }
/*     */ 
/* 541 */     return obj;
/*     */   }
/*     */ 
/*     */   public void reconnect()
/*     */     throws Exception
/*     */   {
/* 550 */     ENV_CACHE.reconnect();
/* 551 */     BeanCache.clear();
/* 552 */     BaseClient.incrementGlobalVersion();
/*     */   }
/*     */ 
/*     */   public void connect(String group)
/*     */     throws Exception
/*     */   {
/* 561 */     ENV_CACHE.connect(group);
/* 562 */     BeanCache.clear();
/* 563 */     BaseClient.incrementGlobalVersion();
/*     */   }
/*     */ 
/*     */   public Map listGroups()
/*     */     throws Exception
/*     */   {
/* 572 */     return ENV_CACHE.listGroups();
/*     */   }
/*     */ 
/*     */   public String getCurrentAppCluster()
/*     */     throws Exception
/*     */   {
/* 581 */     return ENV_CACHE.getCurrentAppCluster();
/*     */   }
/*     */ 
/*     */   public String getOldAppCluster()
/*     */     throws Exception
/*     */   {
/* 590 */     return ENV_CACHE.getOldAppCluster();
/*     */   }
/*     */ 
/*     */   public Object getRemoteObject(Class interfaceClass, boolean isCrossCenter)
/*     */   {
/*     */     try
/*     */     {
/* 601 */       return getEJBObject(interfaceClass, isCrossCenter);
/*     */     }
/*     */     catch (Exception ex) {
/* 604 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  67 */       Service[] services = XMLHelper.getInstance().getServices();
/*  68 */       for (int i = 0; i < services.length; ++i) {
/*  69 */         SERVICES_DEFINE.put(services[i].getId(), services[i]);
/*     */       }
/*     */ 
/*  73 */       Dao[] daos = XMLHelper.getInstance().getDaos();
/*  74 */       for (int i = 0; i < daos.length; ++i) {
/*  75 */         DAOS_DEFINE.put(daos[i].getId(), daos[i]);
/*     */       }
/*     */ 
/*  79 */       Set servicekeys = SERVICES_DEFINE.keySet();
/*  80 */       for (Iterator iter = servicekeys.iterator(); iter.hasNext(); ) {
/*  81 */         String item = (String)iter.next();
/*  82 */         if (DAOS_DEFINE.containsKey(item)) {
/*  83 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_warn"));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  88 */       boolean isAdvance = false;
/*  89 */       String serverXmlPath = null;
/*  90 */       String clientXmlPath = null;
/*  91 */       Property[] objProperty = XMLHelper.getInstance().getDefaults().getProxy().getClazz().getProperties();
/*  92 */       if (objProperty != null) {
/*  93 */         for (int i = 0; i < objProperty.length; ++i) {
/*  94 */           if ((objProperty[i].getName().equalsIgnoreCase("isAdvance")) && (objProperty[i].getValue().equalsIgnoreCase("true"))) {
/*  95 */             isAdvance = true;
/*     */           }
/*  97 */           else if (objProperty[i].getName().equalsIgnoreCase("server")) {
/*  98 */             serverXmlPath = objProperty[i].getValue().trim();
/*     */           }
/* 100 */           else if (objProperty[i].getName().equalsIgnoreCase("client")) {
/* 101 */             clientXmlPath = objProperty[i].getValue().trim();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 107 */       Env[] advanceEnv = null;
/* 108 */       Cluster[] objCluster = null;
/* 109 */       String appcluster = null;
/* 110 */       if (isAdvance) {
/* 111 */         if (StringUtils.isBlank(serverXmlPath)) {
/* 112 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_advance_noserver"));
/*     */         }
/* 114 */         if (StringUtils.isBlank(clientXmlPath)) {
/* 115 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_advance_noclient"));
/*     */         }
/*     */ 
/* 118 */         String clientName = RuntimeServerUtil.getServerName();
/*     */ 
/* 124 */         if (StringUtils.isBlank(clientName)) {
/* 125 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_setwarn"));
/*     */         }
/*     */ 
/* 128 */         appcluster = null;
/* 129 */         Connect[] connects = EnvXmlHelper.getClient(clientXmlPath).getConnects();
/* 130 */         for (int i = 0; i < connects.length; ++i) {
/* 131 */           if (connects[i].getName().equalsIgnoreCase(clientName)) {
/* 132 */             appcluster = connects[i].getAppcluster();
/* 133 */             break;
/*     */           }
/*     */         }
/*     */ 
/* 137 */         if (StringUtils.isBlank(appcluster)) {
/* 138 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_client_setwarn", new String[] { clientName }));
/*     */         }
/*     */ 
/* 141 */         objCluster = EnvXmlHelper.getApp(serverXmlPath).getClusters();
/* 142 */         for (int i = 0; i < objCluster.length; ++i) {
/* 143 */           if (objCluster[i].getName().equalsIgnoreCase(appcluster)) {
/* 144 */             advanceEnv = objCluster[i].getEnvs();
/* 145 */             if ((StringUtils.isBlank(objCluster[i].getBigdistrictflag())) || (!objCluster[i].getBigdistrictflag().trim().equalsIgnoreCase("true"))) break;
/* 146 */             BIG_DISTRICT_MODE = true; break;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 152 */         if (advanceEnv == null) {
/* 153 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_client_set_allwarn", new String[] { clientName, appcluster }));
/*     */         }
/*     */ 
/* 157 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.use_advance"));
/* 158 */         if (BIG_DISTRICT_MODE) {
/* 159 */           System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.cluster_use_advance"));
/* 160 */           InputStream bigdistrictIO = Thread.currentThread().getContextClassLoader().getResourceAsStream("bigdistrict.properties");
/*     */ 
/* 162 */           if (bigdistrictIO == null) {
/* 163 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_find_properties_warn"));
/*     */           }
/*     */ 
/* 166 */           Properties p = new Properties();
/* 167 */           p.load(bigdistrictIO);
/*     */ 
/* 169 */           Set set = p.keySet();
/* 170 */           for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/* 171 */             String item = (String)iter.next();
/* 172 */             BIG_DISTRICT_MAPPING.put(item.trim(), p.getProperty(item).trim());
/*     */           }
/* 174 */           System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict_mapping", new String[] { BIG_DISTRICT_MAPPING.toString() }));
/*     */         }
/*     */         else {
/* 177 */           System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.cluster_not_use_advance"));
/*     */         }
/*     */ 
/* 180 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client", new String[] { clientName }));
/* 181 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.use_cluster", new String[] { appcluster }));
/* 182 */         USE_APP_CLUSTER = appcluster;
/* 183 */         for (int i = 0; i < advanceEnv.length; ++i) {
/* 184 */           System.out.println(advanceEnv[i].toString());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 190 */       Env[] env = null;
/* 191 */       if (isAdvance) {
/* 192 */         env = advanceEnv;
/*     */       }
/*     */       else {
/* 195 */         env = XMLHelper.getInstance().getDefaults().getProxy().getEnvs();
/*     */       }
/*     */ 
/* 198 */       if (env == null) {
/* 199 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_defaults.setwarn"));
/*     */       }
/*     */ 
/* 202 */       boolean isCrossCenter = false;
/* 203 */       for (int i = 0; i < env.length; ++i) {
/* 204 */         if (env[i].getCenter().equals("0")) {
/* 205 */           isCrossCenter = true;
/* 206 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 210 */       if (!isCrossCenter) {
/* 211 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.define_defaults.setcenter_warn"));
/*     */       }
/*     */ 
/* 215 */       if (isAdvance) {
/* 216 */         ENV_CACHE = new EnvCache(env, objCluster, appcluster);
/*     */       }
/*     */       else {
/* 219 */         ENV_CACHE = new EnvCache(env);
/*     */       }
/*     */ 
/* 225 */       if (BIG_DISTRICT_MODE)
/*     */       {
/* 227 */         int start = 300000;
/* 228 */         int interval = 30000;
/* 229 */         if (objProperty != null) {
/* 230 */           for (int i = 0; i < objProperty.length; ++i) {
/* 231 */             if (objProperty[i].getName().equalsIgnoreCase("checkIntervalSeconds")) {
/* 232 */               if ((!StringUtils.isBlank(objProperty[i].getValue())) && (StringUtils.isNumeric(objProperty[i].getValue())))
/* 233 */                 interval = Integer.parseInt(objProperty[i].getValue().trim()) * 1000;
/*     */             }
/*     */             else {
/* 236 */               if ((!objProperty[i].getName().equalsIgnoreCase("checkStartSeconds")) || 
/* 237 */                 (StringUtils.isBlank(objProperty[i].getValue())) || (!StringUtils.isNumeric(objProperty[i].getValue()))) continue;
/* 238 */               start = Integer.parseInt(objProperty[i].getValue().trim()) * 1000;
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 244 */         Timer timer = new Timer(true);
/* 245 */         timer.schedule(new CheckThread(BIG_DISTRICT_MAPPING), start, interval);
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 250 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.DefaultClientServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */