/*    */ package com.ai.appframe2.complex.service.impl.xml;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Client
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addConnect(Connect connect)
/*    */   {
/* 21 */     this.list.add(connect);
/*    */   }
/*    */ 
/*    */   public Connect[] getConnects() {
/* 25 */     return (Connect[])(Connect[])this.list.toArray(new Connect[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.xml.Client
 * JD-Core Version:    0.5.4
 */