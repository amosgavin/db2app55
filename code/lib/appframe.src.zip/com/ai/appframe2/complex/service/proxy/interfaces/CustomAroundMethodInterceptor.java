package com.ai.appframe2.complex.service.proxy.interfaces;

import java.util.HashMap;

public abstract interface CustomAroundMethodInterceptor extends AroundMethodInterceptor
{
  public abstract void init(HashMap paramHashMap)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.interfaces.CustomAroundMethodInterceptor
 * JD-Core Version:    0.5.4
 */