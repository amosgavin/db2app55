package com.ai.appframe2.complex.service.impl.wrapper;

public final class Was61EJBBeanInterceptorWrapper extends DefaultEJBBeanInterceptorWrapper
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.wrapper.Was61EJBBeanInterceptorWrapper
 * JD-Core Version:    0.5.4
 */