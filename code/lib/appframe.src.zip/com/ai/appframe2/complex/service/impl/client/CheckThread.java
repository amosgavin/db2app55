/*     */ package com.ai.appframe2.complex.service.impl.client;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.self.service.check.interfaces.ICheckSV;
/*     */ import com.ai.appframe2.complex.service.impl.DefaultClientServiceInvokeImpl;
/*     */ import com.ai.appframe2.complex.service.impl.client.check.DefaultCheckImpl;
/*     */ import com.ai.appframe2.complex.service.impl.client.check.ICheck;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TimerTask;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CheckThread extends TimerTask
/*     */ {
/*  34 */   private static transient Log log = LogFactory.getLog(CheckThread.class);
/*  35 */   private static ICheck CHECK_INSTANCE = null;
/*     */ 
/*  37 */   private List all = new ArrayList();
/*  38 */   private List error = new ArrayList();
/*     */ 
/*     */   public CheckThread(HashMap bigDistrictMapping)
/*     */   {
/*  81 */     HashMap tmp = new HashMap();
/*  82 */     Set set = bigDistrictMapping.keySet();
/*  83 */     for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/*  84 */       String item = (String)iter.next();
/*  85 */       tmp.put(bigDistrictMapping.get(item), item);
/*     */     }
/*     */ 
/*  88 */     Set t = tmp.keySet();
/*  89 */     for (Iterator iter = t.iterator(); iter.hasNext(); ) {
/*  90 */       String item = (String)iter.next();
/*  91 */       this.all.add(new BigDistrictRegionId(item, (String)tmp.get(item)));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  99 */     Thread.currentThread().setName(CHECK_INSTANCE.getCheckThreadName());
/*     */     try
/*     */     {
/* 103 */       for (Iterator iter = this.all.iterator(); iter.hasNext(); ) {
/* 104 */         BigDistrictRegionId item = (BigDistrictRegionId)iter.next();
/*     */ 
/* 106 */         boolean isContinue = true;
/* 107 */         for (Iterator iterError = this.error.iterator(); iterError.hasNext(); ) {
/* 108 */           BigDistrictRegionId itemError = (BigDistrictRegionId)iterError.next();
/* 109 */           if (item.bigdistrict.equalsIgnoreCase(itemError.bigdistrict)) {
/* 110 */             isContinue = false;
/* 111 */             if (log.isDebugEnabled());
/* 112 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.infos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict }));
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 119 */         if (isContinue) {
/*     */           try
/*     */           {
/* 122 */             CenterFactory.setDirectCenterInfo(item.getCenterInfo());
/*     */ 
/* 125 */             int retry = CHECK_INSTANCE.getCheckRetryCount();
/*     */ 
/* 127 */             for (int i = 0; i < retry; ++i) {
/*     */               try {
/* 129 */                 ICheckSV objICheckSV = (ICheckSV)ServiceFactory.getService(ICheckSV.class);
/* 130 */                 objICheckSV.heartbeat();
/*     */ 
/* 132 */                 if (i > 0) {
/* 133 */                   log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.checkinfos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict, String.valueOf(i + 1) }));
/*     */                 }
/*     */               }
/*     */               catch (Throwable ex)
/*     */               {
/* 138 */                 if (i == retry - 1) {
/* 139 */                   throw ex;
/*     */                 }
/*     */ 
/* 142 */                 log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.check_countinfo", new String[] { String.valueOf(i + 1) }), ex);
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 149 */             if (log.isDebugEnabled())
/* 150 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.heart.noraml_infos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict }));
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 154 */             EnvCache.removeBigDistrict(item.bigdistrict);
/* 155 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.heart.exception_infos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict }), ex);
/* 156 */             if (!this.error.contains(item)) {
/* 157 */               this.error.add(item);
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 165 */       BigDistrictRegionId[] objBigDistrictRegionId = (BigDistrictRegionId[])(BigDistrictRegionId[])this.error.toArray(new BigDistrictRegionId[0]);
/* 166 */       for (int i = 0; i < objBigDistrictRegionId.length; ++i) {
/* 167 */         BigDistrictRegionId item = objBigDistrictRegionId[i];
/*     */         try {
/* 169 */           CenterFactory.setDirectCenterInfo(CHECK_INSTANCE.getCenterInfoByRegionId(item.regionId));
/* 170 */           ICheckSV objICheckSV = (ICheckSV)ServiceFactory.getService(ICheckSV.class);
/* 171 */           objICheckSV.heartbeat();
/*     */ 
/* 173 */           EnvCache.resumeBigDistrict(item.bigdistrict);
/* 174 */           this.error.remove(item);
/* 175 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.heart.resume_noraml_infos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict }));
/*     */         }
/*     */         catch (Throwable ex) {
/* 178 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.bigdistrict.heart.resume_exception_infos", new String[] { DefaultClientServiceInvokeImpl.USE_APP_CLUSTER, item.bigdistrict }), ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 184 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client_2_server.thread_exception"), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  42 */       String strBDCheckImplClass = AIConfigManager.getConfigItem("BD_CHECK_IMPL_CLASS");
/*  43 */       if (!StringUtils.isBlank(strBDCheckImplClass)) {
/*     */         try {
/*  45 */           Object custObject = Class.forName(strBDCheckImplClass.trim()).newInstance();
/*  46 */           if (custObject instanceof ICheck) {
/*  47 */             CHECK_INSTANCE = (ICheck)custObject;
/*     */           }
/*     */           else
/*  50 */             CHECK_INSTANCE = null;
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*  54 */           CHECK_INSTANCE = null;
/*  55 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.CheckThread.impl_class_error"), ex);
/*     */         }
/*     */       }
/*     */       else
/*  59 */         CHECK_INSTANCE = new DefaultCheckImpl();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  63 */       CHECK_INSTANCE = null;
/*  64 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.CheckThread.impl_class_error"), ex);
/*     */     }
/*     */     finally {
/*  67 */       if (CHECK_INSTANCE != null) {
/*  68 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.CheckThread.impl_class", new String[] { CHECK_INSTANCE.getClass().toString() }));
/*     */       }
/*     */       else
/*  71 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.client.CheckThread.impl_class_not_config"));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class BigDistrictRegionId
/*     */   {
/*     */     String bigdistrict;
/*     */     String regionId;
/*     */ 
/*     */     public BigDistrictRegionId(String bigdistrict, String regionId)
/*     */     {
/* 201 */       this.bigdistrict = bigdistrict;
/* 202 */       this.regionId = regionId;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 211 */       boolean rtn = false;
/* 212 */       if (obj != null) {
/* 213 */         BigDistrictRegionId tmp = (BigDistrictRegionId)obj;
/* 214 */         if ((tmp.bigdistrict.equals(this.bigdistrict)) && (tmp.regionId.equals(this.regionId))) {
/* 215 */           rtn = true;
/*     */         }
/*     */       }
/* 218 */       return rtn;
/*     */     }
/*     */ 
/*     */     public CenterInfo getCenterInfo()
/*     */     {
/* 226 */       return CheckThread.CHECK_INSTANCE.getCenterInfoByRegionId(this.regionId);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.client.CheckThread
 * JD-Core Version:    0.5.4
 */