package com.ai.appframe2.complex.service.impl.wrapper;

public final class WeblogicEJBBeanInterceptorWrapper extends DefaultEJBBeanInterceptorWrapper
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.wrapper.WeblogicEJBBeanInterceptorWrapper
 * JD-Core Version:    0.5.4
 */