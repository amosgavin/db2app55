/*     */ package com.ai.appframe2.complex.service.proxy.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.common.SessionManager;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.secframe.ICenterUserInfo;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionInfo;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Tx;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TransactionInterceptorImpl
/*     */   implements AroundMethodInterceptor
/*     */ {
/*  37 */   private static transient Log log = LogFactory.getLog(TransactionInterceptorImpl.class);
/*     */   private static final int REQUIRED = 1;
/*     */   private static final int REQUIRES_NEW = 2;
/*     */   private static final int SUPPORTS = 3;
/*     */   private static final int NOT_SUPPORTED = 4;
/*     */   private static final int NEVER = 5;
/*     */   private static final int MANDATORY = 6;
/*  52 */   private boolean isCreate = false;
/*  53 */   private boolean isSuspend = false;
/*  54 */   private int timeoutSecond = -1;
/*  55 */   private long startTime = 0L;
/*     */ 
/*  57 */   private static int DEFAULT_TRANSACTION_ATTRIBUTE = -1;
/*     */ 
/*  59 */   private static HashMap METHOD_TX_MAP = new HashMap();
/*     */ 
/*     */   public void beforeInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 132 */     int methodTransactionAttribute = getMethodTransactionAttribute(obj.getClass(), methodName);
/*     */ 
/* 134 */     if (log.isDebugEnabled()) {
/* 135 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.property.info", new String[] { int2tx(methodTransactionAttribute) }));
/* 136 */       if (CenterFactory.isSetCenterInfo()) {
/* 137 */         log.debug(CenterFactory.getCenterInfo().toString());
/*     */       }
/*     */       else {
/* 140 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.center.notset_center_conf"));
/*     */       }
/*     */     }
/*     */ 
/* 144 */     if (methodTransactionAttribute == 1)
/*     */     {
/* 146 */       if (ServiceManager.getSession().isStartTransaction()) {
/* 147 */         if (log.isDebugEnabled())
/* 148 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.join_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */       }
/*     */       else
/*     */       {
/* 152 */         if (log.isDebugEnabled()) {
/* 153 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.start_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */         }
/* 155 */         ServiceManager.getSession().startTransaction();
/* 156 */         this.isCreate = true;
/*     */       }
/*     */     }
/* 159 */     else if (methodTransactionAttribute == 2)
/*     */     {
/* 161 */       if (ServiceManager.getSession().isStartTransaction()) {
/* 162 */         if (log.isDebugEnabled())
/*     */         {
/* 164 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.suspendnew_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */         }
/* 166 */         ServiceManager.getSession().suspend();
/* 167 */         ServiceManager.getSession().startTransaction();
/* 168 */         this.isCreate = true;
/* 169 */         this.isSuspend = true;
/*     */       }
/*     */       else {
/* 172 */         if (log.isDebugEnabled())
/*     */         {
/* 174 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.noparent_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */         }
/* 176 */         ServiceManager.getSession().startTransaction();
/* 177 */         this.isCreate = true;
/*     */       }
/*     */     }
/* 180 */     else if (methodTransactionAttribute != 3)
/*     */     {
/* 183 */       if (methodTransactionAttribute == 4)
/*     */       {
/* 185 */         if (ServiceManager.getSession().isStartTransaction()) {
/* 186 */           if (log.isDebugEnabled())
/*     */           {
/* 188 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.suspend_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */           }
/* 190 */           ServiceManager.getSession().suspend();
/* 191 */           this.isSuspend = true;
/*     */         }
/*     */       }
/* 194 */       else if (methodTransactionAttribute == 5)
/*     */       {
/* 196 */         if (ServiceManager.getSession().isStartTransaction()) {
/* 197 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.run_nocontext", new String[] { obj.getClass().getName(), methodName }));
/*     */         }
/*     */       }
/* 200 */       else if ((methodTransactionAttribute == 6) && 
/* 202 */         (!ServiceManager.getSession().isStartTransaction())) {
/* 203 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.run_context", new String[] { obj.getClass().getName(), methodName }));
/*     */       }
/*     */     }
/*     */ 
/* 207 */     if ((!this.isCreate) && (log.isDebugEnabled())) {
/* 208 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.current_info", new String[] { ((ITransactionInfo)ServiceManager.getSession()).getCurrentTxInfo() }));
/*     */     }
/*     */ 
/* 213 */     if ((this.isCreate) && (!this.isSuspend)) {
/* 214 */       UserInfoInterface userInfo = SessionManager.__getUserWithOutLog();
/* 215 */       if ((userInfo != null) && (userInfo instanceof ICenterUserInfo)) {
/* 216 */         this.timeoutSecond = ((ICenterUserInfo)userInfo).getTimeoutSecond();
/* 217 */         this.startTime = System.currentTimeMillis();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 230 */     if (this.isCreate) {
/* 231 */       if ((this.timeoutSecond > 0) && (this.startTime > 0L))
/*     */       {
/* 233 */         long endTime = System.currentTimeMillis();
/*     */ 
/* 235 */         long diffTime = endTime - this.startTime;
/* 236 */         if ((diffTime > 0L) && (diffTime > this.timeoutSecond * 1000))
/*     */         {
/* 238 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.timeout", new Object[] { "" + this.timeoutSecond }), new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.timeout_exception")));
/*     */ 
/* 240 */           ServiceManager.getSession().rollbackTransaction();
/*     */         }
/*     */         else
/*     */         {
/* 244 */           ServiceManager.getSession().commitTransaction();
/* 245 */           if (log.isDebugEnabled())
/*     */           {
/* 247 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.commit_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 253 */         ServiceManager.getSession().commitTransaction();
/* 254 */         if (log.isDebugEnabled())
/*     */         {
/* 256 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.commit_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 261 */     if (this.isSuspend) {
/* 262 */       ServiceManager.getSession().resume();
/* 263 */       if (!log.isDebugEnabled())
/*     */         return;
/* 265 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.resume_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void exceptionInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 279 */     if (this.isCreate) {
/* 280 */       ServiceManager.getSession().rollbackTransaction();
/* 281 */       if (log.isDebugEnabled())
/*     */       {
/* 283 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.rollback_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */       }
/*     */     }
/* 286 */     if (this.isSuspend) {
/* 287 */       ServiceManager.getSession().resume();
/* 288 */       if (!log.isDebugEnabled())
/*     */         return;
/* 290 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.resume_infos", new String[] { obj.getClass().getName(), methodName }));
/*     */     }
/*     */   }
/*     */ 
/*     */   private int getMethodTransactionAttribute(Class implClass, String methodName)
/*     */     throws Exception
/*     */   {
/* 303 */     int rtn = -1;
/* 304 */     if (METHOD_TX_MAP.containsKey(new ClassMethod(implClass, methodName))) {
/* 305 */       rtn = ((Integer)METHOD_TX_MAP.get(new ClassMethod(implClass, methodName))).intValue();
/*     */     }
/*     */     else {
/* 308 */       rtn = DEFAULT_TRANSACTION_ATTRIBUTE;
/*     */     }
/* 310 */     return rtn;
/*     */   }
/*     */ 
/*     */   private static String int2tx(int i)
/*     */   {
/* 319 */     String rtn = null;
/* 320 */     if (i == 1) {
/* 321 */       rtn = "Required";
/*     */     }
/* 323 */     else if (i == 2) {
/* 324 */       rtn = "RequiresNew";
/*     */     }
/* 326 */     else if (i == 3) {
/* 327 */       rtn = "Supports";
/*     */     }
/* 329 */     else if (i == 4) {
/* 330 */       rtn = "NotSupported";
/*     */     }
/* 332 */     else if (i == 5) {
/* 333 */       rtn = "Never";
/*     */     }
/* 335 */     else if (i == 6) {
/* 336 */       rtn = "Mandatory";
/*     */     }
/*     */     else
/*     */     {
/* 341 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.unknown_tx_prop") + ":" + i);
/*     */     }
/* 343 */     return rtn;
/*     */   }
/*     */ 
/*     */   private static int tx2int(String tx)
/*     */   {
/* 352 */     int rtn = -1;
/* 353 */     if (tx.equalsIgnoreCase("Required")) {
/* 354 */       rtn = 1;
/*     */     }
/* 356 */     else if (tx.equalsIgnoreCase("RequiresNew")) {
/* 357 */       rtn = 2;
/*     */     }
/* 359 */     else if (tx.equalsIgnoreCase("Supports")) {
/* 360 */       rtn = 3;
/*     */     }
/* 362 */     else if (tx.equalsIgnoreCase("NotSupported")) {
/* 363 */       rtn = 4;
/*     */     }
/* 365 */     else if (tx.equalsIgnoreCase("Never")) {
/* 366 */       rtn = 5;
/*     */     }
/* 368 */     else if (tx.equalsIgnoreCase("Mandatory")) {
/* 369 */       rtn = 6;
/*     */     }
/*     */     else
/*     */     {
/* 374 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.unknown_tx_prop") + ":" + tx);
/*     */     }
/* 376 */     return rtn;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  63 */       String defaultTxAttr = XMLHelper.getInstance().getDefaults().getTransaction().getType();
/*  64 */       if (StringUtils.isBlank(defaultTxAttr))
/*     */       {
/*  67 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.blank_default_prop"));
/*     */       }
/*     */ 
/*  70 */       DEFAULT_TRANSACTION_ATTRIBUTE = tx2int(defaultTxAttr);
/*     */ 
/*  72 */       if (DEFAULT_TRANSACTION_ATTRIBUTE <= 0)
/*     */       {
/*  75 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.fail_set_prop"));
/*     */       }
/*     */ 
/*  78 */       Service[] services = XMLHelper.getInstance().getServices();
/*  79 */       for (int i = 0; i < services.length; ++i) {
/*  80 */         String implClass = MiscHelper.getImplClassByPropertyAndServiceId(services[i].getId(), services[i].getPropertys());
/*  81 */         Tx tx = services[i].getTx();
/*  82 */         if (tx != null) {
/*  83 */           java.lang.reflect.Method[] classMethods = Class.forName(implClass).getMethods();
/*  84 */           com.ai.appframe2.complex.xml.cfg.services.Method[] methods = tx.getMethods();
/*  85 */           for (int j = 0; j < methods.length; ++j) {
/*  86 */             String methodName = methods[j].getName().trim();
/*  87 */             boolean isFound = false;
/*  88 */             for (int k = 0; k < classMethods.length; ++k) {
/*  89 */               if (classMethods[k].getName().equals(methodName)) {
/*  90 */                 if (!isFound) {
/*  91 */                   METHOD_TX_MAP.put(new ClassMethod(Class.forName(implClass), classMethods[k].getName()), new Integer(tx2int(methods[j].getTxattr().trim())));
/*  92 */                   isFound = true;
/*     */                 }
/*     */                 else
/*     */                 {
/*  97 */                   throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.same_method_name", new String[] { services[i].getId(), methodName }));
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 105 */       if (log.isDebugEnabled()) {
/* 106 */         StringBuilder sb = new StringBuilder();
/* 107 */         Set keys = METHOD_TX_MAP.keySet();
/* 108 */         for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 109 */           Object item = iter.next();
/* 110 */           sb.append(item.toString() + ",transaction property:" + int2tx(((Integer)(Integer)METHOD_TX_MAP.get(item)).intValue()) + "  ");
/*     */         }
/* 112 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.trans.method.info", new String[] { sb.toString() }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 117 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ClassMethod
/*     */   {
/* 380 */     Class implClass = null;
/* 381 */     String methodName = null;
/*     */ 
/*     */     public ClassMethod(Class clazz, String str) {
/* 384 */       this.implClass = clazz;
/* 385 */       this.methodName = str;
/*     */     }
/*     */     public String toString() {
/* 388 */       return "Class name:" + this.implClass.getName() + ",method name:" + this.methodName;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj) {
/* 392 */       boolean rtn = false;
/* 393 */       if (obj == null) {
/* 394 */         return false;
/*     */       }
/*     */ 
/* 397 */       if (obj instanceof ClassMethod) {
/* 398 */         ClassMethod objMethodTX = (ClassMethod)obj;
/* 399 */         if ((objMethodTX.implClass.equals(this.implClass)) && (objMethodTX.methodName.equals(this.methodName)))
/*     */         {
/* 401 */           rtn = true;
/*     */         }
/*     */       }
/*     */ 
/* 405 */       return rtn;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 411 */       return this.implClass.hashCode() + this.methodName.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.impl.TransactionInterceptorImpl
 * JD-Core Version:    0.5.4
 */