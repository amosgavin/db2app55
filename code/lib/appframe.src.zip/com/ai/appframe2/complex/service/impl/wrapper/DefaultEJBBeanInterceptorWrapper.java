/*    */ package com.ai.appframe2.complex.service.impl.wrapper;
/*    */ 
/*    */ import com.ai.appframe2.complex.service.interfaces.ISelfManagedService;
/*    */ import com.ai.appframe2.complex.service.interfaces.ISelfManagedServiceWithRequiredTransaction;
/*    */ import com.ai.appframe2.complex.service.proxy.ProxyInvocationHandler;
/*    */ import com.ai.appframe2.complex.service.proxy.impl.MethodMonitorInterceptorImpl;
/*    */ import com.ai.appframe2.complex.service.proxy.impl.TransactionDataSourceInterceptorImpl;
/*    */ import com.ai.appframe2.complex.service.proxy.impl.TransactionInterceptorImpl;
/*    */ import com.ai.appframe2.complex.util.ProxyUtil;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class DefaultEJBBeanInterceptorWrapper
/*    */ {
/* 25 */   private static transient Log log = LogFactory.getLog(DefaultEJBBeanInterceptorWrapper.class);
/*    */ 
/*    */   public static Object wrapper(Object obj, Class interfaceClass)
/*    */     throws Exception
/*    */   {
/* 38 */     Object rtn = null;
/*    */     try
/*    */     {
/* 41 */       if ((!obj instanceof ISelfManagedService) && (!obj instanceof ISelfManagedServiceWithRequiredTransaction))
/*    */       {
/* 45 */         ProxyInvocationHandler handler = new ProxyInvocationHandler(obj, new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class, TransactionDataSourceInterceptorImpl.class });
/*    */ 
/* 51 */         rtn = ProxyUtil.getProxyObject(interfaceClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*    */       }
/* 55 */       else if (obj instanceof ISelfManagedService) {
/* 56 */         if (log.isDebugEnabled()) {
/* 57 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.wrapper.service.implinfo", new String[] { obj.getClass().getName(), ",implements ISelfManagedService" }));
/*    */         }
/*    */ 
/* 60 */         ProxyInvocationHandler handler = new ProxyInvocationHandler(obj, new Class[] { MethodMonitorInterceptorImpl.class });
/*    */ 
/* 64 */         rtn = ProxyUtil.getProxyObject(interfaceClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*    */       }
/* 67 */       else if (obj instanceof ISelfManagedServiceWithRequiredTransaction) {
/* 68 */         if (log.isDebugEnabled()) {
/* 69 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.wrapper.service.implinfo", new String[] { obj.getClass().getName(), ",implements ISelfManagedServiceWithRequiredTransaction" }));
/*    */         }
/*    */ 
/* 72 */         ProxyInvocationHandler handler = new ProxyInvocationHandler(obj, new Class[] { MethodMonitorInterceptorImpl.class, TransactionInterceptorImpl.class });
/*    */ 
/* 76 */         rtn = ProxyUtil.getProxyObject(interfaceClass.getClassLoader(), new Class[] { interfaceClass }, handler);
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 82 */       log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.impl.wrapper.ejbservice.exception"), ex);
/* 83 */       throw ex;
/*    */     }
/*    */ 
/* 86 */     return rtn;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.wrapper.DefaultEJBBeanInterceptorWrapper
 * JD-Core Version:    0.5.4
 */