package com.ai.appframe2.complex.service.impl;

public class BesClientServiceInvokeImpl extends DefaultClientServiceInvokeImpl
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.BesClientServiceInvokeImpl
 * JD-Core Version:    0.5.4
 */