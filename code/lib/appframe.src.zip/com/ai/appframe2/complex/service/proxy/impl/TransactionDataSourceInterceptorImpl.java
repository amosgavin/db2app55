/*     */ package com.ai.appframe2.complex.service.proxy.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.service.proxy.interfaces.AroundMethodInterceptor;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.IMutilTransactionDatasource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionDatasource;
/*     */ import com.ai.appframe2.complex.util.StringLengthDescComparator;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Mapping;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TransactionDataSourceInterceptorImpl
/*     */   implements AroundMethodInterceptor
/*     */ {
/*  39 */   private static transient Log log = LogFactory.getLog(TransactionDataSourceInterceptorImpl.class);
/*     */ 
/*  42 */   private static final ThreadLocal TMP_MAPPING = new ThreadLocal();
/*     */   private static final String NULL = "NULL";
/*  47 */   private static Map CLAZZ_DATASOURCE_CACHE = new HashMap();
/*     */ 
/*  49 */   private static final HashMap SV_SCOPE = new HashMap();
/*  50 */   private static String[] KEYS = null;
/*     */ 
/*  52 */   private String previousDataSourceWithMutilLocalTransaction = null;
/*     */ 
/*     */   public void beforeInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/*  91 */     if (!ServiceManager.getSession().isStartTransaction())
/*     */     {
/*  94 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.ds_not_allowed"));
/*     */     }
/*     */ 
/*  97 */     if (ServiceManager.getSession() instanceof ITransactionDatasource) {
/*  98 */       ITransactionDatasource objITxDataSource = (ITransactionDatasource)ServiceManager.getSession();
/*  99 */       if (!objITxDataSource.isSetTxDataSource())
/*     */       {
/* 102 */         String ds = getTxDsByInfo(obj.getClass(), obj.getClass().getName(), methodName);
/* 103 */         if (!StringUtils.isBlank(ds)) {
/* 104 */           objITxDataSource.setTxDataSource(ds);
/* 105 */           if (log.isDebugEnabled())
/* 106 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.setds.info", new String[] { obj.getClass().getName(), methodName, ds }));
/*     */         }
/*     */         else
/*     */         {
/* 110 */           objITxDataSource.setTxDataSource(null);
/*     */ 
/* 113 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.no_sv_ds", new String[] { obj.getClass().getName() }));
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 118 */       if (!ServiceManager.getSession() instanceof IMutilTransactionDatasource)
/*     */         return;
/* 120 */       IMutilTransactionDatasource objIMutilTransactionDatasource = (IMutilTransactionDatasource)ServiceManager.getSession();
/*     */ 
/* 125 */       this.previousDataSourceWithMutilLocalTransaction = objIMutilTransactionDatasource.getCurDataSource();
/* 126 */       if ((log.isDebugEnabled()) && 
/* 127 */         (!StringUtils.isBlank(this.previousDataSourceWithMutilLocalTransaction))) {
/* 128 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previousds.info", new String[] { this.previousDataSourceWithMutilLocalTransaction }));
/*     */       }
/*     */ 
/* 133 */       String ds = getTxDsByInfo(obj.getClass(), obj.getClass().getName(), methodName);
/*     */ 
/* 135 */       if (!StringUtils.isBlank(ds)) {
/* 136 */         objIMutilTransactionDatasource.setCurDataSource(ds);
/* 137 */         if (log.isDebugEnabled()) {
/* 138 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.setds.info", new String[] { obj.getClass().getName(), methodName, ds }));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 143 */         objIMutilTransactionDatasource.setCurDataSource(null);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 159 */     if (!ServiceManager.getSession() instanceof IMutilTransactionDatasource)
/*     */       return;
/* 161 */     IMutilTransactionDatasource objIMutilTransactionDatasource = (IMutilTransactionDatasource)ServiceManager.getSession();
/* 162 */     objIMutilTransactionDatasource.setCurDataSource(this.previousDataSourceWithMutilLocalTransaction);
/* 163 */     if ((!log.isDebugEnabled()) || 
/* 164 */       (StringUtils.isBlank(this.previousDataSourceWithMutilLocalTransaction))) return;
/* 165 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource_resume", new String[] { this.previousDataSourceWithMutilLocalTransaction }));
/*     */   }
/*     */ 
/*     */   public void exceptionInterceptor(Object obj, String methodName, Object[] objectArray)
/*     */     throws Exception
/*     */   {
/* 180 */     if (!ServiceManager.getSession() instanceof IMutilTransactionDatasource)
/*     */       return;
/* 182 */     IMutilTransactionDatasource objIMutilTransactionDatasource = (IMutilTransactionDatasource)ServiceManager.getSession();
/* 183 */     objIMutilTransactionDatasource.setCurDataSource(this.previousDataSourceWithMutilLocalTransaction);
/* 184 */     if ((!log.isDebugEnabled()) || 
/* 185 */       (StringUtils.isBlank(this.previousDataSourceWithMutilLocalTransaction))) return;
/* 186 */     log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.service.proxy.impl.previous_datasource_resume", new String[] { this.previousDataSourceWithMutilLocalTransaction }));
/*     */   }
/*     */ 
/*     */   private String getTxDsByInfo(Class clazz, String className, String methodName)
/*     */   {
/* 201 */     String ds = getDataSourceByClass(clazz);
/* 202 */     if ((ds != null) && 
/* 203 */       (StringUtils.contains(ds, "{CENTER}"))) {
/* 204 */       ds = StringUtils.replace(ds, "{CENTER}", CenterFactory.getCenterInfo().getCenter());
/*     */     }
/*     */ 
/* 207 */     return ds;
/*     */   }
/*     */ 
/*     */   private static String getDataSourceByClass(Class clazz)
/*     */   {
/* 216 */     String dataSource = (String)CLAZZ_DATASOURCE_CACHE.get(clazz);
/* 217 */     if (dataSource == null) {
/* 218 */       synchronized (CLAZZ_DATASOURCE_CACHE) {
/* 219 */         if (!CLAZZ_DATASOURCE_CACHE.containsKey(clazz)) {
/* 220 */           for (int i = 0; i < KEYS.length; ++i) {
/* 221 */             if (clazz.getPackage().getName().indexOf(KEYS[i]) == -1)
/*     */               continue;
/* 223 */             dataSource = (String)SV_SCOPE.get(KEYS[i]);
/* 224 */             break;
/*     */           }
/*     */ 
/* 228 */           if (dataSource != null) {
/* 229 */             CLAZZ_DATASOURCE_CACHE.put(clazz, dataSource);
/*     */           }
/*     */           else {
/* 232 */             CLAZZ_DATASOURCE_CACHE.put(clazz, "NULL");
/*     */           }
/*     */         }
/* 235 */         dataSource = (String)CLAZZ_DATASOURCE_CACHE.get(clazz);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 240 */     if ((dataSource == null) || (dataSource.equals("NULL"))) {
/* 241 */       dataSource = getTmpMappingDataSource(clazz);
/*     */     }
/*     */ 
/* 244 */     return dataSource;
/*     */   }
/*     */ 
/*     */   private static String getTmpMappingDataSource(Class clazz)
/*     */   {
/* 254 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 255 */     if (stack == null) {
/* 256 */       return null;
/*     */     }
/*     */ 
/* 259 */     Map tmp = (Map)stack.peek();
/* 260 */     if (tmp == null) {
/* 261 */       return null;
/*     */     }
/*     */ 
/* 264 */     String dataSource = null;
/* 265 */     Set set = tmp.keySet();
/* 266 */     for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/* 267 */       String item = (String)iter.next();
/* 268 */       if (clazz.getPackage().getName().indexOf(item) != -1)
/*     */       {
/* 270 */         dataSource = (String)tmp.get(item);
/* 271 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 275 */     if (log.isDebugEnabled()) {
/* 276 */       log.debug("tmp mapping datasource clazz=" + clazz + ",datasource:" + dataSource);
/*     */     }
/*     */ 
/* 279 */     return dataSource;
/*     */   }
/*     */ 
/*     */   public static void pushTmpMapping(Map map)
/*     */     throws Exception
/*     */   {
/* 288 */     Map treeMap = new TreeMap(new StringLengthDescComparator());
/* 289 */     treeMap.putAll(map);
/*     */ 
/* 291 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 292 */     if (stack == null) {
/* 293 */       stack = new Stack();
/* 294 */       TMP_MAPPING.set(stack);
/*     */     }
/*     */ 
/* 297 */     stack.push(treeMap);
/*     */ 
/* 299 */     if (log.isDebugEnabled())
/* 300 */       log.debug("push tmp mapping datasource:" + map);
/*     */   }
/*     */ 
/*     */   public static void popTmpMapping()
/*     */     throws Exception
/*     */   {
/* 309 */     Stack stack = (Stack)TMP_MAPPING.get();
/* 310 */     if (stack != null) {
/* 311 */       Map map = (Map)stack.pop();
/* 312 */       if (log.isDebugEnabled())
/* 313 */         log.debug("pop tmp mapping datasource:" + map);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  56 */       Property[] property = XMLHelper.getInstance().getDefaults().getTransaction().getMapping().getProperties();
/*     */ 
/*  58 */       List list = new ArrayList();
/*  59 */       for (int i = 0; i < property.length; ++i) {
/*  60 */         SV_SCOPE.put(property[i].getName().trim(), property[i].getValue().trim());
/*  61 */         list.add(property[i].getName().trim());
/*     */       }
/*     */ 
/*  65 */       KEYS = (String[])(String[])list.toArray(new String[0]);
/*  66 */       Arrays.sort(KEYS, new StringLengthDescComparator());
/*     */ 
/*  68 */       if (log.isDebugEnabled()) {
/*  69 */         log.debug("Data after sorting:");
/*  70 */         for (int i = 0; i < KEYS.length; ++i)
/*  71 */           log.debug(KEYS[i]);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  76 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.initial_fail"), ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.proxy.impl.TransactionDataSourceInterceptorImpl
 * JD-Core Version:    0.5.4
 */