/*    */ package com.ai.appframe2.complex.service.impl.xml;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class App
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addCluster(Cluster cluster)
/*    */   {
/* 21 */     this.list.add(cluster);
/*    */   }
/*    */ 
/*    */   public Cluster[] getClusters() {
/* 25 */     return (Cluster[])(Cluster[])this.list.toArray(new Cluster[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.service.impl.xml.App
 * JD-Core Version:    0.5.4
 */