/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import com.ai.appframe2.complex.service.proxy.impl.DAODataSourceInterceptorImpl;
/*    */ import com.ai.appframe2.complex.service.proxy.impl.TransactionDataSourceInterceptorImpl;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class CustomDataSourceUtil
/*    */ {
/*    */   public static void pushTmpMapping(Map map)
/*    */     throws Exception
/*    */   {
/* 30 */     TransactionDataSourceInterceptorImpl.pushTmpMapping(map);
/* 31 */     DAODataSourceInterceptorImpl.pushTmpMapping(map);
/*    */   }
/*    */ 
/*    */   public static void popTmpMapping()
/*    */     throws Exception
/*    */   {
/* 39 */     DAODataSourceInterceptorImpl.popTmpMapping();
/* 40 */     TransactionDataSourceInterceptorImpl.popTmpMapping();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.CustomDataSourceUtil
 * JD-Core Version:    0.5.4
 */