/*    */ package com.ai.appframe2.complex.util.collection.asyn.test;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.collection.asyn.AsynContainer;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class ThreadTest extends Thread
/*    */ {
/*    */   private AsynContainer objAsynContainer;
/*    */ 
/*    */   public ThreadTest(AsynContainer objAsynContainer)
/*    */   {
/*  8 */     this.objAsynContainer = objAsynContainer;
/*    */   }
/*    */ 
/*    */   public void run() {
/* 12 */     for (int i = 0; i < 10000; ++i) {
/* 13 */       this.objAsynContainer.insert(Thread.currentThread().getName() + ":" + i + "jkassssssskjs");
/*    */     }
/* 15 */     System.out.println(Thread.currentThread().getName() + "over");
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 19 */     AsynContainer objAsynContainer = new AsynContainer(1L, 1000L, TestFlushWorkTask.class);
/* 20 */     for (int i = 0; i < 100; ++i) {
/* 21 */       ThreadTest a = new ThreadTest(objAsynContainer);
/* 22 */       a.start();
/*    */     }
/*    */ 
/* 25 */     for (int i = 0; i < 10000000L; ++i) {
/* 26 */       System.out.println("主线程:" + objAsynContainer.getTotalCount());
/* 27 */       Thread.currentThread(); Thread.sleep(1000L);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.test.ThreadTest
 * JD-Core Version:    0.5.4
 */