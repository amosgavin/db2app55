/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.net.SocketException;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class Test
/*    */ {
/*    */   public static void main2(String[] args)
/*    */     throws Exception
/*    */   {
/* 13 */     Class[] e = { IOException.class, SocketException.class };
/*    */ 
/* 15 */     System.out.println(StringUtils.join(e, ","));
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 20 */     int i = 100;
/* 21 */     switch (i)
/*    */     {
/*    */     case 100:
/* 23 */       System.out.println(i);
/*    */     case 200:
/* 25 */       System.out.println(i);
/*    */     case 300:
/* 27 */       System.out.println(i);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.Test
 * JD-Core Version:    0.5.4
 */