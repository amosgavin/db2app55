/*     */ package com.ai.appframe2.complex.util;
/*     */ 
/*     */ import com.ai.appframe2.complex.service.interfaces.IAppServerServiceInvoke;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class RuntimeServerUtil
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(RuntimeServerUtil.class);
/*     */ 
/*  26 */   private static String SERVER_IP_ADDRESS = null;
/*  27 */   private static String SERVER_NAME = null;
/*  28 */   private static Boolean IS_RUN_APPSERVER = null;
/*     */ 
/*     */   public static String getServerIP()
/*     */   {
/*  46 */     return SERVER_IP_ADDRESS;
/*     */   }
/*     */ 
/*     */   public static String getServerName()
/*     */   {
/*  54 */     if (SERVER_NAME == null)
/*     */     {
/*  61 */       SERVER_NAME = System.getProperty("appframe.client.app.name");
/*  62 */       if (StringUtils.isBlank(SERVER_NAME)) {
/*  63 */         SERVER_NAME = System.getProperty("appframe.server.name");
/*     */       }
/*     */ 
/*  67 */       if ((!StringUtils.isBlank(SERVER_NAME)) && (SERVER_NAME.trim().equalsIgnoreCase("{WEBLOGIC}"))) {
/*  68 */         String name = System.getProperty("weblogic.Name");
/*  69 */         if (!StringUtils.isBlank(name)) {
/*  70 */           SERVER_NAME = name.trim();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  75 */       if (StringUtils.isBlank(SERVER_NAME)) {
/*     */         try {
/*  77 */           Class clazz = Class.forName("com.ibm.websphere.runtime.ServerName");
/*  78 */           Method getFullName = clazz.getMethod("getDisplayName", new Class[0]);
/*  79 */           SERVER_NAME = (String)getFullName.invoke(null, new Object[0]);
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*  83 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.RuntimeServerUtil.getServerName_error") + ex.getMessage());
/*  84 */           SERVER_NAME = "";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  89 */       if (StringUtils.isBlank(SERVER_NAME)) {
/*  90 */         SERVER_NAME = "DEFAULT_APPFRAME_SERVER_NAME" + System.currentTimeMillis();
/*     */       }
/*     */     }
/*  93 */     return SERVER_NAME;
/*     */   }
/*     */ 
/*     */   public static void printExceptionFrom(String serverName)
/*     */   {
/* 101 */     if (StringUtils.isBlank(serverName))
/*     */       return;
/* 103 */     log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.RuntimeServerUtil.printExceptionFrom_error", new String[] { serverName }));
/*     */   }
/*     */ 
/*     */   public static void printException(Throwable ex)
/*     */   {
/* 113 */     log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.RuntimeServerUtil.printException_error"), ex);
/*     */   }
/*     */ 
/*     */   public static boolean isRunOnAppServer()
/*     */   {
/* 122 */     if (IS_RUN_APPSERVER == null) {
/* 123 */       Object obj = ServiceFactory.getServiceInvoke();
/* 124 */       if (obj instanceof IAppServerServiceInvoke) {
/* 125 */         IS_RUN_APPSERVER = Boolean.TRUE;
/*     */       }
/*     */       else {
/* 128 */         IS_RUN_APPSERVER = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */ 
/* 132 */     return IS_RUN_APPSERVER.booleanValue();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  32 */       SERVER_IP_ADDRESS = InetAddress.getLocalHost().getHostAddress();
/*     */     }
/*     */     catch (UnknownHostException ex)
/*     */     {
/*  36 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.RuntimeServerUtil.error") + ex.getMessage());
/*  37 */       SERVER_IP_ADDRESS = "127.0.0.1";
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.RuntimeServerUtil
 * JD-Core Version:    0.5.4
 */