/*     */ package com.ai.appframe2.complex.util.tt;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class SUtil
/*     */ {
/*     */   public static String[] csvToStringArray(String csv)
/*     */   {
/*  26 */     if (csv == null) {
/*  27 */       return null;
/*     */     }
/*  29 */     StringTokenizer tokenizer = new StringTokenizer(csv, ",");
/*  30 */     String[] array = new String[tokenizer.countTokens()];
/*  31 */     int index = 0;
/*  32 */     while (tokenizer.hasMoreTokens()) {
/*  33 */       array[(index++)] = tokenizer.nextToken().trim();
/*     */     }
/*  35 */     return array;
/*     */   }
/*     */ 
/*     */   public static String stringArrayToCSV(String[] array)
/*     */   {
/*  42 */     StringBuilder buff = new StringBuilder();
/*  43 */     for (int i = 0; (array != null) && (i < array.length); ++i) {
/*  44 */       buff.append(array[i]);
/*  45 */       if (i < array.length) {
/*  46 */         buff.append(",");
/*     */       }
/*     */     }
/*  49 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   public static String[] listToStringArray(List list) {
/*  53 */     String[] output = new String[list.size()];
/*  54 */     int i = 0;
/*  55 */     for (Iterator it = list.iterator(); it.hasNext(); ++i) {
/*  56 */       output[i] = it.next().toString();
/*     */     }
/*  58 */     return output;
/*     */   }
/*     */ 
/*     */   public static List csvToList(String csv) {
/*  62 */     if (csv == null) {
/*  63 */       return null;
/*     */     }
/*  65 */     StringTokenizer tokenizer = new StringTokenizer(csv, ",");
/*  66 */     List list = new ArrayList(tokenizer.countTokens());
/*  67 */     while (tokenizer.hasMoreTokens()) {
/*  68 */       list.add(tokenizer.nextToken().trim());
/*     */     }
/*  70 */     return list;
/*     */   }
/*     */ 
/*     */   public static String toString(URL[] urls) {
/*  74 */     StringBuilder buff = new StringBuilder();
/*  75 */     for (int i = 0; i < urls.length; ++i) {
/*  76 */       buff.append(urls[i].toString());
/*  77 */       buff.append(";");
/*     */     }
/*  79 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   public static String padRight(String str, int totalLength) {
/*  83 */     int strLen = str.length();
/*  84 */     StringBuilder buff = new StringBuilder(str);
/*  85 */     for (int i = 0; i < totalLength - strLen; ++i) {
/*  86 */       buff.append(' ');
/*     */     }
/*  88 */     return buff.toString();
/*     */   }
/*     */ 
/*     */   public static String getCharSeries(char ch, int length) {
/*  92 */     char[] series = new char[length];
/*  93 */     Arrays.fill(series, ch);
/*  94 */     return new String(series);
/*     */   }
/*     */ 
/*     */   public static String htmlEscape(String str) {
/*  98 */     StringBuilder buff = new StringBuilder(str.length());
/*  99 */     for (int i = 0; i < str.length(); ++i) {
/* 100 */       char ch = str.charAt(i);
/* 101 */       if (ch == '"')
/* 102 */         buff.append("&quot;");
/* 103 */       else if (ch == '<')
/* 104 */         buff.append("&lt;");
/* 105 */       else if (ch == '>')
/* 106 */         buff.append("&gt;");
/*     */       else {
/* 108 */         buff.append(ch);
/*     */       }
/*     */     }
/* 111 */     return buff.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.tt.SUtil
 * JD-Core Version:    0.5.4
 */