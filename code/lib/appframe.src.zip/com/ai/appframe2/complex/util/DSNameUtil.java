/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterFactory;
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public final class DSNameUtil
/*    */ {
/*    */   public static String getDataSourceNameByPrefixName(String name, String center)
/*    */   {
/* 26 */     String rtn = null;
/* 27 */     if (StringUtils.isBlank(center)) {
/* 28 */       rtn = name;
/*    */     }
/*    */     else {
/* 31 */       rtn = name + center;
/*    */     }
/* 33 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static String getDataSourceNameByPrefixNameInImplicit(String name)
/*    */   {
/* 42 */     String rtn = null;
/* 43 */     if (CenterFactory.isSetCenterInfo()) {
/* 44 */       rtn = name + CenterFactory.getCenterInfo().getCenter();
/*    */     }
/*    */     else {
/* 47 */       rtn = name;
/*    */     }
/* 49 */     return rtn;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.DSNameUtil
 * JD-Core Version:    0.5.4
 */