/*    */ package com.ai.appframe2.complex.util.e;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public final class K
/*    */ {
/* 15 */   private static byte[] key = { 97, 105, 95, 110, 106, 95, 114, 100 };
/*    */ 
/*    */   private K()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public static String j(String plain)
/*    */     throws Exception
/*    */   {
/* 33 */     RC2 rc2 = new RC2();
/* 34 */     return rc2.encrypt_rc2_array_base64(plain.getBytes(), key);
/*    */   }
/*    */ 
/*    */   public static String k(String cipher)
/*    */     throws Exception
/*    */   {
/* 44 */     RC2 rc2 = new RC2();
/* 45 */     return rc2.decrypt_rc2_array_base64(cipher.getBytes(), key);
/*    */   }
/*    */ 
/*    */   public static String k_s(String cipher)
/*    */     throws Exception
/*    */   {
/* 55 */     String rtn = null;
/* 56 */     if ((cipher != null) && (cipher.lastIndexOf("{RC2}") != -1)) {
/* 57 */       rtn = k(cipher.substring(5));
/*    */     }
/*    */     else {
/* 60 */       rtn = cipher;
/*    */     }
/* 62 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static void main2(String[] args) throws Exception
/*    */   {
/* 67 */     String a = k_s("{RC2}RcAeFXsjJHfGNA==");
/* 68 */     System.out.println(a);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 73 */     String a = k_s("{RC2}XP&V,");
/* 74 */     System.out.println(a);
/* 75 */     String b = k(a);
/* 76 */     System.out.println(b);
/*    */ 
/* 78 */     System.out.println(j("base"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.e.K
 * JD-Core Version:    0.5.4
 */