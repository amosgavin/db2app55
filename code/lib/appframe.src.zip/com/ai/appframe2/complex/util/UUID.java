/*     */ package com.ai.appframe2.complex.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ 
/*     */ public class UUID
/*     */ {
/*  16 */   private static final UUID INSTANCE = new UUID();
/*     */   private static final String SEP = "";
/*  18 */   private static String formatIp = null;
/*  19 */   private static String formatJvm = null;
/*  20 */   private static String formatHiTime = null;
/*  21 */   private static String formatLoTime = null;
/*     */   private static final int IP;
/*  23 */   private static long counter = 0L;
/*  24 */   private static final int JVM = (int)(System.currentTimeMillis() >>> 8);
/*     */ 
/*     */   private static int toInt(byte[] bytes)
/*     */   {
/*  45 */     int result = 0;
/*  46 */     for (int i = 0; i < 4; ++i) {
/*  47 */       result = (result << 8) - -128 + bytes[i];
/*     */     }
/*  49 */     return result;
/*     */   }
/*     */ 
/*     */   private static int getJVM()
/*     */   {
/*  54 */     return JVM;
/*     */   }
/*     */ 
/*     */   private static int getIP()
/*     */   {
/*  59 */     return IP;
/*     */   }
/*     */ 
/*     */   private static short getHiTime() {
/*  63 */     return (short)(int)(System.currentTimeMillis() >>> 32);
/*     */   }
/*     */ 
/*     */   private static int getLoTime() {
/*  67 */     return (int)System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   private static String format(int intval) {
/*  71 */     String formatted = Integer.toHexString(intval);
/*  72 */     StringBuilder buf = new StringBuilder("00000000");
/*  73 */     buf.replace(8 - formatted.length(), 8, formatted);
/*  74 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private static String format(short shortval) {
/*  78 */     String formatted = Integer.toHexString(shortval);
/*  79 */     StringBuilder buf = new StringBuilder("0000");
/*  80 */     buf.replace(4 - formatted.length(), 4, formatted);
/*  81 */     return buf.toString();
/*     */   }
/*     */ 
/*     */   private synchronized long getCount() {
/*  85 */     if (counter < 0L) counter = 0L;
/*  86 */     return counter++;
/*     */   }
/*     */ 
/*     */   private String getUUID() {
/*  90 */     return 36 + formatIp + "" + formatJvm + "" + formatHiTime + "" + formatLoTime + "" + getCount();
/*     */   }
/*     */ 
/*     */   public static String getID()
/*     */   {
/* 100 */     return INSTANCE.getUUID();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/* 105 */     long start = System.currentTimeMillis();
/*     */ 
/* 107 */     for (int i = 0; i < 100000; ++i) {
/* 108 */       System.out.println(getID());
/*     */     }
/* 110 */     System.out.println("Time cost:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     int ipadd;
/*     */     try
/*     */     {
/*  28 */       ipadd = toInt(InetAddress.getLocalHost().getAddress());
/*     */     }
/*     */     catch (Exception e) {
/*  31 */       ipadd = 0;
/*     */     }
/*  33 */     IP = ipadd;
/*  34 */     formatIp = format(getIP());
/*  35 */     formatJvm = format(getJVM());
/*  36 */     formatHiTime = format(getHiTime());
/*  37 */     formatLoTime = format(getLoTime());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.UUID
 * JD-Core Version:    0.5.4
 */