/*    */ package com.ai.appframe2.complex.util.tt;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Test
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/*  8 */     TextTable a = new TextTable();
/*  9 */     a.setHeader(new String[] { "开始事务数量", "提交事务数量", "回滚事务数量", "挂起事务数量", "恢复事务数量" });
/* 10 */     a.addRow(new String[] { null, "a", "c", "22", "aa" });
/* 11 */     System.out.println(a.draw());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.tt.Test
 * JD-Core Version:    0.5.4
 */