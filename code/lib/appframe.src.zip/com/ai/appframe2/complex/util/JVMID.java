/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public final class JVMID
/*    */ {
/* 16 */   private static String jvm = null;
/*    */ 
/*    */   public static String getLocalJVMID()
/*    */   {
/* 25 */     return jvm;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 29 */     for (int i = 0; i < 100; ++i)
/* 30 */       System.out.println(getLocalJVMID());
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 18 */     jvm = "JVM_" + UUID.getID();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.JVMID
 * JD-Core Version:    0.5.4
 */