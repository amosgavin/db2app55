/*     */ package com.ai.appframe2.complex.util.collection.asyn;
/*     */ 
/*     */ import EDU.oswego.cs.dl.util.concurrent.BoundedBuffer;
/*     */ import EDU.oswego.cs.dl.util.concurrent.PooledExecutor;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.Timer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class AsynContainer
/*     */ {
/*  27 */   private static transient Log log = LogFactory.getLog(AsynContainer.class);
/*     */ 
/*  30 */   private static final Timer TIMER = new Timer(true);
/*     */ 
/*  32 */   private PooledExecutor objPooledExecutor = null;
/*  33 */   private HashMap data = new HashMap();
/*     */ 
/*  35 */   private long limitLength = 0L;
/*  36 */   private Class workTaskClass = null;
/*     */ 
/*  38 */   private long count = 0L;
/*     */ 
/*     */   public AsynContainer(long intervalSeconds, long limitLength, Class workTaskClass)
/*     */   {
/*  47 */     init(intervalSeconds, limitLength, workTaskClass, 1000, 300000L, 1, 5, 1);
/*     */   }
/*     */ 
/*     */   public AsynContainer(long intervalSeconds, long limitLength, Class workTaskClass, int boundedBufferSize, long keepAliveTime, int minThread, int maxThread, int createThread)
/*     */   {
/*  63 */     init(intervalSeconds, limitLength, workTaskClass, boundedBufferSize, keepAliveTime, minThread, maxThread, createThread);
/*     */   }
/*     */ 
/*     */   private void init(long intervalSeconds, long limitLength, Class workTaskClass, int boundedBufferSize, long keepAliveTime, int minThread, int maxThread, int createThread)
/*     */   {
/*  79 */     this.limitLength = limitLength;
/*  80 */     this.workTaskClass = workTaskClass;
/*     */ 
/*  82 */     TIMER.schedule(new FlushTimerTask(this), intervalSeconds * 1000L, intervalSeconds * 1000L);
/*  83 */     if (this.objPooledExecutor == null)
/*  84 */       synchronized (this) {
/*  85 */         if (this.objPooledExecutor == null) {
/*  86 */           this.objPooledExecutor = new PooledExecutor(new BoundedBuffer(boundedBufferSize));
/*  87 */           this.objPooledExecutor.setKeepAliveTime(keepAliveTime);
/*  88 */           this.objPooledExecutor.setMinimumPoolSize(minThread);
/*  89 */           this.objPooledExecutor.setMaximumPoolSize(maxThread);
/*  90 */           this.objPooledExecutor.createThreads(createThread);
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public void insert(Object object)
/*     */   {
/* 101 */     if (this.data.size() >= this.limitLength) {
/* 102 */       synchronized (this) {
/* 103 */         if (this.data.size() >= this.limitLength) {
/* 104 */           flush();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 109 */     long key = increatCount();
/* 110 */     Object obj = this.data.put(new Long(key), object);
/* 111 */     if (obj != null)
/* 112 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.collection.asyn.AsynContainer.insert_key_error", new String[] { obj.toString() }));
/*     */   }
/*     */ 
/*     */   public long getTotalCount()
/*     */   {
/* 121 */     return this.count;
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */     try
/*     */     {
/* 129 */       if (this.data.size() > 0)
/* 130 */         synchronized (this) {
/* 131 */           if (this.data.size() > 0) {
/* 132 */             FlushWorkTask objFlushWorkTask = (FlushWorkTask)this.workTaskClass.newInstance();
/* 133 */             HashMap map = new HashMap();
/* 134 */             map.putAll(this.data);
/*     */ 
/* 136 */             Set keys = map.keySet();
/* 137 */             for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 138 */               Object item = iter.next();
/* 139 */               this.data.remove(item);
/*     */             }
/*     */ 
/* 142 */             objFlushWorkTask.setData(map);
/* 143 */             this.objPooledExecutor.execute(objFlushWorkTask);
/*     */           }
/*     */         }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 149 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.collection.asyn.AsynContainer.insert_Refresh_error"), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private synchronized long increatCount()
/*     */   {
/* 158 */     return ++this.count;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.AsynContainer
 * JD-Core Version:    0.5.4
 */