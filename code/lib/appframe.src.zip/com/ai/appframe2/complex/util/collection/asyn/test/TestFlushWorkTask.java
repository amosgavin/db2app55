/*    */ package com.ai.appframe2.complex.util.collection.asyn.test;
/*    */ 
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.appframe2.common.Session;
/*    */ import com.ai.appframe2.complex.util.collection.asyn.FlushWorkTask;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TestFlushWorkTask extends FlushWorkTask
/*    */ {
/* 14 */   private static transient Log log = LogFactory.getLog(TestFlushWorkTask.class);
/*    */ 
/*    */   public void work(HashMap data)
/*    */     throws Exception
/*    */   {
/* 26 */     long l = 0L;
/* 27 */     Connection conn = null;
/* 28 */     PreparedStatement ptmt = null;
/*    */     try {
/* 30 */       ServiceManager.getSession().startTransaction();
/* 31 */       conn = ServiceManager.getSession().getConnection("base");
/* 32 */       ptmt = conn.prepareStatement("insert into audit_log values(?,?)");
/* 33 */       for (Iterator iter = data.values().iterator(); iter.hasNext(); ) {
/* 34 */         Object item = iter.next();
/* 35 */         ptmt.setLong(1, l);
/* 36 */         ptmt.setString(2, item.toString());
/* 37 */         ptmt.addBatch();
/* 38 */         l += 1L;
/*    */       }
/* 40 */       ptmt.executeBatch();
/* 41 */       log.debug("Count:" + data.size());
/*    */ 
/* 43 */       ServiceManager.getSession().commitTransaction();
/*    */     }
/*    */     catch (Exception ex) {
/* 46 */       ServiceManager.getSession().rollbackTransaction();
/* 47 */       throw ex;
/*    */     }
/*    */     finally {
/* 50 */       if (ptmt != null) {
/* 51 */         ptmt.close();
/*    */       }
/* 53 */       if (conn != null)
/* 54 */         conn.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.test.TestFlushWorkTask
 * JD-Core Version:    0.5.4
 */