/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class StringLengthDescComparator
/*    */   implements Comparator
/*    */ {
/*    */   public int compare(Object o1, Object o2)
/*    */   {
/* 31 */     String s1 = (String)o1;
/* 32 */     String s2 = (String)o2;
/*    */ 
/* 34 */     int rtn = 0;
/* 35 */     int i1 = s1.length();
/* 36 */     int i2 = s2.length();
/* 37 */     if (i1 == i2) {
/* 38 */       rtn = 0;
/*    */     }
/* 40 */     else if (i1 < i2) {
/* 41 */       rtn = 1;
/*    */     }
/* 43 */     else if (i1 > i2) {
/* 44 */       rtn = -1;
/*    */     }
/* 46 */     return rtn;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 62 */     List list = new ArrayList();
/*    */ 
/* 64 */     for (int i = 0; i < 10001; ++i) {
/* 65 */       list.add("str" + i + "str");
/*    */     }
/*    */ 
/* 68 */     String[] a = (String[])(String[])list.toArray(new String[0]);
/* 69 */     Arrays.sort(a, new StringLengthDescComparator());
/* 70 */     System.out.println(a[0]);
/*    */ 
/* 73 */     long start = System.currentTimeMillis();
/* 74 */     for (int j = 0; j < 10000; ++j) {
/* 75 */       for (int i = 0; i < a.length; ++i) {
/* 76 */         if ("str0".indexOf(a[i]) != -1) {
/*    */           break;
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 82 */     System.out.println("Time cost:" + (System.currentTimeMillis() - start) + ":ms");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.StringLengthDescComparator
 * JD-Core Version:    0.5.4
 */