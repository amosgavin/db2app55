/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import com.ai.appframe2.web.HttpUtil;
/*    */ import javax.servlet.ServletRequest;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public final class WebUtil
/*    */ {
/*    */   public static String[] getCenterTypeAndValueByRequestAndCondition(String url)
/*    */     throws Exception
/*    */   {
/* 30 */     String[] rtn = new String[2];
/* 31 */     String[] tmp1 = StringUtils.split(url, "&");
/* 32 */     for (int i = 0; i < tmp1.length; ++i) {
/* 33 */       String[] tmp2 = StringUtils.split(tmp1[i], "=");
/* 34 */       if (tmp2[0].equalsIgnoreCase("CenterType")) {
/* 35 */         rtn[0] = tmp2[1].trim();
/*    */       }
/* 37 */       else if (tmp2[0].equalsIgnoreCase("CenterValue")) {
/* 38 */         rtn[1] = tmp2[1].trim();
/*    */       }
/*    */     }
/* 41 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static String[] getCenterTypeAndValueByRequestAndCondition(ServletRequest request, String conditionName)
/*    */     throws Exception
/*    */   {
/* 51 */     String[] rtn = new String[2];
/* 52 */     String str = HttpUtil.getParameter(request, conditionName);
/* 53 */     String[] tmp1 = StringUtils.split(str, "&");
/* 54 */     for (int i = 0; i < tmp1.length; ++i) {
/* 55 */       String[] tmp2 = StringUtils.split(tmp1[i], "=");
/* 56 */       if (tmp2[0].equalsIgnoreCase("CenterType")) {
/* 57 */         rtn[0] = tmp2[1].trim();
/*    */       }
/* 59 */       else if (tmp2[0].equalsIgnoreCase("CenterValue")) {
/* 60 */         rtn[1] = tmp2[1].trim();
/*    */       }
/*    */     }
/* 63 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static String getCrossCenterByRequestAndCondition(ServletRequest request, String conditionName)
/*    */     throws Exception
/*    */   {
/* 72 */     String rtn = null;
/* 73 */     String str = HttpUtil.getParameter(request, conditionName);
/* 74 */     String[] tmp1 = StringUtils.split(str, "&");
/* 75 */     for (int i = 0; i < tmp1.length; ++i) {
/* 76 */       String[] tmp2 = StringUtils.split(tmp1[i], "=");
/* 77 */       if (tmp2[0].equalsIgnoreCase("CrossCenter")) {
/* 78 */         rtn = tmp2[1].trim();
/* 79 */         break;
/*    */       }
/*    */     }
/* 82 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 87 */     getCenterTypeAndValueByRequestAndCondition(null, null);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.WebUtil
 * JD-Core Version:    0.5.4
 */