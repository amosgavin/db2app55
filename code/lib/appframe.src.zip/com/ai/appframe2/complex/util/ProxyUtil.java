/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import java.lang.reflect.InvocationHandler;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public final class ProxyUtil
/*    */ {
/* 20 */   private static final Class[] CONSTRUCT_PARAM = { InvocationHandler.class };
/* 21 */   private static final HashMap CONS_CACHE = new HashMap();
/*    */ 
/*    */   public static final Object getProxyObject(ClassLoader loader, Class[] interfaces, InvocationHandler h)
/*    */   {
/* 34 */     String key = interfaces[0].getName();
/* 35 */     Constructor cons = (Constructor)CONS_CACHE.get(key);
/* 36 */     if (cons == null) {
/* 37 */       synchronized (CONS_CACHE) {
/* 38 */         if (!CONS_CACHE.containsKey(key)) {
/* 39 */           Class c = Proxy.getProxyClass(loader, interfaces);
/*    */           try {
/* 41 */             cons = c.getConstructor(CONSTRUCT_PARAM);
/*    */           }
/*    */           catch (NoSuchMethodException e) {
/* 44 */             throw new InternalError(e.toString());
/*    */           }
/* 46 */           CONS_CACHE.put(key, cons);
/*    */         }
/* 48 */         cons = (Constructor)CONS_CACHE.get(key);
/*    */       }
/*    */     }
/*    */     try
/*    */     {
/* 53 */       return cons.newInstance(new Object[] { h });
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 56 */       throw new InternalError(e.toString());
/*    */     }
/*    */     catch (InstantiationException e) {
/* 59 */       throw new InternalError(e.toString());
/*    */     }
/*    */     catch (InvocationTargetException e) {
/* 62 */       throw new InternalError(e.toString());
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.ProxyUtil
 * JD-Core Version:    0.5.4
 */