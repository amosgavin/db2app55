package com.ai.appframe2.complex.util.tt;

import java.util.List;

public abstract interface Table
{
  public abstract void setHeader(String[] paramArrayOfString);

  public abstract void addRow(String[] paramArrayOfString);

  public abstract void addRows(List paramList);

  public abstract String draw();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.tt.Table
 * JD-Core Version:    0.5.4
 */