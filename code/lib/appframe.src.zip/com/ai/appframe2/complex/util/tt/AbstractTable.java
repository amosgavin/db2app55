/*    */ package com.ai.appframe2.complex.util.tt;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class AbstractTable
/*    */   implements Table
/*    */ {
/*    */   private String[] header;
/*    */   private List rows;
/*    */ 
/*    */   public AbstractTable()
/*    */   {
/* 15 */     this.rows = new LinkedList();
/*    */   }
/*    */   public void setHeader(String[] header) {
/* 18 */     this.header = header;
/*    */   }
/*    */ 
/*    */   public void addRow(String[] row) {
/* 22 */     this.rows.add(row);
/*    */   }
/*    */ 
/*    */   public void addRows(List rows) {
/* 26 */     this.rows.addAll(rows);
/*    */   }
/*    */ 
/*    */   protected String[] getHeader() {
/* 30 */     return this.header;
/*    */   }
/*    */ 
/*    */   protected List getRows() {
/* 34 */     return this.rows;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.tt.AbstractTable
 * JD-Core Version:    0.5.4
 */