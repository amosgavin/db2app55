/*    */ package com.ai.appframe2.complex.util.collection;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.collections.collection.UnmodifiableCollection;
/*    */ import org.apache.commons.collections.map.UnmodifiableEntrySet;
/*    */ import org.apache.commons.collections.set.UnmodifiableSet;
/*    */ 
/*    */ public final class UnmodifiableHashMap extends HashMap
/*    */ {
/*    */   private static final long serialVersionUID = 87366327269031941L;
/* 25 */   private HashMap map = null;
/*    */ 
/*    */   public UnmodifiableHashMap(HashMap map) {
/* 28 */     if (map == null) {
/* 29 */       throw new NullPointerException();
/*    */     }
/* 31 */     this.map = map;
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 35 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object put(Object key, Object value) {
/* 39 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void putAll(Map mapToCopy) {
/* 43 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object remove(Object key) {
/* 47 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Set entrySet() {
/* 51 */     Set set = this.map.entrySet();
/* 52 */     return UnmodifiableEntrySet.decorate(set);
/*    */   }
/*    */ 
/*    */   public Set keySet() {
/* 56 */     Set set = this.map.keySet();
/* 57 */     return UnmodifiableSet.decorate(set);
/*    */   }
/*    */ 
/*    */   public Collection values() {
/* 61 */     Collection coll = this.map.values();
/* 62 */     return UnmodifiableCollection.decorate(coll);
/*    */   }
/*    */ 
/*    */   public int size() {
/* 66 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 70 */     return this.map.isEmpty();
/*    */   }
/*    */ 
/*    */   public boolean containsKey(Object key) {
/* 74 */     return this.map.containsKey(key);
/*    */   }
/*    */ 
/*    */   public boolean containsValue(Object val) {
/* 78 */     return this.map.containsValue(val);
/*    */   }
/*    */ 
/*    */   public Object get(Object key) {
/* 82 */     return this.map.get(key);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object o) {
/* 86 */     return this.map.equals(o);
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 90 */     return this.map.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 94 */     return this.map.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.UnmodifiableHashMap
 * JD-Core Version:    0.5.4
 */