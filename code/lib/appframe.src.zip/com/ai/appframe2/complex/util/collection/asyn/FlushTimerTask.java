/*    */ package com.ai.appframe2.complex.util.collection.asyn;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.TimerTask;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class FlushTimerTask extends TimerTask
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(FlushTimerTask.class);
/*    */ 
/* 21 */   private AsynContainer objAsynContainer = null;
/*    */ 
/*    */   public FlushTimerTask(AsynContainer objAsynContainer)
/*    */   {
/* 28 */     this.objAsynContainer = objAsynContainer;
/*    */   }
/*    */ 
/*    */   public void run() {
/* 32 */     if (log.isDebugEnabled()) {
/* 33 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.collection.asyn.FlushTimerTask.Flush"));
/*    */     }
/*    */ 
/* 36 */     this.objAsynContainer.flush();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.FlushTimerTask
 * JD-Core Version:    0.5.4
 */