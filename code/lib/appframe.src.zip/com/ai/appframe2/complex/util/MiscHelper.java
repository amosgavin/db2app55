/*     */ package com.ai.appframe2.complex.util;
/*     */ 
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.ClassUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public final class MiscHelper
/*     */ {
/*  22 */   private static final HashMap SERVICES_CACHE = new HashMap();
/*  23 */   private static final HashMap CLIENT_CONSTRUCTOR_CACHE = new HashMap();
/*  24 */   private static final HashMap JNDI_CACHE = new HashMap();
/*  25 */   private static final HashMap HOMECLASS_CACHE = new HashMap();
/*  26 */   private static final HashMap FLYINGCLASS_CACHE = new HashMap();
/*     */ 
/*     */   public static Class getImplClassByInterClassName(Class interClass)
/*     */   {
/*  44 */     Class rtn = (Class)SERVICES_CACHE.get(interClass.getName());
/*  45 */     if (rtn == null) {
/*  46 */       synchronized (SERVICES_CACHE) {
/*  47 */         if (!SERVICES_CACHE.containsKey(interClass)) {
/*  48 */           String packageName = StringUtils.replace(ClassUtils.getPackageName(interClass), "interfaces", "impl");
/*  49 */           char[] className = (ClassUtils.getShortClassName(interClass) + "Impl").toCharArray();
/*  50 */           String clName = packageName + "." + new String(className, 1, className.length - 1);
/*     */           try {
/*  52 */             rtn = Class.forName(clName);
/*     */           }
/*     */           catch (ClassNotFoundException ex) {
/*  55 */             throw new RuntimeException(ex);
/*     */           }
/*  57 */           SERVICES_CACHE.put(interClass.getName(), rtn);
/*     */         }
/*  59 */         rtn = (Class)SERVICES_CACHE.get(interClass.getName());
/*     */       }
/*     */     }
/*  62 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static Class getImplClassByInterClassName(String interClass)
/*     */   {
/*  77 */     Class rtn = (Class)SERVICES_CACHE.get(interClass);
/*  78 */     if (rtn == null) {
/*  79 */       synchronized (SERVICES_CACHE) {
/*  80 */         if (!SERVICES_CACHE.containsKey(interClass)) {
/*  81 */           String[] tmp = StringUtils.split(interClass, ".");
/*  82 */           String[] packageTmp = new String[tmp.length - 1];
/*  83 */           System.arraycopy(tmp, 0, packageTmp, 0, tmp.length - 1);
/*     */ 
/*  85 */           String packageName = StringUtils.replace(StringUtils.join(packageTmp, "."), "interfaces", "impl");
/*  86 */           char[] className = (tmp[(tmp.length - 1)] + "Impl").toCharArray();
/*  87 */           String clName = packageName + "." + new String(className, 1, className.length - 1);
/*     */           try {
/*  89 */             rtn = Class.forName(clName);
/*     */           }
/*     */           catch (ClassNotFoundException ex) {
/*  92 */             throw new RuntimeException(ex);
/*     */           }
/*  94 */           SERVICES_CACHE.put(interClass, rtn);
/*     */         }
/*  96 */         rtn = (Class)SERVICES_CACHE.get(interClass);
/*     */       }
/*     */     }
/*  99 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static String getImplClassByPropertyAndServiceId(String serviceId, Property[] properties)
/*     */   {
/* 109 */     String implClass = null;
/* 110 */     for (int i = 0; i < properties.length; ++i) {
/* 111 */       if (properties[i].getName().equalsIgnoreCase("implClass")) {
/* 112 */         implClass = properties[i].getValue().trim();
/* 113 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 117 */     if (StringUtils.isBlank(implClass))
/*     */     {
/* 119 */       implClass = getImplClassByInterClassName(serviceId).getName();
/*     */     }
/* 121 */     return implClass;
/*     */   }
/*     */ 
/*     */   public static String getInterfaceClassByPropertyAndServiceId(String serviceId, Property[] properties)
/*     */   {
/* 131 */     String interfaceClass = null;
/* 132 */     for (int i = 0; i < properties.length; ++i) {
/* 133 */       if (properties[i].getName().equalsIgnoreCase("interfaceClass")) {
/* 134 */         interfaceClass = properties[i].getValue().trim();
/* 135 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 139 */     if (StringUtils.isBlank(interfaceClass))
/*     */     {
/* 141 */       interfaceClass = serviceId;
/*     */     }
/* 143 */     return interfaceClass;
/*     */   }
/*     */ 
/*     */   public static String getJndiNameByInterClassName(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 153 */     String jndi = null;
/* 154 */     if (!JNDI_CACHE.containsKey(interfaceClass)) {
/* 155 */       synchronized (JNDI_CACHE) {
/* 156 */         if (!JNDI_CACHE.containsKey(interfaceClass)) {
/* 157 */           jndi = StringUtils.replace(interfaceClass.getName(), "interfaces", "ejb");
/*     */ 
/* 159 */           if (jndi == null)
/*     */           {
/* 161 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.cannot_find", new String[] { interfaceClass.toString(), "jndi" });
/*     */ 
/* 163 */             throw new Exception(msg);
/*     */           }
/* 165 */           JNDI_CACHE.put(interfaceClass, jndi);
/*     */         }
/* 167 */         jndi = (String)JNDI_CACHE.get(interfaceClass);
/*     */       }
/*     */     }
/*     */     else {
/* 171 */       jndi = (String)JNDI_CACHE.get(interfaceClass);
/*     */     }
/* 173 */     return jndi;
/*     */   }
/*     */ 
/*     */   public static Class getHomeClassNameByInterClassName(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 183 */     Class home = null;
/* 184 */     if (!HOMECLASS_CACHE.containsKey(interfaceClass)) {
/* 185 */       synchronized (HOMECLASS_CACHE) {
/* 186 */         if (!HOMECLASS_CACHE.containsKey(interfaceClass)) {
/* 187 */           home = Class.forName(StringUtils.replace(interfaceClass.getName(), "interfaces", "ejb") + "RemoteHome");
/*     */ 
/* 189 */           if (home == null)
/*     */           {
/* 192 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.cannot_find", new String[] { interfaceClass.toString(), " EJB Home Class" }));
/*     */           }
/* 194 */           HOMECLASS_CACHE.put(interfaceClass, home);
/*     */         }
/* 196 */         home = (Class)HOMECLASS_CACHE.get(interfaceClass);
/*     */       }
/*     */     }
/*     */     else {
/* 200 */       home = (Class)HOMECLASS_CACHE.get(interfaceClass);
/*     */     }
/*     */ 
/* 203 */     return home;
/*     */   }
/*     */ 
/*     */   public static Class getFlyingClassNameByInterClassName(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 213 */     Class home = null;
/* 214 */     if (!FLYINGCLASS_CACHE.containsKey(interfaceClass)) {
/* 215 */       synchronized (FLYINGCLASS_CACHE) {
/* 216 */         if (!FLYINGCLASS_CACHE.containsKey(interfaceClass)) {
/* 217 */           home = Class.forName(StringUtils.replace(interfaceClass.getName(), "interfaces", "flying") + "FlyingInterface");
/*     */ 
/* 219 */           if (home == null)
/*     */           {
/* 222 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.cannot_find", new String[] { interfaceClass.toString(), " Flying Interface Class" }));
/*     */           }
/* 224 */           FLYINGCLASS_CACHE.put(interfaceClass, home);
/*     */         }
/* 226 */         home = (Class)FLYINGCLASS_CACHE.get(interfaceClass);
/*     */       }
/*     */     }
/*     */     else {
/* 230 */       home = (Class)FLYINGCLASS_CACHE.get(interfaceClass);
/*     */     }
/*     */ 
/* 233 */     return home;
/*     */   }
/*     */ 
/*     */   public static Constructor getEJBClientConstructor(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 244 */     Constructor objConstructor = null;
/* 245 */     if (!CLIENT_CONSTRUCTOR_CACHE.containsKey(interfaceClass)) {
/* 246 */       synchronized (CLIENT_CONSTRUCTOR_CACHE) {
/* 247 */         if (!CLIENT_CONSTRUCTOR_CACHE.containsKey(interfaceClass)) {
/* 248 */           Class client = Class.forName(StringUtils.replace(interfaceClass.getName(), "interfaces", "ejb") + "Client");
/* 249 */           Constructor[] constructors = client.getConstructors();
/* 250 */           for (int i = 0; i < constructors.length; ++i) {
/* 251 */             if ((constructors[i].getParameterTypes() != null) && (constructors[i].getParameterTypes().length == 1)) {
/* 252 */               objConstructor = constructors[i];
/* 253 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 257 */           if (objConstructor == null)
/*     */           {
/* 260 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.cannot_find", new String[] { interfaceClass.toString(), " EJB Client Class" }));
/*     */           }
/* 262 */           CLIENT_CONSTRUCTOR_CACHE.put(interfaceClass, objConstructor);
/*     */         }
/* 264 */         objConstructor = (Constructor)CLIENT_CONSTRUCTOR_CACHE.get(interfaceClass);
/*     */       }
/*     */     }
/*     */     else {
/* 268 */       objConstructor = (Constructor)CLIENT_CONSTRUCTOR_CACHE.get(interfaceClass);
/*     */     }
/* 270 */     return objConstructor;
/*     */   }
/*     */ 
/*     */   public static Constructor getFlyingClientConstructor(Class interfaceClass)
/*     */     throws Exception
/*     */   {
/* 281 */     Constructor objConstructor = null;
/* 282 */     if (!CLIENT_CONSTRUCTOR_CACHE.containsKey(interfaceClass)) {
/* 283 */       synchronized (CLIENT_CONSTRUCTOR_CACHE) {
/* 284 */         if (!CLIENT_CONSTRUCTOR_CACHE.containsKey(interfaceClass)) {
/* 285 */           Class client = Class.forName(StringUtils.replace(interfaceClass.getName(), "interfaces", "flying") + "FlyingClient");
/* 286 */           Constructor[] constructors = client.getConstructors();
/* 287 */           for (int i = 0; i < constructors.length; ++i) {
/* 288 */             if ((constructors[i].getParameterTypes() != null) && (constructors[i].getParameterTypes().length == 1)) {
/* 289 */               objConstructor = constructors[i];
/* 290 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 294 */           if (objConstructor == null)
/*     */           {
/* 297 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.cannot_find", new String[] { interfaceClass.toString(), " Flying Client Class" }));
/*     */           }
/* 299 */           CLIENT_CONSTRUCTOR_CACHE.put(interfaceClass, objConstructor);
/*     */         }
/* 301 */         objConstructor = (Constructor)CLIENT_CONSTRUCTOR_CACHE.get(interfaceClass);
/*     */       }
/*     */     }
/*     */     else {
/* 305 */       objConstructor = (Constructor)CLIENT_CONSTRUCTOR_CACHE.get(interfaceClass);
/*     */     }
/* 307 */     return objConstructor;
/*     */   }
/*     */ 
/*     */   public static String getCallPath()
/*     */   {
/* 316 */     StringBuilder sb = new StringBuilder();
/* 317 */     StackTraceElement[] stack = new Throwable().getStackTrace();
/*     */ 
/* 319 */     String lineCount = AppframeLocaleFactory.getResource("com.ai.appframe2.line_count");
/* 320 */     for (int i = 0; i < stack.length; ++i) {
/* 321 */       sb.append(stack[i].getClassName() + "." + stack[i].getMethodName() + "() " + lineCount + ":" + stack[i].getLineNumber() + "\n");
/*     */     }
/* 323 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.MiscHelper
 * JD-Core Version:    0.5.4
 */