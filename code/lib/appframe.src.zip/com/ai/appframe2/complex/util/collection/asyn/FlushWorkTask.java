/*    */ package com.ai.appframe2.complex.util.collection.asyn;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public abstract class FlushWorkTask
/*    */   implements Runnable
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(FlushWorkTask.class);
/*    */ 
/* 21 */   protected HashMap data = null;
/*    */ 
/*    */   public void setData(HashMap data)
/*    */   {
/* 27 */     this.data = data;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 35 */       work(this.data);
/*    */     }
/*    */     catch (Throwable ex) {
/* 38 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.collection.asyn.FlushWorkTask.run_error"), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public abstract void work(HashMap paramHashMap)
/*    */     throws Exception;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.FlushWorkTask
 * JD-Core Version:    0.5.4
 */