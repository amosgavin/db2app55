/*     */ package com.ai.appframe2.complex.util.e;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.security.InvalidKeyException;
/*     */ import sun.misc.BASE64Decoder;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public final class RC2
/*     */ {
/*  24 */   private static final int[] S_BOX = { 217, 120, 249, 196, 25, 221, 181, 237, 40, 233, 253, 121, 74, 160, 216, 157, 198, 126, 55, 131, 43, 118, 83, 142, 98, 76, 100, 136, 68, 139, 251, 162, 23, 154, 89, 245, 135, 179, 79, 19, 97, 69, 109, 141, 9, 129, 125, 50, 189, 143, 64, 235, 134, 183, 123, 11, 240, 149, 33, 34, 92, 107, 78, 130, 84, 214, 101, 147, 206, 96, 178, 28, 115, 86, 192, 20, 167, 140, 241, 220, 18, 117, 202, 31, 59, 190, 228, 209, 66, 61, 212, 48, 163, 60, 182, 38, 111, 191, 14, 218, 70, 105, 7, 87, 39, 242, 29, 155, 188, 148, 67, 3, 248, 17, 199, 246, 144, 239, 62, 231, 6, 195, 213, 47, 200, 102, 30, 215, 8, 232, 234, 222, 128, 82, 238, 247, 132, 170, 114, 172, 53, 77, 106, 42, 150, 26, 210, 113, 90, 21, 73, 116, 75, 159, 208, 94, 4, 24, 164, 236, 194, 224, 65, 110, 15, 81, 203, 204, 36, 145, 175, 80, 161, 244, 112, 57, 153, 124, 58, 133, 35, 184, 180, 122, 252, 2, 54, 91, 37, 85, 151, 49, 45, 93, 250, 152, 227, 138, 146, 174, 5, 223, 41, 16, 103, 108, 186, 201, 211, 0, 230, 207, 225, 158, 168, 44, 99, 22, 1, 63, 88, 226, 137, 169, 13, 56, 52, 27, 171, 51, 255, 176, 187, 72, 12, 95, 185, 177, 205, 46, 197, 243, 219, 71, 229, 165, 156, 119, 10, 166, 32, 104, 254, 127, 193, 173 };
/*     */   private int[] sKey;
/*     */ 
/*     */   public RC2()
/*     */   {
/*  60 */     this.sKey = new int[64];
/*     */   }
/*     */ 
/*     */   private void makeKey(byte[] userkey)
/*     */     throws InvalidKeyException
/*     */   {
/*  68 */     if (userkey == null) {
/*  69 */       throw new InvalidKeyException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.e.RC2.makeKey_key_null"));
/*     */     }
/*  71 */     int len = userkey.length;
/*  72 */     if (len > 128) {
/*  73 */       throw new InvalidKeyException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.e.RC2.makeKey_key_error"));
/*     */     }
/*     */ 
/*  76 */     int[] sk = new int[''];
/*  77 */     for (int i = 0; i < len; ++i) {
/*  78 */       sk[i] = userkey[i];
/*     */     }
/*  80 */     for (int i = len; i < 128; ++i) {
/*  81 */       sk[i] = S_BOX[(sk[(i - len)] + sk[(i - 1)] & 0xFF)];
/*     */     }
/*     */ 
/*  89 */     len = 128;
/*  90 */     sk[(128 - len)] = S_BOX[(sk[(128 - len)] & 0xFF)];
/*  91 */     for (int i = 127 - len; i >= 0; --i) {
/*  92 */       sk[i] = S_BOX[(sk[(i + len)] ^ sk[(i + 1)])];
/*     */     }
/*     */ 
/*  95 */     for (int i = 63; i >= 0; --i)
/*  96 */       this.sKey[i] = ((sk[(i * 2 + 1)] << 8 | sk[(i * 2)]) & 0xFFFF);
/*     */   }
/*     */ 
/*     */   private void blockEncrypt(byte[] in, int inOff, byte[] out, int outOff)
/*     */   {
/* 107 */     int w0 = in[(inOff++)] & 0xFF | (in[(inOff++)] & 0xFF) << 8;
/* 108 */     int w1 = in[(inOff++)] & 0xFF | (in[(inOff++)] & 0xFF) << 8;
/* 109 */     int w2 = in[(inOff++)] & 0xFF | (in[(inOff++)] & 0xFF) << 8;
/* 110 */     int w3 = in[(inOff++)] & 0xFF | (in[inOff] & 0xFF) << 8;
/* 111 */     int j = 0;
/* 112 */     for (int i = 0; i < 16; ++i) {
/* 113 */       w0 = w0 + (w1 & (w3 ^ 0xFFFFFFFF)) + (w2 & w3) + this.sKey[(j++)] & 0xFFFF;
/* 114 */       w0 = w0 << 1 | w0 >>> 15;
/* 115 */       w1 = w1 + (w2 & (w0 ^ 0xFFFFFFFF)) + (w3 & w0) + this.sKey[(j++)] & 0xFFFF;
/* 116 */       w1 = w1 << 2 | w1 >>> 14;
/* 117 */       w2 = w2 + (w3 & (w1 ^ 0xFFFFFFFF)) + (w0 & w1) + this.sKey[(j++)] & 0xFFFF;
/* 118 */       w2 = w2 << 3 | w2 >>> 13;
/* 119 */       w3 = w3 + (w0 & (w2 ^ 0xFFFFFFFF)) + (w1 & w2) + this.sKey[(j++)] & 0xFFFF;
/* 120 */       w3 = w3 << 5 | w3 >>> 11;
/* 121 */       if ((i == 4) || (i == 10)) {
/* 122 */         w0 += this.sKey[(w3 & 0x3F)];
/* 123 */         w1 += this.sKey[(w0 & 0x3F)];
/* 124 */         w2 += this.sKey[(w1 & 0x3F)];
/* 125 */         w3 += this.sKey[(w2 & 0x3F)];
/*     */       }
/*     */     }
/* 128 */     out[(outOff++)] = (byte)w0;
/* 129 */     out[(outOff++)] = (byte)(w0 >>> 8);
/* 130 */     out[(outOff++)] = (byte)w1;
/* 131 */     out[(outOff++)] = (byte)(w1 >>> 8);
/* 132 */     out[(outOff++)] = (byte)w2;
/* 133 */     out[(outOff++)] = (byte)(w2 >>> 8);
/* 134 */     out[(outOff++)] = (byte)w3;
/* 135 */     out[outOff] = (byte)(w3 >>> 8);
/*     */   }
/*     */ 
/*     */   private void blockDecrypt(byte[] in, int inOff, byte[] out, int outOff)
/*     */   {
/* 146 */     int w0 = in[(inOff + 0)] & 0xFF | (in[(inOff + 1)] & 0xFF) << 8;
/* 147 */     int w1 = in[(inOff + 2)] & 0xFF | (in[(inOff + 3)] & 0xFF) << 8;
/* 148 */     int w2 = in[(inOff + 4)] & 0xFF | (in[(inOff + 5)] & 0xFF) << 8;
/* 149 */     int w3 = in[(inOff + 6)] & 0xFF | (in[(inOff + 7)] & 0xFF) << 8;
/* 150 */     int j = 63;
/* 151 */     for (int i = 15; i >= 0; --i) {
/* 152 */       w3 = (w3 >>> 5 | w3 << 11) & 0xFFFF;
/* 153 */       w3 = w3 - (w0 & (w2 ^ 0xFFFFFFFF)) - (w1 & w2) - this.sKey[(j--)] & 0xFFFF;
/* 154 */       w2 = (w2 >>> 3 | w2 << 13) & 0xFFFF;
/* 155 */       w2 = w2 - (w3 & (w1 ^ 0xFFFFFFFF)) - (w0 & w1) - this.sKey[(j--)] & 0xFFFF;
/* 156 */       w1 = (w1 >>> 2 | w1 << 14) & 0xFFFF;
/* 157 */       w1 = w1 - (w2 & (w0 ^ 0xFFFFFFFF)) - (w3 & w0) - this.sKey[(j--)] & 0xFFFF;
/* 158 */       w0 = (w0 >>> 1 | w0 << 15) & 0xFFFF;
/* 159 */       w0 = w0 - (w1 & (w3 ^ 0xFFFFFFFF)) - (w2 & w3) - this.sKey[(j--)] & 0xFFFF;
/* 160 */       if ((i == 11) || (i == 5)) {
/* 161 */         w3 = w3 - this.sKey[(w2 & 0x3F)] & 0xFFFF;
/* 162 */         w2 = w2 - this.sKey[(w1 & 0x3F)] & 0xFFFF;
/* 163 */         w1 = w1 - this.sKey[(w0 & 0x3F)] & 0xFFFF;
/* 164 */         w0 = w0 - this.sKey[(w3 & 0x3F)] & 0xFFFF;
/*     */       }
/*     */     }
/* 167 */     out[(outOff++)] = (byte)w0;
/* 168 */     out[(outOff++)] = (byte)(w0 >>> 8);
/* 169 */     out[(outOff++)] = (byte)w1;
/* 170 */     out[(outOff++)] = (byte)(w1 >>> 8);
/* 171 */     out[(outOff++)] = (byte)w2;
/* 172 */     out[(outOff++)] = (byte)(w2 >>> 8);
/* 173 */     out[(outOff++)] = (byte)w3;
/* 174 */     out[outOff] = (byte)(w3 >>> 8);
/*     */   }
/*     */ 
/*     */   private byte rc2_encrypt_chr(byte plain)
/*     */   {
/* 185 */     int src = plain;
/*     */ 
/* 187 */     for (int i = 0; i < 64; ++i) {
/* 188 */       src += (this.sKey[i] >> 8 & 0xFF);
/* 189 */       src ^= this.sKey[i] & 0xFF;
/* 190 */       src = (src << 5 & 0xE0) + (src >> 3 & 0x1F);
/*     */ 
/* 192 */       if (i % 16 != 4) if ((((i % 16 == 5) ? 1 : 0) | ((i % 16 == 14) ? 1 : 0)) == 0)
/*     */           continue; src ^= this.sKey[i] >> 8 & 0xFF;
/* 194 */       src -= (this.sKey[i] & 0xFF);
/*     */     }
/*     */ 
/* 198 */     return (byte)src;
/*     */   }
/*     */ 
/*     */   private byte rc2_decrypt_chr(byte ciper)
/*     */   {
/* 209 */     int src = ciper;
/*     */ 
/* 211 */     for (int i = 63; i >= 0; --i) {
/* 212 */       if (i % 16 != 4) if ((((i % 16 == 5) ? 1 : 0) | ((i % 16 == 14) ? 1 : 0)) == 0)
/*     */           break label77; src += (this.sKey[i] & 0xFF);
/* 214 */       src ^= this.sKey[i] >> 8 & 0xFF;
/*     */ 
/* 217 */       label77: src = (src << 3 & 0xF8) + (src >> 5 & 0x7);
/* 218 */       src ^= this.sKey[i] & 0xFF;
/* 219 */       src -= (this.sKey[i] >> 8 & 0xFF);
/*     */     }
/*     */ 
/* 222 */     return (byte)src;
/*     */   }
/*     */ 
/*     */   public byte[] encrypt_rc2_array(byte[] plain, byte[] key)
/*     */     throws Exception
/*     */   {
/* 233 */     byte[] in = new byte[8];
/* 234 */     byte[] out = new byte[8];
/* 235 */     byte[] p = null;
/*     */ 
/* 239 */     if ((plain == null) || (plain.length == 0))
/*     */     {
/* 241 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.blank_plaintext"));
/*     */     }
/*     */ 
/* 244 */     makeKey(key);
/*     */ 
/* 246 */     int j = plain.length / 8;
/* 247 */     for (int i = 0; i < j; ++i) {
/* 248 */       for (int k = 0; k < 8; ++k) {
/* 249 */         in[k] = plain[(i * 8 + k)];
/*     */       }
/* 251 */       blockEncrypt(in, 0, out, 0);
/* 252 */       for (k = 0; k < 8; ++k) {
/* 253 */         plain[(i * 8 + k)] = out[k];
/*     */       }
/*     */     }
/*     */ 
/* 257 */     int leftLen = plain.length - i * 8;
/* 258 */     p = new byte[leftLen];
/* 259 */     for (int d = 0; d < leftLen; ++d) {
/* 260 */       p[d] = plain[(i * 8 + d)];
/*     */     }
/*     */ 
/* 263 */     if ((p != null) && (p.length > 0)) {
/* 264 */       for (int m = 0; m < leftLen; ++m) {
/* 265 */         byte chr_in = p[m];
/* 266 */         p[m] = rc2_encrypt_chr(chr_in);
/*     */       }
/*     */     }
/*     */ 
/* 270 */     byte[] rtn = new byte[plain.length];
/*     */ 
/* 272 */     for (int g = 0; g < i * 8; ++g) {
/* 273 */       rtn[g] = plain[g];
/*     */     }
/* 275 */     for (int g = 0; g < p.length; ++g) {
/* 276 */       rtn[(i * 8 + g)] = p[g];
/*     */     }
/*     */ 
/* 279 */     return rtn;
/*     */   }
/*     */ 
/*     */   public byte[] decrypt_rc2_array(byte[] cipher, byte[] key)
/*     */     throws Exception
/*     */   {
/* 290 */     byte[] in = new byte[8];
/* 291 */     byte[] out = new byte[8];
/* 292 */     byte[] p = null;
/*     */ 
/* 296 */     if ((cipher == null) || (cipher.length == 0))
/*     */     {
/* 298 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.blank_ciphertext"));
/*     */     }
/*     */ 
/* 301 */     makeKey(key);
/*     */ 
/* 303 */     int j = cipher.length / 8;
/* 304 */     for (int i = 0; i < j; ++i) {
/* 305 */       for (int k = 0; k < 8; ++k) {
/* 306 */         in[k] = cipher[(i * 8 + k)];
/*     */       }
/* 308 */       blockDecrypt(in, 0, out, 0);
/* 309 */       for (k = 0; k < 8; ++k) {
/* 310 */         cipher[(i * 8 + k)] = out[k];
/*     */       }
/*     */     }
/*     */ 
/* 314 */     int leftLen = cipher.length - i * 8;
/* 315 */     p = new byte[leftLen];
/* 316 */     for (int d = 0; d < leftLen; ++d) {
/* 317 */       p[d] = cipher[(i * 8 + d)];
/*     */     }
/*     */ 
/* 320 */     if ((p != null) && (p.length > 0)) {
/* 321 */       for (int m = 0; m < leftLen; ++m) {
/* 322 */         byte chr_in = p[m];
/* 323 */         p[m] = rc2_decrypt_chr(chr_in);
/*     */       }
/*     */     }
/*     */ 
/* 327 */     byte[] rtn = new byte[cipher.length];
/*     */ 
/* 329 */     for (int g = 0; g < i * 8; ++g) {
/* 330 */       rtn[g] = cipher[g];
/*     */     }
/* 332 */     for (int g = 0; g < p.length; ++g) {
/* 333 */       rtn[(i * 8 + g)] = p[g];
/*     */     }
/*     */ 
/* 336 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String encrypt_rc2_array_base64(byte[] plain, byte[] key) throws Exception
/*     */   {
/* 341 */     byte[] rtn = encrypt_rc2_array(plain, key);
/* 342 */     return new BASE64Encoder().encode(rtn);
/*     */   }
/*     */ 
/*     */   public String decrypt_rc2_array_base64(byte[] cipher, byte[] key) throws Exception
/*     */   {
/* 347 */     byte[] aa = new BASE64Decoder().decodeBuffer(new String(cipher));
/* 348 */     byte[] rtn = decrypt_rc2_array(aa, key);
/* 349 */     return new String(rtn);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.e.RC2
 * JD-Core Version:    0.5.4
 */