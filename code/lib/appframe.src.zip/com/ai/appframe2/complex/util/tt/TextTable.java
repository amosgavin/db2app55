/*    */ package com.ai.appframe2.complex.util.tt;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TextTable extends AbstractTable
/*    */ {
/*    */   private static final int COLUMN_SPACING = 5;
/*    */   private int[] columnSize;
/*    */ 
/*    */   public String draw()
/*    */   {
/* 23 */     String[] header = getHeader();
/* 24 */     List rows = getRows();
/*    */ 
/* 27 */     this.columnSize = new int[header.length];
/* 28 */     setColumnSize(header);
/* 29 */     for (Iterator it = rows.iterator(); it.hasNext(); ) {
/* 30 */       setColumnSize((String[])(String[])it.next());
/*    */     }
/*    */ 
/* 34 */     StringBuilder buff = new StringBuilder();
/*    */ 
/* 37 */     printRow(header, buff);
/* 38 */     printUnderline(header, buff);
/*    */ 
/* 40 */     for (Iterator it = rows.iterator(); it.hasNext(); ) {
/* 41 */       printRow((String[])(String[])it.next(), buff);
/*    */     }
/* 43 */     return buff.toString();
/*    */   }
/*    */ 
/*    */   private void setColumnSize(String[] row) {
/* 47 */     for (int i = 0; i < row.length; ++i)
/*    */     {
/*    */       int len;
/*    */       int len;
/* 49 */       if (row[i] == null) {
/* 50 */         len = "<null>".length();
/*    */       }
/*    */       else {
/* 53 */         len = row[i].length();
/*    */       }
/* 55 */       if (len > this.columnSize[i])
/* 56 */         this.columnSize[i] = row[i].length();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void printRow(String[] rows, StringBuilder buff) {
/* 61 */     for (int i = 0; i < rows.length; ++i) {
/* 62 */       if (rows[i] == null) {
/* 63 */         rows[i] = "<null>";
/*    */       }
/* 65 */       String columnValue = SUtil.padRight(rows[i], this.columnSize[i] + 5);
/*    */ 
/* 67 */       buff.append(columnValue);
/*    */     }
/* 69 */     buff.append(System.getProperty("line.separator"));
/*    */   }
/*    */ 
/*    */   private void printUnderline(String[] rows, StringBuilder buff) {
/* 73 */     for (int i = 0; i < rows.length; ++i) {
/* 74 */       String underline = SUtil.getCharSeries('-', rows[i].toString().length());
/*    */ 
/* 76 */       underline = SUtil.padRight(underline, this.columnSize[i] + 5);
/*    */ 
/* 78 */       buff.append(underline);
/*    */     }
/* 80 */     buff.append(System.getProperty("line.separator"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.tt.TextTable
 * JD-Core Version:    0.5.4
 */