/*    */ package com.ai.appframe2.complex.util.e;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public final class G
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 19 */     System.out.println("Please enter the encrypted string,end with Enter!");
/* 20 */     BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
/* 21 */     String start = null;
/* 22 */     if ((start = in.readLine()) != null)
/*    */     {
/* 25 */       System.out.println("You enter an encrypted string is:" + start);
/* 26 */       System.out.println("Encrypted string is:" + K.j(start));
/*    */     }
/* 28 */     System.out.println("Sleep 100s then quit");
/* 29 */     Thread.sleep(100000L);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.e.G
 * JD-Core Version:    0.5.4
 */