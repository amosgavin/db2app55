/*     */ package com.ai.appframe2.complex.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public final class IDTransform
/*     */ {
/*     */   public static long asc2long(String code)
/*     */   {
/*  23 */     StringBuilder sb = new StringBuilder(14);
/*  24 */     char[] ch = code.toUpperCase().toCharArray();
/*  25 */     int chLen = ch.length;
/*  26 */     if (ch[(chLen - 1)] == 'A')
/*     */     {
/*  28 */       sb.append((byte)ch[0]);
/*  29 */       sb.append((byte)ch[1]);
/*  30 */       sb.append("9");
/*     */ 
/*  32 */       if ((ch[2] == 'S') && (ch[3] == 'Z')) {
/*  33 */         sb.append("70");
/*     */       }
/*  35 */       else if ((ch[2] == 'M') && (ch[3] == 'M')) {
/*  36 */         sb.append("71");
/*     */       }
/*  38 */       else if ((ch[2] == 'M') && (ch[3] == 'Z')) {
/*  39 */         sb.append("72");
/*     */       }
/*     */       else {
/*  42 */         sb.append(String.valueOf(ch, 2, 2));
/*     */       }
/*     */ 
/*  45 */       if (ch[4] == 'J') {
/*  46 */         sb.append("9");
/*     */       }
/*     */       else {
/*  49 */         sb.append(ch[4]);
/*     */       }
/*  51 */       sb.append(ch, 5, 6);
/*     */     }
/*     */     else
/*     */     {
/*  55 */       sb.append((byte)ch[0]);
/*  56 */       sb.append((byte)ch[1]);
/*  57 */       int yy = Integer.parseInt(String.valueOf(ch, 2, 2));
/*  58 */       int mm = Integer.parseInt(String.valueOf(ch, 4, 2));
/*  59 */       sb.append((yy - 5) * 12 + (mm - 1));
/*  60 */       sb.append(String.valueOf(ch, 6, 8));
/*     */     }
/*  62 */     return Long.parseLong(sb.toString());
/*     */   }
/*     */ 
/*     */   public static String long2asc(long number)
/*     */   {
/*  71 */     StringBuilder sb = new StringBuilder(14);
/*  72 */     char[] ch = String.valueOf(number).toCharArray();
/*  73 */     if (ch[4] == '9')
/*     */     {
/*  75 */       sb.append((char)Integer.parseInt(String.valueOf(ch, 0, 2)));
/*  76 */       sb.append((char)Integer.parseInt(String.valueOf(ch, 2, 2)));
/*     */ 
/*  78 */       if ((ch[5] == '7') && (ch[6] == '0')) {
/*  79 */         sb.append("SZ");
/*     */       }
/*  81 */       else if ((ch[5] == '7') && (ch[6] == '1')) {
/*  82 */         sb.append("MM");
/*     */       }
/*  84 */       else if ((ch[5] == '7') && (ch[6] == '2')) {
/*  85 */         sb.append("MZ");
/*     */       }
/*     */       else {
/*  88 */         sb.append(String.valueOf(ch, 5, 2));
/*     */       }
/*     */ 
/*  91 */       if (ch[7] == '9') {
/*  92 */         sb.append("J");
/*     */       }
/*     */       else {
/*  95 */         sb.append(ch[7]);
/*     */       }
/*     */ 
/*  98 */       sb.append(ch, 8, 6);
/*     */ 
/* 100 */       sb.append("AAA");
/*     */     }
/*     */     else
/*     */     {
/* 104 */       sb.append((char)Integer.parseInt(String.valueOf(ch, 0, 2)));
/* 105 */       sb.append((char)Integer.parseInt(String.valueOf(ch, 2, 2)));
/*     */ 
/* 107 */       int xx = Integer.parseInt(String.valueOf(ch, 4, 2));
/* 108 */       int yy = xx / 12 + 5;
/* 109 */       int mm = xx % 12 + 1;
/*     */ 
/* 111 */       if (yy > 9) {
/* 112 */         sb.append(yy);
/*     */       }
/*     */       else {
/* 115 */         sb.append("0" + yy);
/*     */       }
/*     */ 
/* 118 */       if (mm > 9) {
/* 119 */         sb.append(mm);
/*     */       }
/*     */       else {
/* 122 */         sb.append("0" + mm);
/*     */       }
/*     */ 
/* 125 */       sb.append(ch, 6, 8);
/*     */     }
/* 127 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 133 */     long a = asc2long("NU060402589331");
/* 134 */     System.out.println(a);
/* 135 */     String b = long2asc(a);
/* 136 */     System.out.println(b);
/*     */ 
/* 138 */     long start = System.currentTimeMillis();
/* 139 */     for (int i = 0; i < 2000000; ++i) {
/* 140 */       asc2long(b);
/*     */     }
/* 142 */     System.out.println("Time cost:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.IDTransform
 * JD-Core Version:    0.5.4
 */