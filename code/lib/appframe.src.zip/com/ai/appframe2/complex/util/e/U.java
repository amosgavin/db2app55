/*    */ package com.ai.appframe2.complex.util.e;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public final class U
/*    */ {
/*    */   private static boolean isContainChinese(String str)
/*    */     throws Exception
/*    */   {
/* 27 */     boolean rtn = false;
/* 28 */     int byteLength = str.getBytes().length;
/* 29 */     int strLength = str.length();
/* 30 */     if (byteLength != strLength) {
/* 31 */       rtn = true;
/*    */     }
/* 33 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static String e(String a)
/*    */     throws Exception
/*    */   {
/* 43 */     if (StringUtils.isBlank(a))
/*    */     {
/* 45 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.blank_plaintext"));
/*    */     }
/* 47 */     if (isContainChinese(a))
/*    */     {
/* 49 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.util.chinese_forbid"));
/*    */     }
/* 51 */     char[] ch = a.toCharArray();
/* 52 */     StringBuilder sb = new StringBuilder();
/* 53 */     for (int i = 1; i <= ch.length; ++i) {
/* 54 */       int tmp = ch[(i - 1)];
/* 55 */       tmp = tmp * i + ch.length;
/* 56 */       tmp %= 96;
/* 57 */       tmp = (tmp + 32) % 128;
/* 58 */       sb.append((char)tmp);
/*    */     }
/* 60 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 64 */     long start = System.currentTimeMillis();
/*    */ 
/* 66 */     String a = "111111";
/* 67 */     System.out.println(e(a));
/*    */ 
/* 70 */     String b = "9221138800500107";
/* 71 */     System.out.println(e(b));
/*    */ 
/* 75 */     System.out.println("Time spent:" + (System.currentTimeMillis() - start) + ":ms");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.e.U
 * JD-Core Version:    0.5.4
 */