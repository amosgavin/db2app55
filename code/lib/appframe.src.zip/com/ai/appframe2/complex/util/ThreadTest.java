/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Hashtable;
/*    */ 
/*    */ public class ThreadTest extends Thread
/*    */ {
/*  7 */   private static Hashtable map = new Hashtable(200000);
/*    */ 
/*    */   public void run()
/*    */   {
/* 12 */     long start = System.currentTimeMillis();
/*    */ 
/* 14 */     for (int i = 0; i < 10000; ++i) {
/* 15 */       String a = UUID.getID();
/* 16 */       String b = (String)map.put(a, a);
/* 17 */       if (b != null) {
/* 18 */         System.out.println(b);
/*    */       }
/*    */     }
/* 21 */     System.out.println("Time cost:" + (System.currentTimeMillis() - start) + ":ms");
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 26 */     for (int i = 0; i < 30; ++i) {
/* 27 */       ThreadTest a = new ThreadTest();
/* 28 */       a.start();
/*    */     }
/*    */ 
/* 31 */     Thread.currentThread(); Thread.sleep(5000L);
/*    */ 
/* 33 */     for (int i = 0; i < 10000; ++i) {
/* 34 */       System.out.println(map.size());
/* 35 */       Thread.currentThread(); Thread.sleep(1000L);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.ThreadTest
 * JD-Core Version:    0.5.4
 */