/*    */ package com.ai.appframe2.complex.util;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class TxUtil
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(TxUtil.class);
/* 20 */   private static Boolean INIT_LOCK = Boolean.TRUE;
/*    */ 
/* 22 */   private static Integer GLOBAL_QUERY_TIMEOUT_SECOND = null;
/*    */ 
/*    */   public static int getQueryTimeOut()
/*    */     throws Exception
/*    */   {
/* 33 */     if (RuntimeServerUtil.isRunOnAppServer()) {
/* 34 */       if (GLOBAL_QUERY_TIMEOUT_SECOND == null) {
/* 35 */         synchronized (INIT_LOCK) {
/* 36 */           if (GLOBAL_QUERY_TIMEOUT_SECOND == null) {
/*    */             try {
/* 38 */               String strQueryTimeoutSecond = AIConfigManager.getConfigItem("appframe.appserver.jdbc.query_timeout_second");
/* 39 */               if ((!StringUtils.isBlank(strQueryTimeoutSecond)) && (StringUtils.isNumeric(strQueryTimeoutSecond))) {
/* 40 */                 GLOBAL_QUERY_TIMEOUT_SECOND = new Integer(strQueryTimeoutSecond);
/*    */               }
/*    */               else
/* 43 */                 GLOBAL_QUERY_TIMEOUT_SECOND = new Integer(0);
/*    */             }
/*    */             catch (Throwable ex)
/*    */             {
/* 47 */               GLOBAL_QUERY_TIMEOUT_SECOND = new Integer(0);
/* 48 */               log.error("set global query timeout secon error:", ex);
/*    */             }
/*    */ 
/* 51 */             log.error("run on appserver,global query timeout second:" + GLOBAL_QUERY_TIMEOUT_SECOND.intValue());
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     else {
/* 57 */       GLOBAL_QUERY_TIMEOUT_SECOND = new Integer(0);
/*    */     }
/*    */ 
/* 60 */     return GLOBAL_QUERY_TIMEOUT_SECOND.intValue();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.TxUtil
 * JD-Core Version:    0.5.4
 */