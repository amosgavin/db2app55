/*    */ package com.ai.appframe2.complex.util.collection.asyn.test;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.collection.asyn.AsynContainer;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class Test
/*    */ {
/*    */   public static void main2(String[] args)
/*    */     throws Exception
/*    */   {
/*  9 */     AsynContainer objAsynContainer = new AsynContainer(5L, 2000L, TestFlushWorkTask.class);
/* 10 */     for (int i = 0; i < 10000; ++i) {
/* 11 */       objAsynContainer.insert(":" + i);
/*    */     }
/* 13 */     Thread.currentThread(); Thread.sleep(100000L);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 17 */     long a = 9223372036854775807L;
/* 18 */     a += 1L;
/* 19 */     System.out.println(a);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.util.collection.asyn.test.Test
 * JD-Core Version:    0.5.4
 */