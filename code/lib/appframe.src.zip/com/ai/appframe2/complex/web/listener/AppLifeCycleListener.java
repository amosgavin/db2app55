/*    */ package com.ai.appframe2.complex.web.listener;
/*    */ 
/*    */ import com.ai.appframe2.complex.Startup;
/*    */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*    */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*    */ import com.ai.appframe2.complex.mbean.MBeanRegistryFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ import javax.servlet.ServletContextListener;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class AppLifeCycleListener
/*    */   implements ServletContextListener
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(AppLifeCycleListener.class);
/*    */ 
/*    */   public void contextInitialized(ServletContextEvent servletContextEvent)
/*    */   {
/*    */     try
/*    */     {
/* 34 */       DataSourceFactory.getDataSource().start();
/* 35 */       if (log.isInfoEnabled())
/* 36 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_start_succeed"));
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 40 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_start_failed"), ex);
/*    */     }
/*    */     try
/*    */     {
/* 44 */       MBeanRegistryFactory.registry();
/*    */ 
/* 46 */       if (log.isInfoEnabled())
/* 47 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_registmbean_succeed"));
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 51 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_registmbean_failed"), ex);
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 58 */       Startup.startup();
/*    */ 
/* 60 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_preboot_succeed"));
/*    */     }
/*    */     catch (Throwable ex) {
/* 63 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_preboot_failed"), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent servletContextEvent)
/*    */   {
/*    */     try
/*    */     {
/* 75 */       DataSourceFactory.getDataSource().stop();
/* 76 */       if (log.isInfoEnabled())
/* 77 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_close_succeed"));
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 81 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_close_failed"), ex);
/*    */     }
/*    */     try
/*    */     {
/* 85 */       MBeanRegistryFactory.unregistry();
/*    */ 
/* 87 */       if (log.isInfoEnabled())
/* 88 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_removembean_succeed"));
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 92 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.web.listener.AppLifeCycleListener.contextInitialized_removembean_failed"), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.web.listener.AppLifeCycleListener
 * JD-Core Version:    0.5.4
 */