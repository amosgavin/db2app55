/*     */ package com.ai.appframe2.complex.trace.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.trace.ITrace;
/*     */ import com.ai.appframe2.complex.trace.PtmtParam;
/*     */ import com.ai.appframe2.complex.trace.TraceUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class JdbcTrace
/*     */   implements ITrace
/*     */ {
/*  22 */   private long createTime = 0L;
/*  23 */   private String username = null;
/*  24 */   private String sql = null;
/*  25 */   private String type = null;
/*     */ 
/*  27 */   private int useTime = 0;
/*     */ 
/*  29 */   private Map parameter = null;
/*     */ 
/*     */   public String toXml()
/*     */   {
/*  39 */     StringBuilder sb = new StringBuilder();
/*  40 */     sb.append("<jdbc id=\"" + TraceUtil.getTraceId() + "\" time=\"" + ITrace.DATE_FORMAT.format(new Date(this.createTime)) + "\">");
/*  41 */     sb.append("<u>" + getUsername() + "</u>");
/*  42 */     sb.append("<sql><![CDATA[" + getSql() + "]]></sql>");
/*  43 */     sb.append("<t>" + getType() + "</t>");
/*     */ 
/*  45 */     if (this.parameter != null) {
/*  46 */       sb.append("<in>");
/*  47 */       Set keys = this.parameter.keySet();
/*  48 */       int i = 1;
/*  49 */       for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/*  50 */         Integer item = (Integer)iter.next();
/*     */ 
/*  52 */         List list = (List)this.parameter.get(item);
/*  53 */         String type = null;
/*  54 */         List tmp = new ArrayList();
/*  55 */         for (Iterator iter2 = list.iterator(); iter2.hasNext(); ) {
/*  56 */           PtmtParam item2 = (PtmtParam)iter2.next();
/*  57 */           tmp.add(item2.value);
/*  58 */           type = item2.type;
/*     */         }
/*     */ 
/*  61 */         if (type.equalsIgnoreCase("String")) {
/*  62 */           sb.append("<p s=\"" + i + "\" t=\"" + type + "\"><![CDATA[" + StringUtils.join(tmp.iterator(), "|") + "]]></p>");
/*     */         }
/*     */         else {
/*  65 */           sb.append("<p s=\"" + i + "\" t=\"" + type + "\" v=\"" + StringUtils.join(tmp.iterator(), "|") + "\"/>");
/*     */         }
/*  67 */         ++i;
/*     */       }
/*  69 */       sb.append("</in>");
/*     */     }
/*  71 */     sb.append("<et>" + getUseTime() + "</et>");
/*     */ 
/*  74 */     sb.append("</jdbc>");
/*     */ 
/*  76 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public long getCreateTime()
/*     */   {
/*  81 */     return this.createTime;
/*     */   }
/*     */ 
/*     */   public int getUseTime() {
/*  85 */     return this.useTime;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(long createTime)
/*     */   {
/*  90 */     this.createTime = createTime;
/*     */   }
/*     */   public void setUseTime(int useTime) {
/*  93 */     this.useTime = useTime;
/*     */   }
/*     */ 
/*     */   public void addChild(ITrace objITrace)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getSql()
/*     */   {
/* 106 */     return this.sql;
/*     */   }
/*     */   public void setSql(String sql) {
/* 109 */     this.sql = sql;
/*     */   }
/*     */   public String getUsername() {
/* 112 */     return this.username;
/*     */   }
/*     */   public void setUsername(String username) {
/* 115 */     this.username = username;
/*     */   }
/*     */   public Map getParameter() {
/* 118 */     return this.parameter;
/*     */   }
/*     */   public void setParameter(Map parameter) {
/* 121 */     this.parameter = parameter;
/*     */   }
/*     */   public String getType() {
/* 124 */     return this.type;
/*     */   }
/*     */   public void setType(String type) {
/* 127 */     this.type = type;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.impl.JdbcTrace
 * JD-Core Version:    0.5.4
 */