/*     */ package com.ai.appframe2.complex.trace;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.standard.trace.AppTraceMonitor;
/*     */ import com.ai.appframe2.complex.secframe.ICenterUserInfo;
/*     */ import com.ai.appframe2.complex.trace.impl.AppTrace;
/*     */ import com.ai.appframe2.complex.trace.impl.WebTrace;
/*     */ import com.ai.appframe2.complex.util.UUID;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class TraceFactory
/*     */ {
/*  26 */   private static transient Log log = LogFactory.getLog(TraceFactory.class);
/*     */ 
/*  29 */   private static final ThreadLocal TRACE_SWIFT = new ThreadLocal();
/*     */ 
/*  32 */   private static final ThreadLocal TRACE_STACK = new ThreadLocal();
/*     */ 
/*     */   public static boolean decideAppTrace(UserInfoInterface objUserInfoInterface, String className, String methodName)
/*     */   {
/*  45 */     boolean isNeedEnableTrace = false;
/*  46 */     WebTrace objWebTrace = null;
/*     */ 
/*  49 */     if ((objUserInfoInterface != null) && (objUserInfoInterface instanceof ICenterUserInfo)) {
/*  50 */       ICenterUserInfo userInfo = (ICenterUserInfo)objUserInfoInterface;
/*  51 */       if (userInfo.isTrace()) {
/*  52 */         isNeedEnableTrace = true;
/*  53 */         objWebTrace = userInfo.getWebTrace();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  58 */     if ((!isNeedEnableTrace) && (AppTraceMonitor.isEnableGlobalTrace()))
/*     */     {
/*  60 */       if ((objUserInfoInterface != null) && (objUserInfoInterface.getCode() != null) && (objUserInfoInterface.getCode().equals(AppTraceMonitor._getCode()))) {
/*  61 */         isNeedEnableTrace = true;
/*     */ 
/*  64 */         if (AppTraceMonitor._getClassName() != null) {
/*  65 */           if (className.indexOf(AppTraceMonitor._getClassName()) != -1) {
/*  66 */             isNeedEnableTrace = true;
/*     */           }
/*     */           else {
/*  69 */             isNeedEnableTrace = false;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  74 */         if (AppTraceMonitor._getMethodName() != null) {
/*  75 */           if (methodName.indexOf(AppTraceMonitor._getMethodName()) != -1) {
/*  76 */             isNeedEnableTrace = true;
/*     */           }
/*     */           else {
/*  79 */             isNeedEnableTrace = false;
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/*  85 */         isNeedEnableTrace = false;
/*     */       }
/*     */     }
/*     */ 
/*  89 */     if (isNeedEnableTrace) {
/*  90 */       disableTrace();
/*  91 */       enableTrace();
/*  92 */       if (objWebTrace != null) {
/*  93 */         addTraceInfo(objWebTrace);
/*     */       }
/*     */     }
/*     */ 
/*  97 */     return isNeedEnableTrace;
/*     */   }
/*     */ 
/*     */   public static boolean isEnableTrace()
/*     */   {
/* 105 */     boolean rtn = false;
/* 106 */     Boolean swift = (Boolean)TRACE_SWIFT.get();
/* 107 */     if ((swift != null) && (swift.equals(Boolean.TRUE))) {
/* 108 */       rtn = true;
/*     */     }
/* 110 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static void enableTrace()
/*     */   {
/* 117 */     TRACE_SWIFT.set(Boolean.TRUE);
/*     */ 
/* 119 */     Stack stack = new Stack();
/* 120 */     stack.push(new AppTrace());
/* 121 */     TRACE_STACK.set(stack);
/*     */   }
/*     */ 
/*     */   public static void disableTrace()
/*     */   {
/* 129 */     TRACE_SWIFT.set(null);
/*     */ 
/* 132 */     Stack stack = (Stack)TRACE_STACK.get();
/* 133 */     if (stack != null) {
/* 134 */       stack.clear();
/* 135 */       stack = null;
/*     */     }
/* 137 */     TRACE_STACK.set(null);
/*     */   }
/*     */ 
/*     */   public static void addTraceInfo(ITrace objITrace)
/*     */   {
/* 145 */     ITrace level = getCurrentTraceLevel();
/* 146 */     level.addChild(objITrace);
/*     */   }
/*     */ 
/*     */   public static void pushTraceLevel(ITrace objITrace)
/*     */   {
/* 155 */     Stack stack = (Stack)TRACE_STACK.get();
/* 156 */     stack.push(objITrace);
/*     */   }
/*     */ 
/*     */   public static void popTraceLevel()
/*     */   {
/* 163 */     Stack stack = (Stack)TRACE_STACK.get();
/* 164 */     stack.pop();
/*     */   }
/*     */ 
/*     */   private static ITrace getCurrentTraceLevel()
/*     */   {
/* 172 */     Stack stack = (Stack)TRACE_STACK.get();
/* 173 */     return (ITrace)stack.peek();
/*     */   }
/*     */ 
/*     */   public static String getTraceTreeInfo()
/*     */   {
/* 181 */     Stack stack = (Stack)TRACE_STACK.get();
/* 182 */     if (stack != null) {
/* 183 */       ITrace objITrace = (ITrace)stack.pop();
/* 184 */       return objITrace.toXml();
/*     */     }
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */   public static void writeTraceFile()
/*     */   {
/* 193 */     long useTime = -1L;
/* 194 */     ITrace topITrace = getCurrentTraceLevel();
/* 195 */     if (topITrace instanceof AppTrace) {
/* 196 */       useTime = System.currentTimeMillis() - ((AppTrace)topITrace).getStartTime();
/*     */     }
/*     */ 
/* 199 */     String traceInfo = null;
/*     */     try {
/* 201 */       traceInfo = getTraceTreeInfo();
/* 202 */       if (traceInfo != null) {
/* 203 */         File f = null;
/* 204 */         if (useTime >= 0L) {
/* 205 */           f = new File("AI_" + useTime + "_" + UUID.getID() + ".trc");
/*     */         }
/*     */         else {
/* 208 */           f = new File("AI_" + UUID.getID() + ".trc");
/*     */         }
/* 210 */         FileUtils.writeStringToFile(f, traceInfo, "GBK");
/*     */ 
/* 212 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.trace.TraceFactory.writeTraceFile_succeed", new String[] { f.getAbsolutePath() }));
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 217 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.trace.TraceFactory.writeTraceFile_failed"), ex);
/* 218 */       if (traceInfo != null)
/* 219 */         System.out.println(traceInfo);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.TraceFactory
 * JD-Core Version:    0.5.4
 */