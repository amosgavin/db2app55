/*     */ package com.ai.appframe2.complex.trace.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.trace.ITrace;
/*     */ import com.ai.appframe2.complex.trace.TraceUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DaoTrace
/*     */   implements ITrace
/*     */ {
/*  20 */   private long createTime = 0L;
/*  21 */   private String className = null;
/*  22 */   private String methodName = null;
/*     */ 
/*  24 */   private String center = null;
/*  25 */   private boolean success = false;
/*  26 */   private int useTime = 0;
/*     */ 
/*  28 */   private List child = new ArrayList();
/*     */ 
/*     */   public String toXml()
/*     */   {
/*  38 */     StringBuilder sb = new StringBuilder();
/*  39 */     sb.append("<dao id=\"" + TraceUtil.getTraceId() + "\" time=\"" + ITrace.DATE_FORMAT.format(new Date(this.createTime)) + "\">");
/*  40 */     sb.append("<cn>" + getClassName() + "</cn>");
/*  41 */     sb.append("<mn>" + getMethodName() + "</mn>");
/*     */ 
/*  43 */     sb.append("<cen>" + getCenter() + "</cen>");
/*  44 */     if (isSuccess()) {
/*  45 */       sb.append("<s>1</s>");
/*     */     }
/*     */     else {
/*  48 */       sb.append("<s>0</s>");
/*     */     }
/*  50 */     sb.append("<et>" + getUseTime() + "</et>");
/*     */ 
/*  52 */     for (Iterator iter = this.child.iterator(); iter.hasNext(); ) {
/*  53 */       ITrace item = (ITrace)iter.next();
/*  54 */       sb.append(item.toXml());
/*     */     }
/*     */ 
/*  57 */     sb.append("</dao>");
/*     */ 
/*  59 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getCenter()
/*     */   {
/*  64 */     return this.center;
/*     */   }
/*     */   public String getClassName() {
/*  67 */     return this.className;
/*     */   }
/*     */ 
/*     */   public long getCreateTime() {
/*  71 */     return this.createTime;
/*     */   }
/*     */   public String getMethodName() {
/*  74 */     return this.methodName;
/*     */   }
/*     */   public boolean isSuccess() {
/*  77 */     return this.success;
/*     */   }
/*     */   public int getUseTime() {
/*  80 */     return this.useTime;
/*     */   }
/*     */ 
/*     */   public void setCenter(String center) {
/*  84 */     this.center = center;
/*     */   }
/*     */   public void setClassName(String className) {
/*  87 */     this.className = className;
/*     */   }
/*     */ 
/*     */   public void setCreateTime(long createTime) {
/*  91 */     this.createTime = createTime;
/*     */   }
/*     */   public void setMethodName(String methodName) {
/*  94 */     this.methodName = methodName;
/*     */   }
/*     */   public void setSuccess(boolean success) {
/*  97 */     this.success = success;
/*     */   }
/*     */   public void setUseTime(int useTime) {
/* 100 */     this.useTime = useTime;
/*     */   }
/*     */ 
/*     */   public void addChild(ITrace objITrace)
/*     */   {
/* 109 */     this.child.add(objITrace);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.impl.DaoTrace
 * JD-Core Version:    0.5.4
 */