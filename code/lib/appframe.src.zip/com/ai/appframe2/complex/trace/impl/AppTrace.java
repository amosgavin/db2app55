/*    */ package com.ai.appframe2.complex.trace.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.trace.ITrace;
/*    */ import com.ai.appframe2.complex.trace.TraceUtil;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Date;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AppTrace
/*    */   implements ITrace
/*    */ {
/* 21 */   private long startTime = System.currentTimeMillis();
/* 22 */   private List child = new ArrayList();
/*    */ 
/*    */   public long getStartTime()
/*    */   {
/* 32 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public void addChild(ITrace objITrace)
/*    */   {
/* 40 */     this.child.add(objITrace);
/*    */   }
/*    */ 
/*    */   public String toXml()
/*    */   {
/* 50 */     StringBuilder sb = new StringBuilder();
/* 51 */     sb.append("<?xml version=\"1.0\" encoding=\"GBK\"?>");
/* 52 */     sb.append("<app id=\"" + TraceUtil.getTraceId() + "\" time=\"" + ITrace.DATE_FORMAT.format(new Date(System.currentTimeMillis())) + "\">");
/* 53 */     for (Iterator iter = this.child.iterator(); iter.hasNext(); ) {
/* 54 */       ITrace item = (ITrace)iter.next();
/* 55 */       sb.append(item.toXml());
/*    */     }
/* 57 */     sb.append("</app>");
/* 58 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.impl.AppTrace
 * JD-Core Version:    0.5.4
 */