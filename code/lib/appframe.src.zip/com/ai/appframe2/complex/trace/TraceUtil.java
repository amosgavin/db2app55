/*     */ package com.ai.appframe2.complex.trace;
/*     */ 
/*     */ import com.ai.appframe2.bo.DataContainer;
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import com.thoughtworks.xstream.io.xml.DomDriver;
/*     */ import java.lang.reflect.Array;
/*     */ import org.apache.commons.lang.ClassUtils;
/*     */ 
/*     */ public final class TraceUtil
/*     */ {
/*  24 */   private static long TRACE_ID = 0L;
/*  25 */   private static XStream STREAM = new XStream(new DomDriver());
/*     */ 
/*     */   public static synchronized long getTraceId()
/*     */   {
/*  31 */     return ++TRACE_ID;
/*     */   }
/*     */ 
/*     */   public static String object2xml(Object objects) {
/*  35 */     StringBuilder sb = new StringBuilder();
/*  36 */     if (objects.getClass().isArray()) {
/*  37 */       if (ClassUtils.isAssignable(objects.getClass().getComponentType(), DataContainer.class)) {
/*  38 */         int len = Array.getLength(objects);
/*  39 */         sb.append("<p s=\"1\">");
/*  40 */         for (int j = 0; j < len; ++j) {
/*  41 */           Object tmp2 = Array.get(objects, j);
/*  42 */           if (tmp2 == null) {
/*  43 */             sb.append("<![CDATA[" + null + "]]>");
/*     */           }
/*     */           else {
/*  46 */             sb.append("<![CDATA[" + tmp2.toString() + "]]>");
/*     */           }
/*     */         }
/*  49 */         sb.append("</p>");
/*     */       }
/*     */       else {
/*  52 */         sb.append("<p s=\"1\"><![CDATA[" + STREAM.toXML(objects) + "]]></p>");
/*     */       }
/*     */     }
/*  55 */     else if (objects instanceof DataContainer) {
/*  56 */       sb.append("<p s=\"1\"><![CDATA[" + objects.toString() + "]]></p>");
/*     */     }
/*     */     else {
/*  59 */       sb.append("<p s=\"1\"><![CDATA[" + STREAM.toXML(objects) + "]]></p>");
/*     */     }
/*     */ 
/*  62 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String object2xml(Object[] objects) {
/*  66 */     StringBuilder sb = new StringBuilder();
/*  67 */     if ((objects != null) && (objects.length > 0)) {
/*  68 */       for (int i = 0; i < objects.length; ++i) {
/*  69 */         if (objects[i] == null) {
/*  70 */           sb.append("<p s=\"" + (i + 1) + "\"><![CDATA[null]]></p>");
/*     */         }
/*  74 */         else if (objects[i].getClass().isArray()) {
/*  75 */           if (ClassUtils.isAssignable(objects[i].getClass().getComponentType(), DataContainer.class)) {
/*  76 */             int len = Array.getLength(objects[i]);
/*  77 */             sb.append("<p s=\"" + (i + 1) + "\">");
/*  78 */             for (int j = 0; j < len; ++j) {
/*  79 */               Object tmp2 = Array.get(objects[i], j);
/*  80 */               if (tmp2 == null) {
/*  81 */                 sb.append("<![CDATA[" + null + "]]>");
/*     */               }
/*     */               else {
/*  84 */                 sb.append("<![CDATA[" + tmp2.toString() + "]]>");
/*     */               }
/*     */             }
/*  87 */             sb.append("</p>");
/*     */           }
/*     */           else {
/*  90 */             sb.append("<p s=\"" + (i + 1) + "\"><![CDATA[" + STREAM.toXML(objects[i]) + "]]></p>");
/*     */           }
/*     */         }
/*  93 */         else if (objects[i] instanceof DataContainer) {
/*  94 */           sb.append("<p s=\"" + (i + 1) + "\"><![CDATA[" + objects[i].toString() + "]]></p>");
/*     */         }
/*     */         else {
/*  97 */           sb.append("<p s=\"" + (i + 1) + "\"><![CDATA[" + STREAM.toXML(objects[i]) + "]]></p>");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 102 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.TraceUtil
 * JD-Core Version:    0.5.4
 */