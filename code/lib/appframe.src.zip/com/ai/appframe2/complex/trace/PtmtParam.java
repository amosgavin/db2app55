/*    */ package com.ai.appframe2.complex.trace;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PtmtParam
/*    */   implements Serializable
/*    */ {
/* 16 */   public String type = null;
/* 17 */   public String value = null;
/*    */ 
/* 19 */   public PtmtParam(String type, String value) { this.type = type;
/* 20 */     this.value = value; }
/*    */ 
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.PtmtParam
 * JD-Core Version:    0.5.4
 */