/*     */ package com.ai.appframe2.complex.trace.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.trace.ITrace;
/*     */ import com.ai.appframe2.complex.trace.TraceUtil;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class SvrTrace
/*     */   implements ITrace
/*     */ {
/*  20 */   private long createTime = 0L;
/*  21 */   private String className = null;
/*  22 */   private String methodName = null;
/*     */ 
/*  24 */   private String appIp = null;
/*  25 */   private String appServerName = null;
/*  26 */   private String center = null;
/*  27 */   private String code = null;
/*  28 */   private boolean success = false;
/*  29 */   private int useTime = 0;
/*     */ 
/*  31 */   private Object[] in = null;
/*     */ 
/*  33 */   private List child = new ArrayList();
/*     */ 
/*     */   public String toXml()
/*     */   {
/*  43 */     StringBuilder sb = new StringBuilder();
/*  44 */     sb.append("<srv id=\"" + TraceUtil.getTraceId() + "\" time=\"" + ITrace.DATE_FORMAT.format(new Date(this.createTime)) + "\">");
/*  45 */     sb.append("<cn>" + getClassName() + "</cn>");
/*  46 */     sb.append("<mn>" + getMethodName() + "</mn>");
/*     */ 
/*  48 */     if ((this.in != null) && (this.in.length > 0)) {
/*  49 */       sb.append("<in>" + TraceUtil.object2xml(this.in) + "</in>");
/*     */     }
/*     */ 
/*  52 */     sb.append("<ai>" + this.appIp + "</ai>");
/*  53 */     sb.append("<sn>" + this.appServerName + "</sn>");
/*  54 */     sb.append("<cen>" + getCenter() + "</cen>");
/*  55 */     sb.append("<code>" + getCode() + "</code>");
/*  56 */     if (isSuccess()) {
/*  57 */       sb.append("<s>1</s>");
/*     */     }
/*     */     else {
/*  60 */       sb.append("<s>0</s>");
/*     */     }
/*  62 */     sb.append("<et>" + getUseTime() + "</et>");
/*     */ 
/*  64 */     for (Iterator iter = this.child.iterator(); iter.hasNext(); ) {
/*  65 */       ITrace item = (ITrace)iter.next();
/*  66 */       sb.append(item.toXml());
/*     */     }
/*     */ 
/*  69 */     sb.append("</srv>");
/*     */ 
/*  71 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String getAppIp() {
/*  75 */     return this.appIp;
/*     */   }
/*     */   public String getAppServerName() {
/*  78 */     return this.appServerName;
/*     */   }
/*     */   public String getCenter() {
/*  81 */     return this.center;
/*     */   }
/*     */   public String getClassName() {
/*  84 */     return this.className;
/*     */   }
/*     */   public String getCode() {
/*  87 */     return this.code;
/*     */   }
/*     */   public long getCreateTime() {
/*  90 */     return this.createTime;
/*     */   }
/*     */   public String getMethodName() {
/*  93 */     return this.methodName;
/*     */   }
/*     */   public boolean isSuccess() {
/*  96 */     return this.success;
/*     */   }
/*     */   public int getUseTime() {
/*  99 */     return this.useTime;
/*     */   }
/*     */   public void setAppIp(String appIp) {
/* 102 */     this.appIp = appIp;
/*     */   }
/*     */   public void setAppServerName(String appServerName) {
/* 105 */     this.appServerName = appServerName;
/*     */   }
/*     */   public void setCenter(String center) {
/* 108 */     this.center = center;
/*     */   }
/*     */   public void setClassName(String className) {
/* 111 */     this.className = className;
/*     */   }
/*     */   public void setCode(String code) {
/* 114 */     this.code = code;
/*     */   }
/*     */   public void setCreateTime(long createTime) {
/* 117 */     this.createTime = createTime;
/*     */   }
/*     */   public void setMethodName(String methodName) {
/* 120 */     this.methodName = methodName;
/*     */   }
/*     */   public void setSuccess(boolean success) {
/* 123 */     this.success = success;
/*     */   }
/*     */   public void setUseTime(int useTime) {
/* 126 */     this.useTime = useTime;
/*     */   }
/*     */   public Object[] getIn() {
/* 129 */     return this.in;
/*     */   }
/*     */   public void setIn(Object[] in) {
/* 132 */     this.in = in;
/*     */   }
/*     */ 
/*     */   public void addChild(ITrace objITrace)
/*     */   {
/* 140 */     this.child.add(objITrace);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.impl.SvrTrace
 * JD-Core Version:    0.5.4
 */