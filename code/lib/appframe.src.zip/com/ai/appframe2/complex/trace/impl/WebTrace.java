/*    */ package com.ai.appframe2.complex.trace.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.trace.ITrace;
/*    */ import com.ai.appframe2.complex.trace.TraceUtil;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class WebTrace
/*    */   implements ITrace
/*    */ {
/* 18 */   private long createTime = 0L;
/* 19 */   private String url = null;
/* 20 */   private String clientIp = null;
/* 21 */   private String serverIp = null;
/* 22 */   private String serverName = null;
/*    */ 
/* 24 */   private String code = null;
/*    */ 
/*    */   public String toXml()
/*    */   {
/* 35 */     StringBuilder sb = new StringBuilder();
/* 36 */     sb.append("<web id=\"" + TraceUtil.getTraceId() + "\" time=\"" + ITrace.DATE_FORMAT.format(new Date(this.createTime)) + "\">");
/* 37 */     sb.append("<url><![CDATA[" + getUrl() + "]]></url>");
/* 38 */     sb.append("<ci>" + getClientIp() + "</ci>");
/* 39 */     sb.append("<wi>" + getServerIp() + "</wi>");
/* 40 */     sb.append("<sn>" + getServerName() + "</sn>");
/*    */ 
/* 42 */     sb.append("<code>" + getCode() + "</code>");
/* 43 */     sb.append("</web>");
/*    */ 
/* 45 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public long getCreateTime()
/*    */   {
/* 51 */     return this.createTime;
/*    */   }
/*    */ 
/*    */   public void setCreateTime(long createTime)
/*    */   {
/* 57 */     this.createTime = createTime;
/*    */   }
/*    */ 
/*    */   public void addChild(ITrace objITrace)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getClientIp()
/*    */   {
/* 69 */     return this.clientIp;
/*    */   }
/*    */   public void setClientIp(String clientIp) {
/* 72 */     this.clientIp = clientIp;
/*    */   }
/*    */   public void setCode(String code) {
/* 75 */     this.code = code;
/*    */   }
/*    */   public String getCode() {
/* 78 */     return this.code;
/*    */   }
/*    */   public String getUrl() {
/* 81 */     return this.url;
/*    */   }
/*    */   public void setUrl(String url) {
/* 84 */     this.url = url;
/*    */   }
/*    */   public String getServerIp() {
/* 87 */     return this.serverIp;
/*    */   }
/*    */   public String getServerName() {
/* 90 */     return this.serverName;
/*    */   }
/*    */   public void setServerName(String serverName) {
/* 93 */     this.serverName = serverName;
/*    */   }
/*    */   public void setServerIp(String serverIp) {
/* 96 */     this.serverIp = serverIp;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.impl.WebTrace
 * JD-Core Version:    0.5.4
 */