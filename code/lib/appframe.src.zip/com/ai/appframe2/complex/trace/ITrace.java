/*    */ package com.ai.appframe2.complex.trace;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.text.SimpleDateFormat;
/*    */ 
/*    */ public abstract interface ITrace extends Serializable
/*    */ {
/* 16 */   public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
/*    */ 
/*    */   public abstract String toXml();
/*    */ 
/*    */   public abstract void addChild(ITrace paramITrace);
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.trace.ITrace
 * JD-Core Version:    0.5.4
 */