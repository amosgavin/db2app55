/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.Task;
/*    */ 
/*    */ public class WriteContextTask extends Task
/*    */ {
/*    */   private String fileName;
/*    */   private String context;
/*    */ 
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/*    */     try
/*    */     {
/* 29 */       if (StringUtils.isBlank(this.fileName))
/*    */       {
/* 32 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "fileName" }));
/*    */       }
/* 34 */       if (StringUtils.isBlank(this.context))
/*    */       {
/* 37 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "context" }));
/*    */       }
/*    */ 
/* 40 */       StringBuilder sb = new StringBuilder();
/* 41 */       sb.append(this.context);
/*    */ 
/* 43 */       PrintWriter pw = new PrintWriter(new FileOutputStream(this.fileName));
/* 44 */       pw.write(sb.toString());
/* 45 */       pw.flush();
/* 46 */       pw.close();
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 50 */       e.printStackTrace();
/*    */ 
/* 53 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.gen_file_error", new String[] { this.fileName }) + ": " + e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getFileName() {
/* 58 */     return this.fileName;
/*    */   }
/*    */   public void setFileName(String fileName) {
/* 61 */     this.fileName = fileName;
/*    */   }
/*    */   public String getContext() {
/* 64 */     return this.context;
/*    */   }
/*    */   public void setContext(String context) {
/* 67 */     this.context = context;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.WriteContextTask
 * JD-Core Version:    0.5.4
 */