/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.e.K;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.taskdefs.Property;
/*    */ 
/*    */ public class PropertiesRC2Task extends Property
/*    */ {
/*    */   protected void addProperty(String n, String v)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       v = K.k_s(v);
/*    */     }
/*    */     catch (Exception ex) {
/* 26 */       throw new BuildException("Error:", ex);
/*    */     }
/* 28 */     super.addProperty(n, v);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.PropertiesRC2Task
 * JD-Core Version:    0.5.4
 */