/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import java.util.Date;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.taskdefs.Echo;
/*    */ 
/*    */ public class Echo2 extends Echo
/*    */ {
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/* 21 */     super.log("Time:" + new Date());
/* 22 */     super.execute();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.Echo2
 * JD-Core Version:    0.5.4
 */