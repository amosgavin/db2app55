/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.complex.util.e.K;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Project;
/*     */ import org.apache.tools.ant.Task;
/*     */ import org.apache.tools.ant.taskdefs.optional.ssh.SSHExec;
/*     */ import org.apache.tools.ant.taskdefs.optional.ssh.Scp;
/*     */ 
/*     */ public class BatchBackupTask extends Task
/*     */ {
/*     */   private String hostFile;
/*     */   private String destDir;
/*     */ 
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/*  36 */     if (StringUtils.isBlank(this.hostFile))
/*     */     {
/*  39 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "hostFile" }));
/*     */     }
/*  41 */     if (StringUtils.isBlank(this.destDir))
/*     */     {
/*  44 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destDir" })); } 
/*     */ ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */     Properties prop;
/*     */     String dateStr;
/*     */     Iterator iter;
/*     */     try { Thread.currentThread().setContextClassLoader(BatchBackupTask.class.getClassLoader());
/*     */ 
/*  51 */       prop = new Properties();
/*  52 */       prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(this.hostFile));
/*     */ 
/*  54 */       HashMap map = new HashMap();
/*  55 */       Set set = prop.keySet();
/*  56 */       for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/*  57 */         String item = (String)iter.next();
/*  58 */         map.put(StringUtils.substringBefore(item, "."), null);
/*     */       }
/*     */ 
/*  62 */       Set objSet = map.keySet();
/*  63 */       DateFormat dateformat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
/*  64 */       dateStr = dateformat.format(new Date());
/*     */ 
/*  66 */       for (iter = objSet.iterator(); iter.hasNext(); ) {
/*  67 */         String item = (String)iter.next();
/*  68 */         String host = prop.getProperty(item + ".host");
/*  69 */         String port = prop.getProperty(item + ".port");
/*  70 */         String username = prop.getProperty(item + ".username");
/*  71 */         String password = prop.getProperty(item + ".password");
/*  72 */         String cmd = prop.getProperty(item + ".cmd");
/*  73 */         String deleteBackupFileCmd = prop.getProperty(item + ".deleteBackupFileCmd");
/*  74 */         String backupFile = prop.getProperty(item + ".backupFile");
/*     */ 
/*  76 */         String tmpip = StringUtils.replace(host, ".", "_");
/*  77 */         if (StringUtils.contains(cmd, "{Flag}")) {
/*  78 */           cmd = StringUtils.replace(cmd, "{Flag}", tmpip + "_" + dateStr);
/*     */         }
/*  80 */         if (StringUtils.contains(backupFile, "{Flag}")) {
/*  81 */           backupFile = StringUtils.replace(backupFile, "{Flag}", tmpip + "_" + dateStr);
/*     */         }
/*     */ 
/*  85 */         SSHExec objSsh = new SSHExec();
/*  86 */         objSsh.setProject(getProject());
/*  87 */         objSsh.setHost(host);
/*  88 */         objSsh.setPort(Integer.parseInt(port));
/*  89 */         objSsh.setUsername(username);
/*  90 */         objSsh.setPassword(K.k_s(password));
/*  91 */         objSsh.setTrust(true);
/*     */ 
/*  93 */         objSsh.setCommand(cmd);
/*  94 */         objSsh.execute();
/*     */ 
/*  97 */         Scp objSftpDownload = new Scp();
/*  98 */         objSftpDownload.setProject(getProject());
/*  99 */         objSftpDownload.setPort(Integer.parseInt(port));
/* 100 */         objSftpDownload.setPassword(K.k_s(password));
/* 101 */         objSftpDownload.setTrust(true);
/* 102 */         objSftpDownload.setFile(username + "@" + host + ":" + backupFile);
/* 103 */         objSftpDownload.setTodir(getProject().getBaseDir() + "/" + this.destDir);
/* 104 */         objSftpDownload.execute();
/*     */ 
/* 107 */         SSHExec objSsh2 = new SSHExec();
/* 108 */         objSsh2.setProject(getProject());
/* 109 */         objSsh2.setHost(host);
/* 110 */         objSsh2.setPort(Integer.parseInt(port));
/* 111 */         objSsh2.setUsername(username);
/* 112 */         objSsh2.setPassword(K.k_s(password));
/* 113 */         objSsh2.setTrust(true);
/*     */ 
/* 115 */         objSsh2.setCommand(deleteBackupFileCmd);
/* 116 */         objSsh2.execute();
/*     */ 
/* 118 */         System.out.println("Host:" + host + ",User:" + username + ",File:" + backupFile + " backup completed");
/*     */       }
/*     */  }
/*     */     catch (Throwable ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 127 */       if (old != null)
/* 128 */         Thread.currentThread().setContextClassLoader(old);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getHostFile()
/*     */   {
/* 134 */     return this.hostFile;
/*     */   }
/*     */   public void setHostFile(String hostFile) {
/* 137 */     this.hostFile = hostFile;
/*     */   }
/*     */   public String getDestDir() {
/* 140 */     return this.destDir;
/*     */   }
/*     */   public void setDestDir(String destDir) {
/* 143 */     this.destDir = destDir;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.BatchBackupTask
 * JD-Core Version:    0.5.4
 */