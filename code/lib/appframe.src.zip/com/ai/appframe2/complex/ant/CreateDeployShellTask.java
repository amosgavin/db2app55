/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.PrintWriter;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ 
/*     */ public class CreateDeployShellTask extends Task
/*     */ {
/*     */   private String destPath;
/*     */   private String remotePath;
/*     */   private String wasHome;
/*     */   private String host;
/*     */   private String port;
/*     */   private String username;
/*     */   private String password;
/*     */   private String earName;
/*     */   private String ear;
/*     */   private String cellName;
/*     */   private String clusterName;
/*     */ 
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/*  39 */     if (StringUtils.isBlank(this.destPath))
/*     */     {
/*  42 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destPath" }));
/*     */     }
/*  44 */     if (StringUtils.isBlank(this.remotePath))
/*     */     {
/*  47 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "remotePath" }));
/*     */     }
/*  49 */     if (StringUtils.isBlank(this.wasHome))
/*     */     {
/*  52 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "wasHome" }));
/*     */     }
/*  54 */     if (StringUtils.isBlank(this.host))
/*     */     {
/*  57 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "host" }));
/*     */     }
/*  59 */     if (StringUtils.isBlank(this.port))
/*     */     {
/*  62 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "port" }));
/*     */     }
/*  64 */     if (StringUtils.isBlank(this.username))
/*     */     {
/*  67 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "username" }));
/*     */     }
/*  69 */     if (StringUtils.isBlank(this.password))
/*     */     {
/*  72 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "password" }));
/*     */     }
/*  74 */     if (StringUtils.isBlank(this.earName))
/*     */     {
/*  77 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "earName" }));
/*     */     }
/*  79 */     if (StringUtils.isBlank(this.ear))
/*     */     {
/*  82 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "ear" }));
/*     */     }
/*  84 */     if (StringUtils.isBlank(this.cellName))
/*     */     {
/*  87 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "cellName" }));
/*     */     }
/*  89 */     if (StringUtils.isBlank(this.clusterName))
/*     */     {
/*  92 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "clusterName" }));
/*     */     }
/*     */ 
/*  95 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */     try {
/*  97 */       Thread.currentThread().setContextClassLoader(CreateDeployShellTask.class.getClassLoader());
/*  98 */       BufferedReader br = new BufferedReader(new FileReader(Thread.currentThread().getContextClassLoader().getResource("template/deploy.vm").getFile()));
/*     */ 
/* 100 */       String tmp = null;
/* 101 */       StringBuilder sb = new StringBuilder();
/*     */       while (true) {
/* 103 */         tmp = br.readLine();
/* 104 */         if (tmp == null) break;
/* 105 */         sb.append(tmp + "\n");
/*     */       }
/*     */ 
/* 112 */       String vm = sb.toString();
/* 113 */       vm = StringUtils.replace(vm, "${cluster.path}", this.remotePath);
/* 114 */       vm = StringUtils.replace(vm, "${was.appserver.home}", this.wasHome);
/* 115 */       vm = StringUtils.replace(vm, "${cluster.dmgr.ip}", this.host);
/* 116 */       vm = StringUtils.replace(vm, "${cluster.dmgr.port}", this.port);
/* 117 */       vm = StringUtils.replace(vm, "${cluster.dmgr.username}", this.username);
/* 118 */       vm = StringUtils.replace(vm, "${cluster.dmgr.password}", this.password);
/* 119 */       vm = StringUtils.replace(vm, "${ear_name}", this.earName);
/* 120 */       vm = StringUtils.replace(vm, "${ear}", this.ear);
/* 121 */       vm = StringUtils.replace(vm, "${cluster.cellname}", this.cellName);
/* 122 */       vm = StringUtils.replace(vm, "${cluster.clustername}", this.clusterName);
/*     */ 
/* 124 */       PrintWriter pw = new PrintWriter(new FileOutputStream(this.destPath));
/* 125 */       pw.write(vm);
/* 126 */       pw.flush();
/* 127 */       pw.close();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 135 */       if (old != null)
/* 136 */         Thread.currentThread().setContextClassLoader(old);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getDestPath()
/*     */   {
/* 143 */     return this.destPath;
/*     */   }
/*     */   public void setDestPath(String destPath) {
/* 146 */     this.destPath = destPath;
/*     */   }
/*     */   public String getRemotePath() {
/* 149 */     return this.remotePath;
/*     */   }
/*     */   public void setRemotePath(String remotePath) {
/* 152 */     this.remotePath = remotePath;
/*     */   }
/*     */   public String getWasHome() {
/* 155 */     return this.wasHome;
/*     */   }
/*     */   public void setWasHome(String wasHome) {
/* 158 */     this.wasHome = wasHome;
/*     */   }
/*     */   public String getHost() {
/* 161 */     return this.host;
/*     */   }
/*     */   public void setHost(String host) {
/* 164 */     this.host = host;
/*     */   }
/*     */   public String getPort() {
/* 167 */     return this.port;
/*     */   }
/*     */   public void setPort(String port) {
/* 170 */     this.port = port;
/*     */   }
/*     */   public String getUsername() {
/* 173 */     return this.username;
/*     */   }
/*     */   public void setUsername(String username) {
/* 176 */     this.username = username;
/*     */   }
/*     */   public String getPassword() {
/* 179 */     return this.password;
/*     */   }
/*     */   public void setPassword(String password) {
/* 182 */     this.password = password;
/*     */   }
/*     */   public String getEarName() {
/* 185 */     return this.earName;
/*     */   }
/*     */   public void setEarName(String earName) {
/* 188 */     this.earName = earName;
/*     */   }
/*     */   public String getEar() {
/* 191 */     return this.ear;
/*     */   }
/*     */   public void setEar(String ear) {
/* 194 */     this.ear = ear;
/*     */   }
/*     */   public String getCellName() {
/* 197 */     return this.cellName;
/*     */   }
/*     */   public void setCellName(String cellName) {
/* 200 */     this.cellName = cellName;
/*     */   }
/*     */   public String getClusterName() {
/* 203 */     return this.clusterName;
/*     */   }
/*     */   public void setClusterName(String clusterName) {
/* 206 */     this.clusterName = clusterName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CreateDeployShellTask
 * JD-Core Version:    0.5.4
 */