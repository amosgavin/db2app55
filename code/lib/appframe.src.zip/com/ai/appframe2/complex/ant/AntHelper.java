/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public final class AntHelper
/*     */ {
/*     */   public static String getComponentType(Class clazz)
/*     */     throws Exception
/*     */   {
/*  30 */     Class tmp = clazz;
/*  31 */     StringBuilder sb = new StringBuilder();
/*  32 */     while (clazz.isArray()) {
/*  33 */       if (tmp.getComponentType() == null) {
/*     */         break;
/*     */       }
/*     */ 
/*  37 */       sb.append("[]");
/*  38 */       tmp = tmp.getComponentType();
/*     */     }
/*     */ 
/*  41 */     String rtn = tmp.getName() + sb.toString();
/*  42 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static void writeJavaFile(String generatorDir, String pkgPrefix, String className, String context)
/*     */     throws Exception
/*     */   {
/*  52 */     PrintWriter pw = null;
/*     */     try {
/*  54 */       String fileName = generatorDir + "/" + StringUtils.replace(pkgPrefix, ".", "/") + "/" + getClassNameWithoutPkgByClass(className) + ".java";
/*  55 */       File p = new File(generatorDir + "/" + StringUtils.replace(pkgPrefix, ".", "/"));
/*     */       boolean s;
/*  56 */       if (!p.exists()) {
/*  57 */         s = p.mkdirs();
/*     */       }
/*  59 */       pw = new PrintWriter(new FileOutputStream(fileName));
/*  60 */       pw.write(context);
/*     */     }
/*     */     finally {
/*  63 */       if (pw != null) {
/*  64 */         pw.flush();
/*  65 */         pw.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getClassNameWithoutPkgByClass(Class clazz)
/*     */     throws Exception
/*     */   {
/*  78 */     String[] tmp = StringUtils.split(clazz.getName(), ".");
/*  79 */     return tmp[(tmp.length - 1)];
/*     */   }
/*     */ 
/*     */   public static String getClassNameWithoutPkgByClass(String clazzName) throws Exception {
/*  83 */     String[] tmp = StringUtils.split(clazzName, ".");
/*  84 */     return tmp[(tmp.length - 1)];
/*     */   }
/*     */ 
/*     */   public static Method[] getMethodWithSuperInterfaceMethod(Class clazz, String specialInterfaceName)
/*     */     throws Exception
/*     */   {
/*  95 */     Class[] interfaceClass = clazz.getInterfaces();
/*  96 */     Class tmpIn = null;
/*  97 */     for (int i = 0; i < interfaceClass.length; ++i) {
/*  98 */       if (StringUtils.contains(interfaceClass[i].getName(), specialInterfaceName)) {
/*  99 */         tmpIn = interfaceClass[i];
/* 100 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 104 */     return tmpIn.getMethods();
/*     */   }
/*     */ 
/*     */   public static String getModifyName(int mod)
/*     */   {
/* 113 */     StringBuilder sb = new StringBuilder();
/*     */ 
/* 116 */     if ((mod & 0x1) != 0) sb.append("public ");
/* 117 */     if ((mod & 0x4) != 0) sb.append("protected ");
/* 118 */     if ((mod & 0x2) != 0) sb.append("private ");
/*     */ 
/* 120 */     if ((mod & 0x10) != 0) sb.append("final ");
/*     */     int len;
/* 122 */     if ((len = sb.length()) > 0)
/* 123 */       return sb.toString().substring(0, len - 1);
/* 124 */     return "";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.AntHelper
 * JD-Core Version:    0.5.4
 */