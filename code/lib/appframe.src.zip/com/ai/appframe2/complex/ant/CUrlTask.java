/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
/*    */ import org.apache.commons.httpclient.HttpClient;
/*    */ import org.apache.commons.httpclient.methods.GetMethod;
/*    */ import org.apache.commons.httpclient.params.HttpMethodParams;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.Task;
/*    */ 
/*    */ public class CUrlTask extends Task
/*    */ {
/*    */   private String url;
/*    */ 
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/* 27 */     if (StringUtils.isBlank(this.url))
/*    */     {
/* 30 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "url" }));
/*    */     }
/*    */     try
/*    */     {
/* 34 */       HttpClient httpClient = new HttpClient();
/* 35 */       GetMethod getMethod = new GetMethod(this.url);
/* 36 */       getMethod.getParams().setParameter("http.method.retry-handler", new DefaultHttpMethodRetryHandler());
/*    */       try
/*    */       {
/* 39 */         int statusCode = httpClient.executeMethod(getMethod);
/* 40 */         if (statusCode != 200) {
/* 41 */           System.err.println("Method failed: " + getMethod.getStatusLine());
/*    */         }
/* 43 */         System.out.println(this.url + " status " + statusCode);
/*    */       }
/*    */       finally {
/* 46 */         getMethod.releaseConnection();
/*    */       }
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 51 */       ex.printStackTrace();
/* 52 */       throw new BuildException(ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 57 */     return this.url;
/*    */   }
/*    */   public void setUrl(String url) {
/* 60 */     this.url = url;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CUrlTask
 * JD-Core Version:    0.5.4
 */