/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.util.Date;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.Task;
/*    */ 
/*    */ public class VersionInfoTask extends Task
/*    */ {
/*    */   private String destFile;
/*    */   private String append;
/*    */ 
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/* 33 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*    */     try {
/* 35 */       Thread.currentThread().setContextClassLoader(VersionInfoTask.class.getClassLoader());
/* 36 */       if (StringUtils.isBlank(this.destFile))
/*    */       {
/* 39 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destPath" }));
/*    */       }
/*    */ 
/* 42 */       StringBuilder sb = new StringBuilder();
/*    */ 
/* 45 */       sb.append(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.compile_time") + ":" + new Date() + "\n");
/*    */ 
/* 47 */       if (!StringUtils.isBlank(this.append)) {
/* 48 */         sb.append(this.append + "\n");
/*    */       }
/*    */ 
/* 51 */       writeFile(this.destFile, sb.toString());
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */     }
/*    */     finally
/*    */     {
/* 59 */       if (old != null)
/* 60 */         Thread.currentThread().setContextClassLoader(old);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getDestFile()
/*    */   {
/* 67 */     return this.destFile;
/*    */   }
/*    */ 
/*    */   public void setDestFile(String destFile) {
/* 71 */     this.destFile = destFile;
/*    */   }
/*    */ 
/*    */   public static void writeFile(String file, String context)
/*    */     throws Exception
/*    */   {
/* 81 */     PrintWriter pw = null;
/*    */     try
/*    */     {
/* 84 */       pw = new PrintWriter(new FileOutputStream(file));
/* 85 */       pw.write(context);
/*    */     }
/*    */     finally {
/* 88 */       if (pw != null) {
/* 89 */         pw.flush();
/* 90 */         pw.close();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public String getAppend() {
/* 95 */     return this.append;
/*    */   }
/*    */   public void setAppend(String append) {
/* 98 */     this.append = append;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.VersionInfoTask
 * JD-Core Version:    0.5.4
 */