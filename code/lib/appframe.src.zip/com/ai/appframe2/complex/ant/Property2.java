/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.Project;
/*    */ import org.apache.tools.ant.Task;
/*    */ 
/*    */ public class Property2 extends Task
/*    */ {
/*    */   private String name;
/*    */   private String name2;
/*    */ 
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/* 22 */     if (getProject().getProperties().containsKey(this.name2)) {
/* 23 */       getProject().setInheritedProperty(this.name, (String)getProject().getProperties().get(this.name2));
/*    */     }
/*    */     else
/* 26 */       getProject().setInheritedProperty(this.name, this.name2);
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 31 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 34 */     this.name = name;
/*    */   }
/*    */   public String getName2() {
/* 37 */     return this.name2;
/*    */   }
/*    */   public void setName2(String name2) {
/* 40 */     this.name2 = name2;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.Property2
 * JD-Core Version:    0.5.4
 */