/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.File;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.Task;
/*     */ 
/*     */ public class AIReplaceTask extends Task
/*     */ {
/*     */   private String srcFileName;
/*     */   private String srcStartStr;
/*     */   private String srcEndStr;
/*     */   private String destFileName;
/*     */   private String destReplaceStr;
/*     */ 
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/*  31 */     if (StringUtils.isBlank(this.srcFileName)) {
/*  32 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "srcFileName" }));
/*     */     }
/*  34 */     if (StringUtils.isBlank(this.srcStartStr)) {
/*  35 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "srcStartStr" }));
/*     */     }
/*  37 */     if (StringUtils.isBlank(this.srcEndStr)) {
/*  38 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "srcEndStr" }));
/*     */     }
/*  40 */     if (StringUtils.isBlank(this.destFileName)) {
/*  41 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destFileName" }));
/*     */     }
/*  43 */     if (StringUtils.isBlank(this.destReplaceStr)) {
/*  44 */       throw new BuildException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destReplaceStr" }));
/*     */     }
/*     */     try
/*     */     {
/*  48 */       String src = FileUtils.readFileToString(new File(this.srcFileName), "GBK");
/*     */ 
/*  50 */       String context = StringUtils.substringBefore(StringUtils.substringAfter(src, this.srcStartStr), this.srcEndStr);
/*     */ 
/*  52 */       String dest = FileUtils.readFileToString(new File(this.destFileName), "GBK");
/*     */ 
/*  54 */       FileUtils.writeStringToFile(new File(this.destFileName), StringUtils.replace(dest, this.destReplaceStr, context), "GBK");
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  58 */       ex.printStackTrace();
/*  59 */       throw new BuildException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSrcFileName() {
/*  64 */     return this.srcFileName;
/*     */   }
/*     */   public void setSrcFileName(String srcFileName) {
/*  67 */     this.srcFileName = srcFileName;
/*     */   }
/*     */   public String getSrcStartStr() {
/*  70 */     return this.srcStartStr;
/*     */   }
/*     */   public void setSrcStartStr(String srcStartStr) {
/*  73 */     this.srcStartStr = srcStartStr;
/*     */   }
/*     */   public String getSrcEndStr() {
/*  76 */     return this.srcEndStr;
/*     */   }
/*     */   public void setSrcEndStr(String srcEndStr) {
/*  79 */     this.srcEndStr = srcEndStr;
/*     */   }
/*     */   public String getDestFileName() {
/*  82 */     return this.destFileName;
/*     */   }
/*     */   public void setDestFileName(String destFileName) {
/*  85 */     this.destFileName = destFileName;
/*     */   }
/*     */   public String getDestReplaceStr() {
/*  88 */     return this.destReplaceStr;
/*     */   }
/*     */   public void setDestReplaceStr(String destReplaceStr) {
/*  91 */     this.destReplaceStr = destReplaceStr;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/*  95 */     AIReplaceTask a = new AIReplaceTask();
/*  96 */     a.setSrcFileName("c:/1.xml");
/*  97 */     a.setSrcStartStr("<!-- JSPC servlet mappings start -->");
/*  98 */     a.setSrcEndStr("<!-- JSPC servlet mappings end -->");
/*     */ 
/* 100 */     a.setDestFileName("c:/2.xml");
/* 101 */     a.setDestReplaceStr("<!--REPLACED-->");
/*     */ 
/* 103 */     a.execute();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.AIReplaceTask
 * JD-Core Version:    0.5.4
 */