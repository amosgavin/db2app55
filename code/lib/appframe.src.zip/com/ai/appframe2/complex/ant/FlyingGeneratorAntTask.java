/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.velocity.app.Velocity;
/*     */ import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
/*     */ 
/*     */ public class FlyingGeneratorAntTask extends MatchingTask
/*     */ {
/*     */   private String destPath;
/*     */   private String sourcePath;
/*     */   private List fileSets;
/*     */   private String filename;
/*     */   private String vmConfigPath;
/*     */   private String type;
/*     */ 
/*     */   public FlyingGeneratorAntTask()
/*     */   {
/*  40 */     this.destPath = null;
/*  41 */     this.sourcePath = null;
/*     */ 
/* 306 */     this.fileSets = new LinkedList();
/* 307 */     this.filename = null;
/*     */   }
/*     */ 
/*     */   public String[] createFlying(String destPath, String tmpVmConfig, String type)
/*     */     throws Exception
/*     */   {
/*  55 */     Properties p = new Properties();
/*  56 */     p.put("resource.loader", "class");
/*  57 */     p.put("class.resource.loader.class", ClasspathResourceLoader.class.getName());
/*  58 */     Velocity.init(p);
/*     */ 
/*  60 */     HashMap real = new HashMap();
/*  61 */     String getServiceMethod = null;
/*  62 */     TreeMap result = new TreeMap();
/*     */ 
/*  64 */     if ((!StringUtils.isBlank(type)) && (type.equalsIgnoreCase("file")))
/*     */     {
/*  66 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_by_configurationfile"));
/*     */ 
/*  68 */       Service[] services = XMLHelper.getInstance().getServices();
/*  69 */       for (int i = 0; i < services.length; ++i) {
/*  70 */         Property[] props = services[i].getPropertys();
/*  71 */         String interfaceName = null;
/*  72 */         String implName = null;
/*  73 */         for (int j = 0; j < props.length; ++j) {
/*  74 */           if (props[j].getName().equalsIgnoreCase("interfaceClass")) {
/*  75 */             interfaceName = props[j].getValue();
/*     */           }
/*  77 */           else if (props[j].getName().equalsIgnoreCase("implClass")) {
/*  78 */             implName = props[j].getValue();
/*     */           }
/*     */         }
/*  81 */         result.put(interfaceName, implName);
/*  82 */         real.put(implName, services[i].getId());
/*     */       }
/*     */ 
/*  85 */       getServiceMethod = "ID";
/*     */     }
/*  87 */     else if ((!StringUtils.isBlank(type)) && (type.equalsIgnoreCase("jar")))
/*     */     {
/*  89 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_by_searchingjar"));
/*     */ 
/*  91 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/*  92 */         File item = (File)iter.next();
/*     */ 
/*  94 */         JarInputStream jis = new JarInputStream(new BufferedInputStream(new FileInputStream(item)));
/*  95 */         JarEntry jarEntry = null;
/*  96 */         while ((jarEntry = jis.getNextJarEntry()) != null) {
/*  97 */           if (!jarEntry.isDirectory());
/*  98 */           String tmpStr = jarEntry.getName();
/*  99 */           tmpStr = StringUtils.replace(tmpStr, ".class", "");
/* 100 */           tmpStr = StringUtils.replace(tmpStr, "/", ".");
/* 101 */           if ((tmpStr.indexOf(".interfaces.") >= 0) && (tmpStr.indexOf("Constant") < 0) && (tmpStr.endsWith("SV"))) {
/* 102 */             String impl = MiscHelper.getImplClassByInterClassName(tmpStr).getName();
/* 103 */             result.put(tmpStr, impl);
/* 104 */             real.put(impl, tmpStr);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 111 */       getServiceMethod = "CLASS";
/*     */     }
/*     */     else
/*     */     {
/* 115 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_by_sv"));
/*     */ 
/* 118 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/* 119 */         File item = (File)iter.next();
/* 120 */         String prefix = StringUtils.substringBefore(item.getPath(), "com" + System.getProperty("file.separator") + "asiainfo");
/* 121 */         String tmpStr = StringUtils.replace(item.getPath(), prefix, "");
/* 122 */         tmpStr = StringUtils.replace(tmpStr, ".class", "");
/* 123 */         tmpStr = StringUtils.replace(tmpStr, System.getProperty("file.separator"), ".");
/*     */ 
/* 125 */         if ((tmpStr.indexOf(".interfaces.") >= 0) && (tmpStr.indexOf("Constant") < 0) && (tmpStr.endsWith("SV"))) {
/* 126 */           String impl = MiscHelper.getImplClassByInterClassName(tmpStr).getName();
/* 127 */           result.put(tmpStr, impl);
/*     */ 
/* 129 */           real.put(impl, tmpStr);
/*     */         }
/*     */       }
/*     */ 
/* 133 */       getServiceMethod = "CLASS";
/*     */     }
/*     */ 
/* 136 */     String interfaceName = null;
/* 137 */     List errors = new ArrayList();
/* 138 */     int success = 0;
/* 139 */     int fail = 0;
/* 140 */     for (Iterator it = result.keySet().iterator(); it.hasNext(); ) {
/* 141 */       interfaceName = (String)it.next();
/*     */ 
/* 143 */       String implName = (String)result.get(interfaceName);
/*     */       try {
/* 145 */         Class.forName(implName);
/*     */       }
/*     */       catch (Throwable ex) {
/* 148 */         real.remove(implName);
/*     */ 
/* 150 */         log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_class_instance_error", new String[] { implName, interfaceName }));
/* 151 */         ex.printStackTrace();
/* 152 */         ++fail;
/* 153 */       }continue;
/*     */ 
/* 156 */       String tmpPackage = interfaceName.replaceAll(".interfaces.", ".flying.");
/* 157 */       tmpPackage = tmpPackage.substring(0, tmpPackage.lastIndexOf('.'));
/*     */       try
/*     */       {
/* 160 */         CreateFlying g = new CreateFlying(destPath, tmpVmConfig, tmpPackage, interfaceName, implName);
/* 161 */         g.generatorFlyingImpl();
/* 162 */         g.generatorFlyingInterface();
/* 163 */         g.generatorFlyingClient();
/* 164 */         ++success;
/*     */       }
/*     */       catch (Throwable e) {
/* 167 */         real.remove(implName);
/* 168 */         ++fail;
/*     */ 
/* 171 */         errors.add(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.create_service_error", new String[] { interfaceName, "Flying" }));
/* 172 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 176 */     if (success > 0)
/*     */     {
/* 178 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_generate_succeed", new String[] { success + "" }));
/*     */     }
/* 180 */     if (fail > 0)
/*     */     {
/* 182 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.flying_generate_failed", new String[] { fail + "" }));
/*     */     }
/*     */ 
/* 186 */     if (getServiceMethod.equalsIgnoreCase("CLASS")) {
/* 187 */       boolean isExist = false;
/* 188 */       File f = new File(this.destPath);
/* 189 */       String[] tmp = f.list();
/* 190 */       for (int i = 0; i < tmp.length; ++i) {
/* 191 */         if (tmp[i].equals("sv_class.txt")) {
/* 192 */           isExist = true;
/* 193 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 197 */       List l = new ArrayList();
/* 198 */       Set s = result.keySet();
/* 199 */       for (Iterator iter = s.iterator(); iter.hasNext(); ) {
/* 200 */         String item = (String)iter.next();
/* 201 */         String tmpPackage = item.replaceAll(".interfaces.", ".flying.");
/* 202 */         tmpPackage = tmpPackage.substring(0, tmpPackage.lastIndexOf('.'));
/* 203 */         String interName = tmpPackage + "." + AntHelper.getClassNameWithoutPkgByClass(item) + "FlyingInterface";
/* 204 */         String className = tmpPackage + "." + AntHelper.getClassNameWithoutPkgByClass(item) + "FlyingImpl";
/* 205 */         l.add(interName + "=" + className);
/*     */       }
/*     */ 
/* 208 */       if (isExist) {
/* 209 */         List _l = FileUtils.readLines(new File(this.destPath + "/sv_class.txt"), "GBK");
/* 210 */         l.addAll(_l);
/* 211 */         FileUtils.writeLines(new File(this.destPath + "/sv_class.txt"), "GBK", l);
/*     */       }
/*     */       else {
/* 214 */         FileUtils.writeLines(new File(this.destPath + "/sv_class.txt"), "GBK", l);
/*     */       }
/*     */     }
/* 217 */     else if (getServiceMethod.equalsIgnoreCase("ID")) {
/* 218 */       boolean isExist = false;
/* 219 */       File f = new File(this.destPath);
/* 220 */       String[] tmp = f.list();
/* 221 */       for (int i = 0; i < tmp.length; ++i) {
/* 222 */         if (tmp[i].equals("sv_id.txt")) {
/* 223 */           isExist = true;
/* 224 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 228 */       List l = new ArrayList();
/* 229 */       Set s = result.keySet();
/* 230 */       for (Iterator iter = s.iterator(); iter.hasNext(); ) {
/* 231 */         String item = (String)iter.next();
/* 232 */         String tmpPackage = item.replaceAll(".interfaces.", ".flying.");
/* 233 */         tmpPackage = tmpPackage.substring(0, tmpPackage.lastIndexOf('.'));
/* 234 */         String interName = tmpPackage + "." + AntHelper.getClassNameWithoutPkgByClass(item) + "FlyingInterface";
/* 235 */         String className = tmpPackage + "." + AntHelper.getClassNameWithoutPkgByClass(item) + "FlyingImpl";
/* 236 */         l.add(interName + "=" + className);
/*     */       }
/*     */ 
/* 239 */       if (isExist) {
/* 240 */         List _l = FileUtils.readLines(new File(this.destPath + "/sv_id.txt"), "GBK");
/* 241 */         l.addAll(_l);
/* 242 */         FileUtils.writeLines(new File(this.destPath + "/sv_id.txt"), "GBK", l);
/*     */       }
/*     */       else {
/* 245 */         FileUtils.writeLines(new File(this.destPath + "/sv_id.txt"), "GBK", l);
/*     */       }
/*     */     }
/*     */ 
/* 249 */     return (String[])(String[])errors.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/* 258 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 260 */       Thread.currentThread().setContextClassLoader(FlyingGeneratorAntTask.class.getClassLoader());
/* 261 */       if (StringUtils.isBlank(this.destPath))
/*     */       {
/* 264 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destPath" }));
/*     */       }
/* 266 */       if (StringUtils.isBlank(this.vmConfigPath))
/*     */       {
/* 269 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "vmConfigPath" }));
/*     */       }
/*     */ 
/* 272 */       String[] result = createFlying(this.destPath, this.vmConfigPath, this.type);
/*     */ 
/* 274 */       for (int i = 0; i < result.length; ++i) {
/* 275 */         System.out.println(result[i]);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 283 */       if (old != null)
/* 284 */         Thread.currentThread().setContextClassLoader(old);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getDestPath()
/*     */   {
/* 291 */     return this.destPath;
/*     */   }
/*     */ 
/*     */   public String getSourcePath() {
/* 295 */     return this.sourcePath;
/*     */   }
/*     */ 
/*     */   public void setSourcePath(String sourcePath) {
/* 299 */     this.sourcePath = sourcePath;
/*     */   }
/*     */ 
/*     */   public void setDestPath(String destPath) {
/* 303 */     this.destPath = destPath;
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet)
/*     */   {
/* 312 */     this.fileSets.add(fileSet);
/*     */   }
/*     */ 
/*     */   public void setFilename(String filename) {
/* 316 */     this.filename = filename;
/*     */   }
/*     */ 
/*     */   private List getFiles() {
/* 320 */     List files = new LinkedList();
/* 321 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/* 323 */       FileSet fs = (FileSet)i.next();
/* 324 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/* 326 */       String[] dsFiles = ds.getIncludedFiles();
/* 327 */       for (int j = 0; j < dsFiles.length; ++j) {
/* 328 */         File f = new File(dsFiles[j]);
/* 329 */         if (!f.isFile()) {
/* 330 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/* 333 */         files.add(f);
/*     */       }
/*     */     }
/*     */ 
/* 337 */     return files;
/*     */   }
/*     */ 
/*     */   public String getVmConfigPath() {
/* 341 */     return this.vmConfigPath;
/*     */   }
/*     */ 
/*     */   public void setVmConfigPath(String vmConfigPath) {
/* 345 */     this.vmConfigPath = vmConfigPath;
/*     */   }
/*     */   public String getType() {
/* 348 */     return this.type;
/*     */   }
/*     */   public void setType(String type) {
/* 351 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/* 371 */     String item = IBaseSV.class.getName();
/* 372 */     String tmpPackage = item.replaceAll(".interfaces.", ".flying.");
/* 373 */     tmpPackage = tmpPackage.substring(0, tmpPackage.lastIndexOf('.'));
/* 374 */     String interName = tmpPackage + "." + AntHelper.getClassNameWithoutPkgByClass(item) + "FlyingInterface";
/*     */ 
/* 376 */     System.out.println(interName);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.FlyingGeneratorAntTask
 * JD-Core Version:    0.5.4
 */