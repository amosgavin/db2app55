/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.Velocity;
/*     */ 
/*     */ public class CreateEJB
/*     */ {
/*  32 */   private static transient Log log = LogFactory.getLog(CreateEJB.class);
/*     */   public static final String VERSION = "5.5";
/*     */   public static final String VM_PACKAGE = "VM_PACKAGE";
/*     */   public static final String VM_REMOTE_CLASSNAME = "VM_REMOTE_CLASSNAME";
/*     */   public static final String VM_VERSION = "VM_VERSION";
/*     */   public static final String VM_CREATEDATE = "VM_CREATEDATE";
/*     */   public static final String VM_REMOTEHOME_CLASSNAME = "VM_REMOTEHOME_CLASSNAME";
/*     */   public static final String VM_SERVICE_CLASSNAME = "VM_SERVICE_CLASSNAME";
/*     */   public static final String VM_INTERFACE_CLASSNAME = "VM_INTERFACE_CLASSNAME";
/*     */   public static final String VM_IMPL_CLASSNAME = "VM_IMPL_CLASSNAME";
/*     */   public static final String VM_CLIENT_CLASSNAME = "VM_CLIENT_CLASSNAME";
/*     */   public static final String VM_METHOD = "VM_METHOD";
/*     */   public static final String VM_EJB_JNDI = "VM_EJB_JNDI";
/*     */   public static final String VM_PATH_PREFIX = "template/ejb/";
/*     */   public static final String VM_FILE_EJB_REMOTE = "EJBRemote.vm";
/*     */   public static final String VM_FILE_EJB_REMOTEHOME = "EJBRemoteHome.vm";
/*     */   public static final String VM_FILE_EJB_SERVICE = "EJBService.vm";
/*     */   public static final String VM_FILE_EJB_CLIENT = "EJBClient.vm";
/*  59 */   private String jndi = null;
/*  60 */   private String ejbPkgPrefix = null;
/*  61 */   private String interfaceClass = null;
/*  62 */   private String implClass = null;
/*  63 */   private String generatorDir = null;
/*     */ 
/*  65 */   private String remoteClass = null;
/*  66 */   private String remoteHomeClass = null;
/*  67 */   private String serviceClass = null;
/*  68 */   private String clientClass = null;
/*     */ 
/*  70 */   private List serviceMethodList = null;
/*  71 */   private List remoteMethodList = null;
/*  72 */   private List clientMethodList = null;
/*     */ 
/*  74 */   private String isThrowRemoteException = null;
/*     */ 
/*     */   public CreateEJB()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CreateEJB(String generatorDir, String vmConfig, String ejbPkgPrefix, String interfaceClass, String implClass, String isThrowRemoteException)
/*     */     throws Exception
/*     */   {
/*  92 */     this.ejbPkgPrefix = ejbPkgPrefix;
/*  93 */     this.interfaceClass = interfaceClass;
/*  94 */     this.implClass = implClass;
/*  95 */     this.generatorDir = generatorDir;
/*  96 */     this.isThrowRemoteException = isThrowRemoteException;
/*     */     try
/*     */     {
/* 100 */       String shortInterfaceClassName = AntHelper.getClassNameWithoutPkgByClass(this.interfaceClass);
/* 101 */       this.jndi = MiscHelper.getJndiNameByInterClassName(Class.forName(this.interfaceClass));
/*     */ 
/* 103 */       this.remoteClass = (shortInterfaceClassName + "Remote");
/* 104 */       this.remoteHomeClass = (shortInterfaceClassName + "RemoteHome");
/* 105 */       this.serviceClass = (shortInterfaceClassName + "Service");
/* 106 */       this.clientClass = (shortInterfaceClassName + "Client");
/*     */ 
/* 108 */       this.serviceMethodList = new ArrayList();
/* 109 */       this.remoteMethodList = new ArrayList();
/* 110 */       this.clientMethodList = new ArrayList();
/*     */ 
/* 112 */       Class interfaceClazz = null;
/* 113 */       Class implClazz = null;
/*     */ 
/* 115 */       interfaceClazz = Class.forName(interfaceClass);
/*     */       try
/*     */       {
/* 118 */         implClazz = Class.forName(implClass);
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 123 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.no_impl_class") + ":" + implClass);
/*     */       }
/*     */ 
/* 126 */       Method[] method = interfaceClazz.getMethods();
/*     */ 
/* 140 */       HashMap map = new HashMap();
/* 141 */       for (int i = 0; i < method.length; ++i) {
/* 142 */         this.serviceMethodList.add(generatorServiceMethodList(method[i]));
/* 143 */         this.remoteMethodList.add(generatorRemoteMethodList(method[i]));
/*     */ 
/* 147 */         String tmp = method[i].getName() + "^" + method[i].getParameterTypes().length;
/* 148 */         if (!map.containsKey(tmp)) {
/* 149 */           map.put(tmp, new Integer(0));
/*     */         }
/*     */         else {
/* 152 */           Integer count = (Integer)map.get(tmp);
/* 153 */           map.put(tmp, new Integer(count.intValue() + 1));
/*     */         }
/* 155 */         Integer count = (Integer)map.get(tmp);
/* 156 */         String uniqCode = null;
/* 157 */         if (count.intValue() > 0) {
/* 158 */           uniqCode = String.valueOf(count.intValue());
/*     */         }
/* 160 */         this.clientMethodList.add(generatorClientMethodList(method[i], uniqCode));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 164 */       e.printStackTrace();
/* 165 */       log.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String generatorClientMethodList(Method method, String uniqCode)
/*     */     throws Exception
/*     */   {
/* 177 */     StringBuilder sb = new StringBuilder();
/* 178 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 179 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 180 */     sb.append(method.getName() + "(");
/* 181 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 183 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 184 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/* 185 */       if (j != parameterClazz.length - 1) {
/* 186 */         sb.append(",");
/*     */       }
/*     */     }
/* 189 */     sb.append(")");
/*     */ 
/* 191 */     Class[] exceptionClazz = method.getExceptionTypes();
/* 192 */     if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 193 */       sb.append("throws ");
/* 194 */       for (int j = 0; j < exceptionClazz.length; ++j) {
/* 195 */         sb.append(exceptionClazz[j].getName());
/* 196 */         if (j != exceptionClazz.length - 1) {
/* 197 */           sb.append(",");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 202 */     sb.append("{\n");
/*     */ 
/* 205 */     StringBuilder tmp = new StringBuilder();
/* 206 */     for (int _e = 0; _e < exceptionClazz.length; ++_e) {
/* 207 */       tmp.append(exceptionClazz[_e].getName() + ".class");
/* 208 */       if (_e != exceptionClazz.length - 1) {
/* 209 */         tmp.append(",");
/*     */       }
/*     */     }
/*     */ 
/* 213 */     StringBuilder body = new StringBuilder();
/*     */ 
/* 215 */     if (!method.getReturnType().equals(Void.TYPE)) {
/* 216 */       body.append(AntHelper.getComponentType(method.getReturnType()) + " rtn;\n");
/*     */     }
/* 218 */     body.append("try{\n");
/*     */ 
/* 220 */     body.append("if(!this.isInvokeWithTimeout(\"" + method.getName() + "\"," + parameterClazz.length + ")){\n");
/*     */ 
/* 222 */     if (!method.getReturnType().equals(Void.TYPE)) {
/* 223 */       body.append(" rtn = ");
/*     */     }
/* 225 */     body.append("((" + this.remoteClass + ")getRemoteObject())." + method.getName() + "(");
/*     */ 
/* 227 */     body.append("com.ai.appframe2.complex.center.CenterFactory._centerInfoJoinUserInfo(com.ai.appframe2.common.ServiceManager.getUser())");
/* 228 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 229 */       body.append(",");
/* 230 */       body.append("var" + j);
/*     */     }
/* 232 */     body.append(");\n");
/* 233 */     body.append("}\n");
/*     */ 
/* 235 */     body.append("else{\n");
/* 236 */     body.append("Object[] objectArray = new Object[" + (parameterClazz.length + 1) + "];\n");
/* 237 */     body.append("objectArray[0] = com.ai.appframe2.complex.center.CenterFactory._centerInfoJoinUserInfo(com.ai.appframe2.common.ServiceManager.getUser());\n");
/* 238 */     for (int i = 0; i < parameterClazz.length; ++i) {
/* 239 */       if (parameterClazz[i].equals(Boolean.TYPE)) {
/* 240 */         body.append("objectArray[" + (i + 1) + "] = new Boolean(var" + i + ");\n");
/*     */       }
/* 242 */       else if (parameterClazz[i].equals(Character.TYPE)) {
/* 243 */         body.append("objectArray[" + (i + 1) + "] = new Character(var" + i + ");\n");
/*     */       }
/* 245 */       else if (parameterClazz[i].equals(Byte.TYPE)) {
/* 246 */         body.append("objectArray[" + (i + 1) + "] = new Byte(var" + i + ");\n");
/*     */       }
/* 248 */       else if (parameterClazz[i].equals(Short.TYPE)) {
/* 249 */         body.append("objectArray[" + (i + 1) + "] = new Short(var" + i + ");\n");
/*     */       }
/* 251 */       else if (parameterClazz[i].equals(Integer.TYPE)) {
/* 252 */         body.append("objectArray[" + (i + 1) + "] = new Integer(var" + i + ");\n");
/*     */       }
/* 254 */       else if (parameterClazz[i].equals(Long.TYPE)) {
/* 255 */         body.append("objectArray[" + (i + 1) + "] = new Long(var" + i + ");\n");
/*     */       }
/* 257 */       else if (parameterClazz[i].equals(Float.TYPE)) {
/* 258 */         body.append("objectArray[" + (i + 1) + "] = new Float(var" + i + ");\n");
/*     */       }
/* 260 */       else if (parameterClazz[i].equals(Double.TYPE)) {
/* 261 */         body.append("objectArray[" + (i + 1) + "] = new Double(var" + i + ");\n");
/*     */       }
/*     */       else {
/* 264 */         body.append("objectArray[" + (i + 1) + "] = var" + i + ";\n");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 270 */     if (!method.getReturnType().equals(Void.TYPE)) {
/* 271 */       if (method.getReturnType().equals(Boolean.TYPE)) {
/* 272 */         body.append("rtn = ((Boolean)(");
/*     */       }
/* 274 */       else if (method.getReturnType().equals(Character.TYPE)) {
/* 275 */         body.append("rtn = ((Character)(");
/*     */       }
/* 277 */       else if (method.getReturnType().equals(Byte.TYPE)) {
/* 278 */         body.append("rtn = ((Byte)(");
/*     */       }
/* 280 */       else if (method.getReturnType().equals(Short.TYPE)) {
/* 281 */         body.append("rtn = ((Short)(");
/*     */       }
/* 283 */       else if (method.getReturnType().equals(Integer.TYPE)) {
/* 284 */         body.append("rtn = ((Integer)(");
/*     */       }
/* 286 */       else if (method.getReturnType().equals(Long.TYPE)) {
/* 287 */         body.append("rtn = ((Long)(");
/*     */       }
/* 289 */       else if (method.getReturnType().equals(Float.TYPE)) {
/* 290 */         body.append("rtn = ((Float)(");
/*     */       }
/* 292 */       else if (method.getReturnType().equals(Double.TYPE)) {
/* 293 */         body.append("rtn = ((Double)(");
/*     */       }
/*     */       else {
/* 296 */         body.append(" rtn = (" + AntHelper.getComponentType(method.getReturnType()) + ")(");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 301 */     List list = new ArrayList();
/*     */ 
/* 303 */     list.add(UserInfoInterface.class.getName() + ".class");
/* 304 */     for (int i = 0; i < parameterClazz.length; ++i) {
/* 305 */       if (parameterClazz[i].equals(Boolean.TYPE)) {
/* 306 */         list.add("Boolean.TYPE");
/*     */       }
/* 308 */       else if (parameterClazz[i].equals(Character.TYPE)) {
/* 309 */         list.add("Character.TYPE");
/*     */       }
/* 311 */       else if (parameterClazz[i].equals(Byte.TYPE)) {
/* 312 */         list.add("Byte.TYPE");
/*     */       }
/* 314 */       else if (parameterClazz[i].equals(Short.TYPE)) {
/* 315 */         list.add("Short.TYPE");
/*     */       }
/* 317 */       else if (parameterClazz[i].equals(Integer.TYPE)) {
/* 318 */         list.add("Integer.TYPE");
/*     */       }
/* 320 */       else if (parameterClazz[i].equals(Long.TYPE)) {
/* 321 */         list.add("Long.TYPE");
/*     */       }
/* 323 */       else if (parameterClazz[i].equals(Float.TYPE)) {
/* 324 */         list.add("Float.TYPE");
/*     */       }
/* 326 */       else if (parameterClazz[i].equals(Double.TYPE)) {
/* 327 */         list.add("Double.TYPE");
/*     */       }
/* 330 */       else if (parameterClazz[i].isArray()) {
/* 331 */         StringBuffer demision = new StringBuffer();
/* 332 */         Class tmpClass = parameterClazz[i];
/* 333 */         while (tmpClass.isArray()) {
/* 334 */           demision.append("[]");
/* 335 */           tmpClass = tmpClass.getComponentType();
/*     */         }
/* 337 */         list.add(tmpClass.getName() + demision.toString() + ".class");
/*     */       }
/*     */       else {
/* 340 */         list.add(parameterClazz[i].getName() + ".class");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 345 */     String parmaterTypeStr = "new Class[]{" + StringUtils.join(list.iterator(), ",") + "}";
/*     */ 
/* 347 */     String tmpUniqCode = null;
/* 348 */     if (uniqCode == null) {
/* 349 */       tmpUniqCode = "null";
/*     */     }
/*     */     else {
/* 352 */       tmpUniqCode = "\"" + uniqCode + "\"";
/*     */     }
/* 354 */     body.append("this.invokeWithTimeout((" + this.remoteClass + ")getRemoteObject(),\"" + method.getName() + "\"," + parameterClazz.length + ",objectArray," + parmaterTypeStr + "," + tmpUniqCode + ")");
/*     */ 
/* 356 */     if (!method.getReturnType().equals(Void.TYPE)) {
/* 357 */       if (method.getReturnType().equals(Boolean.TYPE)) {
/* 358 */         body.append(")).booleanValue();\n");
/*     */       }
/* 360 */       else if (method.getReturnType().equals(Character.TYPE)) {
/* 361 */         body.append(")).charValue();\n");
/*     */       }
/* 363 */       else if (method.getReturnType().equals(Byte.TYPE)) {
/* 364 */         body.append(")).byteValue();\n");
/*     */       }
/* 366 */       else if (method.getReturnType().equals(Short.TYPE)) {
/* 367 */         body.append(")).shortValue();\n");
/*     */       }
/* 369 */       else if (method.getReturnType().equals(Integer.TYPE)) {
/* 370 */         body.append(")).intValue();\n");
/*     */       }
/* 372 */       else if (method.getReturnType().equals(Long.TYPE)) {
/* 373 */         body.append(")).longValue();\n");
/*     */       }
/* 375 */       else if (method.getReturnType().equals(Float.TYPE)) {
/* 376 */         body.append(")).floatValue();\n");
/*     */       }
/* 378 */       else if (method.getReturnType().equals(Double.TYPE)) {
/* 379 */         body.append(")).doubleValue();\n");
/*     */       }
/*     */       else {
/* 382 */         body.append(");\n ");
/*     */       }
/*     */     }
/*     */     else {
/* 386 */       body.append(";\n");
/*     */     }
/* 388 */     body.append("}\n");
/*     */ 
/* 390 */     body.append("}catch(Throwable ex){\n");
/* 391 */     body.append("  if(ex instanceof com.ai.appframe2.complex.exceptions.EJBCheckedException){\n");
/* 392 */     body.append("     if(!com.ai.appframe2.complex.util.JVMID.getLocalJVMID().equalsIgnoreCase(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getJvmid())){\n");
/*     */ 
/* 394 */     body.append("       com.ai.appframe2.complex.util.RuntimeServerUtil.printExceptionFrom(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getServerName());\n");
/*     */ 
/* 396 */     body.append("     }\n");
/* 397 */     body.append("  }\n");
/*     */ 
/* 399 */     if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 400 */       body.append("    Throwable root = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(ex);                        \n");
/* 401 */       body.append("    if (root != null) {                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 402 */       for (int _ei = 0; _ei < exceptionClazz.length; ++_ei) {
/* 403 */         if (_ei == 0) {
/* 404 */           body.append("          if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 405 */           body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 406 */           body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */         }
/*     */         else {
/* 409 */           body.append("          else if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 410 */           body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 411 */           body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */         }
/*     */       }
/* 414 */       body.append("          else  {\t\t\n");
/* 415 */       body.append("            throw new RuntimeException(ex);                                     \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 416 */       body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 417 */       body.append("                                                                                \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 418 */       body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 419 */       body.append("    else {                                                                       \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 420 */       body.append("        throw new RuntimeException(ex);                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 421 */       body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */     }
/*     */     else {
/* 424 */       body.append("      throw new RuntimeException(ex);                                              \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */     }
/*     */ 
/* 427 */     body.append("}\n");
/*     */ 
/* 429 */     if (!method.getReturnType().equals(Void.TYPE)) {
/* 430 */       body.append("return rtn;\n");
/*     */     }
/*     */ 
/* 433 */     sb.append(body.toString());
/* 434 */     sb.append("}\n");
/*     */ 
/* 436 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String generatorRemoteMethodList(Method method)
/*     */     throws Exception
/*     */   {
/* 448 */     StringBuilder sb = new StringBuilder();
/* 449 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 450 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 451 */     sb.append(method.getName() + "(");
/* 452 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 454 */     sb.append("com.ai.appframe2.privilege.UserInfoInterface objUserInfoInterface");
/* 455 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 456 */       sb.append(",");
/* 457 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/*     */     }
/* 459 */     sb.append(")");
/*     */ 
/* 461 */     sb.append("throws java.rmi.RemoteException,com.ai.appframe2.complex.exceptions.EJBCheckedException");
/*     */ 
/* 468 */     sb.append(";\n");
/* 469 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String generatorServiceMethodList(Method method)
/*     */     throws Exception
/*     */   {
/* 480 */     StringBuilder sb = new StringBuilder();
/* 481 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 482 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 483 */     sb.append(method.getName() + "(");
/* 484 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 486 */     sb.append("com.ai.appframe2.privilege.UserInfoInterface objUserInfoInterface");
/* 487 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 488 */       sb.append(",");
/* 489 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/*     */     }
/* 491 */     sb.append(") throws ");
/*     */ 
/* 494 */     List exceptionList = new ArrayList();
/*     */ 
/* 496 */     if ((!StringUtils.isBlank(this.isThrowRemoteException)) && (this.isThrowRemoteException.trim().equalsIgnoreCase("true"))) {
/* 497 */       exceptionList.add("java.rmi.RemoteException");
/*     */     }
/*     */ 
/* 500 */     exceptionList.add("com.ai.appframe2.complex.exceptions.EJBCheckedException");
/*     */ 
/* 502 */     sb.append(StringUtils.join(exceptionList.iterator(), ","));
/*     */ 
/* 527 */     sb.append("{\n");
/*     */ 
/* 529 */     StringBuilder body = new StringBuilder();
/* 530 */     body.append("com.ai.appframe2.complex.center.CenterFactory._centerInfoLeavUserInfo(objUserInfoInterface);\n");
/*     */ 
/* 532 */     if (method.getReturnType().equals(Void.TYPE)) {
/* 533 */       body.append("try{\n");
/* 534 */       body.append("  impl." + method.getName() + "(");
/*     */ 
/* 536 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 537 */         body.append("var" + j);
/* 538 */         if (j != parameterClazz.length - 1) {
/* 539 */           body.append(",");
/*     */         }
/*     */       }
/* 542 */       body.append(");\n");
/*     */ 
/* 544 */       body.append("}catch(Throwable ex){\n");
/* 545 */       body.append("  throw new com.ai.appframe2.complex.exceptions.EJBCheckedException(ex);\n");
/* 546 */       body.append("}\n");
/*     */     }
/*     */     else {
/* 549 */       body.append(AntHelper.getComponentType(method.getReturnType()) + " rtn;\n");
/* 550 */       body.append("try{\n");
/* 551 */       body.append(" rtn = impl." + method.getName() + "(");
/*     */ 
/* 553 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 554 */         body.append("var" + j);
/* 555 */         if (j != parameterClazz.length - 1) {
/* 556 */           body.append(",");
/*     */         }
/*     */       }
/* 559 */       body.append(");\n");
/*     */ 
/* 561 */       body.append("}catch(Throwable ex){\n");
/* 562 */       body.append("  throw new com.ai.appframe2.complex.exceptions.EJBCheckedException(ex);\n");
/* 563 */       body.append("}\n");
/* 564 */       body.append("return rtn;\n");
/*     */     }
/*     */ 
/* 568 */     sb.append(body.toString());
/* 569 */     sb.append("}\n");
/*     */ 
/* 571 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void generatorRemoteInterface()
/*     */     throws Exception
/*     */   {
/* 579 */     VelocityContext context = new VelocityContext();
/* 580 */     context.put("VM_PACKAGE", this.ejbPkgPrefix);
/* 581 */     context.put("VM_REMOTE_CLASSNAME", this.remoteClass);
/* 582 */     context.put("VM_VERSION", "5.5");
/* 583 */     context.put("VM_CREATEDATE", new Date().toString());
/* 584 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/*     */ 
/* 586 */     context.put("VM_METHOD", this.remoteMethodList);
/*     */ 
/* 588 */     Template template = Velocity.getTemplate("template/ejb//EJBRemote.vm");
/*     */ 
/* 590 */     StringWriter sw = new StringWriter();
/* 591 */     BufferedWriter writer = new BufferedWriter(sw);
/* 592 */     if (template != null)
/* 593 */       template.merge(context, writer);
/* 594 */     writer.flush();
/* 595 */     writer.close();
/*     */ 
/* 597 */     StringBuffer str = null;
/* 598 */     str = sw.getBuffer();
/*     */ 
/* 600 */     AntHelper.writeJavaFile(this.generatorDir, this.ejbPkgPrefix, this.remoteClass, str.toString());
/*     */   }
/*     */ 
/*     */   public void generatorRemoteHomeInterface()
/*     */     throws Exception
/*     */   {
/* 609 */     VelocityContext context = new VelocityContext();
/* 610 */     context.put("VM_PACKAGE", this.ejbPkgPrefix);
/* 611 */     context.put("VM_REMOTEHOME_CLASSNAME", this.remoteHomeClass);
/* 612 */     context.put("VM_VERSION", "5.5");
/* 613 */     context.put("VM_CREATEDATE", new Date().toString());
/* 614 */     context.put("VM_REMOTE_CLASSNAME", this.remoteClass);
/*     */ 
/* 616 */     Template template = Velocity.getTemplate("template/ejb//EJBRemoteHome.vm");
/*     */ 
/* 618 */     StringWriter sw = new StringWriter();
/* 619 */     BufferedWriter writer = new BufferedWriter(sw);
/* 620 */     if (template != null)
/* 621 */       template.merge(context, writer);
/* 622 */     writer.flush();
/* 623 */     writer.close();
/*     */ 
/* 625 */     StringBuffer str = null;
/* 626 */     str = sw.getBuffer();
/*     */ 
/* 628 */     AntHelper.writeJavaFile(this.generatorDir, this.ejbPkgPrefix, this.remoteHomeClass, str.toString());
/*     */   }
/*     */ 
/*     */   public void generatorEJBService()
/*     */     throws Exception
/*     */   {
/* 637 */     VelocityContext context = new VelocityContext();
/* 638 */     context.put("VM_PACKAGE", this.ejbPkgPrefix);
/* 639 */     context.put("VM_SERVICE_CLASSNAME", this.serviceClass);
/* 640 */     context.put("VM_VERSION", "5.5");
/* 641 */     context.put("VM_CREATEDATE", new Date().toString());
/*     */ 
/* 643 */     context.put("VM_EJB_JNDI", this.jndi);
/*     */ 
/* 645 */     context.put("VM_REMOTE_CLASSNAME", this.remoteClass);
/* 646 */     context.put("VM_REMOTEHOME_CLASSNAME", this.remoteHomeClass);
/*     */ 
/* 648 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/* 649 */     context.put("VM_IMPL_CLASSNAME", this.implClass);
/*     */ 
/* 651 */     context.put("VM_METHOD", this.serviceMethodList);
/*     */ 
/* 653 */     Template template = Velocity.getTemplate("template/ejb//EJBService.vm");
/*     */ 
/* 655 */     StringWriter sw = new StringWriter();
/* 656 */     BufferedWriter writer = new BufferedWriter(sw);
/* 657 */     if (template != null)
/* 658 */       template.merge(context, writer);
/* 659 */     writer.flush();
/* 660 */     writer.close();
/*     */ 
/* 662 */     StringBuffer str = null;
/* 663 */     str = sw.getBuffer();
/*     */ 
/* 665 */     AntHelper.writeJavaFile(this.generatorDir, this.ejbPkgPrefix, this.serviceClass, str.toString());
/*     */   }
/*     */ 
/*     */   public void generatorEJBClient()
/*     */     throws Exception
/*     */   {
/* 673 */     VelocityContext context = new VelocityContext();
/* 674 */     context.put("VM_PACKAGE", this.ejbPkgPrefix);
/* 675 */     context.put("VM_SERVICE_CLASSNAME", this.serviceClass);
/* 676 */     context.put("VM_VERSION", "5.5");
/* 677 */     context.put("VM_CREATEDATE", new Date().toString());
/*     */ 
/* 679 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/*     */ 
/* 681 */     context.put("VM_REMOTE_CLASSNAME", this.remoteClass);
/*     */ 
/* 683 */     context.put("VM_CLIENT_CLASSNAME", this.clientClass);
/*     */ 
/* 685 */     context.put("VM_METHOD", this.clientMethodList);
/*     */ 
/* 687 */     Template template = Velocity.getTemplate("template/ejb//EJBClient.vm");
/*     */ 
/* 689 */     StringWriter sw = new StringWriter();
/* 690 */     BufferedWriter writer = new BufferedWriter(sw);
/* 691 */     if (template != null)
/* 692 */       template.merge(context, writer);
/* 693 */     writer.flush();
/* 694 */     writer.close();
/*     */ 
/* 696 */     StringBuffer str = null;
/* 697 */     str = sw.getBuffer();
/*     */ 
/* 699 */     AntHelper.writeJavaFile(this.generatorDir, this.ejbPkgPrefix, this.clientClass, str.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CreateEJB
 * JD-Core Version:    0.5.4
 */