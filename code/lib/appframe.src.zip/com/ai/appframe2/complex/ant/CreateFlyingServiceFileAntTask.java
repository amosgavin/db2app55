/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ 
/*     */ public class CreateFlyingServiceFileAntTask extends MatchingTask
/*     */ {
/*     */   private List fileSets;
/*     */   private String filename;
/*     */ 
/*     */   public CreateFlyingServiceFileAntTask()
/*     */   {
/*  31 */     this.fileSets = new LinkedList();
/*  32 */     this.filename = null;
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet) {
/*  36 */     this.fileSets.add(fileSet);
/*     */   }
/*     */ 
/*     */   public void setFilename(String filename) {
/*  40 */     this.filename = filename;
/*     */   }
/*     */ 
/*     */   public void execute() throws BuildException
/*     */   {
/*     */     try {
/*  46 */       StringBuilder sb = new StringBuilder();
/*  47 */       sb.append("<?xml version=\"1.0\" encoding=\"GB2312\"?>\n");
/*  48 */       sb.append("<services>\n");
/*     */ 
/*  50 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/*  51 */         File item = (File)iter.next();
/*  52 */         p = new Properties();
/*  53 */         p.load(new FileInputStream(item));
/*  54 */         Set set = p.keySet();
/*  55 */         for (iter2 = set.iterator(); iter2.hasNext(); ) {
/*  56 */           String item2 = (String)iter2.next();
/*  57 */           sb.append("<service>\n");
/*  58 */           sb.append("  <property name=\"interfaceClass\" value=\"" + item2 + "\"/>\n");
/*  59 */           sb.append("  <property name=\"implClass\" value=\"" + p.getProperty(item2) + "\"/>\n");
/*  60 */           sb.append("</service>\n");
/*     */         }
/*     */       }
/*     */       Properties p;
/*     */       Iterator iter2;
/*  64 */       sb.append("</services>\n");
/*     */ 
/*  66 */       log(sb.toString());
/*  67 */       log("filename:----------:" + this.filename);
/*  68 */       PrintWriter pw = new PrintWriter(new FileOutputStream(this.filename));
/*  69 */       pw.write(sb.toString());
/*  70 */       pw.flush();
/*  71 */       pw.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  75 */       e.printStackTrace();
/*     */ 
/*  77 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.create_file_error", new String[] { "flying", "service" });
/*     */ 
/*  79 */       throw new RuntimeException(msg + " : " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private List getFiles() {
/*  84 */     List files = new LinkedList();
/*  85 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/*  87 */       FileSet fs = (FileSet)i.next();
/*  88 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/*  90 */       String[] dsFiles = ds.getIncludedFiles();
/*  91 */       for (int j = 0; j < dsFiles.length; ++j) {
/*  92 */         File f = new File(dsFiles[j]);
/*  93 */         if (!f.isFile()) {
/*  94 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/*  97 */         files.add(f);
/*     */       }
/*     */     }
/*     */ 
/* 101 */     return files;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CreateFlyingServiceFileAntTask
 * JD-Core Version:    0.5.4
 */