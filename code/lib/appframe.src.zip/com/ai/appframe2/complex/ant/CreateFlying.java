/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.Velocity;
/*     */ 
/*     */ public class CreateFlying
/*     */ {
/*  29 */   private static transient Log log = LogFactory.getLog(CreateFlying.class);
/*     */   public static final String VERSION = "5.5";
/*     */   public static final String VM_PACKAGE = "VM_PACKAGE";
/*     */   public static final String VM_REMOTE_CLASSNAME = "VM_REMOTE_CLASSNAME";
/*     */   public static final String VM_VERSION = "VM_VERSION";
/*     */   public static final String VM_CREATEDATE = "VM_CREATEDATE";
/*     */   public static final String VM_SERVICE_CLASSNAME = "VM_SERVICE_CLASSNAME";
/*     */   public static final String VM_INTERFACE_CLASSNAME = "VM_INTERFACE_CLASSNAME";
/*     */   public static final String VM_IMPL_CLASSNAME = "VM_IMPL_CLASSNAME";
/*     */   public static final String VM_CLIENT_CLASSNAME = "VM_CLIENT_CLASSNAME";
/*     */   public static final String VM_METHOD = "VM_METHOD";
/*     */   public static final String VM_PATH_PREFIX = "template/flying/";
/*     */   public static final String VM_FILE_FLYING_INTERFACE = "FlyingInterface.vm";
/*     */   public static final String VM_FILE_FLYING_IMPL = "FlyingImpl.vm";
/*     */   public static final String VM_FILE_FLYING_CLIENT = "FlyingClient.vm";
/*  51 */   private String flyingPkgPrefix = null;
/*  52 */   private String interfaceClass = null;
/*  53 */   private String implClass = null;
/*  54 */   private String generatorDir = null;
/*     */ 
/*  56 */   private String flyingInterfaceClass = null;
/*  57 */   private String flyingImplClass = null;
/*  58 */   private String flyingClientClass = null;
/*     */ 
/*  60 */   private List serviceMethodList = null;
/*  61 */   private List remoteMethodList = null;
/*  62 */   private List clientMethodList = null;
/*     */ 
/*     */   public CreateFlying()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CreateFlying(String generatorDir, String vmConfig, String flyingPkgPrefix, String interfaceClass, String implClass)
/*     */     throws Exception
/*     */   {
/*  80 */     this.flyingPkgPrefix = flyingPkgPrefix;
/*  81 */     this.interfaceClass = interfaceClass;
/*  82 */     this.implClass = implClass;
/*  83 */     this.generatorDir = generatorDir;
/*     */     try
/*     */     {
/*  87 */       String shortInterfaceClassName = AntHelper.getClassNameWithoutPkgByClass(this.interfaceClass);
/*     */ 
/*  89 */       this.flyingInterfaceClass = (shortInterfaceClassName + "FlyingInterface");
/*  90 */       this.flyingImplClass = (shortInterfaceClassName + "FlyingImpl");
/*  91 */       this.flyingClientClass = (shortInterfaceClassName + "FlyingClient");
/*     */ 
/*  93 */       this.serviceMethodList = new ArrayList();
/*  94 */       this.remoteMethodList = new ArrayList();
/*  95 */       this.clientMethodList = new ArrayList();
/*     */ 
/*  97 */       Class interfaceClazz = null;
/*  98 */       Class implClazz = null;
/*     */ 
/* 100 */       interfaceClazz = Class.forName(interfaceClass);
/*     */       try
/*     */       {
/* 103 */         implClazz = Class.forName(implClass);
/*     */       }
/*     */       catch (Throwable e)
/*     */       {
/* 108 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.no_impl_class") + ":" + implClass);
/*     */       }
/*     */ 
/* 111 */       Method[] method = interfaceClazz.getMethods();
/* 112 */       for (int i = 0; i < method.length; ++i) {
/* 113 */         this.serviceMethodList.add(generatorImplMethodList(method[i]));
/* 114 */         this.remoteMethodList.add(generatorInterfaceMethodList(method[i]));
/* 115 */         this.clientMethodList.add(generatorClientMethodList(method[i]));
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 119 */       e.printStackTrace();
/* 120 */       log.error(e.getMessage(), e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String generatorClientMethodList(Method method)
/*     */     throws Exception
/*     */   {
/* 132 */     StringBuilder sb = new StringBuilder();
/* 133 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 134 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 135 */     sb.append(method.getName() + "(");
/* 136 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 138 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 139 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/* 140 */       if (j != parameterClazz.length - 1) {
/* 141 */         sb.append(",");
/*     */       }
/*     */     }
/* 144 */     sb.append(")");
/*     */ 
/* 146 */     Class[] exceptionClazz = method.getExceptionTypes();
/* 147 */     if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 148 */       sb.append("throws ");
/* 149 */       for (int j = 0; j < exceptionClazz.length; ++j) {
/* 150 */         sb.append(exceptionClazz[j].getName());
/* 151 */         if (j != exceptionClazz.length - 1) {
/* 152 */           sb.append(",");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 157 */     sb.append("{\n");
/*     */ 
/* 160 */     StringBuilder tmp = new StringBuilder();
/* 161 */     for (int _e = 0; _e < exceptionClazz.length; ++_e) {
/* 162 */       tmp.append(exceptionClazz[_e].getName() + ".class");
/* 163 */       if (_e != exceptionClazz.length - 1) {
/* 164 */         tmp.append(",");
/*     */       }
/*     */     }
/*     */ 
/* 168 */     StringBuilder body = new StringBuilder();
/*     */ 
/* 170 */     if (method.getReturnType().equals(Void.TYPE)) {
/* 171 */       body.append("try{\n");
/* 172 */       body.append("objRemote." + method.getName() + "(");
/*     */ 
/* 174 */       body.append("com.ai.appframe2.complex.center.CenterFactory._centerInfoJoinUserInfo(com.ai.appframe2.common.ServiceManager.getUser())");
/* 175 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 176 */         body.append(",");
/* 177 */         body.append("var" + j);
/*     */       }
/* 179 */       body.append(");\n");
/*     */ 
/* 181 */       body.append("}catch(Throwable ex){\n");
/* 182 */       body.append("  if(ex instanceof com.ai.appframe2.complex.exceptions.EJBCheckedException){\n");
/* 183 */       body.append("     if(!com.ai.appframe2.complex.util.JVMID.getLocalJVMID().equalsIgnoreCase(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getJvmid())){\n");
/* 184 */       body.append("       com.ai.appframe2.complex.util.RuntimeServerUtil.printExceptionFrom(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getServerName());\n");
/* 185 */       body.append("     }\n");
/* 186 */       body.append("  }\n");
/*     */ 
/* 188 */       if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 189 */         body.append("    Throwable root = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(ex);                        \n");
/* 190 */         body.append("    if (root != null) {                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 191 */         for (int _ei = 0; _ei < exceptionClazz.length; ++_ei) {
/* 192 */           if (_ei == 0) {
/* 193 */             body.append("          if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 194 */             body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 195 */             body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */           }
/*     */           else {
/* 198 */             body.append("          else if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 199 */             body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 200 */             body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */           }
/*     */         }
/* 203 */         body.append("          else  {\t\t\n");
/* 204 */         body.append("            throw new RuntimeException(ex);                                     \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 205 */         body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 206 */         body.append("                                                                                \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 207 */         body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 208 */         body.append("    else {                                                                       \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 209 */         body.append("        throw new RuntimeException(ex);                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 210 */         body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */       }
/*     */       else {
/* 213 */         body.append("      throw new RuntimeException(ex);                                              \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */       }
/*     */ 
/* 217 */       body.append("}\n");
/*     */     }
/*     */     else {
/* 220 */       body.append(AntHelper.getComponentType(method.getReturnType()) + " rtn;\n");
/* 221 */       body.append("try{\n");
/* 222 */       body.append(" rtn = objRemote." + method.getName() + "(");
/*     */ 
/* 224 */       body.append("com.ai.appframe2.complex.center.CenterFactory._centerInfoJoinUserInfo(com.ai.appframe2.common.ServiceManager.getUser())");
/* 225 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 226 */         body.append(",");
/* 227 */         body.append("var" + j);
/*     */       }
/* 229 */       body.append(");\n");
/*     */ 
/* 231 */       body.append("}catch(Throwable ex){\n");
/* 232 */       body.append("  if(ex instanceof com.ai.appframe2.complex.exceptions.EJBCheckedException){\n");
/* 233 */       body.append("     if(!com.ai.appframe2.complex.util.JVMID.getLocalJVMID().equalsIgnoreCase(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getJvmid())){\n");
/* 234 */       body.append("       com.ai.appframe2.complex.util.RuntimeServerUtil.printExceptionFrom(((com.ai.appframe2.complex.exceptions.EJBCheckedException)ex).getServerName());\n");
/* 235 */       body.append("     }\n");
/* 236 */       body.append("  }\n");
/*     */ 
/* 239 */       if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 240 */         body.append("    Throwable root = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(ex);                        \n");
/* 241 */         body.append("    if (root != null) {                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 242 */         for (int _ei = 0; _ei < exceptionClazz.length; ++_ei) {
/* 243 */           if (_ei == 0) {
/* 244 */             body.append("          if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 245 */             body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 246 */             body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */           }
/*     */           else {
/* 249 */             body.append("          else if (org.apache.commons.lang.ClassUtils.isAssignable(root.getClass()," + exceptionClazz[_ei].getName() + ".class)) {\t\t\n");
/* 250 */             body.append("            throw (" + exceptionClazz[_ei].getName() + ")root;                                   \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 251 */             body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */           }
/*     */         }
/* 254 */         body.append("          else  {\t\t\n");
/* 255 */         body.append("            throw new RuntimeException(ex);                                     \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 256 */         body.append("          }                                                                        \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 257 */         body.append("                                                                                \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 258 */         body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 259 */         body.append("    else {                                                                       \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 260 */         body.append("        throw new RuntimeException(ex);                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/* 261 */         body.append("    }                                                                            \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */       }
/*     */       else {
/* 264 */         body.append("      throw new RuntimeException(ex);                                              \t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
/*     */       }
/*     */ 
/* 267 */       body.append("}\n");
/* 268 */       body.append("return rtn;\n");
/*     */     }
/*     */ 
/* 273 */     sb.append(body.toString());
/* 274 */     sb.append("}\n");
/*     */ 
/* 276 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String generatorInterfaceMethodList(Method method)
/*     */     throws Exception
/*     */   {
/* 288 */     StringBuilder sb = new StringBuilder();
/* 289 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 290 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 291 */     sb.append(method.getName() + "(");
/* 292 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 294 */     sb.append("com.ai.appframe2.privilege.UserInfoInterface objUserInfoInterface");
/* 295 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 296 */       sb.append(",");
/* 297 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/*     */     }
/* 299 */     sb.append(")");
/*     */ 
/* 301 */     Class[] exceptionClazz = method.getExceptionTypes();
/* 302 */     if ((exceptionClazz != null) && (exceptionClazz.length != 0)) {
/* 303 */       sb.append("throws java.rmi.RemoteException,com.ai.appframe2.complex.exceptions.EJBCheckedException");
/*     */     }
/*     */ 
/* 312 */     sb.append(";\n");
/* 313 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private String generatorImplMethodList(Method method)
/*     */     throws Exception
/*     */   {
/* 324 */     StringBuilder sb = new StringBuilder();
/* 325 */     sb.append(AntHelper.getModifyName(method.getModifiers()) + " ");
/* 326 */     sb.append(AntHelper.getComponentType(method.getReturnType()) + " ");
/* 327 */     sb.append(method.getName() + "(");
/* 328 */     Class[] parameterClazz = method.getParameterTypes();
/*     */ 
/* 330 */     sb.append("com.ai.appframe2.privilege.UserInfoInterface objUserInfoInterface");
/* 331 */     for (int j = 0; j < parameterClazz.length; ++j) {
/* 332 */       sb.append(",");
/* 333 */       sb.append(AntHelper.getComponentType(parameterClazz[j]) + " " + "var" + j);
/*     */     }
/* 335 */     sb.append(") throws com.ai.appframe2.complex.exceptions.EJBCheckedException");
/*     */ 
/* 360 */     sb.append("{\n");
/*     */ 
/* 362 */     StringBuilder body = new StringBuilder();
/* 363 */     body.append("com.ai.appframe2.complex.center.CenterFactory._centerInfoLeavUserInfo(objUserInfoInterface);\n");
/*     */ 
/* 365 */     if (method.getReturnType().equals(Void.TYPE)) {
/* 366 */       body.append("try{\n");
/* 367 */       body.append("  impl." + method.getName() + "(");
/*     */ 
/* 369 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 370 */         body.append("var" + j);
/* 371 */         if (j != parameterClazz.length - 1) {
/* 372 */           body.append(",");
/*     */         }
/*     */       }
/* 375 */       body.append(");\n");
/*     */ 
/* 377 */       body.append("}catch(Throwable ex){\n");
/* 378 */       body.append("  throw new com.ai.appframe2.complex.exceptions.EJBCheckedException(ex);\n");
/* 379 */       body.append("}\n");
/*     */     }
/*     */     else {
/* 382 */       body.append(AntHelper.getComponentType(method.getReturnType()) + " rtn;\n");
/* 383 */       body.append("try{\n");
/* 384 */       body.append(" rtn = impl." + method.getName() + "(");
/*     */ 
/* 386 */       for (int j = 0; j < parameterClazz.length; ++j) {
/* 387 */         body.append("var" + j);
/* 388 */         if (j != parameterClazz.length - 1) {
/* 389 */           body.append(",");
/*     */         }
/*     */       }
/* 392 */       body.append(");\n");
/*     */ 
/* 394 */       body.append("}catch(Throwable ex){\n");
/* 395 */       body.append("  throw new com.ai.appframe2.complex.exceptions.EJBCheckedException(ex);\n");
/* 396 */       body.append("}\n");
/* 397 */       body.append("return rtn;\n");
/*     */     }
/*     */ 
/* 401 */     sb.append(body.toString());
/* 402 */     sb.append("}\n");
/*     */ 
/* 404 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void generatorFlyingInterface()
/*     */     throws Exception
/*     */   {
/* 412 */     VelocityContext context = new VelocityContext();
/* 413 */     context.put("VM_PACKAGE", this.flyingPkgPrefix);
/* 414 */     context.put("VM_REMOTE_CLASSNAME", this.flyingInterfaceClass);
/* 415 */     context.put("VM_VERSION", "5.5");
/* 416 */     context.put("VM_CREATEDATE", new Date().toString());
/* 417 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/*     */ 
/* 419 */     context.put("VM_METHOD", this.remoteMethodList);
/*     */ 
/* 421 */     Template template = Velocity.getTemplate("template/flying//FlyingInterface.vm");
/*     */ 
/* 423 */     StringWriter sw = new StringWriter();
/* 424 */     BufferedWriter writer = new BufferedWriter(sw);
/* 425 */     if (template != null)
/* 426 */       template.merge(context, writer);
/* 427 */     writer.flush();
/* 428 */     writer.close();
/*     */ 
/* 430 */     StringBuffer str = null;
/* 431 */     str = sw.getBuffer();
/*     */ 
/* 433 */     AntHelper.writeJavaFile(this.generatorDir, this.flyingPkgPrefix, this.flyingInterfaceClass, str.toString());
/*     */   }
/*     */ 
/*     */   public void generatorFlyingImpl()
/*     */     throws Exception
/*     */   {
/* 443 */     VelocityContext context = new VelocityContext();
/* 444 */     context.put("VM_PACKAGE", this.flyingPkgPrefix);
/* 445 */     context.put("VM_SERVICE_CLASSNAME", this.flyingImplClass);
/* 446 */     context.put("VM_VERSION", "5.5");
/* 447 */     context.put("VM_CREATEDATE", new Date().toString());
/*     */ 
/* 449 */     context.put("VM_REMOTE_CLASSNAME", this.flyingInterfaceClass);
/*     */ 
/* 451 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/* 452 */     context.put("VM_IMPL_CLASSNAME", this.implClass);
/*     */ 
/* 454 */     context.put("VM_METHOD", this.serviceMethodList);
/*     */ 
/* 456 */     Template template = Velocity.getTemplate("template/flying//FlyingImpl.vm");
/*     */ 
/* 458 */     StringWriter sw = new StringWriter();
/* 459 */     BufferedWriter writer = new BufferedWriter(sw);
/* 460 */     if (template != null)
/* 461 */       template.merge(context, writer);
/* 462 */     writer.flush();
/* 463 */     writer.close();
/*     */ 
/* 465 */     StringBuffer str = null;
/* 466 */     str = sw.getBuffer();
/*     */ 
/* 468 */     AntHelper.writeJavaFile(this.generatorDir, this.flyingPkgPrefix, this.flyingImplClass, str.toString());
/*     */   }
/*     */ 
/*     */   public void generatorFlyingClient()
/*     */     throws Exception
/*     */   {
/* 476 */     VelocityContext context = new VelocityContext();
/* 477 */     context.put("VM_PACKAGE", this.flyingPkgPrefix);
/* 478 */     context.put("VM_SERVICE_CLASSNAME", this.flyingImplClass);
/* 479 */     context.put("VM_VERSION", "5.5");
/* 480 */     context.put("VM_CREATEDATE", new Date().toString());
/*     */ 
/* 482 */     context.put("VM_INTERFACE_CLASSNAME", this.interfaceClass);
/*     */ 
/* 484 */     context.put("VM_REMOTE_CLASSNAME", this.flyingInterfaceClass);
/*     */ 
/* 486 */     context.put("VM_CLIENT_CLASSNAME", this.flyingClientClass);
/*     */ 
/* 488 */     context.put("VM_METHOD", this.clientMethodList);
/*     */ 
/* 490 */     Template template = Velocity.getTemplate("template/flying//FlyingClient.vm");
/*     */ 
/* 492 */     StringWriter sw = new StringWriter();
/* 493 */     BufferedWriter writer = new BufferedWriter(sw);
/* 494 */     if (template != null)
/* 495 */       template.merge(context, writer);
/* 496 */     writer.flush();
/* 497 */     writer.close();
/*     */ 
/* 499 */     StringBuffer str = null;
/* 500 */     str = sw.getBuffer();
/*     */ 
/* 502 */     AntHelper.writeJavaFile(this.generatorDir, this.flyingPkgPrefix, this.flyingClientClass, str.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CreateFlying
 * JD-Core Version:    0.5.4
 */