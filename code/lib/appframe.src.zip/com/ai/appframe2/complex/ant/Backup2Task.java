/*    */ package com.ai.appframe2.complex.ant;
/*    */ 
/*    */ import java.io.File;
/*    */ import org.apache.tools.ant.BuildException;
/*    */ import org.apache.tools.ant.taskdefs.Tar;
/*    */ 
/*    */ public class Backup2Task extends Tar
/*    */ {
/*    */   private String hisSize;
/*    */   private String backupdir;
/*    */ 
/*    */   public void execute()
/*    */     throws BuildException
/*    */   {
/* 26 */     File backupdirFile = new File(this.backupdir);
/*    */ 
/* 28 */     if (backupdirFile != null) {
/* 29 */       File[] f = backupdirFile.listFiles();
/* 30 */       if (f.length >= 5) {
/* 31 */         long modefied = 9223372036854775807L;
/* 32 */         File first = null;
/* 33 */         for (int i = 0; i < f.length; ++i) {
/* 34 */           if (f[i].lastModified() < modefied) {
/* 35 */             modefied = f[i].lastModified();
/* 36 */             first = f[i];
/*    */           }
/*    */         }
/* 39 */         first.delete();
/*    */       }
/*    */     }
/*    */ 
/* 43 */     super.execute();
/*    */   }
/*    */ 
/*    */   public String getHisSize() {
/* 47 */     return this.hisSize;
/*    */   }
/*    */   public void setHisSize(String hisSize) {
/* 50 */     this.hisSize = hisSize;
/*    */   }
/*    */ 
/*    */   public String getBackupdir() {
/* 54 */     return this.backupdir;
/*    */   }
/*    */   public void setBackupdir(String backupdir) {
/* 57 */     this.backupdir = backupdir;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.Backup2Task
 * JD-Core Version:    0.5.4
 */