/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ 
/*     */ public class PreCreateProcessTask extends MatchingTask
/*     */ {
/*     */   private List fileSets;
/*     */   private String destPath;
/*     */   private String processEngineImplClassName;
/*     */   private String workflowTemplateClassName;
/*     */ 
/*     */   public PreCreateProcessTask()
/*     */   {
/*  26 */     this.fileSets = new LinkedList();
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet)
/*     */   {
/*  32 */     this.fileSets.add(fileSet); } 
/*     */   public void execute() throws BuildException { // Byte code:
/*     */     //   0: invokestatic 6	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   3: invokevirtual 7	java/lang/Thread:getContextClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   6: astore_1
/*     */     //   7: invokestatic 6	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   10: ldc_w 8
/*     */     //   13: invokevirtual 9	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
/*     */     //   16: invokevirtual 10	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   19: aload_0
/*     */     //   20: getfield 11	com/ai/appframe2/complex/ant/PreCreateProcessTask:destPath	Ljava/lang/String;
/*     */     //   23: invokestatic 12	org/apache/commons/lang/StringUtils:isBlank	(Ljava/lang/String;)Z
/*     */     //   26: ifeq +25 -> 51
/*     */     //   29: new 13	java/lang/Exception
/*     */     //   32: dup
/*     */     //   33: ldc 14
/*     */     //   35: iconst_1
/*     */     //   36: anewarray 15	java/lang/String
/*     */     //   39: dup
/*     */     //   40: iconst_0
/*     */     //   41: ldc 16
/*     */     //   43: aastore
/*     */     //   44: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   47: invokespecial 18	java/lang/Exception:<init>	(Ljava/lang/String;)V
/*     */     //   50: athrow
/*     */     //   51: aconst_null
/*     */     //   52: astore_2
/*     */     //   53: aconst_null
/*     */     //   54: astore_3
/*     */     //   55: aconst_null
/*     */     //   56: astore 4
/*     */     //   58: aconst_null
/*     */     //   59: astore 5
/*     */     //   61: aload_0
/*     */     //   62: getfield 19	com/ai/appframe2/complex/ant/PreCreateProcessTask:processEngineImplClassName	Ljava/lang/String;
/*     */     //   65: invokestatic 12	org/apache/commons/lang/StringUtils:isBlank	(Ljava/lang/String;)Z
/*     */     //   68: ifne +70 -> 138
/*     */     //   71: aload_0
/*     */     //   72: getfield 19	com/ai/appframe2/complex/ant/PreCreateProcessTask:processEngineImplClassName	Ljava/lang/String;
/*     */     //   75: invokevirtual 20	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   78: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   81: astore_2
/*     */     //   82: aload_2
/*     */     //   83: ldc 22
/*     */     //   85: iconst_1
/*     */     //   86: anewarray 23	java/lang/Class
/*     */     //   89: dup
/*     */     //   90: iconst_0
/*     */     //   91: ldc_w 15
/*     */     //   94: aastore
/*     */     //   95: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   98: astore_3
/*     */     //   99: aload_2
/*     */     //   100: ldc 25
/*     */     //   102: iconst_1
/*     */     //   103: anewarray 23	java/lang/Class
/*     */     //   106: dup
/*     */     //   107: iconst_0
/*     */     //   108: ldc_w 15
/*     */     //   111: aastore
/*     */     //   112: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   115: astore 4
/*     */     //   117: aload_2
/*     */     //   118: ldc 26
/*     */     //   120: iconst_1
/*     */     //   121: anewarray 23	java/lang/Class
/*     */     //   124: dup
/*     */     //   125: iconst_0
/*     */     //   126: ldc_w 15
/*     */     //   129: aastore
/*     */     //   130: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   133: astore 5
/*     */     //   135: goto +62 -> 197
/*     */     //   138: ldc 27
/*     */     //   140: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   143: astore_2
/*     */     //   144: aload_2
/*     */     //   145: ldc 22
/*     */     //   147: iconst_1
/*     */     //   148: anewarray 23	java/lang/Class
/*     */     //   151: dup
/*     */     //   152: iconst_0
/*     */     //   153: ldc_w 15
/*     */     //   156: aastore
/*     */     //   157: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   160: astore_3
/*     */     //   161: aload_2
/*     */     //   162: ldc 25
/*     */     //   164: iconst_1
/*     */     //   165: anewarray 23	java/lang/Class
/*     */     //   168: dup
/*     */     //   169: iconst_0
/*     */     //   170: ldc_w 15
/*     */     //   173: aastore
/*     */     //   174: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   177: astore 4
/*     */     //   179: aload_2
/*     */     //   180: ldc 26
/*     */     //   182: iconst_1
/*     */     //   183: anewarray 23	java/lang/Class
/*     */     //   186: dup
/*     */     //   187: iconst_0
/*     */     //   188: ldc_w 15
/*     */     //   191: aastore
/*     */     //   192: invokevirtual 24	java/lang/Class:getMethod	(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
/*     */     //   195: astore 5
/*     */     //   197: goto +32 -> 229
/*     */     //   200: astore 6
/*     */     //   202: aload_0
/*     */     //   203: new 28	java/lang/StringBuilder
/*     */     //   206: dup
/*     */     //   207: invokespecial 29	java/lang/StringBuilder:<init>	()V
/*     */     //   210: ldc 30
/*     */     //   212: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   215: aload 6
/*     */     //   217: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   220: invokevirtual 33	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   223: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   226: aload 6
/*     */     //   228: athrow
/*     */     //   229: aconst_null
/*     */     //   230: astore 6
/*     */     //   232: aload_0
/*     */     //   233: getfield 35	com/ai/appframe2/complex/ant/PreCreateProcessTask:workflowTemplateClassName	Ljava/lang/String;
/*     */     //   236: invokestatic 12	org/apache/commons/lang/StringUtils:isBlank	(Ljava/lang/String;)Z
/*     */     //   239: ifne +38 -> 277
/*     */     //   242: aload_0
/*     */     //   243: getfield 35	com/ai/appframe2/complex/ant/PreCreateProcessTask:workflowTemplateClassName	Ljava/lang/String;
/*     */     //   246: invokevirtual 20	java/lang/String:trim	()Ljava/lang/String;
/*     */     //   249: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   252: astore 7
/*     */     //   254: aload 7
/*     */     //   256: ldc 36
/*     */     //   258: invokevirtual 37	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   261: astore 8
/*     */     //   263: aload 8
/*     */     //   265: aconst_null
/*     */     //   266: invokevirtual 38	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   269: checkcast 15	java/lang/String
/*     */     //   272: astore 6
/*     */     //   274: goto +30 -> 304
/*     */     //   277: ldc 39
/*     */     //   279: invokestatic 21	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
/*     */     //   282: astore 7
/*     */     //   284: aload 7
/*     */     //   286: ldc 36
/*     */     //   288: invokevirtual 37	java/lang/Class:getField	(Ljava/lang/String;)Ljava/lang/reflect/Field;
/*     */     //   291: astore 8
/*     */     //   293: aload 8
/*     */     //   295: aconst_null
/*     */     //   296: invokevirtual 38	java/lang/reflect/Field:get	(Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   299: checkcast 15	java/lang/String
/*     */     //   302: astore 6
/*     */     //   304: goto +32 -> 336
/*     */     //   307: astore 7
/*     */     //   309: aload_0
/*     */     //   310: new 28	java/lang/StringBuilder
/*     */     //   313: dup
/*     */     //   314: invokespecial 29	java/lang/StringBuilder:<init>	()V
/*     */     //   317: ldc 40
/*     */     //   319: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   322: aload 7
/*     */     //   324: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   327: invokevirtual 33	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   330: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   333: aload 7
/*     */     //   335: athrow
/*     */     //   336: aload_0
/*     */     //   337: invokespecial 41	com/ai/appframe2/complex/ant/PreCreateProcessTask:getFiles	()Ljava/util/List;
/*     */     //   340: invokeinterface 42 1 0
/*     */     //   345: astore 7
/*     */     //   347: aload 7
/*     */     //   349: invokeinterface 43 1 0
/*     */     //   354: ifeq +322 -> 676
/*     */     //   357: aload 7
/*     */     //   359: invokeinterface 44 1 0
/*     */     //   364: checkcast 45	java/io/File
/*     */     //   367: astore 8
/*     */     //   369: aload 8
/*     */     //   371: invokevirtual 46	java/io/File:getName	()Ljava/lang/String;
/*     */     //   374: ldc 47
/*     */     //   376: invokevirtual 48	java/lang/String:endsWith	(Ljava/lang/String;)Z
/*     */     //   379: ifne +24 -> 403
/*     */     //   382: aload_0
/*     */     //   383: ldc 49
/*     */     //   385: iconst_1
/*     */     //   386: anewarray 15	java/lang/String
/*     */     //   389: dup
/*     */     //   390: iconst_0
/*     */     //   391: aload 8
/*     */     //   393: invokevirtual 50	java/io/File:toString	()Ljava/lang/String;
/*     */     //   396: aastore
/*     */     //   397: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   400: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   403: new 51	java/util/jar/JarInputStream
/*     */     //   406: dup
/*     */     //   407: new 52	java/io/BufferedInputStream
/*     */     //   410: dup
/*     */     //   411: new 53	java/io/FileInputStream
/*     */     //   414: dup
/*     */     //   415: aload 8
/*     */     //   417: invokespecial 54	java/io/FileInputStream:<init>	(Ljava/io/File;)V
/*     */     //   420: invokespecial 55	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   423: invokespecial 56	java/util/jar/JarInputStream:<init>	(Ljava/io/InputStream;)V
/*     */     //   426: astore 9
/*     */     //   428: aconst_null
/*     */     //   429: astore 10
/*     */     //   431: aload 9
/*     */     //   433: invokevirtual 57	java/util/jar/JarInputStream:getNextJarEntry	()Ljava/util/jar/JarEntry;
/*     */     //   436: dup
/*     */     //   437: astore 10
/*     */     //   439: ifnull +234 -> 673
/*     */     //   442: aload 10
/*     */     //   444: invokevirtual 58	java/util/jar/JarEntry:isDirectory	()Z
/*     */     //   447: ifne -16 -> 431
/*     */     //   450: aload 10
/*     */     //   452: invokevirtual 59	java/util/jar/JarEntry:getName	()Ljava/lang/String;
/*     */     //   455: ldc 60
/*     */     //   457: invokevirtual 48	java/lang/String:endsWith	(Ljava/lang/String;)Z
/*     */     //   460: ifeq -29 -> 431
/*     */     //   463: aload 10
/*     */     //   465: invokevirtual 59	java/util/jar/JarEntry:getName	()Ljava/lang/String;
/*     */     //   468: astore 11
/*     */     //   470: aload 11
/*     */     //   472: ldc 60
/*     */     //   474: ldc 61
/*     */     //   476: invokestatic 62	org/apache/commons/lang/StringUtils:replace	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   479: astore 11
/*     */     //   481: aload 11
/*     */     //   483: ldc 63
/*     */     //   485: ldc 64
/*     */     //   487: invokestatic 62	org/apache/commons/lang/StringUtils:replace	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   490: astore 11
/*     */     //   492: aload_3
/*     */     //   493: aconst_null
/*     */     //   494: iconst_1
/*     */     //   495: anewarray 15	java/lang/String
/*     */     //   498: dup
/*     */     //   499: iconst_0
/*     */     //   500: aload 11
/*     */     //   502: aastore
/*     */     //   503: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   506: checkcast 15	java/lang/String
/*     */     //   509: astore 12
/*     */     //   511: aload 12
/*     */     //   513: invokestatic 12	org/apache/commons/lang/StringUtils:isBlank	(Ljava/lang/String;)Z
/*     */     //   516: ifne +100 -> 616
/*     */     //   519: aload 4
/*     */     //   521: aconst_null
/*     */     //   522: iconst_1
/*     */     //   523: anewarray 15	java/lang/String
/*     */     //   526: dup
/*     */     //   527: iconst_0
/*     */     //   528: aload 11
/*     */     //   530: aastore
/*     */     //   531: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   534: checkcast 15	java/lang/String
/*     */     //   537: astore 13
/*     */     //   539: aload 5
/*     */     //   541: aconst_null
/*     */     //   542: iconst_1
/*     */     //   543: anewarray 15	java/lang/String
/*     */     //   546: dup
/*     */     //   547: iconst_0
/*     */     //   548: aload 11
/*     */     //   550: aastore
/*     */     //   551: invokevirtual 65	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   554: checkcast 15	java/lang/String
/*     */     //   557: astore 14
/*     */     //   559: aload_0
/*     */     //   560: getfield 11	com/ai/appframe2/complex/ant/PreCreateProcessTask:destPath	Ljava/lang/String;
/*     */     //   563: aload 14
/*     */     //   565: new 28	java/lang/StringBuilder
/*     */     //   568: dup
/*     */     //   569: invokespecial 29	java/lang/StringBuilder:<init>	()V
/*     */     //   572: aload 13
/*     */     //   574: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   577: ldc 66
/*     */     //   579: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   582: aload 6
/*     */     //   584: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   587: invokevirtual 33	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   590: aload 12
/*     */     //   592: invokestatic 67	com/ai/appframe2/complex/ant/AntHelper:writeJavaFile	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
/*     */     //   595: aload_0
/*     */     //   596: ldc 68
/*     */     //   598: iconst_1
/*     */     //   599: anewarray 15	java/lang/String
/*     */     //   602: dup
/*     */     //   603: iconst_0
/*     */     //   604: aload 11
/*     */     //   606: aastore
/*     */     //   607: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   610: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   613: goto +21 -> 634
/*     */     //   616: aload_0
/*     */     //   617: ldc 69
/*     */     //   619: iconst_1
/*     */     //   620: anewarray 15	java/lang/String
/*     */     //   623: dup
/*     */     //   624: iconst_0
/*     */     //   625: aload 11
/*     */     //   627: aastore
/*     */     //   628: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   631: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   634: goto +36 -> 670
/*     */     //   637: astore 12
/*     */     //   639: aload 12
/*     */     //   641: invokevirtual 70	java/lang/Exception:printStackTrace	()V
/*     */     //   644: aload_0
/*     */     //   645: ldc 71
/*     */     //   647: iconst_2
/*     */     //   648: anewarray 15	java/lang/String
/*     */     //   651: dup
/*     */     //   652: iconst_0
/*     */     //   653: aload 11
/*     */     //   655: aastore
/*     */     //   656: dup
/*     */     //   657: iconst_1
/*     */     //   658: aload 12
/*     */     //   660: invokevirtual 72	java/lang/Exception:toString	()Ljava/lang/String;
/*     */     //   663: aastore
/*     */     //   664: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   667: invokevirtual 34	com/ai/appframe2/complex/ant/PreCreateProcessTask:log	(Ljava/lang/String;)V
/*     */     //   670: goto -239 -> 431
/*     */     //   673: goto -326 -> 347
/*     */     //   676: aload_1
/*     */     //   677: ifnull +75 -> 752
/*     */     //   680: invokestatic 6	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   683: aload_1
/*     */     //   684: invokevirtual 10	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   687: goto +65 -> 752
/*     */     //   690: astore_2
/*     */     //   691: aload_2
/*     */     //   692: invokevirtual 74	java/lang/Throwable:printStackTrace	()V
/*     */     //   695: new 75	java/lang/RuntimeException
/*     */     //   698: dup
/*     */     //   699: new 28	java/lang/StringBuilder
/*     */     //   702: dup
/*     */     //   703: invokespecial 29	java/lang/StringBuilder:<init>	()V
/*     */     //   706: ldc 76
/*     */     //   708: iconst_1
/*     */     //   709: anewarray 15	java/lang/String
/*     */     //   712: dup
/*     */     //   713: iconst_0
/*     */     //   714: ldc 77
/*     */     //   716: aastore
/*     */     //   717: invokestatic 17	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   720: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   723: ldc 78
/*     */     //   725: invokevirtual 31	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   728: invokevirtual 33	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   731: aload_2
/*     */     //   732: invokespecial 79	java/lang/RuntimeException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   735: athrow
/*     */     //   736: astore 15
/*     */     //   738: aload_1
/*     */     //   739: ifnull +10 -> 749
/*     */     //   742: invokestatic 6	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*     */     //   745: aload_1
/*     */     //   746: invokevirtual 10	java/lang/Thread:setContextClassLoader	(Ljava/lang/ClassLoader;)V
/*     */     //   749: aload 15
/*     */     //   751: athrow
/*     */     //   752: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   61	197	200	java/lang/Exception
/*     */     //   232	304	307	java/lang/Exception
/*     */     //   492	634	637	java/lang/Exception
/*     */     //   7	676	690	java/lang/Throwable
/*     */     //   7	676	736	finally
/*     */     //   690	738	736	finally } 
/* 146 */   private List getFiles() { List files = new LinkedList();
/* 147 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/* 149 */       FileSet fs = (FileSet)i.next();
/* 150 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/* 152 */       String[] dsFiles = ds.getIncludedFiles();
/* 153 */       for (int j = 0; j < dsFiles.length; ++j) {
/* 154 */         File f = new File(dsFiles[j]);
/* 155 */         if (!f.isFile()) {
/* 156 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/* 159 */         files.add(f);
/*     */       }
/*     */     }
/*     */ 
/* 163 */     return files; }
/*     */ 
/*     */   public String getDestPath()
/*     */   {
/* 167 */     return this.destPath;
/*     */   }
/*     */ 
/*     */   public String getProcessEngineImplClassName()
/*     */   {
/* 172 */     return this.processEngineImplClassName;
/*     */   }
/*     */ 
/*     */   public String getWorkflowTemplateClassName() {
/* 176 */     return this.workflowTemplateClassName;
/*     */   }
/*     */ 
/*     */   public void setDestPath(String destPath) {
/* 180 */     this.destPath = destPath;
/*     */   }
/*     */ 
/*     */   public void setProcessEngineImplClassName(String processEngineImplClassName)
/*     */   {
/* 185 */     this.processEngineImplClassName = processEngineImplClassName;
/*     */   }
/*     */ 
/*     */   public void setWorkflowTemplateClassName(String workflowTemplateClassName) {
/* 189 */     this.workflowTemplateClassName = workflowTemplateClassName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.PreCreateProcessTask
 * JD-Core Version:    0.5.4
 */