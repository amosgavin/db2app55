/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ 
/*     */ public class CreateManifestAntTask extends MatchingTask
/*     */ {
/*     */   private List fileSets;
/*     */   private String filename;
/*     */   private String append;
/*     */   private String preappend;
/*     */ 
/*     */   public CreateManifestAntTask()
/*     */   {
/*  30 */     this.fileSets = new LinkedList();
/*  31 */     this.filename = null;
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet)
/*     */   {
/*  36 */     this.fileSets.add(fileSet);
/*     */   }
/*     */ 
/*     */   public void setFilename(String filename) {
/*  40 */     this.filename = filename;
/*     */   }
/*     */ 
/*     */   public void execute() throws BuildException
/*     */   {
/*     */     try {
/*  46 */       StringBuilder sb = new StringBuilder();
/*  47 */       sb.append("Manifest-Version: 1.0\n");
/*  48 */       sb.append("Class-Path: ");
/*     */ 
/*  50 */       if (!StringUtils.isBlank(this.preappend)) {
/*  51 */         sb.append(this.preappend + " ");
/*     */       }
/*     */ 
/*  54 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/*  55 */         File item = (File)iter.next();
/*  56 */         sb.append(item.getName() + " ");
/*     */       }
/*     */ 
/*  59 */       if (!StringUtils.isBlank(this.append)) {
/*  60 */         sb.append(this.append + " ");
/*     */       }
/*     */ 
/*  63 */       log(sb.toString());
/*  64 */       log("filename:----------:" + this.filename);
/*  65 */       PrintWriter pw = new PrintWriter(new FileOutputStream(this.filename));
/*  66 */       pw.write(sb.toString());
/*  67 */       pw.flush();
/*  68 */       pw.close();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  72 */       e.printStackTrace();
/*     */ 
/*  75 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.gen_file_failed", new String[] { "manifest" }) + " : " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private List getFiles() {
/*  80 */     List files = new LinkedList();
/*  81 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/*  83 */       FileSet fs = (FileSet)i.next();
/*  84 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/*  86 */       String[] dsFiles = ds.getIncludedFiles();
/*  87 */       for (int j = 0; j < dsFiles.length; ++j) {
/*  88 */         File f = new File(dsFiles[j]);
/*  89 */         if (!f.isFile()) {
/*  90 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/*  93 */         files.add(f);
/*     */       }
/*     */     }
/*     */ 
/*  97 */     return files;
/*     */   }
/*     */   public String getAppend() {
/* 100 */     return this.append;
/*     */   }
/*     */   public void setAppend(String append) {
/* 103 */     this.append = append;
/*     */   }
/*     */   public String getPreappend() {
/* 106 */     return this.preappend;
/*     */   }
/*     */   public void setPreappend(String preappend) {
/* 109 */     this.preappend = preappend;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.CreateManifestAntTask
 * JD-Core Version:    0.5.4
 */