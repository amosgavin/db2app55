/*     */ package com.ai.appframe2.complex.ant;
/*     */ 
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ import org.apache.tools.ant.BuildException;
/*     */ import org.apache.tools.ant.DirectoryScanner;
/*     */ import org.apache.tools.ant.taskdefs.MatchingTask;
/*     */ import org.apache.tools.ant.types.FileSet;
/*     */ import org.apache.velocity.app.Velocity;
/*     */ import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
/*     */ 
/*     */ public class EJBGeneratorAntTask extends MatchingTask
/*     */ {
/*     */   private String destPath;
/*     */   private String sourcePath;
/*     */   private List fileSets;
/*     */   private String filename;
/*     */   private String vmConfigPath;
/*     */   private String type;
/*     */   private String failonerror;
/*     */   private String isThrowRemoteException;
/*     */ 
/*     */   public EJBGeneratorAntTask()
/*     */   {
/*  32 */     this.destPath = null;
/*  33 */     this.sourcePath = null;
/*     */ 
/* 317 */     this.fileSets = new LinkedList();
/* 318 */     this.filename = null;
/*     */ 
/* 322 */     this.failonerror = "true";
/*     */   }
/*     */ 
/*     */   public String[] createEJB(String destPath, String tmpVmConfig, String type)
/*     */     throws Exception
/*     */   {
/*  47 */     Properties p = new Properties();
/*  48 */     p.put("resource.loader", "class");
/*  49 */     p.put("class.resource.loader.class", ClasspathResourceLoader.class.getName());
/*  50 */     Velocity.init(p);
/*     */ 
/*  52 */     HashMap real = new HashMap();
/*  53 */     String getServiceMethod = null;
/*  54 */     TreeMap result = new TreeMap();
/*     */ 
/*  56 */     if ((!StringUtils.isBlank(type)) && (type.equalsIgnoreCase("file")))
/*     */     {
/*  58 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.generateejb_by_configurationfile"));
/*     */ 
/*  60 */       Service[] services = XMLHelper.getInstance().getServices();
/*  61 */       for (int i = 0; i < services.length; ++i) {
/*  62 */         Property[] props = services[i].getPropertys();
/*  63 */         String interfaceName = null;
/*  64 */         String implName = null;
/*  65 */         for (int j = 0; j < props.length; ++j) {
/*  66 */           if (props[j].getName().equalsIgnoreCase("interfaceClass")) {
/*  67 */             interfaceName = props[j].getValue();
/*     */           }
/*  69 */           else if (props[j].getName().equalsIgnoreCase("implClass")) {
/*  70 */             implName = props[j].getValue();
/*     */           }
/*     */         }
/*  73 */         result.put(interfaceName, implName);
/*  74 */         real.put(implName, services[i].getId());
/*     */       }
/*     */ 
/*  77 */       getServiceMethod = "ID";
/*     */     }
/*  79 */     else if ((!StringUtils.isBlank(type)) && (type.equalsIgnoreCase("jar")))
/*     */     {
/*  81 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.generateejb_by_searchingjar"));
/*     */ 
/*  83 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/*  84 */         File item = (File)iter.next();
/*     */ 
/*  86 */         JarInputStream jis = new JarInputStream(new BufferedInputStream(new FileInputStream(item)));
/*  87 */         JarEntry jarEntry = null;
/*  88 */         while ((jarEntry = jis.getNextJarEntry()) != null) {
/*  89 */           if (!jarEntry.isDirectory());
/*  90 */           String tmpStr = jarEntry.getName();
/*  91 */           tmpStr = StringUtils.replace(tmpStr, ".class", "");
/*  92 */           tmpStr = StringUtils.replace(tmpStr, "/", ".");
/*  93 */           if ((tmpStr.indexOf(".interfaces.") >= 0) && (tmpStr.indexOf("Constant") < 0) && (tmpStr.endsWith("SV"))) {
/*  94 */             String impl = null;
/*     */             try {
/*  96 */               impl = MiscHelper.getImplClassByInterClassName(tmpStr).getName();
/*     */             }
/*     */             catch (Throwable ex) {
/*  99 */               if (isFailonerror()) {
/* 100 */                 throw new Exception(ex);
/*     */               }
/*     */ 
/* 103 */               log("generator src error:" + ExceptionUtils.getFullStackTrace(ex).toString());
/*     */             }
/*     */ 
/* 107 */             result.put(tmpStr, impl);
/* 108 */             real.put(impl, tmpStr);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 115 */       getServiceMethod = "CLASS";
/*     */     }
/*     */     else
/*     */     {
/* 119 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.generateejb_by_sv"));
/*     */ 
/* 122 */       for (Iterator iter = getFiles().iterator(); iter.hasNext(); ) {
/* 123 */         File item = (File)iter.next();
/*     */ 
/* 125 */         String prefix = StringUtils.substringBefore(item.getPath(), "com" + System.getProperty("file.separator"));
/* 126 */         String tmpStr = StringUtils.replace(item.getPath(), prefix, "");
/* 127 */         tmpStr = StringUtils.replace(tmpStr, ".class", "");
/* 128 */         tmpStr = StringUtils.replace(tmpStr, System.getProperty("file.separator"), ".");
/*     */ 
/* 130 */         if ((tmpStr.indexOf(".interfaces.") >= 0) && (tmpStr.indexOf("Constant") < 0) && (tmpStr.endsWith("SV"))) {
/* 131 */           String impl = null;
/*     */           try {
/* 133 */             impl = MiscHelper.getImplClassByInterClassName(tmpStr).getName();
/*     */           }
/*     */           catch (Throwable ex) {
/* 136 */             if (isFailonerror()) {
/* 137 */               throw new Exception(ex);
/*     */             }
/*     */ 
/* 140 */             log("generator src error:" + ExceptionUtils.getFullStackTrace(ex).toString());
/*     */           }
/*     */ 
/* 144 */           result.put(tmpStr, impl);
/*     */ 
/* 146 */           real.put(impl, tmpStr);
/*     */         }
/*     */       }
/*     */ 
/* 150 */       getServiceMethod = "CLASS";
/*     */     }
/*     */ 
/* 153 */     String interfaceName = null;
/* 154 */     List errors = new ArrayList();
/* 155 */     int success = 0;
/* 156 */     int fail = 0;
/* 157 */     for (Iterator it = result.keySet().iterator(); it.hasNext(); ) {
/* 158 */       interfaceName = (String)it.next();
/*     */ 
/* 160 */       String implName = (String)result.get(interfaceName);
/*     */       try {
/* 162 */         Class.forName(implName);
/*     */       }
/*     */       catch (Throwable ex) {
/* 165 */         real.remove(implName);
/*     */ 
/* 167 */         log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.ejb_class_instance_error", new String[] { implName, interfaceName }));
/* 168 */         ex.printStackTrace();
/* 169 */         ++fail;
/* 170 */       }continue;
/*     */ 
/* 173 */       String tmpPackage = interfaceName.replaceAll(".interfaces.", ".ejb.");
/* 174 */       tmpPackage = tmpPackage.substring(0, tmpPackage.lastIndexOf('.'));
/*     */       try
/*     */       {
/* 177 */         CreateEJB g = new CreateEJB(destPath, tmpVmConfig, tmpPackage, interfaceName, implName, this.isThrowRemoteException);
/* 178 */         g.generatorEJBService();
/*     */ 
/* 180 */         g.generatorRemoteHomeInterface();
/* 181 */         g.generatorRemoteInterface();
/* 182 */         g.generatorEJBClient();
/* 183 */         ++success;
/*     */       }
/*     */       catch (Throwable e) {
/* 186 */         real.remove(implName);
/* 187 */         ++fail;
/*     */ 
/* 190 */         errors.add(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.create_service_error", new String[] { interfaceName, "EJB" }));
/* 191 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 195 */     if (success > 0)
/*     */     {
/* 197 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.ejb_generate_succeed", new String[] { success + "" }));
/*     */     }
/* 199 */     if (fail > 0)
/*     */     {
/* 201 */       log(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.ejb_generate_failed", new String[] { fail + "" }));
/*     */     }
/*     */ 
/* 205 */     if (getServiceMethod.equalsIgnoreCase("CLASS")) {
/* 206 */       boolean isExist = false;
/* 207 */       File f = new File(this.destPath);
/* 208 */       String[] tmp = f.list();
/* 209 */       for (int i = 0; i < tmp.length; ++i) {
/* 210 */         if (tmp[i].equals("sv_class.txt")) {
/* 211 */           isExist = true;
/* 212 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 216 */       List l = new ArrayList();
/* 217 */       Set s = real.keySet();
/* 218 */       for (Iterator iter = s.iterator(); iter.hasNext(); ) {
/* 219 */         String item = (String)iter.next();
/* 220 */         l.add(real.get(item) + "=" + real.get(item));
/*     */       }
/*     */ 
/* 223 */       if (isExist) {
/* 224 */         List _l = FileUtils.readLines(new File(this.destPath + "/sv_class.txt"), "GBK");
/* 225 */         l.addAll(_l);
/* 226 */         FileUtils.writeLines(new File(this.destPath + "/sv_class.txt"), "GBK", l);
/*     */       }
/*     */       else {
/* 229 */         FileUtils.writeLines(new File(this.destPath + "/sv_class.txt"), "GBK", l);
/*     */       }
/*     */     }
/* 232 */     else if (getServiceMethod.equalsIgnoreCase("ID")) {
/* 233 */       boolean isExist = false;
/* 234 */       File f = new File(this.destPath);
/* 235 */       String[] tmp = f.list();
/* 236 */       for (int i = 0; i < tmp.length; ++i) {
/* 237 */         if (tmp[i].equals("sv_id.txt")) {
/* 238 */           isExist = true;
/* 239 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 243 */       List l = new ArrayList();
/* 244 */       Set s = real.keySet();
/* 245 */       for (Iterator iter = s.iterator(); iter.hasNext(); ) {
/* 246 */         String item = (String)iter.next();
/* 247 */         l.add(real.get(item) + "=" + real.get(item));
/*     */       }
/*     */ 
/* 250 */       if (isExist) {
/* 251 */         List _l = FileUtils.readLines(new File(this.destPath + "/sv_id.txt"), "GBK");
/* 252 */         l.addAll(_l);
/* 253 */         FileUtils.writeLines(new File(this.destPath + "/sv_id.txt"), "GBK", l);
/*     */       }
/*     */       else {
/* 256 */         FileUtils.writeLines(new File(this.destPath + "/sv_id.txt"), "GBK", l);
/*     */       }
/*     */     }
/*     */ 
/* 260 */     return (String[])(String[])errors.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */     throws BuildException
/*     */   {
/* 269 */     ClassLoader old = Thread.currentThread().getContextClassLoader();
/*     */     try {
/* 271 */       Thread.currentThread().setContextClassLoader(EJBGeneratorAntTask.class.getClassLoader());
/* 272 */       if (StringUtils.isBlank(this.destPath))
/*     */       {
/* 275 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "destPath" }));
/*     */       }
/* 277 */       if (StringUtils.isBlank(this.vmConfigPath))
/*     */       {
/* 280 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.ant.Task.cannot_null", new String[] { "vmConfigPath" }));
/*     */       }
/*     */ 
/* 283 */       String[] result = createEJB(this.destPath, this.vmConfigPath, this.type);
/*     */ 
/* 285 */       for (int i = 0; i < result.length; ++i) {
/* 286 */         System.out.println(result[i]);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 294 */       if (old != null)
/* 295 */         Thread.currentThread().setContextClassLoader(old);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getDestPath()
/*     */   {
/* 302 */     return this.destPath;
/*     */   }
/*     */ 
/*     */   public String getSourcePath() {
/* 306 */     return this.sourcePath;
/*     */   }
/*     */ 
/*     */   public void setSourcePath(String sourcePath) {
/* 310 */     this.sourcePath = sourcePath;
/*     */   }
/*     */ 
/*     */   public void setDestPath(String destPath) {
/* 314 */     this.destPath = destPath;
/*     */   }
/*     */ 
/*     */   public void addFileset(FileSet fileSet)
/*     */   {
/* 326 */     this.fileSets.add(fileSet);
/*     */   }
/*     */ 
/*     */   public void setFilename(String filename) {
/* 330 */     this.filename = filename;
/*     */   }
/*     */ 
/*     */   private List getFiles() {
/* 334 */     List files = new LinkedList();
/* 335 */     for (Iterator i = this.fileSets.iterator(); i.hasNext(); )
/*     */     {
/* 337 */       FileSet fs = (FileSet)i.next();
/* 338 */       DirectoryScanner ds = fs.getDirectoryScanner(getProject());
/*     */ 
/* 340 */       String[] dsFiles = ds.getIncludedFiles();
/* 341 */       for (int j = 0; j < dsFiles.length; ++j) {
/* 342 */         File f = new File(dsFiles[j]);
/* 343 */         if (!f.isFile()) {
/* 344 */           f = new File(ds.getBasedir(), dsFiles[j]);
/*     */         }
/*     */ 
/* 347 */         files.add(f);
/*     */       }
/*     */     }
/*     */ 
/* 351 */     return files;
/*     */   }
/*     */ 
/*     */   public String getVmConfigPath() {
/* 355 */     return this.vmConfigPath;
/*     */   }
/*     */ 
/*     */   public void setVmConfigPath(String vmConfigPath) {
/* 359 */     this.vmConfigPath = vmConfigPath;
/*     */   }
/*     */   public String getType() {
/* 362 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean isFailonerror() {
/* 366 */     boolean rtn = true;
/* 367 */     if (!StringUtils.isBlank(getFailonerror())) {
/* 368 */       if (getFailonerror().trim().equalsIgnoreCase("true")) {
/* 369 */         rtn = true;
/*     */       }
/*     */       else {
/* 372 */         rtn = false;
/*     */       }
/*     */     }
/* 375 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String getFailonerror() {
/* 379 */     return this.failonerror;
/*     */   }
/*     */ 
/*     */   public String getIsThrowRemoteException() {
/* 383 */     return this.isThrowRemoteException;
/*     */   }
/*     */ 
/*     */   public void setType(String type) {
/* 387 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public void setFailonerror(String failonerror) {
/* 391 */     this.failonerror = failonerror;
/*     */   }
/*     */ 
/*     */   public void setIsThrowRemoteException(String isThrowRemoteException) {
/* 395 */     this.isThrowRemoteException = isThrowRemoteException;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 399 */     JarInputStream jis = new JarInputStream(new BufferedInputStream(new FileInputStream("D:/work/hamcc/lib/appframe/appframe.jar")));
/* 400 */     JarEntry jarEntry = null;
/* 401 */     while ((jarEntry = jis.getNextJarEntry()) != null) {
/* 402 */       if (!jarEntry.isDirectory());
/* 403 */       String tmpStr = jarEntry.getName();
/* 404 */       tmpStr = StringUtils.replace(tmpStr, ".class", "");
/* 405 */       tmpStr = StringUtils.replace(tmpStr, "/", ".");
/*     */ 
/* 407 */       if ((tmpStr.indexOf(".interfaces.") >= 0) && (tmpStr.indexOf("Constant") < 0) && (tmpStr.endsWith("SV")))
/*     */       {
/* 409 */         System.out.println("Interface:" + tmpStr);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.ant.EJBGeneratorAntTask
 * JD-Core Version:    0.5.4
 */