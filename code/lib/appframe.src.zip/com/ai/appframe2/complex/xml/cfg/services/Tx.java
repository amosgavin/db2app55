/*    */ package com.ai.appframe2.complex.xml.cfg.services;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Tx
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addMethod(Method method)
/*    */   {
/* 21 */     this.list.add(method);
/*    */   }
/*    */   public Method[] getMethods() {
/* 24 */     return (Method[])(Method[])this.list.toArray(new Method[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.services.Tx
 * JD-Core Version:    0.5.4
 */