/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.e.K;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class Property
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */   private Ref ref;
/*    */   private String type;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 23 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 26 */     this.name = name;
/*    */   }
/*    */   public String getValue() {
/* 29 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) throws Exception {
/* 33 */     if (!StringUtils.isBlank(value)) {
/* 34 */       this.value = K.k_s(value);
/*    */     }
/*    */     else
/* 37 */       this.value = value;
/*    */   }
/*    */ 
/*    */   public void setRef(Ref ref) {
/* 41 */     this.ref = ref;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 45 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 48 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Property
 * JD-Core Version:    0.5.4
 */