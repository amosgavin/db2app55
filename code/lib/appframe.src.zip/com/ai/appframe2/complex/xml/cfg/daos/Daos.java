/*    */ package com.ai.appframe2.complex.xml.cfg.daos;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Daos
/*    */ {
/*  7 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addDao(Dao dao)
/*    */   {
/* 12 */     this.list.add(dao);
/*    */   }
/*    */ 
/*    */   public Dao[] getDaos() {
/* 16 */     return (Dao[])(Dao[])this.list.toArray(new Dao[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.daos.Daos
 * JD-Core Version:    0.5.4
 */