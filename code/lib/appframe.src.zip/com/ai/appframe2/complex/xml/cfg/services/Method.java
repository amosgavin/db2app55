/*    */ package com.ai.appframe2.complex.xml.cfg.services;
/*    */ 
/*    */ public class Method
/*    */ {
/*    */   private String name;
/*    */   private String txattr;
/*    */ 
/*    */   public String getName()
/*    */   {
/*  9 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 12 */     this.name = name;
/*    */   }
/*    */   public String getTxattr() {
/* 15 */     return this.txattr;
/*    */   }
/*    */   public void setTxattr(String txattr) {
/* 18 */     this.txattr = txattr;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.services.Method
 * JD-Core Version:    0.5.4
 */