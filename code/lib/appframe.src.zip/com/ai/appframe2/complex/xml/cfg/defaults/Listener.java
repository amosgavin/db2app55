/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ public class Listener
/*    */ {
/*    */   private String name;
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/*  9 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 13 */     return this.name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Listener
 * JD-Core Version:    0.5.4
 */