/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Transaction
/*    */ {
/* 17 */   private List list = new ArrayList();
/* 18 */   private Clazz clazz = null;
/* 19 */   private Mapping mapping = null;
/* 20 */   private String type = null;
/*    */ 
/*    */   public Clazz getClazz()
/*    */   {
/* 26 */     return this.clazz;
/*    */   }
/*    */   public void setClazz(Clazz clazz) {
/* 29 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */   public Mapping getMapping() {
/* 33 */     return this.mapping;
/*    */   }
/*    */   public void setMapping(Mapping mapping) {
/* 36 */     this.mapping = mapping;
/*    */   }
/*    */   public String getType() {
/* 39 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 42 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void addListener(Listener listener) {
/* 46 */     this.list.add(listener);
/*    */   }
/*    */ 
/*    */   public Listener[] getListeners() {
/* 50 */     return (Listener[])(Listener[])this.list.toArray(new Listener[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Transaction
 * JD-Core Version:    0.5.4
 */