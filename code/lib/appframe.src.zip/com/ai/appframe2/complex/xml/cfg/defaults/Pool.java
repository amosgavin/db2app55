/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Pool
/*    */ {
/* 16 */   private List list = new ArrayList();
/* 17 */   private String name = null;
/* 18 */   private String type = null;
/* 19 */   private String db = null;
/*    */   private String primary;
/*    */   private String init;
/* 22 */   private String template = null;
/*    */   private String isAdvanceUrl;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 29 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 33 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 37 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 41 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public String getDb() {
/* 45 */     return this.db;
/*    */   }
/*    */ 
/*    */   public void setDb(String db) {
/* 49 */     this.db = db;
/*    */   }
/*    */ 
/*    */   public void addProperty(Property property) {
/* 53 */     this.list.add(property);
/*    */   }
/*    */ 
/*    */   public Property[] getProperties() {
/* 57 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */   public String getPrimary() {
/* 60 */     return this.primary;
/*    */   }
/*    */   public void setPrimary(String primary) {
/* 63 */     this.primary = primary;
/*    */   }
/*    */   public String getInit() {
/* 66 */     return this.init;
/*    */   }
/*    */   public void setInit(String init) {
/* 69 */     this.init = init;
/*    */   }
/*    */   public String getTemplate() {
/* 72 */     return this.template;
/*    */   }
/*    */   public void setTemplate(String template) {
/* 75 */     this.template = template;
/*    */   }
/*    */   public String getIsAdvanceUrl() {
/* 78 */     return this.isAdvanceUrl;
/*    */   }
/*    */   public void setIsAdvanceUrl(String isAdvanceUrl) {
/* 81 */     this.isAdvanceUrl = isAdvanceUrl;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Pool
 * JD-Core Version:    0.5.4
 */