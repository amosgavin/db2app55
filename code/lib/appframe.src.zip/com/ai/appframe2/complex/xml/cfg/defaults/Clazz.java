/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Clazz
/*    */ {
/* 16 */   private List list = new ArrayList();
/* 17 */   private String name = null;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 21 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 24 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void addProperty(Property property)
/*    */   {
/* 29 */     this.list.add(property);
/*    */   }
/*    */ 
/*    */   public Property[] getProperties() {
/* 33 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Clazz
 * JD-Core Version:    0.5.4
 */