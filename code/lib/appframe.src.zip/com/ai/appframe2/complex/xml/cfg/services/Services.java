/*    */ package com.ai.appframe2.complex.xml.cfg.services;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Services
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addService(Service service)
/*    */   {
/* 21 */     this.list.add(service);
/*    */   }
/*    */ 
/*    */   public Service[] getServices() {
/* 25 */     return (Service[])(Service[])this.list.toArray(new Service[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.services.Services
 * JD-Core Version:    0.5.4
 */