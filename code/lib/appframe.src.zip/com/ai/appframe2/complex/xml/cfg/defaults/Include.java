/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ public class Include
/*    */ {
/*    */   private String classpath;
/*    */   private String type;
/*    */ 
/*    */   public String getClasspath()
/*    */   {
/* 18 */     return this.classpath;
/*    */   }
/*    */   public void setClasspath(String classpath) {
/* 21 */     this.classpath = classpath;
/*    */   }
/*    */   public String getType() {
/* 24 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 27 */     this.type = type;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Include
 * JD-Core Version:    0.5.4
 */