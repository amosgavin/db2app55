/*     */ package com.ai.appframe2.complex.xml;
/*     */ 
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Cache;
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Caches;
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Quartz;
/*     */ import com.ai.appframe2.complex.xml.cfg.daos.Dao;
/*     */ import com.ai.appframe2.complex.xml.cfg.daos.Daos;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Center;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.DataSource;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Env;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Include;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Interceptor;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Listener;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Mapping;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Pool;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Proxy;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Ref;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Method;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Service;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Services;
/*     */ import com.ai.appframe2.complex.xml.cfg.services.Tx;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class XMLHelper
/*     */ {
/*  50 */   private static XMLHelper instance = null;
/*     */ 
/*  52 */   private static Defaults defaults = null;
/*  53 */   private static Service[] services = null;
/*  54 */   private static Dao[] daos = null;
/*  55 */   private static Caches caches = null;
/*     */ 
/*  57 */   private static Boolean isInit = Boolean.FALSE;
/*     */ 
/*  59 */   private static Boolean isServiceInit = Boolean.FALSE;
/*  60 */   private static Boolean isDaoInit = Boolean.FALSE;
/*  61 */   private static Boolean isCacheInit = Boolean.FALSE;
/*     */ 
/*     */   public static XMLHelper getInstance()
/*     */     throws Exception
/*     */   {
/*  76 */     if (isInit.equals(Boolean.FALSE)) {
/*  77 */       synchronized (isInit) {
/*  78 */         if (isInit.equals(Boolean.FALSE)) {
/*  79 */           defaults = createDefaults();
/*     */ 
/*  81 */           isInit = Boolean.TRUE;
/*     */         }
/*     */       }
/*  84 */       instance = new XMLHelper();
/*     */     }
/*  86 */     return instance;
/*     */   }
/*     */ 
/*     */   public Defaults getDefaults()
/*     */   {
/*  95 */     return defaults;
/*     */   }
/*     */ 
/*     */   public Service[] getServices()
/*     */   {
/* 103 */     if (services == null) {
/* 104 */       synchronized (isServiceInit) {
/* 105 */         if (isServiceInit.equals(Boolean.FALSE)) {
/*     */           try {
/* 107 */             services = createServices();
/* 108 */             isServiceInit = Boolean.TRUE;
/*     */           }
/*     */           catch (Throwable ex) {
/* 111 */             throw new RuntimeException(ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 116 */     return services;
/*     */   }
/*     */ 
/*     */   public Dao[] getDaos()
/*     */   {
/* 124 */     if (daos == null) {
/* 125 */       synchronized (isDaoInit) {
/* 126 */         if (isDaoInit.equals(Boolean.FALSE)) {
/*     */           try {
/* 128 */             daos = createDaos();
/* 129 */             isDaoInit = Boolean.TRUE;
/*     */           }
/*     */           catch (Throwable ex) {
/* 132 */             throw new RuntimeException(ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 137 */     return daos;
/*     */   }
/*     */ 
/*     */   public Caches getCaches()
/*     */   {
/* 145 */     if (caches == null) {
/* 146 */       synchronized (isCacheInit) {
/* 147 */         if (isCacheInit.equals(Boolean.FALSE)) {
/*     */           try {
/* 149 */             caches = createCaches();
/* 150 */             isCacheInit = Boolean.TRUE;
/*     */           }
/*     */           catch (Throwable ex) {
/* 153 */             throw new RuntimeException(ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 158 */     return caches;
/*     */   }
/*     */ 
/*     */   private static Defaults createDefaults()
/*     */     throws Exception
/*     */   {
/* 167 */     Defaults rtn = null;
/*     */ 
/* 169 */     String defaultsFileName = "system/service/defaults.xml";
/* 170 */     if (!StringUtils.isBlank(System.getProperty("appframe.service.default.filename"))) {
/* 171 */       defaultsFileName = System.getProperty("appframe.service.default.filename").trim();
/* 172 */       System.out.println("Use defaults.xml:" + defaultsFileName);
/*     */     }
/*     */ 
/* 175 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(defaultsFileName);
/*     */ 
/* 177 */     if (input == null)
/*     */     {
/* 179 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { defaultsFileName });
/*     */ 
/* 181 */       throw new Exception(msg);
/*     */     }
/*     */ 
/* 184 */     Digester digester = new Digester();
/*     */ 
/* 186 */     digester.setValidating(false);
/* 187 */     digester.addObjectCreate("defaults", Defaults.class.getName());
/* 188 */     digester.addSetProperties("defaults");
/*     */ 
/* 191 */     digester.addObjectCreate("defaults/center", Center.class.getName());
/* 192 */     digester.addSetProperties("defaults/center");
/*     */ 
/* 194 */     digester.addObjectCreate("defaults/center/property", Property.class.getName());
/* 195 */     digester.addSetProperties("defaults/center/property");
/*     */ 
/* 198 */     digester.addObjectCreate("defaults/interceptor", Interceptor.class.getName());
/* 199 */     digester.addSetProperties("defaults/interceptor");
/*     */ 
/* 201 */     digester.addObjectCreate("defaults/interceptor/clazz", Clazz.class.getName());
/* 202 */     digester.addSetProperties("defaults/interceptor/clazz");
/*     */ 
/* 204 */     digester.addObjectCreate("defaults/interceptor/clazz/property", Property.class.getName());
/* 205 */     digester.addSetProperties("defaults/interceptor/clazz/property");
/*     */ 
/* 208 */     digester.addObjectCreate("defaults/proxy", Proxy.class.getName());
/* 209 */     digester.addSetProperties("defaults/proxy");
/*     */ 
/* 211 */     digester.addObjectCreate("defaults/proxy/clazz", Clazz.class.getName());
/* 212 */     digester.addSetProperties("defaults/proxy/clazz");
/*     */ 
/* 214 */     digester.addObjectCreate("defaults/proxy/clazz/property", Property.class.getName());
/* 215 */     digester.addSetProperties("defaults/proxy/clazz/property");
/*     */ 
/* 217 */     digester.addObjectCreate("defaults/proxy/env", Env.class.getName());
/* 218 */     digester.addSetProperties("defaults/proxy/env");
/*     */ 
/* 220 */     digester.addObjectCreate("defaults/proxy/env/property", Property.class.getName());
/* 221 */     digester.addSetProperties("defaults/proxy/env/property");
/*     */ 
/* 224 */     digester.addObjectCreate("defaults/transaction", Transaction.class.getName());
/* 225 */     digester.addSetProperties("defaults/transaction");
/*     */ 
/* 227 */     digester.addObjectCreate("defaults/transaction/clazz", Clazz.class.getName());
/* 228 */     digester.addSetProperties("defaults/transaction/clazz");
/*     */ 
/* 230 */     digester.addObjectCreate("defaults/transaction/listener", Listener.class.getName());
/* 231 */     digester.addSetProperties("defaults/transaction/listener");
/*     */ 
/* 234 */     digester.addObjectCreate("defaults/transaction/clazz/property", Property.class.getName());
/* 235 */     digester.addSetProperties("defaults/transaction/clazz/property");
/*     */ 
/* 237 */     digester.addObjectCreate("defaults/transaction/mapping", Mapping.class.getName());
/* 238 */     digester.addSetProperties("defaults/transaction/mapping");
/*     */ 
/* 240 */     digester.addObjectCreate("defaults/transaction/mapping/property", Property.class.getName());
/* 241 */     digester.addSetProperties("defaults/transaction/mapping/property");
/*     */ 
/* 244 */     digester.addObjectCreate("defaults/datasource", DataSource.class.getName());
/* 245 */     digester.addSetProperties("defaults/datasource");
/*     */ 
/* 247 */     digester.addObjectCreate("defaults/datasource/clazz", Clazz.class.getName());
/* 248 */     digester.addSetProperties("defaults/datasource/clazz");
/*     */ 
/* 250 */     digester.addObjectCreate("defaults/datasource/clazz/property", Property.class.getName());
/* 251 */     digester.addSetProperties("defaults/datasource/clazz/property");
/*     */ 
/* 253 */     digester.addObjectCreate("defaults/datasource/pool", Pool.class.getName());
/* 254 */     digester.addSetProperties("defaults/datasource/pool");
/*     */ 
/* 256 */     digester.addObjectCreate("defaults/datasource/pool/property", Property.class.getName());
/* 257 */     digester.addSetProperties("defaults/datasource/pool/property");
/*     */ 
/* 259 */     digester.addObjectCreate("defaults/datasource/mapping", Mapping.class.getName());
/* 260 */     digester.addSetProperties("defaults/datasource/mapping");
/*     */ 
/* 262 */     digester.addObjectCreate("defaults/datasource/mapping/property", Property.class.getName());
/* 263 */     digester.addSetProperties("defaults/datasource/mapping/property");
/*     */ 
/* 266 */     digester.addObjectCreate("defaults/include", Include.class.getName());
/* 267 */     digester.addSetProperties("defaults/include");
/*     */ 
/* 270 */     digester.addSetNext("defaults/center", "setCenter", Center.class.getName());
/* 271 */     digester.addSetNext("defaults/proxy", "setProxy", Proxy.class.getName());
/* 272 */     digester.addSetNext("defaults/transaction", "setTransaction", Transaction.class.getName());
/* 273 */     digester.addSetNext("defaults/datasource", "setDatasource", DataSource.class.getName());
/* 274 */     digester.addSetNext("defaults/include", "addInclude", Include.class.getName());
/*     */ 
/* 276 */     digester.addSetNext("defaults/center/property", "addProperty", Property.class.getName());
/*     */ 
/* 280 */     digester.addSetNext("defaults/interceptor", "setInterceptor", Interceptor.class.getName());
/* 281 */     digester.addSetNext("defaults/interceptor/clazz", "addClazz", Clazz.class.getName());
/* 282 */     digester.addSetNext("defaults/interceptor/clazz/property", "addProperty", Property.class.getName());
/*     */ 
/* 285 */     digester.addSetNext("defaults/proxy/clazz", "setClazz", Clazz.class.getName());
/* 286 */     digester.addSetNext("defaults/proxy/clazz/property", "addProperty", Property.class.getName());
/* 287 */     digester.addSetNext("defaults/proxy/env", "addEnv", Env.class.getName());
/* 288 */     digester.addSetNext("defaults/proxy/env/property", "addProperty", Property.class.getName());
/*     */ 
/* 290 */     digester.addSetNext("defaults/transaction/clazz", "setClazz", Clazz.class.getName());
/*     */ 
/* 292 */     digester.addSetNext("defaults/transaction/clazz/property", "addProperty", Property.class.getName());
/* 293 */     digester.addSetNext("defaults/transaction/listener", "addListener", Listener.class.getName());
/* 294 */     digester.addSetNext("defaults/transaction/mapping", "setMapping", Mapping.class.getName());
/* 295 */     digester.addSetNext("defaults/transaction/mapping/property", "addProperty", Property.class.getName());
/*     */ 
/* 297 */     digester.addSetNext("defaults/datasource/clazz", "setClazz", Clazz.class.getName());
/* 298 */     digester.addSetNext("defaults/datasource/clazz/property", "addProperty", Property.class.getName());
/* 299 */     digester.addSetNext("defaults/datasource/pool", "addPool", Pool.class.getName());
/* 300 */     digester.addSetNext("defaults/datasource/pool/property", "addProperty", Property.class.getName());
/* 301 */     digester.addSetNext("defaults/datasource/mapping", "setMapping", Mapping.class.getName());
/* 302 */     digester.addSetNext("defaults/datasource/mapping/property", "addProperty", Property.class.getName());
/*     */ 
/* 304 */     rtn = (Defaults)digester.parse(input);
/* 305 */     return rtn;
/*     */   }
/*     */ 
/*     */   private static Service[] createServices()
/*     */     throws Exception
/*     */   {
/* 314 */     HashMap serviceMap = new HashMap();
/* 315 */     Include[] includes = defaults.getIncludes();
/* 316 */     for (int i = 0; i < includes.length; ++i) {
/* 317 */       if (includes[i].getType().equalsIgnoreCase("sv")) {
/* 318 */         Services services = null;
/* 319 */         InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(includes[i].getClasspath());
/*     */ 
/* 321 */         if (input == null)
/*     */         {
/* 324 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { includes[i].getClasspath() }));
/*     */         }
/*     */ 
/* 327 */         Digester digester = new Digester();
/*     */ 
/* 329 */         digester.setValidating(false);
/* 330 */         digester.addObjectCreate("services", Services.class.getName());
/* 331 */         digester.addSetProperties("services");
/*     */ 
/* 333 */         digester.addObjectCreate("services/service", Service.class.getName());
/* 334 */         digester.addSetProperties("services/service");
/*     */ 
/* 336 */         digester.addObjectCreate("services/service/property", Property.class.getName());
/* 337 */         digester.addSetProperties("services/service/property");
/*     */ 
/* 339 */         digester.addObjectCreate("services/service/property/ref", Ref.class.getName());
/* 340 */         digester.addSetProperties("services/service/property/ref");
/*     */ 
/* 342 */         digester.addObjectCreate("services/service/tx", Tx.class.getName());
/* 343 */         digester.addSetProperties("services/service/tx");
/*     */ 
/* 345 */         digester.addObjectCreate("services/service/tx/method", Method.class.getName());
/* 346 */         digester.addSetProperties("services/service/tx/method");
/*     */ 
/* 349 */         digester.addSetNext("services/service", "addService", Service.class.getName());
/* 350 */         digester.addSetNext("services/service/property", "addProperty", Property.class.getName());
/* 351 */         digester.addSetNext("services/service/property/ref", "setRef", Ref.class.getName());
/* 352 */         digester.addSetNext("services/service/tx", "setTx", Tx.class.getName());
/* 353 */         digester.addSetNext("services/service/tx/method", "addMethod", Method.class.getName());
/*     */ 
/* 355 */         services = (Services)digester.parse(input);
/*     */ 
/* 357 */         Service[] objService = services.getServices();
/* 358 */         for (int j = 0; j < objService.length; ++j) {
/* 359 */           if (serviceMap.containsKey(objService[j].getId()))
/*     */           {
/* 362 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.SV_double_define", new String[] { objService[j].getId() }));
/*     */           }
/*     */ 
/* 365 */           serviceMap.put(objService[j].getId(), objService[j]);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 371 */     List rtn = new ArrayList();
/* 372 */     Collection c = serviceMap.values();
/* 373 */     for (Iterator iter = c.iterator(); iter.hasNext(); ) {
/* 374 */       Service item = (Service)iter.next();
/* 375 */       rtn.add(item);
/*     */     }
/*     */ 
/* 378 */     return (Service[])(Service[])rtn.toArray(new Service[0]);
/*     */   }
/*     */ 
/*     */   private static Dao[] createDaos()
/*     */     throws Exception
/*     */   {
/* 388 */     HashMap daoMap = new HashMap();
/* 389 */     Include[] includes = defaults.getIncludes();
/* 390 */     for (int i = 0; i < includes.length; ++i) {
/* 391 */       if (includes[i].getType().equalsIgnoreCase("dao")) {
/* 392 */         Daos objDaos = null;
/* 393 */         InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(includes[i].getClasspath());
/*     */ 
/* 395 */         if (input == null)
/*     */         {
/* 398 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { includes[i].getClasspath() }));
/*     */         }
/*     */ 
/* 401 */         Digester digester = new Digester();
/*     */ 
/* 403 */         digester.setValidating(false);
/* 404 */         digester.addObjectCreate("daos", Daos.class.getName());
/* 405 */         digester.addSetProperties("daos");
/*     */ 
/* 407 */         digester.addObjectCreate("daos/dao", Dao.class.getName());
/* 408 */         digester.addSetProperties("daos/dao");
/*     */ 
/* 410 */         digester.addObjectCreate("daos/dao/property", Property.class.getName());
/* 411 */         digester.addSetProperties("daos/dao/property");
/*     */ 
/* 414 */         digester.addSetNext("daos/dao", "addDao", Dao.class.getName());
/* 415 */         digester.addSetNext("daos/dao/property", "addProperty", Property.class.getName());
/*     */ 
/* 417 */         objDaos = (Daos)digester.parse(input);
/*     */ 
/* 419 */         Dao[] objDao = objDaos.getDaos();
/* 420 */         for (int j = 0; j < objDao.length; ++j) {
/* 421 */           if (daoMap.containsKey(objDao[j].getId()))
/*     */           {
/* 424 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.DAO_double_define", new String[] { objDao[j].getId() }));
/*     */           }
/*     */ 
/* 427 */           daoMap.put(objDao[j].getId(), objDao[j]);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 433 */     List rtn = new ArrayList();
/* 434 */     Collection c = daoMap.values();
/* 435 */     for (Iterator iter = c.iterator(); iter.hasNext(); ) {
/* 436 */       Dao item = (Dao)iter.next();
/* 437 */       rtn.add(item);
/*     */     }
/*     */ 
/* 440 */     return (Dao[])(Dao[])rtn.toArray(new Dao[0]);
/*     */   }
/*     */ 
/*     */   private static Caches createCaches()
/*     */     throws Exception
/*     */   {
/* 449 */     Caches objDaos = null;
/*     */ 
/* 451 */     String cacheFileName = "system/cache/cache.xml";
/* 452 */     if (!StringUtils.isBlank(System.getProperty("appframe.cache.filename"))) {
/* 453 */       cacheFileName = System.getProperty("appframe.cache.filename").trim();
/* 454 */       System.out.println("Use the Specified cache.xml file:" + cacheFileName);
/*     */     }
/*     */ 
/* 457 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(cacheFileName);
/*     */ 
/* 459 */     if (input == null)
/*     */     {
/* 462 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { cacheFileName }));
/*     */     }
/*     */ 
/* 465 */     Digester digester = new Digester();
/*     */ 
/* 467 */     digester.setValidating(false);
/* 468 */     digester.addObjectCreate("caches", Caches.class.getName());
/* 469 */     digester.addSetProperties("caches");
/*     */ 
/* 471 */     digester.addObjectCreate("caches/quartz", Quartz.class.getName());
/* 472 */     digester.addSetProperties("caches/quartz");
/*     */ 
/* 474 */     digester.addObjectCreate("caches/quartz/property", Property.class.getName());
/* 475 */     digester.addSetProperties("caches/quartz/property");
/*     */ 
/* 477 */     digester.addObjectCreate("caches/cache", Cache.class.getName());
/* 478 */     digester.addSetProperties("caches/cache");
/*     */ 
/* 480 */     digester.addObjectCreate("caches/cache/property", Property.class.getName());
/* 481 */     digester.addSetProperties("caches/cache/property");
/*     */ 
/* 484 */     digester.addSetNext("caches/quartz", "setQuartz", Quartz.class.getName());
/* 485 */     digester.addSetNext("caches/quartz/property", "addProperty", Property.class.getName());
/*     */ 
/* 487 */     digester.addSetNext("caches/cache", "addCache", Cache.class.getName());
/* 488 */     digester.addSetNext("caches/cache/property", "addProperty", Property.class.getName());
/*     */ 
/* 490 */     objDaos = (Caches)digester.parse(input);
/*     */ 
/* 492 */     return objDaos;
/*     */   }
/*     */ 
/*     */   public static void main2(String[] args) throws Exception {
/* 496 */     Env[] env = getInstance().getDefaults().getProxy().getEnvs();
/* 497 */     for (int i = 0; i < env.length; ++i) {
/* 498 */       System.out.println(env[i].getProperties()[0].getName());
/* 499 */       System.out.println(env[i].getProperties().length);
/*     */     }
/*     */ 
/* 502 */     System.out.println(getInstance().getDefaults().getProxy().getClazz().getName());
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 506 */     getInstance().getDefaults();
/* 507 */     long start = System.currentTimeMillis();
/* 508 */     Defaults defaults = getInstance().getDefaults();
/*     */ 
/* 510 */     System.out.println(defaults.getCenter().getProperties().length);
/* 511 */     System.out.println("8888888888888888888888888888888");
/* 512 */     Pool[] p = defaults.getDatasource().getPools();
/* 513 */     for (int i = 0; i < p.length; ++i) {
/* 514 */       Property[] pa = p[i].getProperties();
/* 515 */       for (int j = 0; j < pa.length; ++j) {
/* 516 */         System.out.println(pa[j].getName() + ":" + pa[j].getValue());
/*     */       }
/* 518 */       System.out.println("=======================");
/*     */     }
/* 520 */     System.out.println("Time cost:" + (System.currentTimeMillis() - start) + ":ms");
/*     */ 
/* 522 */     Service[] s = getInstance().getServices();
/* 523 */     s = getInstance().getServices();
/* 524 */     for (int i = 0; i < s.length; ++i) {
/* 525 */       System.out.println(s[i].getId());
/*     */     }
/*     */ 
/* 528 */     System.out.println("******************************");
/* 529 */     Dao[] a = getInstance().getDaos();
/* 530 */     for (int i = 0; i < a.length; ++i)
/* 531 */       System.out.println(a[i].getId());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.XMLHelper
 * JD-Core Version:    0.5.4
 */