/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ public class Ref
/*    */ {
/*    */   private String name;
/*    */ 
/*    */   public String getName()
/*    */   {
/*  8 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 11 */     this.name = name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Ref
 * JD-Core Version:    0.5.4
 */