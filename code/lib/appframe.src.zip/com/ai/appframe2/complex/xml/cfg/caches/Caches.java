/*    */ package com.ai.appframe2.complex.xml.cfg.caches;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Caches
/*    */ {
/* 17 */   private List list = new ArrayList();
/*    */   private Quartz quartz;
/*    */ 
/*    */   public Quartz getQuartz()
/*    */   {
/* 24 */     return this.quartz;
/*    */   }
/*    */   public void setQuartz(Quartz quartz) {
/* 27 */     this.quartz = quartz;
/*    */   }
/*    */ 
/*    */   public void addCache(Cache cache) {
/* 31 */     this.list.add(cache);
/*    */   }
/*    */ 
/*    */   public Cache[] getCaches() {
/* 35 */     return (Cache[])(Cache[])this.list.toArray(new Cache[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.caches.Caches
 * JD-Core Version:    0.5.4
 */