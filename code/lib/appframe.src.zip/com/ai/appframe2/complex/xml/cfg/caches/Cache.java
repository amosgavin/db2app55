/*    */ package com.ai.appframe2.complex.xml.cfg.caches;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Cache
/*    */ {
/* 17 */   private List list = new ArrayList();
/*    */   private String id;
/* 19 */   private String init = "true";
/*    */ 
/*    */   public String getId()
/*    */   {
/* 25 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 28 */     this.id = id;
/*    */   }
/*    */   public String getInit() {
/* 31 */     return this.init;
/*    */   }
/*    */   public void setInit(String init) {
/* 34 */     this.init = init;
/*    */   }
/*    */ 
/*    */   public void addProperty(Property property)
/*    */   {
/* 39 */     this.list.add(property);
/*    */   }
/*    */   public Property[] getPropertys() {
/* 42 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.caches.Cache
 * JD-Core Version:    0.5.4
 */