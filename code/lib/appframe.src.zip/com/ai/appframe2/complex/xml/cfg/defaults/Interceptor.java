/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Interceptor
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addClazz(Clazz clazz)
/*    */   {
/* 22 */     this.list.add(clazz);
/*    */   }
/*    */ 
/*    */   public Clazz[] getClazzs() {
/* 26 */     return (Clazz[])(Clazz[])this.list.toArray(new Clazz[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Interceptor
 * JD-Core Version:    0.5.4
 */