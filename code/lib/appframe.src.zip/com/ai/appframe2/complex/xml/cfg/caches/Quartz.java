/*    */ package com.ai.appframe2.complex.xml.cfg.caches;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Quartz
/*    */ {
/* 17 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addProperty(Property property)
/*    */   {
/* 22 */     this.list.add(property);
/*    */   }
/*    */   public Property[] getPropertys() {
/* 25 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.caches.Quartz
 * JD-Core Version:    0.5.4
 */