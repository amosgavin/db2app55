/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Defaults
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */   private Transaction transaction;
/*    */   private Proxy proxy;
/*    */   private DataSource datasource;
/*    */   private Center center;
/*    */   private Interceptor interceptor;
/*    */ 
/*    */   public Proxy getProxy()
/*    */   {
/* 27 */     return this.proxy;
/*    */   }
/*    */   public void setProxy(Proxy proxy) {
/* 30 */     this.proxy = proxy;
/*    */   }
/*    */   public Transaction getTransaction() {
/* 33 */     return this.transaction;
/*    */   }
/*    */   public void setTransaction(Transaction transaction) {
/* 36 */     this.transaction = transaction;
/*    */   }
/*    */   public DataSource getDatasource() {
/* 39 */     return this.datasource;
/*    */   }
/*    */   public void setDatasource(DataSource datasource) {
/* 42 */     this.datasource = datasource;
/*    */   }
/*    */ 
/*    */   public void addInclude(Include include) {
/* 46 */     this.list.add(include);
/*    */   }
/*    */ 
/*    */   public Include[] getIncludes() {
/* 50 */     return (Include[])(Include[])this.list.toArray(new Include[0]);
/*    */   }
/*    */ 
/*    */   public void setInterceptor(Interceptor interceptor) {
/* 54 */     this.interceptor = interceptor;
/*    */   }
/*    */ 
/*    */   public Interceptor getInterceptor() {
/* 58 */     return this.interceptor;
/*    */   }
/*    */ 
/*    */   public Center getCenter()
/*    */   {
/* 63 */     return this.center;
/*    */   }
/*    */   public void setCenter(Center center) {
/* 66 */     this.center = center;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Defaults
 * JD-Core Version:    0.5.4
 */