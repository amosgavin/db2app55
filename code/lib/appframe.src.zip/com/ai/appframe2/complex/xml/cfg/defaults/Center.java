/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Center
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addProperty(Property property)
/*    */   {
/* 22 */     this.list.add(property);
/*    */   }
/*    */ 
/*    */   public Property[] getProperties() {
/* 26 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Center
 * JD-Core Version:    0.5.4
 */