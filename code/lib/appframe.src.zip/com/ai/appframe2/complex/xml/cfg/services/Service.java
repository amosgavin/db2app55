/*    */ package com.ai.appframe2.complex.xml.cfg.services;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Service
/*    */ {
/* 18 */   private List list = new ArrayList();
/*    */   private String id;
/*    */   private String invoke;
/*    */   private String type;
/*    */   private Tx tx;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 26 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 29 */     this.id = id;
/*    */   }
/*    */   public String getInvoke() {
/* 32 */     return this.invoke;
/*    */   }
/*    */   public void setInvoke(String invoke) {
/* 35 */     this.invoke = invoke;
/*    */   }
/*    */   public String getType() {
/* 38 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 41 */     this.type = type;
/*    */   }
/*    */   public void addProperty(Property property) {
/* 44 */     this.list.add(property);
/*    */   }
/*    */   public Property[] getPropertys() {
/* 47 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */   public Tx getTx() {
/* 50 */     return this.tx;
/*    */   }
/*    */   public void setTx(Tx tx) {
/* 53 */     this.tx = tx;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.services.Service
 * JD-Core Version:    0.5.4
 */