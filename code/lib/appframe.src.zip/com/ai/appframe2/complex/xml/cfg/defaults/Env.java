/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ 
/*    */ public class Env
/*    */ {
/*    */   public static final String CROSS_CENTER = "0";
/* 10 */   private List list = new ArrayList();
/*    */   private String name;
/*    */   private String center;
/*    */   private String group;
/*    */   private String bigdistrict;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 19 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 22 */     this.name = name;
/*    */   }
/*    */   public String getCenter() {
/* 25 */     return this.center;
/*    */   }
/*    */   public void setCenter(String center) {
/* 28 */     this.center = center;
/*    */   }
/*    */   public void addProperty(Property property) {
/* 31 */     this.list.add(property);
/*    */   }
/*    */ 
/*    */   public Property[] getProperties() {
/* 35 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */   public String getGroup() {
/* 38 */     return this.group;
/*    */   }
/*    */   public void setGroup(String group) {
/* 41 */     this.group = group;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     StringBuilder sb = new StringBuilder();
/* 46 */     if (StringUtils.isBlank(this.bigdistrict)) {
/* 47 */       sb.append("<env name=\"" + this.name + "\" center=\"" + this.center + "\" group=\"" + this.group + "\">\n");
/*    */     }
/*    */     else {
/* 50 */       sb.append("<env name=\"" + this.name + "\" center=\"" + this.center + "\" bigdistrict=\"" + this.bigdistrict + "\" group=\"" + this.group + "\">\n");
/*    */     }
/*    */ 
/* 53 */     for (Iterator iter = this.list.iterator(); iter.hasNext(); ) {
/* 54 */       Property item = (Property)iter.next();
/* 55 */       if (StringUtils.isBlank(item.getType())) {
/* 56 */         sb.append("<property name=\"" + item.getName() + "\" value=\"" + item.getValue() + "\"/>\n");
/*    */       }
/*    */       else {
/* 59 */         sb.append("<property name=\"" + item.getName() + "\" type=\"" + item.getType() + "\" value=\"" + item.getValue() + "\"/>\n");
/*    */       }
/*    */     }
/* 62 */     sb.append("</env>\n");
/* 63 */     return sb.toString();
/*    */   }
/*    */   public String getBigdistrict() {
/* 66 */     return this.bigdistrict;
/*    */   }
/*    */   public void setBigdistrict(String bigdistrict) {
/* 69 */     this.bigdistrict = bigdistrict;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Env
 * JD-Core Version:    0.5.4
 */