/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class DataSource
/*    */ {
/* 16 */   private List list = new ArrayList();
/* 17 */   private Clazz clazz = null;
/* 18 */   private Mapping mapping = null;
/*    */ 
/*    */   public Clazz getClazz()
/*    */   {
/* 24 */     return this.clazz;
/*    */   }
/*    */   public void setClazz(Clazz clazz) {
/* 27 */     this.clazz = clazz;
/*    */   }
/*    */ 
/*    */   public void addPool(Pool pool) {
/* 31 */     this.list.add(pool);
/*    */   }
/*    */ 
/*    */   public Pool[] getPools() {
/* 35 */     return (Pool[])(Pool[])this.list.toArray(new Pool[0]);
/*    */   }
/*    */ 
/*    */   public Mapping getMapping() {
/* 39 */     return this.mapping;
/*    */   }
/*    */   public void setMapping(Mapping mapping) {
/* 42 */     this.mapping = mapping;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.DataSource
 * JD-Core Version:    0.5.4
 */