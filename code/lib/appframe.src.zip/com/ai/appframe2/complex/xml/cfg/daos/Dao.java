/*    */ package com.ai.appframe2.complex.xml.cfg.daos;
/*    */ 
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Dao
/*    */ {
/* 17 */   private List list = new ArrayList();
/*    */   private String id;
/*    */   private String type;
/*    */ 
/*    */   public String getId()
/*    */   {
/* 23 */     return this.id;
/*    */   }
/*    */   public void setId(String id) {
/* 26 */     this.id = id;
/*    */   }
/*    */   public String getType() {
/* 29 */     return this.type;
/*    */   }
/*    */   public void setType(String type) {
/* 32 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public void addProperty(Property property) {
/* 36 */     this.list.add(property);
/*    */   }
/*    */   public Property[] getPropertys() {
/* 39 */     return (Property[])(Property[])this.list.toArray(new Property[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.daos.Dao
 * JD-Core Version:    0.5.4
 */