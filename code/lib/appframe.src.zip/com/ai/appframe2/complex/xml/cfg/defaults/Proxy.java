/*    */ package com.ai.appframe2.complex.xml.cfg.defaults;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Proxy
/*    */ {
/* 16 */   private List list = new ArrayList();
/*    */   private Clazz clazz;
/*    */ 
/*    */   public Clazz getClazz()
/*    */   {
/* 21 */     return this.clazz;
/*    */   }
/*    */   public void setClazz(Clazz clazz) {
/* 24 */     this.clazz = clazz;
/*    */   }
/*    */   public void addEnv(Env env) {
/* 27 */     this.list.add(env);
/*    */   }
/*    */ 
/*    */   public Env[] getEnvs() {
/* 31 */     return (Env[])(Env[])this.list.toArray(new Env[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.xml.cfg.defaults.Proxy
 * JD-Core Version:    0.5.4
 */