/*    */ package com.ai.appframe2.complex.secframe;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ import com.ai.appframe2.complex.trace.impl.WebTrace;
/*    */ import com.ai.secframe.bean.sysmgr.UserInfoDefaultImpl;
/*    */ 
/*    */ public class CenterUserInfoImpl extends UserInfoDefaultImpl
/*    */   implements ICenterUserInfo
/*    */ {
/* 17 */   private CenterInfo centerInfo = null;
/* 18 */   private String jvmid = null;
/* 19 */   private boolean isTrace = false;
/* 20 */   private WebTrace objWebTrace = null;
/* 21 */   private int timeoutSecond = -1;
/*    */ 
/*    */   public CenterInfo getCenterInfo()
/*    */   {
/* 32 */     return this.centerInfo;
/*    */   }
/*    */ 
/*    */   public void setCenterInfo(CenterInfo centerInfo)
/*    */   {
/* 40 */     this.centerInfo = centerInfo;
/*    */   }
/*    */ 
/*    */   public String getJvmid()
/*    */   {
/* 48 */     return this.jvmid;
/*    */   }
/*    */ 
/*    */   public int getTimeoutSecond() {
/* 52 */     return this.timeoutSecond;
/*    */   }
/*    */ 
/*    */   public void setJvmid(String jvmid)
/*    */   {
/* 60 */     this.jvmid = jvmid;
/*    */   }
/*    */ 
/*    */   public void setTimeoutSecond(int timeoutSecond) {
/* 64 */     this.timeoutSecond = timeoutSecond;
/*    */   }
/*    */ 
/*    */   public boolean isTrace() {
/* 68 */     return this.isTrace;
/*    */   }
/*    */ 
/*    */   public void setTrace(boolean isTrace) {
/* 72 */     this.isTrace = isTrace;
/*    */   }
/*    */ 
/*    */   public WebTrace getWebTrace()
/*    */   {
/* 77 */     return this.objWebTrace;
/*    */   }
/*    */ 
/*    */   public void setWebTrace(WebTrace objWebTrace) {
/* 81 */     this.objWebTrace = objWebTrace;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.CenterUserInfoImpl
 * JD-Core Version:    0.5.4
 */