/*    */ package com.ai.appframe2.complex.secframe.access;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class SecAccessFactory
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(SecAccessFactory.class);
/*    */ 
/* 24 */   private static ISecAccess INSTANCE = null;
/*    */ 
/*    */   public static ISecAccess getSecAccess()
/*    */   {
/* 65 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 28 */       String strSecAccessImplClass = AIConfigManager.getConfigItem("SEC_ACCESS_IMPL_CLASS");
/* 29 */       if (!StringUtils.isBlank(strSecAccessImplClass)) {
/*    */         try {
/* 31 */           Object custObject = Class.forName(strSecAccessImplClass.trim()).newInstance();
/* 32 */           if (custObject instanceof ISecAccess) {
/* 33 */             INSTANCE = (ISecAccess)custObject;
/*    */           }
/*    */           else
/* 36 */             INSTANCE = new BlankSecAccessImpl();
/*    */         }
/*    */         catch (Throwable ex)
/*    */         {
/* 40 */           INSTANCE = new BlankSecAccessImpl();
/* 41 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.secframe.access.factory.impl_error"), ex);
/*    */         }
/*    */       }
/*    */       else
/* 45 */         INSTANCE = new BlankSecAccessImpl();
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 49 */       INSTANCE = new BlankSecAccessImpl();
/* 50 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.secframe.access.factory.impl_error"), ex);
/*    */     }
/*    */     finally {
/* 53 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.secframe.access.factory.impl_class", new String[] { INSTANCE.getClass().toString() }));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.access.SecAccessFactory
 * JD-Core Version:    0.5.4
 */