package com.ai.appframe2.complex.secframe.access;

import java.util.HashMap;

public abstract interface ISecAccess
{
  public abstract HashMap getAllAccess()
    throws Exception;

  public abstract HashMap getStaffAccessByStaffId(long paramLong)
    throws Exception;

  public abstract boolean isEnable();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.access.ISecAccess
 * JD-Core Version:    0.5.4
 */