/*    */ package com.ai.appframe2.complex.secframe;
/*    */ 
/*    */ import com.ai.appframe2.privilege.UserInfoInterface;
/*    */ import com.ai.secframe.web.UserManagerDefaultImpl;
/*    */ 
/*    */ public class CenterUserManagerImpl extends UserManagerDefaultImpl
/*    */ {
/*    */   public UserInfoInterface getBlankUserInfo()
/*    */   {
/* 27 */     return new CenterUserInfoImpl();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.CenterUserManagerImpl
 * JD-Core Version:    0.5.4
 */