/*    */ package com.ai.appframe2.complex.secframe.access;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class BlankSecAccessImpl
/*    */   implements ISecAccess
/*    */ {
/*    */   public HashMap getAllAccess()
/*    */     throws Exception
/*    */   {
/* 25 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   public HashMap getStaffAccessByStaffId(long staffId)
/*    */     throws Exception
/*    */   {
/* 35 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   public boolean isEnable()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.access.BlankSecAccessImpl
 * JD-Core Version:    0.5.4
 */