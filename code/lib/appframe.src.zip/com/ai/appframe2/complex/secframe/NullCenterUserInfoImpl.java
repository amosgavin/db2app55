package com.ai.appframe2.complex.secframe;

public class NullCenterUserInfoImpl extends CenterUserInfoImpl
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.NullCenterUserInfoImpl
 * JD-Core Version:    0.5.4
 */