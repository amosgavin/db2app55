package com.ai.appframe2.complex.secframe;

import com.ai.appframe2.complex.center.CenterInfo;
import com.ai.appframe2.complex.trace.impl.WebTrace;

public abstract interface ICenterUserInfo
{
  public abstract CenterInfo getCenterInfo();

  public abstract void setCenterInfo(CenterInfo paramCenterInfo);

  public abstract String getJvmid();

  public abstract void setJvmid(String paramString);

  public abstract boolean isTrace();

  public abstract void setTrace(boolean paramBoolean);

  public abstract WebTrace getWebTrace();

  public abstract void setWebTrace(WebTrace paramWebTrace);

  public abstract int getTimeoutSecond();

  public abstract void setTimeoutSecond(int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.ICenterUserInfo
 * JD-Core Version:    0.5.4
 */