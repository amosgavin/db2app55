/*    */ package com.ai.appframe2.complex.secframe.access;
/*    */ 
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.secframe.service.sysmgr.interfaces.ISysFunction;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class HaSecAccessImpl
/*    */   implements ISecAccess
/*    */ {
/*    */   public HashMap getAllAccess()
/*    */     throws Exception
/*    */   {
/* 29 */     ISysFunction service = (ISysFunction)ServiceFactory.getService("com.ai.secframe.service.sysmgr.SysFunction");
/* 30 */     return service.getAllAccess();
/*    */   }
/*    */ 
/*    */   public HashMap getStaffAccessByStaffId(long staffId)
/*    */     throws Exception
/*    */   {
/* 40 */     ISysFunction service = (ISysFunction)ServiceFactory.getService("com.ai.secframe.service.sysmgr.SysFunction");
/* 41 */     return service.getStaffAccessByStaffId(staffId);
/*    */   }
/*    */ 
/*    */   public boolean isEnable()
/*    */   {
/* 49 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.secframe.access.HaSecAccessImpl
 * JD-Core Version:    0.5.4
 */