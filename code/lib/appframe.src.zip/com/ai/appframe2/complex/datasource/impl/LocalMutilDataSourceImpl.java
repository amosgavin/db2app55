/*     */ package com.ai.appframe2.complex.datasource.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.HashMap;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocalMutilDataSourceImpl extends AbstractLocalDataSourceImpl
/*     */   implements IDataSource
/*     */ {
/*  27 */   private static transient Log log = LogFactory.getLog(LocalMutilDataSourceImpl.class);
/*     */ 
/*     */   public LocalMutilDataSourceImpl()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public DataSource getDataSource(String ds)
/*     */     throws Exception
/*     */   {
/*  44 */     return (DataSource)DATASOURCE_MAP.get(ds.trim());
/*     */   }
/*     */ 
/*     */   public Connection getConnectionFromDataSource(String ds)
/*     */     throws Exception
/*     */   {
/*  54 */     Connection rtn = null;
/*     */     try {
/*  56 */       DataSource objDataSource = (DataSource)DATASOURCE_MAP.get(ds.trim());
/*  57 */       if (objDataSource == null) {
/*  58 */         if (URL_MAP.containsKey(ds))
/*     */         {
/*  60 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.getConnByds_error", new String[] { ds }));
/*     */         }
/*     */         else
/*     */         {
/*  64 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.getConnByds_failed", new String[] { ds }));
/*     */         }
/*     */       }
/*  67 */       rtn = objDataSource.getConnection();
/*  68 */       rtn.setAutoCommit(false);
/*     */     }
/*     */     catch (Exception ex) {
/*  71 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.getConnByds_failed", new String[] { ds }), ex);
/*  72 */       throw ex;
/*     */     }
/*     */ 
/*  75 */     if (log.isDebugEnabled()) {
/*     */       try
/*     */       {
/*  78 */         DatabaseMetaData dmd = rtn.getMetaData();
/*  79 */         if (dmd.getDatabaseProductName().toUpperCase().indexOf("ORACLE") != -1)
/*  80 */           printPhysicalConnectionInfo(rtn, ds);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*  84 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.print_physical"), ex);
/*     */       }
/*     */     }
/*     */ 
/*  88 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String getPrimaryDataSource()
/*     */     throws Exception
/*     */   {
/*  99 */     if (primaryDataSource == null)
/*     */     {
/* 102 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.miss_base_dsname"));
/*     */     }
/* 104 */     return primaryDataSource;
/*     */   }
/*     */ 
/*     */   private void printPhysicalConnectionInfo(Connection conn, String ds)
/*     */     throws Exception
/*     */   {
/* 114 */     PreparedStatement ptmt = null;
/* 115 */     ResultSet rs = null;
/*     */     try {
/* 117 */       ptmt = conn.prepareStatement("SELECT to_number(substr(dbms_session.unique_session_id,1,4),'xxxx') FROM dual");
/* 118 */       rs = ptmt.executeQuery();
/* 119 */       while (rs.next())
/*     */       {
/* 121 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.ds_sid_error", new String[] { ds, rs.getString(1) }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 128 */       if (rs != null) {
/* 129 */         rs.close();
/*     */       }
/* 131 */       if (ptmt != null)
/* 132 */         ptmt.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.impl.LocalMutilDataSourceImpl
 * JD-Core Version:    0.5.4
 */