/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class TraceConnection
/*     */   implements Connection
/*     */ {
/*  25 */   private Connection parentConnection = null;
/*     */ 
/*     */   public TraceConnection(Connection parentConnection)
/*     */   {
/*  33 */     if (parentConnection == null)
/*     */     {
/*  36 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.parent_connection_null"));
/*     */     }
/*  38 */     this.parentConnection = parentConnection;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  46 */     return AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.parent_connection") + ":" + this.parentConnection + "," + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.current_connection") + ":" + super.toString();
/*     */   }
/*     */ 
/*     */   public Statement createStatement()
/*     */     throws SQLException
/*     */   {
/*  56 */     return new TraceStatement(this.parentConnection.createStatement(), this.parentConnection.getMetaData().getUserName());
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/*  67 */     return new TracePreparedStatement(this.parentConnection.prepareStatement(sql), this.parentConnection.getMetaData().getUserName(), sql);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql)
/*     */     throws SQLException
/*     */   {
/*  79 */     return this.parentConnection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */   public String nativeSQL(String sql)
/*     */     throws SQLException
/*     */   {
/*  90 */     return this.parentConnection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {
/* 100 */     this.parentConnection.setAutoCommit(autoCommit);
/*     */   }
/*     */ 
/*     */   public boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 110 */     return this.parentConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws SQLException
/*     */   {
/* 120 */     this.parentConnection.commit();
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLException
/*     */   {
/* 130 */     this.parentConnection.rollback();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 140 */     this.parentConnection.close();
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 150 */     return this.parentConnection.isClosed();
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 161 */     return this.parentConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 171 */     this.parentConnection.setReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 181 */     return this.parentConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */   public void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {
/* 192 */     this.parentConnection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */   public String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 202 */     return this.parentConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   public void setTransactionIsolation(int level)
/*     */     throws SQLException
/*     */   {
/* 217 */     this.parentConnection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */   public int getTransactionIsolation()
/*     */     throws SQLException
/*     */   {
/* 230 */     return this.parentConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 240 */     return this.parentConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 249 */     this.parentConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 266 */     return this.parentConnection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 285 */     return this.parentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 304 */     return this.parentConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public Map getTypeMap()
/*     */     throws SQLException
/*     */   {
/* 314 */     return this.parentConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   public void setTypeMap(Map map)
/*     */     throws SQLException
/*     */   {
/* 326 */     this.parentConnection.setTypeMap(map);
/*     */   }
/*     */ 
/*     */   public void setHoldability(int holdability)
/*     */     throws SQLException
/*     */   {
/* 339 */     this.parentConnection.setHoldability(holdability);
/*     */   }
/*     */ 
/*     */   public int getHoldability()
/*     */     throws SQLException
/*     */   {
/* 351 */     return this.parentConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint()
/*     */     throws SQLException
/*     */   {
/* 363 */     return this.parentConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint(String name)
/*     */     throws SQLException
/*     */   {
/* 376 */     return this.parentConnection.setSavepoint(name);
/*     */   }
/*     */ 
/*     */   public void rollback(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 387 */     this.parentConnection.rollback(savepoint);
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 398 */     this.parentConnection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 418 */     return this.parentConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 440 */     return this.parentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 462 */     return this.parentConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 477 */     return this.parentConnection.prepareStatement(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 492 */     return this.parentConnection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 507 */     return this.parentConnection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.TraceConnection
 * JD-Core Version:    0.5.4
 */