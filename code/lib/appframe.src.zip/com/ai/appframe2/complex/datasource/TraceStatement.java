/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.complex.trace.TraceFactory;
/*     */ import com.ai.appframe2.complex.trace.impl.JdbcTrace;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class TraceStatement
/*     */   implements Statement
/*     */ {
/*  23 */   private static transient Log log = LogFactory.getLog(TraceStatement.class);
/*     */ 
/*  25 */   private Statement parent = null;
/*  26 */   private String username = null;
/*     */ 
/*     */   public TraceStatement(Statement parent, String username)
/*     */   {
/*  33 */     this.parent = parent;
/*  34 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/*  49 */     long start = System.currentTimeMillis();
/*  50 */     ResultSet rtn = this.parent.executeQuery(sql);
/*  51 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/*  53 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/*  70 */     long start = System.currentTimeMillis();
/*  71 */     int rtn = this.parent.executeUpdate(sql);
/*  72 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/*  74 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*  84 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/*  95 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/* 106 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 118 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 128 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 138 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 148 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 159 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 168 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 178 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 187 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 198 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 212 */     long start = System.currentTimeMillis();
/* 213 */     boolean rtn = this.parent.execute(sql);
/* 214 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 216 */     return rtn;
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 227 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 239 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 252 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 265 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 276 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 288 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 299 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 310 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 321 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 331 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 340 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 355 */     return this.parent.executeBatch();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 365 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 384 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 395 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 414 */     long start = System.currentTimeMillis();
/* 415 */     int rtn = this.parent.executeUpdate(sql, autoGeneratedKeys);
/* 416 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 418 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 437 */     long start = System.currentTimeMillis();
/* 438 */     int rtn = this.parent.executeUpdate(sql, columnIndexes);
/* 439 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 441 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 460 */     long start = System.currentTimeMillis();
/* 461 */     int rtn = this.parent.executeUpdate(sql, columnNames);
/* 462 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 464 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 483 */     long start = System.currentTimeMillis();
/* 484 */     boolean rtn = this.parent.execute(sql, autoGeneratedKeys);
/* 485 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 487 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 505 */     long start = System.currentTimeMillis();
/* 506 */     boolean rtn = this.parent.execute(sql, columnIndexes);
/* 507 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 509 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 527 */     long start = System.currentTimeMillis();
/* 528 */     boolean rtn = this.parent.execute(sql, columnNames);
/* 529 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*     */ 
/* 531 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 542 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ 
/*     */   private void doTrace(String username, String sql, long startTime, int useTime)
/*     */   {
/* 549 */     JdbcTrace objJdbcTrace = new JdbcTrace();
/* 550 */     objJdbcTrace.setCreateTime(startTime);
/* 551 */     objJdbcTrace.setUsername(username);
/* 552 */     objJdbcTrace.setSql(sql);
/* 553 */     objJdbcTrace.setType("S");
/* 554 */     objJdbcTrace.setUseTime(useTime);
/*     */ 
/* 556 */     TraceFactory.addTraceInfo(objJdbcTrace);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.TraceStatement
 * JD-Core Version:    0.5.4
 */