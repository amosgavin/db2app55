/*    */ package com.ai.appframe2.complex.datasource;
/*    */ 
/*    */ public class DataBaseConnectURL
/*    */ {
/*    */   private boolean isAdvanceUrl;
/*    */   private String advanceUrl;
/*    */   private String host;
/*    */   private String port;
/*    */   private String sid;
/*    */ 
/*    */   public DataBaseConnectURL()
/*    */   {
/* 13 */     this.isAdvanceUrl = false;
/* 14 */     this.advanceUrl = null;
/* 15 */     this.host = null;
/* 16 */     this.port = null;
/* 17 */     this.sid = null;
/*    */   }
/* 19 */   public String getAdvanceUrl() { return this.advanceUrl; }
/*    */ 
/*    */   public boolean isAdvanceUrl() {
/* 22 */     return this.isAdvanceUrl;
/*    */   }
/*    */   public String getHost() {
/* 25 */     return this.host;
/*    */   }
/*    */   public String getPort() {
/* 28 */     return this.port;
/*    */   }
/*    */   public String getSid() {
/* 31 */     return this.sid;
/*    */   }
/*    */   public void setSid(String sid) {
/* 34 */     this.sid = sid;
/*    */   }
/*    */   public void setPort(String port) {
/* 37 */     this.port = port;
/*    */   }
/*    */   public void setIsAdvanceUrl(boolean isAdvanceUrl) {
/* 40 */     this.isAdvanceUrl = isAdvanceUrl;
/*    */   }
/*    */   public void setHost(String host) {
/* 43 */     this.host = host;
/*    */   }
/*    */   public void setAdvanceUrl(String advanceUrl) {
/* 46 */     this.advanceUrl = advanceUrl;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.DataBaseConnectURL
 * JD-Core Version:    0.5.4
 */