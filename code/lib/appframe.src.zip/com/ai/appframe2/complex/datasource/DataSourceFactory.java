/*    */ package com.ai.appframe2.complex.datasource;
/*    */ 
/*    */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*    */ import com.ai.appframe2.complex.xml.XMLHelper;
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.DataSource;
/*    */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ 
/*    */ public class DataSourceFactory
/*    */ {
/* 19 */   private static IDataSource dataSource = null;
/*    */ 
/*    */   public static IDataSource getDataSource()
/*    */   {
/* 37 */     return dataSource;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 23 */       String className = XMLHelper.getInstance().getDefaults().getDatasource().getClazz().getName().trim();
/* 24 */       dataSource = (IDataSource)Class.forName(className).newInstance();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 29 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.initial_fail"), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.DataSourceFactory
 * JD-Core Version:    0.5.4
 */