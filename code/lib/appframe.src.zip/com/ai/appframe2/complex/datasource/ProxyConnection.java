/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ProxyConnection
/*     */   implements Connection
/*     */ {
/*  25 */   private Connection parentConnection = null;
/*  26 */   private boolean isOpenCount = false;
/*     */ 
/*     */   public ProxyConnection(Connection parentConnection, boolean isOpenCount)
/*     */   {
/*  34 */     if (parentConnection == null)
/*     */     {
/*  37 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.parent_connection_null"));
/*     */     }
/*  39 */     this.parentConnection = parentConnection;
/*  40 */     this.isOpenCount = isOpenCount;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  48 */     return AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.parent_connection") + ":" + this.parentConnection + "," + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.current_connection") + ":" + super.toString();
/*     */   }
/*     */ 
/*     */   public Statement createStatement()
/*     */     throws SQLException
/*     */   {
/*  58 */     return new ProxyStatement(this.parentConnection.createStatement(), this.isOpenCount);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/*  69 */     return new ProxyPreparedStatement(this.parentConnection.prepareStatement(sql), sql, this.isOpenCount);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql)
/*     */     throws SQLException
/*     */   {
/*  81 */     return this.parentConnection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */   public String nativeSQL(String sql)
/*     */     throws SQLException
/*     */   {
/*  92 */     return this.parentConnection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {
/* 102 */     this.parentConnection.setAutoCommit(autoCommit);
/*     */   }
/*     */ 
/*     */   public boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 112 */     return this.parentConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws SQLException
/*     */   {
/* 122 */     this.parentConnection.commit();
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLException
/*     */   {
/* 132 */     this.parentConnection.rollback();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 142 */     this.parentConnection.close();
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 152 */     return this.parentConnection.isClosed();
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 163 */     return this.parentConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 173 */     this.parentConnection.setReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 183 */     return this.parentConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */   public void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {
/* 194 */     this.parentConnection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */   public String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 204 */     return this.parentConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   public void setTransactionIsolation(int level)
/*     */     throws SQLException
/*     */   {
/* 219 */     this.parentConnection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */   public int getTransactionIsolation()
/*     */     throws SQLException
/*     */   {
/* 232 */     return this.parentConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 242 */     return this.parentConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 251 */     this.parentConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 268 */     return this.parentConnection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 287 */     return this.parentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 306 */     return this.parentConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public Map getTypeMap()
/*     */     throws SQLException
/*     */   {
/* 316 */     return this.parentConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   public void setTypeMap(Map map)
/*     */     throws SQLException
/*     */   {
/* 328 */     this.parentConnection.setTypeMap(map);
/*     */   }
/*     */ 
/*     */   public void setHoldability(int holdability)
/*     */     throws SQLException
/*     */   {
/* 341 */     this.parentConnection.setHoldability(holdability);
/*     */   }
/*     */ 
/*     */   public int getHoldability()
/*     */     throws SQLException
/*     */   {
/* 353 */     return this.parentConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint()
/*     */     throws SQLException
/*     */   {
/* 365 */     return this.parentConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint(String name)
/*     */     throws SQLException
/*     */   {
/* 378 */     return this.parentConnection.setSavepoint(name);
/*     */   }
/*     */ 
/*     */   public void rollback(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 389 */     this.parentConnection.rollback(savepoint);
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 400 */     this.parentConnection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 420 */     return this.parentConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 442 */     return this.parentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 464 */     return this.parentConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 479 */     return this.parentConnection.prepareStatement(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 494 */     return this.parentConnection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 509 */     return this.parentConnection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.ProxyConnection
 * JD-Core Version:    0.5.4
 */