/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.standard.sql.SQLMonitor;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ProxyStatement
/*     */   implements Statement
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(ProxyStatement.class);
/*     */ 
/*  26 */   private Statement parent = null;
/*  27 */   private boolean isCount = false;
/*  28 */   private SQLCount objSQLCount = null;
/*     */ 
/*     */   public ProxyStatement(Statement parent)
/*     */   {
/*  36 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public ProxyStatement(Statement parent, boolean isCount)
/*     */   {
/*  45 */     this.parent = parent;
/*  46 */     this.isCount = isCount;
/*  47 */     if (this.isCount)
/*  48 */       this.objSQLCount = new SQLCount();
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/*  63 */     boolean _showMemory = false;
/*  64 */     if (this.isCount) {
/*  65 */       _showMemory = this.objSQLCount.log(getConnection(), sql);
/*     */     }
/*     */ 
/*  68 */     long start = System.currentTimeMillis();
/*  69 */     ResultSet rtn = this.parent.executeQuery(sql);
/*  70 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/*  72 */     if (_showMemory)
/*     */     {
/*  74 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.getmemory_show", new String[] { Runtime.getRuntime().totalMemory() + "", sql }));
/*     */     }
/*     */ 
/*  77 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/*  94 */     long start = System.currentTimeMillis();
/*  95 */     int rtn = this.parent.executeUpdate(sql);
/*  96 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/*  98 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 108 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/* 119 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/* 130 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 142 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 152 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 162 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 172 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 183 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 192 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 202 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 211 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 222 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 236 */     long start = System.currentTimeMillis();
/* 237 */     boolean rtn = this.parent.execute(sql);
/* 238 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 240 */     return rtn;
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 251 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 263 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 276 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 289 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 300 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 312 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 323 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 334 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 345 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 355 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 364 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 379 */     return this.parent.executeBatch();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 389 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 408 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 419 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 438 */     long start = System.currentTimeMillis();
/* 439 */     int rtn = this.parent.executeUpdate(sql, autoGeneratedKeys);
/* 440 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 442 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 461 */     long start = System.currentTimeMillis();
/* 462 */     int rtn = this.parent.executeUpdate(sql, columnIndexes);
/* 463 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 465 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 484 */     long start = System.currentTimeMillis();
/* 485 */     int rtn = this.parent.executeUpdate(sql, columnNames);
/* 486 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 488 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 507 */     long start = System.currentTimeMillis();
/* 508 */     boolean rtn = this.parent.execute(sql, autoGeneratedKeys);
/* 509 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 511 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 529 */     long start = System.currentTimeMillis();
/* 530 */     boolean rtn = this.parent.execute(sql, columnIndexes);
/* 531 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 533 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 551 */     long start = System.currentTimeMillis();
/* 552 */     boolean rtn = this.parent.execute(sql, columnNames);
/* 553 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*     */ 
/* 555 */     return rtn;
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 566 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.ProxyStatement
 * JD-Core Version:    0.5.4
 */