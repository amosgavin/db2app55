/*    */ package com.ai.appframe2.complex.datasource;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.sql.Connection;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class CheckResultSet
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(CheckResultSet.class);
/*    */ 
/* 24 */   private static boolean IS_CHECK = false;
/* 25 */   private static int WARNING_COUNT = 10000;
/* 26 */   private static int ERROR_COUNT = 100000;
/*    */ 
/*    */   public static boolean isCheck()
/*    */   {
/* 75 */     return IS_CHECK;
/*    */   }
/*    */ 
/*    */   public static int getWarningCount()
/*    */   {
/* 83 */     return WARNING_COUNT;
/*    */   }
/*    */ 
/*    */   public static int getErrorCount()
/*    */   {
/* 91 */     return ERROR_COUNT;
/*    */   }
/*    */ 
/*    */   public static void ignoreCheckByConneciton(Connection conn)
/*    */   {
/* 99 */     if ((conn != null) && (conn instanceof LogicConnection))
/* 100 */       ((LogicConnection)conn).ignoreCheck();
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 30 */       HashMap propertyMap = AIConfigManager.getConfigItemsByKind("AppFrameJdbc");
/* 31 */       String check = (String)propertyMap.get("appframe.jdbc.check_resultset");
/* 32 */       if ((!StringUtils.isBlank(check)) && (((check.equalsIgnoreCase("Y")) || (check.equalsIgnoreCase("1"))))) {
/* 33 */         IS_CHECK = true;
/*    */ 
/* 35 */         String warning = (String)propertyMap.get("appframe.jdbc.check_resultset.warning_count");
/* 36 */         if ((!StringUtils.isBlank(warning)) && (StringUtils.isNumeric(warning))) {
/* 37 */           WARNING_COUNT = Integer.parseInt(warning);
/* 38 */           if (WARNING_COUNT == -1) {
/* 39 */             WARNING_COUNT = 2147483647;
/*    */           }
/*    */         }
/*    */ 
/* 43 */         String error = (String)propertyMap.get("appframe.jdbc.check_resultset.error_count");
/* 44 */         if ((!StringUtils.isBlank(error)) && (StringUtils.isNumeric(error))) {
/* 45 */           ERROR_COUNT = Integer.parseInt(error);
/* 46 */           if (ERROR_COUNT == -1) {
/* 47 */             ERROR_COUNT = 2147483647;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 54 */       IS_CHECK = false;
/* 55 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.check_parsing_params_error"), ex);
/*    */     }
/*    */     finally {
/* 58 */       if (IS_CHECK) {
/* 59 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.check_parsing_params_warn", new String[] { WARNING_COUNT + "", ERROR_COUNT + "" }));
/*    */       }
/*    */       else
/* 62 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.check_disable"));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.CheckResultSet
 * JD-Core Version:    0.5.4
 */