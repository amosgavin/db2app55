/*    */ package com.ai.appframe2.complex.datasource.interfaces;
/*    */ 
/*    */ import com.ai.appframe2.complex.listener.LifeCycleListener;
/*    */ import java.sql.Connection;
/*    */ import java.util.HashMap;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public abstract interface IDataSource extends LifeCycleListener
/*    */ {
/* 23 */   public static final ThreadLocal CUR_DATASOURCE = new ThreadLocal();
/*    */ 
/*    */   public abstract Connection getConnectionFromDataSource(String paramString)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract String getPrimaryDataSource()
/*    */     throws Exception;
/*    */ 
/*    */   public abstract DataSource getDataSource(String paramString)
/*    */     throws Exception;
/*    */ 
/*    */   public abstract HashMap getURLMap()
/*    */     throws Exception;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.interfaces.IDataSource
 * JD-Core Version:    0.5.4
 */