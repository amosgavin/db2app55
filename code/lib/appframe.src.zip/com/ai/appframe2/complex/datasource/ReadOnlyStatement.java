/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ public class ReadOnlyStatement
/*     */   implements Statement
/*     */ {
/*  21 */   private Statement parent = null;
/*     */ 
/*     */   public ReadOnlyStatement(Statement parent)
/*     */   {
/*  28 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/*  41 */     return this.parent.executeQuery(sql);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/*  58 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*  68 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/*  79 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/*  90 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 102 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 112 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 122 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 132 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 143 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 152 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 162 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 171 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 182 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 196 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 207 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 219 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 232 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 245 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 256 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 268 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 279 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 290 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 301 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 311 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 320 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 336 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 346 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 365 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 376 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 395 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 414 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 433 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 452 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 470 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 488 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 499 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.ReadOnlyStatement
 * JD-Core Version:    0.5.4
 */