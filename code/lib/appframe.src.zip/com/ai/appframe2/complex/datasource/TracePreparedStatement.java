/*      */ package com.ai.appframe2.complex.datasource;
/*      */ 
/*      */ import com.ai.appframe2.complex.trace.PtmtParam;
/*      */ import com.ai.appframe2.complex.trace.TraceFactory;
/*      */ import com.ai.appframe2.complex.trace.impl.JdbcTrace;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class TracePreparedStatement
/*      */   implements PreparedStatement
/*      */ {
/*   40 */   private static transient Log log = LogFactory.getLog(TracePreparedStatement.class);
/*      */ 
/*   42 */   private PreparedStatement parent = null;
/*   43 */   private String sql = null;
/*   44 */   private String username = null;
/*   45 */   private HashMap map = null;
/*      */ 
/*      */   public TracePreparedStatement(PreparedStatement parent, String username, String sql)
/*      */   {
/*   54 */     this.parent = parent;
/*   55 */     this.sql = sql;
/*   56 */     this.username = username;
/*   57 */     this.map = new HashMap();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/*   71 */     ResultSet rtn = null;
/*      */ 
/*   74 */     long start = System.currentTimeMillis();
/*   75 */     rtn = this.parent.executeQuery();
/*   76 */     doTrace(this.username, this.sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*   78 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/*   93 */     long start = System.currentTimeMillis();
/*   94 */     int rtn = this.parent.executeUpdate();
/*   95 */     doTrace(this.username, this.sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*   97 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/*  108 */     this.parent.setNull(parameterIndex, sqlType);
/*      */   }
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/*  119 */     this.parent.setBoolean(parameterIndex, x);
/*      */ 
/*  121 */     addParameter(parameterIndex, "boolean", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/*  132 */     this.parent.setByte(parameterIndex, x);
/*      */ 
/*  134 */     addParameter(parameterIndex, "byte", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/*  145 */     this.parent.setShort(parameterIndex, x);
/*      */ 
/*  147 */     addParameter(parameterIndex, "short", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/*  158 */     this.parent.setInt(parameterIndex, x);
/*      */ 
/*  160 */     addParameter(parameterIndex, "int", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/*  171 */     this.parent.setLong(parameterIndex, x);
/*      */ 
/*  173 */     addParameter(parameterIndex, "long", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/*  184 */     this.parent.setFloat(parameterIndex, x);
/*      */ 
/*  186 */     addParameter(parameterIndex, "float", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/*  197 */     this.parent.setDouble(parameterIndex, x);
/*      */ 
/*  199 */     addParameter(parameterIndex, "double", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/*  210 */     this.parent.setBigDecimal(parameterIndex, x);
/*      */ 
/*  212 */     addParameter(parameterIndex, "BigDecimal", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/*  223 */     this.parent.setString(parameterIndex, x);
/*      */ 
/*  225 */     addParameter(parameterIndex, "String", x);
/*      */   }
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/*  236 */     this.parent.setBytes(parameterIndex, x);
/*      */ 
/*  238 */     addParameter(parameterIndex, "bytes", new String(x));
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, Date x)
/*      */     throws SQLException
/*      */   {
/*  249 */     this.parent.setDate(parameterIndex, x);
/*      */ 
/*  251 */     addParameter(parameterIndex, "Date", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/*  262 */     this.parent.setTime(parameterIndex, x);
/*      */ 
/*  264 */     addParameter(parameterIndex, "Time", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/*  275 */     this.parent.setTimestamp(parameterIndex, x);
/*      */ 
/*  277 */     addParameter(parameterIndex, "Timestamp", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  289 */     this.parent.setAsciiStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  302 */     this.parent.setUnicodeStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  314 */     this.parent.setBinaryStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  323 */     this.parent.clearParameters();
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*  338 */     this.parent.setObject(parameterIndex, x, targetSqlType, scale);
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/*  350 */     this.parent.setObject(parameterIndex, x, targetSqlType);
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x)
/*      */     throws SQLException
/*      */   {
/*  361 */     this.parent.setObject(parameterIndex, x);
/*      */ 
/*  363 */     addParameter(parameterIndex, "Object", String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/*  376 */     long start = System.currentTimeMillis();
/*  377 */     boolean rtn = this.parent.execute();
/*  378 */     doTrace(this.username, this.sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  380 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  389 */     this.parent.addBatch();
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/*  401 */     this.parent.setCharacterStream(parameterIndex, reader, length);
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/*  412 */     this.parent.setRef(i, x);
/*      */   }
/*      */ 
/*      */   public void setBlob(int i, Blob x)
/*      */     throws SQLException
/*      */   {
/*  423 */     this.parent.setBlob(i, x);
/*      */   }
/*      */ 
/*      */   public void setClob(int i, Clob x)
/*      */     throws SQLException
/*      */   {
/*  434 */     this.parent.setClob(i, x);
/*      */   }
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/*  445 */     this.parent.setArray(i, x);
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  457 */     return this.parent.getMetaData();
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  470 */     this.parent.setDate(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  483 */     this.parent.setTime(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  496 */     this.parent.setTimestamp(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setNull(int paramIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/*  509 */     this.parent.setNull(paramIndex, sqlType, typeName);
/*      */   }
/*      */ 
/*      */   public void setURL(int parameterIndex, URL x)
/*      */     throws SQLException
/*      */   {
/*  520 */     this.parent.setURL(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/*  531 */     return this.parent.getParameterMetaData();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery(String sql)
/*      */     throws SQLException
/*      */   {
/*  545 */     long start = System.currentTimeMillis();
/*  546 */     ResultSet rtn = this.parent.executeQuery(sql);
/*  547 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  549 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql)
/*      */     throws SQLException
/*      */   {
/*  566 */     long start = System.currentTimeMillis();
/*  567 */     int rtn = this.parent.executeUpdate(sql);
/*  568 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  570 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  580 */     this.parent.close();
/*      */   }
/*      */ 
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/*  591 */     return this.parent.getMaxFieldSize();
/*      */   }
/*      */ 
/*      */   public void setMaxFieldSize(int max)
/*      */     throws SQLException
/*      */   {
/*  602 */     this.parent.setMaxFieldSize(max);
/*      */   }
/*      */ 
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/*  614 */     return this.parent.getMaxRows();
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/*  624 */     this.parent.setMaxRows(max);
/*      */   }
/*      */ 
/*      */   public void setEscapeProcessing(boolean enable)
/*      */     throws SQLException
/*      */   {
/*  634 */     this.parent.setEscapeProcessing(enable);
/*      */   }
/*      */ 
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/*  644 */     return this.parent.getQueryTimeout();
/*      */   }
/*      */ 
/*      */   public void setQueryTimeout(int seconds)
/*      */     throws SQLException
/*      */   {
/*  655 */     this.parent.setQueryTimeout(seconds);
/*      */   }
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/*  664 */     this.parent.cancel();
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  674 */     return this.parent.getWarnings();
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  683 */     this.parent.clearWarnings();
/*      */   }
/*      */ 
/*      */   public void setCursorName(String name)
/*      */     throws SQLException
/*      */   {
/*  694 */     this.parent.setCursorName(name);
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql)
/*      */     throws SQLException
/*      */   {
/*  708 */     long start = System.currentTimeMillis();
/*  709 */     boolean rtn = this.parent.execute(sql);
/*  710 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  712 */     return rtn;
/*      */   }
/*      */ 
/*      */   public ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/*  723 */     return this.parent.getResultSet();
/*      */   }
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/*  735 */     return this.parent.getUpdateCount();
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/*  748 */     return this.parent.getMoreResults();
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/*  761 */     this.parent.setFetchDirection(direction);
/*      */   }
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/*  772 */     return this.parent.getFetchDirection();
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/*  784 */     this.parent.setFetchSize(rows);
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*  795 */     return this.parent.getFetchSize();
/*      */   }
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/*  806 */     return this.parent.getResultSetConcurrency();
/*      */   }
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/*  817 */     return this.parent.getResultSetType();
/*      */   }
/*      */ 
/*      */   public void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  827 */     this.parent.addBatch(sql);
/*      */   }
/*      */ 
/*      */   public void clearBatch()
/*      */     throws SQLException
/*      */   {
/*  836 */     this.parent.clearBatch();
/*      */   }
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/*  852 */     long start = System.currentTimeMillis();
/*  853 */     int[] rtn = this.parent.executeBatch();
/*  854 */     doTrace(this.username, this.sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  856 */     return rtn;
/*      */   }
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*  866 */     return this.parent.getConnection();
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults(int current)
/*      */     throws SQLException
/*      */   {
/*  885 */     return this.parent.getMoreResults(current);
/*      */   }
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/*  896 */     return this.parent.getGeneratedKeys();
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  915 */     long start = System.currentTimeMillis();
/*  916 */     int rtn = this.parent.executeUpdate(sql, autoGeneratedKeys);
/*  917 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  919 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int[] columnIndexes)
/*      */     throws SQLException
/*      */   {
/*  938 */     long start = System.currentTimeMillis();
/*  939 */     int rtn = this.parent.executeUpdate(sql, columnIndexes);
/*  940 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  942 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, String[] columnNames)
/*      */     throws SQLException
/*      */   {
/*  961 */     long start = System.currentTimeMillis();
/*  962 */     int rtn = this.parent.executeUpdate(sql, columnNames);
/*  963 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  965 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int autoGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  984 */     long start = System.currentTimeMillis();
/*  985 */     boolean rtn = this.parent.execute(sql, autoGeneratedKeys);
/*  986 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/*  988 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int[] columnIndexes)
/*      */     throws SQLException
/*      */   {
/* 1006 */     long start = System.currentTimeMillis();
/* 1007 */     boolean rtn = this.parent.execute(sql, columnIndexes);
/* 1008 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/* 1010 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, String[] columnNames)
/*      */     throws SQLException
/*      */   {
/* 1028 */     long start = System.currentTimeMillis();
/* 1029 */     boolean rtn = this.parent.execute(sql, columnNames);
/* 1030 */     doTrace(this.username, sql, start, (int)(System.currentTimeMillis() - start));
/*      */ 
/* 1032 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 1043 */     return this.parent.getResultSetHoldability();
/*      */   }
/*      */ 
/*      */   private void addParameter(int index, String type, String value)
/*      */   {
/* 1054 */     Integer i = new Integer(index);
/* 1055 */     if (this.map.containsKey(i)) {
/* 1056 */       List list = (List)this.map.get(i);
/* 1057 */       list.add(new PtmtParam(type, value));
/* 1058 */       this.map.put(i, list);
/*      */     }
/*      */     else {
/* 1061 */       List list = new ArrayList();
/* 1062 */       list.add(new PtmtParam(type, value));
/* 1063 */       this.map.put(i, list);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void doTrace(String username, String sql, long startTime, int useTime)
/*      */   {
/* 1071 */     JdbcTrace objJdbcTrace = new JdbcTrace();
/* 1072 */     objJdbcTrace.setCreateTime(startTime);
/* 1073 */     objJdbcTrace.setUsername(username);
/* 1074 */     objJdbcTrace.setSql(sql);
/* 1075 */     objJdbcTrace.setType("P");
/* 1076 */     objJdbcTrace.setUseTime(useTime);
/* 1077 */     Map tmp = new TreeMap();
/* 1078 */     tmp.putAll(this.map);
/* 1079 */     objJdbcTrace.setParameter(tmp);
/*      */ 
/* 1082 */     TraceFactory.addTraceInfo(objJdbcTrace);
/* 1083 */     this.map.clear();
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.TracePreparedStatement
 * JD-Core Version:    0.5.4
 */