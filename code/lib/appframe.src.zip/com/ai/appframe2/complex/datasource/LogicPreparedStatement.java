/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class LogicPreparedStatement
/*     */   implements PreparedStatement
/*     */ {
/*  36 */   private PreparedStatement parent = null;
/*  37 */   private String sql = null;
/*  38 */   private Map map = new HashMap();
/*     */ 
/*     */   public LogicPreparedStatement(PreparedStatement parent, String sql)
/*     */   {
/*  46 */     this.parent = parent;
/*  47 */     this.sql = sql;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery()
/*     */     throws SQLException
/*     */   {
/*  61 */     return new LogicResultSet(this, this.parent.executeQuery(), this.sql, this.map);
/*     */   }
/*     */ 
/*     */   public int executeUpdate()
/*     */     throws SQLException
/*     */   {
/*  74 */     return this.parent.executeUpdate();
/*     */   }
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType)
/*     */     throws SQLException
/*     */   {
/*  85 */     this.parent.setNull(parameterIndex, sqlType);
/*     */   }
/*     */ 
/*     */   public void setBoolean(int parameterIndex, boolean x)
/*     */     throws SQLException
/*     */   {
/*  96 */     this.parent.setBoolean(parameterIndex, x);
/*  97 */     this.map.put(new Integer(parameterIndex), new Boolean(x));
/*     */   }
/*     */ 
/*     */   public void setByte(int parameterIndex, byte x)
/*     */     throws SQLException
/*     */   {
/* 108 */     this.parent.setByte(parameterIndex, x);
/* 109 */     this.map.put(new Integer(parameterIndex), new Byte(x));
/*     */   }
/*     */ 
/*     */   public void setShort(int parameterIndex, short x)
/*     */     throws SQLException
/*     */   {
/* 120 */     this.parent.setShort(parameterIndex, x);
/* 121 */     this.map.put(new Integer(parameterIndex), new Short(x));
/*     */   }
/*     */ 
/*     */   public void setInt(int parameterIndex, int x)
/*     */     throws SQLException
/*     */   {
/* 132 */     this.parent.setInt(parameterIndex, x);
/* 133 */     this.map.put(new Integer(parameterIndex), new Integer(x));
/*     */   }
/*     */ 
/*     */   public void setLong(int parameterIndex, long x)
/*     */     throws SQLException
/*     */   {
/* 144 */     this.parent.setLong(parameterIndex, x);
/* 145 */     this.map.put(new Integer(parameterIndex), new Long(x));
/*     */   }
/*     */ 
/*     */   public void setFloat(int parameterIndex, float x)
/*     */     throws SQLException
/*     */   {
/* 156 */     this.parent.setFloat(parameterIndex, x);
/* 157 */     this.map.put(new Integer(parameterIndex), new Float(x));
/*     */   }
/*     */ 
/*     */   public void setDouble(int parameterIndex, double x)
/*     */     throws SQLException
/*     */   {
/* 168 */     this.parent.setDouble(parameterIndex, x);
/* 169 */     this.map.put(new Integer(parameterIndex), new Double(x));
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*     */     throws SQLException
/*     */   {
/* 180 */     this.parent.setBigDecimal(parameterIndex, x);
/* 181 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setString(int parameterIndex, String x)
/*     */     throws SQLException
/*     */   {
/* 192 */     this.parent.setString(parameterIndex, x);
/* 193 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setBytes(int parameterIndex, byte[] x)
/*     */     throws SQLException
/*     */   {
/* 204 */     this.parent.setBytes(parameterIndex, x);
/* 205 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x)
/*     */     throws SQLException
/*     */   {
/* 216 */     this.parent.setDate(parameterIndex, x);
/* 217 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x)
/*     */     throws SQLException
/*     */   {
/* 228 */     this.parent.setTime(parameterIndex, x);
/* 229 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x)
/*     */     throws SQLException
/*     */   {
/* 240 */     this.parent.setTimestamp(parameterIndex, x);
/* 241 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 253 */     this.parent.setAsciiStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 266 */     this.parent.setUnicodeStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 278 */     this.parent.setBinaryStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void clearParameters()
/*     */     throws SQLException
/*     */   {
/* 287 */     this.parent.clearParameters();
/* 288 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*     */     throws SQLException
/*     */   {
/* 303 */     this.parent.setObject(parameterIndex, x, targetSqlType, scale);
/* 304 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*     */     throws SQLException
/*     */   {
/* 316 */     this.parent.setObject(parameterIndex, x, targetSqlType);
/* 317 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x)
/*     */     throws SQLException
/*     */   {
/* 328 */     this.parent.setObject(parameterIndex, x);
/* 329 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public boolean execute()
/*     */     throws SQLException
/*     */   {
/* 340 */     return this.parent.execute();
/*     */   }
/*     */ 
/*     */   public void addBatch()
/*     */     throws SQLException
/*     */   {
/* 349 */     this.parent.addBatch();
/*     */   }
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*     */     throws SQLException
/*     */   {
/* 361 */     this.parent.setCharacterStream(parameterIndex, reader, length);
/*     */   }
/*     */ 
/*     */   public void setRef(int i, Ref x)
/*     */     throws SQLException
/*     */   {
/* 372 */     this.parent.setRef(i, x);
/*     */   }
/*     */ 
/*     */   public void setBlob(int i, Blob x)
/*     */     throws SQLException
/*     */   {
/* 383 */     this.parent.setBlob(i, x);
/*     */   }
/*     */ 
/*     */   public void setClob(int i, Clob x)
/*     */     throws SQLException
/*     */   {
/* 394 */     this.parent.setClob(i, x);
/*     */   }
/*     */ 
/*     */   public void setArray(int i, Array x)
/*     */     throws SQLException
/*     */   {
/* 405 */     this.parent.setArray(i, x);
/*     */   }
/*     */ 
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 417 */     return this.parent.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 430 */     this.parent.setDate(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 443 */     this.parent.setTime(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 456 */     this.parent.setTimestamp(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setNull(int paramIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {
/* 469 */     this.parent.setNull(paramIndex, sqlType, typeName);
/*     */   }
/*     */ 
/*     */   public void setURL(int parameterIndex, URL x)
/*     */     throws SQLException
/*     */   {
/* 480 */     this.parent.setURL(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public ParameterMetaData getParameterMetaData()
/*     */     throws SQLException
/*     */   {
/* 491 */     return this.parent.getParameterMetaData();
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/* 503 */     return this.parent.executeQuery(sql);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/* 518 */     return this.parent.executeUpdate(sql);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 528 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/* 539 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/* 550 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 562 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 572 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 582 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 592 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 603 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 612 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 622 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 631 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 642 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 654 */     return this.parent.execute(sql);
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 665 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 677 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 690 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 703 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 714 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 726 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 737 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 748 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 759 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 769 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 778 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 792 */     return this.parent.executeBatch();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 802 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 821 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 832 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 849 */     return this.parent.executeUpdate(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 866 */     return this.parent.executeUpdate(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 883 */     return this.parent.executeUpdate(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 900 */     return this.parent.execute(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 916 */     return this.parent.execute(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 932 */     return this.parent.execute(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 943 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.LogicPreparedStatement
 * JD-Core Version:    0.5.4
 */