/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ public class ReadOnlyPreparedStatement
/*     */   implements PreparedStatement
/*     */ {
/*  36 */   private PreparedStatement parent = null;
/*     */ 
/*     */   public ReadOnlyPreparedStatement(PreparedStatement parent)
/*     */   {
/*  43 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery()
/*     */     throws SQLException
/*     */   {
/*  55 */     return this.parent.executeQuery();
/*     */   }
/*     */ 
/*     */   public int executeUpdate()
/*     */     throws SQLException
/*     */   {
/*  70 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType)
/*     */     throws SQLException
/*     */   {
/*  81 */     this.parent.setNull(parameterIndex, sqlType);
/*     */   }
/*     */ 
/*     */   public void setBoolean(int parameterIndex, boolean x)
/*     */     throws SQLException
/*     */   {
/*  92 */     this.parent.setBoolean(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setByte(int parameterIndex, byte x)
/*     */     throws SQLException
/*     */   {
/* 103 */     this.parent.setByte(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setShort(int parameterIndex, short x)
/*     */     throws SQLException
/*     */   {
/* 114 */     this.parent.setShort(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setInt(int parameterIndex, int x)
/*     */     throws SQLException
/*     */   {
/* 125 */     this.parent.setInt(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setLong(int parameterIndex, long x)
/*     */     throws SQLException
/*     */   {
/* 136 */     this.parent.setLong(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setFloat(int parameterIndex, float x)
/*     */     throws SQLException
/*     */   {
/* 147 */     this.parent.setFloat(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setDouble(int parameterIndex, double x)
/*     */     throws SQLException
/*     */   {
/* 158 */     this.parent.setDouble(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*     */     throws SQLException
/*     */   {
/* 169 */     this.parent.setBigDecimal(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setString(int parameterIndex, String x)
/*     */     throws SQLException
/*     */   {
/* 180 */     this.parent.setString(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setBytes(int parameterIndex, byte[] x)
/*     */     throws SQLException
/*     */   {
/* 191 */     this.parent.setBytes(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x)
/*     */     throws SQLException
/*     */   {
/* 202 */     this.parent.setDate(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x)
/*     */     throws SQLException
/*     */   {
/* 213 */     this.parent.setTime(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x)
/*     */     throws SQLException
/*     */   {
/* 224 */     this.parent.setTimestamp(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 236 */     this.parent.setAsciiStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 249 */     this.parent.setUnicodeStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 261 */     this.parent.setBinaryStream(parameterIndex, x, length);
/*     */   }
/*     */ 
/*     */   public void clearParameters()
/*     */     throws SQLException
/*     */   {
/* 270 */     this.parent.clearParameters();
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*     */     throws SQLException
/*     */   {
/* 285 */     this.parent.setObject(parameterIndex, x, targetSqlType, scale);
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*     */     throws SQLException
/*     */   {
/* 297 */     this.parent.setObject(parameterIndex, x, targetSqlType);
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x)
/*     */     throws SQLException
/*     */   {
/* 308 */     this.parent.setObject(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public boolean execute()
/*     */     throws SQLException
/*     */   {
/* 321 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public void addBatch()
/*     */     throws SQLException
/*     */   {
/* 330 */     this.parent.addBatch();
/*     */   }
/*     */ 
/*     */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*     */     throws SQLException
/*     */   {
/* 342 */     this.parent.setCharacterStream(parameterIndex, reader, length);
/*     */   }
/*     */ 
/*     */   public void setRef(int i, Ref x)
/*     */     throws SQLException
/*     */   {
/* 353 */     this.parent.setRef(i, x);
/*     */   }
/*     */ 
/*     */   public void setBlob(int i, Blob x)
/*     */     throws SQLException
/*     */   {
/* 364 */     this.parent.setBlob(i, x);
/*     */   }
/*     */ 
/*     */   public void setClob(int i, Clob x)
/*     */     throws SQLException
/*     */   {
/* 375 */     this.parent.setClob(i, x);
/*     */   }
/*     */ 
/*     */   public void setArray(int i, Array x)
/*     */     throws SQLException
/*     */   {
/* 386 */     this.parent.setArray(i, x);
/*     */   }
/*     */ 
/*     */   public ResultSetMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 398 */     return this.parent.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 411 */     this.parent.setDate(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 424 */     this.parent.setTime(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*     */     throws SQLException
/*     */   {
/* 437 */     this.parent.setTimestamp(parameterIndex, x, cal);
/*     */   }
/*     */ 
/*     */   public void setNull(int paramIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {
/* 450 */     this.parent.setNull(paramIndex, sqlType, typeName);
/*     */   }
/*     */ 
/*     */   public void setURL(int parameterIndex, URL x)
/*     */     throws SQLException
/*     */   {
/* 461 */     this.parent.setURL(parameterIndex, x);
/*     */   }
/*     */ 
/*     */   public ParameterMetaData getParameterMetaData()
/*     */     throws SQLException
/*     */   {
/* 472 */     return this.parent.getParameterMetaData();
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/* 484 */     return this.parent.executeQuery(sql);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/* 501 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 511 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/* 522 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/* 533 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 545 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 555 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 565 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 575 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 586 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 595 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 605 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 614 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 625 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 639 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 650 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 662 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 675 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 688 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 699 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 711 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 722 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 733 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 744 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 754 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 763 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 779 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 789 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 808 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 819 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 838 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 857 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 876 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 895 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 913 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 931 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.readonly_connection_limit", new String[] { "update/delete/insert" }));
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 942 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.ReadOnlyPreparedStatement
 * JD-Core Version:    0.5.4
 */