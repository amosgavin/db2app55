/*      */ package com.ai.appframe2.complex.datasource;
/*      */ 
/*      */ import com.ai.appframe2.complex.mbean.standard.sql.SQLMonitor;
/*      */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class ProxyPreparedStatement
/*      */   implements PreparedStatement
/*      */ {
/*   38 */   private static transient Log log = LogFactory.getLog(ProxyPreparedStatement.class);
/*      */ 
/*   40 */   private PreparedStatement parent = null;
/*   41 */   private String sql = null;
/*      */ 
/*   43 */   private boolean isCount = false;
/*   44 */   private SQLCount objSQLCount = null;
/*      */ 
/*      */   public ProxyPreparedStatement(PreparedStatement parent, String sql)
/*      */   {
/*   52 */     this.parent = parent;
/*   53 */     this.sql = sql;
/*      */   }
/*      */ 
/*      */   public ProxyPreparedStatement(PreparedStatement parent, String sql, boolean isCount)
/*      */   {
/*   63 */     this.parent = parent;
/*   64 */     this.sql = sql;
/*      */ 
/*   66 */     this.isCount = isCount;
/*   67 */     if (this.isCount)
/*   68 */       this.objSQLCount = new SQLCount();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/*   81 */     ResultSet rtn = null;
/*      */ 
/*   83 */     boolean _showMemory = false;
/*   84 */     if (this.isCount) {
/*   85 */       _showMemory = this.objSQLCount.log(getConnection(), this.sql);
/*      */     }
/*      */ 
/*   88 */     long start = System.currentTimeMillis();
/*   89 */     rtn = this.parent.executeQuery();
/*   90 */     SQLMonitor.sqlInvoke(this.sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*   92 */     if (_showMemory)
/*      */     {
/*   94 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.getmemory_show", new String[] { Runtime.getRuntime().totalMemory() + "", this.sql }));
/*      */     }
/*      */ 
/*   97 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/*  112 */     long start = System.currentTimeMillis();
/*  113 */     int rtn = this.parent.executeUpdate();
/*  114 */     SQLMonitor.sqlInvoke(this.sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  116 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/*  127 */     this.parent.setNull(parameterIndex, sqlType);
/*      */ 
/*  129 */     if (this.isCount)
/*  130 */       this.objSQLCount.setNull(parameterIndex, sqlType);
/*      */   }
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/*  142 */     this.parent.setBoolean(parameterIndex, x);
/*      */ 
/*  144 */     if (this.isCount)
/*  145 */       this.objSQLCount.setBoolean(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/*  157 */     this.parent.setByte(parameterIndex, x);
/*      */ 
/*  159 */     if (this.isCount)
/*  160 */       this.objSQLCount.setByte(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/*  172 */     this.parent.setShort(parameterIndex, x);
/*      */ 
/*  174 */     if (this.isCount)
/*  175 */       this.objSQLCount.setShort(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/*  187 */     this.parent.setInt(parameterIndex, x);
/*      */ 
/*  189 */     if (this.isCount)
/*  190 */       this.objSQLCount.setInt(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/*  202 */     this.parent.setLong(parameterIndex, x);
/*      */ 
/*  204 */     if (this.isCount)
/*  205 */       this.objSQLCount.setLong(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/*  217 */     this.parent.setFloat(parameterIndex, x);
/*      */ 
/*  219 */     if (this.isCount)
/*  220 */       this.objSQLCount.setFloat(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/*  232 */     this.parent.setDouble(parameterIndex, x);
/*      */ 
/*  234 */     if (this.isCount)
/*  235 */       this.objSQLCount.setDouble(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/*  247 */     this.parent.setBigDecimal(parameterIndex, x);
/*      */ 
/*  249 */     if (this.isCount)
/*  250 */       this.objSQLCount.setBigDecimal(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/*  262 */     this.parent.setString(parameterIndex, x);
/*      */ 
/*  264 */     if (this.isCount)
/*  265 */       this.objSQLCount.setString(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/*  277 */     this.parent.setBytes(parameterIndex, x);
/*      */ 
/*  279 */     if (this.isCount)
/*  280 */       this.objSQLCount.setBytes(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, Date x)
/*      */     throws SQLException
/*      */   {
/*  292 */     this.parent.setDate(parameterIndex, x);
/*      */ 
/*  294 */     if (this.isCount)
/*  295 */       this.objSQLCount.setDate(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/*  307 */     this.parent.setTime(parameterIndex, x);
/*      */ 
/*  309 */     if (this.isCount)
/*  310 */       this.objSQLCount.setTime(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/*  322 */     this.parent.setTimestamp(parameterIndex, x);
/*      */ 
/*  324 */     if (this.isCount)
/*  325 */       this.objSQLCount.setTimestamp(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  338 */     this.parent.setAsciiStream(parameterIndex, x, length);
/*      */ 
/*  340 */     if (this.isCount)
/*  341 */       this.objSQLCount.setAsciiStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  355 */     this.parent.setUnicodeStream(parameterIndex, x, length);
/*      */ 
/*  357 */     if (this.isCount)
/*  358 */       this.objSQLCount.setUnicodeStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/*  371 */     this.parent.setBinaryStream(parameterIndex, x, length);
/*      */ 
/*  373 */     if (this.isCount)
/*  374 */       this.objSQLCount.setBinaryStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  384 */     this.parent.clearParameters();
/*      */ 
/*  386 */     if (this.isCount)
/*  387 */       this.objSQLCount.clearParameters();
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*  403 */     this.parent.setObject(parameterIndex, x, targetSqlType, scale);
/*      */ 
/*  405 */     if (this.isCount)
/*  406 */       this.objSQLCount.setObject(parameterIndex, x, targetSqlType, scale);
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/*  419 */     this.parent.setObject(parameterIndex, x, targetSqlType);
/*      */ 
/*  421 */     if (this.isCount)
/*  422 */       this.objSQLCount.setObject(parameterIndex, x, targetSqlType);
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object x)
/*      */     throws SQLException
/*      */   {
/*  434 */     this.parent.setObject(parameterIndex, x);
/*      */ 
/*  436 */     if (this.isCount)
/*  437 */       this.objSQLCount.setObject(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/*  451 */     long start = System.currentTimeMillis();
/*  452 */     boolean rtn = this.parent.execute();
/*  453 */     SQLMonitor.sqlInvoke(this.sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  455 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  464 */     this.parent.addBatch();
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/*  476 */     this.parent.setCharacterStream(parameterIndex, reader, length);
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/*  487 */     this.parent.setRef(i, x);
/*      */   }
/*      */ 
/*      */   public void setBlob(int i, Blob x)
/*      */     throws SQLException
/*      */   {
/*  498 */     this.parent.setBlob(i, x);
/*      */   }
/*      */ 
/*      */   public void setClob(int i, Clob x)
/*      */     throws SQLException
/*      */   {
/*  509 */     this.parent.setClob(i, x);
/*      */   }
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/*  520 */     this.parent.setArray(i, x);
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  532 */     return this.parent.getMetaData();
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  545 */     this.parent.setDate(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  558 */     this.parent.setTime(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/*  571 */     this.parent.setTimestamp(parameterIndex, x, cal);
/*      */   }
/*      */ 
/*      */   public void setNull(int paramIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/*  584 */     this.parent.setNull(paramIndex, sqlType, typeName);
/*      */   }
/*      */ 
/*      */   public void setURL(int parameterIndex, URL x)
/*      */     throws SQLException
/*      */   {
/*  595 */     this.parent.setURL(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/*  606 */     return this.parent.getParameterMetaData();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery(String sql)
/*      */     throws SQLException
/*      */   {
/*  620 */     boolean _showMemory = false;
/*  621 */     if (this.isCount) {
/*  622 */       _showMemory = this.objSQLCount.log(getConnection(), this.sql);
/*      */     }
/*      */ 
/*  625 */     long start = System.currentTimeMillis();
/*  626 */     ResultSet rtn = this.parent.executeQuery(sql);
/*  627 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  629 */     if (_showMemory)
/*      */     {
/*  631 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.getmemory_show", new String[] { Runtime.getRuntime().totalMemory() + "", sql }));
/*      */     }
/*      */ 
/*  634 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql)
/*      */     throws SQLException
/*      */   {
/*  651 */     long start = System.currentTimeMillis();
/*  652 */     int rtn = this.parent.executeUpdate(sql);
/*  653 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  655 */     return rtn;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  665 */     this.parent.close();
/*      */   }
/*      */ 
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/*  676 */     return this.parent.getMaxFieldSize();
/*      */   }
/*      */ 
/*      */   public void setMaxFieldSize(int max)
/*      */     throws SQLException
/*      */   {
/*  687 */     this.parent.setMaxFieldSize(max);
/*      */   }
/*      */ 
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/*  699 */     return this.parent.getMaxRows();
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/*  709 */     this.parent.setMaxRows(max);
/*      */   }
/*      */ 
/*      */   public void setEscapeProcessing(boolean enable)
/*      */     throws SQLException
/*      */   {
/*  719 */     this.parent.setEscapeProcessing(enable);
/*      */   }
/*      */ 
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/*  729 */     return this.parent.getQueryTimeout();
/*      */   }
/*      */ 
/*      */   public void setQueryTimeout(int seconds)
/*      */     throws SQLException
/*      */   {
/*  740 */     this.parent.setQueryTimeout(seconds);
/*      */   }
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/*  749 */     this.parent.cancel();
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  759 */     return this.parent.getWarnings();
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  768 */     this.parent.clearWarnings();
/*      */   }
/*      */ 
/*      */   public void setCursorName(String name)
/*      */     throws SQLException
/*      */   {
/*  779 */     this.parent.setCursorName(name);
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql)
/*      */     throws SQLException
/*      */   {
/*  793 */     long start = System.currentTimeMillis();
/*  794 */     boolean rtn = this.parent.execute(sql);
/*  795 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  797 */     return rtn;
/*      */   }
/*      */ 
/*      */   public ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/*  808 */     return this.parent.getResultSet();
/*      */   }
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/*  820 */     return this.parent.getUpdateCount();
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/*  833 */     return this.parent.getMoreResults();
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/*  846 */     this.parent.setFetchDirection(direction);
/*      */   }
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/*  857 */     return this.parent.getFetchDirection();
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/*  869 */     this.parent.setFetchSize(rows);
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*  880 */     return this.parent.getFetchSize();
/*      */   }
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/*  891 */     return this.parent.getResultSetConcurrency();
/*      */   }
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/*  902 */     return this.parent.getResultSetType();
/*      */   }
/*      */ 
/*      */   public void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  912 */     this.parent.addBatch(sql);
/*      */   }
/*      */ 
/*      */   public void clearBatch()
/*      */     throws SQLException
/*      */   {
/*  921 */     this.parent.clearBatch();
/*      */   }
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/*  937 */     long start = System.currentTimeMillis();
/*  938 */     int[] rtn = this.parent.executeBatch();
/*  939 */     SQLMonitor.sqlInvoke(this.sql, 1, System.currentTimeMillis() - start);
/*      */ 
/*  941 */     return rtn;
/*      */   }
/*      */ 
/*      */   public Connection getConnection()
/*      */     throws SQLException
/*      */   {
/*  951 */     return this.parent.getConnection();
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults(int current)
/*      */     throws SQLException
/*      */   {
/*  970 */     return this.parent.getMoreResults(current);
/*      */   }
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/*  981 */     return this.parent.getGeneratedKeys();
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/* 1000 */     long start = System.currentTimeMillis();
/* 1001 */     int rtn = this.parent.executeUpdate(sql, autoGeneratedKeys);
/* 1002 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1004 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int[] columnIndexes)
/*      */     throws SQLException
/*      */   {
/* 1023 */     long start = System.currentTimeMillis();
/* 1024 */     int rtn = this.parent.executeUpdate(sql, columnIndexes);
/* 1025 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1027 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, String[] columnNames)
/*      */     throws SQLException
/*      */   {
/* 1046 */     long start = System.currentTimeMillis();
/* 1047 */     int rtn = this.parent.executeUpdate(sql, columnNames);
/* 1048 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1050 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int autoGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/* 1069 */     long start = System.currentTimeMillis();
/* 1070 */     boolean rtn = this.parent.execute(sql, autoGeneratedKeys);
/* 1071 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1073 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int[] columnIndexes)
/*      */     throws SQLException
/*      */   {
/* 1091 */     long start = System.currentTimeMillis();
/* 1092 */     boolean rtn = this.parent.execute(sql, columnIndexes);
/* 1093 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1095 */     return rtn;
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, String[] columnNames)
/*      */     throws SQLException
/*      */   {
/* 1113 */     long start = System.currentTimeMillis();
/* 1114 */     boolean rtn = this.parent.execute(sql, columnNames);
/* 1115 */     SQLMonitor.sqlInvoke(sql, 1, System.currentTimeMillis() - start);
/*      */ 
/* 1117 */     return rtn;
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 1128 */     return this.parent.getResultSetHoldability();
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.ProxyPreparedStatement
 * JD-Core Version:    0.5.4
 */