/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SQLCount
/*     */ {
/*  32 */   private static transient Log log = LogFactory.getLog(SQLCount.class);
/*     */ 
/*  34 */   private HashMap map = new HashMap();
/*     */ 
/*     */   public void setNull(int parameterIndex, int sqlType)
/*     */     throws SQLException
/*     */   {
/*  42 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setNull(int parameterIndex, int sqlType)" }));
/*     */   }
/*     */ 
/*     */   public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/*  46 */     this.map.put(new Integer(parameterIndex), new Boolean(x));
/*     */   }
/*     */ 
/*     */   public void setByte(int parameterIndex, byte x) throws SQLException {
/*  50 */     this.map.put(new Integer(parameterIndex), new Byte(x));
/*     */   }
/*     */ 
/*     */   public void setShort(int parameterIndex, short x) throws SQLException {
/*  54 */     this.map.put(new Integer(parameterIndex), new Short(x));
/*     */   }
/*     */ 
/*     */   public void setInt(int parameterIndex, int x) throws SQLException {
/*  58 */     this.map.put(new Integer(parameterIndex), new Integer(x));
/*     */   }
/*     */ 
/*     */   public void setLong(int parameterIndex, long x) throws SQLException {
/*  62 */     this.map.put(new Integer(parameterIndex), new Long(x));
/*     */   }
/*     */ 
/*     */   public void setFloat(int parameterIndex, float x) throws SQLException {
/*  66 */     this.map.put(new Integer(parameterIndex), new Float(x));
/*     */   }
/*     */ 
/*     */   public void setDouble(int parameterIndex, double x) throws SQLException {
/*  70 */     this.map.put(new Integer(parameterIndex), new Double(x));
/*     */   }
/*     */ 
/*     */   public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/*  74 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setString(int parameterIndex, String x) throws SQLException {
/*  78 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/*  82 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setDate(int parameterIndex, Date x) throws SQLException {
/*  86 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setTime(int parameterIndex, Time x) throws SQLException {
/*  90 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException {
/*  94 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 100 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setAsciiStream" }));
/*     */   }
/*     */ 
/*     */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 106 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setUnicodeStream" }));
/*     */   }
/*     */ 
/*     */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*     */     throws SQLException
/*     */   {
/* 112 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setBinaryStream" }));
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
/*     */     throws SQLException
/*     */   {
/* 118 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setObject(int parameterIndex, Object x, int targetSqlType, int scale)" }));
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x, int targetSqlType)
/*     */     throws SQLException
/*     */   {
/* 124 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.unsupport_operation", new String[] { "setObject(int parameterIndex, Object x, int targetSqlType)" }));
/*     */   }
/*     */ 
/*     */   public void setObject(int parameterIndex, Object x) throws SQLException {
/* 128 */     this.map.put(new Integer(parameterIndex), x);
/*     */   }
/*     */ 
/*     */   public void clearParameters() throws SQLException {
/* 132 */     this.map.clear();
/*     */   }
/*     */ 
/*     */   public boolean log(Connection conn, String sql)
/*     */   {
/*     */     try
/*     */     {
/* 143 */       return _log(conn, sql);
/*     */     }
/*     */     catch (Throwable ex) {
/*     */     }
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean _log(Connection conn, String sql)
/*     */     throws Exception
/*     */   {
/* 159 */     boolean rtn = false;
/*     */ 
/* 161 */     if (StringUtils.contains(sql, "nextval")) {
/* 162 */       return rtn;
/*     */     }
/*     */ 
/* 165 */     long _count = 0L;
/* 166 */     PreparedStatement _p = null;
/* 167 */     ResultSet _rs = null;
/*     */     try {
/* 169 */       _p = conn.prepareStatement("select count(0) c from (" + sql + ")");
/*     */       Iterator iter;
/* 170 */       if ((this.map != null) && (!this.map.isEmpty())) {
/* 171 */         Set keys = this.map.keySet();
/* 172 */         for (iter = keys.iterator(); iter.hasNext(); ) {
/* 173 */           Integer item = (Integer)iter.next();
/* 174 */           Object value = this.map.get(item);
/* 175 */           if (value instanceof String) {
/* 176 */             _p.setString(item.intValue(), (String)value);
/*     */           }
/* 178 */           else if (value instanceof Integer) {
/* 179 */             _p.setInt(item.intValue(), ((Integer)value).intValue());
/*     */           }
/* 181 */           else if (value instanceof Long) {
/* 182 */             _p.setLong(item.intValue(), ((Long)value).longValue());
/*     */           }
/* 184 */           else if (value instanceof Float) {
/* 185 */             _p.setFloat(item.intValue(), ((Float)value).floatValue());
/*     */           }
/* 187 */           else if (value instanceof Double) {
/* 188 */             _p.setDouble(item.intValue(), ((Double)value).doubleValue());
/*     */           }
/* 190 */           else if (value instanceof Date) {
/* 191 */             _p.setDate(item.intValue(), (Date)value);
/*     */           }
/* 193 */           else if (value instanceof Time) {
/* 194 */             _p.setTime(item.intValue(), (Time)value);
/*     */           }
/* 196 */           else if (value instanceof Timestamp) {
/* 197 */             _p.setTimestamp(item.intValue(), (Timestamp)value);
/*     */           }
/* 199 */           else if (value instanceof Byte) {
/* 200 */             _p.setByte(item.intValue(), ((Byte)value).byteValue());
/*     */           }
/* 202 */           else if (value instanceof Boolean) {
/* 203 */             _p.setBoolean(item.intValue(), ((Boolean)value).booleanValue());
/*     */           }
/* 205 */           else if (value instanceof byte[]) {
/* 206 */             _p.setBytes(item.intValue(), (byte[])(byte[])value);
/*     */           }
/*     */           else {
/* 209 */             _p.setObject(item.intValue(), value);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 214 */       _rs = _p.executeQuery();
/* 215 */       if (_rs.next()) {
/* 216 */         _count = _rs.getLong("c");
/*     */       }
/*     */ 
/* 220 */       if (_count >= 100L)
/*     */       {
/* 222 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.sql_query_warn_100", new String[] { _count + "", sql }));
/*     */       }
/*     */ 
/* 225 */       if (_count > 1000L)
/*     */       {
/* 227 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.sql_query_warn_1000", new String[] { _count + "", Runtime.getRuntime().totalMemory() + "", sql }));
/* 228 */         rtn = true;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 233 */       if (log.isDebugEnabled())
/*     */       {
/* 235 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.sql_query_error", new String[] { ex.getMessage(), sql }));
/*     */       }
/*     */     }
/*     */     finally {
/* 239 */       if (_rs != null) {
/* 240 */         _rs.close();
/*     */       }
/* 242 */       if (_p != null) {
/* 243 */         _p.close();
/*     */       }
/*     */     }
/*     */ 
/* 247 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.SQLCount
 * JD-Core Version:    0.5.4
 */