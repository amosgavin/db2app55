/*    */ package com.ai.appframe2.complex.datasource;
/*    */ 
/*    */ import com.ai.appframe2.complex.center.CenterFactory;
/*    */ import com.ai.appframe2.complex.center.CenterInfo;
/*    */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class FlatDataSourceUtil
/*    */ {
/* 21 */   private static transient Log log = LogFactory.getLog(FlatDataSourceUtil.class);
/*    */ 
/*    */   public static String suspendCurrentDataSource(String newDataSource)
/*    */     throws Exception
/*    */   {
/* 34 */     if (StringUtils.isBlank(newDataSource)) {
/* 35 */       throw new Exception("newDataSource must not null");
/*    */     }
/*    */ 
/* 39 */     String previousDataSource = (String)IDataSource.CUR_DATASOURCE.get();
/* 40 */     if (log.isDebugEnabled()) {
/* 41 */       if (!StringUtils.isBlank(previousDataSource)) {
/* 42 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.FlatDataSourceUtil.previous_datasource", new String[] { previousDataSource }));
/*    */       }
/*    */       else {
/* 45 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.FlatDataSourceUtil.previous_datasource_null"));
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 50 */     IDataSource.CUR_DATASOURCE.set(null);
/*    */ 
/* 52 */     if (StringUtils.contains(newDataSource, "{CENTER}")) {
/* 53 */       newDataSource = StringUtils.replace(newDataSource, "{CENTER}", CenterFactory.getCenterInfo().getCenter());
/*    */     }
/*    */ 
/* 56 */     IDataSource.CUR_DATASOURCE.set(newDataSource);
/*    */ 
/* 58 */     if (log.isDebugEnabled()) {
/* 59 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.FlatDataSourceUtil.set_datasource", new String[] { newDataSource }));
/*    */     }
/*    */ 
/* 63 */     return previousDataSource;
/*    */   }
/*    */ 
/*    */   public static void resumeCurrentDataSource(String oldDataSource)
/*    */     throws Exception
/*    */   {
/* 73 */     IDataSource.CUR_DATASOURCE.set(oldDataSource);
/* 74 */     if (log.isDebugEnabled())
/* 75 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.FlatDataSourceUtil.resume_datasource", new String[] { oldDataSource }));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.FlatDataSourceUtil
 * JD-Core Version:    0.5.4
 */