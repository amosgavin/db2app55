/*      */ package com.ai.appframe2.complex.datasource;
/*      */ 
/*      */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.lang.StringUtils;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class LogicResultSet
/*      */   implements ResultSet
/*      */ {
/*   43 */   private static transient Log log = LogFactory.getLog(LogicResultSet.class);
/*      */ 
/*   45 */   private int recordCount = 0;
/*   46 */   private ResultSet parent = null;
/*   47 */   private String sql = null;
/*   48 */   private Map map = null;
/*   49 */   private boolean isWarning = false;
/*   50 */   private Statement createStmt = null;
/*      */ 
/*      */   public LogicResultSet(Statement createStmt, ResultSet parent, String sql)
/*      */   {
/*   58 */     this.createStmt = createStmt;
/*   59 */     this.parent = parent;
/*   60 */     this.sql = sql;
/*      */   }
/*      */ 
/*      */   public LogicResultSet(Statement createStmt, ResultSet parent, String sql, Map map)
/*      */   {
/*   69 */     this.createStmt = createStmt;
/*   70 */     this.parent = parent;
/*   71 */     this.sql = sql;
/*   72 */     this.map = map;
/*      */   }
/*      */ 
/*      */   private String convert(String sql, Map map)
/*      */   {
/*   82 */     StringBuilder sb = new StringBuilder();
/*   83 */     sb.append(sql);
/*   84 */     if ((map != null) && (!map.isEmpty())) {
/*   85 */       sb.append("\n");
/*      */ 
/*   87 */       List list = new ArrayList();
/*   88 */       Set set = map.keySet();
/*   89 */       for (Iterator iter = set.iterator(); iter.hasNext(); ) {
/*   90 */         Integer item = (Integer)iter.next();
/*   91 */         Object val = map.get(item);
/*   92 */         list.add("Parameter postition:" + item.intValue() + ",type:" + val.getClass() + ",value:" + val.toString());
/*      */       }
/*      */ 
/*   95 */       sb.append(StringUtils.join(list.iterator(), "\n"));
/*      */     }
/*   97 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/*  108 */     if (CheckResultSet.isCheck()) {
/*  109 */       this.recordCount += 1;
/*      */ 
/*  111 */       if (this.recordCount >= CheckResultSet.getErrorCount()) {
/*  112 */         throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.resultset.limit_error", new String[] { CheckResultSet.getErrorCount() + "", convert(this.sql, this.map) }));
/*      */       }
/*      */ 
/*  115 */       if ((!this.isWarning) && (this.recordCount >= CheckResultSet.getWarningCount())) {
/*  116 */         log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.resultset.limit_warn", new String[] { CheckResultSet.getWarningCount() + "", convert(this.sql, this.map) }));
/*      */ 
/*  118 */         this.isWarning = true;
/*      */       }
/*      */     }
/*  121 */     return this.parent.next();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  132 */     this.parent.close();
/*      */ 
/*  135 */     if (this.createStmt != null)
/*  136 */       this.createStmt.close();
/*      */   }
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/*  148 */     return this.parent.wasNull();
/*      */   }
/*      */ 
/*      */   public String getString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  161 */     return this.parent.getString(columnIndex);
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  174 */     return this.parent.getBoolean(columnIndex);
/*      */   }
/*      */ 
/*      */   public byte getByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  187 */     return this.parent.getByte(columnIndex);
/*      */   }
/*      */ 
/*      */   public short getShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  200 */     return this.parent.getShort(columnIndex);
/*      */   }
/*      */ 
/*      */   public int getInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  213 */     return this.parent.getInt(columnIndex);
/*      */   }
/*      */ 
/*      */   public long getLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  226 */     return this.parent.getLong(columnIndex);
/*      */   }
/*      */ 
/*      */   public float getFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  239 */     return this.parent.getFloat(columnIndex);
/*      */   }
/*      */ 
/*      */   public double getDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  252 */     return this.parent.getDouble(columnIndex);
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/*  266 */     return this.parent.getBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  279 */     return this.parent.getBytes(columnIndex);
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  292 */     return this.parent.getDate(columnIndex);
/*      */   }
/*      */ 
/*      */   public Time getTime(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  305 */     return this.parent.getTime(columnIndex);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  318 */     return this.parent.getTimestamp(columnIndex);
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  332 */     return this.parent.getAsciiStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public InputStream getUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  346 */     return this.parent.getUnicodeStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  360 */     return this.parent.getBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public String getString(String columnName)
/*      */     throws SQLException
/*      */   {
/*  373 */     return this.parent.getString(columnName);
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String columnName)
/*      */     throws SQLException
/*      */   {
/*  386 */     return this.parent.getBoolean(columnName);
/*      */   }
/*      */ 
/*      */   public byte getByte(String columnName)
/*      */     throws SQLException
/*      */   {
/*  399 */     return this.parent.getByte(columnName);
/*      */   }
/*      */ 
/*      */   public short getShort(String columnName)
/*      */     throws SQLException
/*      */   {
/*  412 */     return this.parent.getShort(columnName);
/*      */   }
/*      */ 
/*      */   public int getInt(String columnName)
/*      */     throws SQLException
/*      */   {
/*  425 */     return this.parent.getInt(columnName);
/*      */   }
/*      */ 
/*      */   public long getLong(String columnName)
/*      */     throws SQLException
/*      */   {
/*  438 */     return this.parent.getLong(columnName);
/*      */   }
/*      */ 
/*      */   public float getFloat(String columnName)
/*      */     throws SQLException
/*      */   {
/*  451 */     return this.parent.getFloat(columnName);
/*      */   }
/*      */ 
/*      */   public double getDouble(String columnName)
/*      */     throws SQLException
/*      */   {
/*  464 */     return this.parent.getDouble(columnName);
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName, int scale)
/*      */     throws SQLException
/*      */   {
/*  478 */     return this.parent.getBigDecimal(columnName, scale);
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String columnName)
/*      */     throws SQLException
/*      */   {
/*  491 */     return this.parent.getBytes(columnName);
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName)
/*      */     throws SQLException
/*      */   {
/*  504 */     return this.parent.getDate(columnName);
/*      */   }
/*      */ 
/*      */   public Time getTime(String columnName)
/*      */     throws SQLException
/*      */   {
/*  517 */     return this.parent.getTime(columnName);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName)
/*      */     throws SQLException
/*      */   {
/*  530 */     return this.parent.getTimestamp(columnName);
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(String columnName)
/*      */     throws SQLException
/*      */   {
/*  544 */     return this.parent.getAsciiStream(columnName);
/*      */   }
/*      */ 
/*      */   public InputStream getUnicodeStream(String columnName)
/*      */     throws SQLException
/*      */   {
/*  558 */     return this.parent.getUnicodeStream(columnName);
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(String columnName)
/*      */     throws SQLException
/*      */   {
/*  572 */     return this.parent.getBinaryStream(columnName);
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/*  583 */     return this.parent.getWarnings();
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  593 */     this.parent.getWarnings();
/*      */   }
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/*  604 */     return this.parent.getCursorName();
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  615 */     return this.parent.getMetaData();
/*      */   }
/*      */ 
/*      */   public Object getObject(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  628 */     return this.parent.getObject(columnIndex);
/*      */   }
/*      */ 
/*      */   public Object getObject(String columnName)
/*      */     throws SQLException
/*      */   {
/*  641 */     return this.parent.getObject(columnName);
/*      */   }
/*      */ 
/*      */   public int findColumn(String columnName)
/*      */     throws SQLException
/*      */   {
/*  654 */     return this.parent.findColumn(columnName);
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  668 */     return this.parent.getCharacterStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(String columnName)
/*      */     throws SQLException
/*      */   {
/*  682 */     return this.parent.getCharacterStream(columnName);
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  696 */     return this.parent.getBigDecimal(columnIndex);
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName)
/*      */     throws SQLException
/*      */   {
/*  710 */     return this.parent.getBigDecimal(columnName);
/*      */   }
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  722 */     return this.parent.isBeforeFirst();
/*      */   }
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  734 */     return this.parent.isAfterLast();
/*      */   }
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  745 */     return this.parent.isFirst();
/*      */   }
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  756 */     return this.parent.isLast();
/*      */   }
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  766 */     this.parent.beforeFirst();
/*      */   }
/*      */ 
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  776 */     this.parent.afterLast();
/*      */   }
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/*  787 */     return this.parent.first();
/*      */   }
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/*  798 */     return this.parent.last();
/*      */   }
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/*  809 */     return this.parent.getRow();
/*      */   }
/*      */ 
/*      */   public boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  823 */     return this.parent.absolute(row);
/*      */   }
/*      */ 
/*      */   public boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/*  837 */     return this.parent.relative(rows);
/*      */   }
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/*  848 */     return this.parent.previous();
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/*  862 */     this.parent.setFetchDirection(direction);
/*      */   }
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/*  873 */     return this.parent.getFetchDirection();
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/*  886 */     this.parent.setFetchSize(rows);
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/*  897 */     return this.parent.getFetchSize();
/*      */   }
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/*  909 */     return this.parent.getType();
/*      */   }
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/*  921 */     return this.parent.getConcurrency();
/*      */   }
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/*  933 */     return this.parent.rowUpdated();
/*      */   }
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/*  944 */     return this.parent.rowInserted();
/*      */   }
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/*  955 */     return this.parent.rowDeleted();
/*      */   }
/*      */ 
/*      */   public void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  966 */     this.parent.updateNull(columnIndex);
/*      */   }
/*      */ 
/*      */   public void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/*  978 */     this.parent.updateBoolean(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/*  990 */     this.parent.updateByte(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 1002 */     this.parent.updateShort(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 1014 */     this.parent.updateInt(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 1026 */     this.parent.updateLong(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 1038 */     this.parent.updateFloat(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1050 */     this.parent.updateDouble(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1062 */     this.parent.updateBigDecimal(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 1074 */     this.parent.updateString(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1086 */     this.parent.updateBytes(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 1098 */     this.parent.updateDate(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 1110 */     this.parent.updateTime(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 1122 */     this.parent.updateTimestamp(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1135 */     this.parent.updateAsciiStream(columnIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1148 */     this.parent.updateBinaryStream(columnIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 1161 */     this.parent.updateCharacterStream(columnIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 1175 */     this.parent.updateObject(columnIndex, x, scale);
/*      */   }
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 1187 */     this.parent.updateObject(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1198 */     this.parent.updateNull(columnName);
/*      */   }
/*      */ 
/*      */   public void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1210 */     this.parent.updateBoolean(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 1222 */     this.parent.updateByte(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 1234 */     this.parent.updateShort(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 1246 */     this.parent.updateInt(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 1258 */     this.parent.updateLong(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 1270 */     this.parent.updateFloat(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 1282 */     this.parent.updateDouble(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1294 */     this.parent.updateBigDecimal(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 1306 */     this.parent.updateString(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1318 */     this.parent.updateBytes(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 1330 */     this.parent.updateDate(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 1342 */     this.parent.updateTime(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 1354 */     this.parent.updateTimestamp(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1367 */     this.parent.updateAsciiStream(columnName, x, length);
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1380 */     this.parent.updateBinaryStream(columnName, x, length);
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1393 */     this.parent.updateCharacterStream(columnName, reader, length);
/*      */   }
/*      */ 
/*      */   public void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 1407 */     this.parent.updateObject(columnName, x, scale);
/*      */   }
/*      */ 
/*      */   public void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 1419 */     this.parent.updateObject(columnName, x);
/*      */   }
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 1430 */     this.parent.insertRow();
/*      */   }
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 1441 */     this.parent.updateRow();
/*      */   }
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/* 1452 */     this.parent.deleteRow();
/*      */   }
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 1463 */     this.parent.refreshRow();
/*      */   }
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/* 1474 */     this.parent.cancelRowUpdates();
/*      */   }
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 1484 */     this.parent.moveToInsertRow();
/*      */   }
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 1494 */     this.parent.moveToCurrentRow();
/*      */   }
/*      */ 
/*      */   public Statement getStatement()
/*      */     throws SQLException
/*      */   {
/* 1506 */     return this.parent.getStatement();
/*      */   }
/*      */ 
/*      */   public Object getObject(int i, Map map)
/*      */     throws SQLException
/*      */   {
/* 1521 */     return this.parent.getObject(i, map);
/*      */   }
/*      */ 
/*      */   public Ref getRef(int i)
/*      */     throws SQLException
/*      */   {
/* 1534 */     return this.parent.getRef(i);
/*      */   }
/*      */ 
/*      */   public Blob getBlob(int i)
/*      */     throws SQLException
/*      */   {
/* 1547 */     return this.parent.getBlob(i);
/*      */   }
/*      */ 
/*      */   public Clob getClob(int i)
/*      */     throws SQLException
/*      */   {
/* 1560 */     return this.parent.getClob(i);
/*      */   }
/*      */ 
/*      */   public Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1573 */     return this.parent.getArray(i);
/*      */   }
/*      */ 
/*      */   public Object getObject(String colName, Map map)
/*      */     throws SQLException
/*      */   {
/* 1588 */     return this.parent.getObject(colName, map);
/*      */   }
/*      */ 
/*      */   public Ref getRef(String colName)
/*      */     throws SQLException
/*      */   {
/* 1601 */     return this.parent.getRef(colName);
/*      */   }
/*      */ 
/*      */   public Blob getBlob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1614 */     return this.parent.getBlob(colName);
/*      */   }
/*      */ 
/*      */   public Clob getClob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1627 */     return this.parent.getClob(colName);
/*      */   }
/*      */ 
/*      */   public Array getArray(String colName)
/*      */     throws SQLException
/*      */   {
/* 1640 */     return this.parent.getArray(colName);
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1655 */     return this.parent.getDate(columnIndex, cal);
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1670 */     return this.parent.getDate(columnName, cal);
/*      */   }
/*      */ 
/*      */   public Time getTime(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1685 */     return this.parent.getTime(columnIndex, cal);
/*      */   }
/*      */ 
/*      */   public Time getTime(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1700 */     return this.parent.getTime(columnName, cal);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1715 */     return this.parent.getTimestamp(columnIndex, cal);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1730 */     return this.parent.getTimestamp(columnName, cal);
/*      */   }
/*      */ 
/*      */   public URL getURL(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1744 */     return this.parent.getURL(columnIndex);
/*      */   }
/*      */ 
/*      */   public URL getURL(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1758 */     return this.parent.getURL(columnName);
/*      */   }
/*      */ 
/*      */   public void updateRef(int columnIndex, Ref x)
/*      */     throws SQLException
/*      */   {
/* 1770 */     this.parent.updateRef(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateRef(String columnName, Ref x)
/*      */     throws SQLException
/*      */   {
/* 1782 */     this.parent.updateRef(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateBlob(int columnIndex, Blob x)
/*      */     throws SQLException
/*      */   {
/* 1794 */     this.parent.updateBlob(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateBlob(String columnName, Blob x)
/*      */     throws SQLException
/*      */   {
/* 1806 */     this.parent.updateBlob(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateClob(int columnIndex, Clob x)
/*      */     throws SQLException
/*      */   {
/* 1818 */     this.parent.updateClob(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateClob(String columnName, Clob x)
/*      */     throws SQLException
/*      */   {
/* 1830 */     this.parent.updateClob(columnName, x);
/*      */   }
/*      */ 
/*      */   public void updateArray(int columnIndex, Array x)
/*      */     throws SQLException
/*      */   {
/* 1842 */     this.parent.updateArray(columnIndex, x);
/*      */   }
/*      */ 
/*      */   public void updateArray(String columnName, Array x)
/*      */     throws SQLException
/*      */   {
/* 1854 */     this.parent.updateArray(columnName, x);
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.LogicResultSet
 * JD-Core Version:    0.5.4
 */