/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.IMutilTransactionDatasource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionDatasource;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.DataSource;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Pool;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class DataSourceTemplate
/*     */ {
/*  25 */   private static transient Log log = LogFactory.getLog(DataSourceTemplate.class);
/*     */   public static final String CENTER_FLAG = "{CENTER}";
/*  29 */   private static final HashMap TEMPLATE = new HashMap();
/*     */ 
/*     */   public static String getTemplate(String ds)
/*     */   {
/*  57 */     return (String)TEMPLATE.get(ds);
/*     */   }
/*     */ 
/*     */   public static String getCurrentTemplate()
/*     */     throws Exception
/*     */   {
/*  66 */     return getTemplate(getCurrentDataSource());
/*     */   }
/*     */ 
/*     */   public static String getCurrentDataSource()
/*     */     throws Exception
/*     */   {
/*  75 */     String ds = (String)IDataSource.CUR_DATASOURCE.get();
/*  76 */     if (ds == null) {
/*  77 */       if (ServiceManager.getSession() instanceof ITransactionDatasource) {
/*  78 */         ITransactionDatasource objITransactionDatasource = (ITransactionDatasource)ServiceManager.getSession();
/*  79 */         ds = objITransactionDatasource.getTxDataSource();
/*  80 */         if (log.isInfoEnabled())
/*     */         {
/*  82 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.getds_empty_warn", new String[] { ds }));
/*     */         }
/*     */       }
/*  85 */       else if (ServiceManager.getSession() instanceof IMutilTransactionDatasource) {
/*  86 */         IMutilTransactionDatasource objIMutilTransactionDatasource = (IMutilTransactionDatasource)ServiceManager.getSession();
/*  87 */         ds = objIMutilTransactionDatasource.getCurDataSource();
/*  88 */         if (log.isInfoEnabled())
/*     */         {
/*  90 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.getds_empty_usecurrent", new String[] { ds }));
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*  96 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.no_datasource"));
/*     */       }
/*     */     }
/*     */ 
/* 100 */     if (ds == null)
/*     */     {
/* 103 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.no_datasource"));
/*     */     }
/* 105 */     return ds;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  33 */       Pool[] pool = XMLHelper.getInstance().getDefaults().getDatasource().getPools();
/*  34 */       for (int i = 0; i < pool.length; ++i) {
/*  35 */         if (!StringUtils.isBlank(pool[i].getTemplate())) {
/*  36 */           TEMPLATE.put(pool[i].getName(), pool[i].getTemplate());
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  42 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.gettemplate_error"), ex);
/*  43 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.DataSourceTemplate
 * JD-Core Version:    0.5.4
 */