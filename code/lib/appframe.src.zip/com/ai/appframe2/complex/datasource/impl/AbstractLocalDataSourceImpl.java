/*     */ package com.ai.appframe2.complex.datasource.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.datasource.DataBaseConnectURL;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.complex.util.e.K;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Pool;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.dbcp.BasicDataSource;
/*     */ import org.apache.commons.dbcp.BasicDataSourceFactory;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public abstract class AbstractLocalDataSourceImpl
/*     */   implements IDataSource
/*     */ {
/*  42 */   private static transient Log log = LogFactory.getLog(AbstractLocalDataSourceImpl.class);
/*     */ 
/*  44 */   protected static final HashMap DATASOURCE_MAP = new HashMap();
/*  45 */   protected static final HashMap URL_MAP = new HashMap();
/*  46 */   protected static String primaryDataSource = null;
/*     */ 
/*     */   public AbstractLocalDataSourceImpl()
/*     */     throws Exception
/*     */   {
/*  53 */     Pool[] pool = XMLHelper.getInstance().getDefaults().getDatasource().getPools();
/*     */ 
/*  55 */     List left = new ArrayList();
/*  56 */     Pool primary = null;
/*  57 */     for (int i = 0; i < pool.length; ++i) {
/*  58 */       if ((!StringUtils.isBlank(pool[i].getPrimary())) && (pool[i].getPrimary().equalsIgnoreCase("true"))) {
/*  59 */         if (primary == null) {
/*  60 */           primary = pool[i];
/*  61 */           continue;
/*     */         }
/*     */ 
/*  64 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.multiple_dspool");
/*  65 */         throw new Exception(msg);
/*     */       }
/*     */ 
/*  69 */       left.add(pool[i]);
/*     */     }
/*     */ 
/*  73 */     if (primary == null)
/*     */     {
/*  75 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.multiple_dspool");
/*  76 */       throw new Exception(msg);
/*     */     }
/*     */ 
/*  79 */     primaryDataSource = primary.getName();
/*     */ 
/*  82 */     boolean isPrefetch = false;
/*  83 */     Property[] clazzProperty = XMLHelper.getInstance().getDefaults().getDatasource().getClazz().getProperties();
/*  84 */     if (clazzProperty != null)
/*  85 */       for (int i = 0; i < clazzProperty.length; ++i) {
/*  86 */         if ((!clazzProperty[i].getName().equalsIgnoreCase("prefetch")) || (!clazzProperty[i].getValue().equalsIgnoreCase("true")))
/*     */           continue;
/*  88 */         isPrefetch = true;
/*  89 */         break;
/*     */       }
/*     */     HashMap map;
/*     */     Iterator iter;
/*  94 */     if (isPrefetch) {
/*  95 */       if (log.isDebugEnabled()) {
/*  96 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_type"));
/*     */       }
/*     */ 
/*  99 */       Properties prefetchPoolProperties = new Properties();
/* 100 */       for (int i = 0; i < clazzProperty.length; ++i) {
/* 101 */         if (clazzProperty[i].getName().indexOf("prefetch.") != -1) {
/* 102 */           prefetchPoolProperties.setProperty(StringUtils.replace(clazzProperty[i].getName(), "prefetch.", "").trim(), clazzProperty[i].getValue());
/*     */         }
/*     */       }
/*     */ 
/* 106 */       if (log.isDebugEnabled()) {
/* 107 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_set_over", new String[] { maskPassword(prefetchPoolProperties).toString() }));
/*     */       }
/*     */ 
/* 110 */       javax.sql.DataSource prefetchDataSource = BasicDataSourceFactory.createDataSource(k(prefetchPoolProperties));
/* 111 */       if (log.isDebugEnabled()) {
/* 112 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_create_succeed"));
/*     */       }
/*     */ 
/* 116 */       String dbAcctTable = "cfg_db_acct";
/* 117 */       String dbUrlTable = "cfg_db_url";
/* 118 */       String dbRelatTable = "cfg_db_relat";
/* 119 */       for (int i = 0; i < clazzProperty.length; ++i) {
/* 120 */         if (clazzProperty[i].getName().equalsIgnoreCase("tableName")) {
/* 121 */           dbAcctTable = clazzProperty[i].getValue().trim();
/*     */         }
/* 123 */         else if (clazzProperty[i].getName().equalsIgnoreCase("urlTableName")) {
/* 124 */           dbUrlTable = clazzProperty[i].getValue().trim();
/*     */         }
/* 126 */         else if (clazzProperty[i].getName().equalsIgnoreCase("relatTableName")) {
/* 127 */           dbRelatTable = clazzProperty[i].getValue().trim();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 132 */       left.add(primary);
/* 133 */       HashMap map = getPoolCompletionInfoWhenPrefetch(prefetchDataSource, dbAcctTable, dbUrlTable, dbRelatTable, (Pool[])(Pool[])left.toArray(new Pool[0]));
/* 134 */       Set keys = map.keySet();
/* 135 */       for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 136 */         Pool item = (Pool)iter.next();
/*     */         try {
/* 138 */           Properties leftPoolProperties = (Properties)map.get(item);
/* 139 */           javax.sql.DataSource leftDataSource = BasicDataSourceFactory.createDataSource(k(leftPoolProperties));
/*     */ 
/* 141 */           if ((!StringUtils.isBlank(item.getInit())) && (item.getInit().equalsIgnoreCase("true"))) {
/* 142 */             initConnection(leftDataSource);
/*     */ 
/* 144 */             if (log.isDebugEnabled()) {
/* 145 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_init", new String[] { item.getName().trim() }));
/*     */             }
/*     */           }
/*     */ 
/* 149 */           DATASOURCE_MAP.put(item.getName().trim(), leftDataSource);
/*     */ 
/* 152 */           StringBuilder sb = new StringBuilder();
/* 153 */           Set set = leftPoolProperties.keySet();
/* 154 */           for (Iterator tmp = set.iterator(); tmp.hasNext(); ) {
/* 155 */             String tmpItem = (String)tmp.next();
/* 156 */             if (!tmpItem.equalsIgnoreCase("password")) {
/* 157 */               sb.append(tmpItem + "=" + leftPoolProperties.getProperty(tmpItem) + ",");
/*     */             }
/*     */           }
/* 160 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_create_attr", new String[] { item.getName().trim(), sb.toString() }));
/*     */         }
/*     */         catch (Exception ex) {
/* 163 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_create_failed", new String[] { item.getName().trim() }), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 168 */       ((BasicDataSource)prefetchDataSource).close();
/* 169 */       prefetchDataSource = null;
/* 170 */       if (log.isDebugEnabled()) {
/* 171 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_destroy_succeed"));
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 176 */       if (log.isDebugEnabled()) {
/* 177 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.common_type"));
/*     */       }
/*     */ 
/* 180 */       Properties basePoolProperties = new Properties();
/* 181 */       Property[] baseProperty = primary.getProperties();
/* 182 */       for (int i = 0; i < baseProperty.length; ++i) {
/* 183 */         basePoolProperties.setProperty(baseProperty[i].getName(), baseProperty[i].getValue());
/*     */       }
/*     */ 
/* 186 */       if (log.isDebugEnabled())
/*     */       {
/* 188 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.common_set_over", new String[] { primary.getName().trim(), maskPassword(basePoolProperties).toString() }));
/*     */       }
/*     */ 
/* 191 */       javax.sql.DataSource baseDataSource = BasicDataSourceFactory.createDataSource(k(basePoolProperties));
/* 192 */       DATASOURCE_MAP.put(primary.getName().trim(), baseDataSource);
/*     */ 
/* 194 */       URL_MAP.put(primary.getName().trim(), basePoolProperties.getProperty("url"));
/*     */ 
/* 196 */       if (log.isDebugEnabled())
/*     */       {
/* 198 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.common_baseds_create_succeed", new String[] { primary.getName().trim() }));
/*     */       }
/*     */ 
/* 202 */       Property[] tableProperties = XMLHelper.getInstance().getDefaults().getDatasource().getClazz().getProperties();
/* 203 */       String tableName = "cfg_db_acct";
/* 204 */       for (int i = 0; i < tableProperties.length; ++i) {
/* 205 */         if (tableProperties[i].getName().equalsIgnoreCase("tableName")) {
/* 206 */           tableName = tableProperties[i].getValue().trim();
/* 207 */           break;
/*     */         }
/*     */       }
/* 210 */       map = getPoolCompletionInfo(baseDataSource, tableName, (Pool[])(Pool[])left.toArray(new Pool[0]));
/* 211 */       Set keys = map.keySet();
/* 212 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/* 213 */         Pool item = (Pool)iter.next();
/*     */         try {
/* 215 */           Properties leftPoolProperties = (Properties)map.get(item);
/* 216 */           javax.sql.DataSource leftDataSource = BasicDataSourceFactory.createDataSource(k(leftPoolProperties));
/*     */ 
/* 218 */           if ((!StringUtils.isBlank(item.getInit())) && (item.getInit().equalsIgnoreCase("true"))) {
/* 219 */             initConnection(leftDataSource);
/* 220 */             if (log.isDebugEnabled()) {
/* 221 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.common_ds_create_succeed", new String[] { item.getName().trim() }));
/*     */             }
/*     */           }
/*     */ 
/* 225 */           DATASOURCE_MAP.put(item.getName().trim(), leftDataSource);
/*     */ 
/* 227 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.common_ds_create_succeed", new String[] { item.getName().trim() }));
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 231 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.prefetch_ds_create_failed", new String[] { item.getName().trim() }), ex);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initConnection(javax.sql.DataSource dataSource)
/*     */     throws Exception
/*     */   {
/* 246 */     Connection conn = null;
/*     */     try {
/* 248 */       conn = dataSource.getConnection();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 254 */       if (conn != null)
/* 255 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private HashMap getPoolCompletionInfo(javax.sql.DataSource baseDataSource, String tableName, Pool[] pool)
/*     */     throws Exception
/*     */   {
/* 269 */     HashMap rtn = new HashMap();
/*     */ 
/* 271 */     for (int i = 0; i < pool.length; ++i) {
/* 272 */       Connection conn = null;
/* 273 */       PreparedStatement ptmt = null;
/* 274 */       ResultSet rs = null;
/*     */       try {
/* 276 */         conn = baseDataSource.getConnection();
/* 277 */         ptmt = conn.prepareStatement("select * from " + tableName + " where db_acct_code = ? and state ='U'");
/* 278 */         ptmt.setString(1, pool[i].getName().trim());
/* 279 */         rs = ptmt.executeQuery();
/*     */ 
/* 281 */         Properties properties = new Properties();
/* 282 */         int j = 0;
/* 283 */         while (rs.next()) {
/* 284 */           if (j > 1)
/*     */           {
/* 287 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.key_record_nomatch", new String[] { pool[i].getName().trim(), tableName }));
/*     */           }
/*     */ 
/* 290 */           String host = rs.getString("HOST");
/* 291 */           if (host.equalsIgnoreCase("MYSQL_JDBC")) {
/* 292 */             properties.put("maxActive", rs.getString("DEFAULT_CONN_MAX"));
/* 293 */             properties.put("initialSize", rs.getString("DEFAULT_CONN_MIN"));
/* 294 */             properties.put("maxIdle", rs.getString("DEFAULT_CONN_MAX"));
/* 295 */             properties.put("username", rs.getString("USERNAME"));
/* 296 */             properties.put("password", rs.getString("PASSWORD"));
/* 297 */             String url = rs.getString("SID");
/* 298 */             properties.put("url", url);
/*     */ 
/* 300 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 301 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 302 */             objDataBaseConnectURL.setHost("MYSQL_JDBC");
/* 303 */             objDataBaseConnectURL.setPort("0");
/* 304 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 306 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/* 308 */           else if (host.equalsIgnoreCase("DB2_JDBC")) {
/* 309 */             properties.put("maxActive", rs.getString("DEFAULT_CONN_MAX"));
/* 310 */             properties.put("initialSize", rs.getString("DEFAULT_CONN_MIN"));
/* 311 */             properties.put("maxIdle", rs.getString("DEFAULT_CONN_MAX"));
/* 312 */             properties.put("username", rs.getString("USERNAME"));
/* 313 */             properties.put("password", rs.getString("PASSWORD"));
/* 314 */             String url = rs.getString("SID");
/* 315 */             properties.put("url", url);
/*     */ 
/* 317 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 318 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 319 */             objDataBaseConnectURL.setHost("DB2_JDBC");
/* 320 */             objDataBaseConnectURL.setPort("0");
/* 321 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 323 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/* 325 */           else if (host.equalsIgnoreCase("SYBASE_JDBC")) {
/* 326 */             properties.put("maxActive", rs.getString("DEFAULT_CONN_MAX"));
/* 327 */             properties.put("initialSize", rs.getString("DEFAULT_CONN_MIN"));
/* 328 */             properties.put("maxIdle", rs.getString("DEFAULT_CONN_MAX"));
/* 329 */             properties.put("username", rs.getString("USERNAME"));
/* 330 */             properties.put("password", rs.getString("PASSWORD"));
/* 331 */             String url = rs.getString("SID");
/* 332 */             properties.put("url", url);
/*     */ 
/* 334 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 335 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 336 */             objDataBaseConnectURL.setHost("SYBASE_JDBC");
/* 337 */             objDataBaseConnectURL.setPort("0");
/* 338 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 340 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/*     */           else {
/* 343 */             properties.put("maxActive", rs.getString("DEFAULT_CONN_MAX"));
/* 344 */             properties.put("initialSize", rs.getString("DEFAULT_CONN_MIN"));
/* 345 */             properties.put("maxIdle", rs.getString("DEFAULT_CONN_MAX"));
/* 346 */             properties.put("username", rs.getString("USERNAME"));
/* 347 */             properties.put("password", rs.getString("PASSWORD"));
/* 348 */             String url = "jdbc:oracle:thin:@" + rs.getString("HOST") + ":" + rs.getString("PORT") + ":" + rs.getString("SID");
/* 349 */             properties.put("url", url);
/*     */ 
/* 351 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 352 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 353 */             objDataBaseConnectURL.setHost(rs.getString("HOST"));
/* 354 */             objDataBaseConnectURL.setPort(rs.getString("PORT"));
/* 355 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/* 356 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/*     */ 
/* 359 */           ++j;
/*     */         }
/*     */ 
/* 363 */         Property[] property = pool[i].getProperties();
/* 364 */         for (int k = 0; k < property.length; ++k) {
/* 365 */           properties.put(property[k].getName(), property[k].getValue());
/* 366 */           if (!log.isDebugEnabled())
/*     */             continue;
/* 368 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.reset_prop_according", new String[] { property[k].getName(), property[k].getValue() }));
/*     */         }
/*     */ 
/* 373 */         String prefix = "db.cfg." + pool[i].getName().trim() + ".";
/* 374 */         Properties systemProp = System.getProperties();
/* 375 */         Set systemKeys = systemProp.keySet();
/* 376 */         for (Iterator iter = systemKeys.iterator(); iter.hasNext(); ) {
/* 377 */           String item = (String)iter.next();
/* 378 */           if (StringUtils.indexOf(item, prefix) != -1) {
/* 379 */             String key = StringUtils.replace(item, prefix, "").trim();
/* 380 */             String value = systemProp.getProperty(item);
/* 381 */             properties.put(key, value);
/* 382 */             if (log.isDebugEnabled())
/*     */             {
/* 384 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.reset_prop_info", new String[] { key, value }));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 389 */         if (log.isDebugEnabled()) {
/* 390 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.conn_set_prop_info", new String[] { pool[i].getName().trim(), maskPassword(properties).toString() }));
/*     */         }
/*     */ 
/* 393 */         rtn.put(pool[i], properties);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/*     */       finally
/*     */       {
/* 400 */         if (rs != null) {
/* 401 */           rs.close();
/*     */         }
/* 403 */         if (ptmt != null) {
/* 404 */           ptmt.close();
/*     */         }
/* 406 */         if (conn != null) {
/* 407 */           conn.close();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 412 */     return rtn;
/*     */   }
/*     */ 
/*     */   private HashMap getPoolCompletionInfoWhenPrefetch(javax.sql.DataSource baseDataSource, String dbAcctTable, String dbUrlTable, String dbRelatTable, Pool[] pool)
/*     */     throws Exception
/*     */   {
/* 427 */     HashMap rtn = new HashMap();
/*     */ 
/* 430 */     String serverName = RuntimeServerUtil.getServerName();
/*     */ 
/* 432 */     if (StringUtils.isBlank(serverName))
/*     */     {
/* 434 */       log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.geturl_fatal"));
/* 435 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.get_servername_failed"));
/*     */     }
/*     */ 
/* 438 */     serverName = serverName.trim();
/*     */ 
/* 442 */     System.setProperty("appframe.oracle.session.module.name", "JTC " + serverName);
/* 443 */     System.setProperty("appframe.oracle.session.action.name", "JAVA");
/*     */ 
/* 445 */     boolean isExPproperties = false;
/* 446 */     HashMap selectedPool = new HashMap();
/* 447 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("system/service/exe.properties");
/* 448 */     if (input != null)
/*     */     {
/* 450 */       System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.use_exefile_byprocess"));
/* 451 */       isExPproperties = true;
/* 452 */       Properties p = new Properties();
/* 453 */       p.load(input);
/*     */ 
/* 455 */       String ds = p.getProperty(serverName + ".datasource");
/* 456 */       if (StringUtils.isBlank(ds)) {
/* 457 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.server_nods_warn", new String[] { serverName }));
/*     */       }
/*     */ 
/* 461 */       serverName = p.getProperty(serverName + ".relat");
/* 462 */       if (StringUtils.isBlank(serverName)) {
/* 463 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.server_relatnods_warn", new String[] { serverName }));
/*     */       }
/*     */ 
/* 466 */       String[] dsArray = StringUtils.split(ds, ",");
/* 467 */       for (int i = 0; i < dsArray.length; ++i) {
/* 468 */         selectedPool.put(dsArray[i], null);
/*     */       }
/* 470 */       System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.use_ds", new String[] { StringUtils.join(dsArray, "  ") }));
/*     */     }
/*     */     else {
/* 473 */       isExPproperties = false;
/*     */     }
/*     */ 
/* 476 */     for (int i = 0; i < pool.length; ++i) {
/* 477 */       if ((isExPproperties) && (!selectedPool.containsKey(pool[i].getName())))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 482 */       Connection conn = null;
/* 483 */       PreparedStatement ptmt = null;
/* 484 */       ResultSet rs = null;
/*     */       try {
/* 486 */         conn = baseDataSource.getConnection();
/* 487 */         ptmt = conn.prepareStatement("select * from " + dbAcctTable + " where db_acct_code = ? and state ='U'");
/* 488 */         ptmt.setString(1, pool[i].getName().trim());
/* 489 */         rs = ptmt.executeQuery();
/*     */ 
/* 491 */         Properties properties = new Properties();
/* 492 */         int j = 0;
/* 493 */         while (rs.next()) {
/* 494 */           if (j > 1)
/*     */           {
/* 497 */             throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.key_record_nomatch", new String[] { pool[i].getName().trim(), "cfg_db_acct" }));
/*     */           }
/*     */ 
/* 500 */           String url = null;
/* 501 */           String isAdvance = pool[i].getIsAdvanceUrl();
/* 502 */           String host = rs.getString("HOST");
/*     */ 
/* 504 */           if (host.equalsIgnoreCase("MYSQL_JDBC"))
/*     */           {
/* 506 */             if ((!StringUtils.isBlank(isAdvance)) && (((isAdvance.trim().equalsIgnoreCase("true")) || (isAdvance.trim().equalsIgnoreCase("y"))))) {
/* 507 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_mysql"));
/*     */             }
/*     */ 
/* 510 */             url = rs.getString("SID");
/* 511 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 512 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 513 */             objDataBaseConnectURL.setHost("MYSQL_JDBC");
/* 514 */             objDataBaseConnectURL.setPort("0");
/* 515 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 517 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/* 520 */           else if (host.equalsIgnoreCase("DB2_JDBC"))
/*     */           {
/* 522 */             if ((!StringUtils.isBlank(isAdvance)) && (((isAdvance.trim().equalsIgnoreCase("true")) || (isAdvance.trim().equalsIgnoreCase("y"))))) {
/* 523 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_db2"));
/*     */             }
/*     */ 
/* 526 */             url = rs.getString("SID");
/* 527 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 528 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 529 */             objDataBaseConnectURL.setHost("DB2_JDBC");
/* 530 */             objDataBaseConnectURL.setPort("0");
/* 531 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 533 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/* 536 */           else if (host.equalsIgnoreCase("SYBASE_JDBC"))
/*     */           {
/* 538 */             if ((!StringUtils.isBlank(isAdvance)) && (((isAdvance.trim().equalsIgnoreCase("true")) || (isAdvance.trim().equalsIgnoreCase("y"))))) {
/* 539 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_sysbase"));
/*     */             }
/*     */ 
/* 542 */             url = rs.getString("SID");
/* 543 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 544 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 545 */             objDataBaseConnectURL.setHost("SYBASE_JDBC");
/* 546 */             objDataBaseConnectURL.setPort("0");
/* 547 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 549 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/* 554 */           else if ((!StringUtils.isBlank(isAdvance)) && (((isAdvance.trim().equalsIgnoreCase("true")) || (isAdvance.trim().equalsIgnoreCase("y"))))) {
/* 555 */             if (log.isDebugEnabled()) {
/* 556 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_url_info", new String[] { pool[i].getName().trim() }));
/*     */             }
/*     */ 
/* 559 */             String advUrl = getAdvanceUrlByDbAcctCode(conn, serverName, dbUrlTable, dbRelatTable, pool[i].getName().trim());
/* 560 */             url = "jdbc:oracle:thin:@" + advUrl;
/*     */ 
/* 562 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 563 */             objDataBaseConnectURL.setIsAdvanceUrl(true);
/* 564 */             objDataBaseConnectURL.setAdvanceUrl(advUrl);
/* 565 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/*     */           else {
/* 568 */             url = "jdbc:oracle:thin:@" + rs.getString("HOST") + ":" + rs.getString("PORT") + ":" + rs.getString("SID");
/* 569 */             DataBaseConnectURL objDataBaseConnectURL = new DataBaseConnectURL();
/* 570 */             objDataBaseConnectURL.setIsAdvanceUrl(false);
/* 571 */             objDataBaseConnectURL.setHost(rs.getString("HOST"));
/* 572 */             objDataBaseConnectURL.setPort(rs.getString("PORT"));
/* 573 */             objDataBaseConnectURL.setSid(rs.getString("SID"));
/*     */ 
/* 575 */             URL_MAP.put(pool[i].getName(), objDataBaseConnectURL);
/*     */           }
/*     */ 
/* 579 */           properties.put("maxActive", rs.getString("DEFAULT_CONN_MAX"));
/* 580 */           properties.put("initialSize", rs.getString("DEFAULT_CONN_MIN"));
/* 581 */           properties.put("maxIdle", rs.getString("DEFAULT_CONN_MAX"));
/* 582 */           properties.put("username", rs.getString("USERNAME"));
/* 583 */           properties.put("password", rs.getString("PASSWORD"));
/* 584 */           properties.put("url", url);
/*     */ 
/* 586 */           ++j;
/*     */         }
/*     */ 
/* 590 */         Property[] property = pool[i].getProperties();
/* 591 */         for (int k = 0; k < property.length; ++k) {
/* 592 */           properties.put(property[k].getName(), property[k].getValue());
/* 593 */           if (!log.isDebugEnabled())
/*     */             continue;
/* 595 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.reset_prop_info", new String[] { property[k].getName(), property[k].getValue() }));
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 601 */           Properties cfgDbJdbcParameter = getCfgDbJdbcParameter(conn, serverName, pool[i].getName().trim());
/* 602 */           if ((cfgDbJdbcParameter != null) && (!cfgDbJdbcParameter.isEmpty())) {
/* 603 */             if (cfgDbJdbcParameter.containsKey("username"))
/*     */             {
/* 606 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.table_param_error", new String[] { "username" }));
/*     */             }
/* 608 */             if (cfgDbJdbcParameter.containsKey("password"))
/*     */             {
/* 611 */               throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.table_param_error", new String[] { "password" }));
/*     */             }
/*     */ 
/* 614 */             Set tmpKey = cfgDbJdbcParameter.keySet();
/* 615 */             for (Iterator iter = tmpKey.iterator(); iter.hasNext(); ) {
/* 616 */               String item = (String)iter.next();
/* 617 */               properties.setProperty(item, cfgDbJdbcParameter.getProperty(item));
/*     */             }
/*     */ 
/* 620 */             System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.query_bydb_enable", new String[] { serverName, pool[i].getName().trim() }));
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/* 626 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.reset_conn_error"), ex);
/*     */         }
/*     */ 
/* 630 */         String prefix = "db.cfg." + pool[i].getName().trim() + ".";
/* 631 */         Properties systemProp = System.getProperties();
/* 632 */         Set systemKeys = systemProp.keySet();
/* 633 */         for (Iterator iter = systemKeys.iterator(); iter.hasNext(); ) {
/* 634 */           String item = (String)iter.next();
/* 635 */           if (StringUtils.indexOf(item, prefix) != -1) {
/* 636 */             String key = StringUtils.replace(item, prefix, "").trim();
/* 637 */             String value = systemProp.getProperty(item);
/* 638 */             properties.put(key, value);
/* 639 */             if (log.isDebugEnabled())
/*     */             {
/* 641 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.reset_prop_info", new String[] { key, value }));
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 646 */         if (log.isDebugEnabled()) {
/* 647 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.conn_set_prop_info", new String[] { pool[i].getName().trim(), properties.toString() }));
/*     */         }
/*     */ 
/* 650 */         rtn.put(pool[i], properties);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/*     */       finally
/*     */       {
/* 657 */         if (rs != null) {
/* 658 */           rs.close();
/*     */         }
/* 660 */         if (ptmt != null) {
/* 661 */           ptmt.close();
/*     */         }
/* 663 */         if (conn != null) {
/* 664 */           conn.close();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 669 */     return rtn;
/*     */   }
/*     */ 
/*     */   private Properties getCfgDbJdbcParameter(Connection conn, String serverName, String dbAcctCode)
/*     */     throws Exception
/*     */   {
/* 681 */     Properties p = new Properties();
/* 682 */     PreparedStatement ptmt = null;
/* 683 */     ResultSet rs = null;
/*     */     try {
/* 685 */       ptmt = conn.prepareStatement("select * from cfg_db_jdbc_parameter where server_name = ? and db_acct_code = ? and state = 'U' ");
/* 686 */       ptmt.setString(1, serverName);
/* 687 */       ptmt.setString(2, dbAcctCode);
/* 688 */       rs = ptmt.executeQuery();
/*     */ 
/* 690 */       while (rs.next()) {
/* 691 */         String name = rs.getString("NAME");
/* 692 */         String value = rs.getString("VALUE");
/* 693 */         if ((!StringUtils.isBlank(name)) && (!StringUtils.isBlank(value)))
/* 694 */           p.setProperty(name.trim(), value.trim());
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 702 */       if (rs != null) {
/* 703 */         rs.close();
/*     */       }
/* 705 */       if (ptmt != null) {
/* 706 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/* 710 */     return p;
/*     */   }
/*     */ 
/*     */   private String getAdvanceUrlByDbAcctCode(Connection conn, String serverName, String dbUrlTable, String dbRelatTable, String dbAcctCode)
/*     */     throws Exception
/*     */   {
/* 724 */     String url = null;
/*     */ 
/* 726 */     PreparedStatement ptmt = null;
/* 727 */     ResultSet rs = null;
/*     */     try {
/* 729 */       ptmt = conn.prepareStatement("select c2.url as URL from " + dbRelatTable + " c1," + dbUrlTable + " c2 where c1.url_name = c2.name and c1.db_acct_code = ? and c1.server_name = ? and c1.state='U' and c2.state = 'U' ");
/*     */ 
/* 731 */       ptmt.setString(1, dbAcctCode);
/* 732 */       ptmt.setString(2, serverName);
/* 733 */       rs = ptmt.executeQuery();
/*     */ 
/* 735 */       int j = 0;
/* 736 */       while (rs.next()) {
/* 737 */         if (j > 1)
/*     */         {
/* 739 */           log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_attr_error", new String[] { dbAcctCode, serverName, dbRelatTable }));
/* 740 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_attr_error", new String[] { dbAcctCode, serverName, dbRelatTable }));
/*     */         }
/*     */ 
/* 743 */         url = rs.getString("URL").trim();
/*     */ 
/* 745 */         ++j;
/*     */       }
/*     */ 
/* 748 */       if (j == 0) {
/* 749 */         log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_attr_error_nodata", new String[] { dbAcctCode, serverName }));
/* 750 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.advance_attr_error_nodata", new String[] { dbAcctCode, serverName }));
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 757 */       if (rs != null) {
/* 758 */         rs.close();
/*     */       }
/* 760 */       if (ptmt != null) {
/* 761 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/* 765 */     return url;
/*     */   }
/*     */ 
/*     */   private Properties k(Properties p)
/*     */     throws Exception
/*     */   {
/* 775 */     Set keys = p.keySet();
/* 776 */     for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 777 */       String item = (String)iter.next();
/* 778 */       p.setProperty(item, K.k_s(p.getProperty(item)));
/*     */     }
/* 780 */     return p;
/*     */   }
/*     */ 
/*     */   private Properties maskPassword(Properties p)
/*     */     throws Exception
/*     */   {
/* 790 */     Properties rtn = new Properties();
/*     */ 
/* 792 */     Set keys = p.keySet();
/* 793 */     for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 794 */       String item = (String)iter.next();
/* 795 */       if (!StringUtils.contains(item, "password")) {
/* 796 */         rtn.setProperty(item, p.getProperty(item));
/*     */       }
/*     */     }
/* 799 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 807 */     if (log.isInfoEnabled())
/* 808 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.ds_start_warn"));
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */     throws Exception
/*     */   {
/*     */     Iterator iter;
/* 817 */     if ((DATASOURCE_MAP != null) && (DATASOURCE_MAP.size() != 0)) {
/* 818 */       Set keys = DATASOURCE_MAP.keySet();
/* 819 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/* 820 */         Object item = iter.next();
/* 821 */         BasicDataSource objBasicDataSource = (BasicDataSource)DATASOURCE_MAP.get(item);
/* 822 */         objBasicDataSource.close();
/* 823 */         if (log.isInfoEnabled())
/* 824 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.impl.ds_stop_warn", new String[] { item.toString() }));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public HashMap getURLMap()
/*     */     throws Exception
/*     */   {
/* 836 */     return URL_MAP;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.impl.AbstractLocalDataSourceImpl
 * JD-Core Version:    0.5.4
 */