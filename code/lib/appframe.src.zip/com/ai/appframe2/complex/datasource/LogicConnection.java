/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class LogicConnection
/*     */   implements Connection
/*     */ {
/*  25 */   private Connection physicalConnection = null;
/*  26 */   private boolean isIgnoreCheck = false;
/*  27 */   private int queryTimeoutSeconds = -1;
/*     */ 
/* 173 */   private boolean isClosed = false;
/*     */ 
/*     */   public LogicConnection(Connection physicalConnection)
/*     */   {
/*  33 */     if (physicalConnection == null) {
/*  34 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.physical_conn_null"));
/*     */     }
/*  36 */     this.physicalConnection = physicalConnection;
/*     */   }
/*     */ 
/*     */   public Connection getPhysicalConnection()
/*     */   {
/*  44 */     return this.physicalConnection;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  48 */     return "PhysicalConneciton:" + this.physicalConnection + ",LogicConneciton:" + super.toString();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int queryTimeoutSeconds) {
/*  52 */     this.queryTimeoutSeconds = queryTimeoutSeconds;
/*     */   }
/*     */ 
/*     */   public Statement createStatement()
/*     */     throws SQLException
/*     */   {
/*  62 */     Statement rtn = null;
/*  63 */     if ((CheckResultSet.isCheck()) && (!this.isIgnoreCheck))
/*     */     {
/*  65 */       rtn = new LogicStatement(this.physicalConnection.createStatement());
/*     */     }
/*     */     else {
/*  68 */       rtn = this.physicalConnection.createStatement();
/*     */     }
/*     */ 
/*  71 */     if ((rtn != null) && (this.queryTimeoutSeconds > 0)) {
/*  72 */       rtn.setQueryTimeout(this.queryTimeoutSeconds);
/*     */     }
/*     */ 
/*  75 */     return rtn;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/*  86 */     PreparedStatement rtn = null;
/*  87 */     if ((CheckResultSet.isCheck()) && (!this.isIgnoreCheck))
/*     */     {
/*  89 */       rtn = new LogicPreparedStatement(this.physicalConnection.prepareStatement(sql), sql);
/*     */     }
/*     */     else {
/*  92 */       rtn = this.physicalConnection.prepareStatement(sql);
/*     */     }
/*     */ 
/*  95 */     if ((rtn != null) && (this.queryTimeoutSeconds > 0)) {
/*  96 */       rtn.setQueryTimeout(this.queryTimeoutSeconds);
/*     */     }
/*     */ 
/*  99 */     return rtn;
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql)
/*     */     throws SQLException
/*     */   {
/* 111 */     return this.physicalConnection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */   public String nativeSQL(String sql)
/*     */     throws SQLException
/*     */   {
/* 122 */     return this.physicalConnection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {
/* 132 */     this.physicalConnection.setAutoCommit(autoCommit);
/*     */   }
/*     */ 
/*     */   public boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 142 */     return this.physicalConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws SQLException
/*     */   {
/* 153 */     throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.datasource.logic_conn_commit_warn"));
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLException
/*     */   {
/* 164 */     this.physicalConnection.rollback();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 176 */     this.isClosed = true;
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 186 */     return this.isClosed;
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 197 */     return this.physicalConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   public void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 207 */     this.physicalConnection.setReadOnly(readOnly);
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 217 */     return this.physicalConnection.isReadOnly();
/*     */   }
/*     */ 
/*     */   public void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {
/* 228 */     this.physicalConnection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */   public String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 238 */     return this.physicalConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   public void setTransactionIsolation(int level)
/*     */     throws SQLException
/*     */   {
/* 253 */     this.physicalConnection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */   public int getTransactionIsolation()
/*     */     throws SQLException
/*     */   {
/* 266 */     return this.physicalConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 276 */     return this.physicalConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 285 */     this.physicalConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 302 */     return this.physicalConnection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 321 */     return this.physicalConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 340 */     return this.physicalConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public Map getTypeMap()
/*     */     throws SQLException
/*     */   {
/* 350 */     return this.physicalConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   public void setTypeMap(Map map)
/*     */     throws SQLException
/*     */   {
/* 362 */     this.physicalConnection.setTypeMap(map);
/*     */   }
/*     */ 
/*     */   public void setHoldability(int holdability)
/*     */     throws SQLException
/*     */   {
/* 375 */     this.physicalConnection.setHoldability(holdability);
/*     */   }
/*     */ 
/*     */   public int getHoldability()
/*     */     throws SQLException
/*     */   {
/* 387 */     return this.physicalConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint()
/*     */     throws SQLException
/*     */   {
/* 399 */     return this.physicalConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint(String name)
/*     */     throws SQLException
/*     */   {
/* 412 */     return this.physicalConnection.setSavepoint(name);
/*     */   }
/*     */ 
/*     */   public void rollback(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 423 */     this.physicalConnection.rollback(savepoint);
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 434 */     this.physicalConnection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 454 */     return this.physicalConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 476 */     return this.physicalConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 498 */     return this.physicalConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 513 */     return this.physicalConnection.prepareStatement(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 528 */     return this.physicalConnection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 543 */     return this.physicalConnection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public void ignoreCheck()
/*     */   {
/* 550 */     this.isIgnoreCheck = true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.LogicConnection
 * JD-Core Version:    0.5.4
 */