/*     */ package com.ai.appframe2.complex.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LogicStatement
/*     */   implements Statement
/*     */ {
/*  21 */   private static transient Log log = LogFactory.getLog(LogicStatement.class);
/*     */ 
/*  23 */   private Statement parent = null;
/*     */ 
/*     */   public LogicStatement(Statement parent)
/*     */   {
/*  31 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql)
/*     */     throws SQLException
/*     */   {
/*  44 */     return new LogicResultSet(this, this.parent.executeQuery(sql), sql);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql)
/*     */     throws SQLException
/*     */   {
/*  59 */     return this.parent.executeUpdate(sql);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*  69 */     this.parent.close();
/*     */   }
/*     */ 
/*     */   public int getMaxFieldSize()
/*     */     throws SQLException
/*     */   {
/*  80 */     return this.parent.getMaxFieldSize();
/*     */   }
/*     */ 
/*     */   public void setMaxFieldSize(int max)
/*     */     throws SQLException
/*     */   {
/*  91 */     this.parent.setMaxFieldSize(max);
/*     */   }
/*     */ 
/*     */   public int getMaxRows()
/*     */     throws SQLException
/*     */   {
/* 103 */     return this.parent.getMaxRows();
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int max)
/*     */     throws SQLException
/*     */   {
/* 113 */     this.parent.setMaxRows(max);
/*     */   }
/*     */ 
/*     */   public void setEscapeProcessing(boolean enable)
/*     */     throws SQLException
/*     */   {
/* 123 */     this.parent.setEscapeProcessing(enable);
/*     */   }
/*     */ 
/*     */   public int getQueryTimeout()
/*     */     throws SQLException
/*     */   {
/* 133 */     return this.parent.getQueryTimeout();
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int seconds)
/*     */     throws SQLException
/*     */   {
/* 144 */     this.parent.setQueryTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public void cancel()
/*     */     throws SQLException
/*     */   {
/* 153 */     this.parent.cancel();
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 163 */     return this.parent.getWarnings();
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 172 */     this.parent.clearWarnings();
/*     */   }
/*     */ 
/*     */   public void setCursorName(String name)
/*     */     throws SQLException
/*     */   {
/* 183 */     this.parent.setCursorName(name);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql)
/*     */     throws SQLException
/*     */   {
/* 195 */     return this.parent.execute(sql);
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet()
/*     */     throws SQLException
/*     */   {
/* 206 */     return this.parent.getResultSet();
/*     */   }
/*     */ 
/*     */   public int getUpdateCount()
/*     */     throws SQLException
/*     */   {
/* 218 */     return this.parent.getUpdateCount();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults()
/*     */     throws SQLException
/*     */   {
/* 231 */     return this.parent.getMoreResults();
/*     */   }
/*     */ 
/*     */   public void setFetchDirection(int direction)
/*     */     throws SQLException
/*     */   {
/* 244 */     this.parent.setFetchDirection(direction);
/*     */   }
/*     */ 
/*     */   public int getFetchDirection()
/*     */     throws SQLException
/*     */   {
/* 255 */     return this.parent.getFetchDirection();
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int rows)
/*     */     throws SQLException
/*     */   {
/* 267 */     this.parent.setFetchSize(rows);
/*     */   }
/*     */ 
/*     */   public int getFetchSize()
/*     */     throws SQLException
/*     */   {
/* 278 */     return this.parent.getFetchSize();
/*     */   }
/*     */ 
/*     */   public int getResultSetConcurrency()
/*     */     throws SQLException
/*     */   {
/* 289 */     return this.parent.getResultSetConcurrency();
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */     throws SQLException
/*     */   {
/* 300 */     return this.parent.getResultSetType();
/*     */   }
/*     */ 
/*     */   public void addBatch(String sql)
/*     */     throws SQLException
/*     */   {
/* 310 */     this.parent.addBatch(sql);
/*     */   }
/*     */ 
/*     */   public void clearBatch()
/*     */     throws SQLException
/*     */   {
/* 319 */     this.parent.clearBatch();
/*     */   }
/*     */ 
/*     */   public int[] executeBatch()
/*     */     throws SQLException
/*     */   {
/* 334 */     return this.parent.executeBatch();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 344 */     return this.parent.getConnection();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 363 */     return this.parent.getMoreResults(current);
/*     */   }
/*     */ 
/*     */   public ResultSet getGeneratedKeys()
/*     */     throws SQLException
/*     */   {
/* 374 */     return this.parent.getGeneratedKeys();
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 391 */     return this.parent.executeUpdate(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 408 */     return this.parent.executeUpdate(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 425 */     return this.parent.executeUpdate(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 442 */     return this.parent.execute(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 458 */     return this.parent.execute(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public boolean execute(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 474 */     return this.parent.execute(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public int getResultSetHoldability()
/*     */     throws SQLException
/*     */   {
/* 485 */     return this.parent.getResultSetHoldability();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.datasource.LogicStatement
 * JD-Core Version:    0.5.4
 */