/*     */ package com.ai.appframe2.complex.transaction.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.LogicConnection;
/*     */ import com.ai.appframe2.complex.datasource.ProxyConnection;
/*     */ import com.ai.appframe2.complex.datasource.ReadOnlyConnection;
/*     */ import com.ai.appframe2.complex.datasource.TraceConnection;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.mbean.standard.sql.SQLMonitor;
/*     */ import com.ai.appframe2.complex.mbean.standard.tm.TransactionMonitor;
/*     */ import com.ai.appframe2.complex.trace.TraceFactory;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.IMutilTransactionDatasource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionInfo;
/*     */ import com.ai.appframe2.complex.transaction.listener.ListenerFactory;
/*     */ import com.ai.appframe2.complex.util.JVMID;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.util.TxUtil;
/*     */ import com.ai.appframe2.complex.util.UUID;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocalMutilTransactionImpl extends AbstractTransactionImpl
/*     */   implements Session, IMutilTransactionDatasource, ITransactionInfo
/*     */ {
/*  46 */   private static transient Log log = LogFactory.getLog(LocalMutilTransactionImpl.class);
/*     */ 
/*  48 */   private static ThreadLocal suspend = new ThreadLocal();
/*     */ 
/*  50 */   private static ThreadLocal tx = new ThreadLocal();
/*     */ 
/*     */   public void setCurDataSource(String dataSourceName)
/*     */   {
/*  61 */     getThreadInfo().curDataSource = dataSourceName;
/*     */   }
/*     */ 
/*     */   public String getCurDataSource()
/*     */   {
/*  69 */     return getThreadInfo().curDataSource;
/*     */   }
/*     */ 
/*     */   public String getCurrentTxInfo()
/*     */   {
/*  77 */     String rtn = null;
/*  78 */     ThreadInfo objThreadInfo = getThreadInfo();
/*  79 */     if (objThreadInfo != null) {
/*  80 */       rtn = objThreadInfo.toString();
/*     */     }
/*  82 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean isStartTransaction()
/*     */   {
/*  91 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */ 
/*  93 */     return objThreadInfo != null;
/*     */   }
/*     */ 
/*     */   public void startTransaction()
/*     */     throws Exception
/*     */   {
/* 105 */     if (isStartTransaction())
/*     */     {
/* 107 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.exist_transaction", new String[] { getThreadInfo().toString() }));
/*     */     }
/* 109 */     setThreadInfo(new ThreadInfo());
/*     */ 
/* 111 */     TransactionMonitor.startIncrease();
/*     */ 
/* 113 */     ListenerFactory.onStartTransaction();
/* 114 */     if (log.isDebugEnabled())
/* 115 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.startTransaction_succeed", new String[] { getThreadInfo().toString() }));
/*     */   }
/*     */ 
/*     */   public void rollbackTransaction()
/*     */     throws Exception
/*     */   {
/* 124 */     if (!isStartTransaction())
/*     */     {
/* 126 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.roll_after_begin"));
/*     */     }
/*     */ 
/* 129 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */     try {
/* 131 */       if (objThreadInfo.txConnections.size() != 0) {
/* 132 */         List exceptions = new ArrayList();
/* 133 */         HashMap map = objThreadInfo.txConnections;
/* 134 */         Set sets = map.keySet();
/* 135 */         for (Iterator iter = sets.iterator(); iter.hasNext(); ) {
/* 136 */           String ds = (String)iter.next();
/* 137 */           Connection conn = (Connection)map.get(ds);
/*     */           try {
/* 139 */             conn.rollback();
/* 140 */             if (log.isDebugEnabled())
/*     */             {
/* 142 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.info", new String[] { ds, conn.toString(), getThreadInfo().toString() }));
/*     */             }
/*     */           }
/*     */           catch (Throwable ex) {
/* 146 */             exceptions.add(ex);
/*     */           }
/*     */           finally {
/*     */             try {
/* 150 */               if (!conn.isClosed()) {
/* 151 */                 conn.close();
/*     */               }
/*     */             }
/*     */             catch (Throwable ex)
/*     */             {
/* 156 */               log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.close_error"), ex);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 163 */         if (exceptions.size() != 0) {
/* 164 */           StringBuilder sb = new StringBuilder();
/* 165 */           for (Iterator iter = exceptions.iterator(); iter.hasNext(); ) {
/* 166 */             Exception item = (Exception)iter.next();
/* 167 */             sb.append(ExceptionUtils.getFullStackTrace(item) + "\n");
/*     */           }
/* 169 */           throw new Exception(sb.toString());
/*     */         }
/*     */ 
/* 172 */         if (log.isDebugEnabled())
/*     */         {
/* 174 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.rollback_succeed", new String[] { getThreadInfo().toString() }));
/*     */         }
/*     */ 
/*     */       }
/* 179 */       else if (log.isDebugEnabled())
/*     */       {
/* 181 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.transaction_relatinfo", new String[] { getThreadInfo().toString() }));
/*     */       }
/*     */ 
/* 185 */       TransactionMonitor.rollbackIncrease();
/*     */ 
/* 187 */       ListenerFactory.onRollbackTransaction();
/*     */     }
/*     */     finally {
/* 190 */       afterCompletion();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void commitTransaction()
/*     */     throws Exception
/*     */   {
/* 204 */     if (!isStartTransaction())
/*     */     {
/* 206 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.commit_after_begin"));
/*     */     }
/*     */ 
/* 209 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */     try {
/* 211 */       if (objThreadInfo.txConnections.size() != 0) {
/* 212 */         List exceptions = new ArrayList();
/* 213 */         HashMap map = objThreadInfo.txConnections;
/*     */ 
/* 215 */         int index = 0;
/* 216 */         Set sets = map.keySet();
/* 217 */         for (Iterator iter = sets.iterator(); iter.hasNext(); ) {
/* 218 */           String ds = (String)iter.next();
/* 219 */           Connection conn = (Connection)map.get(ds);
/*     */           try {
/* 221 */             conn.commit();
/*     */ 
/* 223 */             ++index;
/* 224 */             if (log.isDebugEnabled())
/*     */             {
/* 226 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.commit_succeed", new String[] { ds, conn.toString(), getThreadInfo().toString() }));
/*     */             }
/*     */ 
/* 229 */             jsr 31;
/*     */           } catch (Throwable ex) {
/* 231 */             exceptions.add(ex);
/*     */           }
/*     */           finally
/*     */           {
/* 236 */             jsr 6;
/*     */           }try { if (!conn.isClosed())
/* 238 */               conn.close(); }
/*     */           catch (Throwable ex)
/*     */           {
/* 242 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.close_error"), ex);
/* 243 */           }ret;
/*     */         }
/*     */ 
/* 247 */         if (exceptions.size() != 0)
/*     */         {
/* 249 */           Collection collection2 = map.values();
/* 250 */           for (Iterator iter = collection2.iterator(); iter.hasNext(); ) {
/* 251 */             Connection conn = (Connection)iter.next();
/*     */             try {
/* 253 */               conn.rollback();
/*     */             }
/*     */             catch (Throwable ex)
/*     */             {
/* 258 */               log.fatal(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.on_commit_rollback1"), ex);
/*     */             }
/*     */             finally {
/*     */               try {
/* 262 */                 if (!conn.isClosed())
/* 263 */                   conn.close();
/*     */               }
/*     */               catch (Throwable ex)
/*     */               {
/* 267 */                 log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.close_error"), ex);
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 272 */           StringBuilder sb = new StringBuilder();
/*     */ 
/* 274 */           sb.append(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.on_commit_rollback2", new String[] { "" + index }));
/*     */ 
/* 276 */           for (Iterator iter = exceptions.iterator(); iter.hasNext(); ) {
/* 277 */             Exception item = (Exception)iter.next();
/* 278 */             sb.append(ExceptionUtils.getFullStackTrace(item) + "\n");
/*     */           }
/* 280 */           throw new Exception(sb.toString());
/*     */         }
/*     */ 
/* 283 */         if (log.isDebugEnabled()) {
/* 284 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.commit_info", new String[] { getThreadInfo().toString() }));
/*     */         }
/*     */ 
/*     */       }
/* 290 */       else if (log.isDebugEnabled()) {
/* 291 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.commit_relatinfo", new String[] { getThreadInfo().toString() }));
/*     */       }
/*     */ 
/* 296 */       TransactionMonitor.commitIncrease();
/*     */ 
/* 298 */       ListenerFactory.onCommitTransaction();
/*     */     }
/*     */     finally {
/* 301 */       afterCompletion();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void suspend()
/*     */     throws Exception
/*     */   {
/* 310 */     if (!isStartTransaction())
/*     */     {
/* 312 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.suspend_after_begin"));
/*     */     }
/*     */ 
/* 315 */     ThreadInfo obj = getThreadInfo();
/* 316 */     addSuspend(obj);
/*     */ 
/* 318 */     setThreadInfo(null);
/* 319 */     IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 321 */     TransactionMonitor.suspendIncrease();
/*     */ 
/* 323 */     if (log.isDebugEnabled())
/* 324 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.suspend_succeed", new String[] { obj.toString() }));
/*     */   }
/*     */ 
/*     */   public void resume()
/*     */     throws Exception
/*     */   {
/* 334 */     if (isStartTransaction())
/*     */     {
/* 336 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.resume_precheck"));
/*     */     }
/*     */ 
/* 339 */     ThreadInfo obj = (ThreadInfo)getSuspend().pop();
/* 340 */     setThreadInfo(null);
/* 341 */     setThreadInfo(obj);
/*     */ 
/* 343 */     TransactionMonitor.resumeIncrease();
/*     */ 
/* 345 */     if (log.isDebugEnabled())
/* 346 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.resume_succeed", new String[] { obj.toString() }));
/*     */   }
/*     */ 
/*     */   public Connection getNewConnection()
/*     */     throws SQLException
/*     */   {
/* 357 */     if (IDataSource.CUR_DATASOURCE.get() == null)
/*     */     {
/* 359 */       throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.comfirm_set_ds"));
/*     */     }
/* 361 */     return getConnection(true, (String)IDataSource.CUR_DATASOURCE.get());
/*     */   }
/*     */ 
/*     */   public Connection getNewConnection(String ds)
/*     */     throws SQLException
/*     */   {
/* 371 */     return getConnection(true, ds);
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 387 */     String currentDataSource = null;
/* 388 */     if (IDataSource.CUR_DATASOURCE.get() == null) {
/* 389 */       currentDataSource = getThreadInfo().curDataSource;
/* 390 */       if (log.isInfoEnabled())
/*     */       {
/* 392 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_datasrc_info", new String[] { currentDataSource }));
/*     */       }
/*     */     }
/*     */     else {
/* 396 */       currentDataSource = (String)IDataSource.CUR_DATASOURCE.get();
/*     */     }
/*     */ 
/* 399 */     if (currentDataSource == null)
/*     */     {
/* 401 */       throw new SQLException(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.comfirm_set_ds"));
/*     */     }
/*     */ 
/* 404 */     return getConnection(false, currentDataSource);
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String ds)
/*     */     throws SQLException
/*     */   {
/* 415 */     return getConnection(false, ds);
/*     */   }
/*     */ 
/*     */   public Connection getConnection(boolean isNew, String ds)
/*     */     throws SQLException
/*     */   {
/* 426 */     Connection conn = null;
/*     */     try {
/* 428 */       conn = _getConnection(isNew, ds);
/*     */     }
/*     */     catch (Exception ex) {
/* 431 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_error"), ex);
/* 432 */       throw new SQLException(ex.getMessage());
/*     */     }
/* 434 */     return conn;
/*     */   }
/*     */ 
/*     */   public Connection _getConnection(boolean isNew, String ds)
/*     */     throws Exception
/*     */   {
/* 447 */     Connection rtn = null;
/* 448 */     boolean isReadOnly = false;
/*     */ 
/* 450 */     if (isNew) {
/* 451 */       rtn = DataSourceFactory.getDataSource().getConnectionFromDataSource(ds);
/*     */     }
/* 455 */     else if (isStartTransaction())
/*     */     {
/* 458 */       ThreadInfo obj = getThreadInfo();
/* 459 */       if (obj.txConnections.containsKey(ds))
/*     */       {
/* 462 */         rtn = new LogicConnection((Connection)obj.txConnections.get(ds));
/*     */ 
/* 465 */         int queryTimeoutSeconds = TxUtil.getQueryTimeOut();
/* 466 */         if (queryTimeoutSeconds > 0) {
/* 467 */           ((LogicConnection)rtn).setQueryTimeout(queryTimeoutSeconds);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 472 */         Connection objConnection = DataSourceFactory.getDataSource().getConnectionFromDataSource(ds);
/* 473 */         if (objConnection.isReadOnly()) {
/* 474 */           objConnection.rollback();
/*     */         }
/* 476 */         obj.txConnections.put(ds, objConnection);
/*     */ 
/* 478 */         rtn = new LogicConnection((Connection)obj.txConnections.get(ds));
/*     */ 
/* 481 */         int queryTimeoutSeconds = TxUtil.getQueryTimeOut();
/* 482 */         if (queryTimeoutSeconds > 0)
/* 483 */           ((LogicConnection)rtn).setQueryTimeout(queryTimeoutSeconds);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 488 */       rtn = new ReadOnlyConnection(DataSourceFactory.getDataSource().getConnectionFromDataSource(ds));
/*     */ 
/* 490 */       isReadOnly = true;
/*     */ 
/* 492 */       if (log.isDebugEnabled())
/*     */       {
/* 494 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_readonly", new String[] { ds }));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 499 */     if (log.isDebugEnabled()) {
/* 500 */       if (isReadOnly)
/*     */       {
/* 502 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_readonly_info", new String[] { rtn.toString(), ds }));
/*     */       }
/*     */       else
/*     */       {
/* 506 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_write_info", new String[] { rtn.toString(), ds }));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 512 */     if (TraceFactory.isEnableTrace()) {
/* 513 */       rtn = new TraceConnection(rtn);
/*     */     }
/* 516 */     else if (SQLMonitor.isEnable()) {
/* 517 */       rtn = new ProxyConnection(rtn, SQLMonitor.isOpenCountEnable());
/*     */     }
/*     */ 
/* 521 */     return rtn;
/*     */   }
/*     */ 
/*     */   private void afterCompletion()
/*     */   {
/* 529 */     if ((getSuspend() == null) || (getSuspend().size() == 0)) {
/* 530 */       setThreadInfo(null);
/* 531 */       IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 535 */       if ((CenterFactory.isSetCenterInfo()) && 
/* 536 */         (!JVMID.getLocalJVMID().equals(CenterFactory.getCenterInfo().getJVMID()))) {
/* 537 */         CenterFactory.setCenterInfoEmpty();
/*     */       }
/*     */ 
/* 541 */       ServiceManager.clearDoneCode();
/* 542 */       ServiceManager.clearOpDateTime();
/*     */     }
/*     */     else
/*     */     {
/* 546 */       setThreadInfo(null);
/* 547 */       IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 549 */       ServiceManager.clearDoneCode();
/* 550 */       ServiceManager.clearOpDateTime();
/*     */     }
/*     */ 
/* 553 */     ListenerFactory.onCompleteTransaction();
/*     */   }
/*     */ 
/*     */   private void addSuspend(ThreadInfo objThreadInfo)
/*     */   {
/* 561 */     if (suspend.get() == null) {
/* 562 */       Stack stack = new Stack();
/* 563 */       stack.add(objThreadInfo);
/* 564 */       suspend.set(stack);
/*     */     }
/*     */     else {
/* 567 */       Stack stack = (Stack)suspend.get();
/* 568 */       stack.add(objThreadInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Stack getSuspend()
/*     */   {
/* 577 */     return (Stack)suspend.get();
/*     */   }
/*     */ 
/*     */   private void setThreadInfo(ThreadInfo objThreadInfo)
/*     */   {
/* 585 */     tx.set(objThreadInfo);
/*     */   }
/*     */ 
/*     */   private ThreadInfo getThreadInfo()
/*     */   {
/* 593 */     return (ThreadInfo)tx.get();
/*     */   }
/*     */ 
/*     */   private static class ThreadInfo
/*     */   {
/* 606 */     private static Boolean SHOW_DETAIL = null;
/* 607 */     String txid = "";
/* 608 */     HashMap txConnections = new HashMap();
/* 609 */     Date start = null;
/* 610 */     String curDataSource = null;
/* 611 */     String callPath = null;
/* 612 */     String threadName = null;
/*     */ 
/*     */     ThreadInfo() {
/* 615 */       this.start = new Date();
/* 616 */       if (LocalMutilTransactionImpl.log.isDebugEnabled()) {
/* 617 */         this.txid = UUID.getID();
/* 618 */         if (SHOW_DETAIL == null) {
/*     */           try {
/* 620 */             Property[] prop = XMLHelper.getInstance().getDefaults().getTransaction().getClazz().getProperties();
/* 621 */             for (int i = 0; i < prop.length; ++i)
/* 622 */               if ((prop[i].getName().equalsIgnoreCase("showDetail")) && (prop[i].getValue().equalsIgnoreCase("true"))) {
/* 623 */                 SHOW_DETAIL = Boolean.TRUE;
/* 624 */                 this.callPath = MiscHelper.getCallPath();
/* 625 */                 this.threadName = Thread.currentThread().getName();
/*     */               }
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 630 */             LocalMutilTransactionImpl.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.record_detail_error"), ex);
/*     */           }
/*     */         } else {
/* 633 */           if (!SHOW_DETAIL.equals(Boolean.TRUE)) return;
/*     */           try {
/* 635 */             this.callPath = MiscHelper.getCallPath();
/* 636 */             this.threadName = Thread.currentThread().getName();
/*     */           }
/*     */           catch (Exception ex) {
/* 639 */             LocalMutilTransactionImpl.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.record_detail_error"), ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 650 */       String rtn = null;
/* 651 */       if ((SHOW_DETAIL != null) && (SHOW_DETAIL.equals(Boolean.TRUE)))
/*     */       {
/* 653 */         rtn = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.detail1", new String[] { this.txid, this.start.toString(), this.threadName, this.callPath });
/*     */       }
/*     */       else {
/* 656 */         rtn = AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.detail2", new String[] { this.txid, this.start.toString() });
/*     */       }
/* 658 */       return rtn;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.impl.LocalMutilTransactionImpl
 * JD-Core Version:    0.5.4
 */