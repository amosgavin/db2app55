/*    */ package com.ai.appframe2.complex.transaction.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.Session;
/*    */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*    */ import com.ai.appframe2.monitor.MonitorItem;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ 
/*    */ public abstract class AbstractTransactionImpl
/*    */   implements Session
/*    */ {
/*    */   public void startTransaction(String transactionName)
/*    */     throws Exception
/*    */   {
/* 31 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.undo_transaction_byname"));
/*    */   }
/*    */ 
/*    */   public MonitorItem[] getOpenTransaction()
/*    */   {
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   public void forceRollbackTransaction(String classHashCode)
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void suspendDataSource(String newDataSource)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void resumeDataSource()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getDefualtDataSourceOfCurrentTransaction()
/*    */   {
/* 69 */     return null;
/*    */   }
/*    */ 
/*    */   public String getDefualtDataSourceByTransactionName(String transactionName)
/*    */   {
/* 78 */     return null;
/*    */   }
/*    */ 
/*    */   public String getCurrentTransactionName()
/*    */   {
/* 86 */     return (String)IDataSource.CUR_DATASOURCE.get();
/*    */   }
/*    */ 
/*    */   public String debuger()
/*    */   {
/* 94 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.impl.AbstractTransactionImpl
 * JD-Core Version:    0.5.4
 */