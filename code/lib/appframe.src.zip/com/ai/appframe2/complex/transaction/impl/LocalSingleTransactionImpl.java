/*     */ package com.ai.appframe2.complex.transaction.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.complex.center.CenterInfo;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.LogicConnection;
/*     */ import com.ai.appframe2.complex.datasource.ProxyConnection;
/*     */ import com.ai.appframe2.complex.datasource.ReadOnlyConnection;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.mbean.standard.sql.SQLMonitor;
/*     */ import com.ai.appframe2.complex.mbean.standard.tm.TransactionMonitor;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionDatasource;
/*     */ import com.ai.appframe2.complex.transaction.interfaces.ITransactionInfo;
/*     */ import com.ai.appframe2.complex.util.JVMID;
/*     */ import com.ai.appframe2.complex.util.MiscHelper;
/*     */ import com.ai.appframe2.complex.util.UUID;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Clazz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Date;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocalSingleTransactionImpl extends AbstractTransactionImpl
/*     */   implements Session, ITransactionDatasource, ITransactionInfo
/*     */ {
/*  40 */   private static transient Log log = LogFactory.getLog(LocalSingleTransactionImpl.class);
/*     */ 
/*  42 */   private static ThreadLocal suspend = new ThreadLocal();
/*     */ 
/*  44 */   private static ThreadLocal tx = new ThreadLocal();
/*     */ 
/*     */   public boolean isSetTxDataSource()
/*     */   {
/*  55 */     boolean rtn = false;
/*  56 */     if (!StringUtils.isBlank(getThreadInfo().txDataSource)) {
/*  57 */       rtn = true;
/*     */     }
/*  59 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void setTxDataSource(String txDataSourceName)
/*     */   {
/*  67 */     getThreadInfo().txDataSource = txDataSourceName;
/*     */   }
/*     */ 
/*     */   public boolean isStartTransaction()
/*     */   {
/*  75 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */ 
/*  77 */     return objThreadInfo != null;
/*     */   }
/*     */ 
/*     */   public String getTxDataSource()
/*     */   {
/*  89 */     return getThreadInfo().txDataSource;
/*     */   }
/*     */ 
/*     */   public String getCurrentTxInfo()
/*     */   {
/*  97 */     String rtn = null;
/*  98 */     ThreadInfo objThreadInfo = getThreadInfo();
/*  99 */     if (objThreadInfo != null) {
/* 100 */       rtn = objThreadInfo.toString();
/*     */     }
/* 102 */     return rtn;
/*     */   }
/*     */ 
/*     */   public void startTransaction()
/*     */     throws Exception
/*     */   {
/* 110 */     if (isStartTransaction())
/*     */     {
/* 113 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.exist_transaction", new String[] { getThreadInfo().toString() }));
/*     */     }
/* 115 */     setThreadInfo(new ThreadInfo());
/*     */ 
/* 117 */     TransactionMonitor.startIncrease();
/*     */ 
/* 119 */     if (log.isDebugEnabled())
/* 120 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.startTransaction_succeed", new String[] { getThreadInfo().toString() }));
/*     */   }
/*     */ 
/*     */   public void rollbackTransaction()
/*     */     throws Exception
/*     */   {
/* 129 */     if (!isStartTransaction())
/*     */     {
/* 132 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.roll_after_begin"));
/*     */     }
/*     */ 
/* 135 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */     try {
/* 137 */       if (objThreadInfo.txConnection != null) {
/*     */         try {
/* 139 */           objThreadInfo.txConnection.rollback();
/*     */ 
/* 141 */           if (log.isDebugEnabled())
/*     */           {
/* 143 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.rollback_succeed_infos", new String[] { objThreadInfo.txConnection.toString(), getThreadInfo().toString() }));
/*     */           }
/*     */         }
/*     */         catch (SQLException ex) {
/* 147 */           throw ex;
/*     */         }
/*     */         finally {
/* 150 */           if (!objThreadInfo.txConnection.isClosed()) {
/* 151 */             objThreadInfo.txConnection.close();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 156 */       else if (log.isDebugEnabled())
/*     */       {
/* 158 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.transaction_relatinfo", new String[] { getThreadInfo().toString() }));
/*     */       }
/*     */ 
/* 162 */       TransactionMonitor.rollbackIncrease();
/*     */     }
/*     */     finally {
/* 165 */       afterCompletion();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void commitTransaction()
/*     */     throws Exception
/*     */   {
/* 174 */     if (!isStartTransaction())
/*     */     {
/* 177 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.commit_after_begin"));
/*     */     }
/*     */ 
/* 180 */     ThreadInfo objThreadInfo = getThreadInfo();
/*     */     try {
/* 182 */       if (objThreadInfo.txConnection != null) {
/*     */         try {
/* 184 */           objThreadInfo.txConnection.commit();
/*     */ 
/* 186 */           if (log.isDebugEnabled())
/*     */           {
/* 188 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.commit_infos", new String[] { objThreadInfo.txConnection.toString(), getThreadInfo().toString() }));
/*     */           }
/*     */         }
/*     */         catch (SQLException ex) {
/* 192 */           throw ex;
/*     */         }
/*     */         finally {
/* 195 */           if (!objThreadInfo.txConnection.isClosed()) {
/* 196 */             objThreadInfo.txConnection.close();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 201 */       else if (log.isDebugEnabled())
/*     */       {
/* 203 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.commit_relatinfo", new String[] { getThreadInfo().toString() }));
/*     */       }
/*     */ 
/* 207 */       TransactionMonitor.commitIncrease();
/*     */     }
/*     */     finally {
/* 210 */       afterCompletion();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void suspend()
/*     */     throws Exception
/*     */   {
/* 219 */     if (!isStartTransaction())
/*     */     {
/* 222 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.suspend_after_begin"));
/*     */     }
/*     */ 
/* 225 */     ThreadInfo obj = getThreadInfo();
/* 226 */     addSuspend(obj);
/*     */ 
/* 229 */     setThreadInfo(null);
/* 230 */     IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 232 */     TransactionMonitor.suspendIncrease();
/*     */ 
/* 234 */     if (log.isDebugEnabled())
/* 235 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.suspend_succeed", new String[] { obj.toString() }));
/*     */   }
/*     */ 
/*     */   public void resume()
/*     */     throws Exception
/*     */   {
/* 245 */     if (isStartTransaction())
/*     */     {
/* 248 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.resume_precheck"));
/*     */     }
/*     */ 
/* 251 */     ThreadInfo obj = (ThreadInfo)getSuspend().pop();
/* 252 */     setThreadInfo(null);
/* 253 */     setThreadInfo(obj);
/*     */ 
/* 255 */     TransactionMonitor.resumeIncrease();
/*     */ 
/* 257 */     if (log.isDebugEnabled())
/* 258 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.resume_succeed", new String[] { obj.toString() }));
/*     */   }
/*     */ 
/*     */   public Connection getNewConnection()
/*     */     throws SQLException
/*     */   {
/* 277 */     String currentDataSource = null;
/* 278 */     if (IDataSource.CUR_DATASOURCE.get() == null) {
/* 279 */       currentDataSource = getThreadInfo().txDataSource;
/* 280 */       if (log.isInfoEnabled())
/*     */       {
/* 282 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_datasrc_info", new String[] { currentDataSource }));
/*     */       }
/*     */     }
/*     */     else {
/* 286 */       currentDataSource = (String)IDataSource.CUR_DATASOURCE.get();
/*     */     }
/* 288 */     return getConnection(true, currentDataSource);
/*     */   }
/*     */ 
/*     */   public Connection getNewConnection(String ds)
/*     */     throws SQLException
/*     */   {
/* 298 */     return getConnection(true, ds);
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 314 */     String currentDataSource = null;
/* 315 */     if (IDataSource.CUR_DATASOURCE.get() == null) {
/* 316 */       currentDataSource = getThreadInfo().txDataSource;
/* 317 */       if (log.isInfoEnabled())
/*     */       {
/* 319 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_datasrc_info", new String[] { currentDataSource }));
/*     */       }
/*     */     }
/*     */     else {
/* 323 */       currentDataSource = (String)IDataSource.CUR_DATASOURCE.get();
/*     */     }
/* 325 */     return getConnection(false, currentDataSource);
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String ds)
/*     */     throws SQLException
/*     */   {
/* 335 */     return getConnection(false, ds);
/*     */   }
/*     */ 
/*     */   public Connection getConnection(boolean isNew, String ds)
/*     */     throws SQLException
/*     */   {
/* 346 */     Connection conn = null;
/*     */     try {
/* 348 */       conn = _getConnection(isNew, ds);
/*     */     }
/*     */     catch (Exception ex) {
/* 351 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_error"), ex);
/* 352 */       throw new SQLException(ex.getMessage());
/*     */     }
/* 354 */     return conn;
/*     */   }
/*     */ 
/*     */   public Connection _getConnection(boolean isNew, String ds)
/*     */     throws Exception
/*     */   {
/* 367 */     Connection rtn = null;
/* 368 */     boolean isReadOnly = false;
/*     */ 
/* 370 */     if (isNew) {
/* 371 */       rtn = DataSourceFactory.getDataSource().getConnectionFromDataSource(ds);
/*     */     }
/* 375 */     else if (isStartTransaction()) {
/* 376 */       if (getThreadInfo().txDataSource == null)
/*     */       {
/* 379 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.no_transaction_ds"));
/*     */       }
/* 381 */       if (getThreadInfo().txDataSource.equals(ds))
/*     */       {
/* 384 */         ThreadInfo obj = getThreadInfo();
/* 385 */         if (obj.txConnection != null)
/*     */         {
/* 388 */           rtn = new LogicConnection(obj.txConnection);
/*     */         }
/*     */         else
/*     */         {
/* 392 */           Connection objConnection = DataSourceFactory.getDataSource().getConnectionFromDataSource(ds);
/* 393 */           obj.txConnection = objConnection;
/*     */ 
/* 395 */           rtn = new LogicConnection(obj.txConnection);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 400 */         rtn = new ReadOnlyConnection(DataSourceFactory.getDataSource().getConnectionFromDataSource(ds));
/* 401 */         isReadOnly = true;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 406 */       rtn = new ReadOnlyConnection(DataSourceFactory.getDataSource().getConnectionFromDataSource(ds));
/* 407 */       isReadOnly = true;
/*     */ 
/* 409 */       if (log.isDebugEnabled())
/*     */       {
/* 411 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_readonly", new String[] { ds }));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 416 */     if (log.isDebugEnabled()) {
/* 417 */       if ((getThreadInfo() != null) && (getThreadInfo().txDataSource != null)) {
/* 418 */         if (isReadOnly)
/*     */         {
/* 420 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_readonly_info", new String[] { rtn.toString(), ds }));
/*     */         }
/*     */         else
/*     */         {
/* 424 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_write_info", new String[] { rtn.toString(), ds }));
/*     */         }
/*     */ 
/*     */       }
/* 428 */       else if (isReadOnly)
/*     */       {
/* 430 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_readonly_info", new String[] { rtn.toString(), ds }));
/*     */       }
/*     */       else
/*     */       {
/* 434 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.getConnection_write_info", new String[] { rtn.toString(), ds }));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 439 */     if (SQLMonitor.isEnable()) {
/* 440 */       rtn = new ProxyConnection(rtn, SQLMonitor.isOpenCountEnable());
/*     */     }
/*     */ 
/* 443 */     return rtn;
/*     */   }
/*     */ 
/*     */   private void afterCompletion()
/*     */   {
/* 451 */     if ((getSuspend() == null) || (getSuspend().size() == 0)) {
/* 452 */       setThreadInfo(null);
/* 453 */       IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 457 */       if ((CenterFactory.isSetCenterInfo()) && 
/* 458 */         (!JVMID.getLocalJVMID().equals(CenterFactory.getCenterInfo().getJVMID()))) {
/* 459 */         CenterFactory.setCenterInfoEmpty();
/*     */       }
/*     */ 
/* 463 */       ServiceManager.clearDoneCode();
/* 464 */       ServiceManager.clearOpDateTime();
/*     */     }
/*     */     else
/*     */     {
/* 468 */       setThreadInfo(null);
/* 469 */       IDataSource.CUR_DATASOURCE.set(null);
/*     */ 
/* 471 */       ServiceManager.clearDoneCode();
/* 472 */       ServiceManager.clearOpDateTime();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void addSuspend(ThreadInfo objThreadInfo)
/*     */   {
/* 481 */     if (suspend.get() == null) {
/* 482 */       Stack stack = new Stack();
/* 483 */       stack.add(objThreadInfo);
/* 484 */       suspend.set(stack);
/*     */     }
/*     */     else {
/* 487 */       Stack stack = (Stack)suspend.get();
/* 488 */       stack.add(objThreadInfo);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Stack getSuspend()
/*     */   {
/* 497 */     return (Stack)suspend.get();
/*     */   }
/*     */ 
/*     */   private void setThreadInfo(ThreadInfo objThreadInfo)
/*     */   {
/* 505 */     tx.set(objThreadInfo);
/*     */   }
/*     */ 
/*     */   private ThreadInfo getThreadInfo()
/*     */   {
/* 513 */     return (ThreadInfo)tx.get();
/*     */   }
/*     */ 
/*     */   private static class ThreadInfo
/*     */   {
/* 526 */     private static Boolean SHOW_DETAIL = null;
/* 527 */     String txid = null;
/* 528 */     String txDataSource = null;
/* 529 */     Connection txConnection = null;
/* 530 */     Date start = null;
/* 531 */     String callPath = null;
/* 532 */     String threadName = null;
/*     */ 
/*     */     ThreadInfo() {
/* 535 */       this.txid = UUID.getID();
/* 536 */       this.start = new Date();
/* 537 */       if (LocalSingleTransactionImpl.log.isDebugEnabled())
/* 538 */         if (SHOW_DETAIL == null) {
/*     */           try {
/* 540 */             Property[] prop = XMLHelper.getInstance().getDefaults().getTransaction().getClazz().getProperties();
/* 541 */             for (int i = 0; i < prop.length; ++i) {
/* 542 */               if ((prop[i].getName().equalsIgnoreCase("showDetail")) && (prop[i].getValue().equalsIgnoreCase("true"))) {
/* 543 */                 SHOW_DETAIL = Boolean.TRUE;
/* 544 */                 this.callPath = MiscHelper.getCallPath();
/* 545 */                 this.threadName = Thread.currentThread().getName();
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 551 */             LocalSingleTransactionImpl.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.record_detail_error"), ex);
/*     */           }
/*     */         } else {
/* 554 */           if (!SHOW_DETAIL.equals(Boolean.TRUE)) return;
/*     */           try {
/* 556 */             this.callPath = MiscHelper.getCallPath();
/* 557 */             this.threadName = Thread.currentThread().getName();
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 561 */             LocalSingleTransactionImpl.log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.impl.TransactionImpl.ThreadInfo.record_detail_error"), ex);
/*     */           }
/*     */         }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 573 */       String rtn = null;
/* 574 */       if ((SHOW_DETAIL != null) && (SHOW_DETAIL.equals(Boolean.TRUE))) {
/* 575 */         rtn = "[Transaction ID:" + this.txid + ",Start time:" + this.start.toString() + ",Thread:" + this.threadName + ",CallPath:]" + this.callPath;
/*     */       }
/*     */       else {
/* 578 */         rtn = "[Transaction ID:" + this.txid + ",Start time:" + this.start.toString() + "]";
/*     */       }
/* 580 */       return rtn;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.impl.LocalSingleTransactionImpl
 * JD-Core Version:    0.5.4
 */