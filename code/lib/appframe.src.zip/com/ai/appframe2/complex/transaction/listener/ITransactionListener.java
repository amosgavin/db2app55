package com.ai.appframe2.complex.transaction.listener;

public abstract interface ITransactionListener
{
  public abstract void onStartTransaction();

  public abstract void onRollbackTransaction();

  public abstract void onCommitTransaction();

  public abstract void onCompleteTransaction();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.listener.ITransactionListener
 * JD-Core Version:    0.5.4
 */