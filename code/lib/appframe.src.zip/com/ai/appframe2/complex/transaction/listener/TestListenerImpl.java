/*    */ package com.ai.appframe2.complex.transaction.listener;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class TestListenerImpl
/*    */   implements ITransactionListener
/*    */ {
/*    */   public void onStartTransaction()
/*    */   {
/*  8 */     System.out.println("onStartTransaction");
/*    */   }
/*    */ 
/*    */   public void onRollbackTransaction() {
/* 12 */     System.out.println("onRollbackTransaction");
/*    */   }
/*    */ 
/*    */   public void onCommitTransaction() {
/* 16 */     System.out.println("onCommitTransaction");
/*    */   }
/*    */ 
/*    */   public void onCompleteTransaction() {
/* 20 */     System.out.println("onCompleteTransaction");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.listener.TestListenerImpl
 * JD-Core Version:    0.5.4
 */