package com.ai.appframe2.complex.transaction.interfaces;

public abstract interface ITransactionInfo
{
  public abstract String getCurrentTxInfo();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.interfaces.ITransactionInfo
 * JD-Core Version:    0.5.4
 */