/*    */ package com.ai.appframe2.complex.transaction;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ 
/*    */ public final class ReadOnly
/*    */ {
/* 22 */   private static int DRIVER_VERSION = 0;
/*    */ 
/*    */   /** @deprecated */
/*    */   private static void setReadOnly(Connection conn, boolean flag)
/*    */     throws Exception
/*    */   {
/* 41 */     if (DRIVER_VERSION == 0) {
/* 42 */       DRIVER_VERSION = Integer.parseInt(org.apache.commons.lang.StringUtils.split(conn.getMetaData().getDriverVersion(), ".")[0]);
/*    */     }
/*    */ 
/* 45 */     if (DRIVER_VERSION <= 9)
/*    */     {
/* 47 */       conn.setReadOnly(flag);
/*    */     }
/*    */     else
/*    */     {
/* 51 */       PreparedStatement ptmt = null;
/*    */       try {
/* 53 */         if (flag) {
/* 54 */           ptmt = conn.prepareStatement("SET TRANSACTION READ ONLY");
/*    */         }
/*    */         else {
/* 57 */           ptmt = conn.prepareStatement("SET TRANSACTION READ WRITE");
/*    */         }
/* 59 */         ptmt.execute();
/*    */       }
/*    */       catch (Exception ex) {
/* 62 */         throw ex;
/*    */       }
/*    */       finally {
/* 65 */         if (ptmt != null) {
/* 66 */           ptmt.close();
/*    */         }
/*    */       }
/*    */ 
/* 70 */       conn.setReadOnly(flag);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.ReadOnly
 * JD-Core Version:    0.5.4
 */