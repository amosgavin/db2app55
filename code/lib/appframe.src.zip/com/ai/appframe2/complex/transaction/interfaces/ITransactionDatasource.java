package com.ai.appframe2.complex.transaction.interfaces;

public abstract interface ITransactionDatasource
{
  public abstract boolean isSetTxDataSource();

  public abstract void setTxDataSource(String paramString);

  public abstract String getTxDataSource();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.interfaces.ITransactionDatasource
 * JD-Core Version:    0.5.4
 */