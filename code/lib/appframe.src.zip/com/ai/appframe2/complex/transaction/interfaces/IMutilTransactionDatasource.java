package com.ai.appframe2.complex.transaction.interfaces;

public abstract interface IMutilTransactionDatasource
{
  public abstract void setCurDataSource(String paramString);

  public abstract String getCurDataSource();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.interfaces.IMutilTransactionDatasource
 * JD-Core Version:    0.5.4
 */