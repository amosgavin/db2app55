/*     */ package com.ai.appframe2.complex.transaction.listener;
/*     */ 
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Defaults;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Listener;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Transaction;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public final class ListenerFactory
/*     */ {
/*  26 */   private static transient Log log = LogFactory.getLog(ListenerFactory.class);
/*     */ 
/*  28 */   private static boolean IS_LISTENERS = false;
/*  29 */   private static ITransactionListener[] LISTENER = null;
/*     */ 
/*     */   public static void onStartTransaction()
/*     */   {
/*  59 */     if (IS_LISTENERS)
/*  60 */       for (int i = 0; i < LISTENER.length; ++i)
/*     */         try {
/*  62 */           LISTENER[i].onStartTransaction();
/*     */         }
/*     */         catch (Throwable ex) {
/*  65 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.listener.ListenerFactory.onStartTransaction_error", new String[] { LISTENER[i].toString() }), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public static void onRollbackTransaction()
/*     */   {
/*  75 */     if (IS_LISTENERS)
/*  76 */       for (int i = 0; i < LISTENER.length; ++i)
/*     */         try {
/*  78 */           LISTENER[i].onRollbackTransaction();
/*     */         }
/*     */         catch (Throwable ex) {
/*  81 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.listener.ListenerFactory.onRollbackTransaction_error", new String[] { LISTENER[i].toString() }), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public static void onCommitTransaction()
/*     */   {
/*  91 */     if (IS_LISTENERS)
/*  92 */       for (int i = 0; i < LISTENER.length; ++i)
/*     */         try {
/*  94 */           LISTENER[i].onCommitTransaction();
/*     */         }
/*     */         catch (Throwable ex) {
/*  97 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.listener.ListenerFactory.onCommitTransaction_error", new String[] { LISTENER[i].toString() }), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   public static void onCompleteTransaction()
/*     */   {
/* 107 */     if (IS_LISTENERS)
/* 108 */       for (int i = 0; i < LISTENER.length; ++i)
/*     */         try {
/* 110 */           LISTENER[i].onCompleteTransaction();
/*     */         }
/*     */         catch (Throwable ex) {
/* 113 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.listener.ListenerFactory.onCompleteTransaction_error", new String[] { LISTENER[i].toString() }), ex);
/*     */         }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  33 */       Listener[] listener = XMLHelper.getInstance().getDefaults().getTransaction().getListeners();
/*  34 */       if ((listener != null) && (listener.length > 0)) {
/*  35 */         List list = new ArrayList();
/*  36 */         for (int i = 0; i < listener.length; ++i) {
/*  37 */           ITransactionListener objITransactionListener = (ITransactionListener)Class.forName(listener[i].getName()).newInstance();
/*  38 */           list.add(objITransactionListener);
/*     */         }
/*     */ 
/*  41 */         LISTENER = (ITransactionListener[])(ITransactionListener[])list.toArray(new ITransactionListener[0]);
/*  42 */         if ((LISTENER != null) && (LISTENER.length > 0))
/*  43 */           IS_LISTENERS = true;
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  48 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.transaction.listener.ListenerFactory.error"), ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.transaction.listener.ListenerFactory
 * JD-Core Version:    0.5.4
 */