/*     */ package com.ai.appframe2.complex.mbean.standard.sv;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class SVMethodSummary
/*     */   implements Serializable
/*     */ {
/*     */   private String className;
/*     */   private String methodName;
/*     */   private long min;
/*     */   private long max;
/*     */   private long avg;
/*     */   private long last;
/*     */   private long totalCount;
/*     */   private long successCount;
/*     */   private long failCount;
/*     */   private long totalUseTime;
/*     */   private long lastUseTime;
/*     */   private long minCpuTime;
/*     */   private long maxCpuTime;
/*     */   private long totalCpuTime;
/*     */   private long avgCpuTime;
/*     */   private long lastCpuTime;
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  37 */     return this.className;
/*     */   }
/*     */ 
/*     */   public void setClassName(String className) {
/*  41 */     this.className = className;
/*     */   }
/*     */ 
/*     */   public String getMethodName() {
/*  45 */     return this.methodName;
/*     */   }
/*     */ 
/*     */   public void setMethodName(String methodName) {
/*  49 */     this.methodName = methodName;
/*     */   }
/*     */ 
/*     */   public long getMin() {
/*  53 */     return this.min;
/*     */   }
/*     */ 
/*     */   public void setMin(long min) {
/*  57 */     this.min = min;
/*     */   }
/*     */ 
/*     */   public long getMax() {
/*  61 */     return this.max;
/*     */   }
/*     */ 
/*     */   public void setMax(long max) {
/*  65 */     this.max = max;
/*     */   }
/*     */ 
/*     */   public long getAvg() {
/*  69 */     return this.avg;
/*     */   }
/*     */ 
/*     */   public void setAvg(long avg) {
/*  73 */     this.avg = avg;
/*     */   }
/*     */ 
/*     */   public long getLast() {
/*  77 */     return this.last;
/*     */   }
/*     */ 
/*     */   public void setLast(long last) {
/*  81 */     this.last = last;
/*     */   }
/*     */ 
/*     */   public long getTotalCount() {
/*  85 */     return this.totalCount;
/*     */   }
/*     */ 
/*     */   public void setTotalCount(long totalCount) {
/*  89 */     this.totalCount = totalCount;
/*     */   }
/*     */ 
/*     */   public long getSuccessCount() {
/*  93 */     return this.successCount;
/*     */   }
/*     */ 
/*     */   public void setSuccessCount(long successCount) {
/*  97 */     this.successCount = successCount;
/*     */   }
/*     */ 
/*     */   public long getFailCount() {
/* 101 */     return this.failCount;
/*     */   }
/*     */ 
/*     */   public void setFailCount(long failCount) {
/* 105 */     this.failCount = failCount;
/*     */   }
/*     */   public long getTotalUseTime() {
/* 108 */     return this.totalUseTime;
/*     */   }
/*     */   public void setTotalUseTime(long totalUseTime) {
/* 111 */     this.totalUseTime = totalUseTime;
/*     */   }
/*     */   public long getLastUseTime() {
/* 114 */     return this.lastUseTime;
/*     */   }
/*     */ 
/*     */   public long getAvgCpuTime() {
/* 118 */     return this.avgCpuTime;
/*     */   }
/*     */ 
/*     */   public long getLastCpuTime() {
/* 122 */     return this.lastCpuTime;
/*     */   }
/*     */ 
/*     */   public long getTotalCpuTime() {
/* 126 */     return this.totalCpuTime;
/*     */   }
/*     */ 
/*     */   public long getMaxCpuTime() {
/* 130 */     return this.maxCpuTime;
/*     */   }
/*     */ 
/*     */   public long getMinCpuTime() {
/* 134 */     return this.minCpuTime;
/*     */   }
/*     */ 
/*     */   public void setLastUseTime(long lastUseTime) {
/* 138 */     this.lastUseTime = lastUseTime;
/*     */   }
/*     */ 
/*     */   public void setAvgCpuTime(long avgCpuTime) {
/* 142 */     this.avgCpuTime = avgCpuTime;
/*     */   }
/*     */ 
/*     */   public void setLastCpuTime(long lastCpuTime) {
/* 146 */     this.lastCpuTime = lastCpuTime;
/*     */   }
/*     */ 
/*     */   public void setTotalCpuTime(long totalCpuTime) {
/* 150 */     this.totalCpuTime = totalCpuTime;
/*     */   }
/*     */ 
/*     */   public void setMinCpuTime(long minCpuTime) {
/* 154 */     this.minCpuTime = minCpuTime;
/*     */   }
/*     */ 
/*     */   public void setMaxCpuTime(long maxCpuTime) {
/* 158 */     this.maxCpuTime = maxCpuTime;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sv.SVMethodSummary
 * JD-Core Version:    0.5.4
 */