/*     */ package com.ai.appframe2.complex.mbean.registry;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.JMXConfigure;
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBean;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBeans;
/*     */ import com.ai.appframe2.complex.mbean.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.util.e.K;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.remote.JMXAuthenticator;
/*     */ import javax.management.remote.JMXConnectorServer;
/*     */ import javax.management.remote.JMXConnectorServerFactory;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import mx4j.tools.remote.PasswordAuthenticator;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocalMBeanRegistryImpl extends AbstractMBeanRegistryImpl
/*     */   implements IMBeanRegistry
/*     */ {
/*  39 */   private static transient Log log = LogFactory.getLog(LocalMBeanRegistryImpl.class);
/*     */ 
/*  41 */   private MBeanServer server = null;
/*  42 */   private JMXConnectorServer connectorServer = null;
/*     */ 
/*     */   public void registry()
/*     */     throws Exception
/*     */   {
/*  56 */     if ((this.connectorServer != null) && (this.server != null)) {
/*  57 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.succeed"));
/*  58 */       return;
/*     */     }
/*     */ 
/*  62 */     String portStr = null;
/*  63 */     if (!StringUtils.isBlank(System.getProperty("jmx.registry.local.agent.port"))) {
/*  64 */       portStr = System.getProperty("jmx.registry.local.agent.port").trim();
/*     */     }
/*  66 */     if ((StringUtils.isBlank(portStr)) && (!StringUtils.isBlank(System.getProperty("app.name")))) {
/*  67 */       portStr = JMXConfigure.getProperties().getProperty(System.getProperty("app.name").trim());
/*     */     }
/*  69 */     if ((StringUtils.isBlank(portStr)) && (!StringUtils.isBlank(JMXConfigure.getProperties().getProperty("jmx.registry.local.agent.port")))) {
/*  70 */       portStr = JMXConfigure.getProperties().getProperty("jmx.registry.local.agent.port");
/*     */     }
/*     */ 
/*  73 */     if (StringUtils.isBlank(portStr)) {
/*  74 */       log.error("====================================");
/*  75 */       log.error("========" + AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.getport_error") + "========");
/*  76 */       log.error("====================================");
/*  77 */       return;
/*     */     }
/*     */ 
/*  80 */     int port = Integer.parseInt(portStr);
/*  81 */     String username = JMXConfigure.getProperties().getProperty("jmx.registry.local.agent.username");
/*  82 */     String password = JMXConfigure.getProperties().getProperty("jmx.registry.local.agent.password");
/*     */ 
/*  84 */     MBean[] objMBean = null;
/*     */     try {
/*  86 */       objMBean = XMLHelper.getInstance(JMXConfigure.getProperties().getProperty("jmx.registry.local.file")).getMBeans().getMBeans();
/*     */     }
/*     */     catch (Exception ex) {
/*  89 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.getmbean_error"), ex);
/*  90 */       return;
/*     */     }
/*     */ 
/*  94 */     if (isGreaterJava14())
/*     */     {
/*  96 */       Class ManagementFactory = Class.forName("java.lang.management.ManagementFactory");
/*  97 */       Method getPlatformMBeanServer = ManagementFactory.getMethod("getPlatformMBeanServer", new Class[0]);
/*  98 */       this.server = ((MBeanServer)getPlatformMBeanServer.invoke(null, new Object[0]));
/*  99 */       LocateRegistry.createRegistry(port);
/*     */     }
/*     */     else
/*     */     {
/* 103 */       this.server = MBeanServerFactory.createMBeanServer();
/*     */ 
/* 105 */       ObjectName namingName = ObjectName.getInstance("naming:type=rmiregistry");
/* 106 */       this.server.createMBean("mx4j.tools.naming.NamingService", namingName, null);
/* 107 */       this.server.setAttribute(namingName, new Attribute("Port", new Integer(port)));
/* 108 */       this.server.invoke(namingName, "start", null, null);
/*     */     }
/*     */ 
/* 113 */     String urlStr = "service:jmx:rmi://localhost/jndi/rmi://" + InetAddress.getLocalHost().getHostAddress() + ":" + port + "/jmxconnector";
/* 114 */     JMXServiceURL url = new JMXServiceURL(urlStr);
/* 115 */     if (log.isInfoEnabled()) {
/* 116 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.url", new String[] { urlStr }));
/*     */     }
/*     */ 
/* 121 */     if ((objMBean != null) && (objMBean.length != 0)) {
/* 122 */       for (int i = 0; i < objMBean.length; ++i) {
/*     */         try {
/* 124 */           ObjectName name = new ObjectName(objMBean[i].getName().trim());
/* 125 */           Object object = Class.forName(objMBean[i].getClassname()).newInstance();
/*     */ 
/* 127 */           if ((object != null) && (object instanceof IControl) && (!StringUtils.isBlank(objMBean[i].getEnable())) && (objMBean[i].getEnable().equalsIgnoreCase("true")) && (!StringUtils.isBlank(objMBean[i].getTimeout())))
/*     */           {
/* 132 */             ((IControl)object).enable(Long.parseLong(objMBean[i].getTimeout()));
/* 133 */             if (log.isInfoEnabled()) {
/* 134 */               log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.mbean_enable", new String[] { objMBean[i].getName() }));
/*     */             }
/*     */           }
/*     */ 
/* 138 */           this.server.registerMBean(object, name);
/*     */ 
/* 140 */           if (log.isInfoEnabled()) {
/* 141 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.succeed_info", new String[] { objMBean[i].getName() }));
/*     */           }
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 146 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.failed_info", new String[] { objMBean[i].getName() }), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 154 */     HashMap environment = new HashMap();
/* 155 */     if ((!StringUtils.isBlank(username)) && (!StringUtils.isBlank(password))) {
/* 156 */       String tmpUsername = K.k_s(username.trim());
/* 157 */       String tmpPassword = K.k_s(password.trim());
/* 158 */       ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream((tmpUsername + "=" + tmpPassword).getBytes());
/* 159 */       JMXAuthenticator authenticator = new PasswordAuthenticator(objByteArrayInputStream);
/* 160 */       environment.put("jmx.remote.authenticator", authenticator);
/* 161 */       if (log.isInfoEnabled()) {
/* 162 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.jmx_security_enable"));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 167 */     this.connectorServer = JMXConnectorServerFactory.newJMXConnectorServer(url, environment, this.server);
/* 168 */     this.connectorServer.start();
/*     */ 
/* 170 */     if (log.isInfoEnabled())
/* 171 */       log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.jmx_security_enabled"));
/*     */   }
/*     */ 
/*     */   public void unregistry()
/*     */     throws Exception
/*     */   {
/* 181 */     if (this.connectorServer != null) {
/* 182 */       this.connectorServer.stop();
/*     */     }
/* 184 */     if (this.server != null)
/* 185 */       MBeanServerFactory.releaseMBeanServer(this.server);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.LocalMBeanRegistryImpl
 * JD-Core Version:    0.5.4
 */