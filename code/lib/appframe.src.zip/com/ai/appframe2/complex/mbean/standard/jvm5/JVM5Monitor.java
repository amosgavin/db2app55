/*    */ package com.ai.appframe2.complex.mbean.standard.jvm5;
/*    */ 
/*    */ import java.lang.management.ManagementFactory;
/*    */ import java.lang.management.MemoryMXBean;
/*    */ import java.lang.management.MemoryUsage;
/*    */ import java.lang.management.ThreadInfo;
/*    */ import java.lang.management.ThreadMXBean;
/*    */ 
/*    */ public class JVM5Monitor
/*    */   implements JVM5MonitorMBean
/*    */ {
/*    */   public String getAllThreadInfo()
/*    */     throws Exception
/*    */   {
/* 31 */     long[] threadIds = ManagementFactory.getThreadMXBean().getAllThreadIds();
/* 32 */     ThreadInfo[] objThreadInfo = ManagementFactory.getThreadMXBean().getThreadInfo(threadIds, 2147483647);
/* 33 */     StringBuilder sb = new StringBuilder();
/* 34 */     for (int i = 0; i < objThreadInfo.length; ++i) {
/* 35 */       sb.append("<data>");
/* 36 */       sb.append("<rownum>" + (i + 1) + "</rownum>");
/* 37 */       sb.append("<id>" + objThreadInfo[i].getThreadId() + "</id>");
/* 38 */       sb.append("<state>" + objThreadInfo[i].getThreadState().name() + "</state>");
/* 39 */       sb.append("<name>" + objThreadInfo[i].getThreadName() + "</name>");
/* 40 */       StackTraceElement[] stack = objThreadInfo[i].getStackTrace();
/* 41 */       StringBuffer tmp = new StringBuffer();
/* 42 */       for (int j = 0; j < stack.length; ++j) {
/* 43 */         tmp.append(stack[j].getClassName() + "." + stack[j].getMethodName() + "(" + stack[j].getFileName() + ":" + stack[j].getLineNumber() + ")\n");
/*    */       }
/* 45 */       sb.append("<stack>" + tmp + "</stack>");
/* 46 */       sb.append("</data>");
/*    */     }
/*    */ 
/* 49 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public String getMemoryInfo()
/*    */     throws Exception
/*    */   {
/* 58 */     MemoryUsage objMemoryUsage = ManagementFactory.getMemoryMXBean().getHeapMemoryUsage();
/* 59 */     long total = objMemoryUsage.getMax();
/* 60 */     long used = objMemoryUsage.getUsed();
/* 61 */     StringBuffer sb = new StringBuffer();
/* 62 */     sb.append("<data>");
/* 63 */     sb.append("<t>" + total + "</t>");
/* 64 */     sb.append("<u>" + used + "</u>");
/* 65 */     sb.append("</data>");
/* 66 */     return sb.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.jvm5.JVM5Monitor
 * JD-Core Version:    0.5.4
 */