package com.ai.appframe2.complex.mbean.standard.sql;

import com.ai.appframe2.complex.mbean.standard.IControl;

public abstract interface SQLMonitorMBean extends IControl
{
  public abstract SQLSummary[] fetchSQLSummary(String paramString);

  public abstract String printSQLSummary(String paramString);

  public abstract void enableCount();

  public abstract void disableCount();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sql.SQLMonitorMBean
 * JD-Core Version:    0.5.4
 */