/*    */ package com.ai.appframe2.complex.mbean;
/*    */ 
/*    */ import com.ai.appframe2.complex.mbean.registry.BlankMBeanRegistryImpl;
/*    */ import com.ai.appframe2.complex.mbean.registry.IMBeanRegistry;
/*    */ import com.ai.appframe2.complex.mbean.registry.LocalMBeanRegistryImpl;
/*    */ import com.ai.appframe2.complex.mbean.registry.RemoteMBeanRegistryImpl;
/*    */ import com.ai.appframe2.complex.mbean.registry.Was61MBeanRegistryImpl;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class MBeanRegistryFactory
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(MBeanRegistryFactory.class);
/* 24 */   private static IMBeanRegistry objIMBeanRegistry = null;
/*    */ 
/*    */   public static void registry()
/*    */   {
/*    */     try
/*    */     {
/* 67 */       objIMBeanRegistry.registry();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 71 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registryfactory.registry_error"), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void unregistry()
/*    */   {
/*    */     try
/*    */     {
/* 80 */       objIMBeanRegistry.unregistry();
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 84 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registryfactory.unregistry_error"), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 28 */       if (JMXConfigure.isEnable()) {
/* 29 */         if (JMXConfigure.getProperties().getProperty("jmx.registry.type").equalsIgnoreCase("local"))
/*    */         {
/* 31 */           objIMBeanRegistry = new LocalMBeanRegistryImpl();
/*    */         }
/* 33 */         else if (JMXConfigure.getProperties().getProperty("jmx.registry.type").equalsIgnoreCase("remote"))
/*    */         {
/* 35 */           objIMBeanRegistry = new RemoteMBeanRegistryImpl();
/*    */         }
/* 37 */         else if (JMXConfigure.getProperties().getProperty("jmx.registry.type").equalsIgnoreCase("was61"))
/*    */         {
/* 39 */           objIMBeanRegistry = new Was61MBeanRegistryImpl();
/*    */         }
/*    */         else {
/* 42 */           objIMBeanRegistry = new BlankMBeanRegistryImpl();
/*    */         }
/*    */       }
/*    */       else {
/* 46 */         objIMBeanRegistry = new BlankMBeanRegistryImpl();
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 51 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registryfactory.init_error"), ex);
/* 52 */       objIMBeanRegistry = new BlankMBeanRegistryImpl();
/*    */     }
/*    */ 
/* 56 */     log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registryfactory.class_info", new String[] { objIMBeanRegistry.toString() }));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.MBeanRegistryFactory
 * JD-Core Version:    0.5.4
 */