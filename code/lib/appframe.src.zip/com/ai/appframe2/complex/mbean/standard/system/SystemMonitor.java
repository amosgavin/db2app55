/*     */ package com.ai.appframe2.complex.mbean.standard.system;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class SystemMonitor
/*     */   implements SystemMonitorMBean
/*     */ {
/*     */   public String fetchResourcePath(String resource)
/*     */   {
/*  34 */     URL url = Thread.currentThread().getContextClassLoader().getResource(resource);
/*  35 */     if (url != null) {
/*  36 */       return url.toString();
/*     */     }
/*     */ 
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */   public String fetchClassLoaderByResourcePath(String resource)
/*     */   {
/*  49 */     return Thread.currentThread().getContextClassLoader().toString();
/*     */   }
/*     */ 
/*     */   public String fetchResourceFromClassPath(String resource)
/*     */   {
/*  58 */     String rtn = "";
/*  59 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(resource);
/*  60 */     if (input != null) {
/*     */       try {
/*  62 */         BufferedReader reader = null;
/*  63 */         reader = new BufferedReader(new InputStreamReader(input));
/*  64 */         StringBuilder buffer = new StringBuilder();
/*  65 */         String line = null;
/*  66 */         line = reader.readLine();
/*  67 */         while (line != null) {
/*  68 */           buffer.append(line);
/*  69 */           buffer.append("\n");
/*  70 */           line = reader.readLine();
/*     */         }
/*  72 */         rtn = buffer.toString();
/*     */       }
/*     */       catch (Throwable ex) {
/*  75 */         rtn = "Failed to get resource:" + ex.getMessage();
/*     */       }
/*     */     }
/*  78 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String printSystemProperties(String key)
/*     */   {
/*  87 */     StringBuilder sb = new StringBuilder();
/*  88 */     Properties prop = System.getProperties();
/*  89 */     Set keys = prop.keySet();
/*     */     Iterator iter;
/*     */     Iterator iter;
/*  90 */     if (StringUtils.isBlank(key)) {
/*  91 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/*  92 */         String item = (String)iter.next();
/*  93 */         sb.append(item + "=" + prop.getProperty(item) + "\n");
/*     */       }
/*     */     }
/*     */     else {
/*  97 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/*  98 */         String item = (String)iter.next();
/*  99 */         if (item.indexOf(key) != -1) {
/* 100 */           sb.append(item + "=" + prop.getProperty(item) + "\n");
/*     */         }
/*     */       }
/*     */     }
/* 104 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public HashMap fetchSystemProperties(String key)
/*     */   {
/* 113 */     HashMap rtn = new HashMap();
/* 114 */     Properties prop = System.getProperties();
/* 115 */     Set keys = prop.keySet();
/*     */     Iterator iter;
/*     */     Iterator iter;
/* 116 */     if (StringUtils.isBlank(key)) {
/* 117 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/* 118 */         String item = (String)iter.next();
/* 119 */         rtn.put(item, prop.getProperty(item));
/*     */       }
/*     */     }
/*     */     else {
/* 123 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/* 124 */         String item = (String)iter.next();
/* 125 */         if (item.indexOf(key) != -1) {
/* 126 */           rtn.put(item, prop.getProperty(item));
/*     */         }
/*     */       }
/*     */     }
/* 130 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.system.SystemMonitor
 * JD-Core Version:    0.5.4
 */