/*    */ package com.ai.appframe2.complex.mbean.standard.sql;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SQLSummary
/*    */   implements Serializable
/*    */ {
/*    */   private String sql;
/*    */   private int type;
/*    */   private long last;
/*    */   private long min;
/*    */   private long max;
/*    */   private long avg;
/*    */   private long lastUseTime;
/*    */   private long count;
/*    */   private long totalUseTime;
/*    */ 
/*    */   public String getSql()
/*    */   {
/* 28 */     return this.sql;
/*    */   }
/*    */ 
/*    */   public void setSql(String sql) {
/* 32 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public int getType() {
/* 36 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(int type) {
/* 40 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public long getLast() {
/* 44 */     return this.last;
/*    */   }
/*    */ 
/*    */   public void setLast(long last) {
/* 48 */     this.last = last;
/*    */   }
/*    */ 
/*    */   public long getMin() {
/* 52 */     return this.min;
/*    */   }
/*    */ 
/*    */   public void setMin(long min) {
/* 56 */     this.min = min;
/*    */   }
/*    */ 
/*    */   public long getMax() {
/* 60 */     return this.max;
/*    */   }
/*    */ 
/*    */   public void setMax(long max) {
/* 64 */     this.max = max;
/*    */   }
/*    */ 
/*    */   public long getAvg() {
/* 68 */     return this.avg;
/*    */   }
/*    */ 
/*    */   public void setAvg(long avg) {
/* 72 */     this.avg = avg;
/*    */   }
/*    */ 
/*    */   public long getLastUseTime() {
/* 76 */     return this.lastUseTime;
/*    */   }
/*    */ 
/*    */   public void setLastUseTime(long lastUseTime) {
/* 80 */     this.lastUseTime = lastUseTime;
/*    */   }
/*    */ 
/*    */   public long getCount() {
/* 84 */     return this.count;
/*    */   }
/*    */ 
/*    */   public void setCount(long count) {
/* 88 */     this.count = count;
/*    */   }
/*    */   public long getTotalUseTime() {
/* 91 */     return this.totalUseTime;
/*    */   }
/*    */   public void setTotalUseTime(long totalUseTime) {
/* 94 */     this.totalUseTime = totalUseTime;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sql.SQLSummary
 * JD-Core Version:    0.5.4
 */