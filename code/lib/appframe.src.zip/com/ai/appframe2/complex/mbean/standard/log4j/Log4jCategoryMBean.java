package com.ai.appframe2.complex.mbean.standard.log4j;

public abstract interface Log4jCategoryMBean
{
  public abstract void activateInfo(String paramString);

  public abstract void activateDebug(String paramString);

  public abstract void activateWarn(String paramString);

  public abstract void activateError(String paramString);

  public abstract void activateFatal(String paramString);

  public abstract void reset();

  public abstract Object[] getCurrentLogger();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.log4j.Log4jCategoryMBean
 * JD-Core Version:    0.5.4
 */