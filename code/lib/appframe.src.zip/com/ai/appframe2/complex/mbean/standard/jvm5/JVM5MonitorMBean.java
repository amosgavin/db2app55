package com.ai.appframe2.complex.mbean.standard.jvm5;

public abstract interface JVM5MonitorMBean
{
  public abstract String getAllThreadInfo()
    throws Exception;

  public abstract String getMemoryInfo()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.jvm5.JVM5MonitorMBean
 * JD-Core Version:    0.5.4
 */