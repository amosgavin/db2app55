/*    */ package com.ai.appframe2.complex.mbean.standard.cc;
/*    */ 
/*    */ import com.ai.appframe2.complex.service.interfaces.IServiceClientControl;
/*    */ import com.ai.appframe2.complex.service.interfaces.IServiceInvoke;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ClientControl
/*    */   implements ClientControlMBean
/*    */ {
/*    */   public void reconnect()
/*    */     throws Exception
/*    */   {
/* 27 */     IServiceInvoke objIServiceInvoke = ServiceFactory.getServiceInvoke();
/* 28 */     if (objIServiceInvoke instanceof IServiceClientControl) {
/* 29 */       ((IServiceClientControl)objIServiceInvoke).reconnect();
/*    */     }
/*    */     else
/* 32 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.no_imp_interface", new String[] { IServiceClientControl.class.getName() }));
/*    */   }
/*    */ 
/*    */   public void connect(String group)
/*    */     throws Exception
/*    */   {
/* 43 */     IServiceInvoke objIServiceInvoke = ServiceFactory.getServiceInvoke();
/* 44 */     if (objIServiceInvoke instanceof IServiceClientControl) {
/* 45 */       ((IServiceClientControl)objIServiceInvoke).connect(group);
/*    */     }
/*    */     else
/* 48 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.no_imp_interface", new String[] { IServiceClientControl.class.getName() }));
/*    */   }
/*    */ 
/*    */   public Map listGroups()
/*    */     throws Exception
/*    */   {
/* 59 */     IServiceInvoke objIServiceInvoke = ServiceFactory.getServiceInvoke();
/*    */ 
/* 61 */     if (objIServiceInvoke instanceof IServiceClientControl) {
/* 62 */       return ((IServiceClientControl)objIServiceInvoke).listGroups();
/*    */     }
/*    */ 
/* 65 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.no_imp_interface", new String[] { objIServiceInvoke.toString() }));
/*    */   }
/*    */ 
/*    */   public String getCurrentAppCluster()
/*    */     throws Exception
/*    */   {
/* 76 */     IServiceInvoke objIServiceInvoke = ServiceFactory.getServiceInvoke();
/* 77 */     if (objIServiceInvoke instanceof IServiceClientControl) {
/* 78 */       return ((IServiceClientControl)objIServiceInvoke).getCurrentAppCluster();
/*    */     }
/*    */ 
/* 81 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.no_imp_interface", new String[] { IServiceClientControl.class.getName() }));
/*    */   }
/*    */ 
/*    */   public String getOldAppCluster()
/*    */     throws Exception
/*    */   {
/* 92 */     IServiceInvoke objIServiceInvoke = ServiceFactory.getServiceInvoke();
/* 93 */     if (objIServiceInvoke instanceof IServiceClientControl) {
/* 94 */       return ((IServiceClientControl)objIServiceInvoke).getOldAppCluster();
/*    */     }
/*    */ 
/* 97 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.no_imp_interface", new String[] { IServiceClientControl.class.getName() }));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.cc.ClientControl
 * JD-Core Version:    0.5.4
 */