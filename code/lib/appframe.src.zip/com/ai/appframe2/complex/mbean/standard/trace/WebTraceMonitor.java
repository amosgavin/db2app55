/*     */ package com.ai.appframe2.complex.mbean.standard.trace;
/*     */ 
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class WebTraceMonitor
/*     */   implements WebTraceMonitorMBean
/*     */ {
/*  16 */   private static boolean GLOBAL_WEB_TRACE_SWIFT = false;
/*  17 */   private static String CODE = null;
/*  18 */   private static String URL = null;
/*  19 */   private static String CLIENT_IP = null;
/*     */ 
/*  21 */   private static int DURATION = 0;
/*  22 */   private static long END_TIME = 0L;
/*     */ 
/*     */   public static boolean isTimeOut()
/*     */   {
/*  32 */     boolean rtn = true;
/*  33 */     if (System.currentTimeMillis() >= END_TIME) {
/*  34 */       rtn = true;
/*     */     }
/*     */     else {
/*  37 */       rtn = false;
/*     */     }
/*  39 */     return rtn;
/*     */   }
/*     */ 
/*     */   public static boolean isEnableGlobalTrace()
/*     */   {
/*  47 */     return GLOBAL_WEB_TRACE_SWIFT;
/*     */   }
/*     */ 
/*     */   public static void enableGlobalTrace(String code, String url, String clientIp, int duration)
/*     */   {
/*  56 */     CODE = code;
/*  57 */     URL = url;
/*     */ 
/*  59 */     if (!StringUtils.isBlank(clientIp)) {
/*  60 */       CLIENT_IP = clientIp;
/*     */     }
/*     */     else {
/*  63 */       CLIENT_IP = null;
/*     */     }
/*     */ 
/*  66 */     if (duration > 0) {
/*  67 */       DURATION = duration;
/*  68 */       END_TIME = System.currentTimeMillis() + duration * 1000;
/*     */     }
/*     */     else {
/*  71 */       DURATION = 0;
/*  72 */       END_TIME = 0L;
/*     */     }
/*     */ 
/*  75 */     GLOBAL_WEB_TRACE_SWIFT = true;
/*     */   }
/*     */ 
/*     */   public static void disableGlobalTrace()
/*     */   {
/*  82 */     GLOBAL_WEB_TRACE_SWIFT = false;
/*  83 */     CODE = null;
/*  84 */     URL = null;
/*  85 */     CLIENT_IP = null;
/*  86 */     DURATION = 0;
/*  87 */     END_TIME = 0L;
/*     */   }
/*     */ 
/*     */   public static String _getCode() {
/*  91 */     return CODE;
/*     */   }
/*     */ 
/*     */   public static String _getUrl() {
/*  95 */     return URL;
/*     */   }
/*     */ 
/*     */   public static String _getClientIp() {
/*  99 */     return CLIENT_IP;
/*     */   }
/*     */ 
/*     */   public static int _getDuration() {
/* 103 */     return DURATION;
/*     */   }
/*     */ 
/*     */   public boolean isEnable()
/*     */   {
/* 112 */     return isEnableGlobalTrace();
/*     */   }
/*     */ 
/*     */   public void disable()
/*     */   {
/* 119 */     disableGlobalTrace();
/*     */   }
/*     */ 
/*     */   public void enable(String code, String url, String clientIp, int duration)
/*     */   {
/* 130 */     enableGlobalTrace(code, url, clientIp, duration);
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/* 135 */     return URL;
/*     */   }
/*     */ 
/*     */   public String getCode() {
/* 139 */     return CODE;
/*     */   }
/*     */ 
/*     */   public String getClientIp() {
/* 143 */     return CLIENT_IP;
/*     */   }
/*     */ 
/*     */   public int getDuration() {
/* 147 */     return DURATION;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.trace.WebTraceMonitor
 * JD-Core Version:    0.5.4
 */