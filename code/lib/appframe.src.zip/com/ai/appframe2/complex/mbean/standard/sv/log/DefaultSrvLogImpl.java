/*    */ package com.ai.appframe2.complex.mbean.standard.sv.log;
/*    */ 
/*    */ import com.ai.appframe2.common.SessionManager;
/*    */ import com.ai.appframe2.complex.mbean.standard.sv.SVMethodMonitor;
/*    */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*    */ import com.ai.appframe2.privilege.UserInfoInterface;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.InputStream;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Iterator;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class DefaultSrvLogImpl
/*    */   implements ISrvLog
/*    */ {
/* 29 */   private static transient Log log = LogFactory.getLog(DefaultSrvLogImpl.class);
/*    */ 
/* 31 */   private static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("MMddHHmmss");
/*    */ 
/* 33 */   private static Boolean FIRST = Boolean.TRUE;
/*    */ 
/* 36 */   private static boolean IS_SRV_LOG_ENABLE = false;
/*    */ 
/*    */   public void logSrvInfo(String className, String methodName, long last, boolean isSuccess, long useTime, long cpuTime)
/*    */   {
/* 83 */     if (!IS_SRV_LOG_ENABLE) {
/* 84 */       return;
/*    */     }
/*    */     try
/*    */     {
/* 88 */       StringBuilder sb = new StringBuilder();
/*    */ 
/* 91 */       sb.append(DATE_FORMAT.format(new Date(last)) + "|");
/*    */ 
/* 94 */       sb.append(className + "|");
/*    */ 
/* 97 */       sb.append(methodName + "|");
/*    */ 
/* 100 */       if (isSuccess) {
/* 101 */         sb.append("1|");
/*    */       }
/*    */       else {
/* 104 */         sb.append("0|");
/*    */       }
/*    */ 
/* 108 */       String code = null;
/* 109 */       UserInfoInterface userInfo = SessionManager.__getUserWithOutLog();
/* 110 */       if (userInfo != null) {
/* 111 */         code = userInfo.getCode();
/*    */       }
/*    */ 
/* 114 */       if (code != null) {
/* 115 */         sb.append(code + "|");
/*    */       }
/*    */       else {
/* 118 */         sb.append("|");
/*    */       }
/*    */ 
/* 122 */       sb.append(useTime);
/*    */ 
/* 124 */       if (SVMethodMonitor.IS_CPU_TIME) {
/* 125 */         sb.append("|");
/* 126 */         sb.append(cpuTime);
/*    */       }
/*    */ 
/* 129 */       log.info(sb.toString());
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 133 */       if (FIRST.equals(Boolean.TRUE))
/* 134 */         synchronized (FIRST) {
/* 135 */           FIRST = Boolean.FALSE;
/* 136 */           ex.printStackTrace();
/*    */         }
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 40 */       String serverName = RuntimeServerUtil.getServerName();
/* 41 */       InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("system/jmx/srvlog.properties");
/*    */       Iterator iter;
/* 42 */       if (is != null) {
/* 43 */         Properties p = new Properties();
/* 44 */         p.load(is);
/* 45 */         Set key = p.keySet();
/* 46 */         for (iter = key.iterator(); iter.hasNext(); ) {
/* 47 */           String item = (String)iter.next();
/* 48 */           if (StringUtils.contains(serverName, item)) {
/* 49 */             IS_SRV_LOG_ENABLE = true;
/* 50 */             break;
/*    */           }
/*    */         }
/*    */       }
/*    */       else {
/* 55 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.exitsinfo"));
/*    */       }
/*    */ 
/* 58 */       if (IS_SRV_LOG_ENABLE) {
/* 59 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.enabled", new String[] { serverName }));
/*    */       }
/*    */       else
/* 62 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.noenabled", new String[] { serverName }));
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 66 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.check_enabled"), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sv.log.DefaultSrvLogImpl
 * JD-Core Version:    0.5.4
 */