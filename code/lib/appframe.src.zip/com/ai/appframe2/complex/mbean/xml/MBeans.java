/*    */ package com.ai.appframe2.complex.mbean.xml;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class MBeans
/*    */ {
/*  7 */   private List list = new ArrayList();
/*    */ 
/*    */   public void addMBean(MBean bean)
/*    */   {
/* 12 */     this.list.add(bean);
/*    */   }
/*    */ 
/*    */   public MBean[] getMBeans() {
/* 16 */     return (MBean[])(MBean[])this.list.toArray(new MBean[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.xml.MBeans
 * JD-Core Version:    0.5.4
 */