/*    */ package com.ai.appframe2.complex.mbean;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class JMXConfigure
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(JMXConfigure.class);
/*    */ 
/* 24 */   private static boolean isEnable = false;
/* 25 */   private static final Properties properties = new Properties();
/*    */ 
/*    */   public static Properties getProperties()
/*    */   {
/* 62 */     return properties;
/*    */   }
/*    */ 
/*    */   public static boolean isEnable()
/*    */   {
/* 70 */     return isEnable;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 74 */     System.out.println(isEnable);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 27 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream("system/jmx/jmx.properties");
/* 28 */     if (input == null) {
/* 29 */       if (!log.isDebugEnabled())
/*    */         return;
/* 31 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.no_jmxfile"));
/*    */     }
/*    */     else
/*    */     {
/*    */       try {
/* 36 */         properties.load(input);
/* 37 */         if ((properties != null) && (properties.getProperty("jmx.enable").equalsIgnoreCase("true"))) {
/* 38 */           isEnable = true;
/* 39 */           if (log.isInfoEnabled())
/*    */           {
/* 41 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.enabe"));
/*    */           }
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (IOException ex)
/*    */       {
/* 48 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.load_jmxfile_error"), ex);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.JMXConfigure
 * JD-Core Version:    0.5.4
 */