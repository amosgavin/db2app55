/*     */ package com.ai.appframe2.complex.mbean.standard.cache;
/*     */ 
/*     */ import com.ai.appframe2.complex.cache.CacheFactory;
/*     */ import com.ai.appframe2.complex.cache.ICache;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class CacheMonitor
/*     */   implements CacheMonitorMBean
/*     */ {
/*  24 */   private static final HashMap map = new HashMap();
/*     */ 
/*     */   public static void refreshInvoke(Class cacheClass, long oldCount, long newCount, long startTime, long endTime)
/*     */   {
/*  38 */     if (map.containsKey(cacheClass.getName())) {
/*  39 */       CacheSummary objSQLSummary = (CacheSummary)map.get(cacheClass.getName());
/*  40 */       objSQLSummary.setOldCount(oldCount);
/*  41 */       objSQLSummary.setNewCount(newCount);
/*  42 */       objSQLSummary.setLastRefreshStartTime(startTime);
/*  43 */       objSQLSummary.setLastRefreshEndTime(endTime);
/*  44 */       map.put(cacheClass.getName(), objSQLSummary);
/*     */     }
/*     */     else {
/*  47 */       CacheSummary objSQLSummary = new CacheSummary();
/*  48 */       objSQLSummary.setClassName(cacheClass.getName());
/*  49 */       objSQLSummary.setOldCount(oldCount);
/*  50 */       objSQLSummary.setNewCount(newCount);
/*  51 */       objSQLSummary.setLastRefreshStartTime(startTime);
/*  52 */       objSQLSummary.setLastRefreshEndTime(endTime);
/*  53 */       map.put(cacheClass.getName(), objSQLSummary);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] listAllCache()
/*     */   {
/*  62 */     List list = new ArrayList();
/*  63 */     Set keys = CacheFactory._getCacheInstances().keySet();
/*  64 */     for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/*  65 */       Class item = (Class)iter.next();
/*  66 */       list.add(item.getName());
/*     */     }
/*  68 */     return (String[])(String[])list.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public String printCacheString(String className)
/*     */   {
/*  77 */     CacheSummary[] objCacheSummary = fetchCache(className);
/*     */ 
/*  79 */     TextTable objTextTable = new TextTable();
/*     */ 
/*  83 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.class_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.count_before_refresh"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.count_after_refresh"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.last_refresh_begintime"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.last_refresh_endtime") });
/*     */ 
/*  88 */     if (objCacheSummary != null) {
/*  89 */       for (int i = 0; i < objCacheSummary.length; ++i) {
/*  90 */         objTextTable.addRow(new String[] { objCacheSummary[i].getClassName(), String.valueOf(objCacheSummary[i].getOldCount()), String.valueOf(objCacheSummary[i].getNewCount()), String.valueOf(objCacheSummary[i].getLastRefreshStartTime()), String.valueOf(objCacheSummary[i].getLastRefreshEndTime()) });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  96 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public CacheSummary[] fetchCache(String className)
/*     */   {
/* 105 */     CacheSummary[] rtn = null;
/* 106 */     if (StringUtils.isBlank(className)) {
/* 107 */       rtn = (CacheSummary[])(CacheSummary[])map.values().toArray(new CacheSummary[0]);
/*     */     }
/* 110 */     else if (map.containsKey(className)) {
/* 111 */       rtn = new CacheSummary[1];
/* 112 */       rtn[0] = ((CacheSummary)map.get(className));
/*     */     }
/*     */ 
/* 115 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String forceRefresh(String className)
/*     */   {
/* 124 */     String rtn = "";
/*     */     try {
/* 126 */       Class clazz = Class.forName(className);
/* 127 */       if (CacheFactory._getCacheInstances().containsKey(clazz)) {
/* 128 */         ICache cache = (ICache)CacheFactory._getCacheInstances().get(clazz);
/* 129 */         cache.refresh();
/* 130 */         rtn = "Refresh finished!";
/*     */       }
/*     */       else {
/* 133 */         throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.cache.nocalss", new String[] { className }));
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 137 */       rtn = "The class named " + className + " can not be found.";
/*     */     }
/*     */     catch (Throwable ex) {
/* 140 */       rtn = "An error occured:" + ex.getMessage();
/*     */     }
/* 142 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.cache.CacheMonitor
 * JD-Core Version:    0.5.4
 */