/*    */ package com.ai.appframe2.complex.mbean.xml;
/*    */ 
/*    */ public class MBean
/*    */ {
/*    */   private String classname;
/*    */   private String desc;
/*    */   private String name;
/*    */   private String enable;
/*    */   private String timeout;
/*    */   private String interfacename;
/*    */ 
/*    */   public String getClassname()
/*    */   {
/* 13 */     return this.classname;
/*    */   }
/*    */   public void setClassname(String classname) {
/* 16 */     this.classname = classname;
/*    */   }
/*    */   public String getDesc() {
/* 19 */     return this.desc;
/*    */   }
/*    */   public void setDesc(String desc) {
/* 22 */     this.desc = desc;
/*    */   }
/*    */   public String getName() {
/* 25 */     return this.name;
/*    */   }
/*    */   public void setName(String name) {
/* 28 */     this.name = name;
/*    */   }
/*    */   public String getEnable() {
/* 31 */     return this.enable;
/*    */   }
/*    */   public void setEnable(String enable) {
/* 34 */     this.enable = enable;
/*    */   }
/*    */   public String getTimeout() {
/* 37 */     return this.timeout;
/*    */   }
/*    */   public void setTimeout(String timeout) {
/* 40 */     this.timeout = timeout;
/*    */   }
/*    */   public String getInterfacename() {
/* 43 */     return this.interfacename;
/*    */   }
/*    */   public void setInterfacename(String interfacename) {
/* 46 */     this.interfacename = interfacename;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.xml.MBean
 * JD-Core Version:    0.5.4
 */