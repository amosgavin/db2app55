/*     */ package com.ai.appframe2.complex.mbean.standard.session;
/*     */ 
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.privilege.UserManager;
/*     */ import com.ai.appframe2.privilege.UserManagerFactory;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class AppframeSessionMonitor
/*     */   implements AppframeSessionMonitorMBean
/*     */ {
/*  27 */   private static transient Log log = LogFactory.getLog(AppframeSessionMonitor.class);
/*     */ 
/*     */   public HashMap[] fetchLogedUsers()
/*     */   {
/*  38 */     HashMap[] rtn = null;
/*     */     try {
/*  40 */       UserInfoInterface[] userInfo = UserManagerFactory.getUserManager().getLogedUsers();
/*  41 */       if ((userInfo != null) && (userInfo.length != 0)) {
/*  42 */         rtn = new HashMap[userInfo.length];
/*  43 */         for (int i = 0; i < rtn.length; ++i) {
/*  44 */           rtn[i] = new HashMap();
/*  45 */           rtn[i].put("SERVER_NAME", RuntimeServerUtil.getServerName());
/*  46 */           rtn[i].put("ID", new Long(userInfo[i].getID()));
/*  47 */           rtn[i].put("IP", userInfo[i].getIP());
/*  48 */           rtn[i].put("CODE", userInfo[i].getCode());
/*  49 */           rtn[i].put("NAME", userInfo[i].getName());
/*  50 */           rtn[i].put("ORG_ID", new Long(userInfo[i].getOrgId()));
/*  51 */           rtn[i].put("ORG_NAME", userInfo[i].getOrgName());
/*  52 */           rtn[i].put("SERIAL_ID", userInfo[i].getSerialID());
/*  53 */           rtn[i].put("LOGIN_TIME", userInfo[i].getLoginTime());
/*  54 */           rtn[i].put("SESSION_ID", userInfo[i].getSessionID());
/*  55 */           rtn[i].put("ATTRS", "ATTRS");
/*     */ 
/*  59 */           Map attrs = userInfo[i].getAttrs();
/*  60 */           Map canSeriaObject = new HashMap();
/*  61 */           Set keys = attrs.keySet();
/*  62 */           for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/*  63 */             Object item = iter.next();
/*  64 */             Object value = attrs.get(item);
/*  65 */             if ((item != null) && (value != null) && 
/*  66 */               (((item instanceof String) || (item.getClass().isPrimitive()))) && ((
/*  66 */               (value instanceof String) || (value.getClass().isPrimitive()))))
/*     */             {
/*  68 */               canSeriaObject.put(item, value);
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*  74 */           rtn[i].put("ATTRS", canSeriaObject);
/*     */         }
/*     */       }
/*     */       else {
/*  78 */         rtn = new HashMap[0];
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/*  82 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.login_user_exception"), ex);
/*     */     }
/*  84 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String printLogedUsersSummary()
/*     */   {
/*  92 */     HashMap[] objUserInfo = fetchLogedUsers();
/*     */ 
/*  94 */     TextTable objTextTable = new TextTable();
/*     */     try {
/*  96 */       objTextTable.setHeader(new String[] { "SERVER_NAME", AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.user_id"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.client_ip"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.staff_id"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.user_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.org_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.loggin_no"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.loggin_time"), "SessionID", AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.other_info") });
/*     */ 
/* 104 */       if (objUserInfo != null) {
/* 105 */         for (int i = 0; i < objUserInfo.length; ++i) {
/* 106 */           objTextTable.addRow(new String[] { RuntimeServerUtil.getServerName(), String.valueOf(((Long)objUserInfo[i].get("ID")).longValue()), (String)objUserInfo[i].get("IP"), (String)objUserInfo[i].get("CODE"), (String)objUserInfo[i].get("NAME"), (String)objUserInfo[i].get("ORG_NAME"), (String)objUserInfo[i].get("SERIAL_ID"), ((Timestamp)objUserInfo[i].get("LOGIN_TIME")).toString(), (String)objUserInfo[i].get("SESSION_ID"), objUserInfo[i].get("ATTRS").toString() });
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 121 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.session.login_user_exception"), ex);
/*     */     }
/* 123 */     return objTextTable.draw();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.session.AppframeSessionMonitor
 * JD-Core Version:    0.5.4
 */