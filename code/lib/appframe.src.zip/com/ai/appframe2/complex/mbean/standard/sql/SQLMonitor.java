/*     */ package com.ai.appframe2.complex.mbean.standard.sql;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class SQLMonitor
/*     */   implements SQLMonitorMBean, IControl
/*     */ {
/*     */   public static final int PREPARED_STATEMENT = 1;
/*     */   public static final int STATEMENT = 1;
/*  26 */   private static final HashMap map = new HashMap();
/*     */ 
/*  28 */   private static boolean isEnable = false;
/*     */ 
/*  30 */   private static boolean isCountEnable = false;
/*     */ 
/*  32 */   private static Long endTime = new Long(0L);
/*     */ 
/*     */   public static boolean isOpenCountEnable()
/*     */   {
/*  39 */     return isCountEnable;
/*     */   }
/*     */ 
/*     */   public static boolean isEnable()
/*     */   {
/*  47 */     return isEnable;
/*     */   }
/*     */ 
/*     */   public static void sqlInvoke(String sql, int type, long useTime)
/*     */   {
/*  58 */     if ((endTime.longValue() >= 0L) && (System.currentTimeMillis() >= endTime.longValue())) {
/*  59 */       synchronized (endTime) {
/*  60 */         map.clear();
/*  61 */         isEnable = false;
/*  62 */         isCountEnable = false;
/*  63 */         endTime = new Long(0L);
/*     */       }
/*     */     }
/*     */ 
/*  67 */     if (!isEnable) {
/*  68 */       return;
/*     */     }
/*     */ 
/*  71 */     if (map.containsKey(sql)) {
/*  72 */       SQLSummary objSQLSummary = (SQLSummary)map.get(sql);
/*  73 */       objSQLSummary.setLast(System.currentTimeMillis());
/*  74 */       objSQLSummary.setLastUseTime(useTime);
/*  75 */       objSQLSummary.setCount(objSQLSummary.getCount() + 1L);
/*  76 */       if (useTime < objSQLSummary.getMin()) {
/*  77 */         objSQLSummary.setMin(useTime);
/*     */       }
/*  79 */       if (useTime > objSQLSummary.getMax()) {
/*  80 */         objSQLSummary.setMax(useTime);
/*     */       }
/*  82 */       objSQLSummary.setTotalUseTime(objSQLSummary.getTotalUseTime() + useTime);
/*  83 */       objSQLSummary.setAvg(objSQLSummary.getTotalUseTime() / objSQLSummary.getCount());
/*  84 */       map.put(sql, objSQLSummary);
/*     */     }
/*     */     else {
/*  87 */       SQLSummary objSQLSummary = new SQLSummary();
/*  88 */       objSQLSummary.setSql(sql);
/*  89 */       objSQLSummary.setType(type);
/*  90 */       objSQLSummary.setLast(System.currentTimeMillis());
/*  91 */       objSQLSummary.setLastUseTime(useTime);
/*  92 */       objSQLSummary.setTotalUseTime(useTime);
/*  93 */       objSQLSummary.setMin(useTime);
/*  94 */       objSQLSummary.setMax(useTime);
/*  95 */       objSQLSummary.setAvg(useTime);
/*  96 */       objSQLSummary.setCount(1L);
/*  97 */       map.put(sql, objSQLSummary);
/*     */     }
/*     */   }
/*     */ 
/*     */   public SQLSummary[] fetchSQLSummary(String condition)
/*     */   {
/* 107 */     SQLSummary[] rtn = null;
/* 108 */     if (StringUtils.isBlank(condition)) {
/* 109 */       rtn = (SQLSummary[])(SQLSummary[])map.values().toArray(new SQLSummary[0]);
/*     */     }
/*     */     else {
/* 112 */       List list = new ArrayList();
/* 113 */       Set keys = map.keySet();
/* 114 */       for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 115 */         String item = (String)iter.next();
/* 116 */         if (item.indexOf(condition) != -1) {
/* 117 */           list.add(map.get(item));
/*     */         }
/*     */       }
/*     */ 
/* 121 */       rtn = (SQLSummary[])(SQLSummary[])list.toArray(new SQLSummary[0]);
/*     */     }
/* 123 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String printSQLSummary(String condition)
/*     */   {
/* 133 */     SQLSummary[] objSQLSummary = fetchSQLSummary(condition);
/*     */ 
/* 135 */     TextTable objTextTable = new TextTable();
/*     */ 
/* 137 */     objTextTable.setHeader(new String[] { "SQL", AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.item_type"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.min_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.max_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.avg_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.total_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.execute_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_access_time") });
/*     */ 
/* 145 */     if (objSQLSummary != null) {
/* 146 */       for (int i = 0; i < objSQLSummary.length; ++i) {
/* 147 */         objTextTable.addRow(new String[] { objSQLSummary[i].getSql(), String.valueOf(objSQLSummary[i].getType()), String.valueOf(objSQLSummary[i].getMin()), String.valueOf(objSQLSummary[i].getMax()), String.valueOf(objSQLSummary[i].getAvg()), String.valueOf(objSQLSummary[i].getLastUseTime()), String.valueOf(objSQLSummary[i].getTotalUseTime()), String.valueOf(objSQLSummary[i].getCount()), String.valueOf(objSQLSummary[i].getLast()) });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 158 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public synchronized void disable()
/*     */   {
/* 165 */     map.clear();
/* 166 */     isEnable = false;
/* 167 */     isCountEnable = false;
/*     */   }
/*     */ 
/*     */   public synchronized void enable(long seconds)
/*     */   {
/* 175 */     if (seconds < 0L) {
/* 176 */       endTime = new Long(seconds);
/*     */     }
/*     */     else {
/* 179 */       endTime = new Long(System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 181 */     isEnable = true;
/* 182 */     isCountEnable = true;
/*     */   }
/*     */ 
/*     */   public boolean fetchStatus()
/*     */   {
/* 191 */     return isEnable;
/*     */   }
/*     */ 
/*     */   public synchronized void enableCount()
/*     */   {
/* 198 */     isCountEnable = true;
/*     */   }
/*     */ 
/*     */   public synchronized void disableCount()
/*     */   {
/* 205 */     isCountEnable = false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sql.SQLMonitor
 * JD-Core Version:    0.5.4
 */