package com.ai.appframe2.complex.mbean.standard.cache;

public abstract interface CacheMonitorMBean
{
  public abstract String[] listAllCache();

  public abstract String printCacheString(String paramString);

  public abstract CacheSummary[] fetchCache(String paramString);

  public abstract String forceRefresh(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.cache.CacheMonitorMBean
 * JD-Core Version:    0.5.4
 */