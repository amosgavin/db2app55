package com.ai.appframe2.complex.mbean.standard.sv;

import com.ai.appframe2.complex.mbean.standard.IControl;

public abstract interface SVMethodMonitorMBean extends IControl
{
  public abstract SVMethodSummary[] fetchSVMethodSummary(String paramString);

  public abstract String printSVMethodSummary(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sv.SVMethodMonitorMBean
 * JD-Core Version:    0.5.4
 */