package com.ai.appframe2.complex.mbean.standard.system;

import java.util.HashMap;

public abstract interface SystemMonitorMBean
{
  public abstract String fetchResourcePath(String paramString);

  public abstract String fetchClassLoaderByResourcePath(String paramString);

  public abstract String fetchResourceFromClassPath(String paramString);

  public abstract String printSystemProperties(String paramString);

  public abstract HashMap fetchSystemProperties(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.system.SystemMonitorMBean
 * JD-Core Version:    0.5.4
 */