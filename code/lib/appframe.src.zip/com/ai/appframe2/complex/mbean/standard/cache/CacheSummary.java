/*    */ package com.ai.appframe2.complex.mbean.standard.cache;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class CacheSummary
/*    */   implements Serializable
/*    */ {
/*    */   private String className;
/*    */   private long oldCount;
/*    */   private long lastRefreshStartTime;
/*    */   private long lastRefreshEndTime;
/*    */   private long newCount;
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 25 */     return this.className;
/*    */   }
/*    */ 
/*    */   public void setClassName(String className) {
/* 29 */     this.className = className;
/*    */   }
/*    */ 
/*    */   public long getOldCount() {
/* 33 */     return this.oldCount;
/*    */   }
/*    */ 
/*    */   public void setOldCount(long oldCount) {
/* 37 */     this.oldCount = oldCount;
/*    */   }
/*    */ 
/*    */   public long getLastRefreshStartTime() {
/* 41 */     return this.lastRefreshStartTime;
/*    */   }
/*    */ 
/*    */   public void setLastRefreshStartTime(long lastRefreshStartTime) {
/* 45 */     this.lastRefreshStartTime = lastRefreshStartTime;
/*    */   }
/*    */ 
/*    */   public long getLastRefreshEndTime() {
/* 49 */     return this.lastRefreshEndTime;
/*    */   }
/*    */ 
/*    */   public void setLastRefreshEndTime(long lastRefreshEndTime) {
/* 53 */     this.lastRefreshEndTime = lastRefreshEndTime;
/*    */   }
/*    */ 
/*    */   public long getNewCount() {
/* 57 */     return this.newCount;
/*    */   }
/*    */ 
/*    */   public void setNewCount(long newCount) {
/* 61 */     this.newCount = newCount;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.cache.CacheSummary
 * JD-Core Version:    0.5.4
 */