package com.ai.appframe2.complex.mbean.standard.sc;

public abstract interface ServiceControlMBean
{
  public abstract void refreshControlData();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sc.ServiceControlMBean
 * JD-Core Version:    0.5.4
 */