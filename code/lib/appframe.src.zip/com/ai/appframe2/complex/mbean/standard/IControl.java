package com.ai.appframe2.complex.mbean.standard;

public abstract interface IControl
{
  public abstract void disable();

  public abstract void enable(long paramLong);

  public abstract boolean fetchStatus();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.IControl
 * JD-Core Version:    0.5.4
 */