/*     */ package com.ai.appframe2.complex.mbean.standard.action;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class ActionMonitor
/*     */   implements ActionMonitorMBean, IControl
/*     */ {
/*  23 */   private static final HashMap map = new HashMap();
/*     */ 
/*  25 */   private static boolean isEnable = false;
/*     */ 
/*  27 */   private static Long endTime = new Long(0L);
/*     */ 
/*     */   public static boolean isEnable()
/*     */   {
/*  33 */     return isEnable;
/*     */   }
/*     */ 
/*     */   public static void actionInvoke(String className, String methodName, long useTime, boolean isSuccess)
/*     */   {
/*  45 */     if ((endTime.longValue() >= 0L) && (System.currentTimeMillis() >= endTime.longValue())) {
/*  46 */       synchronized (endTime) {
/*  47 */         map.clear();
/*  48 */         isEnable = false;
/*  49 */         endTime = new Long(0L);
/*     */       }
/*     */     }
/*     */ 
/*  53 */     if (!isEnable) {
/*  54 */       return;
/*     */     }
/*     */ 
/*  57 */     String key = className + "|" + methodName;
/*  58 */     if (map.containsKey(key)) {
/*  59 */       ActionSummary objActionSummary = (ActionSummary)map.get(key);
/*  60 */       objActionSummary.setLastUseTime(useTime);
/*  61 */       objActionSummary.setTotalCount(objActionSummary.getTotalCount() + 1L);
/*  62 */       if (useTime < objActionSummary.getMin()) {
/*  63 */         objActionSummary.setMin(useTime);
/*     */       }
/*  65 */       if (useTime > objActionSummary.getMax()) {
/*  66 */         objActionSummary.setMax(useTime);
/*     */       }
/*  68 */       objActionSummary.setTotalUseTime(objActionSummary.getTotalUseTime() + useTime);
/*  69 */       objActionSummary.setAvg(objActionSummary.getTotalUseTime() / objActionSummary.getTotalCount());
/*     */ 
/*  71 */       if (isSuccess) {
/*  72 */         objActionSummary.setSuccessCount(objActionSummary.getSuccessCount() + 1L);
/*     */       }
/*     */       else {
/*  75 */         objActionSummary.setFailCount(objActionSummary.getFailCount() + 1L);
/*     */       }
/*     */ 
/*  78 */       objActionSummary.setLast(System.currentTimeMillis());
/*  79 */       map.put(key, objActionSummary);
/*     */     }
/*     */     else {
/*  82 */       ActionSummary objActionSummary = new ActionSummary();
/*  83 */       objActionSummary.setClassName(className);
/*  84 */       objActionSummary.setMethodName(methodName);
/*  85 */       objActionSummary.setLastUseTime(useTime);
/*  86 */       objActionSummary.setTotalUseTime(useTime);
/*  87 */       objActionSummary.setMin(useTime);
/*  88 */       objActionSummary.setMax(useTime);
/*  89 */       objActionSummary.setAvg(useTime);
/*  90 */       objActionSummary.setTotalCount(1L);
/*  91 */       if (isSuccess) {
/*  92 */         objActionSummary.setSuccessCount(1L);
/*  93 */         objActionSummary.setFailCount(0L);
/*     */       }
/*     */       else {
/*  96 */         objActionSummary.setSuccessCount(0L);
/*  97 */         objActionSummary.setFailCount(1L);
/*     */       }
/*  99 */       objActionSummary.setLast(System.currentTimeMillis());
/* 100 */       map.put(key, objActionSummary);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ActionSummary[] fetchActionSummary(String condition)
/*     */   {
/* 110 */     ActionSummary[] rtn = null;
/* 111 */     if (StringUtils.isBlank(condition)) {
/* 112 */       rtn = (ActionSummary[])(ActionSummary[])map.values().toArray(new ActionSummary[0]);
/*     */     }
/*     */     else {
/* 115 */       List list = new ArrayList();
/* 116 */       Set keys = map.keySet();
/* 117 */       for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 118 */         String item = (String)iter.next();
/* 119 */         if (item.indexOf(condition) != -1) {
/* 120 */           list.add(map.get(item));
/*     */         }
/*     */       }
/*     */ 
/* 124 */       rtn = (ActionSummary[])(ActionSummary[])list.toArray(new ActionSummary[0]);
/*     */     }
/* 126 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String printActionSummary(String condition)
/*     */   {
/* 136 */     ActionSummary[] objActionSummary = fetchActionSummary(condition);
/*     */ 
/* 138 */     TextTable objTextTable = new TextTable();
/*     */ 
/* 141 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.class_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.method_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.min_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.max_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.avg_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.total_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.success_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.fail_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.total_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_access_time") });
/*     */ 
/* 152 */     if (objActionSummary != null) {
/* 153 */       for (int i = 0; i < objActionSummary.length; ++i) {
/* 154 */         objTextTable.addRow(new String[] { objActionSummary[i].getClassName(), objActionSummary[i].getMethodName(), String.valueOf(objActionSummary[i].getMin()), String.valueOf(objActionSummary[i].getMax()), String.valueOf(objActionSummary[i].getAvg()), String.valueOf(objActionSummary[i].getLastUseTime()), String.valueOf(objActionSummary[i].getTotalUseTime()), String.valueOf(objActionSummary[i].getSuccessCount()), String.valueOf(objActionSummary[i].getFailCount()), String.valueOf(objActionSummary[i].getTotalCount()), String.valueOf(objActionSummary[i].getLast()) });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 165 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public synchronized void disable()
/*     */   {
/* 172 */     map.clear();
/* 173 */     isEnable = false;
/*     */   }
/*     */ 
/*     */   public synchronized void enable(long seconds)
/*     */   {
/* 181 */     if (seconds < 0L) {
/* 182 */       endTime = new Long(seconds);
/*     */     }
/*     */     else {
/* 185 */       endTime = new Long(System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 187 */     isEnable = true;
/*     */   }
/*     */ 
/*     */   public boolean fetchStatus()
/*     */   {
/* 197 */     return isEnable;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.action.ActionMonitor
 * JD-Core Version:    0.5.4
 */