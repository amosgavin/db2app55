package com.ai.appframe2.complex.mbean.standard.sv.log;

public abstract interface ISrvLog
{
  public abstract void logSrvInfo(String paramString1, String paramString2, long paramLong1, boolean paramBoolean, long paramLong2, long paramLong3);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sv.log.ISrvLog
 * JD-Core Version:    0.5.4
 */