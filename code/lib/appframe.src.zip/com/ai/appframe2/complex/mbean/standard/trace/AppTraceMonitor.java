/*     */ package com.ai.appframe2.complex.mbean.standard.trace;
/*     */ 
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public class AppTraceMonitor
/*     */   implements AppTraceMonitorMBean
/*     */ {
/*  16 */   private static boolean GLOBAL_APP_TRACE_SWIFT = false;
/*  17 */   private static String CODE = null;
/*  18 */   private static String CLASS_NAME = null;
/*  19 */   private static String METHOD_NAME = null;
/*     */ 
/*     */   public static boolean isEnableGlobalTrace()
/*     */   {
/*  30 */     return GLOBAL_APP_TRACE_SWIFT;
/*     */   }
/*     */ 
/*     */   public static void enableGlobalTrace(String code, String className, String methodName)
/*     */   {
/*  39 */     CODE = code;
/*  40 */     CLASS_NAME = className;
/*     */ 
/*  42 */     if (!StringUtils.isBlank(className)) {
/*  43 */       CLASS_NAME = className;
/*     */     }
/*     */     else {
/*  46 */       CLASS_NAME = null;
/*     */     }
/*     */ 
/*  49 */     if (!StringUtils.isBlank(methodName)) {
/*  50 */       METHOD_NAME = methodName;
/*     */     }
/*     */     else {
/*  53 */       METHOD_NAME = null;
/*     */     }
/*     */ 
/*  56 */     GLOBAL_APP_TRACE_SWIFT = true;
/*     */   }
/*     */ 
/*     */   public static void disableGlobalTrace()
/*     */   {
/*  63 */     GLOBAL_APP_TRACE_SWIFT = false;
/*  64 */     CODE = null;
/*  65 */     CLASS_NAME = null;
/*  66 */     METHOD_NAME = null;
/*     */   }
/*     */ 
/*     */   public static String _getCode() {
/*  70 */     return CODE;
/*     */   }
/*     */ 
/*     */   public static String _getClassName() {
/*  74 */     return CLASS_NAME;
/*     */   }
/*     */ 
/*     */   public static String _getMethodName() {
/*  78 */     return METHOD_NAME;
/*     */   }
/*     */ 
/*     */   public boolean isEnable()
/*     */   {
/*  86 */     return isEnableGlobalTrace();
/*     */   }
/*     */ 
/*     */   public void disable()
/*     */   {
/*  93 */     disableGlobalTrace();
/*     */   }
/*     */ 
/*     */   public void enable(String code, String className, String methodName)
/*     */   {
/* 104 */     enableGlobalTrace(code, className, methodName);
/*     */   }
/*     */ 
/*     */   public String getCode() {
/* 108 */     return CODE;
/*     */   }
/*     */ 
/*     */   public String getClassName() {
/* 112 */     return CLASS_NAME;
/*     */   }
/*     */ 
/*     */   public String getMethodName() {
/* 116 */     return METHOD_NAME;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.trace.AppTraceMonitor
 * JD-Core Version:    0.5.4
 */