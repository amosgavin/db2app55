package com.ai.appframe2.complex.mbean.standard.datasource;

public abstract interface DataSourceMonitorMBean
{
  public abstract String printDataSourceConfigString(String paramString);

  public abstract DataSourceSummary fetchDataSourceConfig(String paramString);

  public abstract String printDataSourceRuntimeString(String paramString);

  public abstract DataSourceRuntime fetchDataSourceRuntime(String paramString);

  public abstract String[] getAllDataSource();

  public abstract DataSourceSummary[] fetchAllDataSourceConfig();

  public abstract DataSourceRuntime[] fetchAllDataSourceRuntime();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.datasource.DataSourceMonitorMBean
 * JD-Core Version:    0.5.4
 */