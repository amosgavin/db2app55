/*    */ package com.ai.appframe2.complex.mbean.standard.tm;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TmSummary
/*    */   implements Serializable
/*    */ {
/*    */   private long commitCount;
/*    */   private long startCount;
/*    */   private long rollbackCount;
/*    */   private long suspendCount;
/*    */   private long resumeCount;
/*    */ 
/*    */   public TmSummary(long startCount, long commitCount, long rollbackCount, long suspendCount, long resumeCount)
/*    */   {
/* 22 */     this.startCount = startCount;
/* 23 */     this.commitCount = commitCount;
/* 24 */     this.rollbackCount = rollbackCount;
/* 25 */     this.suspendCount = suspendCount;
/* 26 */     this.resumeCount = resumeCount;
/*    */   }
/*    */ 
/*    */   public long getCommitCount() {
/* 30 */     return this.commitCount;
/*    */   }
/*    */ 
/*    */   public void setCommitCount(long commitCount) {
/* 34 */     this.commitCount = commitCount;
/*    */   }
/*    */ 
/*    */   public long getStartCount() {
/* 38 */     return this.startCount;
/*    */   }
/*    */ 
/*    */   public void setStartCount(long startCount) {
/* 42 */     this.startCount = startCount;
/*    */   }
/*    */ 
/*    */   public long getRollbackCount() {
/* 46 */     return this.rollbackCount;
/*    */   }
/*    */ 
/*    */   public void setRollbackCount(long rollbackCount) {
/* 50 */     this.rollbackCount = rollbackCount;
/*    */   }
/*    */ 
/*    */   public long getSuspendCount() {
/* 54 */     return this.suspendCount;
/*    */   }
/*    */ 
/*    */   public void setSuspendCount(long suspendCount) {
/* 58 */     this.suspendCount = suspendCount;
/*    */   }
/*    */ 
/*    */   public void setResumeCount(long resumeCount) {
/* 62 */     this.resumeCount = resumeCount;
/*    */   }
/*    */ 
/*    */   public long getResumeCount() {
/* 66 */     return this.resumeCount;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.tm.TmSummary
 * JD-Core Version:    0.5.4
 */