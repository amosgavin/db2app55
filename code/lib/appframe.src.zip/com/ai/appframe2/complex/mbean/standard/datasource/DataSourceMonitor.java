/*     */ package com.ai.appframe2.complex.mbean.standard.datasource;
/*     */ 
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.dbcp.BasicDataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool;
/*     */ 
/*     */ public class DataSourceMonitor
/*     */   implements DataSourceMonitorMBean
/*     */ {
/*  24 */   private static transient Log log = LogFactory.getLog(DataSourceMonitor.class);
/*     */ 
/*     */   public String printDataSourceConfigString(String ds)
/*     */   {
/*  35 */     TextTable objTextTable = new TextTable();
/*     */ 
/*  37 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.datasource.driver"), "URL", AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.datasource.user_name"), "maxActie", "maxIdle", "minIdle", "initialSize", "maxWait" });
/*     */     try
/*     */     {
/*  41 */       DataSourceSummary objDataSourceSummary = fetchDataSourceConfig(ds);
/*     */ 
/*  44 */       if (objDataSourceSummary != null) {
/*  45 */         objTextTable.addRow(new String[] { objDataSourceSummary.getDriverClassName(), objDataSourceSummary.getUrl(), objDataSourceSummary.getUsername(), String.valueOf(objDataSourceSummary.getMaxActive()), String.valueOf(objDataSourceSummary.getMaxIdle()), String.valueOf(objDataSourceSummary.getMinIdle()), String.valueOf(objDataSourceSummary.getInitialSize()), String.valueOf(objDataSourceSummary.getMaxWait()) });
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  53 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.error"), ex);
/*     */     }
/*  55 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public DataSourceSummary fetchDataSourceConfig(String ds)
/*     */   {
/*  64 */     DataSourceSummary objDataSourceSummary = null;
/*     */     try {
/*  66 */       BasicDataSource objBasicDataSource = (BasicDataSource)DataSourceFactory.getDataSource().getDataSource(ds);
/*  67 */       if (objBasicDataSource != null) {
/*  68 */         objDataSourceSummary = new DataSourceSummary();
/*  69 */         objDataSourceSummary.setDriverClassName(objBasicDataSource.getDriverClassName());
/*  70 */         objDataSourceSummary.setUrl(objBasicDataSource.getUrl());
/*  71 */         objDataSourceSummary.setUsername(objBasicDataSource.getUsername());
/*  72 */         objDataSourceSummary.setMaxActive(objBasicDataSource.getMaxActive());
/*  73 */         objDataSourceSummary.setMaxIdle(objBasicDataSource.getMaxIdle());
/*  74 */         objDataSourceSummary.setMinIdle(objBasicDataSource.getMinIdle());
/*  75 */         objDataSourceSummary.setInitialSize(objBasicDataSource.getInitialSize());
/*  76 */         objDataSourceSummary.setMaxWait(objBasicDataSource.getMaxWait());
/*  77 */         objDataSourceSummary.setDataSource(ds);
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/*  81 */       log.error("An error Occured", ex);
/*     */     }
/*  83 */     return objDataSourceSummary;
/*     */   }
/*     */ 
/*     */   public String printDataSourceRuntimeString(String ds)
/*     */   {
/*  92 */     DataSourceRuntime objDataSourceRuntime = fetchDataSourceRuntime(ds);
/*  93 */     TextTable objTextTable = new TextTable();
/*     */ 
/*  95 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.datasource.physical_conn_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.datasource.idle_conn_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.datasource.used_conn_count") });
/*     */ 
/*  99 */     if (objDataSourceRuntime != null) {
/* 100 */       objTextTable.addRow(new String[] { String.valueOf(objDataSourceRuntime.getNumPhysical()), String.valueOf(objDataSourceRuntime.getNumIdle()), String.valueOf(objDataSourceRuntime.getNumActive()) });
/*     */     }
/*     */ 
/* 103 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public DataSourceRuntime fetchDataSourceRuntime(String ds)
/*     */   {
/* 112 */     DataSourceRuntime objDataSourceRuntime = null;
/*     */     try {
/* 114 */       BasicDataSource objBasicDataSource = (BasicDataSource)DataSourceFactory.getDataSource().getDataSource(ds);
/*     */ 
/* 116 */       if (objBasicDataSource != null) {
/* 117 */         Field connectionPoolField = null;
/*     */         try {
/* 119 */           connectionPoolField = BasicDataSource.class.getDeclaredField("connectionPool");
/* 120 */           connectionPoolField.setAccessible(true);
/* 121 */           GenericObjectPool connectionPool = (GenericObjectPool)connectionPoolField.get(objBasicDataSource);
/*     */ 
/* 123 */           long numActive = 0L;
/* 124 */           long numIdle = 0L;
/* 125 */           long numPhysical = 0L;
/*     */ 
/* 127 */           if (connectionPool != null) {
/* 128 */             numActive = connectionPool.getNumActive();
/* 129 */             numIdle = connectionPool.getNumIdle();
/* 130 */             numPhysical = numActive + numIdle;
/*     */           }
/*     */ 
/* 133 */           objDataSourceRuntime = new DataSourceRuntime();
/* 134 */           objDataSourceRuntime.setNumPhysical(numPhysical);
/* 135 */           objDataSourceRuntime.setNumActive(numActive);
/* 136 */           objDataSourceRuntime.setNumIdle(numIdle);
/* 137 */           objDataSourceRuntime.setDataSource(ds);
/*     */         }
/*     */         finally {
/* 140 */           if (connectionPoolField != null)
/* 141 */             connectionPoolField.setAccessible(false);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 147 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.error"), ex);
/*     */     }
/* 149 */     return objDataSourceRuntime;
/*     */   }
/*     */ 
/*     */   public String[] getAllDataSource()
/*     */   {
/* 158 */     String[] rtn = null;
/*     */     try {
/* 160 */       rtn = (String[])(String[])DataSourceFactory.getDataSource().getURLMap().keySet().toArray(new String[0]);
/*     */     }
/*     */     catch (Exception ex) {
/* 163 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.error"), ex);
/*     */     }
/* 165 */     return rtn;
/*     */   }
/*     */ 
/*     */   public DataSourceSummary[] fetchAllDataSourceConfig()
/*     */   {
/* 173 */     String[] dataSource = getAllDataSource();
/* 174 */     DataSourceSummary[] rtn = new DataSourceSummary[dataSource.length];
/* 175 */     for (int i = 0; i < dataSource.length; ++i) {
/* 176 */       rtn[i] = fetchDataSourceConfig(dataSource[i]);
/*     */     }
/* 178 */     return rtn;
/*     */   }
/*     */ 
/*     */   public DataSourceRuntime[] fetchAllDataSourceRuntime()
/*     */   {
/* 186 */     String[] dataSource = getAllDataSource();
/* 187 */     DataSourceRuntime[] rtn = new DataSourceRuntime[dataSource.length];
/* 188 */     for (int i = 0; i < dataSource.length; ++i) {
/* 189 */       rtn[i] = fetchDataSourceRuntime(dataSource[i]);
/*     */     }
/* 191 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.datasource.DataSourceMonitor
 * JD-Core Version:    0.5.4
 */