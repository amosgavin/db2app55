/*     */ package com.ai.appframe2.complex.mbean.standard.log4j;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.LogManager;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Log4jCategory
/*     */   implements Log4jCategoryMBean
/*     */ {
/*  26 */   private static final HashMap OLD = new HashMap();
/*     */ 
/*     */   public void activateInfo(String category)
/*     */   {
/*  35 */     if ((!OLD.containsKey(category)) && 
/*  36 */       (LogManager.getLogger(category).getLevel() != null)) {
/*  37 */       OLD.put(category, LogManager.getLogger(category).getLevel());
/*     */     }
/*     */ 
/*  40 */     LogManager.getLogger(category).setLevel(Level.INFO);
/*     */   }
/*     */ 
/*     */   public void activateDebug(String category)
/*     */   {
/*  48 */     if ((!OLD.containsKey(category)) && 
/*  49 */       (LogManager.getLogger(category).getLevel() != null)) {
/*  50 */       OLD.put(category, LogManager.getLogger(category).getLevel());
/*     */     }
/*     */ 
/*  53 */     LogManager.getLogger(category).setLevel(Level.DEBUG);
/*     */   }
/*     */ 
/*     */   public void activateWarn(String category)
/*     */   {
/*  61 */     if ((!OLD.containsKey(category)) && 
/*  62 */       (LogManager.getLogger(category).getLevel() != null)) {
/*  63 */       OLD.put(category, LogManager.getLogger(category).getLevel());
/*     */     }
/*     */ 
/*  66 */     LogManager.getLogger(category).setLevel(Level.WARN);
/*     */   }
/*     */ 
/*     */   public void activateError(String category)
/*     */   {
/*  74 */     if ((!OLD.containsKey(category)) && 
/*  75 */       (LogManager.getLogger(category).getLevel() != null)) {
/*  76 */       OLD.put(category, LogManager.getLogger(category).getLevel());
/*     */     }
/*     */ 
/*  79 */     LogManager.getLogger(category).setLevel(Level.ERROR);
/*     */   }
/*     */ 
/*     */   public void activateFatal(String category)
/*     */   {
/*  87 */     if ((!OLD.containsKey(category)) && 
/*  88 */       (LogManager.getLogger(category).getLevel() != null)) {
/*  89 */       OLD.put(category, LogManager.getLogger(category).getLevel());
/*     */     }
/*     */ 
/*  92 */     LogManager.getLogger(category).setLevel(Level.FATAL);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/*  99 */     Set keys = OLD.keySet();
/* 100 */     for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 101 */       String item = (String)iter.next();
/* 102 */       LogManager.getLogger(item).setLevel((Level)OLD.get(item));
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object[] getCurrentLogger() {
/* 107 */     List result = new ArrayList();
/* 108 */     Enumeration loggerEnums = LogManager.getCurrentLoggers();
/*     */ 
/* 111 */     while (loggerEnums.hasMoreElements()) {
/* 112 */       Logger item = (Logger)loggerEnums.nextElement();
/* 113 */       Level level = item.getEffectiveLevel();
/* 114 */       String[] entry = new String[2];
/* 115 */       entry[0] = item.getName();
/* 116 */       entry[1] = level.toString();
/* 117 */       result.add(entry);
/*     */     }
/* 119 */     return (Object[])result.toArray(new Object[0]);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.log4j.Log4jCategory
 * JD-Core Version:    0.5.4
 */