/*     */ package com.ai.appframe2.complex.mbean.registry;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.JMXConfigure;
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBean;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBeans;
/*     */ import com.ai.appframe2.complex.mbean.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jboss.remoting.transporter.TransporterServer;
/*     */ 
/*     */ public class RemoteMBeanRegistryImpl extends AbstractMBeanRegistryImpl
/*     */   implements IMBeanRegistry
/*     */ {
/*  28 */   private static transient Log log = LogFactory.getLog(RemoteMBeanRegistryImpl.class);
/*     */ 
/*  30 */   private static Boolean LOCK = Boolean.FALSE;
/*  31 */   private TransporterServer server = null;
/*     */ 
/*     */   public void registry()
/*     */     throws Exception
/*     */   {
/*  45 */     synchronized (LOCK) {
/*  46 */       if (LOCK.equals(Boolean.FALSE)) {
/*  47 */         if (this.server != null) {
/*  48 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.succeed"));
/*  49 */           return;
/*     */         }
/*     */ 
/*  52 */         String serverName = getServerName();
/*     */ 
/*  54 */         if (StringUtils.isBlank(serverName)) {
/*  55 */           System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.remote_service_error"));
/*  56 */           return;
/*     */         }
/*     */ 
/*  59 */         String enable = JMXConfigure.getProperties().getProperty("jmx.registry.remote." + serverName + ".enable");
/*  60 */         if ((StringUtils.isBlank(enable)) || (!enable.equalsIgnoreCase("true"))) {
/*  61 */           System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.remote_state_close"));
/*  62 */           return;
/*     */         }
/*     */ 
/*  65 */         String locator = JMXConfigure.getProperties().getProperty("jmx.registry.remote." + serverName + ".locator");
/*  66 */         if (StringUtils.isBlank(locator)) {
/*  67 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.remote_locator_empty"));
/*     */         }
/*     */ 
/*  70 */         String file = JMXConfigure.getProperties().getProperty("jmx.registry.remote." + serverName + ".file");
/*  71 */         if (StringUtils.isBlank(file)) {
/*  72 */           throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.remote_file_empty"));
/*     */         }
/*     */ 
/*  75 */         MBean[] objMBean = null;
/*     */         try {
/*  77 */           objMBean = XMLHelper.getInstance(file).getMBeans().getMBeans();
/*     */         }
/*     */         catch (Exception ex) {
/*  80 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.getmbean_error"), ex);
/*  81 */           return;
/*     */         }
/*     */ 
/*  85 */         TransporterServer server = null;
/*     */ 
/*  88 */         if ((objMBean != null) && (objMBean.length != 0)) {
/*  89 */           for (int i = 0; i < objMBean.length; ++i) {
/*     */             try {
/*  91 */               Object object = Class.forName(objMBean[i].getClassname()).newInstance();
/*     */ 
/*  93 */               if ((object != null) && (object instanceof IControl) && (!StringUtils.isBlank(objMBean[i].getEnable())) && (objMBean[i].getEnable().equalsIgnoreCase("true")) && (!StringUtils.isBlank(objMBean[i].getTimeout())))
/*     */               {
/*  98 */                 ((IControl)object).enable(Long.parseLong(objMBean[i].getTimeout()));
/*  99 */                 if (log.isInfoEnabled()) {
/* 100 */                   log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.mbean_enable", new String[] { objMBean[i].getName() }));
/*     */                 }
/*     */               }
/*     */ 
/* 104 */               if ((i == 0) || (server == null)) {
/* 105 */                 server = TransporterServer.createTransporterServer(locator, object, objMBean[i].getInterfacename());
/*     */               }
/*     */               else {
/* 108 */                 server.addHandler(object, objMBean[i].getInterfacename());
/*     */               }
/* 110 */               if (log.isInfoEnabled()) {
/* 111 */                 log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.succeed_info", new String[] { objMBean[i].getName() }));
/*     */               }
/*     */             }
/*     */             catch (Exception ex)
/*     */             {
/* 116 */               log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.failed_info", new String[] { objMBean[i].getName() }), ex);
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 122 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.jmx_security_enabled", new String[] { locator }));
/*     */ 
/* 124 */         LOCK = Boolean.TRUE;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void unregistry()
/*     */     throws Exception
/*     */   {
/* 134 */     if (this.server != null)
/* 135 */       this.server.stop();
/*     */   }
/*     */ 
/*     */   private String getServerName()
/*     */     throws Exception
/*     */   {
/* 146 */     return RuntimeServerUtil.getServerName();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.RemoteMBeanRegistryImpl
 * JD-Core Version:    0.5.4
 */