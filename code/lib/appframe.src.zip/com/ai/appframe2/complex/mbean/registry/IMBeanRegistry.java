package com.ai.appframe2.complex.mbean.registry;

public abstract interface IMBeanRegistry
{
  public abstract void registry()
    throws Exception;

  public abstract void unregistry()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.IMBeanRegistry
 * JD-Core Version:    0.5.4
 */