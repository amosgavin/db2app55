/*    */ package com.ai.appframe2.complex.mbean.registry;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public abstract class AbstractMBeanRegistryImpl
/*    */ {
/* 18 */   private static transient Log log = LogFactory.getLog(AbstractMBeanRegistryImpl.class);
/*    */ 
/*    */   protected boolean isGreaterJava14()
/*    */   {
/* 28 */     boolean rtn = false;
/* 29 */     String javaVersion = System.getProperty("java.specification.version");
/* 30 */     if (javaVersion.equalsIgnoreCase("1.3")) {
/* 31 */       rtn = false;
/*    */     }
/* 33 */     else if (javaVersion.equalsIgnoreCase("1.4")) {
/* 34 */       rtn = false;
/*    */     }
/* 36 */     else if (javaVersion.equalsIgnoreCase("1.5")) {
/* 37 */       rtn = true;
/*    */     }
/*    */     else {
/* 40 */       rtn = true;
/*    */     }
/*    */ 
/* 43 */     if (log.isDebugEnabled()) {
/* 44 */       if (rtn)
/*    */       {
/* 46 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.greaterJava14"));
/*    */       }
/* 48 */       if (!rtn) {
/* 49 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.nogreaterJava14"));
/*    */       }
/*    */     }
/*    */ 
/* 53 */     return rtn;
/*    */   }
/*    */ 
/*    */   protected int getRandomInScope(int min, int max)
/*    */   {
/* 63 */     return 0;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.AbstractMBeanRegistryImpl
 * JD-Core Version:    0.5.4
 */