/*    */ package com.ai.appframe2.complex.mbean.standard.datasource;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DataSourceRuntime
/*    */   implements Serializable
/*    */ {
/*    */   private long numActive;
/*    */   private long numIdle;
/*    */   private long numPhysical;
/*    */   private String dataSource;
/*    */ 
/*    */   public long getNumActive()
/*    */   {
/* 22 */     return this.numActive;
/*    */   }
/*    */   public void setNumActive(long numActive) {
/* 25 */     this.numActive = numActive;
/*    */   }
/*    */   public long getNumIdle() {
/* 28 */     return this.numIdle;
/*    */   }
/*    */   public void setNumIdle(long numIdle) {
/* 31 */     this.numIdle = numIdle;
/*    */   }
/*    */   public long getNumPhysical() {
/* 34 */     return this.numPhysical;
/*    */   }
/*    */   public void setNumPhysical(long numPhysical) {
/* 37 */     this.numPhysical = numPhysical;
/*    */   }
/*    */   public String getDataSource() {
/* 40 */     return this.dataSource;
/*    */   }
/*    */   public void setDataSource(String dataSource) {
/* 43 */     this.dataSource = dataSource;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.datasource.DataSourceRuntime
 * JD-Core Version:    0.5.4
 */