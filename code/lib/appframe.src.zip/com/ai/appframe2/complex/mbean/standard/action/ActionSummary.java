/*     */ package com.ai.appframe2.complex.mbean.standard.action;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class ActionSummary
/*     */   implements Serializable
/*     */ {
/*     */   private long totalCount;
/*     */   private long min;
/*     */   private long failCount;
/*     */   private long successCount;
/*     */   private long avg;
/*     */   private String className;
/*     */   private String methodName;
/*     */   private long totalUseTime;
/*     */   private long max;
/*     */   private long lastUseTime;
/*     */   private long last;
/*     */ 
/*     */   public long getMax()
/*     */   {
/*  30 */     return this.max;
/*     */   }
/*     */ 
/*     */   public void setMax(long max) {
/*  34 */     this.max = max;
/*     */   }
/*     */ 
/*     */   public long getTotalUseTime() {
/*  38 */     return this.totalUseTime;
/*     */   }
/*     */ 
/*     */   public void setTotalUseTime(long totalUseTime) {
/*  42 */     this.totalUseTime = totalUseTime;
/*     */   }
/*     */ 
/*     */   public long getTotalCount() {
/*  46 */     return this.totalCount;
/*     */   }
/*     */ 
/*     */   public void setTotalCount(long totalCount) {
/*  50 */     this.totalCount = totalCount;
/*     */   }
/*     */ 
/*     */   public long getMin() {
/*  54 */     return this.min;
/*     */   }
/*     */ 
/*     */   public void setMin(long min) {
/*  58 */     this.min = min;
/*     */   }
/*     */ 
/*     */   public long getFailCount() {
/*  62 */     return this.failCount;
/*     */   }
/*     */ 
/*     */   public void setFailCount(long failCount) {
/*  66 */     this.failCount = failCount;
/*     */   }
/*     */ 
/*     */   public String getClassName() {
/*  70 */     return this.className;
/*     */   }
/*     */ 
/*     */   public void setClassName(String className) {
/*  74 */     this.className = className;
/*     */   }
/*     */ 
/*     */   public long getSuccessCount() {
/*  78 */     return this.successCount;
/*     */   }
/*     */ 
/*     */   public void setSuccessCount(long successCount) {
/*  82 */     this.successCount = successCount;
/*     */   }
/*     */ 
/*     */   public String getMethodName() {
/*  86 */     return this.methodName;
/*     */   }
/*     */ 
/*     */   public void setMethodName(String methodName) {
/*  90 */     this.methodName = methodName;
/*     */   }
/*     */   public long getAvg() {
/*  93 */     return this.avg;
/*     */   }
/*     */   public void setAvg(long avg) {
/*  96 */     this.avg = avg;
/*     */   }
/*     */   public long getLastUseTime() {
/*  99 */     return this.lastUseTime;
/*     */   }
/*     */   public void setLastUseTime(long lastUseTime) {
/* 102 */     this.lastUseTime = lastUseTime;
/*     */   }
/*     */   public long getLast() {
/* 105 */     return this.last;
/*     */   }
/*     */   public void setLast(long last) {
/* 108 */     this.last = last;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.action.ActionSummary
 * JD-Core Version:    0.5.4
 */