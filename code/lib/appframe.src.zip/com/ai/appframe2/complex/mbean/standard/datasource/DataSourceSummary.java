/*    */ package com.ai.appframe2.complex.mbean.standard.datasource;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DataSourceSummary
/*    */   implements Serializable
/*    */ {
/*    */   private String driverClassName;
/*    */   private String url;
/*    */   private String username;
/*    */   private long maxActive;
/*    */   private long maxIdle;
/*    */   private long minIdle;
/*    */   private long initialSize;
/*    */   private long maxWait;
/*    */   private String dataSource;
/*    */ 
/*    */   public String getDriverClassName()
/*    */   {
/* 28 */     return this.driverClassName;
/*    */   }
/*    */ 
/*    */   public void setDriverClassName(String driverClassName) {
/* 32 */     this.driverClassName = driverClassName;
/*    */   }
/*    */ 
/*    */   public long getMaxActive() {
/* 36 */     return this.maxActive;
/*    */   }
/*    */ 
/*    */   public void setMaxActive(long maxActive) {
/* 40 */     this.maxActive = maxActive;
/*    */   }
/*    */ 
/*    */   public long getMaxIdle() {
/* 44 */     return this.maxIdle;
/*    */   }
/*    */ 
/*    */   public void setMaxIdle(long maxIdle) {
/* 48 */     this.maxIdle = maxIdle;
/*    */   }
/*    */ 
/*    */   public long getMinIdle() {
/* 52 */     return this.minIdle;
/*    */   }
/*    */ 
/*    */   public void setMinIdle(long minIdle) {
/* 56 */     this.minIdle = minIdle;
/*    */   }
/*    */ 
/*    */   public long getInitialSize() {
/* 60 */     return this.initialSize;
/*    */   }
/*    */ 
/*    */   public void setInitialSize(long initialSize) {
/* 64 */     this.initialSize = initialSize;
/*    */   }
/*    */ 
/*    */   public long getMaxWait() {
/* 68 */     return this.maxWait;
/*    */   }
/*    */ 
/*    */   public void setMaxWait(long maxWait) {
/* 72 */     this.maxWait = maxWait;
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 76 */     return this.url;
/*    */   }
/*    */ 
/*    */   public void setUrl(String url) {
/* 80 */     this.url = url;
/*    */   }
/*    */ 
/*    */   public String getUsername() {
/* 84 */     return this.username;
/*    */   }
/*    */ 
/*    */   public void setUsername(String username) {
/* 88 */     this.username = username;
/*    */   }
/*    */   public String getDataSource() {
/* 91 */     return this.dataSource;
/*    */   }
/*    */   public void setDataSource(String dataSource) {
/* 94 */     this.dataSource = dataSource;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.datasource.DataSourceSummary
 * JD-Core Version:    0.5.4
 */