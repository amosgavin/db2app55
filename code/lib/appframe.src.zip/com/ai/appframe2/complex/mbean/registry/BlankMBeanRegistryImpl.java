/*    */ package com.ai.appframe2.complex.mbean.registry;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class BlankMBeanRegistryImpl
/*    */   implements IMBeanRegistry
/*    */ {
/* 19 */   private static transient Log log = LogFactory.getLog(BlankMBeanRegistryImpl.class);
/*    */ 
/*    */   public void registry()
/*    */     throws Exception
/*    */   {
/* 29 */     if (log.isDebugEnabled())
/* 30 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.nothing"));
/*    */   }
/*    */ 
/*    */   public void unregistry()
/*    */     throws Exception
/*    */   {
/* 39 */     if (log.isDebugEnabled())
/* 40 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.unregistry.nothing"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.BlankMBeanRegistryImpl
 * JD-Core Version:    0.5.4
 */