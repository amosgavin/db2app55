/*    */ package com.ai.appframe2.complex.mbean.xml;
/*    */ 
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.commons.digester.Digester;
/*    */ 
/*    */ public class XMLHelper
/*    */ {
/* 20 */   private static XMLHelper instance = null;
/*    */ 
/* 22 */   private static MBeans mbeans = null;
/*    */ 
/* 24 */   private static Boolean isInit = Boolean.FALSE;
/*    */ 
/*    */   public static XMLHelper getInstance(String file)
/*    */     throws Exception
/*    */   {
/* 39 */     if (isInit.equals(Boolean.FALSE)) {
/* 40 */       synchronized (isInit) {
/* 41 */         if (isInit.equals(Boolean.FALSE)) {
/* 42 */           mbeans = createMBeans(file);
/* 43 */           isInit = Boolean.TRUE;
/*    */         }
/*    */       }
/* 46 */       instance = new XMLHelper();
/*    */     }
/* 48 */     return instance;
/*    */   }
/*    */ 
/*    */   public MBeans getMBeans()
/*    */   {
/* 57 */     return mbeans;
/*    */   }
/*    */ 
/*    */   private static MBeans createMBeans(String file)
/*    */     throws Exception
/*    */   {
/* 67 */     MBeans rtn = null;
/* 68 */     InputStream input = Thread.currentThread().getContextClassLoader().getResourceAsStream(file);
/*    */ 
/* 70 */     if (input == null)
/*    */     {
/* 72 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.xml.no_config_file", new String[] { file }));
/*    */     }
/*    */ 
/* 75 */     Digester digester = new Digester();
/* 76 */     digester.setValidating(false);
/* 77 */     digester.addObjectCreate("mbeans", MBeans.class.getName());
/* 78 */     digester.addSetProperties("mbeans");
/*    */ 
/* 80 */     digester.addObjectCreate("mbeans/mbean", MBean.class.getName());
/* 81 */     digester.addSetProperties("mbeans/mbean");
/*    */ 
/* 83 */     digester.addSetNext("mbeans/mbean", "addMBean", MBean.class.getName());
/*    */ 
/* 85 */     rtn = (MBeans)digester.parse(input);
/* 86 */     return rtn;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception
/*    */   {
/* 91 */     MBean[] objMBean = getInstance("system/jmx/mbeans.xml").getMBeans().getMBeans();
/* 92 */     for (int i = 0; i < objMBean.length; ++i) {
/* 93 */       System.out.println(objMBean[i].getClassname());
/* 94 */       System.out.println(objMBean[i].getName());
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.xml.XMLHelper
 * JD-Core Version:    0.5.4
 */