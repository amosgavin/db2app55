/*    */ package com.ai.appframe2.complex.mbean.standard.tm;
/*    */ 
/*    */ import com.ai.appframe2.complex.util.tt.TextTable;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ 
/*    */ public class TransactionMonitor
/*    */   implements TransactionMonitorMBean
/*    */ {
/* 17 */   private static long startCount = 0L;
/* 18 */   private static long commitCount = 0L;
/* 19 */   private static long rollbackCount = 0L;
/* 20 */   private static long suspendCount = 0L;
/* 21 */   private static long resumeCount = 0L;
/*    */ 
/*    */   public static void startIncrease()
/*    */   {
/* 27 */     startCount += 1L;
/*    */   }
/*    */ 
/*    */   public static void commitIncrease() {
/* 31 */     commitCount += 1L;
/*    */   }
/*    */ 
/*    */   public static void rollbackIncrease() {
/* 35 */     rollbackCount += 1L;
/*    */   }
/*    */ 
/*    */   public static void suspendIncrease() {
/* 39 */     suspendCount += 1L;
/*    */   }
/*    */ 
/*    */   public static void resumeIncrease() {
/* 43 */     resumeCount += 1L;
/*    */   }
/*    */ 
/*    */   public String printTmSummary()
/*    */   {
/* 52 */     TextTable objTextTable = new TextTable();
/*    */ 
/* 54 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.start_trans_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.commit_trans_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.rollback_trans_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.suspend_trans_count"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.resume_trans_count") });
/*    */ 
/* 59 */     objTextTable.addRow(new String[] { String.valueOf(startCount), String.valueOf(commitCount), String.valueOf(rollbackCount), String.valueOf(suspendCount), String.valueOf(resumeCount) });
/* 60 */     return objTextTable.draw();
/*    */   }
/*    */ 
/*    */   public TmSummary fetchTmSummary()
/*    */   {
/* 68 */     return new TmSummary(startCount, commitCount, rollbackCount, suspendCount, resumeCount);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.tm.TransactionMonitor
 * JD-Core Version:    0.5.4
 */