package com.ai.appframe2.complex.mbean.standard.ac;

import java.util.List;

public abstract interface AppframeCacheMonitorMBean
{
  public abstract void remove(String paramString, Object paramObject);

  public abstract void remove(String paramString);

  public abstract String[] getTypes();

  public abstract List query(String paramString1, String paramString2);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.ac.AppframeCacheMonitorMBean
 * JD-Core Version:    0.5.4
 */