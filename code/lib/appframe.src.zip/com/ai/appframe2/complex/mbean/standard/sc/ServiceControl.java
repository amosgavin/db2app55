/*    */ package com.ai.appframe2.complex.mbean.standard.sc;
/*    */ 
/*    */ import com.ai.appframe2.complex.service.control.ISrvControl;
/*    */ import com.ai.appframe2.complex.service.control.SrvControlFactory;
/*    */ 
/*    */ public class ServiceControl
/*    */   implements ServiceControlMBean
/*    */ {
/*    */   public void refreshControlData()
/*    */   {
/* 26 */     SrvControlFactory.getSrvControl().refreshControlData();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sc.ServiceControl
 * JD-Core Version:    0.5.4
 */