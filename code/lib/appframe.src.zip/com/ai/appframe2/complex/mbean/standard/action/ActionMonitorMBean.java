package com.ai.appframe2.complex.mbean.standard.action;

import com.ai.appframe2.complex.mbean.standard.IControl;

public abstract interface ActionMonitorMBean extends IControl
{
  public abstract ActionSummary[] fetchActionSummary(String paramString);

  public abstract String printActionSummary(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.action.ActionMonitorMBean
 * JD-Core Version:    0.5.4
 */