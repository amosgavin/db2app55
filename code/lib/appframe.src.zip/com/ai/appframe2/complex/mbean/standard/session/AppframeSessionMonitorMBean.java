package com.ai.appframe2.complex.mbean.standard.session;

import java.util.HashMap;

public abstract interface AppframeSessionMonitorMBean
{
  public abstract HashMap[] fetchLogedUsers();

  public abstract String printLogedUsersSummary();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.session.AppframeSessionMonitorMBean
 * JD-Core Version:    0.5.4
 */