/*    */ package com.ai.appframe2.complex.mbean.standard.ac;
/*    */ 
/*    */ import com.ai.appframe2.common.CacheManager;
/*    */ import com.ai.appframe2.common.SessionManager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AppframeCacheMonitor
/*    */   implements AppframeCacheMonitorMBean
/*    */ {
/*    */   public void remove(String type, Object key)
/*    */   {
/* 25 */     SessionManager.getCacheManager().remove(type, key);
/*    */   }
/*    */ 
/*    */   public void remove(String type) {
/* 29 */     SessionManager.getCacheManager().remove(type);
/*    */   }
/*    */ 
/*    */   public String[] getTypes() {
/* 33 */     return SessionManager.getCacheManager().getTypes();
/*    */   }
/*    */ 
/*    */   public List query(String type, String key) {
/* 37 */     return SessionManager.getCacheManager().query(type, key);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.ac.AppframeCacheMonitor
 * JD-Core Version:    0.5.4
 */