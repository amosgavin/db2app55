package com.ai.appframe2.complex.mbean.standard.tm;

public abstract interface TransactionMonitorMBean
{
  public abstract String printTmSummary();

  public abstract TmSummary fetchTmSummary();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.tm.TransactionMonitorMBean
 * JD-Core Version:    0.5.4
 */