/*     */ package com.ai.appframe2.complex.mbean.standard.sv;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.mbean.standard.sv.log.ISrvLog;
/*     */ import com.ai.appframe2.complex.util.tt.TextTable;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.management.ThreadMXBean;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SVMethodMonitor
/*     */   implements SVMethodMonitorMBean, IControl
/*     */ {
/*  27 */   private static transient Log log = LogFactory.getLog(SVMethodMonitor.class);
/*     */ 
/*  29 */   private static final HashMap map = new HashMap();
/*     */ 
/*  31 */   private static boolean isEnable = false;
/*     */ 
/*  33 */   private static Long endTime = new Long(0L);
/*     */ 
/*  36 */   private static ISrvLog SRV_LOG_INSTANCE = null;
/*     */ 
/*  39 */   public static boolean IS_CPU_TIME = false;
/*     */ 
/*     */   public static void methodInvoke(String className, String methodName, boolean isSuccess, long useTime, long useCpuTime)
/*     */   {
/* 118 */     if ((endTime.longValue() >= 0L) && (System.currentTimeMillis() >= endTime.longValue())) {
/* 119 */       synchronized (endTime) {
/* 120 */         map.clear();
/* 121 */         isEnable = false;
/* 122 */         endTime = new Long(0L);
/*     */       }
/*     */     }
/*     */ 
/* 126 */     if (!isEnable) {
/* 127 */       return;
/*     */     }
/*     */ 
/* 130 */     long last = System.currentTimeMillis();
/*     */ 
/* 132 */     String key = className + "|" + methodName;
/*     */ 
/* 134 */     if (map.containsKey(key)) {
/* 135 */       SVMethodSummary objSVMethodSummary = (SVMethodSummary)map.get(key);
/* 136 */       objSVMethodSummary.setLast(last);
/* 137 */       objSVMethodSummary.setLastUseTime(useTime);
/* 138 */       objSVMethodSummary.setTotalCount(objSVMethodSummary.getTotalCount() + 1L);
/* 139 */       if (useTime < objSVMethodSummary.getMin()) {
/* 140 */         objSVMethodSummary.setMin(useTime);
/*     */       }
/* 142 */       if (useTime > objSVMethodSummary.getMax()) {
/* 143 */         objSVMethodSummary.setMax(useTime);
/*     */       }
/* 145 */       objSVMethodSummary.setTotalUseTime(objSVMethodSummary.getTotalUseTime() + useTime);
/* 146 */       objSVMethodSummary.setAvg(objSVMethodSummary.getTotalUseTime() / objSVMethodSummary.getTotalCount());
/* 147 */       if (isSuccess) {
/* 148 */         objSVMethodSummary.setSuccessCount(objSVMethodSummary.getSuccessCount() + 1L);
/*     */       }
/*     */       else {
/* 151 */         objSVMethodSummary.setFailCount(objSVMethodSummary.getFailCount() + 1L);
/*     */       }
/*     */ 
/* 154 */       if (IS_CPU_TIME) {
/* 155 */         if (useCpuTime < objSVMethodSummary.getMinCpuTime()) {
/* 156 */           objSVMethodSummary.setMinCpuTime(useCpuTime);
/*     */         }
/*     */ 
/* 159 */         if (useCpuTime > objSVMethodSummary.getMaxCpuTime()) {
/* 160 */           objSVMethodSummary.setMaxCpuTime(useCpuTime);
/*     */         }
/*     */ 
/* 163 */         objSVMethodSummary.setTotalCpuTime(objSVMethodSummary.getTotalCpuTime() + useCpuTime);
/* 164 */         objSVMethodSummary.setAvgCpuTime(objSVMethodSummary.getTotalCpuTime() / objSVMethodSummary.getTotalCount());
/* 165 */         objSVMethodSummary.setLastCpuTime(useCpuTime);
/*     */       }
/*     */ 
/* 168 */       map.put(key, objSVMethodSummary);
/*     */     }
/*     */     else {
/* 171 */       SVMethodSummary objSVMethodSummary = new SVMethodSummary();
/* 172 */       objSVMethodSummary.setClassName(className);
/* 173 */       objSVMethodSummary.setMethodName(methodName);
/* 174 */       objSVMethodSummary.setLast(last);
/* 175 */       objSVMethodSummary.setLastUseTime(useTime);
/* 176 */       objSVMethodSummary.setTotalCount(1L);
/* 177 */       objSVMethodSummary.setMin(useTime);
/* 178 */       objSVMethodSummary.setMax(useTime);
/* 179 */       objSVMethodSummary.setAvg(useTime);
/* 180 */       objSVMethodSummary.setTotalUseTime(useTime);
/* 181 */       if (isSuccess) {
/* 182 */         objSVMethodSummary.setSuccessCount(1L);
/* 183 */         objSVMethodSummary.setFailCount(0L);
/*     */       }
/*     */       else {
/* 186 */         objSVMethodSummary.setSuccessCount(0L);
/* 187 */         objSVMethodSummary.setFailCount(1L);
/*     */       }
/*     */ 
/* 190 */       if (IS_CPU_TIME) {
/* 191 */         objSVMethodSummary.setMinCpuTime(useCpuTime);
/* 192 */         objSVMethodSummary.setMaxCpuTime(useCpuTime);
/* 193 */         objSVMethodSummary.setTotalCpuTime(useCpuTime);
/* 194 */         objSVMethodSummary.setAvgCpuTime(useCpuTime);
/* 195 */         objSVMethodSummary.setLastCpuTime(useCpuTime);
/*     */       }
/*     */ 
/* 198 */       map.put(key, objSVMethodSummary);
/*     */     }
/*     */ 
/* 202 */     if (SRV_LOG_INSTANCE != null)
/* 203 */       SRV_LOG_INSTANCE.logSrvInfo(className, methodName, last, isSuccess, useTime, useCpuTime);
/*     */   }
/*     */ 
/*     */   public SVMethodSummary[] fetchSVMethodSummary(String condition)
/*     */   {
/* 213 */     SVMethodSummary[] rtn = null;
/* 214 */     if (StringUtils.isBlank(condition)) {
/* 215 */       rtn = (SVMethodSummary[])(SVMethodSummary[])map.values().toArray(new SVMethodSummary[0]);
/*     */     }
/*     */     else {
/* 218 */       List list = new ArrayList();
/* 219 */       Set keys = map.keySet();
/* 220 */       for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 221 */         String item = (String)iter.next();
/* 222 */         if (item.indexOf(condition) != -1) {
/* 223 */           list.add(map.get(item));
/*     */         }
/*     */       }
/*     */ 
/* 227 */       rtn = (SVMethodSummary[])(SVMethodSummary[])list.toArray(new SVMethodSummary[0]);
/*     */     }
/* 229 */     return rtn;
/*     */   }
/*     */ 
/*     */   public String printSVMethodSummary(String condition)
/*     */   {
/* 238 */     SVMethodSummary[] objSVMethodSummary = fetchSVMethodSummary(condition);
/* 239 */     TextTable objTextTable = new TextTable();
/*     */ 
/* 241 */     String minCpuTime = "minCpuTime";
/* 242 */     String maxCpuTime = "maxCpuTime";
/* 243 */     String avgCpuTime = "avgCpuTime";
/* 244 */     String totalCpuTime = "totalCpuTime";
/* 245 */     String lastCpuTime = "lastCpuTime";
/*     */ 
/* 248 */     objTextTable.setHeader(new String[] { AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.class_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.method_name"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.min_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.max_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.avg_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.success_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.fail_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.total_times"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.total_timecost"), AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.last_access_time"), minCpuTime, maxCpuTime, avgCpuTime, totalCpuTime, lastCpuTime });
/*     */ 
/* 260 */     if (objSVMethodSummary != null) {
/* 261 */       for (int i = 0; i < objSVMethodSummary.length; ++i) {
/* 262 */         objTextTable.addRow(new String[] { objSVMethodSummary[i].getClassName(), objSVMethodSummary[i].getMethodName(), String.valueOf(objSVMethodSummary[i].getMin()), String.valueOf(objSVMethodSummary[i].getMax()), String.valueOf(objSVMethodSummary[i].getAvg()), String.valueOf(objSVMethodSummary[i].getLastUseTime()), String.valueOf(objSVMethodSummary[i].getSuccessCount()), String.valueOf(objSVMethodSummary[i].getFailCount()), String.valueOf(objSVMethodSummary[i].getTotalCount()), String.valueOf(objSVMethodSummary[i].getTotalUseTime()), String.valueOf(objSVMethodSummary[i].getLast()), String.valueOf(objSVMethodSummary[i].getMinCpuTime()), String.valueOf(objSVMethodSummary[i].getMaxCpuTime()), String.valueOf(objSVMethodSummary[i].getAvgCpuTime()), String.valueOf(objSVMethodSummary[i].getTotalCpuTime()), String.valueOf(objSVMethodSummary[i].getLastCpuTime()) });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 281 */     return objTextTable.draw();
/*     */   }
/*     */ 
/*     */   public synchronized void disable()
/*     */   {
/* 288 */     map.clear();
/* 289 */     isEnable = false;
/*     */   }
/*     */ 
/*     */   public synchronized void enable(long seconds)
/*     */   {
/* 297 */     if (seconds < 0L) {
/* 298 */       endTime = new Long(seconds);
/*     */     }
/*     */     else {
/* 301 */       endTime = new Long(System.currentTimeMillis() + seconds * 1000L);
/*     */     }
/* 303 */     isEnable = true;
/*     */   }
/*     */ 
/*     */   public boolean fetchStatus()
/*     */   {
/* 311 */     return isEnable;
/*     */   }
/*     */ 
/*     */   public static boolean isEnable()
/*     */   {
/* 319 */     return isEnable;
/*     */   }
/*     */ 
/*     */   public static long getCurrentThreadCpuTime()
/*     */   {
/* 327 */     if (IS_CPU_TIME) {
/* 328 */       return ManagementFactory.getThreadMXBean().getCurrentThreadCpuTime();
/*     */     }
/*     */ 
/* 331 */     return 0L;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  44 */       String strSrvLogImplClass = AIConfigManager.getConfigItem("SRVLOG_IMPL_CLASS");
/*  45 */       if (!StringUtils.isBlank(strSrvLogImplClass)) {
/*     */         try {
/*  47 */           Object custObject = Class.forName(strSrvLogImplClass.trim()).newInstance();
/*  48 */           if (custObject instanceof ISrvLog) {
/*  49 */             SRV_LOG_INSTANCE = (ISrvLog)custObject;
/*     */           }
/*     */           else
/*  52 */             SRV_LOG_INSTANCE = null;
/*     */         }
/*     */         catch (Throwable ex)
/*     */         {
/*  56 */           SRV_LOG_INSTANCE = null;
/*  57 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.error"), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*  62 */         SRV_LOG_INSTANCE = null;
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  66 */       SRV_LOG_INSTANCE = null;
/*  67 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.error"), ex);
/*     */     }
/*     */     finally {
/*  70 */       if (SRV_LOG_INSTANCE != null) {
/*  71 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.srvlogenable", new String[] { SRV_LOG_INSTANCE.toString() }));
/*     */       }
/*     */       else {
/*  74 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.srvlogdisable"));
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  80 */       String strCputTimeSupport = AIConfigManager.getConfigItem("CPU_TIME_SUPPORT");
/*  81 */       if (!StringUtils.isBlank(strCputTimeSupport)) {
/*  82 */         if (strCputTimeSupport.trim().equalsIgnoreCase("true")) {
/*  83 */           ThreadMXBean objThreadMXBean = ManagementFactory.getThreadMXBean();
/*  84 */           if ((objThreadMXBean.isThreadCpuTimeSupported()) && (objThreadMXBean.isThreadCpuTimeEnabled()))
/*  85 */             IS_CPU_TIME = true;
/*     */         }
/*     */         else
/*     */         {
/*  89 */           IS_CPU_TIME = false;
/*     */         }
/*     */       }
/*     */       else {
/*  93 */         ThreadMXBean objThreadMXBean = ManagementFactory.getThreadMXBean();
/*  94 */         if ((objThreadMXBean.isThreadCpuTimeSupported()) && (objThreadMXBean.isThreadCpuTimeEnabled()))
/*  95 */           IS_CPU_TIME = true;
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 100 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.standard.sv.srvlog.check_enabled"), ex);
/* 101 */       IS_CPU_TIME = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.sv.SVMethodMonitor
 * JD-Core Version:    0.5.4
 */