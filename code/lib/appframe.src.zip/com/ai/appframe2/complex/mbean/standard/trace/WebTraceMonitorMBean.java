package com.ai.appframe2.complex.mbean.standard.trace;

public abstract interface WebTraceMonitorMBean
{
  public abstract boolean isEnable();

  public abstract void enable(String paramString1, String paramString2, String paramString3, int paramInt);

  public abstract void disable();

  public abstract String getCode();

  public abstract String getUrl();

  public abstract String getClientIp();

  public abstract int getDuration();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.trace.WebTraceMonitorMBean
 * JD-Core Version:    0.5.4
 */