/*    */ package com.ai.appframe2.complex.mbean.standard.tm;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TmCurrentDetail
/*    */   implements Serializable
/*    */ {
/*    */   private String threadName;
/*    */   private long startTime;
/*    */   private String txType;
/*    */   private String[] relateDataSource;
/*    */   private String txId;
/*    */ 
/*    */   public String getThreadName()
/*    */   {
/* 24 */     return this.threadName;
/*    */   }
/*    */ 
/*    */   public void setThreadName(String threadName) {
/* 28 */     this.threadName = threadName;
/*    */   }
/*    */ 
/*    */   public long getStartTime() {
/* 32 */     return this.startTime;
/*    */   }
/*    */ 
/*    */   public void setStartTime(long startTime) {
/* 36 */     this.startTime = startTime;
/*    */   }
/*    */ 
/*    */   public String getTxType() {
/* 40 */     return this.txType;
/*    */   }
/*    */ 
/*    */   public void setTxType(String txType) {
/* 44 */     this.txType = txType;
/*    */   }
/*    */ 
/*    */   public String[] getRelateDataSource() {
/* 48 */     return this.relateDataSource;
/*    */   }
/*    */ 
/*    */   public void setRelateDataSource(String[] relateDataSource) {
/* 52 */     this.relateDataSource = relateDataSource;
/*    */   }
/*    */   public String getTxId() {
/* 55 */     return this.txId;
/*    */   }
/*    */   public void setTxId(String txId) {
/* 58 */     this.txId = txId;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.tm.TmCurrentDetail
 * JD-Core Version:    0.5.4
 */