/*     */ package com.ai.appframe2.complex.mbean.registry;
/*     */ 
/*     */ import com.ai.appframe2.complex.mbean.JMXConfigure;
/*     */ import com.ai.appframe2.complex.mbean.standard.IControl;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBean;
/*     */ import com.ai.appframe2.complex.mbean.xml.MBeans;
/*     */ import com.ai.appframe2.complex.mbean.xml.XMLHelper;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectInstance;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class Was61MBeanRegistryImpl extends AbstractMBeanRegistryImpl
/*     */   implements IMBeanRegistry
/*     */ {
/*  31 */   private static transient Log log = LogFactory.getLog(Was61MBeanRegistryImpl.class);
/*     */ 
/*  33 */   private HashMap map = new HashMap();
/*  34 */   private boolean isSuccess = false;
/*     */ 
/*     */   public void registry()
/*     */     throws Exception
/*     */   {
/*  48 */     if (this.isSuccess) {
/*  49 */       log.info("Have registered successfully.");
/*  50 */       return;
/*     */     }
/*     */ 
/*  53 */     MBean[] objMBean = null;
/*     */     try {
/*  55 */       objMBean = XMLHelper.getInstance(JMXConfigure.getProperties().getProperty("jmx.registry.was61.file")).getMBeans().getMBeans();
/*     */     }
/*     */     catch (Exception ex) {
/*  58 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.getmbean_error"), ex);
/*  59 */       return;
/*     */     }
/*     */ 
/*  63 */     MBeanServer objMBeanServer = null;
/*     */     try {
/*  65 */       objMBeanServer = getMBeanServer();
/*     */     }
/*     */     catch (Exception ex) {
/*  68 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.mbeanserver_error"), ex);
/*     */     }
/*     */ 
/*  73 */     Object memoryMXBean = getMemoryMXBean();
/*  74 */     ObjectInstance memoryMXBeanInstance = objMBeanServer.registerMBean(memoryMXBean, new ObjectName("java.lang:type=Memory"));
/*  75 */     this.map.put(memoryMXBeanInstance.getObjectName(), memoryMXBean);
/*     */ 
/*  78 */     Object threadMXBean = getThreadMXBean();
/*  79 */     ObjectInstance threadMXBeanInstance = objMBeanServer.registerMBean(threadMXBean, new ObjectName("java.lang:type=Threading"));
/*  80 */     this.map.put(threadMXBeanInstance.getObjectName(), threadMXBean);
/*     */ 
/*  84 */     if ((objMBean != null) && (objMBean.length != 0)) {
/*  85 */       for (int i = 0; i < objMBean.length; ++i) {
/*     */         try {
/*  87 */           ObjectName name = new ObjectName(objMBean[i].getName().trim());
/*     */ 
/*  89 */           Object object = Class.forName(objMBean[i].getClassname()).newInstance();
/*     */ 
/*  91 */           if ((object != null) && (object instanceof IControl) && (!StringUtils.isBlank(objMBean[i].getEnable())) && (objMBean[i].getEnable().equalsIgnoreCase("true")) && (!StringUtils.isBlank(objMBean[i].getTimeout())))
/*     */           {
/*  96 */             ((IControl)object).enable(Long.parseLong(objMBean[i].getTimeout()));
/*  97 */             if (log.isInfoEnabled()) {
/*  98 */               log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.mbean_enable", new String[] { objMBean[i].getName() }));
/*     */             }
/*     */           }
/*     */ 
/* 102 */           ObjectInstance objObjectInstance = objMBeanServer.registerMBean(object, name);
/* 103 */           this.map.put(objObjectInstance.getObjectName(), object);
/*     */ 
/* 105 */           if (log.isInfoEnabled())
/* 106 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.succeed_info", new String[] { objMBean[i].getName() }));
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 110 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.registry.failed_info", new String[] { objMBean[i].getName() }), ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 117 */     this.isSuccess = true;
/*     */   }
/*     */ 
/*     */   public void unregistry()
/*     */     throws Exception
/*     */   {
/*     */     MBeanServer objMBeanServer;
/*     */     Iterator iter;
/* 125 */     if ((this.isSuccess) && 
/* 126 */       (!this.map.isEmpty())) {
/* 127 */       Set keys = this.map.keySet();
/* 128 */       objMBeanServer = getMBeanServer();
/* 129 */       for (iter = keys.iterator(); iter.hasNext(); ) {
/* 130 */         ObjectName item = (ObjectName)iter.next();
/*     */ 
/* 132 */         Object object = this.map.get(item);
/* 133 */         if ((object != null) && (object instanceof IControl)) {
/* 134 */           ((IControl)object).disable();
/* 135 */           if (log.isInfoEnabled()) {
/* 136 */             log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.unregistry.disable", new String[] { item.toString() }));
/*     */           }
/*     */         }
/*     */ 
/* 140 */         objMBeanServer.unregisterMBean(item);
/* 141 */         if (log.isInfoEnabled()) {
/* 142 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.mbean.unregistry.succeed", new String[] { item.toString() }));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 147 */     this.map.clear();
/* 148 */     this.isSuccess = false;
/*     */   }
/*     */ 
/*     */   private MBeanServer getMBeanServer()
/*     */     throws Exception
/*     */   {
/* 157 */     Class AdminServiceFactory = Class.forName("com.ibm.websphere.management.AdminServiceFactory");
/* 158 */     Method getMBeanFactory = AdminServiceFactory.getMethod("getMBeanFactory", new Class[0]);
/* 159 */     Object mbeanFactory = getMBeanFactory.invoke(null, new Object[0]);
/*     */ 
/* 161 */     Method getMBeanServer = mbeanFactory.getClass().getMethod("getMBeanServer", new Class[0]);
/* 162 */     return (MBeanServer)getMBeanServer.invoke(mbeanFactory, new Object[0]);
/*     */   }
/*     */ 
/*     */   private Object getMemoryMXBean()
/*     */     throws Exception
/*     */   {
/* 171 */     Class ManagementFactory = Class.forName("java.lang.management.ManagementFactory");
/* 172 */     Method getMemoryMXBean = ManagementFactory.getMethod("getMemoryMXBean", new Class[0]);
/* 173 */     return getMemoryMXBean.invoke(null, new Object[0]);
/*     */   }
/*     */ 
/*     */   private Object getThreadMXBean()
/*     */     throws Exception
/*     */   {
/* 182 */     Class ManagementFactory = Class.forName("java.lang.management.ManagementFactory");
/* 183 */     Method getThreadMXBean = ManagementFactory.getMethod("getThreadMXBean", new Class[0]);
/* 184 */     return getThreadMXBean.invoke(null, new Object[0]);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.registry.Was61MBeanRegistryImpl
 * JD-Core Version:    0.5.4
 */