package com.ai.appframe2.complex.mbean.standard.cc;

import java.util.Map;

public abstract interface ClientControlMBean
{
  public abstract void reconnect()
    throws Exception;

  public abstract void connect(String paramString)
    throws Exception;

  public abstract Map listGroups()
    throws Exception;

  public abstract String getCurrentAppCluster()
    throws Exception;

  public abstract String getOldAppCluster()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.mbean.standard.cc.ClientControlMBean
 * JD-Core Version:    0.5.4
 */