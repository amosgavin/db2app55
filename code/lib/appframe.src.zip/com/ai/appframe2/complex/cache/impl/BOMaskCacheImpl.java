/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.bo.IBOMask;
/*    */ import com.ai.appframe2.complex.self.po.BOMask;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class BOMaskCacheImpl extends AbstractCache
/*    */ {
/* 25 */   private static transient Log log = LogFactory.getLog(BOMaskCacheImpl.class);
/*    */   public static final String SPLIT_CHAR = "^";
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 38 */     HashMap map = new HashMap();
/*    */ 
/* 40 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/*    */ 
/* 42 */     BOMask[] objBOMask = objIBaseSV.getAllBOMask();
/* 43 */     for (int i = 0; i < objBOMask.length; ++i)
/*    */     {
/* 45 */       map.put(objBOMask[i].getBoName(), objBOMask[i].getBoName());
/*    */ 
/* 47 */       if (StringUtils.isBlank(objBOMask[i].getMaskFunctionClass())) continue;
/*    */       try {
/* 49 */         IBOMask objIBOMask = (IBOMask)Class.forName(objBOMask[i].getMaskFunctionClass().trim()).newInstance();
/* 50 */         map.put(objBOMask[i].getBoName() + "^" + objBOMask[i].getAttrName(), objIBOMask);
/*    */       }
/*    */       catch (Throwable ex) {
/* 53 */         log.error("load bo mask cache error", ex);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 58 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.BOMaskCacheImpl
 * JD-Core Version:    0.5.4
 */