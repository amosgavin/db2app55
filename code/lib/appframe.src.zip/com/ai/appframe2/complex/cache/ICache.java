package com.ai.appframe2.complex.cache;

import java.util.HashMap;

public abstract interface ICache
{
  public abstract void refresh()
    throws Exception;

  public abstract Object getObject(Object paramObject)
    throws Exception;

  public abstract boolean containsKey(Object paramObject)
    throws Exception;

  public abstract HashMap getAll()
    throws Exception;

  public abstract boolean isCacheLoaded();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.ICache
 * JD-Core Version:    0.5.4
 */