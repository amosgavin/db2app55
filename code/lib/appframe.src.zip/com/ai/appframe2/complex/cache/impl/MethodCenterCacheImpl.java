/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.MethodCenter;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class MethodCenterCacheImpl extends AbstractCache
/*    */ {
/* 25 */   private static transient Log log = LogFactory.getLog(MethodCenterCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 37 */     HashMap map = new HashMap();
/* 38 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/* 39 */     MethodCenter[] objMethodCenter = objIBaseSV.getAllMethodCenter();
/* 40 */     for (int i = 0; i < objMethodCenter.length; ++i) {
/* 41 */       String key = getKey(objMethodCenter[i]);
/* 42 */       if (!map.containsKey(key)) {
/* 43 */         map.put(key, objMethodCenter[i]);
/*    */       }
/*    */       else {
/* 46 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.conflict_key"));
/*    */       }
/*    */     }
/*    */ 
/* 50 */     return map;
/*    */   }
/*    */ 
/*    */   private static String getKey(MethodCenter objMethodCenter)
/*    */   {
/* 59 */     return objMethodCenter.getServiceImplClassName() + "." + objMethodCenter.getMethodName() + "." + objMethodCenter.getParameterCount();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.MethodCenterCacheImpl
 * JD-Core Version:    0.5.4
 */