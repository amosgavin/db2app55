/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.TableSplitMapping;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TableSplitMappingCacheImpl extends AbstractCache
/*    */ {
/* 25 */   private static transient Log log = LogFactory.getLog(TableSplitMappingCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 37 */     HashMap map = new HashMap();
/*    */ 
/* 39 */     HashMap tmp = new HashMap();
/* 40 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/*    */ 
/* 42 */     TableSplitMapping[] objTableSplitMapping = objIBaseSV.getAllTableSplitMapping();
/* 43 */     for (int i = 0; i < objTableSplitMapping.length; ++i) {
/* 44 */       if (tmp.containsKey(objTableSplitMapping[i].getTableName())) {
/* 45 */         List list = (List)tmp.get(objTableSplitMapping[i].getTableName());
/* 46 */         list.add(objTableSplitMapping[i]);
/* 47 */         tmp.put(objTableSplitMapping[i].getTableName(), list);
/*    */       }
/*    */       else {
/* 50 */         List list = new ArrayList();
/* 51 */         list.add(objTableSplitMapping[i]);
/* 52 */         tmp.put(objTableSplitMapping[i].getTableName(), list);
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 57 */     Set keys = tmp.keySet();
/* 58 */     for (Iterator iter = keys.iterator(); iter.hasNext(); ) {
/* 59 */       String item = (String)iter.next();
/* 60 */       TableSplitMapping[] obj = (TableSplitMapping[])(TableSplitMapping[])((List)tmp.get(item)).toArray(new TableSplitMapping[0]);
/* 61 */       map.put(item, obj);
/*    */     }
/*    */ 
/* 64 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.TableSplitMappingCacheImpl
 * JD-Core Version:    0.5.4
 */