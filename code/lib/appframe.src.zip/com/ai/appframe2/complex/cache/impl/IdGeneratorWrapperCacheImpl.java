/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class IdGeneratorWrapperCacheImpl extends AbstractCache
/*    */ {
/* 24 */   private static transient Log log = LogFactory.getLog(IdGeneratorWrapperCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 36 */     HashMap map = new HashMap();
/*    */ 
/* 38 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/* 39 */     IdGeneratorWrapperBean[] objIdGeneratorWrapperBean = objIBaseSV.getAllIdGeneratorWrapper();
/*    */     try
/*    */     {
/* 42 */       for (int i = 0; i < objIdGeneratorWrapperBean.length; ++i) {
/* 43 */         String tableWrapperImpl = objIdGeneratorWrapperBean[i].getTableSeqWrapperImpl();
/* 44 */         String hisTableWrapperImpl = objIdGeneratorWrapperBean[i].getHisTableSeqWrapperImpl();
/*    */ 
/* 46 */         Object tableWrapperObject = null;
/* 47 */         if (!StringUtils.isBlank(tableWrapperImpl)) {
/* 48 */           tableWrapperObject = Class.forName(tableWrapperImpl).newInstance();
/*    */         }
/* 50 */         objIdGeneratorWrapperBean[i].setTableSeqWrapperObj(tableWrapperObject);
/*    */ 
/* 52 */         Object hisTableWrapperObject = null;
/* 53 */         if (!StringUtils.isBlank(hisTableWrapperImpl)) {
/* 54 */           hisTableWrapperObject = Class.forName(hisTableWrapperImpl).newInstance();
/*    */         }
/* 56 */         objIdGeneratorWrapperBean[i].setHisTableSeqWrapperObj(hisTableWrapperObject);
/*    */ 
/* 58 */         map.put(objIdGeneratorWrapperBean[i].getTableName(), objIdGeneratorWrapperBean[i]);
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 62 */       log.error("Load IdGeneratorWrapperCacheImpl Exception", ex);
/*    */     }
/*    */ 
/* 65 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.IdGeneratorWrapperCacheImpl
 * JD-Core Version:    0.5.4
 */