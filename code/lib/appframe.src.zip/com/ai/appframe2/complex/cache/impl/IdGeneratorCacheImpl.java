/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.IdGeneratorBean;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class IdGeneratorCacheImpl extends AbstractCache
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(IdGeneratorCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 35 */     HashMap map = new HashMap();
/*    */ 
/* 37 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/*    */ 
/* 39 */     IdGeneratorBean[] objIdGeneratorBean = objIBaseSV.getAllIdGenerator();
/* 40 */     for (int i = 0; i < objIdGeneratorBean.length; ++i) {
/* 41 */       map.put(objIdGeneratorBean[i].getTableName(), objIdGeneratorBean[i]);
/*    */     }
/*    */ 
/* 44 */     if (log.isDebugEnabled()) {
/* 45 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.load_id_succeed"));
/*    */     }
/*    */ 
/* 48 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.IdGeneratorCacheImpl
 * JD-Core Version:    0.5.4
 */