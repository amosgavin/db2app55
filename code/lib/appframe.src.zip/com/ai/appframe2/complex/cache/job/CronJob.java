/*    */ package com.ai.appframe2.complex.cache.job;
/*    */ 
/*    */ import com.ai.appframe2.complex.cache.ICache;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.quartz.Job;
/*    */ import org.quartz.JobDataMap;
/*    */ import org.quartz.JobDetail;
/*    */ import org.quartz.JobExecutionContext;
/*    */ import org.quartz.JobExecutionException;
/*    */ 
/*    */ public class CronJob
/*    */   implements Job
/*    */ {
/* 24 */   private static transient Log log = LogFactory.getLog(CronJob.class);
/*    */ 
/*    */   public void execute(JobExecutionContext jobExecutionContext)
/*    */     throws JobExecutionException
/*    */   {
/*    */     try
/*    */     {
/* 37 */       JobDataMap data = jobExecutionContext.getJobDetail().getJobDataMap();
/* 38 */       ICache cache = (ICache)data.get("SCHEDULER_VAR");
/* 39 */       if (cache.isCacheLoaded()) {
/* 40 */         cache.refresh();
/* 41 */         if (log.isInfoEnabled()) {
/* 42 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.job.refresh.succeed", new String[] { cache.getClass().getName() }));
/*    */         }
/*    */ 
/*    */       }
/* 46 */       else if (log.isInfoEnabled())
/*    */       {
/* 48 */         log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.job.noload_cache_nothing", new String[] { cache.getClass().getName() }));
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 53 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.job.refresh.failed"), ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.job.CronJob
 * JD-Core Version:    0.5.4
 */