/*     */ package com.ai.appframe2.complex.cache.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.cache.ICache;
/*     */ import com.ai.appframe2.complex.mbean.standard.cache.CacheMonitor;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public abstract class AbstractCache
/*     */   implements ICache
/*     */ {
/*  21 */   private static transient Log log = LogFactory.getLog(AbstractCache.class);
/*     */ 
/*  23 */   private HashMap cache = new HashMap();
/*  24 */   private Long COUNT = new Long(0L);
/*  25 */   private Boolean LOCK = Boolean.FALSE;
/*     */ 
/*  28 */   private Boolean FIRST_INIT = Boolean.FALSE;
/*     */ 
/*     */   public void refresh()
/*     */     throws Exception
/*     */   {
/*  38 */     long tmp = this.COUNT.longValue();
/*  39 */     if (tmp == this.COUNT.longValue())
/*  40 */       synchronized (this.COUNT) {
/*  41 */         if (tmp == this.COUNT.longValue()) {
/*  42 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.start_info", new String[] { super.getClass().getName() }));
/*     */ 
/*  44 */           long startTime = System.currentTimeMillis();
/*  45 */           long oldCount = this.cache.size();
/*     */ 
/*  48 */           HashMap map = getData();
/*     */ 
/*  52 */           this.LOCK = Boolean.TRUE;
/*  53 */           this.cache.clear();
/*  54 */           this.cache.putAll(map);
/*  55 */           this.COUNT = new Long(this.COUNT.longValue() + 1L);
/*  56 */           this.LOCK = Boolean.FALSE;
/*  57 */           this.FIRST_INIT = Boolean.TRUE;
/*  58 */           map.clear();
/*  59 */           map = null;
/*     */ 
/*  61 */           long newCount = this.cache.size();
/*  62 */           CacheMonitor.refreshInvoke(super.getClass(), oldCount, newCount, startTime, System.currentTimeMillis());
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   public Object getObject(Object key)
/*     */     throws Exception
/*     */   {
/*  75 */     if (this.FIRST_INIT.equals(Boolean.FALSE)) {
/*  76 */       if (log.isDebugEnabled()) {
/*  77 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.load_info", new String[] { super.getClass().toString() }));
/*     */       }
/*  79 */       refresh();
/*     */     }
/*     */ 
/*  82 */     if (this.LOCK.equals(Boolean.TRUE))
/*     */     {
/*  84 */       int i = 0;
/*     */       while (true) { if (!this.LOCK.equals(Boolean.TRUE)) break label107;
/*  86 */         if (i >= 50) break;
/*  87 */         Thread.currentThread(); Thread.sleep(100L);
/*     */ 
/*  89 */         ++i; }
/*     */ 
/*     */ 
/*  92 */       return null;
/*     */     }
/*     */ 
/*  97 */     label107: return this.cache.get(key);
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */     throws Exception
/*     */   {
/* 107 */     if (this.FIRST_INIT.equals(Boolean.FALSE)) {
/* 108 */       refresh();
/*     */     }
/*     */ 
/* 111 */     if (this.LOCK.equals(Boolean.TRUE))
/*     */     {
/* 113 */       int i = 0;
/*     */       while (true) { if (!this.LOCK.equals(Boolean.TRUE)) break label69;
/* 115 */         if (i >= 50) break;
/* 116 */         Thread.currentThread(); Thread.sleep(100L);
/*     */ 
/* 118 */         ++i; }
/*     */ 
/*     */ 
/* 121 */       return false;
/*     */     }
/*     */ 
/* 126 */     label69: return this.cache.containsKey(key);
/*     */   }
/*     */ 
/*     */   public HashMap getAll()
/*     */     throws Exception
/*     */   {
/* 135 */     if (this.FIRST_INIT.equals(Boolean.FALSE)) {
/* 136 */       refresh();
/*     */     }
/* 138 */     return this.cache;
/*     */   }
/*     */ 
/*     */   public boolean isCacheLoaded()
/*     */   {
/* 149 */     return this.FIRST_INIT.booleanValue();
/*     */   }
/*     */ 
/*     */   public abstract HashMap getData()
/*     */     throws Exception;
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.AbstractCache
 * JD-Core Version:    0.5.4
 */