/*     */ package com.ai.appframe2.complex.cache.impl;
/*     */ 
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Field;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.dbcp.BasicDataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.pool.impl.GenericObjectPool;
/*     */ 
/*     */ public class SysDateCacheImpl extends AbstractCache
/*     */ {
/*  31 */   private static transient Log log = LogFactory.getLog(SysDateCacheImpl.class);
/*     */   public static final long MAX_DIFF_DATE = -99999999L;
/*  36 */   private static boolean IS_FIRST_LOAD = true;
/*     */ 
/*     */   public HashMap getData()
/*     */     throws Exception
/*     */   {
/*  48 */     HashMap map = new HashMap();
/*     */     Iterator iter;
/*  51 */     if (IS_FIRST_LOAD) {
/*  52 */       HashMap urlMap = DataSourceFactory.getDataSource().getURLMap();
/*  53 */       Set key = urlMap.keySet();
/*  54 */       for (Iterator iter = key.iterator(); iter.hasNext(); ) {
/*  55 */         String pool = (String)iter.next();
/*     */         try {
/*  57 */           Long diff = new Long(diff(pool));
/*  58 */           map.put(pool, diff);
/*  59 */           if (log.isDebugEnabled())
/*     */           {
/*  61 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.host_db_diff_time", new String[] { pool, diff + "" }));
/*     */           }
/*     */         }
/*     */         catch (Exception ex) {
/*  65 */           map.put(pool, new Long(0L));
/*     */ 
/*  67 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.host_db_time_error", new String[] { pool }), ex);
/*     */         }
/*     */       }
/*     */ 
/*  71 */       IS_FIRST_LOAD = false;
/*     */     }
/*     */     else
/*     */     {
/*  75 */       HashMap urlMap = DataSourceFactory.getDataSource().getURLMap();
/*  76 */       Set key = urlMap.keySet();
/*  77 */       for (iter = key.iterator(); iter.hasNext(); ) {
/*  78 */         String pool = (String)iter.next();
/*  79 */         if (isNeedSyncDbDate(pool)) {
/*     */           try {
/*  81 */             Long diff = new Long(diff(pool));
/*  82 */             map.put(pool, new Long(diff(pool)));
/*  83 */             if (log.isDebugEnabled())
/*  84 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.host_db_diff_time", new String[] { pool, diff + "" }));
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/*  88 */             map.put(pool, new Long(0L));
/*  89 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.host_db_time_error", new String[] { pool }), ex);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/*  94 */           map.put(pool, new Long(0L));
/*  95 */           if (log.isDebugEnabled()) {
/*  96 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.ds_synchronize_nothing", new String[] { pool }));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 103 */     return map;
/*     */   }
/*     */ 
/*     */   private long diff(String ds)
/*     */     throws Exception
/*     */   {
/* 113 */     long rtn = 0L;
/* 114 */     Connection conn = null;
/*     */     try {
/* 116 */       conn = ServiceManager.getSession().getConnection(ds);
/* 117 */       long hostTime = System.currentTimeMillis();
/* 118 */       Timestamp result = new Timestamp(DialectFactory.getDialect().getSysDate(conn));
/* 119 */       rtn = result.getTime() - hostTime;
/*     */ 
/* 122 */       if ((rtn >= 600000L) || (rtn <= -600000L)) {
/* 123 */         System.out.println("=============================");
/* 124 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.sys_db_diff_time", new String[] { ds, rtn + "" }));
/* 125 */         System.out.println(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.gettime_bydb"));
/* 126 */         System.out.println("=============================");
/* 127 */         rtn = -99999999L;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 135 */       if ((conn != null) && (!conn.isClosed())) {
/* 136 */         conn.close();
/*     */       }
/*     */     }
/* 139 */     return rtn;
/*     */   }
/*     */ 
/*     */   private boolean isNeedSyncDbDate(String ds)
/*     */   {
/* 151 */     boolean rtn = true;
/*     */     try {
/* 153 */       BasicDataSource objBasicDataSource = (BasicDataSource)DataSourceFactory.getDataSource().getDataSource(ds);
/*     */ 
/* 155 */       if (objBasicDataSource != null) {
/* 156 */         Field connectionPoolField = null;
/*     */         try {
/* 158 */           connectionPoolField = BasicDataSource.class.getDeclaredField("connectionPool");
/* 159 */           connectionPoolField.setAccessible(true);
/* 160 */           GenericObjectPool connectionPool = (GenericObjectPool)connectionPoolField.get(objBasicDataSource);
/*     */ 
/* 162 */           long numActive = connectionPool.getNumActive();
/* 163 */           long numIdle = connectionPool.getNumIdle();
/*     */ 
/* 165 */           if ((numActive == 0L) && (numIdle == 0L))
/* 166 */             rtn = false;
/*     */         }
/*     */         finally
/*     */         {
/* 170 */           if (connectionPoolField != null)
/* 171 */             connectionPoolField.setAccessible(false);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 177 */       log.error("Error:", ex);
/*     */     }
/* 179 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.SysDateCacheImpl
 * JD-Core Version:    0.5.4
 */