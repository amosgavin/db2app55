/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.TableSplit;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class TableSplitCacheImpl extends AbstractCache
/*    */ {
/* 22 */   private static transient Log log = LogFactory.getLog(TableSplitCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 34 */     HashMap map = new HashMap();
/* 35 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/* 36 */     TableSplit[] objTableSplit = objIBaseSV.getAllTableSplit();
/* 37 */     for (int i = 0; i < objTableSplit.length; ++i) {
/* 38 */       map.put(objTableSplit[i].getTableName(), objTableSplit[i]);
/*    */     }
/* 40 */     if (log.isDebugEnabled()) {
/* 41 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.load_sub_table_complete"));
/*    */     }
/*    */ 
/* 44 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.TableSplitCacheImpl
 * JD-Core Version:    0.5.4
 */