/*     */ package com.ai.appframe2.complex.cache;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.complex.cache.job.CronJob;
/*     */ import com.ai.appframe2.complex.util.collection.UnmodifiableHashMap;
/*     */ import com.ai.appframe2.complex.xml.XMLHelper;
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Cache;
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Caches;
/*     */ import com.ai.appframe2.complex.xml.cfg.caches.Quartz;
/*     */ import com.ai.appframe2.complex.xml.cfg.defaults.Property;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.quartz.CronTrigger;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.SchedulerFactory;
/*     */ import org.quartz.Trigger;
/*     */ import org.quartz.impl.StdSchedulerFactory;
/*     */ 
/*     */ public final class CacheFactory
/*     */ {
/*  38 */   private static transient Log log = LogFactory.getLog(CacheFactory.class);
/*     */   public static final String SCHEDULER_VAR = "SCHEDULER_VAR";
/*  42 */   private static final HashMap INSTANCE = new HashMap();
/*     */ 
/*  44 */   private static boolean IS_READONLY = false;
/*     */ 
/*     */   public static Object get(Class clazz, Object key)
/*     */     throws Exception
/*     */   {
/* 162 */     ICache cacheInstance = (ICache)INSTANCE.get(clazz);
/* 163 */     if (cacheInstance == null)
/*     */     {
/* 165 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.no_cache", new String[] { clazz.getName() }));
/*     */     }
/* 167 */     return cacheInstance.getObject(key);
/*     */   }
/*     */ 
/*     */   public static boolean containsKey(Class clazz, Object key)
/*     */     throws Exception
/*     */   {
/* 178 */     ICache cacheInstance = (ICache)INSTANCE.get(clazz);
/* 179 */     if (cacheInstance == null)
/*     */     {
/* 181 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.no_cache", new String[] { clazz.getName() }));
/*     */     }
/* 183 */     return cacheInstance.containsKey(key);
/*     */   }
/*     */ 
/*     */   public static HashMap getAll(Class clazz)
/*     */     throws Exception
/*     */   {
/* 193 */     ICache cacheInstance = (ICache)INSTANCE.get(clazz);
/* 194 */     if (cacheInstance == null)
/*     */     {
/* 196 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.no_cache", new String[] { clazz.getName() }));
/*     */     }
/*     */ 
/* 199 */     if (IS_READONLY) {
/* 200 */       return new UnmodifiableHashMap(cacheInstance.getAll());
/*     */     }
/*     */ 
/* 203 */     return cacheInstance.getAll();
/*     */   }
/*     */ 
/*     */   public static HashMap _getCacheInstances()
/*     */   {
/* 212 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  48 */       Caches caches = XMLHelper.getInstance().getCaches();
/*  49 */       Cache[] objCache = caches.getCaches();
/*     */ 
/*  51 */       for (int i = 0; i < objCache.length; ++i) {
/*  52 */         ICache cacheInstance = null;
/*     */         try {
/*  54 */           cacheInstance = (ICache)Class.forName(objCache[i].getId()).newInstance();
/*     */         }
/*     */         catch (Throwable ex) {
/*  57 */           log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.instantiate_failed", new String[] { objCache[i].getId() }), ex);
/*  58 */           break label274:
/*     */         }
/*     */ 
/*  61 */         INSTANCE.put(Class.forName(objCache[i].getId()), cacheInstance);
/*     */ 
/*  63 */         label274: if (objCache[i].getInit().equalsIgnoreCase("true")) {
/*     */           try {
/*  65 */             cacheInstance.refresh();
/*  66 */             if (log.isDebugEnabled())
/*  67 */               log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.instantiate_succeed", new String[] { objCache[i].getId(), cacheInstance.getAll().size() + "" }));
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/*  71 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.refresh_failed", new String[] { objCache[i].getId() }), ex);
/*     */           }
/*     */ 
/*     */         }
/*  76 */         else if (log.isDebugEnabled()) {
/*  77 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.load_delay", new String[] { objCache[i].getId() }));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  83 */       Quartz objQuartz = caches.getQuartz();
/*  84 */       Property[] property = objQuartz.getPropertys();
/*  85 */       Properties properties = new Properties();
/*  86 */       for (int i = 0; i < property.length; ++i) {
/*  87 */         properties.put(property[i].getName(), property[i].getValue());
/*     */       }
/*     */ 
/*  90 */       if (log.isDebugEnabled()) {
/*  91 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.prop_quartz", new String[] { properties.toString() }));
/*     */       }
/*     */ 
/*  95 */       SchedulerFactory objSchedulerFactory = new StdSchedulerFactory(properties);
/*  96 */       Scheduler objScheduler = objSchedulerFactory.getScheduler();
/*     */ 
/*  98 */       for (int i = 0; i < objCache.length; ++i) {
/*  99 */         if ((objCache[i].getPropertys() != null) && (objCache[i].getPropertys().length != 0) && (objCache[i].getPropertys()[0].getName().equalsIgnoreCase("cronExpression"))) {
/* 100 */           JobDetail job = new JobDetail("CronJob" + i, "CronJobGrp" + i, CronJob.class);
/* 101 */           Trigger trigger = new CronTrigger("CronTrigger" + i, "CronTriggerGrp" + i, objCache[i].getPropertys()[0].getValue());
/*     */ 
/* 103 */           job.getJobDataMap().put("SCHEDULER_VAR", INSTANCE.get(Class.forName(objCache[i].getId())));
/*     */ 
/* 105 */           objScheduler.scheduleJob(job, trigger);
/*     */ 
/* 107 */           if (log.isDebugEnabled()) {
/* 108 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.refresh_expression", new String[] { objCache[i].getId(), objCache[i].getPropertys()[0].getValue() }));
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 113 */       objScheduler.start();
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 118 */       log.error("Failed to load data:", ex);
/* 119 */       throw new RuntimeException(ex);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 125 */       String strReturnUnmodifiedMap = AIConfigManager.getConfigItem("CACHE_READONLY");
/* 126 */       if (!StringUtils.isBlank(strReturnUnmodifiedMap)) {
/* 127 */         if (strReturnUnmodifiedMap.trim().equalsIgnoreCase("true")) {
/* 128 */           IS_READONLY = true;
/*     */         }
/*     */         else {
/* 131 */           IS_READONLY = false;
/*     */         }
/*     */       }
/*     */       else
/* 135 */         IS_READONLY = false;
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 139 */       IS_READONLY = false;
/*     */     }
/*     */     finally {
/* 142 */       if (IS_READONLY) {
/* 143 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.readonly.true"));
/*     */       }
/*     */       else
/* 146 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.readonly.false"));
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.CacheFactory
 * JD-Core Version:    0.5.4
 */