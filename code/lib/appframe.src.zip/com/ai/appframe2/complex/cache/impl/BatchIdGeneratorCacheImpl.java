/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.IdGeneratorBean;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.complex.tab.id.BatchSequence;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class BatchIdGeneratorCacheImpl extends AbstractCache
/*    */ {
/* 25 */   private static transient Log log = LogFactory.getLog(BatchIdGeneratorCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 37 */     HashMap map = new HashMap();
/*    */ 
/* 39 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/*    */ 
/* 41 */     IdGeneratorBean[] objIdGeneratorBean = objIBaseSV.getAllIdGenerator();
/* 42 */     for (int i = 0; i < objIdGeneratorBean.length; ++i)
/*    */     {
/* 44 */       if (StringUtils.isBlank(objIdGeneratorBean[i].getTableName())) {
/* 45 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.tablename_null"));
/*    */       }
/*    */ 
/* 48 */       if (StringUtils.isBlank(objIdGeneratorBean[i].getSequenceName()))
/*    */       {
/* 50 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.sequence_null", new String[] { objIdGeneratorBean[i].getTableName() }));
/*    */       }
/*    */ 
/* 54 */       if ((!StringUtils.isBlank(objIdGeneratorBean[i].getTableName())) && (!StringUtils.isBlank(objIdGeneratorBean[i].getSequenceName())) && (objIdGeneratorBean[i].getStepBy() > 0L) && (objIdGeneratorBean[i].getGeneratorType().equalsIgnoreCase("S")))
/*    */       {
/* 56 */         map.put(objIdGeneratorBean[i].getTableName(), new BatchSequence(objIdGeneratorBean[i].getSequenceName(), objIdGeneratorBean[i].getStepBy()));
/*    */ 
/* 58 */         if (log.isDebugEnabled()) {
/* 59 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.sequence_info", new String[] { objIdGeneratorBean[i].getTableName(), objIdGeneratorBean[i].getSequenceName(), objIdGeneratorBean[i].getStepBy() + "" }));
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 64 */       if ((StringUtils.isBlank(objIdGeneratorBean[i].getHisTableName())) || (objIdGeneratorBean[i].getHisStepBy() <= 0L) || (!objIdGeneratorBean[i].getGeneratorType().equalsIgnoreCase("S")) || (StringUtils.isBlank(objIdGeneratorBean[i].getHisSequenceName())))
/*    */         continue;
/* 66 */       map.put(objIdGeneratorBean[i].getHisTableName(), new BatchSequence(objIdGeneratorBean[i].getHisSequenceName(), objIdGeneratorBean[i].getHisStepBy()));
/*    */ 
/* 68 */       if (log.isDebugEnabled()) {
/* 69 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.hissequence_info", new String[] { objIdGeneratorBean[i].getHisTableName(), objIdGeneratorBean[i].getHisSequenceName(), objIdGeneratorBean[i].getHisStepBy() + "" }));
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 74 */     if (log.isDebugEnabled()) {
/* 75 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.cache.impl.load_id_succeed"));
/*    */     }
/*    */ 
/* 78 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.BatchIdGeneratorCacheImpl
 * JD-Core Version:    0.5.4
 */