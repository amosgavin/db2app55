/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.secframe.access.ISecAccess;
/*    */ import com.ai.appframe2.complex.secframe.access.SecAccessFactory;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class SecAllAccessCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 26 */     return SecAccessFactory.getSecAccess().getAllAccess();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.SecAllAccessCacheImpl
 * JD-Core Version:    0.5.4
 */