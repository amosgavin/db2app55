/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.DyncTableSplit;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import java.util.HashMap;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class DyncTableSplitCacheImpl extends AbstractCache
/*    */ {
/* 21 */   private static transient Log log = LogFactory.getLog(DyncTableSplitCacheImpl.class);
/*    */ 
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 33 */     HashMap map = new HashMap();
/* 34 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/*    */ 
/* 36 */     DyncTableSplit[] objDyncTableSplit = objIBaseSV.getAllDyncTableSplit();
/* 37 */     for (int i = 0; i < objDyncTableSplit.length; ++i) {
/* 38 */       if (map.containsKey(objDyncTableSplit[i].getGroupName())) {
/* 39 */         HashMap map2 = (HashMap)map.get(objDyncTableSplit[i].getGroupName());
/* 40 */         map2.put(objDyncTableSplit[i].getTableName(), objDyncTableSplit[i]);
/* 41 */         map.put(objDyncTableSplit[i].getGroupName(), map2);
/*    */       }
/*    */       else {
/* 44 */         HashMap map2 = new HashMap();
/* 45 */         map2.put(objDyncTableSplit[i].getTableName(), objDyncTableSplit[i]);
/* 46 */         map.put(objDyncTableSplit[i].getGroupName(), map2);
/*    */       }
/*    */     }
/*    */ 
/* 50 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.DyncTableSplitCacheImpl
 * JD-Core Version:    0.5.4
 */