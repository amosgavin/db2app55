/*    */ package com.ai.appframe2.complex.cache.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.po.ClientTimeout;
/*    */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*    */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*    */ import com.ai.appframe2.service.ServiceFactory;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ClientTimeoutCacheImpl extends AbstractCache
/*    */ {
/*    */   public HashMap getData()
/*    */     throws Exception
/*    */   {
/* 29 */     HashMap map = new HashMap();
/* 30 */     IBaseSV objIBaseSV = (IBaseSV)ServiceFactory.getService(IBaseSV.class);
/* 31 */     ClientTimeout[] objClientTimeout = objIBaseSV.getAllClientTimeoutByServerName(RuntimeServerUtil.getServerName());
/*    */ 
/* 33 */     for (int i = 0; i < objClientTimeout.length; ++i) {
/* 34 */       map.put(objClientTimeout[i].getInterfaceClassName() + "^" + objClientTimeout[i].getMethodName() + "^" + objClientTimeout[i].getParamterCount(), objClientTimeout[i]);
/*    */     }
/*    */ 
/* 37 */     return map;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.cache.impl.ClientTimeoutCacheImpl
 * JD-Core Version:    0.5.4
 */