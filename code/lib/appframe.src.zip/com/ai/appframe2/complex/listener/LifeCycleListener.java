package com.ai.appframe2.complex.listener;

public abstract interface LifeCycleListener
{
  public abstract void start()
    throws Exception;

  public abstract void stop()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.listener.LifeCycleListener
 * JD-Core Version:    0.5.4
 */