/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DyncTableSplit
/*    */   implements Serializable
/*    */ {
/*    */   private String groupName;
/*    */   private String tableName;
/*    */   private String tableNameExpr;
/*    */   private String convertClass;
/*    */   private String state;
/*    */ 
/*    */   public String getGroupName()
/*    */   {
/* 23 */     return this.groupName;
/*    */   }
/*    */   public void setGroupName(String groupName) {
/* 26 */     this.groupName = groupName;
/*    */   }
/*    */   public String getTableName() {
/* 29 */     return this.tableName;
/*    */   }
/*    */   public void setTableName(String tableName) {
/* 32 */     this.tableName = tableName;
/*    */   }
/*    */   public String getTableNameExpr() {
/* 35 */     return this.tableNameExpr;
/*    */   }
/*    */   public void setTableNameExpr(String tableNameExpr) {
/* 38 */     this.tableNameExpr = tableNameExpr;
/*    */   }
/*    */   public String getConvertClass() {
/* 41 */     return this.convertClass;
/*    */   }
/*    */   public void setConvertClass(String convertClass) {
/* 44 */     this.convertClass = convertClass;
/*    */   }
/*    */   public String getState() {
/* 47 */     return this.state;
/*    */   }
/*    */   public void setState(String state) {
/* 50 */     this.state = state;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.DyncTableSplit
 * JD-Core Version:    0.5.4
 */