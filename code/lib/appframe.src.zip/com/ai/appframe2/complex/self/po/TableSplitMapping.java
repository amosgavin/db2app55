/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TableSplitMapping
/*    */   implements Serializable
/*    */ {
/*    */   private long mappingId;
/*    */   private String columnName;
/*    */   private String tableName;
/*    */   private String columnConvertClass;
/*    */   private String state;
/*    */   private String remarks;
/*    */ 
/*    */   public String getColumnName()
/*    */   {
/* 29 */     return this.columnName;
/*    */   }
/*    */ 
/*    */   public long getMappingId() {
/* 33 */     return this.mappingId;
/*    */   }
/*    */ 
/*    */   public String getRemarks() {
/* 37 */     return this.remarks;
/*    */   }
/*    */ 
/*    */   public String getState() {
/* 41 */     return this.state;
/*    */   }
/*    */ 
/*    */   public String getTableName() {
/* 45 */     return this.tableName;
/*    */   }
/*    */ 
/*    */   public void setTableName(String tableName) {
/* 49 */     this.tableName = tableName.toUpperCase();
/*    */   }
/*    */ 
/*    */   public void setState(String state) {
/* 53 */     this.state = state;
/*    */   }
/*    */ 
/*    */   public void setRemarks(String remarks) {
/* 57 */     this.remarks = remarks;
/*    */   }
/*    */ 
/*    */   public void setMappingId(long mappingId) {
/* 61 */     this.mappingId = mappingId;
/*    */   }
/*    */ 
/*    */   public void setColumnName(String columnName) {
/* 65 */     this.columnName = columnName.toUpperCase();
/*    */   }
/*    */   public String getColumnConvertClass() {
/* 68 */     return this.columnConvertClass;
/*    */   }
/*    */   public void setColumnConvertClass(String columnConvertClass) {
/* 71 */     this.columnConvertClass = columnConvertClass;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.TableSplitMapping
 * JD-Core Version:    0.5.4
 */