package com.ai.appframe2.complex.self.service.check.interfaces;

import java.rmi.RemoteException;

public abstract interface ICheckSV
{
  public abstract String getResourcePath(String paramString);

  public abstract String getCurrentClassLoader();

  public abstract String getVersionInfo()
    throws RemoteException, Exception;

  public abstract long heartbeat()
    throws RemoteException, Exception;

  public abstract String getServerName()
    throws RemoteException, Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.service.check.interfaces.ICheckSV
 * JD-Core Version:    0.5.4
 */