/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class MethodCenter
/*    */   implements Serializable
/*    */ {
/*    */   private String serviceImplClassName;
/*    */   private String methodName;
/*    */   private int parameterCount;
/*    */   private int parameterIndex;
/*    */   private String parameterFunction;
/*    */   private String centerType;
/*    */ 
/*    */   public void setServiceImplClassName(String serviceImplClassName)
/*    */   {
/* 29 */     this.serviceImplClassName = serviceImplClassName;
/*    */   }
/*    */ 
/*    */   public void setMethodName(String methodName) {
/* 33 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */   public void setParameterCount(int parameterCount) {
/* 37 */     this.parameterCount = parameterCount;
/*    */   }
/*    */ 
/*    */   public void setParameterIndex(int parameterIndex) {
/* 41 */     this.parameterIndex = parameterIndex;
/*    */   }
/*    */ 
/*    */   public void setParameterFunction(String parameterFunction) {
/* 45 */     this.parameterFunction = parameterFunction;
/*    */   }
/*    */ 
/*    */   public void setCenterType(String centerType) {
/* 49 */     this.centerType = centerType;
/*    */   }
/*    */ 
/*    */   public String getServiceImplClassName() {
/* 53 */     return this.serviceImplClassName;
/*    */   }
/*    */ 
/*    */   public String getMethodName() {
/* 57 */     return this.methodName;
/*    */   }
/*    */ 
/*    */   public int getParameterCount() {
/* 61 */     return this.parameterCount;
/*    */   }
/*    */ 
/*    */   public int getParameterIndex() {
/* 65 */     return this.parameterIndex;
/*    */   }
/*    */ 
/*    */   public String getParameterFunction() {
/* 69 */     return this.parameterFunction;
/*    */   }
/*    */ 
/*    */   public String getCenterType() {
/* 73 */     return this.centerType;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.MethodCenter
 * JD-Core Version:    0.5.4
 */