/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class BOMask
/*    */   implements Serializable
/*    */ {
/*    */   private String boName;
/*    */   private String attrName;
/*    */   private String maskFunctionClass;
/*    */ 
/*    */   public void setBoName(String boName)
/*    */   {
/* 13 */     this.boName = boName;
/*    */   }
/*    */ 
/*    */   public void setAttrName(String attrName) {
/* 17 */     this.attrName = attrName;
/*    */   }
/*    */ 
/*    */   public void setMaskFunctionClass(String maskFunctionClass) {
/* 21 */     this.maskFunctionClass = maskFunctionClass;
/*    */   }
/*    */ 
/*    */   public String getBoName() {
/* 25 */     return this.boName;
/*    */   }
/*    */ 
/*    */   public String getAttrName() {
/* 29 */     return this.attrName;
/*    */   }
/*    */ 
/*    */   public String getMaskFunctionClass() {
/* 33 */     return this.maskFunctionClass;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.BOMask
 * JD-Core Version:    0.5.4
 */