/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class IdGeneratorWrapperBean
/*    */   implements Serializable
/*    */ {
/*    */   private String tableName;
/*    */   private String tableSeqWrapperImpl;
/*    */   private String hisTableSeqWrapperImpl;
/*    */   private Object tableSeqWrapperObj;
/*    */   private Object hisTableSeqWrapperObj;
/*    */ 
/*    */   public void setTableName(String tableName)
/*    */   {
/* 25 */     this.tableName = tableName;
/*    */   }
/*    */ 
/*    */   public void setTableSeqWrapperImpl(String tableSeqWrapperImpl) {
/* 29 */     this.tableSeqWrapperImpl = tableSeqWrapperImpl;
/*    */   }
/*    */ 
/*    */   public void setHisTableSeqWrapperImpl(String hisTableSeqWrapperImpl) {
/* 33 */     this.hisTableSeqWrapperImpl = hisTableSeqWrapperImpl;
/*    */   }
/*    */ 
/*    */   public void setTableSeqWrapperObj(Object tableSeqWrapperObj) {
/* 37 */     this.tableSeqWrapperObj = tableSeqWrapperObj;
/*    */   }
/*    */ 
/*    */   public void setHisTableSeqWrapperObj(Object hisTableSeqWrapperObj) {
/* 41 */     this.hisTableSeqWrapperObj = hisTableSeqWrapperObj;
/*    */   }
/*    */ 
/*    */   public String getTableName() {
/* 45 */     return this.tableName;
/*    */   }
/*    */ 
/*    */   public String getTableSeqWrapperImpl() {
/* 49 */     return this.tableSeqWrapperImpl;
/*    */   }
/*    */ 
/*    */   public String getHisTableSeqWrapperImpl() {
/* 53 */     return this.hisTableSeqWrapperImpl;
/*    */   }
/*    */ 
/*    */   public Object getTableSeqWrapperObj() {
/* 57 */     return this.tableSeqWrapperObj;
/*    */   }
/*    */ 
/*    */   public Object getHisTableSeqWrapperObj() {
/* 61 */     return this.hisTableSeqWrapperObj;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean
 * JD-Core Version:    0.5.4
 */