/*     */ package com.ai.appframe2.complex.self.dao.base.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.complex.center.mc.function.DefaultFunctionImpl;
/*     */ import com.ai.appframe2.complex.datasource.DataSourceFactory;
/*     */ import com.ai.appframe2.complex.datasource.interfaces.IDataSource;
/*     */ import com.ai.appframe2.complex.self.dao.base.interfaces.IBaseDAO;
/*     */ import com.ai.appframe2.complex.self.po.BOMask;
/*     */ import com.ai.appframe2.complex.self.po.ClientTimeout;
/*     */ import com.ai.appframe2.complex.self.po.DyncTableSplit;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorBean;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean;
/*     */ import com.ai.appframe2.complex.self.po.MethodCenter;
/*     */ import com.ai.appframe2.complex.self.po.TableSplit;
/*     */ import com.ai.appframe2.complex.self.po.TableSplitMapping;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class BaseDAOImpl
/*     */   implements IBaseDAO
/*     */ {
/*     */   public ClientTimeout[] getAllClientTimeoutByServerName(String serverName)
/*     */     throws Exception
/*     */   {
/*  45 */     HashMap defaultMap = getClientTimeoutByServerName("DEFAULT");
/*     */ 
/*  47 */     HashMap serverMap = getClientTimeoutByServerName(serverName);
/*     */ 
/*  50 */     defaultMap.putAll(serverMap);
/*     */ 
/*  52 */     return (ClientTimeout[])(ClientTimeout[])defaultMap.values().toArray(new ClientTimeout[0]);
/*     */   }
/*     */ 
/*     */   public BOMask[] getAllBOMask()
/*     */     throws Exception
/*     */   {
/*  61 */     List rtn = new ArrayList();
/*     */ 
/*  63 */     Connection conn = null;
/*  64 */     PreparedStatement ptmt = null;
/*  65 */     ResultSet rs = null;
/*     */     try {
/*  67 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/*  68 */       ptmt = conn.prepareStatement("select * from cfg_bo_mask where state = 'U'");
/*  69 */       rs = ptmt.executeQuery();
/*  70 */       while (rs.next()) {
/*  71 */         BOMask objBOMask = new BOMask();
/*  72 */         objBOMask.setBoName(rs.getString("BO_NAME"));
/*  73 */         objBOMask.setAttrName(rs.getString("ATTR_NAME").toUpperCase());
/*  74 */         objBOMask.setMaskFunctionClass(rs.getString("MASK_FUNCTION_CLASS"));
/*     */ 
/*  76 */         rtn.add(objBOMask);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/*  83 */       if (rs != null) {
/*  84 */         rs.close();
/*     */       }
/*  86 */       if (ptmt != null) {
/*  87 */         ptmt.close();
/*     */       }
/*  89 */       if (conn != null) {
/*  90 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/*  94 */     return (BOMask[])(BOMask[])rtn.toArray(new BOMask[0]);
/*     */   }
/*     */ 
/*     */   public TableSplit[] getAllTableSplit()
/*     */     throws Exception
/*     */   {
/* 104 */     List rtn = new ArrayList();
/*     */ 
/* 106 */     Connection conn = null;
/* 107 */     PreparedStatement ptmt = null;
/* 108 */     ResultSet rs = null;
/*     */     try {
/* 110 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 111 */       ptmt = conn.prepareStatement("select * from cfg_table_split where state = 'U'");
/* 112 */       rs = ptmt.executeQuery();
/* 113 */       while (rs.next()) {
/* 114 */         TableSplit objTableSplit = new TableSplit();
/* 115 */         objTableSplit.setTableName(rs.getString("TABLE_NAME"));
/* 116 */         objTableSplit.setTableNameExpr(rs.getString("TABLE_NAME_EXPR"));
/* 117 */         objTableSplit.setState(rs.getString("STATE"));
/* 118 */         objTableSplit.setRemarks(rs.getString("REMARKS"));
/*     */ 
/* 120 */         rtn.add(objTableSplit);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 127 */       if (rs != null) {
/* 128 */         rs.close();
/*     */       }
/* 130 */       if (ptmt != null) {
/* 131 */         ptmt.close();
/*     */       }
/* 133 */       if (conn != null) {
/* 134 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 138 */     return (TableSplit[])(TableSplit[])rtn.toArray(new TableSplit[0]);
/*     */   }
/*     */ 
/*     */   public TableSplitMapping[] getAllTableSplitMapping()
/*     */     throws Exception
/*     */   {
/* 147 */     List rtn = new ArrayList();
/*     */ 
/* 149 */     Connection conn = null;
/* 150 */     PreparedStatement ptmt = null;
/* 151 */     ResultSet rs = null;
/*     */     try {
/* 153 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 154 */       ptmt = conn.prepareStatement("select * from cfg_table_split_mapping where state = 'U'");
/* 155 */       rs = ptmt.executeQuery();
/* 156 */       while (rs.next()) {
/* 157 */         TableSplitMapping objTableSplitMapping = new TableSplitMapping();
/* 158 */         objTableSplitMapping.setMappingId(rs.getLong("MAPPING_ID"));
/* 159 */         objTableSplitMapping.setColumnName(rs.getString("COLUMN_NAME"));
/* 160 */         objTableSplitMapping.setTableName(rs.getString("TABLE_NAME"));
/* 161 */         objTableSplitMapping.setColumnConvertClass(rs.getString("COLUMN_CONVERT_CLASS"));
/* 162 */         objTableSplitMapping.setState(rs.getString("STATE"));
/* 163 */         objTableSplitMapping.setRemarks(rs.getString("REMARKS"));
/*     */ 
/* 165 */         rtn.add(objTableSplitMapping);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 172 */       if (rs != null) {
/* 173 */         rs.close();
/*     */       }
/* 175 */       if (ptmt != null) {
/* 176 */         ptmt.close();
/*     */       }
/* 178 */       if (conn != null) {
/* 179 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 183 */     return (TableSplitMapping[])(TableSplitMapping[])rtn.toArray(new TableSplitMapping[0]);
/*     */   }
/*     */ 
/*     */   public TableSplitMapping[] getAllTableSplitFunction()
/*     */     throws Exception
/*     */   {
/* 192 */     List rtn = new ArrayList();
/*     */ 
/* 194 */     Connection conn = null;
/* 195 */     PreparedStatement ptmt = null;
/* 196 */     ResultSet rs = null;
/*     */     try {
/* 198 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 199 */       ptmt = conn.prepareStatement("select distinct column_convert_class from cfg_table_split_mapping where state = 'U'");
/* 200 */       rs = ptmt.executeQuery();
/* 201 */       while (rs.next()) {
/* 202 */         TableSplitMapping objTableSplitMapping = new TableSplitMapping();
/* 203 */         objTableSplitMapping.setColumnConvertClass(rs.getString("COLUMN_CONVERT_CLASS"));
/*     */ 
/* 205 */         rtn.add(objTableSplitMapping);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 212 */       if (rs != null) {
/* 213 */         rs.close();
/*     */       }
/* 215 */       if (ptmt != null) {
/* 216 */         ptmt.close();
/*     */       }
/* 218 */       if (conn != null) {
/* 219 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 223 */     return (TableSplitMapping[])(TableSplitMapping[])rtn.toArray(new TableSplitMapping[0]);
/*     */   }
/*     */ 
/*     */   public IdGeneratorBean[] getAllIdGenerator()
/*     */     throws Exception
/*     */   {
/* 233 */     List rtn = new ArrayList();
/*     */ 
/* 235 */     Connection conn = null;
/* 236 */     PreparedStatement ptmt = null;
/* 237 */     ResultSet rs = null;
/*     */     try {
/* 239 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 240 */       ptmt = conn.prepareStatement("select * from cfg_id_generator");
/* 241 */       rs = ptmt.executeQuery();
/* 242 */       while (rs.next()) {
/* 243 */         IdGeneratorBean objIdGenerator = new IdGeneratorBean();
/* 244 */         objIdGenerator.setDomainId(rs.getLong("DOMAIN_ID"));
/* 245 */         objIdGenerator.setStartValue(rs.getLong("START_VALUE"));
/* 246 */         objIdGenerator.setHisDonecodeFlag(rs.getString("HIS_DONECODE_FLAG"));
/* 247 */         objIdGenerator.setCycleFlag(rs.getString("CYCLE_FLAG"));
/* 248 */         objIdGenerator.setHisDataFlag(rs.getString("HIS_DATA_FLAG"));
/* 249 */         objIdGenerator.setMaxValue(rs.getLong("MAX_VALUE"));
/* 250 */         objIdGenerator.setTableName(rs.getString("TABLE_NAME"));
/* 251 */         objIdGenerator.setSequenceName(rs.getString("SEQUENCE_NAME"));
/* 252 */         objIdGenerator.setHisMaxId(rs.getLong("HIS_MAX_ID"));
/* 253 */         objIdGenerator.setSequenceCreateScript(rs.getString("SEQUENCE_CREATE_SCRIPT"));
/* 254 */         objIdGenerator.setGeneratorType(rs.getString("GENERATOR_TYPE"));
/* 255 */         objIdGenerator.setMaxId(rs.getLong("MAX_ID"));
/* 256 */         objIdGenerator.setHisSequenceName(rs.getString("HIS_SEQUENCE_NAME"));
/* 257 */         objIdGenerator.setHisTableName(rs.getString("HIS_TABLE_NAME"));
/* 258 */         objIdGenerator.setIncrementValue(rs.getLong("INCREMENT_VALUE"));
/* 259 */         objIdGenerator.setMinValue(rs.getLong("MIN_VALUE"));
/* 260 */         objIdGenerator.setCacheSize(rs.getLong("CACHE_SIZE"));
/* 261 */         objIdGenerator.setStepBy(rs.getLong("STEP_BY"));
/* 262 */         objIdGenerator.setHisStepBy(rs.getLong("HIS_STEP_BY"));
/*     */ 
/* 264 */         rtn.add(objIdGenerator);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 271 */       if (rs != null) {
/* 272 */         rs.close();
/*     */       }
/* 274 */       if (ptmt != null) {
/* 275 */         ptmt.close();
/*     */       }
/* 277 */       if (conn != null) {
/* 278 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 282 */     return (IdGeneratorBean[])(IdGeneratorBean[])rtn.toArray(new IdGeneratorBean[0]);
/*     */   }
/*     */ 
/*     */   public IdGeneratorWrapperBean[] getAllIdGeneratorWrapper()
/*     */     throws Exception
/*     */   {
/* 291 */     List rtn = new ArrayList();
/*     */ 
/* 293 */     Connection conn = null;
/* 294 */     PreparedStatement ptmt = null;
/* 295 */     ResultSet rs = null;
/*     */     try {
/* 297 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 298 */       ptmt = conn.prepareStatement("select * from cfg_id_generator_wrapper");
/* 299 */       rs = ptmt.executeQuery();
/* 300 */       while (rs.next()) {
/* 301 */         IdGeneratorWrapperBean objIdGeneratorWrapperBean = new IdGeneratorWrapperBean();
/* 302 */         objIdGeneratorWrapperBean.setTableName(rs.getString("TABLE_NAME"));
/* 303 */         objIdGeneratorWrapperBean.setTableSeqWrapperImpl(rs.getString("TABLE_SEQ_WRAPPER_IMPL"));
/* 304 */         objIdGeneratorWrapperBean.setHisTableSeqWrapperImpl(rs.getString("HIS_TABLE_SEQ_WRAPPER_IMPL"));
/*     */ 
/* 306 */         rtn.add(objIdGeneratorWrapperBean);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 313 */       if (rs != null) {
/* 314 */         rs.close();
/*     */       }
/* 316 */       if (ptmt != null) {
/* 317 */         ptmt.close();
/*     */       }
/* 319 */       if (conn != null) {
/* 320 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 324 */     return (IdGeneratorWrapperBean[])(IdGeneratorWrapperBean[])rtn.toArray(new IdGeneratorWrapperBean[0]);
/*     */   }
/*     */ 
/*     */   public DyncTableSplit[] getAllDyncTableSplit()
/*     */     throws Exception
/*     */   {
/* 333 */     List rtn = new ArrayList();
/*     */ 
/* 335 */     Connection conn = null;
/* 336 */     PreparedStatement ptmt = null;
/* 337 */     ResultSet rs = null;
/*     */     try {
/* 339 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 340 */       ptmt = conn.prepareStatement("select * from cfg_dync_table_split where state = 'U' order by group_name,table_name");
/* 341 */       rs = ptmt.executeQuery();
/* 342 */       while (rs.next()) {
/* 343 */         DyncTableSplit objDyncTableSplit = new DyncTableSplit();
/* 344 */         objDyncTableSplit.setGroupName(rs.getString("GROUP_NAME"));
/* 345 */         objDyncTableSplit.setTableName(rs.getString("TABLE_NAME"));
/* 346 */         objDyncTableSplit.setTableNameExpr(rs.getString("TABLE_NAME_EXPR"));
/* 347 */         objDyncTableSplit.setConvertClass(rs.getString("CONVERT_CLASS"));
/*     */ 
/* 349 */         rtn.add(objDyncTableSplit);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 356 */       if (rs != null) {
/* 357 */         rs.close();
/*     */       }
/* 359 */       if (ptmt != null) {
/* 360 */         ptmt.close();
/*     */       }
/* 362 */       if (conn != null) {
/* 363 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 367 */     return (DyncTableSplit[])(DyncTableSplit[])rtn.toArray(new DyncTableSplit[0]);
/*     */   }
/*     */ 
/*     */   public String[] getAllDyncSplitFunction()
/*     */     throws Exception
/*     */   {
/* 377 */     List rtn = new ArrayList();
/*     */ 
/* 379 */     Connection conn = null;
/* 380 */     PreparedStatement ptmt = null;
/* 381 */     ResultSet rs = null;
/*     */     try {
/* 383 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 384 */       ptmt = conn.prepareStatement("select distinct convert_class from cfg_dync_table_split where state = 'U'");
/* 385 */       rs = ptmt.executeQuery();
/* 386 */       while (rs.next())
/* 387 */         rtn.add(rs.getString("CONVERT_CLASS").trim());
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 394 */       if (rs != null) {
/* 395 */         rs.close();
/*     */       }
/* 397 */       if (ptmt != null) {
/* 398 */         ptmt.close();
/*     */       }
/* 400 */       if (conn != null) {
/* 401 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 405 */     return (String[])(String[])rtn.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public MethodCenter[] getAllMethodCenter()
/*     */     throws Exception
/*     */   {
/* 414 */     List rtn = new ArrayList();
/*     */ 
/* 416 */     Connection conn = null;
/* 417 */     PreparedStatement ptmt = null;
/* 418 */     ResultSet rs = null;
/*     */     try {
/* 420 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 421 */       ptmt = conn.prepareStatement("select * from cfg_method_center where state = 'U' order by service_impl_classname,method_name,parameter_count");
/* 422 */       rs = ptmt.executeQuery();
/* 423 */       while (rs.next()) {
/* 424 */         MethodCenter objMethodCenter = new MethodCenter();
/* 425 */         objMethodCenter.setServiceImplClassName(rs.getString("SERVICE_IMPL_CLASSNAME").trim());
/* 426 */         objMethodCenter.setMethodName(rs.getString("METHOD_NAME").trim());
/* 427 */         objMethodCenter.setParameterCount(rs.getInt("PARAMETER_COUNT"));
/* 428 */         objMethodCenter.setParameterIndex(rs.getInt("PARAMETER_INDEX"));
/*     */ 
/* 430 */         String function = rs.getString("PARAMETER_FUNCTION").trim();
/* 431 */         if (function.equalsIgnoreCase("default")) {
/* 432 */           objMethodCenter.setParameterFunction(DefaultFunctionImpl.class.getName());
/*     */         }
/*     */         else {
/* 435 */           objMethodCenter.setParameterFunction(function);
/*     */         }
/*     */ 
/* 438 */         objMethodCenter.setCenterType(rs.getString("CENTER_TYPE").trim());
/*     */ 
/* 440 */         rtn.add(objMethodCenter);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 447 */       if (rs != null) {
/* 448 */         rs.close();
/*     */       }
/* 450 */       if (ptmt != null) {
/* 451 */         ptmt.close();
/*     */       }
/* 453 */       if (conn != null) {
/* 454 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 458 */     return (MethodCenter[])(MethodCenter[])rtn.toArray(new MethodCenter[0]);
/*     */   }
/*     */ 
/*     */   private HashMap getClientTimeoutByServerName(String serverName)
/*     */     throws Exception
/*     */   {
/* 468 */     HashMap rtn = new HashMap();
/*     */ 
/* 470 */     Connection conn = null;
/* 471 */     PreparedStatement ptmt = null;
/* 472 */     ResultSet rs = null;
/*     */     try {
/* 474 */       conn = ServiceManager.getSession().getConnection(DataSourceFactory.getDataSource().getPrimaryDataSource());
/* 475 */       ptmt = conn.prepareStatement("select * from cfg_client_timeout where state = 'U' and server_name = ? ");
/* 476 */       ptmt.setString(1, serverName);
/* 477 */       rs = ptmt.executeQuery();
/* 478 */       while (rs.next()) {
/* 479 */         ClientTimeout objClientTimeout = new ClientTimeout();
/* 480 */         objClientTimeout.setServerName(rs.getString("SERVER_NAME").trim());
/* 481 */         objClientTimeout.setInterfaceClassName(rs.getString("INTERFACE_CLASSNAME").trim());
/* 482 */         objClientTimeout.setMethodName(rs.getString("METHOD_NAME").trim());
/* 483 */         objClientTimeout.setParamterCount(rs.getInt("PARAMETER_COUNT"));
/* 484 */         objClientTimeout.setTimeoutSecond(rs.getInt("TIMEOUT_SECOND"));
/*     */ 
/* 486 */         rtn.put(objClientTimeout.getInterfaceClassName() + "^" + objClientTimeout.getMethodName() + "^" + objClientTimeout.getParamterCount(), objClientTimeout);
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 493 */       if (rs != null) {
/* 494 */         rs.close();
/*     */       }
/* 496 */       if (ptmt != null) {
/* 497 */         ptmt.close();
/*     */       }
/* 499 */       if (conn != null) {
/* 500 */         conn.close();
/*     */       }
/*     */     }
/*     */ 
/* 504 */     return rtn;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.dao.base.impl.BaseDAOImpl
 * JD-Core Version:    0.5.4
 */