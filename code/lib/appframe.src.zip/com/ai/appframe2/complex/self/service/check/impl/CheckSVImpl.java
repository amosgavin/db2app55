/*    */ package com.ai.appframe2.complex.self.service.check.impl;
/*    */ 
/*    */ import com.ai.appframe2.complex.self.service.check.interfaces.ICheckSV;
/*    */ import com.ai.appframe2.complex.util.RuntimeServerUtil;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.InputStreamReader;
/*    */ import java.net.URL;
/*    */ import java.rmi.RemoteException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class CheckSVImpl
/*    */   implements ICheckSV
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(CheckSVImpl.class);
/*    */ 
/*    */   public String getResourcePath(String resource)
/*    */   {
/* 34 */     URL url = Thread.currentThread().getContextClassLoader().getResource(resource);
/* 35 */     if (url != null) {
/* 36 */       return url.toString();
/*    */     }
/*    */ 
/* 39 */     return null;
/*    */   }
/*    */ 
/*    */   public String getCurrentClassLoader()
/*    */   {
/* 48 */     return Thread.currentThread().getContextClassLoader().toString();
/*    */   }
/*    */ 
/*    */   public String getVersionInfo()
/*    */     throws RemoteException, Exception
/*    */   {
/* 58 */     StringBuilder sb = new StringBuilder();
/*    */     try {
/* 60 */       BufferedReader reader = new BufferedReader(new InputStreamReader(Thread.currentThread().getContextClassLoader().getResourceAsStream("system/service/version.txt")));
/*    */       while (true) {
/* 62 */         String line = reader.readLine();
/* 63 */         if (line == null) {
/*    */           break;
/*    */         }
/*    */ 
/* 67 */         sb.append(line + "\n");
/*    */       }
/*    */ 
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 73 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.complex.self.service.check.impl.version_failed"), ex);
/*    */     }
/*    */ 
/* 76 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public long heartbeat()
/*    */     throws RemoteException, Exception
/*    */   {
/* 86 */     return System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   public String getServerName()
/*    */     throws RemoteException, Exception
/*    */   {
/* 96 */     return RuntimeServerUtil.getServerName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.service.check.impl.CheckSVImpl
 * JD-Core Version:    0.5.4
 */