/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class ClientTimeout
/*    */   implements Serializable
/*    */ {
/*    */   private String serverName;
/*    */   private String interfaceClassName;
/*    */   private String methodName;
/*    */   private int paramterCount;
/*    */   private int timeoutSecond;
/*    */ 
/*    */   public void setServerName(String serverName)
/*    */   {
/* 25 */     this.serverName = serverName;
/*    */   }
/*    */ 
/*    */   public void setInterfaceClassName(String interfaceClassName) {
/* 29 */     this.interfaceClassName = interfaceClassName;
/*    */   }
/*    */ 
/*    */   public void setMethodName(String methodName) {
/* 33 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */   public void setParamterCount(int paramterCount) {
/* 37 */     this.paramterCount = paramterCount;
/*    */   }
/*    */ 
/*    */   public void setTimeoutSecond(int timeoutSecond) {
/* 41 */     this.timeoutSecond = timeoutSecond;
/*    */   }
/*    */ 
/*    */   public String getServerName() {
/* 45 */     return this.serverName;
/*    */   }
/*    */ 
/*    */   public String getInterfaceClassName() {
/* 49 */     return this.interfaceClassName;
/*    */   }
/*    */ 
/*    */   public String getMethodName() {
/* 53 */     return this.methodName;
/*    */   }
/*    */ 
/*    */   public int getParamterCount() {
/* 57 */     return this.paramterCount;
/*    */   }
/*    */ 
/*    */   public int getTimeoutSecond() {
/* 61 */     return this.timeoutSecond;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.ClientTimeout
 * JD-Core Version:    0.5.4
 */