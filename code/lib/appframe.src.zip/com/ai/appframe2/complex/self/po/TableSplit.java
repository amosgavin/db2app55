/*    */ package com.ai.appframe2.complex.self.po;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TableSplit
/*    */   implements Serializable
/*    */ {
/*    */   private String tableName;
/*    */   private String tableNameExpr;
/*    */   private String state;
/*    */   private String remarks;
/*    */ 
/*    */   public String getTableName()
/*    */   {
/* 24 */     return this.tableName;
/*    */   }
/*    */ 
/*    */   public void setTableName(String tableName) {
/* 28 */     this.tableName = tableName.toUpperCase();
/*    */   }
/*    */ 
/*    */   public String getTableNameExpr() {
/* 32 */     return this.tableNameExpr;
/*    */   }
/*    */ 
/*    */   public void setTableNameExpr(String tableNameExpr) {
/* 36 */     this.tableNameExpr = tableNameExpr;
/*    */   }
/*    */ 
/*    */   public String getState() {
/* 40 */     return this.state;
/*    */   }
/*    */ 
/*    */   public void setState(String state) {
/* 44 */     this.state = state;
/*    */   }
/*    */ 
/*    */   public String getRemarks() {
/* 48 */     return this.remarks;
/*    */   }
/*    */ 
/*    */   public void setRemarks(String remarks) {
/* 52 */     this.remarks = remarks;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.TableSplit
 * JD-Core Version:    0.5.4
 */