/*     */ package com.ai.appframe2.complex.self.po;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class IdGeneratorBean
/*     */   implements Serializable
/*     */ {
/*     */   private long domainId;
/*     */   private long startValue;
/*     */   private String hisDonecodeFlag;
/*     */   private String cycleFlag;
/*     */   private String hisDataFlag;
/*     */   private long maxValue;
/*     */   private String sequenceName;
/*     */   private long hisMaxId;
/*     */   private String sequenceCreateScript;
/*     */   private String generatorType;
/*     */   private long maxId;
/*     */   private String hisSequenceName;
/*     */   private String hisTableName;
/*     */   private long incrementValue;
/*     */   private long minValue;
/*     */   private long cacheSize;
/*     */   private long stepBy;
/*     */   private String tableName;
/*     */   private long hisStepBy;
/*     */ 
/*     */   public long getCacheSize()
/*     */   {
/*  38 */     return this.cacheSize;
/*     */   }
/*     */   public String getCycleFlag() {
/*  41 */     return this.cycleFlag;
/*     */   }
/*     */   public long getDomainId() {
/*  44 */     return this.domainId;
/*     */   }
/*     */   public String getGeneratorType() {
/*  47 */     return this.generatorType;
/*     */   }
/*     */   public String getHisDataFlag() {
/*  50 */     return this.hisDataFlag;
/*     */   }
/*     */   public String getHisDonecodeFlag() {
/*  53 */     return this.hisDonecodeFlag;
/*     */   }
/*     */   public long getHisMaxId() {
/*  56 */     return this.hisMaxId;
/*     */   }
/*     */   public String getHisSequenceName() {
/*  59 */     return this.hisSequenceName;
/*     */   }
/*     */   public String getHisTableName() {
/*  62 */     return this.hisTableName;
/*     */   }
/*     */   public long getIncrementValue() {
/*  65 */     return this.incrementValue;
/*     */   }
/*     */   public long getMaxId() {
/*  68 */     return this.maxId;
/*     */   }
/*     */   public long getMinValue() {
/*  71 */     return this.minValue;
/*     */   }
/*     */   public long getMaxValue() {
/*  74 */     return this.maxValue;
/*     */   }
/*     */   public String getSequenceCreateScript() {
/*  77 */     return this.sequenceCreateScript;
/*     */   }
/*     */   public String getSequenceName() {
/*  80 */     return this.sequenceName;
/*     */   }
/*     */   public long getStartValue() {
/*  83 */     return this.startValue;
/*     */   }
/*     */   public long getStepBy() {
/*  86 */     return this.stepBy;
/*     */   }
/*     */   public String getTableName() {
/*  89 */     return this.tableName;
/*     */   }
/*     */   public void setTableName(String tableName) {
/*  92 */     this.tableName = tableName;
/*     */   }
/*     */   public void setStepBy(long stepBy) {
/*  95 */     this.stepBy = stepBy;
/*     */   }
/*     */   public void setStartValue(long startValue) {
/*  98 */     this.startValue = startValue;
/*     */   }
/*     */   public void setSequenceName(String sequenceName) {
/* 101 */     this.sequenceName = sequenceName;
/*     */   }
/*     */   public void setSequenceCreateScript(String sequenceCreateScript) {
/* 104 */     this.sequenceCreateScript = sequenceCreateScript;
/*     */   }
/*     */   public void setMinValue(long minValue) {
/* 107 */     this.minValue = minValue;
/*     */   }
/*     */   public void setMaxValue(long maxValue) {
/* 110 */     this.maxValue = maxValue;
/*     */   }
/*     */   public void setMaxId(long maxId) {
/* 113 */     this.maxId = maxId;
/*     */   }
/*     */   public void setIncrementValue(long incrementValue) {
/* 116 */     this.incrementValue = incrementValue;
/*     */   }
/*     */   public void setHisTableName(String hisTableName) {
/* 119 */     this.hisTableName = hisTableName;
/*     */   }
/*     */   public void setHisSequenceName(String hisSequenceName) {
/* 122 */     this.hisSequenceName = hisSequenceName;
/*     */   }
/*     */   public void setHisMaxId(long hisMaxId) {
/* 125 */     this.hisMaxId = hisMaxId;
/*     */   }
/*     */   public void setHisDonecodeFlag(String hisDonecodeFlag) {
/* 128 */     this.hisDonecodeFlag = hisDonecodeFlag;
/*     */   }
/*     */   public void setHisDataFlag(String hisDataFlag) {
/* 131 */     this.hisDataFlag = hisDataFlag;
/*     */   }
/*     */   public void setDomainId(long domainId) {
/* 134 */     this.domainId = domainId;
/*     */   }
/*     */   public void setCycleFlag(String cycleFlag) {
/* 137 */     this.cycleFlag = cycleFlag;
/*     */   }
/*     */   public void setCacheSize(long cacheSize) {
/* 140 */     this.cacheSize = cacheSize;
/*     */   }
/*     */   public void setGeneratorType(String generatorType) {
/* 143 */     this.generatorType = generatorType;
/*     */   }
/*     */   public long getHisStepBy() {
/* 146 */     return this.hisStepBy;
/*     */   }
/*     */   public void setHisStepBy(long hisStepBy) {
/* 149 */     this.hisStepBy = hisStepBy;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.po.IdGeneratorBean
 * JD-Core Version:    0.5.4
 */