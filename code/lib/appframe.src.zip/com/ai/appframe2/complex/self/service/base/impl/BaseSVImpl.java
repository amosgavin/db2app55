/*     */ package com.ai.appframe2.complex.self.service.base.impl;
/*     */ 
/*     */ import com.ai.appframe2.complex.self.dao.base.interfaces.IBaseDAO;
/*     */ import com.ai.appframe2.complex.self.po.BOMask;
/*     */ import com.ai.appframe2.complex.self.po.ClientTimeout;
/*     */ import com.ai.appframe2.complex.self.po.DyncTableSplit;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorBean;
/*     */ import com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean;
/*     */ import com.ai.appframe2.complex.self.po.MethodCenter;
/*     */ import com.ai.appframe2.complex.self.po.TableSplit;
/*     */ import com.ai.appframe2.complex.self.po.TableSplitMapping;
/*     */ import com.ai.appframe2.complex.self.service.base.interfaces.IBaseSV;
/*     */ import com.ai.appframe2.service.ServiceFactory;
/*     */ 
/*     */ public class BaseSVImpl
/*     */   implements IBaseSV
/*     */ {
/*     */   public ClientTimeout[] getAllClientTimeoutByServerName(String serverName)
/*     */     throws Exception
/*     */   {
/*  36 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  37 */     return objIBaseDAO.getAllClientTimeoutByServerName(serverName);
/*     */   }
/*     */ 
/*     */   public BOMask[] getAllBOMask()
/*     */     throws Exception
/*     */   {
/*  46 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  47 */     return objIBaseDAO.getAllBOMask();
/*     */   }
/*     */ 
/*     */   public TableSplit[] getAllTableSplit()
/*     */     throws Exception
/*     */   {
/*  56 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  57 */     return objIBaseDAO.getAllTableSplit();
/*     */   }
/*     */ 
/*     */   public TableSplitMapping[] getAllTableSplitMapping()
/*     */     throws Exception
/*     */   {
/*  66 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  67 */     return objIBaseDAO.getAllTableSplitMapping();
/*     */   }
/*     */ 
/*     */   public TableSplitMapping[] getAllTableSplitFunction()
/*     */     throws Exception
/*     */   {
/*  76 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  77 */     return objIBaseDAO.getAllTableSplitFunction();
/*     */   }
/*     */ 
/*     */   public IdGeneratorBean[] getAllIdGenerator()
/*     */     throws Exception
/*     */   {
/*  87 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  88 */     return objIBaseDAO.getAllIdGenerator();
/*     */   }
/*     */ 
/*     */   public IdGeneratorWrapperBean[] getAllIdGeneratorWrapper()
/*     */     throws Exception
/*     */   {
/*  97 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/*  98 */     return objIBaseDAO.getAllIdGeneratorWrapper();
/*     */   }
/*     */ 
/*     */   public DyncTableSplit[] getAllDyncTableSplit()
/*     */     throws Exception
/*     */   {
/* 107 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/* 108 */     return objIBaseDAO.getAllDyncTableSplit();
/*     */   }
/*     */ 
/*     */   public String[] getAllDyncSplitFunction()
/*     */     throws Exception
/*     */   {
/* 117 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/* 118 */     return objIBaseDAO.getAllDyncSplitFunction();
/*     */   }
/*     */ 
/*     */   public MethodCenter[] getAllMethodCenter()
/*     */     throws Exception
/*     */   {
/* 127 */     IBaseDAO objIBaseDAO = (IBaseDAO)ServiceFactory.getService(IBaseDAO.class);
/* 128 */     return objIBaseDAO.getAllMethodCenter();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.service.base.impl.BaseSVImpl
 * JD-Core Version:    0.5.4
 */