package com.ai.appframe2.complex.self.dao.base.interfaces;

import com.ai.appframe2.complex.self.po.BOMask;
import com.ai.appframe2.complex.self.po.ClientTimeout;
import com.ai.appframe2.complex.self.po.DyncTableSplit;
import com.ai.appframe2.complex.self.po.IdGeneratorBean;
import com.ai.appframe2.complex.self.po.IdGeneratorWrapperBean;
import com.ai.appframe2.complex.self.po.MethodCenter;
import com.ai.appframe2.complex.self.po.TableSplit;
import com.ai.appframe2.complex.self.po.TableSplitMapping;

public abstract interface IBaseDAO
{
  public abstract ClientTimeout[] getAllClientTimeoutByServerName(String paramString)
    throws Exception;

  public abstract BOMask[] getAllBOMask()
    throws Exception;

  public abstract TableSplit[] getAllTableSplit()
    throws Exception;

  public abstract TableSplitMapping[] getAllTableSplitMapping()
    throws Exception;

  public abstract TableSplitMapping[] getAllTableSplitFunction()
    throws Exception;

  public abstract IdGeneratorBean[] getAllIdGenerator()
    throws Exception;

  public abstract IdGeneratorWrapperBean[] getAllIdGeneratorWrapper()
    throws Exception;

  public abstract DyncTableSplit[] getAllDyncTableSplit()
    throws Exception;

  public abstract String[] getAllDyncSplitFunction()
    throws Exception;

  public abstract MethodCenter[] getAllMethodCenter()
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.complex.self.dao.base.interfaces.IBaseDAO
 * JD-Core Version:    0.5.4
 */