/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ class ConditionClass extends ConditionData
/*     */ {
/*     */   String name;
/*     */   Class m_class;
/*     */ 
/*     */   public ConditionClass(String name, Class aClass)
/*     */   {
/* 586 */     this.name = name;
/* 587 */     this.m_class = aClass;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 591 */     return "Class: " + this.name;
/*     */   }
/*     */ 
/*     */   public Object getObject(Operation parent) {
/* 595 */     return this.m_class;
/*     */   }
/*     */   public void setObject(Operation parent, Object object) {
/* 598 */     this.m_class = ((Class)object);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ConditionClass
 * JD-Core Version:    0.5.4
 */