/*    */ package com.ai.appframe2.express;
/*    */ 
/*    */ public class ConditionData
/*    */ {
/*    */   protected Object DataObject;
/*    */   protected Class type;
/*    */ 
/*    */   public ConditionData()
/*    */   {
/*  9 */     this.DataObject = null;
/*    */   }
/*    */ 
/*    */   public ConditionData(Object obj, Class aType) {
/* 13 */     this.type = aType;
/* 14 */     this.DataObject = obj;
/*    */   }
/*    */   public Class getType(Operation parent) throws Exception {
/* 17 */     if (this.type != null) {
/* 18 */       return this.type;
/*    */     }
/* 20 */     Object obj = getObject(parent);
/* 21 */     if (obj == null) {
/* 22 */       return null;
/*    */     }
/* 24 */     return obj.getClass();
/*    */   }
/*    */   public Object getObject(Operation parent) throws Exception {
/* 27 */     return this.DataObject;
/*    */   }
/*    */   public void setObject(Operation parent, Object obj) {
/* 30 */     this.DataObject = obj;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 34 */     return this.DataObject.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ConditionData
 * JD-Core Version:    0.5.4
 */