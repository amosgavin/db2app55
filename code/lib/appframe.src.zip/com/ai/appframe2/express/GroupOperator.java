/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ class GroupOperator extends Operator
/*     */ {
/*     */   int a;
/*     */   int b;
/*     */ 
/*     */   public GroupOperator(int aa, int ab)
/*     */   {
/*  94 */     this.name = "group";
/*  95 */     this.a = aa;
/*  96 */     this.b = ab;
/*     */   }
/*     */ 
/*     */   public ConditionData execute(Operation parent, ConditionData[] list) throws Exception
/*     */   {
/* 101 */     return new ConditionData(new Long(this.a + this.b), Long.TYPE);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.GroupOperator
 * JD-Core Version:    0.5.4
 */