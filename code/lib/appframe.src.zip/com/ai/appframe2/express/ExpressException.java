/*   */ package com.ai.appframe2.express;
/*   */ 
/*   */ public class ExpressException extends Exception
/*   */ {
/*   */   public ExpressException(String message)
/*   */   {
/* 5 */     super(message);
/*   */   }
/*   */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ExpressException
 * JD-Core Version:    0.5.4
 */