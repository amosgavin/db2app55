/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ 
/*     */ final class Divide
/*     */ {
/*     */   static Object execute(Object op1, Object op2)
/*     */     throws Exception
/*     */   {
/*     */     boolean flag5;
/*     */     boolean flag4;
/*     */     boolean flag3;
/*     */     boolean flag2;
/*     */     boolean flag1;
/*  16 */     boolean flag = flag1 = flag2 = flag3 = flag4 = flag5 = 0;
/*     */ 
/*  18 */     if (op1 instanceof String) {
/*  19 */       flag = true;
/*     */     }
/*  21 */     else if (op1 instanceof Long) {
/*  22 */       flag2 = true;
/*     */     }
/*  24 */     else if (op1 instanceof Integer) {
/*  25 */       flag2 = true;
/*     */     }
/*  27 */     else if (op1 instanceof Double)
/*  28 */       flag4 = true;
/*  29 */     if (op2 instanceof String) {
/*  30 */       flag1 = true;
/*     */     }
/*  32 */     else if (op2 instanceof Long) {
/*  33 */       flag3 = true;
/*     */     }
/*  35 */     else if (op2 instanceof Integer) {
/*  36 */       flag3 = true;
/*     */     }
/*  38 */     else if (op2 instanceof Double)
/*  39 */       flag5 = true;
/*     */     Object obj;
/*  41 */     if (((flag2) && (((flag3) || (flag1)))) || ((flag3) && (flag)))
/*     */     {
/*  43 */       long l = 0L;
/*     */       try
/*     */       {
/*  46 */         if (flag2)
/*     */         {
/*  48 */           if (op1 instanceof Long)
/*  49 */             l = ((Long)op1).longValue();
/*     */           else
/*  51 */             l = ((Integer)op1).longValue();
/*     */         }
/*     */         else {
/*  54 */           l = Long.parseLong((String)op1);
/*     */         }
/*  56 */         if (flag3)
/*     */         {
/*  58 */           if (op2 instanceof Long)
/*  59 */             l /= ((Long)op2).longValue();
/*     */           else
/*  61 */             l /= ((Integer)op2).longValue();
/*     */         }
/*     */         else
/*  64 */           l /= Long.parseLong((String)op2);
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/*  68 */         throw new Exception("NumberFormatException : " + e.getMessage());
/*     */       }
/*     */ 
/*  71 */       obj = new Long(l);
/*     */     }
/*     */     else
/*     */     {
/*     */       Object obj;
/*  73 */       if (((flag4) && (((flag3) || (flag5) || (flag1)))) || ((flag5) && (((flag2) || (flag)))))
/*     */       {
/*  75 */         double d = 0.0D;
/*     */         try
/*     */         {
/*  78 */           if (flag4) {
/*  79 */             d = ((Double)op1).doubleValue();
/*     */           }
/*  81 */           else if (flag2)
/*     */           {
/*  83 */             if (op1 instanceof Long)
/*  84 */               d = ((Long)op1).doubleValue();
/*     */             else
/*  86 */               d = ((Integer)op1).doubleValue();
/*     */           }
/*     */           else {
/*  89 */             d = Double.parseDouble((String)op1);
/*     */           }
/*  91 */           if (flag5) {
/*  92 */             d /= ((Double)op2).doubleValue();
/*     */           }
/*  94 */           else if (flag3)
/*     */           {
/*  96 */             if (op2 instanceof Long)
/*  97 */               d /= ((Long)op2).doubleValue();
/*     */             else
/*  99 */               d /= ((Integer)op2).doubleValue();
/*     */           }
/*     */           else
/* 102 */             d /= Double.parseDouble((String)op2);
/*     */         }
/*     */         catch (NumberFormatException e)
/*     */         {
/* 106 */           throw new Exception("NumberFormatException :" + e.getMessage());
/*     */         }
/*     */ 
/* 109 */         obj = new Double(d);
/*     */       }
/*     */       else {
/* 112 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.express.datatype_error");
/* 113 */         throw new Exception(msg);
/*     */       }
/*     */     }
/*     */     Object obj;
/* 115 */     return obj;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.Divide
 * JD-Core Version:    0.5.4
 */