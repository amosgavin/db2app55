/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ class ConditionParameter extends ConditionData
/*     */ {
/*     */   String name;
/*     */ 
/*     */   public ConditionParameter(String name)
/*     */   {
/* 528 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 533 */     return this.name;
/*     */   }
/*     */   public Object getObject(Operation parent) {
/*     */     try {
/* 537 */       return parent.getParameterValue(this.name);
/*     */     } catch (Exception e) {
/*     */     }
/* 540 */     return null;
/*     */   }
/*     */   public void setObject(Operation parent, Object object) {
/*     */     try {
/* 544 */       parent.setParameterValue(this.name, object);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ConditionParameter
 * JD-Core Version:    0.5.4
 */