/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ 
/*     */ class ExpressDataType
/*     */ {
/*     */   public static Class getSimpleDataType(Class aClass)
/*     */   {
/*  24 */     if (Integer.class.equals(aClass)) return Integer.TYPE;
/*  25 */     if (Short.class.equals(aClass)) return Short.TYPE;
/*  26 */     if (Long.class.equals(aClass)) return Long.TYPE;
/*  27 */     if (Double.class.equals(aClass)) return Double.TYPE;
/*  28 */     if (Float.class.equals(aClass)) return Float.TYPE;
/*  29 */     if (Byte.class.equals(aClass)) return Byte.TYPE;
/*  30 */     if (Character.class.equals(aClass)) return Character.TYPE;
/*  31 */     if (Boolean.class.equals(aClass)) return Boolean.TYPE;
/*  32 */     return aClass;
/*     */   }
/*     */ 
/*     */   public static Object transfer(Object value, Class type) {
/*  36 */     if (value == null) return null;
/*  37 */     if ((value instanceof String) && (value.toString().trim().equals(""))) {
/*  38 */       if (type.equals(String.class)) {
/*  39 */         return value;
/*     */       }
/*  41 */       return null;
/*     */     }
/*  43 */     if ((Short.class.equals(type)) || (Short.TYPE.equals(type))) {
/*  44 */       if (value instanceof Short) {
/*  45 */         return value;
/*     */       }
/*  47 */       return new Short(new BigDecimal(value.toString()).shortValue());
/*  48 */     }if ((Integer.class.equals(type)) || (Integer.TYPE.equals(type))) {
/*  49 */       if (value instanceof Integer) {
/*  50 */         return value;
/*     */       }
/*  52 */       return new Integer(new BigDecimal(value.toString()).intValue());
/*  53 */     }if ((Character.class.equals(type)) || (Character.TYPE.equals(type))) {
/*  54 */       if (value instanceof Character) {
/*  55 */         return value;
/*     */       }
/*  57 */       return new Character(value.toString().charAt(0));
/*  58 */     }if ((Long.class.equals(type)) || (Long.TYPE.equals(type))) {
/*  59 */       if (value instanceof Long) {
/*  60 */         return value;
/*     */       }
/*  62 */       return new Long(new BigDecimal(value.toString()).longValue());
/*  63 */     }if (String.class.equals(type)) {
/*  64 */       if (value instanceof String) {
/*  65 */         return value;
/*     */       }
/*  67 */       return value.toString();
/*  68 */     }if ((Double.class.equals(type)) || (Double.TYPE.equals(type))) {
/*  69 */       if (value instanceof Double) {
/*  70 */         return value;
/*     */       }
/*  72 */       return new Double(new BigDecimal(value.toString()).doubleValue());
/*  73 */     }if ((Float.class.equals(type)) || (Float.TYPE.equals(type))) {
/*  74 */       if (value instanceof Float) {
/*  75 */         return value;
/*     */       }
/*  77 */       return new Float(new BigDecimal(value.toString()).floatValue());
/*  78 */     }if ((Byte.class.equals(type)) || (Byte.TYPE.equals(type))) {
/*  79 */       if (value instanceof Byte) {
/*  80 */         return value;
/*     */       }
/*  82 */       return new Byte(new BigDecimal(value.toString()).byteValue());
/*  83 */     }if ((Boolean.class.equals(type)) || (Boolean.TYPE.equals(type))) {
/*  84 */       if (value instanceof Boolean)
/*  85 */         return value;
/*  86 */       if (value instanceof Number) {
/*  87 */         if (((Number)value).doubleValue() > 0.0D) {
/*  88 */           return new Boolean(true);
/*     */         }
/*  90 */         return new Boolean(false);
/*  91 */       }if (value instanceof String) {
/*  92 */         if ((((String)value).equalsIgnoreCase("true")) || (((String)value).equalsIgnoreCase("y"))) {
/*  93 */           return new Boolean(true);
/*     */         }
/*  95 */         return new Boolean(false);
/*     */       }
/*  97 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.datatype_transform_error", new String[] { value.toString(), "Boolean" });
/*  98 */       throw new RuntimeException(msg);
/*     */     }
/*     */ 
/* 101 */     return value;
/*     */   }
/*     */ 
/*     */   static boolean isAssignable(Class lhsType, Class rhsType)
/*     */   {
/* 106 */     if (lhsType == null)
/* 107 */       return false;
/* 108 */     if (rhsType == null) {
/* 109 */       return !lhsType.isPrimitive();
/*     */     }
/* 111 */     if ((lhsType.isPrimitive()) && (rhsType.isPrimitive())) {
/* 112 */       if (lhsType == rhsType) {
/* 113 */         return true;
/*     */       }
/* 115 */       if ((rhsType == Byte.TYPE) && (((lhsType == Short.TYPE) || (lhsType == Integer.TYPE) || (lhsType == Long.TYPE) || (lhsType == Float.TYPE) || (lhsType == Double.TYPE))))
/*     */       {
/* 119 */         return true;
/*     */       }
/* 121 */       if ((rhsType == Short.TYPE) && (((lhsType == Integer.TYPE) || (lhsType == Long.TYPE) || (lhsType == Float.TYPE) || (lhsType == Double.TYPE))))
/*     */       {
/* 124 */         return true;
/*     */       }
/* 126 */       if ((rhsType == Character.TYPE) && (((lhsType == Integer.TYPE) || (lhsType == Long.TYPE) || (lhsType == Float.TYPE) || (lhsType == Double.TYPE))))
/*     */       {
/* 129 */         return true;
/*     */       }
/* 131 */       if ((rhsType == Integer.TYPE) && (((lhsType == Long.TYPE) || (lhsType == Float.TYPE) || (lhsType == Double.TYPE))))
/*     */       {
/* 134 */         return true;
/*     */       }
/* 136 */       if ((rhsType == Long.TYPE) && (((lhsType == Float.TYPE) || (lhsType == Double.TYPE))))
/*     */       {
/* 138 */         return true;
/*     */       }
/* 140 */       if ((rhsType == Float.TYPE) && (lhsType == Double.TYPE)) {
/* 141 */         return true;
/*     */       }
/*     */     }
/* 144 */     else if (lhsType.isAssignableFrom(rhsType)) {
/* 145 */       return true;
/*     */     }
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   static boolean isSignatureAssignable(Class[] from, Class[] to) {
/* 151 */     for (int i = 0; i < from.length; ++i)
/* 152 */       if (!isAssignable(to[i], from[i]))
/* 153 */         return false;
/* 154 */     return true;
/*     */   }
/*     */ 
/*     */   static int findMostSpecificSignature(Class[] idealMatch, Class[][] candidates) {
/* 158 */     Class[] bestMatch = null;
/* 159 */     int bestMatchIndex = -1;
/*     */ 
/* 161 */     for (int i = candidates.length - 1; i >= 0; --i) {
/* 162 */       Class[] targetMatch = candidates[i];
/* 163 */       if ((!isSignatureAssignable(idealMatch, targetMatch)) || ((bestMatch != null) && (!isSignatureAssignable(targetMatch, bestMatch)))) {
/*     */         continue;
/*     */       }
/* 166 */       bestMatch = targetMatch;
/* 167 */       bestMatchIndex = i;
/*     */     }
/*     */ 
/* 171 */     if (bestMatch != null) {
/* 172 */       return bestMatchIndex;
/*     */     }
/* 174 */     return -1;
/*     */   }
/*     */ 
/*     */   static Method findMethod(Class baseClass, String methodName, Class[] types, boolean publicOnly, boolean isStatic)
/*     */   {
/* 181 */     Vector candidates = gatherMethodsRecursive(baseClass, methodName, types.length, publicOnly, isStatic, null);
/*     */ 
/* 183 */     Method method = findMostSpecificMethod(types, (Method[])(Method[])candidates.toArray(new Method[0]));
/*     */ 
/* 187 */     return method;
/*     */   }
/*     */ 
/*     */   static Constructor findConstructor(Class baseClass, Class[] types) {
/* 191 */     Constructor[] constructors = baseClass.getConstructors();
/* 192 */     Class[][] candidateSigs = new Class[constructors.length][];
/* 193 */     List list = new ArrayList();
/* 194 */     for (int i = 0; i < constructors.length; ++i) {
/* 195 */       if (constructors[i].getParameterTypes().length == types.length) {
/* 196 */         list.add(constructors[i].getParameterTypes());
/*     */       }
/*     */     }
/*     */ 
/* 200 */     int match = findMostSpecificSignature(types, (Class[][])(Class[][])list.toArray(new Class[0][]));
/* 201 */     return (match == -1) ? null : constructors[match];
/*     */   }
/*     */ 
/*     */   static Method findMostSpecificMethod(Class[] idealMatch, Method[] methods)
/*     */   {
/* 207 */     Class[][] candidateSigs = new Class[methods.length][];
/* 208 */     for (int i = 0; i < methods.length; ++i) {
/* 209 */       candidateSigs[i] = methods[i].getParameterTypes();
/*     */     }
/* 211 */     int match = findMostSpecificSignature(idealMatch, candidateSigs);
/* 212 */     return (match == -1) ? null : methods[match];
/*     */   }
/*     */ 
/*     */   private static Vector gatherMethodsRecursive(Class baseClass, String methodName, int numArgs, boolean publicOnly, boolean isStatic, Vector candidates)
/*     */   {
/* 219 */     if (candidates == null) {
/* 220 */       candidates = new Vector();
/*     */     }
/*     */ 
/* 223 */     addCandidates(baseClass.getDeclaredMethods(), methodName, numArgs, publicOnly, isStatic, candidates);
/*     */ 
/* 226 */     Class[] intfs = baseClass.getInterfaces();
/* 227 */     for (int i = 0; i < intfs.length; ++i) {
/* 228 */       gatherMethodsRecursive(intfs[i], methodName, numArgs, publicOnly, isStatic, candidates);
/*     */     }
/*     */ 
/* 232 */     Class superclass = baseClass.getSuperclass();
/* 233 */     if (superclass != null) {
/* 234 */       gatherMethodsRecursive(superclass, methodName, numArgs, publicOnly, isStatic, candidates);
/*     */     }
/*     */ 
/* 237 */     return candidates;
/*     */   }
/*     */ 
/*     */   private static Vector addCandidates(Method[] methods, String methodName, int numArgs, boolean publicOnly, boolean isStatic, Vector candidates)
/*     */   {
/* 243 */     for (int i = 0; i < methods.length; ++i) {
/* 244 */       Method m = methods[i];
/* 245 */       if ((!m.getName().equals(methodName)) || (m.getParameterTypes().length != numArgs) || ((publicOnly) && (((!isPublic(m)) || ((isStatic) && (!isStatic(m)))))))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 250 */       candidates.add(m);
/*     */     }
/* 252 */     return candidates;
/*     */   }
/*     */ 
/*     */   private static boolean isPublic(Class c) {
/* 256 */     return Modifier.isPublic(c.getModifiers());
/*     */   }
/*     */ 
/*     */   private static boolean isPublic(Method m) {
/* 260 */     return Modifier.isPublic(m.getModifiers());
/*     */   }
/*     */   private static boolean isStatic(Method m) {
/* 263 */     return Modifier.isStatic(m.getModifiers());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ExpressDataType
 * JD-Core Version:    0.5.4
 */