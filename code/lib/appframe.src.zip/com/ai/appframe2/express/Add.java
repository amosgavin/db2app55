/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ 
/*     */ public final class Add
/*     */ {
/*     */   public static Object execute(Object op1, Object op2)
/*     */     throws Exception
/*     */   {
/*  19 */     Object result = null;
/*     */     boolean flag5;
/*     */     boolean flag4;
/*     */     boolean flag3;
/*     */     boolean flag2;
/*     */     boolean flag1;
/*  25 */     boolean flag = flag1 = flag2 = flag3 = flag4 = flag5 = 0;
/*     */ 
/*  27 */     if (op1 instanceof String) {
/*  28 */       flag = true;
/*     */     }
/*  30 */     else if (op1 instanceof Long) {
/*  31 */       flag2 = true;
/*     */     }
/*  33 */     else if (op1 instanceof Integer) {
/*  34 */       flag2 = true;
/*     */     }
/*  36 */     else if (op1 instanceof Double)
/*  37 */       flag4 = true;
/*  38 */     if (op2 instanceof String) {
/*  39 */       flag1 = true;
/*     */     }
/*  41 */     else if (op2 instanceof Long) {
/*  42 */       flag3 = true;
/*     */     }
/*  44 */     else if (op2 instanceof Integer) {
/*  45 */       flag3 = true;
/*     */     }
/*  47 */     else if (op2 instanceof Double)
/*  48 */       flag5 = true;
/*  49 */     if (flag) {
/*  50 */       result = (String)op1 + op2;
/*     */     }
/*  52 */     else if ((flag2) && (((flag3) || (flag1))))
/*     */     {
/*  54 */       long l = 0L;
/*     */       try
/*     */       {
/*  57 */         if (flag2)
/*     */         {
/*  59 */           if (op1 instanceof Long)
/*  60 */             l = ((Long)op1).longValue();
/*     */           else
/*  62 */             l = ((Integer)op1).longValue();
/*     */         }
/*     */         else {
/*  65 */           l = Long.parseLong((String)op1);
/*     */         }
/*  67 */         if (flag3)
/*     */         {
/*  69 */           if (op2 instanceof Long)
/*  70 */             l += ((Long)op2).longValue();
/*     */           else
/*  72 */             l += ((Integer)op2).longValue();
/*     */         }
/*     */         else
/*  75 */           l += Long.parseLong((String)op2);
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/*  79 */         throw new Exception("NumberFormatException :" + e.getMessage());
/*     */       }
/*  81 */       result = new Long(l);
/*     */     }
/*  83 */     else if (((flag4) && (((flag3) || (flag5) || (flag1)))) || ((flag5) && (flag2)))
/*     */     {
/*  85 */       double d = 0.0D;
/*     */       try
/*     */       {
/*  89 */         BigDecimal decimal = new BigDecimal(op1.toString());
/*  90 */         decimal = decimal.add(new BigDecimal(op2.toString()));
/*     */ 
/* 117 */         d = decimal.doubleValue();
/*     */       }
/*     */       catch (NumberFormatException e) {
/* 120 */         throw new Exception("NumberFormatException :" + e.getMessage());
/*     */       }
/* 122 */       result = new Double(d);
/*     */     } else {
/* 124 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.express.datatype_error");
/* 125 */       throw new Exception(msg);
/*     */     }
/* 127 */     return result;
/*     */   }
/*     */   public static void main(String[] args) throws Exception {
/* 130 */     System.out.println(execute(new Integer(100), "a0").toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.Add
 * JD-Core Version:    0.5.4
 */