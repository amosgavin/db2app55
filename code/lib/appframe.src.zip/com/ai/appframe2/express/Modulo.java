/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ 
/*     */ final class Modulo
/*     */ {
/*     */   static Object execute(Object op1, Object op2)
/*     */     throws Exception
/*     */   {
/*   9 */     Object result = null;
/*     */     boolean flag5;
/*     */     boolean flag4;
/*     */     boolean flag3;
/*     */     boolean flag2;
/*     */     boolean flag1;
/*  15 */     boolean flag = flag1 = flag2 = flag3 = flag4 = flag5 = 0;
/*     */ 
/*  17 */     if (op1 instanceof String) {
/*  18 */       flag = true;
/*     */     }
/*  20 */     else if (op1 instanceof Long) {
/*  21 */       flag2 = true;
/*     */     }
/*  23 */     else if (op1 instanceof Integer) {
/*  24 */       flag2 = true;
/*     */     }
/*  26 */     else if (op1 instanceof Double)
/*  27 */       flag4 = true;
/*  28 */     if (op2 instanceof String) {
/*  29 */       flag1 = true;
/*     */     }
/*  31 */     else if (op2 instanceof Long) {
/*  32 */       flag3 = true;
/*     */     }
/*  34 */     else if (op2 instanceof Integer) {
/*  35 */       flag3 = true;
/*     */     }
/*  37 */     else if (op2 instanceof Double)
/*  38 */       flag5 = true;
/*  39 */     if (((flag2) && (((flag3) || (flag1)))) || ((flag3) && (flag)))
/*     */     {
/*  41 */       long l = 0L;
/*     */       try
/*     */       {
/*  44 */         if (flag2)
/*     */         {
/*  46 */           if (op1 instanceof Long)
/*  47 */             l = ((Long)op1).longValue();
/*     */           else
/*  49 */             l = ((Integer)op1).longValue();
/*     */         }
/*     */         else {
/*  52 */           l = Long.parseLong((String)op1);
/*     */         }
/*  54 */         if (flag3)
/*     */         {
/*  56 */           if (op2 instanceof Long)
/*  57 */             l %= ((Long)op2).longValue();
/*     */           else
/*  59 */             l %= ((Integer)op2).longValue();
/*     */         }
/*     */         else
/*  62 */           l %= Long.parseLong((String)op2);
/*     */       }
/*     */       catch (NumberFormatException e) {
/*  65 */         throw new Exception("NumberFormatException :" + e.getMessage());
/*     */       }
/*  67 */       result = new Long(l);
/*     */     }
/*  69 */     else if (((flag4) && (((flag3) || (flag5) || (flag1)))) || ((flag5) && (((flag2) || (flag)))))
/*     */     {
/*  71 */       double d = 0.0D;
/*     */       try
/*     */       {
/*  74 */         if (flag4) {
/*  75 */           d = ((Double)op1).doubleValue();
/*     */         }
/*  77 */         else if (flag2)
/*     */         {
/*  79 */           if (op1 instanceof Long)
/*  80 */             d = ((Long)op1).doubleValue();
/*     */           else
/*  82 */             d = ((Integer)op1).doubleValue();
/*     */         }
/*     */         else {
/*  85 */           d = Double.parseDouble((String)op1);
/*     */         }
/*  87 */         if (flag5) {
/*  88 */           d %= ((Double)op2).doubleValue();
/*     */         }
/*  90 */         else if (flag3)
/*     */         {
/*  92 */           if (op2 instanceof Long)
/*  93 */             d %= ((Long)op2).doubleValue();
/*     */           else
/*  95 */             d %= ((Integer)op2).doubleValue();
/*     */         }
/*     */         else
/*  98 */           d %= Double.parseDouble((String)op2);
/*     */       }
/*     */       catch (NumberFormatException e) {
/* 101 */         throw new Exception("NumberFormatException :" + e.getMessage());
/*     */       }
/* 103 */       result = new Double(d);
/*     */     }
/*     */     else {
/* 106 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.express.datatype_error");
/* 107 */       throw new Exception(msg);
/*     */     }
/* 109 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.Modulo
 * JD-Core Version:    0.5.4
 */