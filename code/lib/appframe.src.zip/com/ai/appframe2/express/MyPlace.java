package com.ai.appframe2.express;

class MyPlace
{
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.MyPlace
 * JD-Core Version:    0.5.4
 */