/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ class ConditionAttr extends ConditionData
/*     */ {
/*     */   String name;
/*     */ 
/*     */   public ConditionAttr(String name)
/*     */   {
/* 554 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*     */     try {
/* 559 */       return "Condition Attr: " + this.name;
/*     */     } catch (Exception ex) {
/*     */     }
/* 562 */     return ex.getMessage();
/*     */   }
/*     */ 
/*     */   public Object getObject(Operation parent) throws Exception {
/* 566 */     return parent.getAttrValue(this.name);
/*     */   }
/*     */ 
/*     */   public Class getType(Operation parent) throws Exception {
/* 570 */     return parent.getAttrValueClassType(this.name);
/*     */   }
/*     */   public void setObject(Operation parent, Object object) {
/*     */     try {
/* 574 */       parent.setAttrValue(this.name, object);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.ConditionAttr
 * JD-Core Version:    0.5.4
 */