/*     */ package com.ai.appframe2.express;
/*     */ 
/*     */ class OpStr
/*     */ {
/*     */   public String Name;
/*     */   public int PRI;
/*     */   public int Combine;
/*     */   public int OpDataMember;
/*     */ 
/*     */   public OpStr(String name, int pri, int combine, int aOpDataMember)
/*     */   {
/* 316 */     this.Name = name;
/* 317 */     this.PRI = pri;
/* 318 */     this.Combine = combine;
/* 319 */     this.OpDataMember = aOpDataMember;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.express.OpStr
 * JD-Core Version:    0.5.4
 */