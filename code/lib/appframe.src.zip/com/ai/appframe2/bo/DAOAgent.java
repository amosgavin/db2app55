/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import sun.jdbc.rowset.CachedRowSet;
/*     */ 
/*     */ public class DAOAgent
/*     */   implements Serializable
/*     */ {
/*     */   public static final int STRING = 0;
/*     */   public static final int INT = 1;
/*     */   public static final int FLOAT = 2;
/*     */   public static final int DATE = 3;
/*     */   public static final int DATETIME = 4;
/*     */   public static final int DOUBLE = 5;
/*     */   public static final int BYTE = 6;
/*     */   public static final int BOOLEAN = 7;
/*     */   public static final int LONG = 8;
/*     */   public static final int CHAR = 9;
/*     */   private static final String DATATYPE_STRING = "String";
/*     */   private static final String DATATYPE_INTEGER = "Integer";
/*     */   private static final String DATATYPE_LONG = "Long";
/*     */   private static final String DATATYPE_DOUBLE = "Double";
/*     */   private static final String DATATYPE_FLOAT = "Float";
/*     */   private static final String DATATYPE_BYTE = "Byte";
/*     */   private static final String DATATYPE_BOOLEAN = "Boolean";
/*     */   private static final String DATATYPE_DATE = "Date";
/*     */   private static final String DATATYPE_DATETIME = "DateTime";
/*     */   private static final String DATATYPE_CHAR = "Char";
/*  42 */   private static String sourceURL = "";
/*  43 */   private static String JNDIFactory = "";
/*  44 */   private SQLWarning SQLWarning = null;
/*     */ 
/*  47 */   private static String sysConfigPath = "";
/*  48 */   private String errorMessage = "";
/*     */ 
/*     */   public Connection getConnection(String aDataSourceName)
/*     */     throws Exception
/*     */   {
/*  59 */     return ServiceManager.getSession().getNewConnection(aDataSourceName);
/*     */   }
/*     */ 
/*     */   public CachedRowSet query(String aPrepSQL, StatementArgumentHelper aArg, String aDataSourceName)
/*     */     throws Exception
/*     */   {
/*  71 */     long lStart = System.currentTimeMillis();
/*  72 */     CachedRowSet objCRS = null;
/*  73 */     Connection objConn = null;
/*  74 */     boolean hasException = false;
/*  75 */     Exception objExcption = null;
/*  76 */     String strError = "";
/*     */ 
/*  78 */     objCRS = new CachedRowSet();
/*  79 */     objCRS.setCommand(aPrepSQL);
/*  80 */     prepStatementValues(objCRS, aArg);
/*  81 */     objConn = getConnection(aDataSourceName);
/*  82 */     if (objConn != null)
/*     */     {
/*     */       try
/*     */       {
/*  93 */         throw new AIException(strError);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/*  87 */         hasException = true;
/*     */ 
/*  93 */         throw new AIException(strError);
/*     */       }
/*     */       finally
/*     */       {
/*  91 */         releaseConnection(objConn);
/*  92 */         if (hasException) {
/*  93 */           throw new AIException(strError);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  99 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DAOAgent.datasrc_conn_error");
/* 100 */       throw new AIException(msg + aDataSourceName);
/*     */     }
/* 102 */     return objCRS;
/*     */   }
/*     */ 
/*     */   public CachedRowSet query(String aPrepSQL, StatementArgumentHelper aArg, Connection aConn) throws Exception
/*     */   {
/* 107 */     long lStart = System.currentTimeMillis();
/* 108 */     CachedRowSet objCRS = null;
/* 109 */     Connection objConn = null;
/* 110 */     boolean hasException = false;
/* 111 */     String strError = "";
/* 112 */     objCRS = new CachedRowSet();
/*     */ 
/* 114 */     objCRS.setCommand(aPrepSQL);
/* 115 */     prepStatementValues(objCRS, aArg);
/* 116 */     objConn = aConn;
/* 117 */     if (objConn != null)
/*     */     {
/*     */       try
/*     */       {
/* 128 */         throw new AIException(strError);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 122 */         hasException = true;
/*     */ 
/* 128 */         throw new AIException(strError);
/*     */       }
/*     */       finally
/*     */       {
/* 127 */         if (hasException)
/* 128 */           throw new AIException(strError);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 133 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DAOAgent.datasrc_conn_null");
/* 134 */       throw new AIException(msg);
/*     */     }
/* 136 */     return objCRS;
/*     */   }
/*     */ 
/*     */   public int[] batchExecuteNonSelect(String[] aPrepSQLs, String aDataSourceNames)
/*     */     throws Exception
/*     */   {
/* 151 */     long lStart = System.currentTimeMillis();
/* 152 */     Connection objConn = null;
/* 153 */     Statement objStam = null;
/* 154 */     boolean hasException = false;
/* 155 */     String strError = "";
/* 156 */     int[] flag = null;
/*     */     try {
/* 158 */       objConn = getConnection(aDataSourceNames);
/*     */ 
/* 160 */       objStam = objConn.createStatement();
/* 161 */       for (int i = 0; (aPrepSQLs != null) && (i < aPrepSQLs.length); ++i) {
/* 162 */         objStam.addBatch(aPrepSQLs[i]);
/*     */       }
/* 164 */       flag = objStam.executeBatch();
/* 165 */       objStam.close();
/*     */ 
/* 175 */       throw new AIException(strError);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 169 */       hasException = true;
/*     */ 
/* 175 */       throw new AIException(strError);
/*     */     }
/*     */     finally
/*     */     {
/* 173 */       releaseConnection(objConn);
/* 174 */       if (hasException)
/* 175 */         throw new AIException(strError);
/*     */     }
/* 177 */     return flag;
/*     */   }
/*     */ 
/*     */   public int[] batchExecuteNonSelect(String[] aPrepSQLs, Connection aConn) throws Exception {
/* 181 */     long lStart = System.currentTimeMillis();
/* 182 */     Connection objConn = aConn;
/* 183 */     Statement objStam = null;
/* 184 */     boolean hasException = false;
/* 185 */     String strError = "";
/* 186 */     int[] flag = null;
/*     */     try {
/* 188 */       objStam = objConn.createStatement();
/* 189 */       for (int i = 0; (aPrepSQLs != null) && (i < aPrepSQLs.length); ++i) {
/* 190 */         objStam.addBatch(aPrepSQLs[i]);
/*     */       }
/*     */ 
/* 200 */       throw new AIException(strError);
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 195 */       hasException = true;
/*     */ 
/* 200 */       throw new AIException(strError);
/*     */     }
/*     */     finally
/*     */     {
/* 199 */       if (hasException)
/* 200 */         throw new AIException(strError);
/*     */     }
/* 202 */     return flag;
/*     */   }
/*     */ 
/*     */   public Connection beginTransation(String aDataSource)
/*     */     throws Exception
/*     */   {
/* 227 */     Connection objConn = getConnection(aDataSource);
/* 228 */     objConn.setAutoCommit(false);
/* 229 */     return objConn;
/*     */   }
/*     */ 
/*     */   public void commit(Connection aConn) throws Exception {
/* 233 */     aConn.commit();
/*     */ 
/* 235 */     aConn.close();
/* 236 */     aConn = null;
/*     */   }
/*     */ 
/*     */   public void rollback(Connection aConn) throws Exception {
/* 240 */     aConn.rollback();
/*     */ 
/* 242 */     aConn.close();
/* 243 */     aConn = null;
/*     */   }
/*     */ 
/*     */   private void prepStatementValues(CachedRowSet aCRS, StatementArgumentHelper aArg)
/*     */     throws Exception
/*     */   {
/* 249 */     if ((aArg == null) || (aCRS == null))
/* 250 */       return;
/* 251 */     for (int i = 0; (aArg != null) && (i < aArg.length()); ++i) {
/* 252 */       Object objValue = aArg.getValues()[i];
/* 253 */       Object objValueType = aArg.getValueTypes()[i];
/* 254 */       if (objValue == null) continue; if (objValueType == null)
/*     */         continue;
/* 256 */       switch (Integer.parseInt(objValueType.toString()))
/*     */       {
/*     */       case 0:
/*     */       case 9:
/* 259 */         aCRS.setString(i + 1, objValue.toString());
/* 260 */         break;
/*     */       case 1:
/* 262 */         aCRS.setInt(i + 1, Integer.parseInt(objValue.toString()));
/* 263 */         break;
/*     */       case 8:
/* 265 */         aCRS.setLong(i + 1, Long.parseLong(objValue.toString()));
/* 266 */         break;
/*     */       case 2:
/* 268 */         aCRS.setFloat(i + 1, Float.parseFloat(objValue.toString()));
/* 269 */         break;
/*     */       case 3:
/* 271 */         if (objValue instanceof Date)
/* 272 */           aCRS.setDate(i + 1, (Date)(Date)objValue);
/*     */         else
/* 274 */           aCRS.setDate(i + 1, Date.valueOf(objValue.toString()));
/* 275 */         break;
/*     */       case 4:
/* 277 */         if (objValue instanceof Timestamp)
/* 278 */           aCRS.setTimestamp(i + 1, (Timestamp)(Timestamp)objValue);
/*     */         else
/* 280 */           aCRS.setTimestamp(i + 1, Timestamp.valueOf(aArg.getValues()[i].toString()));
/* 281 */         break;
/*     */       case 5:
/*     */       case 6:
/*     */       case 7:
/*     */       default:
/* 283 */         aCRS.setObject(i + 1, aArg.getValues()[i]);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void releaseConnection(Connection aConn)
/*     */   {
/*     */     try
/*     */     {
/* 296 */       if ((aConn != null) && (!aConn.isClosed())) {
/* 297 */         aConn.close();
/* 298 */         aConn = null;
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 302 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private int transSQLTypeToInt(String aStrType) {
/* 307 */     if (aStrType.trim().equalsIgnoreCase("String")) {
/* 308 */       return 0;
/*     */     }
/* 310 */     if (aStrType.trim().equalsIgnoreCase("Integer")) {
/* 311 */       return 1;
/*     */     }
/* 313 */     if (aStrType.trim().equalsIgnoreCase("Float")) {
/* 314 */       return 2;
/*     */     }
/* 316 */     if (aStrType.trim().equalsIgnoreCase("Date")) {
/* 317 */       return 3;
/*     */     }
/* 319 */     if (aStrType.trim().equalsIgnoreCase("DateTime")) {
/* 320 */       return 4;
/*     */     }
/* 322 */     if (aStrType.trim().equalsIgnoreCase("Byte")) {
/* 323 */       return 6;
/*     */     }
/* 325 */     if (aStrType.trim().equalsIgnoreCase("Double")) {
/* 326 */       return 5;
/*     */     }
/* 328 */     if (aStrType.trim().equalsIgnoreCase("Long")) {
/* 329 */       return 8;
/*     */     }
/* 331 */     if (aStrType.trim().equalsIgnoreCase("Boolean")) {
/* 332 */       return 7;
/*     */     }
/* 334 */     if (aStrType.trim().equalsIgnoreCase("Char")) {
/* 335 */       return 9;
/*     */     }
/*     */ 
/* 338 */     return -1;
/*     */   }
/*     */ 
/*     */   public String getUserDataDivCondiction(String aDataTableName, String aUserID)
/*     */     throws Exception
/*     */   {
/* 388 */     int count = 1;
/* 389 */     Connection conn = null;
/* 390 */     ResultSet rs = null;
/* 391 */     PreparedStatement pstam = null;
/* 392 */     StringBuilder strCond = new StringBuilder();
/* 393 */     StringBuilder strTabCond = new StringBuilder();
/* 394 */     String div_rule = "";
/* 395 */     String user_column = "";
/* 396 */     String div_column = "";
/* 397 */     String rule_table = "";
/* 398 */     String rule_column_main = "";
/* 399 */     String rule_column_vis = "";
/* 400 */     String div_mode = "";
/* 401 */     String strTableNames = "";
/* 402 */     boolean flag = false;
/*     */     try {
/* 404 */       conn = getConnection("UserDataSource");
/* 405 */       pstam = conn.prepareStatement("select a.div_column,a.div_mode,b.role_table,b.div_rule,b.rule_table,b.user_column,b.rule_column_main,b.rule_column_vis from sm_data_divcfg a,sm_data_divtype b where a.table_name = ? and a.divtype_code = b.divtype_code and a.active_flag = ? and b.active_flag = ?");
/* 406 */       pstam.setString(1, aDataTableName);
/* 407 */       pstam.setString(2, "1");
/* 408 */       pstam.setString(3, "1");
/* 409 */       strCond.append(" sm_user.row_id = '").append(aUserID).append("' and ");
/* 410 */       rs = pstam.executeQuery();
/* 411 */       while ((rs != null) && 
/* 412 */         (rs.next())) {
/* 413 */         flag = true;
/* 414 */         div_rule = rs.getString("div_rule");
/* 415 */         div_column = rs.getString("div_column");
/* 416 */         user_column = rs.getString("user_column");
/* 417 */         if (div_rule.equalsIgnoreCase("TAB")) {
/* 418 */           rule_table = rs.getString("rule_table");
/* 419 */           rule_column_main = rs.getString("rule_column_main");
/* 420 */           rule_column_vis = rs.getString("rule_column_vis");
/* 421 */           strTableNames = "sm_user," + rule_table + " where (";
/* 422 */           if (count > 1) {
/* 423 */             strTabCond.append(div_mode);
/*     */           }
/* 425 */           strTabCond.append(" (sm_user.").append(user_column);
/* 426 */           strTabCond.append(" = ").append(rule_table).append(".").append(rule_column_main);
/* 427 */           strTabCond.append(" and ").append(rule_table).append(".").append(rule_column_vis);
/* 428 */           strTabCond.append(" = ").append(aDataTableName).append(".").append(div_column).append(" ) ");
/* 429 */           div_mode = rs.getString("div_mode");
/*     */         }
/*     */         else {
/* 432 */           strTableNames = "sm_user where (";
/* 433 */           strCond.append("sm_user.").append(user_column).append(" = ").append(aDataTableName).append(".").append(div_column);
/* 434 */           break;
/*     */         }
/* 436 */         ++count;
/*     */       }
/*     */ 
/* 439 */       if (strTabCond.length() != 0) {
/* 440 */         strTabCond.insert(0, " ( ");
/* 441 */         strTabCond.insert(strTabCond.length(), " ) ");
/*     */       }
/* 443 */       rs.close();
/* 444 */       pstam.close();
/*     */     }
/*     */     catch (Exception e) {
/* 447 */       e.printStackTrace();
/*     */     }
/*     */     finally {
/* 450 */       releaseConnection(conn);
/*     */     }
/* 452 */     if (flag) {
/* 453 */       strCond.insert(0, strTableNames).append(strTabCond).append(" )");
/* 454 */       return strCond.toString();
/*     */     }
/*     */ 
/* 457 */     return "";
/*     */   }
/*     */ 
/*     */   private String cacultWestTome(long lStart)
/*     */   {
/* 462 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DAOAgent.sql_time_cost");
/* 463 */     StringBuilder str = new StringBuilder(msg);
/* 464 */     str.append(System.currentTimeMillis() - lStart).append(" MS");
/* 465 */     return str.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*     */     try {
/* 470 */       DAOAgent objDao = new DAOAgent();
/*     */ 
/* 473 */       objDao.query("select * from tab", null, "UserDataSource");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 484 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DAOAgent
 * JD-Core Version:    0.5.4
 */