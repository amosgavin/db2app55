/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.TextElement;
/*     */ 
/*     */ public class Mapingenty extends TextElement
/*     */ {
/*  18 */   public static String _tagName = "mapingenty";
/*     */ 
/*  20 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Mapingenty()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Mapingenty(String text)
/*     */   {
/*  35 */     super(text);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  43 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  52 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/*  60 */     Element elem = super.marshal();
/*     */ 
/*  62 */     elem.addAttribute(this.type.marshal());
/*  63 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Mapingenty unmarshal(Element elem)
/*     */   {
/*  71 */     Mapingenty __objMapingenty = (Mapingenty)TextElement.unmarshal(elem, new Mapingenty());
/*  72 */     if (__objMapingenty != null)
/*     */     {
/*  75 */       __objMapingenty.type.setValue(elem.getAttribute("type"));
/*     */     }
/*  77 */     return __objMapingenty;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/*  94 */     ErrorList errors = new ErrorList();
/*     */ 
/*  97 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 106 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Mapingenty
 * JD-Core Version:    0.5.4
 */