package com.ai.appframe2.bo.boinfo;

public abstract interface OperationArgInterface
{
  public abstract void setType(String paramString);

  public abstract String getType();

  public abstract void setValue(String paramString);

  public abstract String getValue();

  public abstract void setDataType(String paramString);

  public abstract String getDataType();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.OperationArgInterface
 * JD-Core Version:    0.5.4
 */