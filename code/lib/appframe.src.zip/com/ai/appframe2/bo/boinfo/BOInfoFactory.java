/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.util.JarResourceLoader;
/*     */ import com.ai.appframe2.util.ResourceLoader;
/*     */ import com.ai.appframe2.util.SourceFileInterface;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class BOInfoFactory
/*     */ {
/*  21 */   private static BOInfoFactory objBOInfoFactory = new BOInfoFactory();
/*     */ 
/*  23 */   private static HashMap m_BOHashCach = new HashMap();
/*     */ 
/*     */   public static BOInterface getBOInfo(String aName)
/*     */   {
/*  34 */     BOInterface objBO = null;
/*  35 */     String boPackage = getPackageName(aName);
/*  36 */     if (m_BOHashCach.containsKey(aName.toUpperCase())) {
/*  37 */       boPackage = null;
/*  38 */       objBO = (BOInterface)m_BOHashCach.get(aName.toUpperCase());
/*     */     }
/*     */     else {
/*  41 */       objBO = new BORootNode(getResourceURL(aName)).getBO();
/*  42 */       if (!StringUtils.isEmptyString(boPackage))
/*  43 */         ((BONode)objBO).setPackageName(boPackage);
/*  44 */       m_BOHashCach.put(aName.toUpperCase(), objBO);
/*     */     }
/*     */ 
/*  47 */     return objBO;
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectType(String aName) {
/*  51 */     ObjectType objBO = null;
/*  52 */     String boPackage = getPackageName(aName);
/*  53 */     if (m_BOHashCach.containsKey(aName.toUpperCase())) {
/*  54 */       boPackage = null;
/*  55 */       objBO = (ObjectType)m_BOHashCach.get(aName.toUpperCase());
/*     */     }
/*     */     else {
/*  58 */       objBO = new BORootNode(getResourceURL(aName)).getObjectType();
/*  59 */       if (!StringUtils.isEmptyString(boPackage))
/*  60 */         ((BONode)objBO).setPackageName(boPackage);
/*  61 */       m_BOHashCach.put(aName.toUpperCase(), objBO);
/*     */     }
/*  63 */     return objBO;
/*     */   }
/*     */ 
/*     */   static String getPackageName(String aName)
/*     */   {
/*  69 */     ResourceLoader objResourceLoader = null;
/*  70 */     if (aName.indexOf(".") == -1) {
/*  71 */       return "";
/*     */     }
/*     */ 
/*  74 */     String strPackage = aName.substring(0, aName.lastIndexOf("."));
/*  75 */     return strPackage;
/*     */   }
/*     */ 
/*     */   private static URL getResourceURL(String aName)
/*     */   {
/*  80 */     if (System.getProperty("compressed", "false").equalsIgnoreCase("true")) {
/*  81 */       URL objRes = JarResourceLoader.getResourceURL(aName + ".bo");
/*  82 */       if (objRes == null) {
/*  83 */         System.err.println("No business object：" + aName);
/*  84 */         return null;
/*     */       }
/*     */ 
/*  87 */       return objRes;
/*     */     }
/*     */ 
/*  93 */     String boPackage = "";
/*  94 */     ResourceLoader objResourceLoader = null;
/*     */     String strBOName;
/*  95 */     if (aName.indexOf(".") == -1) {
/*  96 */       String strPackage = aName + ".bo";
/*  97 */       String strBOName = aName;
/*  98 */       objResourceLoader = new ResourceLoader("bo");
/*     */     }
/*     */     else {
/* 101 */       String strPackage = aName.substring(0, aName.lastIndexOf("."));
/* 102 */       boPackage = strPackage;
/* 103 */       strBOName = aName.substring(aName.lastIndexOf(".") + 1, aName.length());
/* 104 */       objResourceLoader = new ResourceLoader(strPackage, "bo");
/*     */     }
/* 106 */     SourceFileInterface objFile = objResourceLoader.getSource(strBOName);
/* 107 */     if (objFile == null) {
/* 108 */       System.err.println("No business object：" + aName);
/* 109 */       return null;
/*     */     }
/*     */ 
/* 112 */     return objFile.toURL();
/*     */   }
/*     */ 
/*     */   public static BOInterface getBOInfo(String aName, boolean isRequareNew)
/*     */   {
/* 126 */     BOInterface objBO = null;
/*     */ 
/* 128 */     if (!isRequareNew) {
/* 129 */       return getBOInfo(aName);
/*     */     }
/*     */ 
/* 134 */     ResourceLoader objResourceLoader = null;
/*     */     String strBOName;
/* 135 */     if (aName.indexOf(".") == -1) {
/* 136 */       String strPackage = aName + ".bo";
/* 137 */       String strBOName = aName;
/* 138 */       objResourceLoader = new ResourceLoader("bo");
/*     */     }
/*     */     else {
/* 141 */       String strPackage = aName.substring(0, aName.lastIndexOf("."));
/* 142 */       strBOName = aName.substring(aName.lastIndexOf(".") + 1, aName.length());
/* 143 */       objResourceLoader = new ResourceLoader(strPackage, "bo");
/*     */     }
/* 145 */     SourceFileInterface objFile = objResourceLoader.getSource(strBOName);
/* 146 */     if (objFile == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     objBO = new BORootNode(objFile.toURL()).getBO();
/* 150 */     objFile = null;
/* 151 */     return objBO;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 157 */       System.out.println(getObjectType("aicommon.BOCard.bo").getMapingEnty());
/*     */     }
/*     */     catch (Exception ex) {
/* 160 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOInfoFactory
 * JD-Core Version:    0.5.4
 */