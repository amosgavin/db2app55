/*    */ package com.ai.appframe2.bo.boinfo;
/*    */ 
/*    */ import com.ai.appframe2.bo.boinfo.boinfoxml.Op;
/*    */ import com.ai.appframe2.bo.boinfo.boinfoxml.Oplist;
/*    */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*    */ import com.borland.xml.toolkit.XmlObject;
/*    */ import java.util.Collection;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class BOOpRootNode extends AbstractNode
/*    */ {
/* 18 */   private Oplist m_OPRoot = null;
/*    */ 
/* 20 */   public BOOpRootNode(AbstractNode aSuper, AbstractNode aParent) { super(aSuper, aParent, "OpRoot"); }
/*    */ 
/*    */   public void buildTree(XmlObject aNode)
/*    */   {
/* 24 */     if (aNode == null)
/* 25 */       return;
/* 26 */     Oplist objOplist = (Oplist)aNode;
/* 27 */     this.m_OPRoot = objOplist;
/* 28 */     int count = objOplist.getOpCount();
/* 29 */     setNodeObject(objOplist);
/* 30 */     BOOperationNode objOpNode = null;
/*    */ 
/* 32 */     for (int i = 0; i < count; ++i) {
/* 33 */       Op objOp = objOplist.getOp(i);
/* 34 */       objOpNode = new BOOperationNode(getParentNode(), this, objOp.getName());
/* 35 */       addChild(objOp.getName(), objOpNode);
/* 36 */       objOpNode.buildTree(objOp);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String[] getOpNameArray() {
/* 41 */     if ((getChildSet() == null) || (getChildSet().size() == 0))
/* 42 */       return null;
/* 43 */     Object[] objKey = getChildSet().keySet().toArray(new Object[0]);
/* 44 */     String[] strNames = new String[objKey.length];
/* 45 */     System.arraycopy(objKey, 0, strNames, 0, strNames.length);
/* 46 */     return strNames;
/*    */   }
/*    */ 
/*    */   public void removeOperation(String aName) {
/* 50 */     BOOperationNode objOpNode = (BOOperationNode)getChild(aName);
/* 51 */     if (objOpNode != null) {
/* 52 */       this.m_OPRoot.removeOp((Op)objOpNode.getNodeObject());
/* 53 */       removeChild(aName);
/*    */     }
/*    */   }
/*    */ 
/*    */   public BOOperationInterface[] getOPArray() {
/* 58 */     if ((getChildSet() == null) || (getChildSet().size() == 0))
/* 59 */       return null;
/* 60 */     Object[] objOps = getChildSet().values().toArray(new Object[0]);
/* 61 */     BOOperationInterface[] objOPArray = new BOOperationInterface[objOps.length];
/* 62 */     System.arraycopy(objOps, 0, objOPArray, 0, objOPArray.length);
/* 63 */     return objOPArray;
/*    */   }
/*    */ 
/*    */   public BOOperationInterface addOperationd(String aName) {
/* 67 */     Op objOp = new Op();
/* 68 */     objOp.setName(aName);
/* 69 */     BOOperationNode objOpNode = new BOOperationNode(getParentNode(), this, objOp.getName());
/* 70 */     this.m_OPRoot.addOp(objOp);
/* 71 */     addChild(objOp.getName(), objOpNode);
/* 72 */     objOpNode.buildTree(objOp);
/* 73 */     return objOpNode;
/*    */   }
/*    */ 
/*    */   public BOOperationInterface getOperation(String aName) {
/* 77 */     if ((getChildSet() == null) || (getChildSet().size() == 0))
/* 78 */       return null;
/* 79 */     BOOperationInterface objOp = (BOOperationInterface)getChild(aName);
/* 80 */     return objOp;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOOpRootNode
 * JD-Core Version:    0.5.4
 */