/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.TextElement;
/*     */ 
/*     */ public class Arg extends TextElement
/*     */ {
/*  18 */   public static String _tagName = "arg";
/*     */ 
/*  20 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  22 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  24 */   public Attribute datatype = new Attribute("datatype", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  26 */   public Attribute remark = new Attribute("remark", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Arg()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Arg(String text)
/*     */   {
/*  41 */     super(text);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  49 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  58 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  66 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  75 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getDatatype()
/*     */   {
/*  83 */     return this.datatype.getValue();
/*     */   }
/*     */ 
/*     */   public void setDatatype(String value_)
/*     */   {
/*  92 */     this.datatype.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getRemark()
/*     */   {
/* 100 */     return this.remark.getValue();
/*     */   }
/*     */ 
/*     */   public void setRemark(String value_)
/*     */   {
/* 109 */     this.remark.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 117 */     Element elem = super.marshal();
/*     */ 
/* 119 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 121 */     elem.addAttribute(this.type.marshal());
/*     */ 
/* 123 */     elem.addAttribute(this.datatype.marshal());
/*     */ 
/* 125 */     elem.addAttribute(this.remark.marshal());
/* 126 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Arg unmarshal(Element elem)
/*     */   {
/* 134 */     Arg __objArg = (Arg)TextElement.unmarshal(elem, new Arg());
/* 135 */     if (__objArg != null)
/*     */     {
/* 138 */       __objArg.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 140 */       __objArg.type.setValue(elem.getAttribute("type"));
/*     */ 
/* 142 */       __objArg.datatype.setValue(elem.getAttribute("datatype"));
/*     */ 
/* 144 */       __objArg.remark.setValue(elem.getAttribute("remark"));
/*     */     }
/* 146 */     return __objArg;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 163 */     ErrorList errors = new ErrorList();
/*     */ 
/* 166 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 175 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Arg
 * JD-Core Version:    0.5.4
 */