/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Displaycol extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "displaycol";
/*     */ 
/*  21 */   public Attribute cond = new Attribute("cond", "CDATA", "REQUIRED", "");
/*     */ 
/*  23 */   public Attribute fkbo = new Attribute("fkbo", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  25 */   protected ArrayList _objFkattr = new ArrayList();
/*     */ 
/*  27 */   public Attribute outjoin = new Attribute("outjoin", "NMTOKEN", "IMPLIED", "");
/*     */ 
/*     */   public String getCond()
/*     */   {
/*  42 */     return this.cond.getValue();
/*     */   }
/*     */ 
/*     */   public void setCond(String value_)
/*     */   {
/*  51 */     this.cond.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getFkbo()
/*     */   {
/*  59 */     return this.fkbo.getValue();
/*     */   }
/*     */ 
/*     */   public void setFkbo(String value_)
/*     */   {
/*  68 */     this.fkbo.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getOutjoin()
/*     */   {
/*  73 */     return this.outjoin.getValue();
/*     */   }
/*     */ 
/*     */   public void setOutjoin(String _value) {
/*  77 */     this.outjoin.setValue(_value);
/*     */   }
/*     */ 
/*     */   public Fkattr[] getFkattr()
/*     */   {
/*  86 */     return (Fkattr[])(Fkattr[])this._objFkattr.toArray(new Fkattr[0]);
/*     */   }
/*     */ 
/*     */   public void setFkattr(Fkattr[] objArray)
/*     */   {
/*  96 */     if ((objArray == null) || (objArray.length == 0)) {
/*  97 */       this._objFkattr.clear();
/*     */     }
/*     */     else {
/* 100 */       this._objFkattr = new ArrayList(Arrays.asList(objArray));
/* 101 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/* 103 */         if (objArray[i] != null)
/* 104 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Fkattr getFkattr(int index)
/*     */   {
/* 116 */     return (Fkattr)this._objFkattr.get(index);
/*     */   }
/*     */ 
/*     */   public void setFkattr(int index, Fkattr obj)
/*     */   {
/* 127 */     if (obj == null) {
/* 128 */       removeFkattr(index);
/*     */     }
/*     */     else {
/* 131 */       this._objFkattr.set(index, obj);
/* 132 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getFkattrCount()
/*     */   {
/* 141 */     return this._objFkattr.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoFkattr()
/*     */   {
/* 150 */     return this._objFkattr.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getFkattrList()
/*     */   {
/* 158 */     return Collections.unmodifiableList(this._objFkattr);
/*     */   }
/*     */ 
/*     */   public boolean addFkattr(Fkattr obj)
/*     */   {
/* 168 */     if (obj == null) {
/* 169 */       return false;
/*     */     }
/* 171 */     obj._setParent(this);
/* 172 */     return this._objFkattr.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addFkattr(Collection coFkattr)
/*     */   {
/* 182 */     if (coFkattr == null) {
/* 183 */       return false;
/*     */     }
/* 185 */     Iterator it = coFkattr.iterator();
/* 186 */     while (it.hasNext())
/*     */     {
/* 188 */       Object obj = it.next();
/* 189 */       if ((obj != null) && (obj instanceof XmlObject))
/* 190 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 192 */     return this._objFkattr.addAll(coFkattr);
/*     */   }
/*     */ 
/*     */   public Fkattr removeFkattr(int index)
/*     */   {
/* 201 */     return (Fkattr)this._objFkattr.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeFkattr(Fkattr obj)
/*     */   {
/* 211 */     return this._objFkattr.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearFkattrList()
/*     */   {
/* 219 */     this._objFkattr.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 227 */     Element elem = new Element(get_TagName());
/*     */ 
/* 229 */     elem.addAttribute(this.cond.marshal());
/*     */ 
/* 231 */     elem.addAttribute(this.fkbo.marshal());
/*     */ 
/* 233 */     elem.addAttribute(this.outjoin.marshal());
/*     */ 
/* 236 */     Iterator it1 = this._objFkattr.iterator();
/* 237 */     while (it1.hasNext())
/*     */     {
/* 239 */       Fkattr obj = (Fkattr)it1.next();
/* 240 */       if (obj != null)
/*     */       {
/* 242 */         elem.addComment(obj._marshalCommentList());
/* 243 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 247 */     elem.addComment(_marshalBottomCommentList());
/* 248 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Displaycol unmarshal(Element elem)
/*     */   {
/* 256 */     if (elem == null) {
/* 257 */       return null;
/*     */     }
/* 259 */     Displaycol __objDisplaycol = new Displaycol();
/* 260 */     if (__objDisplaycol != null)
/*     */     {
/* 263 */       __objDisplaycol.cond.setValue(elem.getAttribute("cond"));
/*     */ 
/* 265 */       __objDisplaycol.fkbo.setValue(elem.getAttribute("fkbo"));
/*     */ 
/* 267 */       __objDisplaycol.outjoin.setValue(elem.getAttribute("outjoin"));
/*     */     }
/*     */ 
/* 270 */     ArrayList __comments = null;
/* 271 */     Iterator it = elem.getChildObjects().iterator();
/* 272 */     while (it.hasNext())
/*     */     {
/* 274 */       Object __obj = it.next();
/* 275 */       if (__obj instanceof Comment)
/*     */       {
/* 277 */         if (__comments == null) {
/* 278 */           __comments = new ArrayList(2);
/*     */         }
/* 280 */         __comments.add(__obj);
/*     */       }
/* 282 */       else if (__obj instanceof Element)
/*     */       {
/* 284 */         Element __e = (Element)__obj;
/* 285 */         String __name = __e.getName();
/* 286 */         if (__name.equals(Fkattr._tagName))
/*     */         {
/* 289 */           Fkattr __objFkattr = Fkattr.unmarshal(__e);
/* 290 */           __objDisplaycol.addFkattr(__objFkattr);
/* 291 */           __objFkattr._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 294 */         __comments = null;
/*     */       }
/*     */     }
/* 297 */     __objDisplaycol._unmarshalBottomCommentList(__comments);
/* 298 */     return __objDisplaycol;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 315 */     ErrorList errors = new ErrorList();
/*     */ 
/* 318 */     if (this._objFkattr.size() == 0)
/*     */     {
/* 320 */       errors.add(new ElementError(this, Fkattr.class));
/* 321 */       if (firstError)
/* 322 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 326 */       Iterator it1 = this._objFkattr.iterator();
/* 327 */       while (it1.hasNext())
/*     */       {
/* 329 */         Fkattr obj = (Fkattr)it1.next();
/* 330 */         if (obj != null)
/*     */         {
/* 332 */           errors.add(obj.validate(firstError));
/* 333 */           if ((firstError) && (errors.size() > 0)) {
/* 334 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 339 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 348 */     List children = new ArrayList();
/*     */ 
/* 350 */     if ((this._objFkattr != null) && (this._objFkattr.size() > 0))
/* 351 */       children.add(this._objFkattr);
/* 352 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 361 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Displaycol
 * JD-Core Version:    0.5.4
 */