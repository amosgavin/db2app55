/*    */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class Package extends TextElement
/*    */ {
/* 18 */   public static String _tagName = "package";
/*    */ 
/*    */   public Package()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Package(String text)
/*    */   {
/* 33 */     super(text);
/*    */   }
/*    */ 
/*    */   public static Package unmarshal(Element elem)
/*    */   {
/* 42 */     Package __objPackage = (Package)TextElement.unmarshal(elem, new Package());
/* 43 */     return __objPackage;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 53 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Package
 * JD-Core Version:    0.5.4
 */