/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Attrlist;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Mapingenty;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Oplist;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Relationlist;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Sysbo;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Sysbolist;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Operator;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.Relation;
/*     */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class BONode extends AbstractNode
/*     */   implements BOInterface, ObjectType
/*     */ {
/*  25 */   private String TempTableName = null;
/*  26 */   private BOAttrRootNode attrRootNode = null;
/*  27 */   private BOOpRootNode opRootNode = null;
/*  28 */   private BORelationRootNode relationRootNode = null;
/*  29 */   private String packageName = null;
/*  30 */   private Sysbo m_SysBO = null;
/*  31 */   private String fullName = null;
/*     */ 
/*     */   public BONode(AbstractNode aSuper, AbstractNode aParent, String aName)
/*     */   {
/*  39 */     super(aSuper, aParent, aName);
/*  40 */     this.attrRootNode = new BOAttrRootNode(aSuper, this);
/*  41 */     this.opRootNode = new BOOpRootNode(aSuper, this);
/*  42 */     this.relationRootNode = new BORelationRootNode(aSuper, this);
/*  43 */     addChild("AttrRoot", this.attrRootNode);
/*  44 */     addChild("OpRoot", this.opRootNode);
/*  45 */     addChild("RelationRoot", this.relationRootNode);
/*     */   }
/*     */   public void toXML(Object obj) {
/*     */   }
/*     */ 
/*     */   public void setDataSource(String dataSource) {
/*  51 */     this.m_SysBO.setDatasource(dataSource);
/*     */   }
/*     */   public String getDataSource() {
/*  54 */     return this.m_SysBO.getDatasource();
/*     */   }
/*     */   public void setMainAttr(String mainAttr) {
/*  57 */     this.m_SysBO.setMainattr(mainAttr);
/*     */   }
/*     */   public String getMainAttr() {
/*  60 */     return this.m_SysBO.getMainattr();
/*     */   }
/*     */   public void setMapingEnty(String mapingEnty) {
/*  63 */     if (this.m_SysBO.getMapingenty() == null) {
/*  64 */       this.m_SysBO.setMapingenty(new Mapingenty(mapingEnty));
/*     */     }
/*     */     else
/*  67 */       this.m_SysBO.setMapingentyText(mapingEnty);
/*     */   }
/*     */ 
/*     */   public String getTempTableName() {
/*  71 */     if (this.TempTableName != null) {
/*  72 */       return this.TempTableName;
/*     */     }
/*  74 */     return getMapingEnty();
/*     */   }
/*     */ 
/*     */   public void setTempTableName(String aName) {
/*  78 */     this.TempTableName = aName;
/*     */   }
/*     */ 
/*     */   public String getMapingEnty() {
/*  82 */     return this.m_SysBO.getMapingentyText().replaceAll("\n", " \n");
/*     */   }
/*     */   public void setDataFilter(String dataFilter) {
/*  85 */     this.m_SysBO.setDatafilterText(dataFilter);
/*     */   }
/*     */   public String getDataFilter() {
/*  88 */     return this.m_SysBO.getDatafilterText();
/*     */   }
/*     */   public void setMapingEntyType(String mapingEntyType) {
/*  91 */     if (this.m_SysBO.getMapingenty() == null) {
/*  92 */       this.m_SysBO.setMapingenty(new Mapingenty());
/*     */     }
/*  94 */     this.m_SysBO.getMapingenty().setType(mapingEntyType);
/*     */   }
/*     */   public String getMapingEntyType() {
/*  97 */     return this.m_SysBO.getMapingenty().getType();
/*     */   }
/*     */ 
/*     */   public void buildTree(XmlObject aNode) {
/* 101 */     if (aNode == null)
/* 102 */       return;
/* 103 */     Sysbo objBO = (Sysbo)aNode;
/* 104 */     setNodeObject(objBO);
/* 105 */     this.m_SysBO = objBO;
/* 106 */     if (objBO.getAttrlist() == null) {
/* 107 */       objBO.setAttrlist(new Attrlist());
/*     */     }
/* 109 */     this.attrRootNode.buildTree(objBO.getAttrlist());
/*     */ 
/* 111 */     if (objBO.getOplist() == null) {
/* 112 */       objBO.setOplist(new Oplist());
/*     */     }
/* 114 */     this.opRootNode.buildTree(objBO.getOplist());
/*     */ 
/* 116 */     if (objBO.getRelationlist() == null) {
/* 117 */       objBO.setRelationlist(new Relationlist());
/*     */     }
/* 119 */     this.relationRootNode.buildTree(objBO.getRelationlist());
/*     */   }
/*     */ 
/*     */   public BOAttrRootNode getAttrRootNode() {
/* 123 */     return this.attrRootNode;
/*     */   }
/*     */   public void setAttrRootNode(BOAttrRootNode attrRootNode) {
/* 126 */     this.attrRootNode = attrRootNode;
/*     */   }
/*     */   public BOOpRootNode getOpRootNode() {
/* 129 */     return this.opRootNode;
/*     */   }
/*     */   public void setOpRootNode(BOOpRootNode opRootNode) {
/* 132 */     this.opRootNode = opRootNode;
/*     */   }
/*     */   public void setRelationRootNode(BORelationRootNode relationRootNode) {
/* 135 */     this.relationRootNode = relationRootNode;
/*     */   }
/*     */   public BORelationRootNode getRelationRootNode() {
/* 138 */     return this.relationRootNode;
/*     */   }
/*     */ 
/*     */   public BOAttrInterface[] getBOAttrArray() {
/* 142 */     return this.attrRootNode.getAttrArray();
/*     */   }
/*     */ 
/*     */   public BOOperationInterface[] getOperationArray() {
/* 146 */     return this.opRootNode.getOPArray();
/*     */   }
/*     */ 
/*     */   public BORelationInterface[] getRelationArray() {
/* 150 */     return this.relationRootNode.getRelationArray();
/*     */   }
/*     */ 
/*     */   public BOAttrInterface[] getPKAttrAray() {
/* 154 */     return this.attrRootNode.getPKAttrAray();
/*     */   }
/*     */ 
/*     */   public String[] getPKAttrNameArray() {
/* 158 */     return this.attrRootNode.getPKAttrNameArray();
/*     */   }
/*     */ 
/*     */   public String[] getAttrNameArray() {
/* 162 */     return this.attrRootNode.getAttrNameArray();
/*     */   }
/*     */ 
/*     */   public String[] getOpNameArray() {
/* 166 */     return this.opRootNode.getOpNameArray();
/*     */   }
/*     */   public BOAttrInterface getBOAttr(String aName) {
/* 169 */     return (BOAttrInterface)this.attrRootNode.getChild(aName);
/*     */   }
/*     */ 
/*     */   public BOOperationInterface getBOOPeration(String aName) {
/* 173 */     return (BOOperationInterface)this.opRootNode.getChild(aName);
/*     */   }
/*     */ 
/*     */   public BORelationInterface getBORelation(String aName) {
/* 177 */     return this.relationRootNode.getRelation(aName);
/*     */   }
/*     */ 
/*     */   private BOOperationInterface getBOOperationByType(String aType) {
/* 181 */     BOOperationInterface objOp = null;
/* 182 */     if (this.opRootNode.getChildSet() == null)
/* 183 */       return null;
/* 184 */     Iterator objIterator = this.opRootNode.getChildSet().values().iterator();
/* 185 */     while (objIterator.hasNext()) {
/* 186 */       objOp = (BOOperationInterface)objIterator.next();
/* 187 */       if ((objOp.getOperationType() != null) && (objOp.getOperationType().trim().equalsIgnoreCase(aType))) {
/*     */         break;
/*     */       }
/*     */ 
/* 191 */       objOp = null;
/*     */     }
/*     */ 
/* 194 */     return objOp;
/*     */   }
/*     */ 
/*     */   public BOOperationInterface getBOCreateOperation() {
/* 198 */     return getBOOperationByType("create");
/*     */   }
/*     */ 
/*     */   public BOOperationInterface getBORemoveOperation() {
/* 202 */     return getBOOperationByType("remove");
/*     */   }
/*     */ 
/*     */   public BOOperationInterface getBOUpdateOperation() {
/* 206 */     return getBOOperationByType("update");
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 210 */     return this.m_SysBO.getRemark();
/*     */   }
/*     */   public void setRemark(String remark) {
/* 213 */     super.setRemark(remark);
/* 214 */     this.m_SysBO.setRemark(remark);
/*     */   }
/*     */ 
/*     */   public BOAttrInterface addBOAttr(String aName) {
/* 218 */     return this.attrRootNode.addBOAttr(aName);
/*     */   }
/*     */ 
/*     */   public String getPackage() {
/* 222 */     return ((Sysbolist)getParentNode().getNodeObject()).getPackageText();
/*     */   }
/*     */   public String getName() {
/* 225 */     return this.m_SysBO.getName();
/*     */   }
/*     */ 
/*     */   public String getFullName() {
/* 229 */     return getBOFullName();
/*     */   }
/*     */ 
/*     */   public String getBOFullName() {
/* 233 */     if (this.fullName == null) {
/* 234 */       if (((Sysbolist)getParentNode().getNodeObject()).getPackageText() != null) {
/* 235 */         this.fullName = (((Sysbolist)getParentNode().getNodeObject()).getPackageText() + "." + getName());
/*     */       }
/* 237 */       else if (!StringUtils.isEmptyString(this.packageName))
/* 238 */         this.fullName = (this.packageName + "." + getName());
/*     */       else {
/* 240 */         this.fullName = getName();
/*     */       }
/*     */     }
/*     */ 
/* 244 */     return this.fullName;
/*     */   }
/*     */ 
/*     */   public BOOperationInterface addOperation(String aName) {
/* 248 */     return this.opRootNode.addOperationd(aName);
/*     */   }
/*     */   public void removeAllBoAttr() {
/* 251 */     this.attrRootNode.removeAllBoAttr();
/*     */   }
/*     */   public void removeBOAttr(String aName) {
/* 254 */     this.attrRootNode.removeBOAttr(aName);
/*     */   }
/*     */ 
/*     */   public void removeBOOP(String aName) {
/* 258 */     this.opRootNode.removeOperation(aName);
/*     */   }
/*     */ 
/*     */   public void setName(String aName) {
/* 262 */     super.setName(aName);
/* 263 */     this.m_SysBO.setName(aName);
/*     */   }
/*     */ 
/*     */   public BORelationInterface addRelation(String aName) {
/* 267 */     return this.relationRootNode.addRelation(aName);
/*     */   }
/*     */ 
/*     */   public List getRelationList() {
/* 271 */     return this.relationRootNode.getRelationList();
/*     */   }
/*     */ 
/*     */   public void removeRelation(String aName) {
/* 275 */     this.relationRootNode.removeRelation(aName);
/*     */   }
/*     */ 
/*     */   public String getCondictionMapingCol(String aExp) {
/* 279 */     String[] str = StringUtils.split(aExp, '.');
/* 280 */     StringBuilder strRs = null;
/* 281 */     if (str == null)
/* 282 */       return null;
/* 283 */     String strAttrName = "";
/* 284 */     String strBOName = "";
/* 285 */     BOAttrInterface objAttr = null;
/* 286 */     if (str.length > 1) {
/* 287 */       strBOName = str[(str.length - 2)];
/* 288 */       strAttrName = str[(str.length - 1)];
/*     */     }
/*     */     else {
/* 291 */       strBOName = this.m_SysBO.getName();
/* 292 */       strAttrName = str[(str.length - 1)];
/*     */     }
/* 294 */     objAttr = getBOAttr(strAttrName);
/* 295 */     if ((strBOName.equalsIgnoreCase(this.m_SysBO.getName())) && (objAttr != null)) {
/* 296 */       strRs = new StringBuilder(getTempTableName());
/* 297 */       strRs.append(".").append(objAttr.getMapingColName());
/*     */     }
/* 299 */     if (strRs == null) {
/* 300 */       return "";
/*     */     }
/* 302 */     return strRs.toString();
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 307 */     return null;
/*     */   }
/*     */   public boolean isKeyProperty(String p) {
/* 310 */     BOAttrInterface objAttr = getBOAttr(p);
/*     */ 
/* 312 */     return (objAttr != null) && (objAttr.getType().equalsIgnoreCase("PK"));
/*     */   }
/*     */ 
/*     */   public HashMap getKeyProperties()
/*     */   {
/* 319 */     BOAttrInterface[] objAttrs = getPKAttrAray();
/* 320 */     HashMap objPkMap = new HashMap();
/* 321 */     for (int i = 0; (objAttrs != null) && (i < objAttrs.length); ++i) {
/* 322 */       objPkMap.put(objAttrs[i].getName(), objAttrs[i]);
/*     */     }
/* 324 */     return objPkMap;
/*     */   }
/*     */   public String[] getPropertyNames() {
/* 327 */     return (String[])(String[])getProperties().keySet().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public HashMap getProperties()
/*     */   {
/* 346 */     BOAttrInterface[] objAttrs = getBOAttrArray();
/* 347 */     HashMap result = new HashMap();
/* 348 */     for (int i = 0; (objAttrs != null) && (i < objAttrs.length); ++i) {
/* 349 */       result.put(objAttrs[i].getName(), objAttrs[i]);
/*     */     }
/* 351 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean hasProperty(String name)
/*     */   {
/* 356 */     return getBOAttr(name) != null;
/*     */   }
/*     */ 
/*     */   public Property getProperty(String name)
/*     */   {
/* 361 */     return (Property)getBOAttr(name);
/*     */   }
/*     */   public HashMap getRelations() {
/* 364 */     HashMap objMap = new HashMap();
/* 365 */     BORelationInterface[] objRelations = getRelationArray();
/*     */ 
/* 367 */     for (int i = 0; (objRelations != null) && (i < objRelations.length); ++i) {
/* 368 */       objMap.put(objRelations[i].getName(), objRelations[i]);
/*     */     }
/* 370 */     return objMap;
/*     */   }
/*     */ 
/*     */   public boolean hasRelation(String name) {
/* 374 */     return getRelation(name) != null;
/*     */   }
/*     */ 
/*     */   public Relation getRelation(String name)
/*     */   {
/* 380 */     return (Relation)getRelationRootNode().getRelation(name);
/*     */   }
/*     */   public HashMap getOperators() {
/* 383 */     HashMap objMap = new HashMap();
/* 384 */     BOOperationInterface[] objOperators = getOperationArray();
/* 385 */     for (int i = 0; (objOperators != null) && (i < objOperators.length); ++i) {
/* 386 */       objMap.put(objOperators[i].getName(), objOperators[i]);
/*     */     }
/* 388 */     return objMap;
/*     */   }
/*     */ 
/*     */   public boolean hasOperator(String name) {
/* 392 */     return getOperator(name) != null;
/*     */   }
/*     */ 
/*     */   public Operator getOperator(String name)
/*     */   {
/* 398 */     return (Operator)getOpRootNode().getOperation(name);
/*     */   }
/*     */ 
/*     */   public String debug() {
/* 402 */     String keyProp = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.key_prop");
/* 403 */     String propertyInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.property");
/* 404 */     String relationInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.reference_obj");
/* 405 */     String operateInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.operation");
/*     */ 
/* 407 */     String result = "ObjectType:" + getName() + "\n " + keyProp + ":\n";
/* 408 */     for (Iterator it = getKeyProperties().values().iterator(); it.hasNext(); ) {
/* 409 */       result = result + ((Property)it.next()).toString() + "\n";
/*     */     }
/* 411 */     result = result + propertyInfo + ":\n";
/* 412 */     for (Iterator it = getProperties().values().iterator(); it.hasNext(); )
/* 413 */       result = result + ((Property)it.next()).toString() + "\n";
/* 414 */     result = result + relationInfo + ":\n";
/* 415 */     for (Iterator it = getRelations().values().iterator(); it.hasNext(); )
/* 416 */       result = result + ((Relation)it.next()).toString() + "\n";
/* 417 */     result = result + operateInfo + ":\n";
/* 418 */     for (Iterator it = getOperators().values().iterator(); it.hasNext(); )
/* 419 */       result = result + ((Operator)it.next()).toString() + "\n";
/* 420 */     return result;
/*     */   }
/*     */ 
/*     */   public String getPackageName() {
/* 424 */     return this.packageName;
/*     */   }
/*     */   public void setPackageName(String packageName) {
/* 427 */     this.packageName = packageName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BONode
 * JD-Core Version:    0.5.4
 */