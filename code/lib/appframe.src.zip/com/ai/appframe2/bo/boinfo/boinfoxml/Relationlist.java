/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Relationlist extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "relationlist";
/*     */ 
/*  21 */   protected ArrayList _objRelation = new ArrayList();
/*     */ 
/*     */   public Relation[] getRelation()
/*     */   {
/*  37 */     return (Relation[])(Relation[])this._objRelation.toArray(new Relation[0]);
/*     */   }
/*     */ 
/*     */   public void setRelation(Relation[] objArray)
/*     */   {
/*  47 */     if ((objArray == null) || (objArray.length == 0)) {
/*  48 */       this._objRelation.clear();
/*     */     }
/*     */     else {
/*  51 */       this._objRelation = new ArrayList(Arrays.asList(objArray));
/*  52 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  54 */         if (objArray[i] != null)
/*  55 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Relation getRelation(int index)
/*     */   {
/*  67 */     return (Relation)this._objRelation.get(index);
/*     */   }
/*     */ 
/*     */   public void setRelation(int index, Relation obj)
/*     */   {
/*  78 */     if (obj == null) {
/*  79 */       removeRelation(index);
/*     */     }
/*     */     else {
/*  82 */       this._objRelation.set(index, obj);
/*  83 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getRelationCount()
/*     */   {
/*  92 */     return this._objRelation.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoRelation()
/*     */   {
/* 101 */     return this._objRelation.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getRelationList()
/*     */   {
/* 109 */     return Collections.unmodifiableList(this._objRelation);
/*     */   }
/*     */ 
/*     */   public boolean addRelation(Relation obj)
/*     */   {
/* 119 */     if (obj == null) {
/* 120 */       return false;
/*     */     }
/* 122 */     obj._setParent(this);
/* 123 */     return this._objRelation.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addRelation(Collection coRelation)
/*     */   {
/* 133 */     if (coRelation == null) {
/* 134 */       return false;
/*     */     }
/* 136 */     Iterator it = coRelation.iterator();
/* 137 */     while (it.hasNext())
/*     */     {
/* 139 */       Object obj = it.next();
/* 140 */       if ((obj != null) && (obj instanceof XmlObject))
/* 141 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 143 */     return this._objRelation.addAll(coRelation);
/*     */   }
/*     */ 
/*     */   public Relation removeRelation(int index)
/*     */   {
/* 152 */     return (Relation)this._objRelation.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeRelation(Relation obj)
/*     */   {
/* 162 */     return this._objRelation.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearRelationList()
/*     */   {
/* 170 */     this._objRelation.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 178 */     Element elem = new Element(get_TagName());
/*     */ 
/* 180 */     Iterator it1 = this._objRelation.iterator();
/* 181 */     while (it1.hasNext())
/*     */     {
/* 183 */       Relation obj = (Relation)it1.next();
/* 184 */       if (obj != null)
/*     */       {
/* 186 */         elem.addComment(obj._marshalCommentList());
/* 187 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 191 */     elem.addComment(_marshalBottomCommentList());
/* 192 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Relationlist unmarshal(Element elem)
/*     */   {
/* 200 */     if (elem == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     Relationlist __objRelationlist = new Relationlist();
/*     */ 
/* 205 */     ArrayList __comments = null;
/* 206 */     Iterator it = elem.getChildObjects().iterator();
/* 207 */     while (it.hasNext())
/*     */     {
/* 209 */       Object __obj = it.next();
/* 210 */       if (__obj instanceof Comment)
/*     */       {
/* 212 */         if (__comments == null) {
/* 213 */           __comments = new ArrayList(2);
/*     */         }
/* 215 */         __comments.add(__obj);
/*     */       }
/* 217 */       else if (__obj instanceof Element)
/*     */       {
/* 219 */         Element __e = (Element)__obj;
/* 220 */         String __name = __e.getName();
/* 221 */         if (__name.equals(Relation._tagName))
/*     */         {
/* 224 */           Relation __objRelation = Relation.unmarshal(__e);
/* 225 */           __objRelationlist.addRelation(__objRelation);
/* 226 */           __objRelation._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 229 */         __comments = null;
/*     */       }
/*     */     }
/* 232 */     __objRelationlist._unmarshalBottomCommentList(__comments);
/* 233 */     return __objRelationlist;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 250 */     ErrorList errors = new ErrorList();
/*     */ 
/* 253 */     if (this._objRelation.size() == 0)
/*     */     {
/* 255 */       errors.add(new ElementError(this, Relation.class));
/* 256 */       if (firstError)
/* 257 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 261 */       Iterator it1 = this._objRelation.iterator();
/* 262 */       while (it1.hasNext())
/*     */       {
/* 264 */         Relation obj = (Relation)it1.next();
/* 265 */         if (obj != null)
/*     */         {
/* 267 */           errors.add(obj.validate(firstError));
/* 268 */           if ((firstError) && (errors.size() > 0)) {
/* 269 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 274 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 283 */     List children = new ArrayList();
/*     */ 
/* 285 */     if ((this._objRelation != null) && (this._objRelation.size() > 0))
/* 286 */       children.add(this._objRelation);
/* 287 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 296 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Relationlist
 * JD-Core Version:    0.5.4
 */