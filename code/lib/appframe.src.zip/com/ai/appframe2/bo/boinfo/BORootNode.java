/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Sysbo;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Sysbolist;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Util;
/*     */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*     */ import com.ai.appframe2.util.FileUtils;
/*     */ import com.borland.xml.toolkit.Outputter;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class BORootNode extends AbstractNode
/*     */   implements BORootInterface
/*     */ {
/*  28 */   private Sysbolist g_SysBOList = null;
/*  29 */   private String m_ErrorMessage = "";
/*  30 */   private String m_BOName = null;
/*     */ 
/*  32 */   private transient URL confogFileURL = null;
/*  33 */   private transient File m_SrcFile = null;
/*     */ 
/*     */   public BORootNode(URL aSrcURL, boolean flag)
/*     */   {
/*  37 */     super(null, null, "SysBOList");
/*  38 */     this.confogFileURL = aSrcURL;
/*  39 */     this.m_SrcFile = new File(aSrcURL.getFile());
/*  40 */     this.g_SysBOList = new Sysbolist();
/*  41 */     setNodeObject(this.g_SysBOList);
/*  42 */     buildTree(this.g_SysBOList);
/*     */   }
/*     */   public BORootNode(URL aSrcURL) {
/*  45 */     super(null, null, "SysBOList");
/*  46 */     this.confogFileURL = aSrcURL;
/*  47 */     this.m_SrcFile = new File(aSrcURL.getFile());
/*     */ 
/*  51 */     Reader reader = null;
/*     */     try {
/*  53 */       byte[] bytes = Util.getResourceAsBytes(aSrcURL.openStream());
/*  54 */       if (bytes != null)
/*  55 */         if (Util.isValidUtf8(bytes, bytes.length))
/*  56 */           reader = new StringReader(new String(bytes, "UTF-8"));
/*     */         else
/*  58 */           reader = new StringReader(new String(bytes));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  62 */       throw new RuntimeException(e);
/*     */     }
/*  64 */     if (reader != null) {
/*  65 */       this.g_SysBOList = Sysbolist.unmarshal(reader);
/*     */     }
/*  67 */     if (this.g_SysBOList == null) {
/*  68 */       this.g_SysBOList = new Sysbolist();
/*     */     }
/*  70 */     setNodeObject(this.g_SysBOList);
/*  71 */     buildTree(this.g_SysBOList);
/*     */   }
/*     */ 
/*     */   public BORootNode(URL aSrcURL, InputStream is)
/*     */   {
/*  76 */     super(null, null, "SysBOList");
/*  77 */     this.confogFileURL = aSrcURL;
/*  78 */     this.m_SrcFile = new File(aSrcURL.getFile());
/*     */ 
/*  80 */     this.g_SysBOList = Sysbolist.unmarshal(is);
/*  81 */     if (this.g_SysBOList == null) {
/*  82 */       this.g_SysBOList = new Sysbolist();
/*     */     }
/*  84 */     setNodeObject(this.g_SysBOList);
/*  85 */     buildTree(this.g_SysBOList);
/*     */   }
/*     */ 
/*     */   public BORootNode(File aSrcFile) {
/*  89 */     super(null, null, "SysBOList");
/*  90 */     this.m_SrcFile = aSrcFile;
/*     */     try {
/*  92 */       this.confogFileURL = aSrcFile.toURL();
/*     */     }
/*     */     catch (Exception ex) {
/*  95 */       ex.printStackTrace();
/*     */     }
/*     */ 
/*  98 */     this.g_SysBOList = Sysbolist.unmarshal(this.confogFileURL);
/*  99 */     if (this.g_SysBOList == null)
/* 100 */       this.g_SysBOList = new Sysbolist();
/* 101 */     setNodeObject(this.g_SysBOList);
/* 102 */     buildTree(this.g_SysBOList);
/*     */   }
/*     */ 
/*     */   public void refresh()
/*     */   {
/* 107 */     this.g_SysBOList = Sysbolist.unmarshal(this.confogFileURL);
/* 108 */     setNodeObject(this.g_SysBOList);
/* 109 */     buildTree(this.g_SysBOList);
/*     */   }
/*     */ 
/*     */   public void buildTree(XmlObject aNode) {
/* 113 */     if (aNode == null)
/* 114 */       return;
/* 115 */     int count = ((Sysbolist)aNode).getSysboCount();
/* 116 */     Sysbo objBO = null;
/* 117 */     for (int i = 0; i < count; ++i) {
/* 118 */       objBO = ((Sysbolist)aNode).getSysbo(i);
/*     */ 
/* 120 */       if (i == 0) {
/* 121 */         this.m_BOName = objBO.getName();
/*     */       }
/* 123 */       BONode objBONode = new BONode(this, this, objBO.getName());
/* 124 */       addChild(objBO.getName(), objBONode);
/* 125 */       objBONode.buildTree(objBO);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BOInterface addBO(String aName)
/*     */   {
/* 134 */     Sysbo objBO = new Sysbo();
/* 135 */     objBO.setName(aName);
/* 136 */     BONode objBONode = new BONode(this, this, aName);
/* 137 */     addChild(objBO.getName(), objBONode);
/* 138 */     objBONode.buildTree(objBO);
/* 139 */     this.g_SysBOList.addSysbo(objBO);
/* 140 */     return objBONode;
/*     */   }
/*     */ 
/*     */   public void removeBO(String aName)
/*     */   {
/* 148 */     BONode objBONode = (BONode)getChild(aName);
/* 149 */     if (objBONode != null) {
/* 150 */       this.g_SysBOList.removeSysbo((Sysbo)objBONode.getNodeObject());
/* 151 */       removeChild(aName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BOInterface getBO(String aName) {
/* 156 */     return (BOInterface)getChild(aName);
/*     */   }
/*     */ 
/*     */   public BOInterface getBO() {
/* 160 */     return getBO(this.m_BOName);
/*     */   }
/*     */ 
/*     */   public ObjectType getObjectType() {
/* 164 */     return (ObjectType)getChild(this.m_BOName);
/*     */   }
/*     */ 
/*     */   public String getPackage()
/*     */   {
/* 171 */     return this.g_SysBOList.getPackageText();
/*     */   }
/*     */ 
/*     */   public void setPackage(String aPackage) {
/* 175 */     this.g_SysBOList.setPackageText(aPackage);
/*     */   }
/*     */ 
/*     */   public List getBOList()
/*     */   {
/* 183 */     if ((getChildSet() == null) || (getChildSet().values() == null))
/* 184 */       return new ArrayList(0);
/* 185 */     ArrayList objList = new ArrayList(getChildSet().values());
/* 186 */     return objList;
/*     */   }
/*     */ 
/*     */   public void toXML(Object obj) {
/*     */     try {
/* 191 */       if (this.g_SysBOList == null) {
/* 192 */         this.g_SysBOList = new Sysbolist();
/*     */       }
/*     */ 
/* 198 */       Outputter outP = new Outputter("  ", "UTF-8");
/* 199 */       StringWriter writer = new StringWriter();
/* 200 */       this.g_SysBOList.marshal(writer, outP);
/* 201 */       FileUtils.writeFile(this.m_SrcFile.getPath(), writer.getBuffer().toString().getBytes("UTF-8"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 205 */       e.printStackTrace();
/* 206 */       this.m_ErrorMessage = e.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeFile()
/*     */     throws Exception
/*     */   {
/* 215 */     toXML(this.m_ErrorMessage);
/* 216 */     if (!this.m_ErrorMessage.equals(""))
/* 217 */       throw new AIException(this.m_ErrorMessage);
/*     */   }
/*     */ 
/*     */   public String[] getBONames()
/*     */   {
/* 228 */     String[] sRe = new String[0];
/* 229 */     if (getChildSet().keySet() != null)
/* 230 */       sRe = (String[])(String[])getChildSet().keySet().toArray(new String[0]);
/* 231 */     return sRe;
/*     */   }
/*     */ 
/*     */   public BOInterface[] getBOInfos()
/*     */   {
/* 241 */     BOInterface[] boInfoRe = null;
/* 242 */     if (getChildSet().values() != null)
/* 243 */       boInfoRe = (BOInterface[])(BOInterface[])getChildSet().values().toArray(new BOInterface[0]);
/* 244 */     return boInfoRe;
/*     */   }
/*     */ 
/*     */   public String getPackageName() {
/* 248 */     return this.g_SysBOList.getPackageText();
/*     */   }
/*     */ 
/*     */   public void setPackageName(String aName) {
/* 252 */     this.g_SysBOList.setPackageText(aName);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BORootNode
 * JD-Core Version:    0.5.4
 */