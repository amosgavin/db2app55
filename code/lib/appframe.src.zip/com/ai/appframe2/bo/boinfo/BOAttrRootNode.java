/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Attr;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Attrlist;
/*     */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class BOAttrRootNode extends AbstractNode
/*     */ {
/*  19 */   private ArrayList PKAttrList = new ArrayList(1);
/*  20 */   private ArrayList PKNameList = new ArrayList(1);
/*  21 */   private Attrlist m_AttrList = null;
/*     */ 
/*  23 */   public BOAttrRootNode(AbstractNode aSuper, AbstractNode aParent) { super(aSuper, aParent, "AttrRoot"); }
/*     */ 
/*     */   public void buildTree(XmlObject aNode)
/*     */   {
/*  27 */     if (aNode == null) {
/*  28 */       return;
/*     */     }
/*  30 */     Attrlist objAttrlist = (Attrlist)aNode;
/*  31 */     this.m_AttrList = objAttrlist;
/*  32 */     int count = objAttrlist.getAttrCount();
/*  33 */     BOAttrNode objAttrNode = null;
/*  34 */     Attr objAttr = null;
/*  35 */     for (int i = 0; i < count; ++i) {
/*  36 */       objAttr = objAttrlist.getAttr(i);
/*  37 */       objAttrNode = new BOAttrNode(getParentNode(), this, objAttr.getName());
/*  38 */       if (objAttr.getType().trim().equalsIgnoreCase("PK")) {
/*  39 */         this.PKAttrList.add(objAttrNode);
/*  40 */         this.PKNameList.add(objAttr.getName());
/*     */       }
/*  42 */       addChild(objAttr.getName(), objAttrNode);
/*  43 */       objAttrNode.buildTree(objAttr);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAttrList() {
/*  48 */     if (getChildSet() != null) {
/*  49 */       return new ArrayList(getChildSet().values());
/*     */     }
/*  51 */     return new ArrayList(0);
/*     */   }
/*     */ 
/*     */   public BOAttrInterface[] getAttrArray() {
/*  55 */     if (getChildSet() == null)
/*  56 */       return null;
/*  57 */     Object[] obj = getChildSet().values().toArray(new Object[0]);
/*  58 */     BOAttrInterface[] objAttr = new BOAttrInterface[obj.length];
/*  59 */     System.arraycopy(obj, 0, objAttr, 0, obj.length);
/*  60 */     return objAttr;
/*     */   }
/*     */ 
/*     */   public String[] getAttrNameArray() {
/*  64 */     Object[] objKey = getChildSet().keySet().toArray(new Object[0]);
/*  65 */     String[] strNames = new String[objKey.length];
/*  66 */     System.arraycopy(objKey, 0, strNames, 0, strNames.length);
/*  67 */     return strNames;
/*     */   }
/*     */ 
/*     */   public String[] getPKAttrNameArray() {
/*  71 */     Object[] obj = this.PKNameList.toArray(new Object[0]);
/*  72 */     String[] objPKAttrNames = new String[obj.length];
/*  73 */     System.arraycopy(obj, 0, objPKAttrNames, 0, obj.length);
/*  74 */     return objPKAttrNames;
/*     */   }
/*     */ 
/*     */   public BOAttrInterface[] getPKAttrAray() {
/*  78 */     Object[] obj = this.PKAttrList.toArray(new Object[0]);
/*  79 */     BOAttrInterface[] objPKAttr = new BOAttrInterface[obj.length];
/*  80 */     System.arraycopy(obj, 0, objPKAttr, 0, obj.length);
/*  81 */     return objPKAttr;
/*     */   }
/*     */ 
/*     */   public BOAttrInterface addBOAttr(String aName)
/*     */   {
/*  90 */     Attr objAttr = new Attr();
/*  91 */     objAttr.setName(aName);
/*  92 */     this.m_AttrList.addAttr(objAttr);
/*  93 */     BOAttrNode objAttrNode = new BOAttrNode(getParentNode(), this, aName);
/*  94 */     objAttrNode.buildTree(objAttr);
/*  95 */     addChild(aName, objAttrNode);
/*  96 */     return objAttrNode;
/*     */   }
/*     */   public void removeAllBoAttr() {
/*  99 */     this.m_AttrList.clearAttrList();
/* 100 */     removeAllChild();
/*     */   }
/*     */   public void removeBOAttr(String aName) {
/* 103 */     BOAttrNode objAttrNode = (BOAttrNode)getChild(aName);
/* 104 */     if (objAttrNode != null) {
/* 105 */       this.m_AttrList.removeAttr((Attr)objAttrNode.getNodeObject());
/* 106 */       removeChild(aName);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOAttrRootNode
 * JD-Core Version:    0.5.4
 */