package com.ai.appframe2.bo.boinfo;

import com.ai.appframe2.common.mutablenode.AbstractNodeInterface;
import java.util.List;

public abstract interface BOAttrInterface extends AbstractNodeInterface
{
  public abstract void setType(String paramString);

  public abstract String getType();

  public abstract void setDatatype(String paramString);

  public abstract String getDatatype();

  public abstract void setMaxLength(int paramInt);

  public abstract int getMaxLength();

  public abstract void setFloatLength(int paramInt);

  public abstract int getFloatLength();

  public abstract void setMapingColName(String paramString);

  public abstract String getMapingColName();

  public abstract void setMapingColType(String paramString);

  public abstract String getMapingColType();

  public abstract List getDisplayColName();

  public abstract void setDisplayEnty(String paramString);

  public abstract String getDisplayEnty();

  public abstract void setDisplayCond(String paramString);

  public abstract String getDisplayCond();

  public abstract void setLinkName(String paramString);

  public abstract String getLinkName();

  public abstract List getDisplayAttrList();

  public abstract void setAutoValue(String paramString);

  public abstract String getAutoValue();

  public abstract String getName();

  public abstract String getAutoValueType();

  public abstract void setAutoValueType(String paramString);

  public abstract void addDisplayCol(String paramString1, String paramString2);

  public abstract void removeDisplayCol();

  public abstract String toString();

  public abstract String getRelationObjectTypeOutJoin();

  public abstract void setRelationObjectTypeOutJoin(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOAttrInterface
 * JD-Core Version:    0.5.4
 */