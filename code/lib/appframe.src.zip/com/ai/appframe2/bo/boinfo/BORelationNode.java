/*    */ package com.ai.appframe2.bo.boinfo;
/*    */ 
/*    */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import com.borland.xml.toolkit.XmlObject;
/*    */ 
/*    */ public class BORelationNode extends AbstractNode
/*    */   implements BORelationInterface, com.ai.appframe2.common.Relation
/*    */ {
/* 19 */   private com.ai.appframe2.bo.boinfo.boinfoxml.Relation m_Relation = null;
/*    */ 
/* 21 */   public BORelationNode(AbstractNode aSuper, AbstractNode aParent, String aName) { super(aSuper, aParent, aName); }
/*    */ 
/*    */   public String getChildBOName() {
/* 24 */     return this.m_Relation.getChildname();
/*    */   }
/*    */   public void setChildBOName(String childBOName) {
/* 27 */     this.m_Relation.setChildname(childBOName);
/*    */   }
/*    */   public void setRelationCondition(String relationCondiction) {
/* 30 */     this.m_Relation.setText(relationCondiction);
/*    */   }
/*    */   public String getRelationCondition() {
/* 33 */     return this.m_Relation.getText();
/*    */   }
/*    */   public void buildTree(XmlObject aNode) {
/* 36 */     if (aNode == null)
/* 37 */       return;
/* 38 */     com.ai.appframe2.bo.boinfo.boinfoxml.Relation objRelation = (com.ai.appframe2.bo.boinfo.boinfoxml.Relation)aNode;
/* 39 */     this.m_Relation = objRelation;
/* 40 */     setNodeObject(objRelation);
/*    */   }
/*    */   public void setName(String aName) {
/* 43 */     super.setName(aName);
/* 44 */     this.m_Relation.setName(aName);
/*    */   }
/*    */   public void setRemark(String remark) {
/* 47 */     super.setRemark(remark);
/* 48 */     this.m_Relation.setRemark(remark);
/*    */   }
/*    */ 
/*    */   public String getJavaDataType() {
/* 52 */     return null;
/*    */   }
/*    */ 
/*    */   public boolean isCollection()
/*    */   {
/* 57 */     return (!StringUtils.isEmptyString(this.m_Relation.getIsCollection())) && (!this.m_Relation.getIsCollection().equalsIgnoreCase("false"));
/*    */   }
/*    */ 
/*    */   public void setCollection(boolean flag)
/*    */   {
/* 65 */     if (flag)
/* 66 */       this.m_Relation.setIsCollection("true");
/*    */     else
/* 68 */       this.m_Relation.setIsCollection("false");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BORelationNode
 * JD-Core Version:    0.5.4
 */