/*    */ package com.ai.appframe2.bo.boinfo;
/*    */ 
/*    */ import com.ai.appframe2.bo.boinfo.boinfoxml.Arg;
/*    */ import com.ai.appframe2.common.ParameterType;
/*    */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*    */ import com.borland.xml.toolkit.XmlObject;
/*    */ 
/*    */ public class OperationArgNode extends AbstractNode
/*    */   implements OperationArgInterface, ParameterType
/*    */ {
/* 18 */   private Arg m_Arg = null;
/*    */ 
/* 20 */   public OperationArgNode(AbstractNode aSuper, AbstractNode aParent, String aName) { super(aSuper, aParent, aName); }
/*    */ 
/*    */   public void buildTree(XmlObject aNode) {
/* 23 */     if (aNode == null)
/* 24 */       return;
/* 25 */     Arg objArg = (Arg)aNode;
/* 26 */     this.m_Arg = objArg;
/* 27 */     setRemark(objArg.getRemark());
/* 28 */     setNodeObject(objArg);
/*    */   }
/*    */ 
/*    */   public void setType(String type) {
/* 32 */     this.m_Arg.setType(type);
/*    */   }
/*    */   public String getType() {
/* 35 */     return this.m_Arg.getType();
/*    */   }
/*    */   public void setValue(String value) {
/* 38 */     this.m_Arg.setText(value);
/*    */   }
/*    */   public String getValue() {
/* 41 */     return this.m_Arg.getText();
/*    */   }
/*    */   public void setDataType(String dataType) {
/* 44 */     this.m_Arg.setDatatype(dataType);
/*    */   }
/*    */   public String getDataType() {
/* 47 */     return this.m_Arg.getDatatype();
/*    */   }
/*    */   public void setName(String aName) {
/* 50 */     super.setName(aName);
/* 51 */     this.m_Arg.setName(aName);
/*    */   }
/*    */   public void setRemark(String remark) {
/* 54 */     super.setRemark(remark);
/* 55 */     this.m_Arg.setRemark(remark);
/*    */   }
/*    */   public String getRemark() {
/* 58 */     return this.m_Arg.getRemark();
/*    */   }
/*    */ 
/*    */   public String getJavaDataType() {
/* 62 */     return this.m_Arg.getDatatype();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.OperationArgNode
 * JD-Core Version:    0.5.4
 */