/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Sysbo extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "sysbo";
/*     */ 
/*  21 */   public Attribute datasource = new Attribute("datasource", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  23 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  25 */   public Attribute mainattr = new Attribute("mainattr", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  27 */   public Attribute remark = new Attribute("remark", "NMTOKEN", "REQUIRED", "");
/*     */   protected Mapingenty _objMapingenty;
/*     */   protected Datafilter _objDatafilter;
/*     */   protected Attrlist _objAttrlist;
/*     */   protected Relationlist _objRelationlist;
/*     */   protected Oplist _objOplist;
/*     */ 
/*     */   public String getDatasource()
/*     */   {
/*  52 */     return this.datasource.getValue();
/*     */   }
/*     */ 
/*     */   public void setDatasource(String value_)
/*     */   {
/*  61 */     this.datasource.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  69 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  78 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getMainattr()
/*     */   {
/*  86 */     return this.mainattr.getValue();
/*     */   }
/*     */ 
/*     */   public void setMainattr(String value_)
/*     */   {
/*  95 */     this.mainattr.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getRemark()
/*     */   {
/* 103 */     return this.remark.getValue();
/*     */   }
/*     */ 
/*     */   public void setRemark(String value_)
/*     */   {
/* 112 */     this.remark.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getMapingentyText()
/*     */   {
/* 120 */     return (this._objMapingenty == null) ? null : this._objMapingenty.getText();
/*     */   }
/*     */ 
/*     */   public void setMapingentyText(String text)
/*     */   {
/* 131 */     if (text == null)
/*     */     {
/* 133 */       this._objMapingenty = null;
/* 134 */       return;
/*     */     }
/*     */ 
/* 137 */     if (this._objMapingenty == null) {
/* 138 */       this._objMapingenty = new Mapingenty();
/*     */     }
/* 140 */     this._objMapingenty.setText(text);
/* 141 */     this._objMapingenty._setParent(this);
/*     */   }
/*     */ 
/*     */   public Mapingenty getMapingenty()
/*     */   {
/* 149 */     return this._objMapingenty;
/*     */   }
/*     */ 
/*     */   public void setMapingenty(Mapingenty obj)
/*     */   {
/* 160 */     this._objMapingenty = obj;
/* 161 */     if (obj == null) {
/* 162 */       return;
/*     */     }
/* 164 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public String getDatafilterText()
/*     */   {
/* 171 */     return (this._objDatafilter == null) ? null : this._objDatafilter.getText();
/*     */   }
/*     */ 
/*     */   public void setDatafilterText(String text)
/*     */   {
/* 182 */     if (text == null)
/*     */     {
/* 184 */       this._objDatafilter = null;
/* 185 */       return;
/*     */     }
/*     */ 
/* 188 */     if (this._objDatafilter == null) {
/* 189 */       this._objDatafilter = new Datafilter();
/*     */     }
/* 191 */     this._objDatafilter.setText(text);
/* 192 */     this._objDatafilter._setParent(this);
/*     */   }
/*     */ 
/*     */   public Datafilter getDatafilter()
/*     */   {
/* 200 */     return this._objDatafilter;
/*     */   }
/*     */ 
/*     */   public void setDatafilter(Datafilter obj)
/*     */   {
/* 211 */     this._objDatafilter = obj;
/* 212 */     if (obj == null) {
/* 213 */       return;
/*     */     }
/* 215 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Attrlist getAttrlist()
/*     */   {
/* 222 */     return this._objAttrlist;
/*     */   }
/*     */ 
/*     */   public void setAttrlist(Attrlist obj)
/*     */   {
/* 233 */     this._objAttrlist = obj;
/* 234 */     if (obj == null) {
/* 235 */       return;
/*     */     }
/* 237 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Relationlist getRelationlist()
/*     */   {
/* 244 */     return this._objRelationlist;
/*     */   }
/*     */ 
/*     */   public void setRelationlist(Relationlist obj)
/*     */   {
/* 255 */     this._objRelationlist = obj;
/* 256 */     if (obj == null) {
/* 257 */       return;
/*     */     }
/* 259 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Oplist getOplist()
/*     */   {
/* 266 */     return this._objOplist;
/*     */   }
/*     */ 
/*     */   public void setOplist(Oplist obj)
/*     */   {
/* 277 */     this._objOplist = obj;
/* 278 */     if (obj == null) {
/* 279 */       return;
/*     */     }
/* 281 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 289 */     Element elem = new Element(get_TagName());
/*     */ 
/* 291 */     elem.addAttribute(this.datasource.marshal());
/*     */ 
/* 293 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 295 */     elem.addAttribute(this.mainattr.marshal());
/*     */ 
/* 297 */     elem.addAttribute(this.remark.marshal());
/*     */ 
/* 299 */     if (this._objMapingenty != null)
/*     */     {
/* 301 */       elem.addComment(this._objMapingenty._marshalCommentList());
/* 302 */       elem.addContent(this._objMapingenty.marshal());
/*     */     }
/*     */ 
/* 305 */     if (this._objDatafilter != null)
/*     */     {
/* 307 */       elem.addComment(this._objDatafilter._marshalCommentList());
/* 308 */       elem.addContent(this._objDatafilter.marshal());
/*     */     }
/*     */ 
/* 311 */     if (this._objAttrlist != null)
/*     */     {
/* 313 */       elem.addComment(this._objAttrlist._marshalCommentList());
/* 314 */       elem.addContent(this._objAttrlist.marshal());
/*     */     }
/*     */ 
/* 317 */     if (this._objRelationlist != null)
/*     */     {
/* 319 */       elem.addComment(this._objRelationlist._marshalCommentList());
/* 320 */       elem.addContent(this._objRelationlist.marshal());
/*     */     }
/*     */ 
/* 323 */     if (this._objOplist != null)
/*     */     {
/* 325 */       elem.addComment(this._objOplist._marshalCommentList());
/* 326 */       elem.addContent(this._objOplist.marshal());
/*     */     }
/*     */ 
/* 329 */     elem.addComment(_marshalBottomCommentList());
/* 330 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Sysbo unmarshal(Element elem)
/*     */   {
/* 338 */     if (elem == null) {
/* 339 */       return null;
/*     */     }
/* 341 */     Sysbo __objSysbo = new Sysbo();
/* 342 */     if (__objSysbo != null)
/*     */     {
/* 345 */       __objSysbo.datasource.setValue(elem.getAttribute("datasource"));
/*     */ 
/* 347 */       __objSysbo.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 349 */       __objSysbo.mainattr.setValue(elem.getAttribute("mainattr"));
/*     */ 
/* 351 */       __objSysbo.remark.setValue(elem.getAttribute("remark"));
/*     */     }
/*     */ 
/* 354 */     ArrayList __comments = null;
/* 355 */     Iterator it = elem.getChildObjects().iterator();
/* 356 */     while (it.hasNext())
/*     */     {
/* 358 */       Object __obj = it.next();
/* 359 */       if (__obj instanceof Comment)
/*     */       {
/* 361 */         if (__comments == null) {
/* 362 */           __comments = new ArrayList(2);
/*     */         }
/* 364 */         __comments.add(__obj);
/*     */       }
/* 366 */       else if (__obj instanceof Element)
/*     */       {
/* 368 */         Element __e = (Element)__obj;
/* 369 */         String __name = __e.getName();
/* 370 */         if (__name.equals(Mapingenty._tagName))
/*     */         {
/* 373 */           Mapingenty __objMapingenty = Mapingenty.unmarshal(__e);
/* 374 */           __objSysbo.setMapingenty(__objMapingenty);
/* 375 */           __objMapingenty._unmarshalCommentList(__comments);
/*     */         }
/* 377 */         if (__name.equals(Datafilter._tagName))
/*     */         {
/* 380 */           Datafilter __objDatafilter = Datafilter.unmarshal(__e);
/* 381 */           __objSysbo.setDatafilter(__objDatafilter);
/* 382 */           __objDatafilter._unmarshalCommentList(__comments);
/*     */         }
/* 384 */         if (__name.equals(Attrlist._tagName))
/*     */         {
/* 387 */           Attrlist __objAttrlist = Attrlist.unmarshal(__e);
/* 388 */           __objSysbo.setAttrlist(__objAttrlist);
/* 389 */           __objAttrlist._unmarshalCommentList(__comments);
/*     */         }
/* 391 */         if (__name.equals(Relationlist._tagName))
/*     */         {
/* 394 */           Relationlist __objRelationlist = Relationlist.unmarshal(__e);
/* 395 */           __objSysbo.setRelationlist(__objRelationlist);
/* 396 */           __objRelationlist._unmarshalCommentList(__comments);
/*     */         }
/* 398 */         if (__name.equals(Oplist._tagName))
/*     */         {
/* 401 */           Oplist __objOplist = Oplist.unmarshal(__e);
/* 402 */           __objSysbo.setOplist(__objOplist);
/* 403 */           __objOplist._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 406 */         __comments = null;
/*     */       }
/*     */     }
/* 409 */     __objSysbo._unmarshalBottomCommentList(__comments);
/* 410 */     return __objSysbo;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 427 */     ErrorList errors = new ErrorList();
/*     */ 
/* 430 */     if (this._objMapingenty != null)
/* 431 */       errors.add(this._objMapingenty.validate(firstError));
/*     */     else
/* 433 */       errors.add(new ElementError(this, Mapingenty.class));
/* 434 */     if ((firstError) && (errors.size() > 0)) {
/* 435 */       return errors;
/*     */     }
/* 437 */     if (this._objDatafilter != null)
/* 438 */       errors.add(this._objDatafilter.validate(firstError));
/*     */     else
/* 440 */       errors.add(new ElementError(this, Datafilter.class));
/* 441 */     if ((firstError) && (errors.size() > 0)) {
/* 442 */       return errors;
/*     */     }
/* 444 */     if (this._objAttrlist != null)
/* 445 */       errors.add(this._objAttrlist.validate(firstError));
/*     */     else
/* 447 */       errors.add(new ElementError(this, Attrlist.class));
/* 448 */     if ((firstError) && (errors.size() > 0)) {
/* 449 */       return errors;
/*     */     }
/* 451 */     if (this._objRelationlist != null)
/* 452 */       errors.add(this._objRelationlist.validate(firstError));
/*     */     else
/* 454 */       errors.add(new ElementError(this, Relationlist.class));
/* 455 */     if ((firstError) && (errors.size() > 0)) {
/* 456 */       return errors;
/*     */     }
/* 458 */     if (this._objOplist != null)
/* 459 */       errors.add(this._objOplist.validate(firstError));
/*     */     else
/* 461 */       errors.add(new ElementError(this, Oplist.class));
/* 462 */     if ((firstError) && (errors.size() > 0)) {
/* 463 */       return errors;
/*     */     }
/* 465 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 474 */     List children = new ArrayList();
/*     */ 
/* 476 */     if (this._objMapingenty != null) {
/* 477 */       children.add(this._objMapingenty);
/*     */     }
/* 479 */     if (this._objDatafilter != null) {
/* 480 */       children.add(this._objDatafilter);
/*     */     }
/* 482 */     if (this._objAttrlist != null) {
/* 483 */       children.add(this._objAttrlist);
/*     */     }
/* 485 */     if (this._objRelationlist != null) {
/* 486 */       children.add(this._objRelationlist);
/*     */     }
/* 488 */     if (this._objOplist != null)
/* 489 */       children.add(this._objOplist);
/* 490 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 499 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Sysbo
 * JD-Core Version:    0.5.4
 */