/*      */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*      */ 
/*      */ import com.borland.xml.toolkit.Comment;
/*      */ import com.borland.xml.toolkit.DOMAdapterNotFoundException;
/*      */ import com.borland.xml.toolkit.Element;
/*      */ import com.borland.xml.toolkit.ElementError;
/*      */ import com.borland.xml.toolkit.ErrorList;
/*      */ import com.borland.xml.toolkit.Outputter;
/*      */ import com.borland.xml.toolkit.XmlObject;
/*      */ import com.borland.xml.toolkit.XmlUtil;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.net.URL;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import org.xml.sax.DTDHandler;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ 
/*      */ public class Sysbolist extends XmlObject
/*      */ {
/*   19 */   public static String _tagName = "sysbolist";
/*      */   protected Package _objPackage;
/*   23 */   protected ArrayList _objSysbo = new ArrayList();
/*      */ 
/*   25 */   protected String publicId = "";
/*      */ 
/*   27 */   protected String systemId = "";
/*      */ 
/*   29 */   protected Outputter _outputter = null;
/*      */ 
/*      */   public String getPackageText()
/*      */   {
/*   44 */     return (this._objPackage == null) ? null : this._objPackage.getText();
/*      */   }
/*      */ 
/*      */   public void setPackageText(String text)
/*      */   {
/*   55 */     if (text == null)
/*      */     {
/*   57 */       this._objPackage = null;
/*   58 */       return;
/*      */     }
/*      */ 
/*   61 */     if (this._objPackage == null) {
/*   62 */       this._objPackage = new Package();
/*      */     }
/*   64 */     this._objPackage.setText(text);
/*   65 */     this._objPackage._setParent(this);
/*      */   }
/*      */ 
/*      */   public Package getPackage()
/*      */   {
/*   73 */     return this._objPackage;
/*      */   }
/*      */ 
/*      */   public void setPackage(Package obj)
/*      */   {
/*   84 */     this._objPackage = obj;
/*   85 */     if (obj == null) {
/*   86 */       return;
/*      */     }
/*   88 */     obj._setParent(this);
/*      */   }
/*      */ 
/*      */   public Sysbo[] getSysbo()
/*      */   {
/*   96 */     return (Sysbo[])(Sysbo[])this._objSysbo.toArray(new Sysbo[0]);
/*      */   }
/*      */ 
/*      */   public void setSysbo(Sysbo[] objArray)
/*      */   {
/*  106 */     if ((objArray == null) || (objArray.length == 0)) {
/*  107 */       this._objSysbo.clear();
/*      */     }
/*      */     else {
/*  110 */       this._objSysbo = new ArrayList(Arrays.asList(objArray));
/*  111 */       for (int i = 0; i < objArray.length; ++i)
/*      */       {
/*  113 */         if (objArray[i] != null)
/*  114 */           objArray[i]._setParent(this);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Sysbo getSysbo(int index)
/*      */   {
/*  126 */     return (Sysbo)this._objSysbo.get(index);
/*      */   }
/*      */ 
/*      */   public void setSysbo(int index, Sysbo obj)
/*      */   {
/*  137 */     if (obj == null) {
/*  138 */       removeSysbo(index);
/*      */     }
/*      */     else {
/*  141 */       this._objSysbo.set(index, obj);
/*  142 */       obj._setParent(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getSysboCount()
/*      */   {
/*  151 */     return this._objSysbo.size();
/*      */   }
/*      */ 
/*      */   public boolean isNoSysbo()
/*      */   {
/*  160 */     return this._objSysbo.size() == 0;
/*      */   }
/*      */ 
/*      */   public List getSysboList()
/*      */   {
/*  168 */     return Collections.unmodifiableList(this._objSysbo);
/*      */   }
/*      */ 
/*      */   public boolean addSysbo(Sysbo obj)
/*      */   {
/*  178 */     if (obj == null) {
/*  179 */       return false;
/*      */     }
/*  181 */     obj._setParent(this);
/*  182 */     return this._objSysbo.add(obj);
/*      */   }
/*      */ 
/*      */   public boolean addSysbo(Collection coSysbo)
/*      */   {
/*  192 */     if (coSysbo == null) {
/*  193 */       return false;
/*      */     }
/*  195 */     Iterator it = coSysbo.iterator();
/*  196 */     while (it.hasNext())
/*      */     {
/*  198 */       Object obj = it.next();
/*  199 */       if ((obj != null) && (obj instanceof XmlObject))
/*  200 */         ((XmlObject)obj)._setParent(this);
/*      */     }
/*  202 */     return this._objSysbo.addAll(coSysbo);
/*      */   }
/*      */ 
/*      */   public Sysbo removeSysbo(int index)
/*      */   {
/*  211 */     return (Sysbo)this._objSysbo.remove(index);
/*      */   }
/*      */ 
/*      */   public boolean removeSysbo(Sysbo obj)
/*      */   {
/*  221 */     return this._objSysbo.remove(obj);
/*      */   }
/*      */ 
/*      */   public void clearSysboList()
/*      */   {
/*  229 */     this._objSysbo.clear();
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out)
/*      */     throws IOException
/*      */   {
/*  239 */     Element elem = marshal();
/*  240 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent)
/*      */     throws IOException
/*      */   {
/*  262 */     Element elem = marshal();
/*  263 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  286 */     Element elem = marshal();
/*  287 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  320 */     Element elem = marshal();
/*  321 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(OutputStream out, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  338 */     Element elem = marshal();
/*  339 */     XmlUtil.writeDocument(out, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName)
/*      */     throws IOException
/*      */   {
/*  351 */     Element elem = marshal();
/*  352 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent)
/*      */     throws IOException
/*      */   {
/*  375 */     Element elem = marshal();
/*  376 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  399 */     Element elem = marshal();
/*  400 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  433 */     Element elem = marshal();
/*  434 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(String fileName, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  451 */     Element elem = marshal();
/*  452 */     XmlUtil.writeDocument(fileName, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(File file)
/*      */     throws IOException
/*      */   {
/*  464 */     Element elem = marshal();
/*  465 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent)
/*      */     throws IOException
/*      */   {
/*  488 */     Element elem = marshal();
/*  489 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  512 */     Element elem = marshal();
/*  513 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  546 */     Element elem = marshal();
/*  547 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(File file, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  564 */     Element elem = marshal();
/*  565 */     XmlUtil.writeDocument(file, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer)
/*      */     throws IOException
/*      */   {
/*  577 */     Element elem = marshal();
/*  578 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), this._outputter);
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent)
/*      */     throws IOException
/*      */   {
/*  601 */     Element elem = marshal();
/*  602 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent, String encoding)
/*      */     throws IOException
/*      */   {
/*  625 */     Element elem = marshal();
/*  626 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent, encoding));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, String indent, boolean newlines, String encoding, boolean printEncoding, boolean printDeclaration)
/*      */     throws IOException
/*      */   {
/*  659 */     Element elem = marshal();
/*  660 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), new Outputter(indent, newlines, encoding, printEncoding, printDeclaration));
/*      */   }
/*      */ 
/*      */   public void marshal(Writer writer, Outputter outputter)
/*      */     throws IOException
/*      */   {
/*  677 */     Element elem = marshal();
/*  678 */     XmlUtil.writeDocument(writer, elem, getPublicId(), getSystemId(), outputter);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(InputStream in, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  703 */     Element elem = XmlUtil.getDocRootElement(in, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  706 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(InputStream in, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  724 */     Element elem = XmlUtil.getDocRootElement(in, domParserClass, validation);
/*      */ 
/*  726 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(InputStream in)
/*      */   {
/*  735 */     return unmarshal(XmlUtil.getDocRootElement(in));
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(File file, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  759 */     Element elem = XmlUtil.getDocRootElement(file, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  762 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(File file, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  780 */     Element elem = XmlUtil.getDocRootElement(file, domParserClass, validation);
/*      */ 
/*  782 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(File file)
/*      */   {
/*  791 */     return unmarshal(XmlUtil.getDocRootElement(file));
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(String fileName, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  815 */     Element elem = XmlUtil.getDocRootElement(fileName, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  818 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(String fileName, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  836 */     Element elem = XmlUtil.getDocRootElement(fileName, domParserClass, validation);
/*      */ 
/*  838 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(String fileName)
/*      */   {
/*  847 */     return unmarshal(XmlUtil.getDocRootElement(fileName));
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(URL url, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  871 */     Element elem = XmlUtil.getDocRootElement(url, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  874 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(URL url, String domParserClass, boolean validation)
/*      */     throws DOMAdapterNotFoundException
/*      */   {
/*  892 */     Element elem = XmlUtil.getDocRootElement(url, domParserClass, validation);
/*      */ 
/*  894 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(URL url)
/*      */   {
/*  903 */     return unmarshal(XmlUtil.getDocRootElement(url));
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(Reader reader, String saxParserClass, boolean validation, EntityResolver entityResolver, DTDHandler dtdHandler, ErrorHandler errorHandler)
/*      */   {
/*  927 */     Element elem = XmlUtil.getDocRootElement(reader, saxParserClass, validation, entityResolver, dtdHandler, errorHandler);
/*      */ 
/*  930 */     return unmarshal(elem);
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(Reader reader)
/*      */   {
/*  939 */     return unmarshal(XmlUtil.getDocRootElement(reader));
/*      */   }
/*      */ 
/*      */   public void _setOutputter(Outputter outputter)
/*      */   {
/*  947 */     this._outputter = outputter;
/*      */   }
/*      */ 
/*      */   public Outputter _getOutputter()
/*      */   {
/*  955 */     return this._outputter;
/*      */   }
/*      */ 
/*      */   public void _setIndent(String indent)
/*      */   {
/*  965 */     if (this._outputter == null) {
/*  966 */       this._outputter = new Outputter();
/*      */     }
/*  968 */     this._outputter.setIndent(indent);
/*      */   }
/*      */ 
/*      */   public void _setIndentSize(int indentSize)
/*      */   {
/*  977 */     if (this._outputter == null) {
/*  978 */       this._outputter = new Outputter();
/*      */     }
/*  980 */     this._outputter.setIndentSize(indentSize);
/*      */   }
/*      */ 
/*      */   public void _setNewlines(boolean newlines)
/*      */   {
/*  990 */     if (this._outputter == null) {
/*  991 */       this._outputter = new Outputter();
/*      */     }
/*  993 */     this._outputter.setNewlines(newlines);
/*      */   }
/*      */ 
/*      */   public void _setEncoding(String encoding)
/*      */   {
/* 1001 */     if (this._outputter == null) {
/* 1002 */       this._outputter = new Outputter();
/*      */     }
/* 1004 */     this._outputter.setEncoding(encoding);
/*      */   }
/*      */ 
/*      */   public void _setPrintEncoding(boolean printEncoding)
/*      */   {
/* 1013 */     if (this._outputter == null) {
/* 1014 */       this._outputter = new Outputter();
/*      */     }
/* 1016 */     this._outputter.setPrintEncoding(printEncoding);
/*      */   }
/*      */ 
/*      */   public void _setPrintXMLDeclaration(boolean printXMLDeclaration)
/*      */   {
/* 1024 */     if (this._outputter == null) {
/* 1025 */       this._outputter = new Outputter();
/*      */     }
/* 1027 */     this._outputter.setPrintXMLDeclaration(printXMLDeclaration);
/*      */   }
/*      */ 
/*      */   public String getPublicId()
/*      */   {
/* 1035 */     return this.publicId;
/*      */   }
/*      */ 
/*      */   public void setPublicId(String publicId)
/*      */   {
/* 1043 */     this.publicId = publicId;
/*      */   }
/*      */ 
/*      */   public String getSystemId()
/*      */   {
/* 1051 */     return this.systemId;
/*      */   }
/*      */ 
/*      */   public void setSystemId(String systemId)
/*      */   {
/* 1059 */     this.systemId = systemId;
/*      */   }
/*      */ 
/*      */   public Element marshal()
/*      */   {
/* 1067 */     Element elem = new Element(get_TagName());
/*      */ 
/* 1069 */     if (this._objPackage != null)
/*      */     {
/* 1071 */       elem.addComment(this._objPackage._marshalCommentList());
/* 1072 */       elem.addContent(this._objPackage.marshal());
/*      */     }
/*      */ 
/* 1075 */     Iterator it1 = this._objSysbo.iterator();
/* 1076 */     while (it1.hasNext())
/*      */     {
/* 1078 */       Sysbo obj = (Sysbo)it1.next();
/* 1079 */       if (obj != null)
/*      */       {
/* 1081 */         elem.addComment(obj._marshalCommentList());
/* 1082 */         elem.addContent(obj.marshal());
/*      */       }
/*      */     }
/*      */ 
/* 1086 */     elem.addComment(_marshalBottomCommentList());
/* 1087 */     return elem;
/*      */   }
/*      */ 
/*      */   public static Sysbolist unmarshal(Element elem)
/*      */   {
/* 1095 */     if (elem == null) {
/* 1096 */       return null;
/*      */     }
/* 1098 */     Sysbolist __objSysbolist = new Sysbolist();
/*      */ 
/* 1100 */     ArrayList __comments = null;
/* 1101 */     Iterator it = elem.getChildObjects().iterator();
/* 1102 */     while (it.hasNext())
/*      */     {
/* 1104 */       Object __obj = it.next();
/* 1105 */       if (__obj instanceof Comment)
/*      */       {
/* 1107 */         if (__comments == null) {
/* 1108 */           __comments = new ArrayList(2);
/*      */         }
/* 1110 */         __comments.add(__obj);
/*      */       }
/* 1112 */       else if (__obj instanceof Element)
/*      */       {
/* 1114 */         Element __e = (Element)__obj;
/* 1115 */         String __name = __e.getName();
/* 1116 */         if (__name.equals(Package._tagName))
/*      */         {
/* 1119 */           Package __objPackage = Package.unmarshal(__e);
/* 1120 */           __objSysbolist.setPackage(__objPackage);
/* 1121 */           __objPackage._unmarshalCommentList(__comments);
/*      */         }
/* 1123 */         if (__name.equals(Sysbo._tagName))
/*      */         {
/* 1126 */           Sysbo __objSysbo = Sysbo.unmarshal(__e);
/* 1127 */           __objSysbolist.addSysbo(__objSysbo);
/* 1128 */           __objSysbo._unmarshalCommentList(__comments);
/*      */         }
/*      */ 
/* 1131 */         __comments = null;
/*      */       }
/*      */     }
/* 1134 */     __objSysbolist._unmarshalBottomCommentList(__comments);
/* 1135 */     return __objSysbolist;
/*      */   }
/*      */ 
/*      */   public ErrorList validate(boolean firstError)
/*      */   {
/* 1152 */     ErrorList errors = new ErrorList();
/*      */ 
/* 1155 */     if (this._objPackage != null)
/* 1156 */       errors.add(this._objPackage.validate(firstError));
/*      */     else
/* 1158 */       errors.add(new ElementError(this, Package.class));
/* 1159 */     if ((firstError) && (errors.size() > 0)) {
/* 1160 */       return errors;
/*      */     }
/* 1162 */     if (this._objSysbo.size() == 0)
/*      */     {
/* 1164 */       errors.add(new ElementError(this, Sysbo.class));
/* 1165 */       if (firstError)
/* 1166 */         return errors;
/*      */     }
/*      */     else
/*      */     {
/* 1170 */       Iterator it1 = this._objSysbo.iterator();
/* 1171 */       while (it1.hasNext())
/*      */       {
/* 1173 */         Sysbo obj = (Sysbo)it1.next();
/* 1174 */         if (obj != null)
/*      */         {
/* 1176 */           errors.add(obj.validate(firstError));
/* 1177 */           if ((firstError) && (errors.size() > 0)) {
/* 1178 */             return errors;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1183 */     return (errors.size() == 0) ? null : errors;
/*      */   }
/*      */ 
/*      */   public List _getChildren()
/*      */   {
/* 1192 */     List children = new ArrayList();
/*      */ 
/* 1194 */     if (this._objPackage != null) {
/* 1195 */       children.add(this._objPackage);
/*      */     }
/* 1197 */     if ((this._objSysbo != null) && (this._objSysbo.size() > 0))
/* 1198 */       children.add(this._objSysbo);
/* 1199 */     return children;
/*      */   }
/*      */ 
/*      */   public String get_TagName()
/*      */   {
/* 1208 */     return _tagName;
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Sysbolist
 * JD-Core Version:    0.5.4
 */