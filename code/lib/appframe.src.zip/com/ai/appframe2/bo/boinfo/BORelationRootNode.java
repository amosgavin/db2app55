/*    */ package com.ai.appframe2.bo.boinfo;
/*    */ 
/*    */ import com.ai.appframe2.bo.boinfo.boinfoxml.Relation;
/*    */ import com.ai.appframe2.bo.boinfo.boinfoxml.Relationlist;
/*    */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*    */ import com.borland.xml.toolkit.XmlObject;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class BORelationRootNode extends AbstractNode
/*    */ {
/* 18 */   private Relationlist m_RelationList = null;
/*    */ 
/* 20 */   public BORelationRootNode(AbstractNode aSuper, AbstractNode aParent) { super(aSuper, aParent, "RelationRoot"); }
/*    */ 
/*    */   public void buildTree(XmlObject aNode) {
/* 23 */     if (aNode == null)
/* 24 */       return;
/* 25 */     Relationlist objRelationlist = (Relationlist)aNode;
/* 26 */     this.m_RelationList = objRelationlist;
/* 27 */     int count = objRelationlist.getRelationCount();
/* 28 */     setNodeObject(objRelationlist);
/* 29 */     for (int i = 0; i < count; ++i) {
/* 30 */       Relation objRelation = objRelationlist.getRelation(i);
/* 31 */       BORelationNode objRelationNode = new BORelationNode(getParentNode(), this, objRelation.getName());
/* 32 */       addChild(objRelation.getName(), objRelationNode);
/* 33 */       objRelationNode.buildTree(objRelation);
/*    */     }
/*    */   }
/*    */ 
/*    */   public BORelationInterface addRelation(String aName) {
/* 38 */     BORelationNode objRelationNode = new BORelationNode(getParentNode(), this, aName);
/* 39 */     Relation objRelation = new Relation();
/* 40 */     this.m_RelationList.addRelation(objRelation);
/* 41 */     objRelationNode.buildTree(objRelation);
/* 42 */     addChild(aName, objRelationNode);
/* 43 */     return objRelationNode;
/*    */   }
/*    */ 
/*    */   public List getRelationList() {
/* 47 */     if (getChildSet() != null) {
/* 48 */       return new ArrayList(getChildSet().values());
/*    */     }
/* 50 */     return new ArrayList(0);
/*    */   }
/*    */ 
/*    */   public BORelationInterface[] getRelationArray() {
/* 54 */     Object[] obj = getRelationList().toArray(new Object[0]);
/* 55 */     BORelationInterface[] objRelation = new BORelationInterface[obj.length];
/* 56 */     System.arraycopy(obj, 0, objRelation, 0, obj.length);
/* 57 */     return objRelation;
/*    */   }
/*    */ 
/*    */   public void removeRelation(String aName)
/*    */   {
/* 63 */     BORelationNode objRelationNode = (BORelationNode)getChild(aName);
/* 64 */     if (objRelationNode != null) {
/* 65 */       this.m_RelationList.removeRelation((Relation)objRelationNode.getNodeObject());
/* 66 */       removeChild(aName);
/*    */     }
/*    */   }
/*    */ 
/*    */   public BORelationInterface getRelation(String aName) {
/* 71 */     return (BORelationNode)getChild(aName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BORelationRootNode
 * JD-Core Version:    0.5.4
 */