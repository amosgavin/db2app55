package com.ai.appframe2.bo.boinfo;

import com.ai.appframe2.common.mutablenode.AbstractNodeInterface;
import java.util.List;

public abstract interface BOOperationInterface extends AbstractNodeInterface
{
  public abstract String[] getCommandArray();

  public abstract void setExecuteCondiction(String paramString);

  public abstract String getExecuteCondiction();

  public abstract String getOperationType();

  public abstract void setOperationType(String paramString);

  public abstract void setCommands(String paramString);

  public abstract String getCommands();

  public abstract OperationArgInterface getArg(String paramString);

  public abstract List getArgList();

  public abstract OperationArgInterface addArg(String paramString);

  public abstract void removeArg(String paramString);

  public abstract String getCommandRemark();

  public abstract void setCommandRemark(String paramString);

  public abstract OperationArgNode[] getArgs();

  public abstract void removeAllArg();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOOperationInterface
 * JD-Core Version:    0.5.4
 */