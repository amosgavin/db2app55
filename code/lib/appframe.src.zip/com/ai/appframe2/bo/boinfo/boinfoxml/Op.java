/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Op extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "op";
/*     */ 
/*  21 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  23 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  25 */   public Attribute remark = new Attribute("remark", "NMTOKEN", "REQUIRED", "");
/*     */   protected Condiction _objCondiction;
/*     */   protected Arglist _objArglist;
/*     */   protected Sql _objSql;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  46 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  55 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  63 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/*  72 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getRemark()
/*     */   {
/*  80 */     return this.remark.getValue();
/*     */   }
/*     */ 
/*     */   public void setRemark(String value_)
/*     */   {
/*  89 */     this.remark.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getCondictionText()
/*     */   {
/*  97 */     return (this._objCondiction == null) ? null : this._objCondiction.getText();
/*     */   }
/*     */ 
/*     */   public void setCondictionText(String text)
/*     */   {
/* 108 */     if (text == null)
/*     */     {
/* 110 */       this._objCondiction = null;
/* 111 */       return;
/*     */     }
/*     */ 
/* 114 */     if (this._objCondiction == null) {
/* 115 */       this._objCondiction = new Condiction();
/*     */     }
/* 117 */     this._objCondiction.setText(text);
/* 118 */     this._objCondiction._setParent(this);
/*     */   }
/*     */ 
/*     */   public Condiction getCondiction()
/*     */   {
/* 126 */     return this._objCondiction;
/*     */   }
/*     */ 
/*     */   public void setCondiction(Condiction obj)
/*     */   {
/* 137 */     this._objCondiction = obj;
/* 138 */     if (obj == null) {
/* 139 */       return;
/*     */     }
/* 141 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Arglist getArglist()
/*     */   {
/* 148 */     return this._objArglist;
/*     */   }
/*     */ 
/*     */   public void setArglist(Arglist obj)
/*     */   {
/* 159 */     this._objArglist = obj;
/* 160 */     if (obj == null) {
/* 161 */       return;
/*     */     }
/* 163 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public String getSqlText()
/*     */   {
/* 170 */     return (this._objSql == null) ? null : this._objSql.getText();
/*     */   }
/*     */ 
/*     */   public void setSqlText(String text)
/*     */   {
/* 181 */     if (text == null)
/*     */     {
/* 183 */       this._objSql = null;
/* 184 */       return;
/*     */     }
/*     */ 
/* 187 */     if (this._objSql == null) {
/* 188 */       this._objSql = new Sql();
/*     */     }
/* 190 */     this._objSql.setText(text);
/* 191 */     this._objSql._setParent(this);
/*     */   }
/*     */ 
/*     */   public Sql getSql()
/*     */   {
/* 199 */     return this._objSql;
/*     */   }
/*     */ 
/*     */   public void setSql(Sql obj)
/*     */   {
/* 210 */     this._objSql = obj;
/* 211 */     if (obj == null) {
/* 212 */       return;
/*     */     }
/* 214 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 222 */     Element elem = new Element(get_TagName());
/*     */ 
/* 224 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 226 */     elem.addAttribute(this.type.marshal());
/*     */ 
/* 228 */     elem.addAttribute(this.remark.marshal());
/*     */ 
/* 230 */     if (this._objCondiction != null)
/*     */     {
/* 232 */       elem.addComment(this._objCondiction._marshalCommentList());
/* 233 */       elem.addContent(this._objCondiction.marshal());
/*     */     }
/*     */ 
/* 236 */     if (this._objArglist != null)
/*     */     {
/* 238 */       elem.addComment(this._objArglist._marshalCommentList());
/* 239 */       elem.addContent(this._objArglist.marshal());
/*     */     }
/*     */ 
/* 242 */     if (this._objSql != null)
/*     */     {
/* 244 */       elem.addComment(this._objSql._marshalCommentList());
/* 245 */       elem.addContent(this._objSql.marshal());
/*     */     }
/*     */ 
/* 248 */     elem.addComment(_marshalBottomCommentList());
/* 249 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Op unmarshal(Element elem)
/*     */   {
/* 257 */     if (elem == null) {
/* 258 */       return null;
/*     */     }
/* 260 */     Op __objOp = new Op();
/* 261 */     if (__objOp != null)
/*     */     {
/* 264 */       __objOp.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 266 */       __objOp.type.setValue(elem.getAttribute("type"));
/*     */ 
/* 268 */       __objOp.remark.setValue(elem.getAttribute("remark"));
/*     */     }
/*     */ 
/* 271 */     ArrayList __comments = null;
/* 272 */     Iterator it = elem.getChildObjects().iterator();
/* 273 */     while (it.hasNext())
/*     */     {
/* 275 */       Object __obj = it.next();
/* 276 */       if (__obj instanceof Comment)
/*     */       {
/* 278 */         if (__comments == null) {
/* 279 */           __comments = new ArrayList(2);
/*     */         }
/* 281 */         __comments.add(__obj);
/*     */       }
/* 283 */       else if (__obj instanceof Element)
/*     */       {
/* 285 */         Element __e = (Element)__obj;
/* 286 */         String __name = __e.getName();
/* 287 */         if (__name.equals(Condiction._tagName))
/*     */         {
/* 290 */           Condiction __objCondiction = Condiction.unmarshal(__e);
/* 291 */           __objOp.setCondiction(__objCondiction);
/* 292 */           __objCondiction._unmarshalCommentList(__comments);
/*     */         }
/* 294 */         if (__name.equals(Arglist._tagName))
/*     */         {
/* 297 */           Arglist __objArglist = Arglist.unmarshal(__e);
/* 298 */           __objOp.setArglist(__objArglist);
/* 299 */           __objArglist._unmarshalCommentList(__comments);
/*     */         }
/* 301 */         if (__name.equals(Sql._tagName))
/*     */         {
/* 304 */           Sql __objSql = Sql.unmarshal(__e);
/* 305 */           __objOp.setSql(__objSql);
/* 306 */           __objSql._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 309 */         __comments = null;
/*     */       }
/*     */     }
/* 312 */     __objOp._unmarshalBottomCommentList(__comments);
/* 313 */     return __objOp;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 330 */     ErrorList errors = new ErrorList();
/*     */ 
/* 333 */     if (this._objCondiction != null)
/* 334 */       errors.add(this._objCondiction.validate(firstError));
/*     */     else
/* 336 */       errors.add(new ElementError(this, Condiction.class));
/* 337 */     if ((firstError) && (errors.size() > 0)) {
/* 338 */       return errors;
/*     */     }
/* 340 */     if (this._objArglist != null)
/* 341 */       errors.add(this._objArglist.validate(firstError));
/*     */     else
/* 343 */       errors.add(new ElementError(this, Arglist.class));
/* 344 */     if ((firstError) && (errors.size() > 0)) {
/* 345 */       return errors;
/*     */     }
/* 347 */     if (this._objSql != null)
/* 348 */       errors.add(this._objSql.validate(firstError));
/*     */     else
/* 350 */       errors.add(new ElementError(this, Sql.class));
/* 351 */     if ((firstError) && (errors.size() > 0)) {
/* 352 */       return errors;
/*     */     }
/* 354 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 363 */     List children = new ArrayList();
/*     */ 
/* 365 */     if (this._objCondiction != null) {
/* 366 */       children.add(this._objCondiction);
/*     */     }
/* 368 */     if (this._objArglist != null) {
/* 369 */       children.add(this._objArglist);
/*     */     }
/* 371 */     if (this._objSql != null)
/* 372 */       children.add(this._objSql);
/* 373 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 382 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Op
 * JD-Core Version:    0.5.4
 */