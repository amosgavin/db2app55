/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.TextElement;
/*     */ 
/*     */ public class Fkattr extends TextElement
/*     */ {
/*  18 */   public static String _tagName = "fkattr";
/*     */ 
/*  20 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Fkattr()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Fkattr(String text)
/*     */   {
/*  35 */     super(text);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  43 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  52 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/*  60 */     Element elem = super.marshal();
/*     */ 
/*  62 */     elem.addAttribute(this.name.marshal());
/*  63 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Fkattr unmarshal(Element elem)
/*     */   {
/*  71 */     Fkattr __objFkattr = (Fkattr)TextElement.unmarshal(elem, new Fkattr());
/*  72 */     if (__objFkattr != null)
/*     */     {
/*  75 */       __objFkattr.name.setValue(elem.getAttribute("name"));
/*     */     }
/*  77 */     return __objFkattr;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/*  94 */     ErrorList errors = new ErrorList();
/*     */ 
/*  97 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 106 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Fkattr
 * JD-Core Version:    0.5.4
 */