/*    */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class Link extends TextElement
/*    */ {
/* 18 */   public static String _tagName = "link";
/*    */ 
/*    */   public Link()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Link(String text)
/*    */   {
/* 33 */     super(text);
/*    */   }
/*    */ 
/*    */   public static Link unmarshal(Element elem)
/*    */   {
/* 42 */     Link __objLink = (Link)TextElement.unmarshal(elem, new Link());
/* 43 */     return __objLink;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 53 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Link
 * JD-Core Version:    0.5.4
 */