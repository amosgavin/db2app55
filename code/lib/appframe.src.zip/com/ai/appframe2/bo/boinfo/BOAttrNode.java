/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Attr;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Autovalue;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Displaycol;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Fkattr;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Mapingcol;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ public class BOAttrNode extends AbstractNode
/*     */   implements BOAttrInterface, Property
/*     */ {
/*  22 */   private ArrayList displayColName = new ArrayList();
/*     */   private List displayAttr;
/*     */   private List FKAttr;
/*  28 */   private Attr m_Attr = null;
/*     */ 
/*  32 */   private boolean m_hasAlias = false;
/*  33 */   private boolean m_isInitalHasAlias = false;
/*     */ 
/*  35 */   public BOAttrNode(AbstractNode aSuper, AbstractNode aParent, String aName) { super(aSuper, aParent, aName); }
/*     */ 
/*     */   public boolean hasAlias()
/*     */   {
/*  39 */     if (!this.m_isInitalHasAlias) {
/*  40 */       this.m_hasAlias = (!getName().equalsIgnoreCase(getMapingColName()));
/*  41 */       this.m_isInitalHasAlias = true;
/*     */     }
/*  43 */     return this.m_hasAlias;
/*     */   }
/*     */   public void setType(String type) {
/*  46 */     this.m_Attr.setType(type);
/*     */   }
/*     */   public String getType() {
/*  49 */     return this.m_Attr.getType();
/*     */   }
/*     */   public void setDatatype(String datatype) {
/*  52 */     this.m_Attr.setDatatype(datatype);
/*     */   }
/*     */   public String getDatatype() {
/*  55 */     return this.m_Attr.getDatatype();
/*     */   }
/*     */   public void setMaxLength(int maxLength) {
/*  58 */     this.m_Attr.setMaxlength(String.valueOf(maxLength));
/*     */   }
/*     */   public int getMaxLength() {
/*  61 */     if ((this.m_Attr.getMaxlength() != null) && (!this.m_Attr.getMaxlength().trim().equals(""))) {
/*  62 */       return Integer.parseInt(this.m_Attr.getMaxlength());
/*     */     }
/*  64 */     return 20;
/*     */   }
/*     */   public void setFloatLength(int floatLength) {
/*  67 */     this.m_Attr.setFloatlength(String.valueOf(floatLength));
/*     */   }
/*     */   public int getFloatLength() {
/*  70 */     if ((this.m_Attr.getFloatlength() != null) && (!this.m_Attr.getFloatlength().trim().equals("")))
/*  71 */       return Integer.parseInt(this.m_Attr.getFloatlength());
/*  72 */     return 0;
/*     */   }
/*     */   public void setMapingColName(String mapingColName) {
/*  75 */     if (this.m_Attr.getMapingcol() == null) {
/*  76 */       this.m_Attr.setMapingcol(new Mapingcol());
/*     */     }
/*  78 */     this.m_Attr.getMapingcol().setText(mapingColName);
/*     */   }
/*     */   public String getMapingColName() {
/*  81 */     if (this.m_Attr.getMapingcol() == null)
/*  82 */       return null;
/*  83 */     return this.m_Attr.getMapingcol().getText();
/*     */   }
/*     */   public void setMapingColType(String mapingColType) {
/*  86 */     if (this.m_Attr.getMapingcol() == null) {
/*  87 */       this.m_Attr.setMapingcol(new Mapingcol());
/*     */     }
/*  89 */     this.m_Attr.getMapingcol().setDatatype(mapingColType);
/*     */   }
/*     */   public String getMapingColType() {
/*  92 */     if (this.m_Attr.getMapingcol() == null)
/*  93 */       return null;
/*  94 */     return this.m_Attr.getMapingcol().getDatatype();
/*     */   }
/*     */ 
/*     */   public List getDisplayColName() {
/*  98 */     return this.displayColName;
/*     */   }
/*     */ 
/*     */   public List getDisplayAttrList() {
/* 102 */     return this.displayAttr;
/*     */   }
/*     */ 
/*     */   public void setDisplayEnty(String displayEnty) {
/* 106 */     if (this.m_Attr.getDisplaycol() == null) {
/* 107 */       this.m_Attr.setDisplaycol(new Displaycol());
/*     */     }
/* 109 */     this.m_Attr.getDisplaycol().setFkbo(displayEnty);
/*     */   }
/*     */   public String getDisplayEnty() {
/* 112 */     if (this.m_Attr.getDisplaycol() != null) {
/* 113 */       return this.m_Attr.getDisplaycol().getFkbo();
/*     */     }
/* 115 */     return null;
/*     */   }
/*     */   public void setDisplayCond(String displayCond) {
/* 118 */     if (this.m_Attr.getDisplaycol() == null) {
/* 119 */       this.m_Attr.setDisplaycol(new Displaycol());
/*     */     }
/* 121 */     this.m_Attr.getDisplaycol().setCond(displayCond);
/*     */   }
/*     */   public String getDisplayCond() {
/* 124 */     if (this.m_Attr.getDisplaycol() != null) {
/* 125 */       return this.m_Attr.getDisplaycol().getCond();
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public void addDisplayCol(String aAttrName, String aColName) {
/* 131 */     if (this.m_Attr.getDisplaycol() != null) {
/* 132 */       Fkattr objAttr = new Fkattr(aColName);
/* 133 */       objAttr.setName(aAttrName);
/* 134 */       this.m_Attr.getDisplaycol().addFkattr(objAttr);
/* 135 */       if (this.FKAttr == null)
/* 136 */         this.FKAttr = new ArrayList();
/* 137 */       this.FKAttr.add(aColName);
/* 138 */       if (this.displayAttr == null)
/* 139 */         this.displayAttr = new ArrayList();
/* 140 */       this.displayAttr.add(aAttrName);
/* 141 */       if (this.displayColName == null)
/* 142 */         this.displayColName = new ArrayList();
/* 143 */       this.displayColName.add(aColName + ";" + aAttrName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeDisplayCol() {
/* 148 */     if (this.m_Attr.getDisplaycol() != null) {
/* 149 */       this.m_Attr.setDisplaycol(null);
/* 150 */       this.FKAttr.clear();
/* 151 */       this.displayAttr.clear();
/* 152 */       this.displayColName.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAutoValue() {
/* 157 */     if (this.m_Attr.getAutovalue() != null)
/* 158 */       this.m_Attr.setAutovalue(null);
/*     */   }
/*     */ 
/*     */   public void setLinkName(String linkName)
/*     */   {
/* 163 */     this.m_Attr.setLinkText(linkName);
/*     */   }
/*     */   public String getLinkName() {
/* 166 */     return this.m_Attr.getLinkText();
/*     */   }
/*     */ 
/*     */   public void buildTree(XmlObject aNode) {
/* 170 */     if (aNode == null)
/* 171 */       return;
/* 172 */     Attr objAttr = (Attr)aNode;
/* 173 */     this.m_Attr = objAttr;
/* 174 */     setNodeObject(objAttr);
/*     */ 
/* 176 */     if (objAttr.getDisplaycol() != null) {
/* 177 */       int count = objAttr.getDisplaycol().getFkattrCount();
/* 178 */       this.displayAttr = new ArrayList(count);
/* 179 */       this.FKAttr = new ArrayList(count);
/* 180 */       for (int i = 0; i < count; ++i) {
/* 181 */         this.FKAttr.add(objAttr.getDisplaycol().getFkattr(i).getText());
/* 182 */         this.displayAttr.add(objAttr.getDisplaycol().getFkattr(i).getName());
/* 183 */         this.displayColName.add(objAttr.getDisplaycol().getFkattr(i).getText() + ";" + objAttr.getDisplaycol().getFkattr(i).getName());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAutoValue(String aAutoValue) {
/* 188 */     if (this.m_Attr.getAutovalue() == null) {
/* 189 */       this.m_Attr.setAutovalue(new Autovalue());
/*     */     }
/* 191 */     this.m_Attr.getAutovalue().setText(aAutoValue);
/*     */   }
/*     */ 
/*     */   public List getFKBOAttr() {
/* 195 */     return this.FKAttr;
/*     */   }
/*     */ 
/*     */   public String getAutoValue() {
/* 199 */     if (this.m_Attr.getAutovalue() != null) {
/* 200 */       return this.m_Attr.getAutovalue().getText();
/*     */     }
/* 202 */     return null;
/*     */   }
/*     */   public String getAutoValueType() {
/* 205 */     if (this.m_Attr.getAutovalue() != null) {
/* 206 */       return this.m_Attr.getAutovalue().getType();
/*     */     }
/* 208 */     return null;
/*     */   }
/*     */   public void setAutoValueType(String autoValueType) {
/* 211 */     if (this.m_Attr.getAutovalue() == null) {
/* 212 */       this.m_Attr.setAutovalue(new Autovalue());
/*     */     }
/* 214 */     this.m_Attr.getAutovalue().setType(autoValueType);
/*     */   }
/*     */   public String getRemark() {
/* 217 */     return this.m_Attr.getRemark();
/*     */   }
/*     */   public void setRemark(String remark) {
/* 220 */     super.setRemark(remark);
/* 221 */     this.m_Attr.setRemark(remark);
/*     */   }
/*     */   public void setName(String aName) {
/* 224 */     super.setName(aName);
/* 225 */     this.m_Attr.setName(aName);
/*     */   }
/*     */ 
/*     */   public String getJavaDataType() {
/* 229 */     return getDatatype();
/*     */   }
/*     */   public String getDatabaseDataType() {
/* 232 */     return getMapingColType();
/*     */   }
/*     */   public String getRelationObjectTypeName() {
/* 235 */     return getDisplayEnty();
/*     */   }
/*     */   public String getRelationCondition() {
/* 238 */     return getDisplayCond();
/*     */   }
/*     */   public String[] getDisplayPropertyNames() {
/* 241 */     if (StringUtils.isEmptyString(getDisplayEnty()))
/* 242 */       return new String[0];
/* 243 */     List objFKAttr = getFKBOAttr();
/* 244 */     if (objFKAttr == null) {
/* 245 */       return new String[0];
/*     */     }
/* 247 */     return (String[])(String[])objFKAttr.toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public String[] getDisplayColNames() {
/* 251 */     if (getDisplayColName() == null) {
/* 252 */       return new String[0];
/*     */     }
/* 254 */     return (String[])(String[])getDisplayColName().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public HashMap getDisplayProperty()
/*     */   {
/* 259 */     if (StringUtils.isEmptyString(getDisplayEnty()))
/* 260 */       return new HashMap();
/* 261 */     BOInterface objBO = BOInfoFactory.getBOInfo(getDisplayEnty());
/* 262 */     List objFKAttr = getFKBOAttr();
/*     */ 
/* 264 */     if (objFKAttr == null)
/* 265 */       return new HashMap();
/* 266 */     HashMap objMap = new HashMap();
/* 267 */     BOAttrInterface objAttr = null;
/* 268 */     for (int i = 0; (objFKAttr != null) && (i < objFKAttr.size()); ++i) {
/* 269 */       objAttr = objBO.getBOAttr(objFKAttr.get(i).toString());
/* 270 */       if (objAttr != null) {
/* 271 */         objMap.put(this.displayAttr.get(i).toString(), objAttr);
/*     */       }
/*     */     }
/* 274 */     return objMap;
/*     */   }
/*     */   public String getDefaultValue() {
/* 277 */     return getAutoValue();
/*     */   }
/*     */ 
/*     */   public boolean isCollection() {
/* 281 */     throw new UnsupportedOperationException("Method isCollection() not yet implemented.");
/*     */   }
/*     */   public String toString() {
/* 284 */     return super.getName();
/*     */   }
/*     */ 
/*     */   public String getRelationObjectTypeOutJoin()
/*     */   {
/* 292 */     return this.m_Attr.getDisplaycol().getOutjoin();
/*     */   }
/*     */   public void setRelationObjectTypeOutJoin(String pValue) {
/* 295 */     this.m_Attr.getDisplaycol().setOutjoin(pValue);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOAttrNode
 * JD-Core Version:    0.5.4
 */