/*    */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class Datafilter extends TextElement
/*    */ {
/* 18 */   public static String _tagName = "datafilter";
/*    */ 
/*    */   public Datafilter()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Datafilter(String text)
/*    */   {
/* 33 */     super(text);
/*    */   }
/*    */ 
/*    */   public static Datafilter unmarshal(Element elem)
/*    */   {
/* 42 */     Datafilter __objDatafilter = (Datafilter)TextElement.unmarshal(elem, new Datafilter());
/* 43 */     return __objDatafilter;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 53 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Datafilter
 * JD-Core Version:    0.5.4
 */