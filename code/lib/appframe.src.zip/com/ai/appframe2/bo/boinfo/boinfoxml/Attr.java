/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Attr extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "attr";
/*     */ 
/*  21 */   public Attribute floatlength = new Attribute("floatlength", "NMTOKEN", "FIXED", "0");
/*     */ 
/*  23 */   public Attribute name = new Attribute("name", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  25 */   public Attribute maxlength = new Attribute("maxlength", "NMTOKEN", "FIXED", "20");
/*     */ 
/*  27 */   public Attribute datatype = new Attribute("datatype", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  29 */   public Attribute type = new Attribute("type", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*  31 */   public Attribute remark = new Attribute("remark", "NMTOKEN", "REQUIRED", "");
/*     */   protected Mapingcol _objMapingcol;
/*     */   protected Displaycol _objDisplaycol;
/*     */   protected Link _objLink;
/*     */   protected Autovalue _objAutovalue;
/*     */ 
/*     */   public String getFloatlength()
/*     */   {
/*  54 */     return this.floatlength.getValue();
/*     */   }
/*     */ 
/*     */   public void setFloatlength(String value_)
/*     */   {
/*  63 */     this.floatlength.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  71 */     return this.name.getValue();
/*     */   }
/*     */ 
/*     */   public void setName(String value_)
/*     */   {
/*  80 */     this.name.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getMaxlength()
/*     */   {
/*  88 */     return this.maxlength.getValue();
/*     */   }
/*     */ 
/*     */   public void setMaxlength(String value_)
/*     */   {
/*  97 */     this.maxlength.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getDatatype()
/*     */   {
/* 105 */     return this.datatype.getValue();
/*     */   }
/*     */ 
/*     */   public void setDatatype(String value_)
/*     */   {
/* 114 */     this.datatype.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 122 */     return this.type.getValue();
/*     */   }
/*     */ 
/*     */   public void setType(String value_)
/*     */   {
/* 131 */     this.type.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getRemark()
/*     */   {
/* 139 */     return this.remark.getValue();
/*     */   }
/*     */ 
/*     */   public void setRemark(String value_)
/*     */   {
/* 148 */     this.remark.setValue(value_);
/*     */   }
/*     */ 
/*     */   public String getMapingcolText()
/*     */   {
/* 156 */     return (this._objMapingcol == null) ? null : this._objMapingcol.getText();
/*     */   }
/*     */ 
/*     */   public void setMapingcolText(String text)
/*     */   {
/* 167 */     if (text == null)
/*     */     {
/* 169 */       this._objMapingcol = null;
/* 170 */       return;
/*     */     }
/*     */ 
/* 173 */     if (this._objMapingcol == null) {
/* 174 */       this._objMapingcol = new Mapingcol();
/*     */     }
/* 176 */     this._objMapingcol.setText(text);
/* 177 */     this._objMapingcol._setParent(this);
/*     */   }
/*     */ 
/*     */   public Mapingcol getMapingcol()
/*     */   {
/* 185 */     return this._objMapingcol;
/*     */   }
/*     */ 
/*     */   public void setMapingcol(Mapingcol obj)
/*     */   {
/* 196 */     this._objMapingcol = obj;
/* 197 */     if (obj == null) {
/* 198 */       return;
/*     */     }
/* 200 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Displaycol getDisplaycol()
/*     */   {
/* 207 */     return this._objDisplaycol;
/*     */   }
/*     */ 
/*     */   public void setDisplaycol(Displaycol obj)
/*     */   {
/* 218 */     this._objDisplaycol = obj;
/* 219 */     if (obj == null) {
/* 220 */       return;
/*     */     }
/* 222 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public String getLinkText()
/*     */   {
/* 229 */     return (this._objLink == null) ? null : this._objLink.getText();
/*     */   }
/*     */ 
/*     */   public void setLinkText(String text)
/*     */   {
/* 240 */     if (text == null)
/*     */     {
/* 242 */       this._objLink = null;
/* 243 */       return;
/*     */     }
/*     */ 
/* 246 */     if (this._objLink == null) {
/* 247 */       this._objLink = new Link();
/*     */     }
/* 249 */     this._objLink.setText(text);
/* 250 */     this._objLink._setParent(this);
/*     */   }
/*     */ 
/*     */   public Link getLink()
/*     */   {
/* 258 */     return this._objLink;
/*     */   }
/*     */ 
/*     */   public void setLink(Link obj)
/*     */   {
/* 269 */     this._objLink = obj;
/* 270 */     if (obj == null) {
/* 271 */       return;
/*     */     }
/* 273 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public String getAutovalueText()
/*     */   {
/* 280 */     return (this._objAutovalue == null) ? null : this._objAutovalue.getText();
/*     */   }
/*     */ 
/*     */   public void setAutovalueText(String text)
/*     */   {
/* 291 */     if (text == null)
/*     */     {
/* 293 */       this._objAutovalue = null;
/* 294 */       return;
/*     */     }
/*     */ 
/* 297 */     if (this._objAutovalue == null) {
/* 298 */       this._objAutovalue = new Autovalue();
/*     */     }
/* 300 */     this._objAutovalue.setText(text);
/* 301 */     this._objAutovalue._setParent(this);
/*     */   }
/*     */ 
/*     */   public Autovalue getAutovalue()
/*     */   {
/* 309 */     return this._objAutovalue;
/*     */   }
/*     */ 
/*     */   public void setAutovalue(Autovalue obj)
/*     */   {
/* 320 */     this._objAutovalue = obj;
/* 321 */     if (obj == null) {
/* 322 */       return;
/*     */     }
/* 324 */     obj._setParent(this);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 332 */     Element elem = new Element(get_TagName());
/*     */ 
/* 334 */     elem.addAttribute(this.floatlength.marshal());
/*     */ 
/* 336 */     elem.addAttribute(this.name.marshal());
/*     */ 
/* 338 */     elem.addAttribute(this.maxlength.marshal());
/*     */ 
/* 340 */     elem.addAttribute(this.datatype.marshal());
/*     */ 
/* 342 */     elem.addAttribute(this.type.marshal());
/*     */ 
/* 344 */     elem.addAttribute(this.remark.marshal());
/*     */ 
/* 346 */     if (this._objMapingcol != null)
/*     */     {
/* 348 */       elem.addComment(this._objMapingcol._marshalCommentList());
/* 349 */       elem.addContent(this._objMapingcol.marshal());
/*     */     }
/*     */ 
/* 352 */     if (this._objDisplaycol != null)
/*     */     {
/* 354 */       elem.addComment(this._objDisplaycol._marshalCommentList());
/* 355 */       elem.addContent(this._objDisplaycol.marshal());
/*     */     }
/*     */ 
/* 358 */     if (this._objLink != null)
/*     */     {
/* 360 */       elem.addComment(this._objLink._marshalCommentList());
/* 361 */       elem.addContent(this._objLink.marshal());
/*     */     }
/*     */ 
/* 364 */     if (this._objAutovalue != null)
/*     */     {
/* 366 */       elem.addComment(this._objAutovalue._marshalCommentList());
/* 367 */       elem.addContent(this._objAutovalue.marshal());
/*     */     }
/*     */ 
/* 370 */     elem.addComment(_marshalBottomCommentList());
/* 371 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Attr unmarshal(Element elem)
/*     */   {
/* 379 */     if (elem == null) {
/* 380 */       return null;
/*     */     }
/* 382 */     Attr __objAttr = new Attr();
/* 383 */     if (__objAttr != null)
/*     */     {
/* 386 */       __objAttr.floatlength.setValue(elem.getAttribute("floatlength"));
/*     */ 
/* 388 */       __objAttr.name.setValue(elem.getAttribute("name"));
/*     */ 
/* 390 */       __objAttr.maxlength.setValue(elem.getAttribute("maxlength"));
/*     */ 
/* 392 */       __objAttr.datatype.setValue(elem.getAttribute("datatype"));
/*     */ 
/* 394 */       __objAttr.type.setValue(elem.getAttribute("type"));
/*     */ 
/* 396 */       __objAttr.remark.setValue(elem.getAttribute("remark"));
/*     */     }
/*     */ 
/* 399 */     ArrayList __comments = null;
/* 400 */     Iterator it = elem.getChildObjects().iterator();
/* 401 */     while (it.hasNext())
/*     */     {
/* 403 */       Object __obj = it.next();
/* 404 */       if (__obj instanceof Comment)
/*     */       {
/* 406 */         if (__comments == null) {
/* 407 */           __comments = new ArrayList(2);
/*     */         }
/* 409 */         __comments.add(__obj);
/*     */       }
/* 411 */       else if (__obj instanceof Element)
/*     */       {
/* 413 */         Element __e = (Element)__obj;
/* 414 */         String __name = __e.getName();
/* 415 */         if (__name.equals(Mapingcol._tagName))
/*     */         {
/* 418 */           Mapingcol __objMapingcol = Mapingcol.unmarshal(__e);
/* 419 */           __objAttr.setMapingcol(__objMapingcol);
/* 420 */           __objMapingcol._unmarshalCommentList(__comments);
/*     */         }
/* 422 */         if (__name.equals(Displaycol._tagName))
/*     */         {
/* 425 */           Displaycol __objDisplaycol = Displaycol.unmarshal(__e);
/* 426 */           __objAttr.setDisplaycol(__objDisplaycol);
/* 427 */           __objDisplaycol._unmarshalCommentList(__comments);
/*     */         }
/* 429 */         if (__name.equals(Link._tagName))
/*     */         {
/* 432 */           Link __objLink = Link.unmarshal(__e);
/* 433 */           __objAttr.setLink(__objLink);
/* 434 */           __objLink._unmarshalCommentList(__comments);
/*     */         }
/* 436 */         if (__name.equals(Autovalue._tagName))
/*     */         {
/* 439 */           Autovalue __objAutovalue = Autovalue.unmarshal(__e);
/* 440 */           __objAttr.setAutovalue(__objAutovalue);
/* 441 */           __objAutovalue._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 444 */         __comments = null;
/*     */       }
/*     */     }
/* 447 */     __objAttr._unmarshalBottomCommentList(__comments);
/* 448 */     return __objAttr;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 465 */     ErrorList errors = new ErrorList();
/*     */ 
/* 468 */     if (this._objMapingcol != null)
/* 469 */       errors.add(this._objMapingcol.validate(firstError));
/*     */     else
/* 471 */       errors.add(new ElementError(this, Mapingcol.class));
/* 472 */     if ((firstError) && (errors.size() > 0)) {
/* 473 */       return errors;
/*     */     }
/* 475 */     if (this._objDisplaycol != null)
/*     */     {
/* 477 */       errors.add(this._objDisplaycol.validate(firstError));
/* 478 */       if ((firstError) && (errors.size() > 0)) {
/* 479 */         return errors;
/*     */       }
/*     */     }
/* 482 */     if (this._objLink != null)
/*     */     {
/* 484 */       errors.add(this._objLink.validate(firstError));
/* 485 */       if ((firstError) && (errors.size() > 0)) {
/* 486 */         return errors;
/*     */       }
/*     */     }
/* 489 */     if (this._objAutovalue != null)
/*     */     {
/* 491 */       errors.add(this._objAutovalue.validate(firstError));
/* 492 */       if ((firstError) && (errors.size() > 0)) {
/* 493 */         return errors;
/*     */       }
/*     */     }
/* 496 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 505 */     List children = new ArrayList();
/*     */ 
/* 507 */     if (this._objMapingcol != null) {
/* 508 */       children.add(this._objMapingcol);
/*     */     }
/* 510 */     if (this._objDisplaycol != null) {
/* 511 */       children.add(this._objDisplaycol);
/*     */     }
/* 513 */     if (this._objLink != null) {
/* 514 */       children.add(this._objLink);
/*     */     }
/* 516 */     if (this._objAutovalue != null)
/* 517 */       children.add(this._objAutovalue);
/* 518 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 527 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Attr
 * JD-Core Version:    0.5.4
 */