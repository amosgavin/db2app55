/*     */ package com.ai.appframe2.bo.boinfo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Arg;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Arglist;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Op;
/*     */ import com.ai.appframe2.bo.boinfo.boinfoxml.Sql;
/*     */ import com.ai.appframe2.common.Operator;
/*     */ import com.ai.appframe2.common.mutablenode.AbstractNode;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.TreeMap;
/*     */ 
/*     */ public class BOOperationNode extends AbstractNode
/*     */   implements BOOperationInterface, Operator
/*     */ {
/*  19 */   private String[] commandArray = null;
/*  20 */   private Op m_OP = null;
/*     */ 
/*  22 */   public BOOperationNode(AbstractNode aSuper, AbstractNode aParent, String aName) { super(aSuper, aParent, aName); }
/*     */ 
/*     */   public void buildTree(XmlObject aNode)
/*     */   {
/*  26 */     if (aNode == null)
/*  27 */       return;
/*  28 */     Op objOp = (Op)aNode;
/*  29 */     this.m_OP = objOp;
/*  30 */     setRemark(objOp.getRemark());
/*  31 */     setNodeObject(objOp);
/*  32 */     String strSQLs = objOp.getSqlText();
/*  33 */     this.commandArray = StringUtils.split(strSQLs, ';');
/*  34 */     if (objOp.getArglist() == null) {
/*  35 */       objOp.setArglist(new Arglist());
/*     */     }
/*  37 */     Arglist objArglist = objOp.getArglist();
/*  38 */     int count = objArglist.getArgCount();
/*  39 */     Arg objArg = null;
/*  40 */     for (int i = 0; i < count; ++i) {
/*  41 */       objArg = objArglist.getArg(i);
/*  42 */       OperationArgNode objArgNode = new OperationArgNode(getRootNode(), this, objArg.getName());
/*  43 */       addChild(objArg.getName(), objArgNode);
/*  44 */       objArgNode.buildTree(objArg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getCommandArray() {
/*  48 */     if (this.m_OP.getSqlText() != null) {
/*  49 */       return StringUtils.split(this.m_OP.getSqlText(), ';');
/*     */     }
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */   public void setExecuteCondiction(String executeCondiction) {
/*  55 */     this.m_OP.setCondictionText(executeCondiction);
/*     */   }
/*     */   public String getExecuteCondiction() {
/*  58 */     return this.m_OP.getCondictionText();
/*     */   }
/*     */   public String getOperationType() {
/*  61 */     return this.m_OP.getType();
/*     */   }
/*     */   public void setOperationType(String operationType) {
/*  64 */     this.m_OP.setType(operationType);
/*     */   }
/*     */   public String getCommands() {
/*  67 */     if (this.m_OP.getSql() == null) {
/*  68 */       return null;
/*     */     }
/*  70 */     return this.m_OP.getSqlText();
/*     */   }
/*     */   public void setCommands(String commands) {
/*  73 */     if (this.m_OP.getSql() == null) {
/*  74 */       this.m_OP.setSql(new Sql());
/*     */     }
/*  76 */     this.m_OP.setSqlText(commands);
/*     */   }
/*     */ 
/*     */   public String getCommandRemark() {
/*  80 */     if (this.m_OP.getSql() != null) {
/*  81 */       return this.m_OP.getSql().getRemark();
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   public void setCommandRemark(String aRemark) {
/*  87 */     if (this.m_OP.getSql() == null) {
/*  88 */       this.m_OP.setSql(new Sql());
/*     */     }
/*  90 */     this.m_OP.getSql().setRemark(aRemark);
/*     */   }
/*     */ 
/*     */   public void addComand(String aSql) {
/*  94 */     if (this.m_OP.getSql() == null) {
/*  95 */       this.m_OP.setSql(new Sql());
/*     */     }
/*  97 */     StringBuilder str = new StringBuilder(this.m_OP.getSqlText());
/*  98 */     str.append(";").append(aSql);
/*  99 */     this.m_OP.setSqlText(str.toString());
/*     */   }
/*     */ 
/*     */   public void setRemark(String remark) {
/* 103 */     super.setRemark(remark);
/* 104 */     this.m_OP.setRemark(remark);
/*     */   }
/*     */   public void setName(String aName) {
/* 107 */     super.setName(aName);
/* 108 */     this.m_OP.setName(aName);
/*     */   }
/*     */ 
/*     */   public List getArgList() {
/* 112 */     if (getChildSet() == null)
/* 113 */       return null;
/* 114 */     ArrayList objList = new ArrayList(getChildSet().values());
/* 115 */     return objList;
/*     */   }
/*     */ 
/*     */   public OperationArgNode[] getArgs() {
/* 119 */     if (getChildSet() == null)
/* 120 */       return new OperationArgNode[0];
/* 121 */     Object[] obj = getChildSet().values().toArray(new Object[0]);
/* 122 */     OperationArgNode[] objArgs = new OperationArgNode[obj.length];
/* 123 */     System.arraycopy(obj, 0, objArgs, 0, objArgs.length);
/* 124 */     return objArgs;
/*     */   }
/*     */ 
/*     */   public OperationArgInterface addArg(String aName) {
/* 128 */     OperationArgNode objArgNode = new OperationArgNode(getRootNode(), this, aName);
/* 129 */     Arg objArg = new Arg();
/* 130 */     objArg.setName(aName);
/* 131 */     if (this.m_OP.getArglist() == null) {
/* 132 */       this.m_OP.setArglist(new Arglist());
/*     */     }
/* 134 */     this.m_OP.getArglist().addArg(objArg);
/* 135 */     objArgNode.setNodeObject(objArg);
/* 136 */     objArgNode.buildTree(objArg);
/* 137 */     addChild(aName, objArgNode);
/* 138 */     return objArgNode;
/*     */   }
/*     */ 
/*     */   public void removeArg(String aName) {
/* 142 */     OperationArgNode objArgNode = (OperationArgNode)getChild(aName);
/* 143 */     if (objArgNode != null) {
/* 144 */       this.m_OP.getArglist().removeArg((Arg)objArgNode.getNodeObject());
/* 145 */       removeChild(aName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAllArg() {
/* 150 */     removeAllChild();
/* 151 */     this.m_OP.setArglist(null);
/*     */   }
/*     */ 
/*     */   public OperationArgInterface getArg(String aName) {
/* 155 */     return (OperationArgNode)getChild(aName);
/*     */   }
/*     */ 
/*     */   public HashMap getParameterTypes() {
/* 159 */     HashMap objMap = new HashMap();
/* 160 */     List objArgList = getArgList();
/* 161 */     OperationArgNode objArg = null;
/* 162 */     for (int i = 0; (objArgList != null) && (i < objArgList.size()); ++i) {
/* 163 */       objArg = (OperationArgNode)objArgList.get(i);
/*     */ 
/* 165 */       objMap.put(objArg.getName(), objArg);
/*     */     }
/*     */ 
/* 168 */     return objMap;
/*     */   }
/*     */   public String getResultDataType() {
/* 171 */     return null;
/*     */   }
/*     */   public boolean isCollectionOfResult() {
/* 174 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOOperationNode
 * JD-Core Version:    0.5.4
 */