package com.ai.appframe2.bo.boinfo;

import com.ai.appframe2.common.ObjectType;
import java.util.List;

public abstract interface BORootInterface
{
  public abstract BOInterface addBO(String paramString);

  public abstract void removeBO(String paramString);

  public abstract List getBOList();

  public abstract String[] getBONames();

  public abstract BOInterface[] getBOInfos();

  public abstract BOInterface getBO(String paramString);

  public abstract ObjectType getObjectType();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BORootInterface
 * JD-Core Version:    0.5.4
 */