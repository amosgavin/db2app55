/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Arglist extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "arglist";
/*     */ 
/*  21 */   protected ArrayList _objArg = new ArrayList();
/*     */ 
/*     */   public Arg[] getArg()
/*     */   {
/*  37 */     return (Arg[])(Arg[])this._objArg.toArray(new Arg[0]);
/*     */   }
/*     */ 
/*     */   public void setArg(Arg[] objArray)
/*     */   {
/*  47 */     if ((objArray == null) || (objArray.length == 0)) {
/*  48 */       this._objArg.clear();
/*     */     }
/*     */     else {
/*  51 */       this._objArg = new ArrayList(Arrays.asList(objArray));
/*  52 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  54 */         if (objArray[i] != null)
/*  55 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Arg getArg(int index)
/*     */   {
/*  67 */     return (Arg)this._objArg.get(index);
/*     */   }
/*     */ 
/*     */   public void setArg(int index, Arg obj)
/*     */   {
/*  78 */     if (obj == null) {
/*  79 */       removeArg(index);
/*     */     }
/*     */     else {
/*  82 */       this._objArg.set(index, obj);
/*  83 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getArgCount()
/*     */   {
/*  92 */     return this._objArg.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoArg()
/*     */   {
/* 101 */     return this._objArg.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getArgList()
/*     */   {
/* 109 */     return Collections.unmodifiableList(this._objArg);
/*     */   }
/*     */ 
/*     */   public boolean addArg(Arg obj)
/*     */   {
/* 119 */     if (obj == null) {
/* 120 */       return false;
/*     */     }
/* 122 */     obj._setParent(this);
/* 123 */     return this._objArg.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addArg(Collection coArg)
/*     */   {
/* 133 */     if (coArg == null) {
/* 134 */       return false;
/*     */     }
/* 136 */     Iterator it = coArg.iterator();
/* 137 */     while (it.hasNext())
/*     */     {
/* 139 */       Object obj = it.next();
/* 140 */       if ((obj != null) && (obj instanceof XmlObject))
/* 141 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 143 */     return this._objArg.addAll(coArg);
/*     */   }
/*     */ 
/*     */   public Arg removeArg(int index)
/*     */   {
/* 152 */     return (Arg)this._objArg.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeArg(Arg obj)
/*     */   {
/* 162 */     return this._objArg.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearArgList()
/*     */   {
/* 170 */     this._objArg.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 178 */     Element elem = new Element(get_TagName());
/*     */ 
/* 180 */     Iterator it1 = this._objArg.iterator();
/* 181 */     while (it1.hasNext())
/*     */     {
/* 183 */       Arg obj = (Arg)it1.next();
/* 184 */       if (obj != null)
/*     */       {
/* 186 */         elem.addComment(obj._marshalCommentList());
/* 187 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 191 */     elem.addComment(_marshalBottomCommentList());
/* 192 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Arglist unmarshal(Element elem)
/*     */   {
/* 200 */     if (elem == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     Arglist __objArglist = new Arglist();
/*     */ 
/* 205 */     ArrayList __comments = null;
/* 206 */     Iterator it = elem.getChildObjects().iterator();
/* 207 */     while (it.hasNext())
/*     */     {
/* 209 */       Object __obj = it.next();
/* 210 */       if (__obj instanceof Comment)
/*     */       {
/* 212 */         if (__comments == null) {
/* 213 */           __comments = new ArrayList(2);
/*     */         }
/* 215 */         __comments.add(__obj);
/*     */       }
/* 217 */       else if (__obj instanceof Element)
/*     */       {
/* 219 */         Element __e = (Element)__obj;
/* 220 */         String __name = __e.getName();
/* 221 */         if (__name.equals(Arg._tagName))
/*     */         {
/* 224 */           Arg __objArg = Arg.unmarshal(__e);
/* 225 */           __objArglist.addArg(__objArg);
/* 226 */           __objArg._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 229 */         __comments = null;
/*     */       }
/*     */     }
/* 232 */     __objArglist._unmarshalBottomCommentList(__comments);
/* 233 */     return __objArglist;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 250 */     ErrorList errors = new ErrorList();
/*     */ 
/* 253 */     if (this._objArg.size() == 0)
/*     */     {
/* 255 */       errors.add(new ElementError(this, Arg.class));
/* 256 */       if (firstError)
/* 257 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 261 */       Iterator it1 = this._objArg.iterator();
/* 262 */       while (it1.hasNext())
/*     */       {
/* 264 */         Arg obj = (Arg)it1.next();
/* 265 */         if (obj != null)
/*     */         {
/* 267 */           errors.add(obj.validate(firstError));
/* 268 */           if ((firstError) && (errors.size() > 0)) {
/* 269 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 274 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 283 */     List children = new ArrayList();
/*     */ 
/* 285 */     if ((this._objArg != null) && (this._objArg.size() > 0))
/* 286 */       children.add(this._objArg);
/* 287 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 296 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Arglist
 * JD-Core Version:    0.5.4
 */