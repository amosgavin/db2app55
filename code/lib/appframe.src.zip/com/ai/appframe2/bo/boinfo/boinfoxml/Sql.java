/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Attribute;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.TextElement;
/*     */ 
/*     */ public class Sql extends TextElement
/*     */ {
/*  18 */   public static String _tagName = "sql";
/*     */ 
/*  20 */   public Attribute remark = new Attribute("remark", "NMTOKEN", "REQUIRED", "");
/*     */ 
/*     */   public Sql()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Sql(String text)
/*     */   {
/*  35 */     super(text);
/*     */   }
/*     */ 
/*     */   public String getRemark()
/*     */   {
/*  43 */     return this.remark.getValue();
/*     */   }
/*     */ 
/*     */   public void setRemark(String value_)
/*     */   {
/*  52 */     this.remark.setValue(value_);
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/*  60 */     Element elem = super.marshal();
/*     */ 
/*  62 */     elem.addAttribute(this.remark.marshal());
/*  63 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Sql unmarshal(Element elem)
/*     */   {
/*  71 */     Sql __objSql = (Sql)TextElement.unmarshal(elem, new Sql());
/*  72 */     if (__objSql != null)
/*     */     {
/*  75 */       __objSql.remark.setValue(elem.getAttribute("remark"));
/*     */     }
/*  77 */     return __objSql;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/*  94 */     ErrorList errors = new ErrorList();
/*     */ 
/*  97 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 106 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Sql
 * JD-Core Version:    0.5.4
 */