package com.ai.appframe2.bo.boinfo;

import com.ai.appframe2.common.mutablenode.AbstractNodeInterface;

public abstract interface BORelationInterface extends AbstractNodeInterface
{
  public abstract String getChildBOName();

  public abstract void setChildBOName(String paramString);

  public abstract void setRelationCondition(String paramString);

  public abstract String getRelationCondition();

  public abstract boolean isCollection();

  public abstract void setCollection(boolean paramBoolean);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BORelationInterface
 * JD-Core Version:    0.5.4
 */