/*    */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*    */ 
/*    */ import com.borland.xml.toolkit.Element;
/*    */ import com.borland.xml.toolkit.TextElement;
/*    */ 
/*    */ public class Condiction extends TextElement
/*    */ {
/* 18 */   public static String _tagName = "condiction";
/*    */ 
/*    */   public Condiction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Condiction(String text)
/*    */   {
/* 33 */     super(text);
/*    */   }
/*    */ 
/*    */   public static Condiction unmarshal(Element elem)
/*    */   {
/* 42 */     Condiction __objCondiction = (Condiction)TextElement.unmarshal(elem, new Condiction());
/* 43 */     return __objCondiction;
/*    */   }
/*    */ 
/*    */   public String get_TagName()
/*    */   {
/* 53 */     return _tagName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Condiction
 * JD-Core Version:    0.5.4
 */