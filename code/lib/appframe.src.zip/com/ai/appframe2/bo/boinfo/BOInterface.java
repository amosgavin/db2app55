package com.ai.appframe2.bo.boinfo;

import com.ai.appframe2.common.mutablenode.AbstractNodeInterface;
import java.util.List;

public abstract interface BOInterface extends AbstractNodeInterface
{
  public abstract void setDataSource(String paramString);

  public abstract String getDataSource();

  public abstract void setMainAttr(String paramString);

  public abstract String getMainAttr();

  public abstract void setMapingEnty(String paramString);

  public abstract String getMapingEnty();

  public abstract void setDataFilter(String paramString);

  public abstract String getDataFilter();

  public abstract void setMapingEntyType(String paramString);

  public abstract String getMapingEntyType();

  public abstract BOAttrInterface[] getBOAttrArray();

  public abstract BOAttrInterface[] getPKAttrAray();

  public abstract String[] getPKAttrNameArray();

  public abstract String[] getAttrNameArray();

  public abstract BOAttrInterface getBOAttr(String paramString);

  public abstract String[] getOpNameArray();

  public abstract BOOperationInterface getBOOPeration(String paramString);

  public abstract BORelationInterface getBORelation(String paramString);

  public abstract BOOperationInterface getBOCreateOperation();

  public abstract BOOperationInterface getBORemoveOperation();

  public abstract BOOperationInterface getBOUpdateOperation();

  public abstract BOAttrInterface addBOAttr(String paramString);

  public abstract void removeBOAttr(String paramString);

  public abstract String getTempTableName();

  public abstract void setTempTableName(String paramString);

  public abstract BORelationInterface addRelation(String paramString);

  public abstract List getRelationList();

  public abstract BORelationInterface[] getRelationArray();

  public abstract void removeRelation(String paramString);

  public abstract BOOperationInterface[] getOperationArray();

  public abstract BOOperationInterface addOperation(String paramString);

  public abstract String getCondictionMapingCol(String paramString);

  public abstract String getPackage();

  public abstract String getBOFullName();
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.BOInterface
 * JD-Core Version:    0.5.4
 */