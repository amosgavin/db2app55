/*     */ package com.ai.appframe2.bo.boinfo.boinfoxml;
/*     */ 
/*     */ import com.borland.xml.toolkit.Comment;
/*     */ import com.borland.xml.toolkit.Element;
/*     */ import com.borland.xml.toolkit.ElementError;
/*     */ import com.borland.xml.toolkit.ErrorList;
/*     */ import com.borland.xml.toolkit.XmlObject;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Attrlist extends XmlObject
/*     */ {
/*  19 */   public static String _tagName = "attrlist";
/*     */ 
/*  21 */   protected ArrayList _objAttr = new ArrayList();
/*     */ 
/*     */   public Attr[] getAttr()
/*     */   {
/*  37 */     return (Attr[])(Attr[])this._objAttr.toArray(new Attr[0]);
/*     */   }
/*     */ 
/*     */   public void setAttr(Attr[] objArray)
/*     */   {
/*  47 */     if ((objArray == null) || (objArray.length == 0)) {
/*  48 */       this._objAttr.clear();
/*     */     }
/*     */     else {
/*  51 */       this._objAttr = new ArrayList(Arrays.asList(objArray));
/*  52 */       for (int i = 0; i < objArray.length; ++i)
/*     */       {
/*  54 */         if (objArray[i] != null)
/*  55 */           objArray[i]._setParent(this);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Attr getAttr(int index)
/*     */   {
/*  67 */     return (Attr)this._objAttr.get(index);
/*     */   }
/*     */ 
/*     */   public void setAttr(int index, Attr obj)
/*     */   {
/*  78 */     if (obj == null) {
/*  79 */       removeAttr(index);
/*     */     }
/*     */     else {
/*  82 */       this._objAttr.set(index, obj);
/*  83 */       obj._setParent(this);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getAttrCount()
/*     */   {
/*  92 */     return this._objAttr.size();
/*     */   }
/*     */ 
/*     */   public boolean isNoAttr()
/*     */   {
/* 101 */     return this._objAttr.size() == 0;
/*     */   }
/*     */ 
/*     */   public List getAttrList()
/*     */   {
/* 109 */     return Collections.unmodifiableList(this._objAttr);
/*     */   }
/*     */ 
/*     */   public boolean addAttr(Attr obj)
/*     */   {
/* 119 */     if (obj == null) {
/* 120 */       return false;
/*     */     }
/* 122 */     obj._setParent(this);
/* 123 */     return this._objAttr.add(obj);
/*     */   }
/*     */ 
/*     */   public boolean addAttr(Collection coAttr)
/*     */   {
/* 133 */     if (coAttr == null) {
/* 134 */       return false;
/*     */     }
/* 136 */     Iterator it = coAttr.iterator();
/* 137 */     while (it.hasNext())
/*     */     {
/* 139 */       Object obj = it.next();
/* 140 */       if ((obj != null) && (obj instanceof XmlObject))
/* 141 */         ((XmlObject)obj)._setParent(this);
/*     */     }
/* 143 */     return this._objAttr.addAll(coAttr);
/*     */   }
/*     */ 
/*     */   public Attr removeAttr(int index)
/*     */   {
/* 152 */     return (Attr)this._objAttr.remove(index);
/*     */   }
/*     */ 
/*     */   public boolean removeAttr(Attr obj)
/*     */   {
/* 162 */     return this._objAttr.remove(obj);
/*     */   }
/*     */ 
/*     */   public void clearAttrList()
/*     */   {
/* 170 */     this._objAttr.clear();
/*     */   }
/*     */ 
/*     */   public Element marshal()
/*     */   {
/* 178 */     Element elem = new Element(get_TagName());
/*     */ 
/* 180 */     Iterator it1 = this._objAttr.iterator();
/* 181 */     while (it1.hasNext())
/*     */     {
/* 183 */       Attr obj = (Attr)it1.next();
/* 184 */       if (obj != null)
/*     */       {
/* 186 */         elem.addComment(obj._marshalCommentList());
/* 187 */         elem.addContent(obj.marshal());
/*     */       }
/*     */     }
/*     */ 
/* 191 */     elem.addComment(_marshalBottomCommentList());
/* 192 */     return elem;
/*     */   }
/*     */ 
/*     */   public static Attrlist unmarshal(Element elem)
/*     */   {
/* 200 */     if (elem == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     Attrlist __objAttrlist = new Attrlist();
/*     */ 
/* 205 */     ArrayList __comments = null;
/* 206 */     Iterator it = elem.getChildObjects().iterator();
/* 207 */     while (it.hasNext())
/*     */     {
/* 209 */       Object __obj = it.next();
/* 210 */       if (__obj instanceof Comment)
/*     */       {
/* 212 */         if (__comments == null) {
/* 213 */           __comments = new ArrayList(2);
/*     */         }
/* 215 */         __comments.add(__obj);
/*     */       }
/* 217 */       else if (__obj instanceof Element)
/*     */       {
/* 219 */         Element __e = (Element)__obj;
/* 220 */         String __name = __e.getName();
/* 221 */         if (__name.equals(Attr._tagName))
/*     */         {
/* 224 */           Attr __objAttr = Attr.unmarshal(__e);
/* 225 */           __objAttrlist.addAttr(__objAttr);
/* 226 */           __objAttr._unmarshalCommentList(__comments);
/*     */         }
/*     */ 
/* 229 */         __comments = null;
/*     */       }
/*     */     }
/* 232 */     __objAttrlist._unmarshalBottomCommentList(__comments);
/* 233 */     return __objAttrlist;
/*     */   }
/*     */ 
/*     */   public ErrorList validate(boolean firstError)
/*     */   {
/* 250 */     ErrorList errors = new ErrorList();
/*     */ 
/* 253 */     if (this._objAttr.size() == 0)
/*     */     {
/* 255 */       errors.add(new ElementError(this, Attr.class));
/* 256 */       if (firstError)
/* 257 */         return errors;
/*     */     }
/*     */     else
/*     */     {
/* 261 */       Iterator it1 = this._objAttr.iterator();
/* 262 */       while (it1.hasNext())
/*     */       {
/* 264 */         Attr obj = (Attr)it1.next();
/* 265 */         if (obj != null)
/*     */         {
/* 267 */           errors.add(obj.validate(firstError));
/* 268 */           if ((firstError) && (errors.size() > 0)) {
/* 269 */             return errors;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 274 */     return (errors.size() == 0) ? null : errors;
/*     */   }
/*     */ 
/*     */   public List _getChildren()
/*     */   {
/* 283 */     List children = new ArrayList();
/*     */ 
/* 285 */     if ((this._objAttr != null) && (this._objAttr.size() > 0))
/* 286 */       children.add(this._objAttr);
/* 287 */     return children;
/*     */   }
/*     */ 
/*     */   public String get_TagName()
/*     */   {
/* 296 */     return _tagName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.boinfo.boinfoxml.Attrlist
 * JD-Core Version:    0.5.4
 */