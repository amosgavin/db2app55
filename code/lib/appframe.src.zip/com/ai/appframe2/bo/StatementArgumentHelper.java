/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class StatementArgumentHelper
/*    */   implements Cloneable
/*    */ {
/*  6 */   private int index = 0;
/*  7 */   private ArrayList attrObject = new ArrayList();
/*  8 */   private ArrayList attrNames = new ArrayList();
/*  9 */   private ArrayList iValueType = new ArrayList();
/* 10 */   private ArrayList objValue = new ArrayList();
/*    */ 
/*    */   public List getAttrObjectList()
/*    */   {
/* 16 */     return this.attrObject;
/*    */   }
/*    */ 
/*    */   public void addValue(int aValueType, Object aValue)
/*    */   {
/* 21 */     this.iValueType.add(this.index, new Integer(aValueType));
/* 22 */     this.objValue.add(this.index, aValue);
/* 23 */     this.index += 1;
/*    */   }
/*    */ 
/*    */   public void addValue(String aValueType, Object aValue) {
/* 27 */     addValue(transSQLTypeToInt(aValueType), aValue);
/*    */   }
/*    */ 
/*    */   public void addValue(String aAttrName, int aValueType, Object aValue) {
/* 31 */     this.iValueType.add(this.index, new Integer(aValueType));
/* 32 */     this.objValue.add(this.index, aValue);
/* 33 */     this.attrNames.add(aAttrName);
/* 34 */     this.index += 1;
/*    */   }
/*    */ 
/*    */   public void addValue(String aAttrName, String aValueType, Object aValue) {
/* 38 */     addValue(aAttrName, transSQLTypeToInt(aValueType), aValue);
/*    */   }
/*    */ 
/*    */   public Object[] getValueTypes() {
/* 42 */     return this.iValueType.toArray();
/*    */   }
/*    */ 
/*    */   public Object[] getValues() {
/* 46 */     return this.objValue.toArray();
/*    */   }
/*    */ 
/*    */   public ArrayList getValueList() {
/* 50 */     return this.objValue;
/*    */   }
/*    */ 
/*    */   public void addAttrName(String aName) {
/* 54 */     this.attrNames.add(aName);
/*    */   }
/*    */ 
/*    */   public ArrayList getAttrNames() {
/* 58 */     return this.attrNames;
/*    */   }
/*    */ 
/*    */   public int length() {
/* 62 */     return this.index;
/*    */   }
/*    */ 
/*    */   public Object clone() throws CloneNotSupportedException {
/* 66 */     StatementArgumentHelper objClone = new StatementArgumentHelper();
/* 67 */     objClone.attrNames = ((ArrayList)this.attrNames.clone());
/* 68 */     objClone.index = this.index;
/* 69 */     objClone.iValueType = ((ArrayList)this.iValueType.clone());
/* 70 */     objClone.objValue = ((ArrayList)this.objValue.clone());
/* 71 */     return objClone;
/*    */   }
/*    */ 
/*    */   private int transSQLTypeToInt(String aStrType) {
/* 75 */     if (aStrType.trim().equalsIgnoreCase("string")) {
/* 76 */       return 0;
/*    */     }
/* 78 */     if (aStrType.trim().equalsIgnoreCase("int")) {
/* 79 */       return 1;
/*    */     }
/* 81 */     if (aStrType.trim().equalsIgnoreCase("float")) {
/* 82 */       return 2;
/*    */     }
/* 84 */     if (aStrType.trim().equalsIgnoreCase("date")) {
/* 85 */       return 3;
/*    */     }
/* 87 */     if (aStrType.trim().equalsIgnoreCase("datetime")) {
/* 88 */       return 4;
/*    */     }
/*    */ 
/* 91 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.StatementArgumentHelper
 * JD-Core Version:    0.5.4
 */