package com.ai.appframe2.bo;

import com.ai.appframe2.common.DataContainerInterface;
import com.ai.appframe2.privilege.UserInfoInterface;

public abstract interface IBOMask
{
  public abstract Object maskBOAttr(UserInfoInterface paramUserInfoInterface, DataContainerInterface paramDataContainerInterface, Object paramObject);
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.IBOMask
 * JD-Core Version:    0.5.4
 */