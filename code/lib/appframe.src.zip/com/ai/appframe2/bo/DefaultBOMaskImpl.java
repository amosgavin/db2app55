/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.privilege.UserInfoInterface;
/*    */ 
/*    */ public class DefaultBOMaskImpl
/*    */   implements IBOMask
/*    */ {
/*    */   public Object maskBOAttr(UserInfoInterface userInfo, DataContainerInterface dc, Object initValue)
/*    */   {
/* 28 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DefaultBOMaskImpl
 * JD-Core Version:    0.5.4
 */