/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.util.resource.ClasspathResourceLoading;
/*    */ import com.ai.appframe2.util.resource.Resource;
/*    */ import java.util.SortedSet;
/*    */ import java.util.TreeSet;
/*    */ 
/*    */ public class ObjectTypeOfBoListLoad
/*    */ {
/*    */   public static String[] getAllFileList()
/*    */   {
/* 19 */     SortedSet set = new TreeSet();
/* 20 */     ClasspathResourceLoading load = new ClasspathResourceLoading();
/* 21 */     Resource[] resources = ClasspathResourceLoading.loadAllClassPathResources(".bo");
/*    */ 
/* 23 */     for (int i = 0; i < resources.length; ++i) {
/* 24 */       set.add(resources[i].getAlias().substring(0, resources[i].getAlias().lastIndexOf(".bo")).replace('/', '.'));
/*    */     }
/*    */ 
/* 29 */     return (String[])(String[])set.toArray(new String[0]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeOfBoListLoad
 * JD-Core Version:    0.5.4
 */