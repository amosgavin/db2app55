/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.util.XmlUtil;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import org.dom4j.Element;
/*     */ 
/*     */ public class MatchItem
/*     */ {
/*     */   String matchName;
/*  16 */   TreeMap matchs = new TreeMap();
/*     */   String sourceBOName;
/*     */ 
/*     */   public MatchItem(String aMatchName)
/*     */     throws Exception
/*     */   {
/*  24 */     this.matchName = aMatchName;
/*     */   }
/*     */ 
/*     */   public MatchItem(String aMatchName, InputStream in, boolean isRuntime)
/*     */     throws Exception
/*     */   {
/*  33 */     this.matchName = aMatchName;
/*  34 */     Element root = XmlUtil.parseXml(in);
/*     */ 
/*  37 */     for (Iterator it = root.elementIterator("match"); it.hasNext(); ) {
/*  38 */       Element tmpNode = (Element)it.next();
/*  39 */       sourceBO = tmpNode.attributeValue("source");
/*  40 */       destBO = tmpNode.attributeValue("dest");
/*  41 */       this.sourceBOName = sourceBO;
/*  42 */       for (itCols = tmpNode.elementIterator("col"); itCols.hasNext(); ) {
/*  43 */         Element tmpCol = (Element)itCols.next();
/*     */ 
/*  45 */         if (isRuntime == true) {
/*  46 */           addMatch(sourceBO, destBO, tmpCol.attributeValue("source").toUpperCase(), tmpCol.attributeValue("dest").toUpperCase());
/*  47 */           addMatch(destBO, sourceBO, tmpCol.attributeValue("dest").toUpperCase(), tmpCol.attributeValue("source").toUpperCase());
/*     */         }
/*  49 */         addMatch(sourceBO, destBO, tmpCol.attributeValue("source"), tmpCol.attributeValue("dest"));
/*     */       }
/*     */     }String sourceBO;
/*     */     String destBO;
/*     */     Iterator itCols;
/*     */   }
/*     */ 
/*     */   public String getSourceBO() {
/*  56 */     return this.sourceBOName;
/*     */   }
/*     */ 
/*     */   public String getMatchField() {
/*  60 */     return "";
/*     */   }
/*     */ 
/*     */   public void toXmlString(Writer writer)
/*     */     throws Exception
/*     */   {
/*  68 */     XmlUtil.writerXml(writer, getRoot());
/*     */   }
/*     */ 
/*     */   public Element getRoot()
/*     */   {
/*  76 */     Element root = XmlUtil.createElement("maps", null);
/*     */ 
/*  80 */     for (Iterator it = this.matchs.entrySet().iterator(); it.hasNext(); ) {
/*  81 */       Element tmpMatch = XmlUtil.createElement("match", null);
/*  82 */       Map.Entry e = (Map.Entry)it.next();
/*  83 */       int index = ((String)e.getKey()).indexOf(":");
/*  84 */       tmpMatch.addAttribute("source", ((String)e.getKey()).substring(0, index));
/*  85 */       tmpMatch.addAttribute("dest", ((String)e.getKey()).substring(index + 1));
/*  86 */       for (Iterator itCols = ((Map)e.getValue()).entrySet().iterator(); itCols.hasNext(); ) {
/*  87 */         Map.Entry eCol = (Map.Entry)itCols.next();
/*  88 */         Element tmpCol = XmlUtil.createElement("col", null);
/*  89 */         tmpCol.addAttribute("source", (String)eCol.getValue());
/*  90 */         tmpCol.addAttribute("dest", (String)eCol.getKey());
/*  91 */         tmpMatch.add(tmpCol);
/*     */       }
/*  93 */       root.add(tmpMatch);
/*     */     }
/*  95 */     return root;
/*     */   }
/*     */ 
/*     */   public void addMatch(String sourceBO, String destBO, String sourceCol, String destCol)
/*     */   {
/* 106 */     Map tmpMap = (Map)this.matchs.get(sourceBO + ":" + destBO);
/* 107 */     if (tmpMap == null) {
/* 108 */       tmpMap = new TreeMap();
/* 109 */       this.matchs.put(sourceBO + ":" + destBO, tmpMap);
/*     */     }
/* 111 */     tmpMap.put(destCol.toUpperCase(), sourceCol.toUpperCase());
/*     */   }
/*     */ 
/*     */   public Map getMatch(String sourceBO, String destBO)
/*     */   {
/* 121 */     return (Map)this.matchs.get(sourceBO + ":" + destBO);
/*     */   }
/*     */ 
/*     */   public void delete(String sourceBO, String destBO)
/*     */   {
/* 130 */     this.matchs.remove(sourceBO + ":" + destBO);
/*     */   }
/*     */ 
/*     */   public void deleteField(String sourceBO, String destBO, String sourceCol, String destField)
/*     */   {
/* 138 */     String[][] result = new String[this.matchs.size()][2];
/* 139 */     int point = 0;
/* 140 */     for (Iterator it = this.matchs.entrySet().iterator(); it.hasNext(); ) {
/* 141 */       Map.Entry e = (Map.Entry)it.next();
/* 142 */       int index = ((String)e.getKey()).indexOf(":");
/* 143 */       result[point][0] = ((String)e.getKey()).substring(0, index);
/* 144 */       result[point][1] = ((String)e.getKey()).substring(index + 1);
/* 145 */       point += 1;
/* 146 */       if ((result[point][0].equalsIgnoreCase(destField)) && (result[point][1].equalsIgnoreCase(sourceCol))) {
/* 147 */         TreeMap treemap = (TreeMap)this.matchs.get(sourceBO + ":" + destBO);
/* 148 */         treemap.remove(result[point][0]);
/* 149 */         return;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 161 */     this.matchs.clear();
/*     */   }
/*     */ 
/*     */   public String getMatchName()
/*     */   {
/* 169 */     return this.matchName;
/*     */   }
/*     */ 
/*     */   public String[][] getMatchBO()
/*     */   {
/* 177 */     String[][] result = new String[this.matchs.size()][2];
/* 178 */     int point = 0;
/* 179 */     for (Iterator it = this.matchs.entrySet().iterator(); it.hasNext(); ) {
/* 180 */       Map.Entry e = (Map.Entry)it.next();
/* 181 */       int index = ((String)e.getKey()).indexOf(":");
/* 182 */       result[point][0] = ((String)e.getKey()).substring(0, index);
/* 183 */       result[point][1] = ((String)e.getKey()).substring(index + 1);
/* 184 */       point += 1;
/*     */     }
/* 186 */     return result;
/*     */   }
/*     */ 
/*     */   public String[][] getMatchCols(String sourceBO, String destBO)
/*     */   {
/* 197 */     Map tmpMap = getMatch(sourceBO, destBO);
/* 198 */     if (tmpMap == null) {
/* 199 */       return new String[0][2];
/*     */     }
/* 201 */     String[][] result = new String[tmpMap.size()][2];
/* 202 */     for (int i = 0; i < tmpMap.size(); ++i) {
/* 203 */       result[i] = new String[2];
/*     */     }
/* 205 */     int point = 0;
/*     */ 
/* 207 */     for (Iterator itCols = tmpMap.entrySet().iterator(); itCols.hasNext(); ) {
/* 208 */       Map.Entry eCol = (Map.Entry)itCols.next();
/* 209 */       result[point][0] = ((String)eCol.getValue());
/* 210 */       result[point][1] = ((String)eCol.getKey());
/* 211 */       point += 1;
/*     */     }
/* 213 */     return result;
/*     */   }
/*     */   public static void main(String[] args) throws Exception {
/* 216 */     String matchName = "demo.OrganizeToStaff";
/* 217 */     String sourceBO = "demo.Organize";
/* 218 */     String destBO = "demo.Staff";
/* 219 */     String testName = "demo.Test";
/* 220 */     String fileName = matchName.replace('.', '/') + ".map";
/* 221 */     InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/*     */ 
/* 225 */     MatchItem item = new MatchItem(matchName, in, false);
/*     */ 
/* 227 */     System.out.println(XmlUtil.formatElement(item.getRoot()));
/*     */ 
/* 229 */     item.addMatch(sourceBO, destBO, "abc", "abc1");
/* 230 */     item.addMatch(sourceBO, destBO, "abc3", "abc4");
/* 231 */     System.out.println(XmlUtil.formatElement(item.getRoot()));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.MatchItem
 * JD-Core Version:    0.5.4
 */