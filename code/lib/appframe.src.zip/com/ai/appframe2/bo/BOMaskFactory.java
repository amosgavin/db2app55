/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.complex.cache.CacheFactory;
/*    */ import com.ai.appframe2.complex.cache.impl.BOMaskCacheImpl;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class BOMaskFactory
/*    */ {
/* 23 */   private static transient Log log = LogFactory.getLog(BOMaskFactory.class);
/*    */ 
/* 26 */   private static boolean IS_BO_MASK = false;
/*    */ 
/*    */   public static boolean isNeedMask(String boName)
/*    */     throws Exception
/*    */   {
/* 64 */     if (!IS_BO_MASK) {
/* 65 */       return false;
/*    */     }
/* 67 */     return CacheFactory.containsKey(BOMaskCacheImpl.class, boName);
/*    */   }
/*    */ 
/*    */   public static IBOMask getBOMask(String boName, String attrName)
/*    */     throws Exception
/*    */   {
/* 78 */     return (IBOMask)CacheFactory.get(BOMaskCacheImpl.class, boName + "^" + attrName);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 30 */       String strBOMask = AIConfigManager.getConfigItem("appframe.bo.mask");
/* 31 */       if (!StringUtils.isBlank(strBOMask)) {
/* 32 */         if ((strBOMask.equalsIgnoreCase("1")) || (strBOMask.equalsIgnoreCase("true"))) {
/* 33 */           IS_BO_MASK = true;
/*    */         }
/*    */       }
/*    */       else
/* 37 */         IS_BO_MASK = false;
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 41 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.BOMaskFactory.config_error"), ex);
/* 42 */       IS_BO_MASK = false;
/*    */     }
/*    */ 
/* 45 */     if (IS_BO_MASK) {
/* 46 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.BOMaskFactory.enable_mask"));
/*    */     }
/*    */     else
/* 49 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.BOMaskFactory.disbale_mask"));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.BOMaskFactory
 * JD-Core Version:    0.5.4
 */