/*    */ package com.ai.appframe2.bo.dialect;
/*    */ 
/*    */ import com.ai.appframe2.common.AIConfigManager;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import org.apache.commons.lang.StringUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public final class DialectFactory
/*    */ {
/* 24 */   private static transient Log log = LogFactory.getLog(DialectFactory.class);
/*    */   public static final String ORACLE = "ORACLE";
/*    */   public static final String DB2 = "DB2";
/*    */   public static final String SYBASE = "SYBASE";
/*    */   public static final String MYSQL = "MYSQL";
/* 31 */   private static IDialect DIALECT = null;
/*    */ 
/*    */   public static IDialect getDialect()
/*    */   {
/* 60 */     return DIALECT;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 35 */       String strDatabaseDialect = AIConfigManager.getConfigItem("DATABASE_DIALECT");
/* 36 */       if (!StringUtils.isBlank(strDatabaseDialect)) {
/* 37 */         DIALECT = (IDialect)Class.forName(strDatabaseDialect.trim()).newInstance();
/*    */       }
/*    */       else
/* 40 */         DIALECT = new OracleDialectImpl();
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 44 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.database_dialect_error"), ex);
/* 45 */       DIALECT = new OracleDialectImpl();
/*    */     }
/*    */     finally {
/* 48 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.database_dialect", new String[] { DIALECT.getClass().getName() }));
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.DialectFactory
 * JD-Core Version:    0.5.4
 */