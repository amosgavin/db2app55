/*     */ package com.ai.appframe2.bo.dialect;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MySQLDialectImpl extends AbstractDialectImpl
/*     */   implements IDialect
/*     */ {
/*  33 */   private static transient Log log = LogFactory.getLog(MySQLDialectImpl.class);
/*     */ 
/*     */   public long getNewId(Connection conn, String sequenceName)
/*     */     throws Exception
/*     */   {
/*  46 */     long start = 0L;
/*  47 */     PreparedStatement ptmt = null;
/*  48 */     ResultSet rs = null;
/*     */     try {
/*  50 */       ptmt = conn.prepareStatement("select seq_nextval('" + sequenceName + "')");
/*  51 */       rs = ptmt.executeQuery();
/*  52 */       if (rs.next()) {
/*  53 */         start = rs.getLong(1);
/*     */       }
/*     */ 
/*  56 */       if (start < 0L) {
/*  57 */         throw new Exception("Failed to get sequence.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  66 */       if (rs != null) {
/*  67 */         rs.close();
/*     */       }
/*  69 */       if (ptmt != null) {
/*  70 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/*  74 */     return start;
/*     */   }
/*     */ 
/*     */   public long getSysDate(Connection conn)
/*     */     throws Exception
/*     */   {
/*  84 */     long rtn = 0L;
/*  85 */     PreparedStatement ptmt = null;
/*  86 */     ResultSet rs = null;
/*     */     try {
/*  88 */       ptmt = conn.prepareStatement("select date_format(now(), '%Y-%m-%d %H:%i:%s') as D");
/*  89 */       rs = ptmt.executeQuery();
/*  90 */       int i = 1;
/*  91 */       if (rs.next())
/*     */       {
/*  94 */         String s = rs.getString("D");
/*  95 */         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  96 */         rtn = format.parse(s).getTime();
/*  97 */         if (i > 1) {
/*  98 */           throw new Exception("Multiple records.");
/*     */         }
/* 100 */         ++i;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 107 */       if (rs != null) {
/* 108 */         rs.close();
/*     */       }
/* 110 */       if (ptmt != null) {
/* 111 */         ptmt.close();
/*     */       }
/* 113 */       if (conn != null) {
/* 114 */         conn.close();
/*     */       }
/*     */     }
/* 117 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean isSupportRowId()
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public String getRowIDString()
/*     */   {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public String rowId2String(Object rowid)
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDatabaseType()
/*     */   {
/* 150 */     return "MYSQL";
/*     */   }
/*     */ 
/*     */   public String getSelectSQL(Connection conn, ObjectType objectType, String[] aCols, String aCond, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 172 */     if (!objectType.getMapingEntyType().equalsIgnoreCase("table")) {
/* 173 */       return getMySQLCustomerQuerySQL(objectType, aCols, aCond, aStartNum, aEndNum);
/*     */     }
/*     */ 
/* 177 */     Property[] properties = null;
/* 178 */     if ((aCols == null) || (aCols.length == 0))
/*     */     {
/* 180 */       properties = (Property[])(Property[])objectType.getProperties().values().toArray(new Property[0]);
/*     */     }
/*     */     else
/*     */     {
/* 184 */       properties = new Property[aCols.length];
/* 185 */       for (int i = 0; i < properties.length; ++i) {
/* 186 */         properties[i] = objectType.getProperty(aCols[i]);
/*     */       }
/*     */     }
/*     */ 
/* 190 */     ArrayList tableList = new ArrayList(1);
/* 191 */     tableList.add(objectType.getMapingEnty() + " M");
/*     */ 
/* 193 */     ArrayList conditionList = new ArrayList();
/*     */ 
/* 196 */     if ((objectType.getDataFilter() != null) && (!objectType.getDataFilter().trim().equals(""))) {
/* 197 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName() }, new String[] { "M" }, objectType.getDataFilter()) + " ) ");
/*     */     }
/*     */ 
/* 200 */     StringBuilder bufferCols = new StringBuilder();
/* 201 */     boolean isFirstCol = true;
/* 202 */     for (int i = 0; i < properties.length; ++i) {
/* 203 */       Property p = properties[i];
/* 204 */       if (p.getType().equalsIgnoreCase("VIRTUAL"))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 209 */       if (!isFirstCol) {
/* 210 */         bufferCols.append(",");
/*     */       }
/*     */       else {
/* 213 */         isFirstCol = false;
/*     */       }
/*     */ 
/* 217 */       if (p.hasAlias() == true) {
/* 218 */         bufferCols.append("M.").append(p.getMapingColName()).append(" as ").append(p.getName());
/*     */       }
/*     */       else {
/* 221 */         bufferCols.append("M.").append(p.getMapingColName());
/*     */       }
/*     */ 
/* 224 */       String fkTypeName = p.getRelationObjectTypeName();
/* 225 */       if ((!aFkFlag) || (fkTypeName == null) || (fkTypeName.trim() == ""))
/*     */         continue;
/* 227 */       fkTypeName = fkTypeName.trim();
/* 228 */       String fkCondition = p.getRelationCondition();
/* 229 */       ObjectType fkType = ServiceManager.getObjectTypeFactory().getInstance(fkTypeName);
/* 230 */       if (fkType == null)
/*     */       {
/* 232 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.impl.SqlBuilder.no_busi_object");
/* 233 */         throw new AIException(msg + ":" + fkTypeName);
/*     */       }
/*     */ 
/* 236 */       if ((fkType.getMapingEntyType() != null) && (!fkType.getMapingEntyType().equalsIgnoreCase("table"))) {
/* 237 */         tableList.add("( " + fkType.getMapingEnty() + ") F" + i);
/*     */       }
/*     */       else {
/* 240 */         tableList.add(fkType.getMapingEnty() + " F" + i);
/*     */       }
/* 242 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName(), fkTypeName }, new String[] { "M", "F" + i }, fkCondition) + " ) ");
/*     */ 
/* 245 */       String[] displayColNames = p.getDisplayColNames();
/* 246 */       for (int j = 0; j < displayColNames.length; ++j) {
/* 247 */         String[] strCols = StringUtils.split(displayColNames[j], ';');
/* 248 */         Property fkP = fkType.getProperty(strCols[0]);
/* 249 */         bufferCols.append(", ").append("F" + i).append(".").append(fkP.getMapingColName()).append(" as ").append(strCols[1]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 254 */     if (isSupportRowId())
/*     */     {
/* 256 */       bufferCols.append(" ,M.ROWID as MROWID___ ");
/*     */     }
/*     */ 
/* 260 */     String outCondition = null;
/* 261 */     if ((aCond != null) && (!aCond.equals("")))
/*     */     {
/*     */       String[] tmpAlias;
/*     */       String[] tmpTypes;
/*     */       String[] tmpAlias;
/* 264 */       if (aExtenBOArray != null) {
/* 265 */         String[] tmpTypes = new String[aExtenBOArray.length + 1];
/* 266 */         tmpAlias = new String[aExtenBOArray.length + 1];
/*     */       }
/*     */       else {
/* 269 */         tmpTypes = new String[1];
/* 270 */         tmpAlias = new String[1];
/*     */       }
/* 272 */       tmpTypes[0] = objectType.getFullName();
/* 273 */       tmpAlias[0] = "M";
/*     */ 
/* 275 */       for (int i = 0; (aExtenBOArray != null) && (i < aExtenBOArray.length); ++i) {
/* 276 */         tmpTypes[(i + 1)] = aExtenBOArray[i];
/* 277 */         tmpAlias[(i + 1)] = ("E" + i);
/* 278 */         ObjectType tmpType = ServiceManager.getObjectTypeFactory().getInstance(aExtenBOArray[i]);
/* 279 */         if (tmpType.getMapingEntyType().equalsIgnoreCase("table") == true) {
/* 280 */           tableList.add(tmpType.getMapingEnty() + " E" + i);
/*     */         }
/*     */         else {
/* 283 */           tableList.add("( " + tmpType.getMapingEnty() + " ) E" + i);
/*     */         }
/*     */       }
/* 286 */       outCondition = getCondition(tmpTypes, tmpAlias, aCond);
/*     */     }
/*     */ 
/* 290 */     String[] ss = splitString(outCondition, "order by");
/* 291 */     String strOrderBy = ss[1];
/* 292 */     if (ss[0] != "") {
/* 293 */       conditionList.add(ss[0]);
/*     */     }
/*     */ 
/* 296 */     StringBuilder strSQL = new StringBuilder();
/* 297 */     if (aDistinctFlag) {
/* 298 */       strSQL.append(" select distinct ").append(bufferCols).append(" from ");
/*     */     }
/*     */     else {
/* 301 */       strSQL.append(" select ").append(bufferCols).append(" from ");
/*     */     }
/*     */ 
/* 304 */     for (int k = 0; k < tableList.size(); ++k) {
/* 305 */       if (k == 0) {
/* 306 */         strSQL.append(tableList.get(k));
/*     */       }
/*     */       else {
/* 309 */         strSQL.append(",").append(tableList.get(k));
/*     */       }
/*     */     }
/*     */ 
/* 313 */     for (int i = 0; i < conditionList.size(); ++i) {
/* 314 */       if (i == 0) {
/* 315 */         strSQL.append(" where ");
/*     */       }
/*     */       else {
/* 318 */         strSQL.append(" and ");
/*     */       }
/* 320 */       strSQL.append(conditionList.get(i));
/*     */     }
/*     */ 
/* 323 */     if (!strOrderBy.equals("")) {
/* 324 */       strSQL.append(" order by ").append(strOrderBy);
/*     */     }
/*     */ 
/* 328 */     if ((aStartNum == -1) && (aEndNum == -1)) {
/* 329 */       if (strSQL.toString().indexOf(" ( )") > -1) {
/* 330 */         String strSQLNew = strSQL.toString().replace(" ( )", "()");
/* 331 */         if (strSQLNew.indexOf(" ( )") > -1) {
/* 332 */           strSQLNew = strSQLNew.replace(" \\( \\)", "()");
/*     */         }
/* 334 */         return strSQLNew;
/*     */       }
/*     */ 
/* 337 */       return strSQL.toString();
/*     */     }
/*     */ 
/* 340 */     StringBuilder str = new StringBuilder(strSQL);
/*     */ 
/* 342 */     if ((aStartNum < 0) && (aEndNum >= 0)) {
/* 343 */       str.append(" limit ").append("0").append(",").append(aEndNum);
/*     */     }
/* 345 */     else if ((aEndNum < 0) && (aStartNum >= 0))
/*     */     {
/* 347 */       if (aStartNum > 0) {
/* 348 */         str.append(" limit ").append(aStartNum - 1).append(",").append("18446744073709551615");
/*     */       }
/*     */       else {
/* 351 */         str.append(" limit ").append(aStartNum).append(",").append("18446744073709551615");
/*     */       }
/*     */ 
/*     */     }
/* 355 */     else if (aEndNum < aStartNum) {
/* 356 */       str.append(" limit ").append("0").append(",").append("0");
/*     */     }
/*     */     else {
/* 359 */       int offset = aEndNum - aStartNum + 1;
/* 360 */       int tmpStart = 0;
/* 361 */       if (aStartNum > 0) {
/* 362 */         tmpStart = aStartNum - 1;
/*     */       }
/*     */       else {
/* 365 */         tmpStart = 0;
/*     */       }
/* 367 */       str.append(" limit ").append(tmpStart).append(",").append(offset);
/*     */     }
/*     */ 
/* 371 */     if (str.toString().indexOf(" ( )") > -1) {
/* 372 */       String strSQLNew = str.toString().replace(" ( )", "()");
/* 373 */       if (strSQLNew.indexOf(" ( )") > -1) {
/* 374 */         strSQLNew = strSQLNew.replace(" \\( \\)", "()");
/*     */       }
/* 376 */       return strSQLNew;
/*     */     }
/*     */ 
/* 379 */     return str.toString();
/*     */   }
/*     */ 
/*     */   private static String getMySQLCustomerQuerySQL(ObjectType aType, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */     throws Exception
/*     */   {
/* 394 */     return getMySQLCustomerQuerySQL(aType.getMapingEnty(), aCols, aCond, aStartNum, aEndNum);
/*     */   }
/*     */ 
/*     */   private static String getMySQLCustomerQuerySQL(String aCustomerSQL, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */   {
/* 407 */     StringBuilder buffer = new StringBuilder();
/*     */ 
/* 409 */     if ((aCond != null) && (!aCond.trim().equalsIgnoreCase("")))
/*     */     {
/* 411 */       buffer.append(" select ");
/*     */ 
/* 414 */       if ((aCols != null) && (aCols.length > 0)) {
/* 415 */         for (int i = 0; i < aCols.length; ++i) {
/* 416 */           if (i > 0) {
/* 417 */             buffer.append(",");
/*     */           }
/* 419 */           buffer.append(aCols[i]);
/*     */         }
/*     */       }
/*     */       else {
/* 423 */         buffer.append(" * ");
/*     */       }
/*     */ 
/* 427 */       buffer.append(" from (");
/* 428 */       buffer.append(aCustomerSQL);
/*     */ 
/* 431 */       buffer.append(" ) __MS");
/*     */ 
/* 434 */       if ((aCond != null) && (!aCond.trim().equalsIgnoreCase(""))) {
/* 435 */         String t = aCond.trim().toLowerCase();
/* 436 */         if ((t.startsWith("order")) || (t.startsWith("group"))) {
/* 437 */           t = t.substring(5).trim();
/* 438 */           if (t.startsWith("by")) {
/* 439 */             buffer.append(aCond);
/*     */           }
/*     */           else
/* 442 */             buffer.append(" where ").append(aCond);
/*     */         }
/*     */         else
/*     */         {
/* 446 */           buffer.append(" where ").append(aCond);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 452 */       buffer.append(aCustomerSQL);
/*     */     }
/*     */ 
/* 456 */     if ((aStartNum >= 0) || (aEndNum >= 0)) {
/* 457 */       if ((aStartNum < 0) && (aEndNum >= 0)) {
/* 458 */         buffer.append(" limit ").append("0").append(",").append(aEndNum);
/*     */       }
/* 460 */       else if ((aEndNum < 0) && (aStartNum >= 0))
/*     */       {
/* 462 */         if (aStartNum > 0) {
/* 463 */           buffer.append(" limit ").append(aStartNum - 1).append(",").append("18446744073709551615");
/*     */         }
/*     */         else {
/* 466 */           buffer.append(" limit ").append(aStartNum).append(",").append("18446744073709551615");
/*     */         }
/*     */ 
/*     */       }
/* 470 */       else if (aEndNum < aStartNum) {
/* 471 */         buffer.append(" limit ").append("0").append(",").append("0");
/*     */       }
/*     */       else {
/* 474 */         int offset = aEndNum - aStartNum + 1;
/* 475 */         int tmpStart = 0;
/* 476 */         if (aStartNum > 0) {
/* 477 */           tmpStart = aStartNum - 1;
/*     */         }
/*     */         else {
/* 480 */           tmpStart = 0;
/*     */         }
/* 482 */         buffer.append(" limit ").append(tmpStart).append(",").append(offset);
/*     */       }
/*     */     }
/*     */ 
/* 486 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 490 */     String aSql = "select staff_id as id,name as n from staff order by name";
/* 491 */     String aCondition = "ORDER By n ";
/* 492 */     String[] aCols = { "n", "id" };
/* 493 */     System.out.println(getMySQLCustomerQuerySQL(aSql, aCols, aCondition, 3, 2));
/*     */ 
/* 495 */     long start = System.currentTimeMillis();
/* 496 */     for (int i = 0; i < 100000; ++i) {
/* 497 */       getMySQLCustomerQuerySQL(aSql, aCols, aCondition, 10, -1);
/*     */     }
/*     */ 
/* 500 */     System.out.println("耗时:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.MySQLDialectImpl
 * JD-Core Version:    0.5.4
 */