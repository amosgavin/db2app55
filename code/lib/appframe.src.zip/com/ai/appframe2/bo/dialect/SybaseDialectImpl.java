/*     */ package com.ai.appframe2.bo.dialect;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SybaseDialectImpl extends AbstractDialectImpl
/*     */   implements IDialect
/*     */ {
/*  33 */   private static transient Log log = LogFactory.getLog(SybaseDialectImpl.class);
/*     */ 
/*     */   public long getNewId(Connection conn, String sequenceName)
/*     */     throws Exception
/*     */   {
/*  48 */     long rtn = -999999L;
/*  49 */     Connection newconn = null;
/*     */     try
/*     */     {
/*  52 */       newconn = ServiceManager.getSession().getNewConnection();
/*  53 */       for (int i = 0; i < 5; ++i)
/*     */       {
/*     */         try {
/*  56 */           rtn = getSybaseNewId(newconn, sequenceName);
/*     */         }
/*     */         finally {
/*  59 */           if (newconn != null) {
/*  60 */             newconn.commit();
/*     */           }
/*     */         }
/*     */ 
/*  64 */         if (rtn > 0L) {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  74 */       if (newconn != null) {
/*  75 */         newconn.close();
/*     */       }
/*     */     }
/*     */ 
/*  79 */     if (rtn < 0L) {
/*  80 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.sybase.fifth_get_error", new String[] { sequenceName }));
/*     */     }
/*     */ 
/*  83 */     return rtn;
/*     */   }
/*     */ 
/*     */   protected long getSybaseNewId(Connection conn, String sequenceName)
/*     */     throws Exception
/*     */   {
/*  94 */     long startBy = 0L;
/*  95 */     long incrementBy = 0L;
/*  96 */     long lastNumber = 0L;
/*  97 */     long nextLastNumber = 0L;
/*  98 */     PreparedStatement ptmt = null;
/*  99 */     ResultSet rs = null;
/*     */     try {
/* 101 */       ptmt = conn.prepareStatement("select start_by,increment_by,last_number from sys_sequences where sequence_name = ? ");
/* 102 */       ptmt.setString(1, sequenceName);
/* 103 */       rs = ptmt.executeQuery();
/* 104 */       while (rs.next()) {
/* 105 */         startBy = rs.getLong(1);
/* 106 */         incrementBy = rs.getLong(2);
/* 107 */         lastNumber = rs.getLong(3);
/*     */       }
/*     */ 
/* 110 */       if (lastNumber == 0L) {
/* 111 */         nextLastNumber = startBy;
/*     */       }
/*     */       else {
/* 114 */         nextLastNumber = lastNumber + incrementBy;
/*     */       }
/*     */ 
/* 117 */       ptmt = conn.prepareStatement("update sys_sequences set last_number = ? where sequence_name = ? and last_number = ? ");
/* 118 */       ptmt.setLong(1, nextLastNumber);
/* 119 */       ptmt.setString(2, sequenceName);
/* 120 */       ptmt.setLong(3, lastNumber);
/*     */ 
/* 122 */       int count = ptmt.executeUpdate();
/*     */ 
/* 124 */       if (count != 1) {
/* 125 */         long l1 = -999999L;
/*     */         return l1;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 132 */       if (rs != null) {
/* 133 */         rs.close();
/*     */       }
/* 135 */       if (ptmt != null) {
/* 136 */         ptmt.close();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 141 */     return nextLastNumber;
/*     */   }
/*     */ 
/*     */   public long getSysDate(Connection conn)
/*     */     throws Exception
/*     */   {
/* 152 */     long rtn = 0L;
/* 153 */     PreparedStatement ptmt = null;
/* 154 */     ResultSet rs = null;
/*     */     try {
/* 156 */       ptmt = conn.prepareStatement("select getdate() as D");
/* 157 */       rs = ptmt.executeQuery();
/* 158 */       int i = 1;
/* 159 */       if (rs.next())
/*     */       {
/* 162 */         String s = rs.getString("D");
/* 163 */         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 164 */         rtn = format.parse(s).getTime();
/* 165 */         if (i > 1) {
/* 166 */           throw new Exception("Multiple records.");
/*     */         }
/* 168 */         ++i;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 175 */       if (rs != null) {
/* 176 */         rs.close();
/*     */       }
/* 178 */       if (ptmt != null) {
/* 179 */         ptmt.close();
/*     */       }
/* 181 */       if (conn != null) {
/* 182 */         conn.close();
/*     */       }
/*     */     }
/* 185 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean isSupportRowId()
/*     */   {
/* 193 */     return false;
/*     */   }
/*     */ 
/*     */   public String getRowIDString()
/*     */   {
/* 201 */     return null;
/*     */   }
/*     */ 
/*     */   public String rowId2String(Object rowid)
/*     */   {
/* 210 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDatabaseType()
/*     */   {
/* 218 */     return "SYBASE";
/*     */   }
/*     */ 
/*     */   public String getSelectSQL(Connection conn, ObjectType objectType, String[] aCols, String aCond, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 240 */     if (!objectType.getMapingEntyType().equalsIgnoreCase("table")) {
/* 241 */       return getSybaseCustomerQuerySQL(objectType, aCols, aCond, aStartNum, aEndNum);
/*     */     }
/*     */ 
/* 245 */     Property[] properties = null;
/* 246 */     if ((aCols == null) || (aCols.length == 0))
/*     */     {
/* 248 */       properties = (Property[])(Property[])objectType.getProperties().values().toArray(new Property[0]);
/*     */     }
/*     */     else
/*     */     {
/* 252 */       properties = new Property[aCols.length];
/* 253 */       for (int i = 0; i < properties.length; ++i) {
/* 254 */         properties[i] = objectType.getProperty(aCols[i]);
/*     */       }
/*     */     }
/*     */ 
/* 258 */     ArrayList tableList = new ArrayList(1);
/* 259 */     tableList.add(objectType.getMapingEnty() + " M");
/*     */ 
/* 261 */     ArrayList conditionList = new ArrayList();
/*     */ 
/* 264 */     if ((objectType.getDataFilter() != null) && (!objectType.getDataFilter().trim().equals(""))) {
/* 265 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName() }, new String[] { "M" }, objectType.getDataFilter()) + " ) ");
/*     */     }
/*     */ 
/* 268 */     StringBuilder bufferCols = new StringBuilder();
/* 269 */     boolean isFirstCol = true;
/* 270 */     for (int i = 0; i < properties.length; ++i) {
/* 271 */       Property p = properties[i];
/* 272 */       if (p.getType().equalsIgnoreCase("VIRTUAL"))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 277 */       if (!isFirstCol) {
/* 278 */         bufferCols.append(",");
/*     */       }
/*     */       else {
/* 281 */         isFirstCol = false;
/*     */       }
/*     */ 
/* 285 */       if (p.hasAlias() == true) {
/* 286 */         bufferCols.append("M.").append(p.getMapingColName()).append(" as ").append(p.getName());
/*     */       }
/*     */       else {
/* 289 */         bufferCols.append("M.").append(p.getMapingColName());
/*     */       }
/*     */ 
/* 292 */       String fkTypeName = p.getRelationObjectTypeName();
/* 293 */       if ((!aFkFlag) || (fkTypeName == null) || (fkTypeName.trim() == ""))
/*     */         continue;
/* 295 */       fkTypeName = fkTypeName.trim();
/* 296 */       String fkCondition = p.getRelationCondition();
/* 297 */       ObjectType fkType = ServiceManager.getObjectTypeFactory().getInstance(fkTypeName);
/* 298 */       if (fkType == null)
/*     */       {
/* 300 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.impl.SqlBuilder.no_busi_object");
/* 301 */         throw new AIException(msg + ":" + fkTypeName);
/*     */       }
/*     */ 
/* 304 */       if ((fkType.getMapingEntyType() != null) && (!fkType.getMapingEntyType().equalsIgnoreCase("table"))) {
/* 305 */         tableList.add("( " + fkType.getMapingEnty() + ") F" + i);
/*     */       }
/*     */       else {
/* 308 */         tableList.add(fkType.getMapingEnty() + " F" + i);
/*     */       }
/* 310 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName(), fkTypeName }, new String[] { "M", "F" + i }, fkCondition) + " ) ");
/*     */ 
/* 313 */       String[] displayColNames = p.getDisplayColNames();
/* 314 */       for (int j = 0; j < displayColNames.length; ++j) {
/* 315 */         String[] strCols = StringUtils.split(displayColNames[j], ';');
/* 316 */         Property fkP = fkType.getProperty(strCols[0]);
/* 317 */         bufferCols.append(", ").append("F" + i).append(".").append(fkP.getMapingColName()).append(" as ").append(strCols[1]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 322 */     if (isSupportRowId())
/*     */     {
/* 324 */       bufferCols.append(" ,M.ROWID as MROWID___ ");
/*     */     }
/*     */ 
/* 328 */     String outCondition = null;
/* 329 */     if ((aCond != null) && (!aCond.equals("")))
/*     */     {
/*     */       String[] tmpAlias;
/*     */       String[] tmpTypes;
/*     */       String[] tmpAlias;
/* 332 */       if (aExtenBOArray != null) {
/* 333 */         String[] tmpTypes = new String[aExtenBOArray.length + 1];
/* 334 */         tmpAlias = new String[aExtenBOArray.length + 1];
/*     */       }
/*     */       else {
/* 337 */         tmpTypes = new String[1];
/* 338 */         tmpAlias = new String[1];
/*     */       }
/* 340 */       tmpTypes[0] = objectType.getFullName();
/* 341 */       tmpAlias[0] = "M";
/*     */ 
/* 343 */       for (int i = 0; (aExtenBOArray != null) && (i < aExtenBOArray.length); ++i) {
/* 344 */         tmpTypes[(i + 1)] = aExtenBOArray[i];
/* 345 */         tmpAlias[(i + 1)] = ("E" + i);
/* 346 */         ObjectType tmpType = ServiceManager.getObjectTypeFactory().getInstance(aExtenBOArray[i]);
/* 347 */         if (tmpType.getMapingEntyType().equalsIgnoreCase("table") == true) {
/* 348 */           tableList.add(tmpType.getMapingEnty() + " E" + i);
/*     */         }
/*     */         else {
/* 351 */           tableList.add("( " + tmpType.getMapingEnty() + " ) E" + i);
/*     */         }
/*     */       }
/* 354 */       outCondition = getCondition(tmpTypes, tmpAlias, aCond);
/*     */     }
/*     */ 
/* 358 */     String[] ss = splitString(outCondition, "order by");
/* 359 */     String strOrderBy = ss[1];
/* 360 */     if (ss[0] != "") {
/* 361 */       conditionList.add(ss[0]);
/*     */     }
/*     */ 
/* 364 */     StringBuilder strSQL = new StringBuilder();
/* 365 */     if (aDistinctFlag) {
/* 366 */       strSQL.append(" select distinct ").append(bufferCols).append(" from ");
/*     */     }
/*     */     else {
/* 369 */       strSQL.append(" select ").append(bufferCols).append(" from ");
/*     */     }
/*     */ 
/* 372 */     for (int k = 0; k < tableList.size(); ++k) {
/* 373 */       if (k == 0) {
/* 374 */         strSQL.append(tableList.get(k));
/*     */       }
/*     */       else {
/* 377 */         strSQL.append(",").append(tableList.get(k));
/*     */       }
/*     */     }
/*     */ 
/* 381 */     for (int i = 0; i < conditionList.size(); ++i) {
/* 382 */       if (i == 0) {
/* 383 */         strSQL.append(" where ");
/*     */       }
/*     */       else {
/* 386 */         strSQL.append(" and ");
/*     */       }
/* 388 */       strSQL.append(conditionList.get(i));
/*     */     }
/*     */ 
/* 391 */     if (!strOrderBy.equals("")) {
/* 392 */       strSQL.append(" order by ").append(strOrderBy);
/*     */     }
/*     */ 
/* 396 */     if ((aStartNum == -1) && (aEndNum == -1)) {
/* 397 */       return strSQL.toString();
/*     */     }
/*     */ 
/* 400 */     throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.sybase.not_support_page"));
/*     */   }
/*     */ 
/*     */   private static String getSybaseCustomerQuerySQL(ObjectType aType, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */     throws Exception
/*     */   {
/* 429 */     return getSybaseCustomerQuerySQL(aType.getMapingEnty(), aCols, aCond, aStartNum, aEndNum);
/*     */   }
/*     */ 
/*     */   private static String getSybaseCustomerQuerySQL(String aCustomerSQL, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */   {
/* 442 */     StringBuilder buffer = new StringBuilder();
/*     */ 
/* 444 */     if ((aCond != null) && (!aCond.trim().equalsIgnoreCase("")))
/*     */     {
/* 446 */       buffer.append(" select ");
/*     */ 
/* 449 */       if ((aCols != null) && (aCols.length > 0)) {
/* 450 */         for (int i = 0; i < aCols.length; ++i) {
/* 451 */           if (i > 0) {
/* 452 */             buffer.append(",");
/*     */           }
/* 454 */           buffer.append(aCols[i]);
/*     */         }
/*     */       }
/*     */       else {
/* 458 */         buffer.append(" * ");
/*     */       }
/*     */ 
/* 462 */       buffer.append(" from (");
/* 463 */       buffer.append(aCustomerSQL);
/* 464 */       buffer.append(" ) ");
/*     */ 
/* 467 */       if ((aCond != null) && (!aCond.trim().equalsIgnoreCase(""))) {
/* 468 */         String t = aCond.trim().toLowerCase();
/* 469 */         if ((t.startsWith("order")) || (t.startsWith("group"))) {
/* 470 */           t = t.substring(5).trim();
/* 471 */           if (t.startsWith("by")) {
/* 472 */             buffer.append(aCond);
/*     */           }
/*     */           else
/* 475 */             buffer.append(" where ").append(aCond);
/*     */         }
/*     */         else
/*     */         {
/* 479 */           buffer.append(" where ").append(aCond);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 485 */       buffer.append(aCustomerSQL);
/*     */     }
/*     */ 
/* 489 */     if ((aStartNum >= 0) || (aEndNum >= 0)) {
/* 490 */       throw new RuntimeException(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.sybase.not_support_page"));
/*     */     }
/*     */ 
/* 504 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 508 */     String aSql = "select EXAMPLE_CHANNEL_ID as id,KEY_NUM as n from EXAMPLE_CHANNEL order by n";
/* 509 */     String aCondition = "ORDER By n ";
/* 510 */     String[] aCols = { "n", "id" };
/* 511 */     System.out.println(getSybaseCustomerQuerySQL(aSql, aCols, aCondition, -5, 11));
/*     */ 
/* 513 */     long start = System.currentTimeMillis();
/* 514 */     for (int i = 0; i < 100000; ++i) {
/* 515 */       getSybaseCustomerQuerySQL(aSql, aCols, aCondition, 10, -1);
/*     */     }
/*     */ 
/* 518 */     System.out.println("耗时:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.SybaseDialectImpl
 * JD-Core Version:    0.5.4
 */