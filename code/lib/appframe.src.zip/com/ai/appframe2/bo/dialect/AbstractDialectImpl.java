/*     */ package com.ai.appframe2.bo.dialect;
/*     */ 
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.express.Operation;
/*     */ import com.ai.appframe2.express.OperatorManager;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractDialectImpl
/*     */   implements IDialect
/*     */ {
/*  23 */   protected static Operation op = new Operation();
/*     */ 
/*     */   protected static String getCondictionMapingCol(ObjectType type, String aAlias, String aExp)
/*     */   {
/*  33 */     if (aExp == null) {
/*  34 */       return null;
/*     */     }
/*     */ 
/*  37 */     String strAttrName = "";
/*  38 */     String strBOName = "";
/*     */ 
/*  40 */     if (aExp.indexOf(".") > 0) {
/*  41 */       String[] str = StringUtils.split(aExp, '.');
/*  42 */       strBOName = str[(str.length - 2)];
/*  43 */       strAttrName = str[(str.length - 1)];
/*     */     }
/*     */     else {
/*  46 */       strBOName = type.getName();
/*  47 */       strAttrName = aExp.trim();
/*     */     }
/*     */ 
/*  50 */     Property p = type.getProperty(strAttrName);
/*  51 */     if ((p != null) && (strBOName.equalsIgnoreCase(type.getName()))) {
/*  52 */       return aAlias + "." + p.getMapingColName();
/*     */     }
/*     */ 
/*  55 */     return null;
/*     */   }
/*     */ 
/*     */   protected static String getCondition(String[] types, String[] aAilas, String aCondition)
/*     */     throws Exception
/*     */   {
/*  70 */     String[] objRs = op.parseForDatabase(aCondition);
/*  71 */     StringBuilder buffer = new StringBuilder(" ");
/*  72 */     for (int i = 0; (objRs != null) && (i < objRs.length); ++i) {
/*  73 */       if ((op.getOperatorManager().isOperator(objRs[i])) || (objRs[i].equals("?"))) {
/*  74 */         buffer.append(objRs[i]).append(" ");
/*     */       }
/*     */       else {
/*  77 */         for (int j = 0; (types != null) && (j < types.length); ++j) {
/*  78 */           String strTrmp = getCondictionMapingCol(ServiceManager.getObjectTypeFactory().getInstance(types[j]), aAilas[j], objRs[i]);
/*  79 */           if ((strTrmp != null) && (strTrmp.trim() != "")) {
/*  80 */             buffer.append(strTrmp).append(" ");
/*  81 */             break;
/*     */           }
/*     */ 
/*  84 */           if (j == types.length - 1) {
/*  85 */             buffer.append(objRs[i]).append(" ");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  90 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   protected static String[] splitString(String s, String tag)
/*     */   {
/* 100 */     String[] result = new String[2];
/* 101 */     result[0] = "";
/* 102 */     result[1] = "";
/* 103 */     if ((s == null) || (tag == null))
/* 104 */       return result;
/* 105 */     s = s.trim();
/* 106 */     tag = tag.trim();
/* 107 */     int index = s.toLowerCase().indexOf(tag.toLowerCase());
/*     */ 
/* 109 */     if (index == -1) {
/* 110 */       result[0] = s;
/* 111 */     } else if (index != 0) {
/* 112 */       result[0] = s.substring(0, index);
/* 113 */       result[1] = s.substring(index + tag.length(), s.length());
/*     */     }
/*     */     else {
/* 116 */       result[1] = s.substring(tag.length(), s.length());
/* 117 */     }return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.AbstractDialectImpl
 * JD-Core Version:    0.5.4
 */