/*     */ package com.ai.appframe2.bo.dialect;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DB2DialectImpl extends AbstractDialectImpl
/*     */   implements IDialect
/*     */ {
/*  33 */   private static transient Log log = LogFactory.getLog(DB2DialectImpl.class);
/*     */ 
/*     */   public long getNewId(Connection conn, String sequenceName)
/*     */     throws Exception
/*     */   {
/*  46 */     long start = 0L;
/*  47 */     PreparedStatement ptmt = null;
/*  48 */     ResultSet rs = null;
/*     */     try {
/*  50 */       ptmt = conn.prepareStatement("SELECT nextval for " + sequenceName + "  as id FROM SYSIBM.SYSDUMMY1");
/*  51 */       rs = ptmt.executeQuery();
/*  52 */       if (rs.next()) {
/*  53 */         start = rs.getLong(1);
/*     */       }
/*     */ 
/*  56 */       if (start < 0L) {
/*  57 */         throw new Exception("Failed to get sequence.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  66 */       if (rs != null) {
/*  67 */         rs.close();
/*     */       }
/*  69 */       if (ptmt != null) {
/*  70 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/*  74 */     return start;
/*     */   }
/*     */ 
/*     */   public long getSysDate(Connection conn)
/*     */     throws Exception
/*     */   {
/*  84 */     long rtn = 0L;
/*  85 */     PreparedStatement ptmt = null;
/*  86 */     ResultSet rs = null;
/*     */     try {
/*  88 */       ptmt = conn.prepareStatement("SELECT  varchar(current date )|| ' ' || replace(varchar(current time) ,'.',':') rq FROM SYSIBM.SYSDUMMY1");
/*  89 */       rs = ptmt.executeQuery();
/*  90 */       int i = 1;
/*  91 */       if (rs.next())
/*     */       {
/*  94 */         String s = rs.getString("rq");
/*  95 */         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/*  96 */         rtn = format.parse(s).getTime();
/*  97 */         if (i > 1) {
/*  98 */           throw new Exception("Multiple records.");
/*     */         }
/* 100 */         ++i;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 107 */       if (rs != null) {
/* 108 */         rs.close();
/*     */       }
/* 110 */       if (ptmt != null) {
/* 111 */         ptmt.close();
/*     */       }
/* 113 */       if (conn != null) {
/* 114 */         conn.close();
/*     */       }
/*     */     }
/* 117 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean isSupportRowId()
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */ 
/*     */   public String getRowIDString()
/*     */   {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public String rowId2String(Object rowid)
/*     */   {
/* 142 */     return null;
/*     */   }
/*     */ 
/*     */   public String getDatabaseType()
/*     */   {
/* 150 */     return "DB2";
/*     */   }
/*     */ 
/*     */   public String getSelectSQL(Connection conn, ObjectType objectType, String[] aCols, String aCond, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 172 */     if (!objectType.getMapingEntyType().equalsIgnoreCase("table"))
/* 173 */       return getDB2CustomerQuerySQL(objectType, aCols, aCond, aStartNum, aEndNum);
/*     */     Property[] properties;
/*     */     Property[] properties;
/* 178 */     if ((aCols == null) || (aCols.length == 0)) {
/* 179 */       properties = (Property[])(Property[])objectType.getProperties().values().toArray(new Property[0]);
/*     */     }
/*     */     else {
/* 182 */       properties = new Property[aCols.length];
/* 183 */       for (int i = 0; i < properties.length; ++i) {
/* 184 */         properties[i] = objectType.getProperty(aCols[i]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 189 */     ArrayList tableList = new ArrayList(1);
/*     */ 
/* 191 */     ArrayList conditionList = new ArrayList();
/*     */ 
/* 194 */     tableList.add(objectType.getMapingEnty() + " M");
/*     */ 
/* 197 */     ArrayList tableList_fk = new ArrayList();
/*     */ 
/* 199 */     ArrayList conditionList_fk = new ArrayList();
/*     */ 
/* 201 */     ArrayList joinType_fk = new ArrayList();
/*     */ 
/* 204 */     if ((objectType.getDataFilter() != null) && (!objectType.getDataFilter().trim().equals(""))) {
/* 205 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName() }, new String[] { "M" }, objectType.getDataFilter()) + " ) ");
/*     */     }
/*     */ 
/* 209 */     StringBuilder bufferCols = new StringBuilder();
/*     */ 
/* 211 */     boolean isFirstCol = true;
/* 212 */     for (int i = 0; i < properties.length; ++i) {
/* 213 */       Property p = properties[i];
/* 214 */       if (p.getType().equalsIgnoreCase("VIRTUAL")) {
/*     */         continue;
/*     */       }
/*     */ 
/* 218 */       if (!isFirstCol) {
/* 219 */         bufferCols.append(",");
/*     */       }
/*     */       else {
/* 222 */         isFirstCol = false;
/*     */       }
/*     */ 
/* 226 */       bufferCols.append("M.").append(p.getMapingColName()).append(" as ").append(p.getName());
/*     */ 
/* 228 */       String fkTypeName = p.getRelationObjectTypeName();
/*     */ 
/* 231 */       if ((aFkFlag) && (fkTypeName != null) && (fkTypeName.trim() != "")) {
/* 232 */         fkTypeName = fkTypeName.trim();
/*     */ 
/* 234 */         String fkCondition = p.getRelationCondition();
/*     */ 
/* 237 */         ObjectType fkType = ServiceManager.getObjectTypeFactory().getInstance(fkTypeName);
/* 238 */         if (fkType == null) {
/* 239 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.impl.SqlBuilder.no_busi_object");
/* 240 */           throw new AIException(msg + ":" + fkTypeName);
/*     */         }
/*     */ 
/* 244 */         String joinType = p.getRelationObjectTypeOutJoin();
/*     */ 
/* 246 */         if ((joinType == null) || (joinType.equals("")))
/*     */         {
/* 248 */           if ((fkType.getMapingEntyType() != null) && (!fkType.getMapingEntyType().equalsIgnoreCase("table"))) {
/* 249 */             tableList.add("( " + fkType.getMapingEnty() + ") F" + i);
/*     */           }
/*     */           else {
/* 252 */             tableList.add(fkType.getMapingEnty() + " F" + i);
/*     */           }
/*     */ 
/* 256 */           conditionList.add("( " + getCondition(new String[] { objectType.getFullName(), fkTypeName }, new String[] { "M", "F" + i }, fkCondition) + " ) ");
/*     */ 
/* 259 */           String[] displayColNames = p.getDisplayColNames();
/* 260 */           for (int j = 0; j < displayColNames.length; ++j) {
/* 261 */             String[] strCols = StringUtils.split(displayColNames[j], ';');
/*     */ 
/* 264 */             Property fkP = fkType.getProperty(strCols[0]);
/* 265 */             bufferCols.append(", ").append("F" + i).append(".").append(fkP.getMapingColName()).append(" as ").append(strCols[1]);
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 274 */           if ((fkType.getMapingEntyType() != null) && (!fkType.getMapingEntyType().equalsIgnoreCase("table"))) {
/* 275 */             tableList_fk.add("( " + fkType.getMapingEnty() + ") as F" + i + "_data ) F" + i);
/*     */           }
/*     */           else {
/* 278 */             tableList_fk.add(fkType.getMapingEnty() + ") F" + i);
/*     */           }
/*     */ 
/* 281 */           conditionList_fk.add("( " + getCondition(new String[] { objectType.getFullName(), fkTypeName }, new String[] { "M", "F" + i }, fkCondition) + " ) ");
/*     */ 
/* 284 */           joinType_fk.add(joinType);
/*     */ 
/* 287 */           String[] displayColNames = p.getDisplayColNames();
/* 288 */           for (int j = 0; j < displayColNames.length; ++j) {
/* 289 */             String[] strCols = StringUtils.split(displayColNames[j], ';');
/*     */ 
/* 292 */             Property fkP = fkType.getProperty(strCols[0]);
/* 293 */             bufferCols.append(", ").append("F" + i).append(".").append(fkP.getMapingColName()).append(" as ").append(strCols[1]);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 301 */     String outCondition = null;
/* 302 */     if ((aCond != null) && (!aCond.equals("")))
/*     */     {
/*     */       String[] tmpAlias;
/*     */       String[] tmpTypes;
/*     */       String[] tmpAlias;
/* 305 */       if (aExtenBOArray != null) {
/* 306 */         String[] tmpTypes = new String[aExtenBOArray.length + 1];
/* 307 */         tmpAlias = new String[aExtenBOArray.length + 1];
/*     */       }
/*     */       else {
/* 310 */         tmpTypes = new String[1];
/* 311 */         tmpAlias = new String[1];
/*     */       }
/* 313 */       tmpTypes[0] = objectType.getFullName();
/* 314 */       tmpAlias[0] = "M";
/*     */ 
/* 316 */       for (int i = 0; (aExtenBOArray != null) && (i < aExtenBOArray.length); ++i) {
/* 317 */         tmpTypes[(i + 1)] = aExtenBOArray[i];
/* 318 */         tmpAlias[(i + 1)] = ("E" + i);
/* 319 */         ObjectType tmpType = ServiceManager.getObjectTypeFactory().getInstance(aExtenBOArray[i]);
/* 320 */         if (tmpType.getMapingEntyType().equalsIgnoreCase("table") == true) {
/* 321 */           tableList.add(tmpType.getMapingEnty() + " E" + i);
/*     */         }
/*     */         else {
/* 324 */           tableList.add("( " + tmpType.getMapingEnty() + " ) E" + i);
/*     */         }
/*     */       }
/* 327 */       outCondition = getCondition(tmpTypes, tmpAlias, aCond);
/*     */     }
/*     */ 
/* 331 */     String[] ss = splitString(outCondition, "order by");
/* 332 */     String strOrderBy = ss[1];
/* 333 */     if (!ss[0].equals("")) {
/* 334 */       conditionList.add(ss[0]);
/*     */     }
/*     */ 
/* 337 */     StringBuilder strSQL = new StringBuilder();
/* 338 */     if (aDistinctFlag) {
/* 339 */       strSQL.append(" select distinct ").append(bufferCols).append(" from ");
/*     */     }
/*     */     else {
/* 342 */       strSQL.append(" select ").append(bufferCols).append(" from ");
/*     */     }
/*     */ 
/* 346 */     strSQL.append(tableList.get(0));
/*     */ 
/* 349 */     for (int i = 0; i < tableList_fk.size(); ++i) {
/* 350 */       String joinType = (String)joinType_fk.get(i);
/* 351 */       if ((joinType == null) || (joinType.equalsIgnoreCase("left"))) {
/* 352 */         strSQL.append(" left outer join (select * from ");
/*     */       }
/*     */       else {
/* 355 */         strSQL.append(" right outer join (select * from ");
/*     */       }
/* 357 */       strSQL.append(tableList_fk.get(i));
/* 358 */       strSQL.append(" on ( ");
/* 359 */       strSQL.append(conditionList_fk.get(i));
/* 360 */       strSQL.append(" ) ");
/*     */     }
/*     */ 
/* 364 */     for (int k = 1; k < tableList.size(); ++k) {
/* 365 */       strSQL.append(",").append(tableList.get(k));
/*     */     }
/*     */ 
/* 369 */     for (int i = 0; i < conditionList.size(); ++i) {
/* 370 */       if (i == 0) {
/* 371 */         strSQL.append(" where ");
/*     */       }
/*     */       else {
/* 374 */         strSQL.append(" and ");
/*     */       }
/* 376 */       strSQL.append(conditionList.get(i));
/*     */     }
/*     */ 
/* 380 */     if (!strOrderBy.equals("")) {
/* 381 */       strSQL.append(" order by ").append(strOrderBy);
/*     */     }
/*     */ 
/* 385 */     if ((aStartNum == -1) && (aEndNum == -1)) {
/* 386 */       return strSQL.toString();
/*     */     }
/*     */ 
/* 389 */     StringBuilder str = new StringBuilder("select * from (select data1.*,rownumber() over() as row_index from ( ");
/* 390 */     str.append(strSQL);
/* 391 */     str.append("  ) as data1 ) as data2 where ");
/* 392 */     if (aStartNum >= 0) {
/* 393 */       str.append(" row_index >=").append(aStartNum);
/* 394 */       if (aEndNum >= 0)
/* 395 */         str.append(" and row_index <= ").append(aEndNum);
/*     */     }
/*     */     else
/*     */     {
/* 399 */       str.append(" row_index <= ").append(aEndNum);
/*     */     }
/*     */ 
/* 402 */     return str.toString();
/*     */   }
/*     */ 
/*     */   protected static String getDB2CustomerQuerySQL(ObjectType aType, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */     throws Exception
/*     */   {
/* 417 */     return getDB2CustomerQuerySQL(aType.getMapingEnty(), aCols, aCond, aStartNum, aEndNum);
/*     */   }
/*     */ 
/*     */   protected static String getDB2CustomerQuerySQL(String aCustomerSQL, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */   {
/* 431 */     StringBuilder buffer = new StringBuilder();
/*     */ 
/* 434 */     if ((aCond != null) && (!aCond.trim().equalsIgnoreCase(""))) {
/* 435 */       buffer.append(" select ");
/* 436 */       if ((aCols != null) && (aCols.length > 0)) {
/* 437 */         for (int i = 0; i < aCols.length; ++i) {
/* 438 */           if (i > 0) {
/* 439 */             buffer.append(",");
/*     */           }
/* 441 */           buffer.append(aCols[i]);
/*     */         }
/*     */       }
/*     */       else {
/* 445 */         buffer.append(" * ");
/*     */       }
/* 447 */       buffer.append(" from (");
/* 448 */       buffer.append(aCustomerSQL);
/*     */ 
/* 450 */       buffer.append(" ) as data");
/*     */ 
/* 453 */       if ((aCond != null) && (!aCond.trim().equalsIgnoreCase(""))) {
/* 454 */         String t = aCond.trim().toLowerCase();
/* 455 */         if ((t.startsWith("order")) || (t.startsWith("group"))) {
/* 456 */           t = t.substring(5).trim();
/* 457 */           if (t.startsWith("by")) {
/* 458 */             buffer.append(" ").append(aCond);
/*     */           }
/*     */           else
/* 461 */             buffer.append(" where ").append(aCond);
/*     */         }
/*     */         else
/*     */         {
/* 465 */           buffer.append(" where ").append(aCond);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 471 */       buffer.append(aCustomerSQL);
/*     */     }
/*     */ 
/* 474 */     if ((aStartNum >= 0) || (aEndNum >= 0)) {
/* 475 */       buffer.insert(0, "select * from (select data1.*,rownumber() over() as row_index from ( ");
/* 476 */       buffer.append(" ) as data1 ) as data2 where ");
/* 477 */       if (aStartNum >= 0) {
/* 478 */         buffer.append(" row_index >=").append(aStartNum);
/* 479 */         if (aEndNum >= 0)
/* 480 */           buffer.append(" and row_index <= ").append(aEndNum);
/*     */       }
/*     */       else
/*     */       {
/* 484 */         buffer.append(" row_index <= ").append(aEndNum);
/*     */       }
/*     */     }
/* 487 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 491 */     String aSql = "select staff_id as id,name as n from staff order by name";
/* 492 */     String aCondition = "ORDER By n ";
/* 493 */     String[] aCols = { "n", "id" };
/*     */ 
/* 495 */     System.out.println(getDB2CustomerQuerySQL(aSql, aCols, aCondition, 10, -1));
/*     */ 
/* 497 */     long start = System.currentTimeMillis();
/* 498 */     for (int i = 0; i < 100000; ++i) {
/* 499 */       getDB2CustomerQuerySQL(aSql, aCols, aCondition, 10, -1);
/*     */     }
/*     */ 
/* 502 */     System.out.println("耗时:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.DB2DialectImpl
 * JD-Core Version:    0.5.4
 */