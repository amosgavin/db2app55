package com.ai.appframe2.bo.dialect;

import com.ai.appframe2.common.ObjectType;
import java.sql.Connection;

public abstract interface IDialect
{
  public abstract long getNewId(Connection paramConnection, String paramString)
    throws Exception;

  public abstract long getSysDate(Connection paramConnection)
    throws Exception;

  public abstract boolean isSupportRowId();

  public abstract String getRowIDString();

  public abstract String rowId2String(Object paramObject);

  public abstract String getDatabaseType();

  public abstract String getSelectSQL(Connection paramConnection, ObjectType paramObjectType, String[] paramArrayOfString1, String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, String[] paramArrayOfString2)
    throws Exception;
}

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.IDialect
 * JD-Core Version:    0.5.4
 */