/*     */ package com.ai.appframe2.bo.dialect;
/*     */ 
/*     */ import com.ai.appframe2.common.AIConfigManager;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import oracle.sql.ROWID;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class OracleDialectImpl extends AbstractDialectImpl
/*     */   implements IDialect
/*     */ {
/*  35 */   private static transient Log log = LogFactory.getLog(OracleDialectImpl.class);
/*     */ 
/*  37 */   private static boolean IS_ROWID = false;
/*     */ 
/*     */   public long getNewId(Connection conn, String sequenceName)
/*     */     throws Exception
/*     */   {
/*  72 */     long start = 0L;
/*  73 */     PreparedStatement ptmt = null;
/*  74 */     ResultSet rs = null;
/*     */     try {
/*  76 */       ptmt = conn.prepareStatement("select " + sequenceName + ".nextval from dual");
/*  77 */       rs = ptmt.executeQuery();
/*  78 */       if (rs.next()) {
/*  79 */         start = rs.getLong(1);
/*     */       }
/*     */ 
/*  82 */       if (start < 0L) {
/*  83 */         throw new Exception("Failed to get sequence.");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  92 */       if (rs != null) {
/*  93 */         rs.close();
/*     */       }
/*  95 */       if (ptmt != null) {
/*  96 */         ptmt.close();
/*     */       }
/*     */     }
/*     */ 
/* 100 */     return start;
/*     */   }
/*     */ 
/*     */   public long getSysDate(Connection conn)
/*     */     throws Exception
/*     */   {
/* 110 */     long rtn = 0L;
/* 111 */     PreparedStatement ptmt = null;
/* 112 */     ResultSet rs = null;
/*     */     try {
/* 114 */       ptmt = conn.prepareStatement("select to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')  as D from dual");
/* 115 */       rs = ptmt.executeQuery();
/* 116 */       int i = 1;
/* 117 */       if (rs.next())
/*     */       {
/* 120 */         String s = rs.getString("D");
/* 121 */         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 122 */         rtn = format.parse(s).getTime();
/* 123 */         if (i > 1) {
/* 124 */           throw new Exception("Multiple records.");
/*     */         }
/* 126 */         ++i;
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally {
/* 133 */       if (rs != null) {
/* 134 */         rs.close();
/*     */       }
/* 136 */       if (ptmt != null) {
/* 137 */         ptmt.close();
/*     */       }
/* 139 */       if (conn != null) {
/* 140 */         conn.close();
/*     */       }
/*     */     }
/* 143 */     return rtn;
/*     */   }
/*     */ 
/*     */   public boolean isSupportRowId()
/*     */   {
/* 151 */     return IS_ROWID;
/*     */   }
/*     */ 
/*     */   public String getRowIDString()
/*     */   {
/* 159 */     return "ROWID";
/*     */   }
/*     */ 
/*     */   public String rowId2String(Object rowid)
/*     */   {
/* 168 */     return ((ROWID)(ROWID)rowid).stringValue();
/*     */   }
/*     */ 
/*     */   public String getDatabaseType()
/*     */   {
/* 176 */     return "ORACLE";
/*     */   }
/*     */ 
/*     */   public String getSelectSQL(Connection conn, ObjectType objectType, String[] aCols, String aCond, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 198 */     if (!objectType.getMapingEntyType().equalsIgnoreCase("table")) {
/* 199 */       return getOracleCustomerQuerySQL(objectType, aCols, aCond, aStartNum, aEndNum);
/*     */     }
/*     */ 
/* 203 */     Property[] properties = null;
/* 204 */     if ((aCols == null) || (aCols.length == 0))
/*     */     {
/* 206 */       properties = (Property[])(Property[])objectType.getProperties().values().toArray(new Property[0]);
/*     */     }
/*     */     else
/*     */     {
/* 210 */       properties = new Property[aCols.length];
/* 211 */       for (int i = 0; i < properties.length; ++i) {
/* 212 */         properties[i] = objectType.getProperty(aCols[i]);
/*     */       }
/*     */     }
/*     */ 
/* 216 */     ArrayList tableList = new ArrayList(1);
/* 217 */     tableList.add(objectType.getMapingEnty() + " M");
/*     */ 
/* 219 */     ArrayList conditionList = new ArrayList();
/*     */ 
/* 222 */     if ((objectType.getDataFilter() != null) && (!objectType.getDataFilter().trim().equals(""))) {
/* 223 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName() }, new String[] { "M" }, objectType.getDataFilter()) + " ) ");
/*     */     }
/*     */ 
/* 226 */     StringBuilder bufferCols = new StringBuilder();
/* 227 */     boolean isFirstCol = true;
/* 228 */     for (int i = 0; i < properties.length; ++i) {
/* 229 */       Property p = properties[i];
/* 230 */       if (p.getType().equalsIgnoreCase("VIRTUAL"))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 235 */       if (!isFirstCol) {
/* 236 */         bufferCols.append(",");
/*     */       }
/*     */       else {
/* 239 */         isFirstCol = false;
/*     */       }
/*     */ 
/* 243 */       if (p.hasAlias() == true) {
/* 244 */         bufferCols.append("M.").append(p.getMapingColName()).append(" as ").append(p.getName());
/*     */       }
/*     */       else {
/* 247 */         bufferCols.append("M.").append(p.getMapingColName());
/*     */       }
/*     */ 
/* 250 */       String fkTypeName = p.getRelationObjectTypeName();
/* 251 */       if ((!aFkFlag) || (fkTypeName == null) || (fkTypeName.trim() == ""))
/*     */         continue;
/* 253 */       fkTypeName = fkTypeName.trim();
/* 254 */       String fkCondition = p.getRelationCondition();
/* 255 */       ObjectType fkType = ServiceManager.getObjectTypeFactory().getInstance(fkTypeName);
/* 256 */       if (fkType == null)
/*     */       {
/* 258 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.impl.SqlBuilder.no_busi_object");
/* 259 */         throw new AIException(msg + ":" + fkTypeName);
/*     */       }
/*     */ 
/* 262 */       if ((fkType.getMapingEntyType() != null) && (!fkType.getMapingEntyType().equalsIgnoreCase("table"))) {
/* 263 */         tableList.add("( " + fkType.getMapingEnty() + ") F" + i);
/*     */       }
/*     */       else {
/* 266 */         tableList.add(fkType.getMapingEnty() + " F" + i);
/*     */       }
/* 268 */       conditionList.add("( " + getCondition(new String[] { objectType.getFullName(), fkTypeName }, new String[] { "M", "F" + i }, fkCondition) + " ) ");
/*     */ 
/* 271 */       String[] displayColNames = p.getDisplayColNames();
/* 272 */       for (int j = 0; j < displayColNames.length; ++j) {
/* 273 */         String[] strCols = com.ai.appframe2.util.StringUtils.split(displayColNames[j], ';');
/* 274 */         Property fkP = fkType.getProperty(strCols[0]);
/* 275 */         bufferCols.append(", ").append("F" + i).append(".").append(fkP.getMapingColName()).append(" as ").append(strCols[1]);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 280 */     if (isSupportRowId())
/*     */     {
/* 282 */       bufferCols.append(" ,M.ROWID as MROWID___ ");
/*     */     }
/*     */ 
/* 286 */     String outCondition = null;
/* 287 */     if ((aCond != null) && (!aCond.equals("")))
/*     */     {
/*     */       String[] tmpAlias;
/*     */       String[] tmpTypes;
/*     */       String[] tmpAlias;
/* 290 */       if (aExtenBOArray != null) {
/* 291 */         String[] tmpTypes = new String[aExtenBOArray.length + 1];
/* 292 */         tmpAlias = new String[aExtenBOArray.length + 1];
/*     */       }
/*     */       else {
/* 295 */         tmpTypes = new String[1];
/* 296 */         tmpAlias = new String[1];
/*     */       }
/* 298 */       tmpTypes[0] = objectType.getFullName();
/* 299 */       tmpAlias[0] = "M";
/*     */ 
/* 301 */       for (int i = 0; (aExtenBOArray != null) && (i < aExtenBOArray.length); ++i) {
/* 302 */         tmpTypes[(i + 1)] = aExtenBOArray[i];
/* 303 */         tmpAlias[(i + 1)] = ("E" + i);
/* 304 */         ObjectType tmpType = ServiceManager.getObjectTypeFactory().getInstance(aExtenBOArray[i]);
/* 305 */         if (tmpType.getMapingEntyType().equalsIgnoreCase("table") == true) {
/* 306 */           tableList.add(tmpType.getMapingEnty() + " E" + i);
/*     */         }
/*     */         else {
/* 309 */           tableList.add("( " + tmpType.getMapingEnty() + " ) E" + i);
/*     */         }
/*     */       }
/* 312 */       outCondition = getCondition(tmpTypes, tmpAlias, aCond);
/*     */     }
/*     */ 
/* 316 */     String[] ss = splitString(outCondition, "order by");
/* 317 */     String strOrderBy = ss[1];
/* 318 */     if (ss[0] != "") {
/* 319 */       conditionList.add(ss[0]);
/*     */     }
/*     */ 
/* 322 */     StringBuilder strSQL = new StringBuilder();
/* 323 */     if (aDistinctFlag) {
/* 324 */       strSQL.append(" select distinct ").append(bufferCols).append(" from ");
/*     */     }
/*     */     else {
/* 327 */       strSQL.append(" select ").append(bufferCols).append(" from ");
/*     */     }
/*     */ 
/* 330 */     for (int k = 0; k < tableList.size(); ++k) {
/* 331 */       if (k == 0) {
/* 332 */         strSQL.append(tableList.get(k));
/*     */       }
/*     */       else {
/* 335 */         strSQL.append(",").append(tableList.get(k));
/*     */       }
/*     */     }
/*     */ 
/* 339 */     for (int i = 0; i < conditionList.size(); ++i) {
/* 340 */       if (i == 0) {
/* 341 */         strSQL.append(" where ");
/*     */       }
/*     */       else {
/* 344 */         strSQL.append(" and ");
/*     */       }
/* 346 */       strSQL.append(conditionList.get(i));
/*     */     }
/*     */ 
/* 349 */     if (!strOrderBy.equals("")) {
/* 350 */       strSQL.append(" order by ").append(strOrderBy);
/*     */     }
/*     */ 
/* 354 */     if ((aStartNum == -1) && (aEndNum == -1)) {
/* 355 */       return strSQL.toString();
/*     */     }
/*     */ 
/* 358 */     StringBuilder str = new StringBuilder("select * from (select B.*,rownum as row_index from ( ");
/* 359 */     str.append(strSQL);
/* 360 */     str.append(" ) B) where ");
/* 361 */     if (aStartNum >= 0) {
/* 362 */       str.append(" row_index >=").append(aStartNum);
/* 363 */       if (aEndNum >= 0)
/* 364 */         str.append(" and row_index <= ").append(aEndNum);
/*     */     }
/*     */     else
/*     */     {
/* 368 */       str.append(" row_index <= ").append(aEndNum);
/*     */     }
/* 370 */     return str.toString();
/*     */   }
/*     */ 
/*     */   private static String getOracleCustomerQuerySQL(ObjectType aType, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */     throws Exception
/*     */   {
/* 385 */     return getOracleCustomerQuerySQL(aType.getMapingEnty(), aCols, aCond, aStartNum, aEndNum);
/*     */   }
/*     */ 
/*     */   private static String getOracleCustomerQuerySQL(String aCustomerSQL, String[] aCols, String aCond, int aStartNum, int aEndNum)
/*     */   {
/* 398 */     StringBuilder buffer = new StringBuilder();
/*     */ 
/* 400 */     if ((aCond != null) && (!aCond.trim().equalsIgnoreCase("")))
/*     */     {
/* 402 */       buffer.append(" select ");
/*     */ 
/* 405 */       if ((aCols != null) && (aCols.length > 0)) {
/* 406 */         for (int i = 0; i < aCols.length; ++i) {
/* 407 */           if (i > 0) {
/* 408 */             buffer.append(",");
/*     */           }
/* 410 */           buffer.append(aCols[i]);
/*     */         }
/*     */       }
/*     */       else {
/* 414 */         buffer.append(" * ");
/*     */       }
/*     */ 
/* 418 */       buffer.append(" from (");
/* 419 */       buffer.append(aCustomerSQL);
/* 420 */       buffer.append(" ) ");
/*     */ 
/* 423 */       if ((aCond != null) && (!aCond.trim().equalsIgnoreCase(""))) {
/* 424 */         String t = aCond.trim().toLowerCase();
/* 425 */         if ((t.startsWith("order")) || (t.startsWith("group"))) {
/* 426 */           t = t.substring(5).trim();
/* 427 */           if (t.startsWith("by")) {
/* 428 */             buffer.append(aCond);
/*     */           }
/*     */           else
/* 431 */             buffer.append(" where ").append(aCond);
/*     */         }
/*     */         else
/*     */         {
/* 435 */           buffer.append(" where ").append(aCond);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 441 */       buffer.append(aCustomerSQL);
/*     */     }
/*     */ 
/* 445 */     if ((aStartNum >= 0) || (aEndNum >= 0)) {
/* 446 */       buffer.insert(0, "select * from (select B.*,rownum as row_index from ( ");
/* 447 */       buffer.append(" ) B) where ");
/* 448 */       if (aStartNum >= 0) {
/* 449 */         buffer.append(" row_index >=").append(aStartNum);
/* 450 */         if (aEndNum >= 0)
/* 451 */           buffer.append(" and row_index <= ").append(aEndNum);
/*     */       }
/*     */       else
/*     */       {
/* 455 */         buffer.append(" row_index <= ").append(aEndNum);
/*     */       }
/*     */     }
/* 458 */     return buffer.toString();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 462 */     String aSql = "select staff_id as id,name as n from staff order by name";
/* 463 */     String aCondition = "ORDER By n ";
/* 464 */     String[] aCols = { "n", "id" };
/* 465 */     System.out.println(getOracleCustomerQuerySQL(aSql, aCols, aCondition, -10, 21));
/*     */ 
/* 467 */     long start = System.currentTimeMillis();
/* 468 */     for (int i = 0; i < 100000; ++i) {
/* 469 */       getOracleCustomerQuerySQL(aSql, aCols, aCondition, 10, -1);
/*     */     }
/*     */ 
/* 472 */     System.out.println("耗时:" + (System.currentTimeMillis() - start) + ":ms");
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  42 */       HashMap map = AIConfigManager.getConfigItemsByKind("AppFrameJdbc");
/*  43 */       if ((map != null) && (map.containsKey("appframe.jdbc.use.rowid"))) {
/*  44 */         String rowid = (String)map.get("appframe.jdbc.use.rowid");
/*  45 */         if (!org.apache.commons.lang.StringUtils.isBlank(rowid)) {
/*  46 */           if (rowid.trim().equalsIgnoreCase("1")) {
/*  47 */             IS_ROWID = true;
/*     */           }
/*     */           else
/*  50 */             IS_ROWID = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/*  56 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.dialect.appframe_jdbc_use_rowid_error"), ex);
/*  57 */       IS_ROWID = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.dialect.OracleDialectImpl
 * JD-Core Version:    0.5.4
 */