/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStructInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ManagerObject;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.Reuse;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DataContainer
/*     */   implements DataContainerInterface, Reuse, ManagerObject, Serializable
/*     */ {
/*     */   public static final String MROWID___ = "MROWID___";
/*  30 */   private boolean rowIdFlag = false;
/*  31 */   private String mrowid___ = null;
/*     */   protected transient ObjectType m_type;
/*  38 */   protected String dc_boName = null;
/*  39 */   protected boolean m_isDeleted = false;
/*  40 */   private HashMap m_back = null;
/*  41 */   private HashMap m_front = null;
/*     */ 
/*  45 */   private HashMap m_AttrSet = null;
/*  46 */   private HashMap m_AttrSet_old = null;
/*  47 */   private HashMap m_relation = null;
/*     */ 
/*  50 */   private HashMap m_extAttr = null;
/*     */ 
/*  53 */   private HashMap mask = null;
/*     */   protected String m_setName;
/*  58 */   private String replaceTableName = null;
/*     */ 
/*     */   public DataContainer() {
/*     */     try {
/*  62 */       this.m_type = ServiceManager.getObjectTypeFactory().getInstance();
/*  63 */       this.dc_boName = this.m_type.getFullName();
/*     */     }
/*     */     catch (Throwable e) {
/*  66 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSetName() {
/*  71 */     return this.m_setName;
/*     */   }
/*     */   public void setSetName(String m_setName) {
/*  74 */     this.m_setName = m_setName;
/*     */   }
/*     */ 
/*     */   public DataContainer(ObjectType type) {
/*  78 */     this.m_type = type;
/*  79 */     this.dc_boName = this.m_type.getFullName();
/*     */   }
/*     */ 
/*     */   public String getTypeName() {
/*  83 */     return getType().getFullName();
/*     */   }
/*     */ 
/*     */   public ObjectType getType() {
/*  87 */     if (this.m_type == null) {
/*  88 */       if (this.dc_boName != null)
/*     */         try {
/*  90 */           this.m_type = ServiceManager.getObjectTypeFactory().getInstance(this.dc_boName);
/*     */         }
/*     */         catch (Exception e) {
/*  93 */           throw new RuntimeException(e);
/*     */         }
/*     */       else {
/*     */         try
/*     */         {
/*  98 */           this.m_type = ServiceManager.getObjectTypeFactory().getInstance();
/*     */         }
/*     */         catch (Exception e) {
/* 101 */           throw new RuntimeException(e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 106 */     return this.m_type;
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType type) throws AIException {
/* 110 */     this.m_type = type;
/*     */ 
/* 113 */     this.dc_boName = this.m_type.getFullName();
/*     */   }
/*     */ 
/*     */   public ObjectType getObjectType() {
/* 117 */     return getType();
/*     */   }
/*     */ 
/*     */   public void clear() {
/* 121 */     this.m_isDeleted = false;
/* 122 */     if (this.m_back != null) this.m_back.clear();
/* 123 */     if (this.m_front != null) this.m_front.clear();
/* 124 */     if (this.m_AttrSet != null) this.m_AttrSet.clear();
/* 125 */     if (this.m_AttrSet_old != null) this.m_AttrSet_old.clear();
/* 126 */     if (this.m_relation == null) return; this.m_relation.clear();
/*     */   }
/*     */   public void free() {
/* 129 */     clear();
/*     */     try {
/* 131 */       this.m_type = ServiceManager.getObjectTypeFactory().getInstance();
/*     */     }
/*     */     catch (Exception e) {
/* 134 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkKey(String name, Object value) {
/* 138 */     if (getObjectType() instanceof ObjectTypeNull)
/* 139 */       return;
/* 140 */     if (!getObjectType().hasProperty(name))
/*     */     {
/* 142 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.no_attr", new String[] { this.m_type.getFullName(), name });
/* 143 */       throw new RuntimeException(msg);
/*     */     }
/* 145 */     if ((!getObjectType().isKeyProperty(name)) || (value != null))
/*     */       return;
/* 147 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.pk_null", new String[] { name });
/* 148 */     throw new RuntimeException(msg);
/*     */   }
/*     */ 
/*     */   public void initPropertyOld(String name, Object value) throws AIException
/*     */   {
/* 153 */     name = name.toUpperCase();
/* 154 */     checkKey(name, value);
/* 155 */     if (!getObjectType() instanceof ObjectTypeNull)
/* 156 */       value = DataType.transfer(value, getObjectType().getProperty(name).getJavaDataType());
/* 157 */     if (this.m_back == null)
/* 158 */       this.m_back = new HashMap();
/* 159 */     this.m_back.put(name, value);
/*     */   }
/*     */ 
/*     */   public void initProperty(String name, Object value)
/*     */   {
/* 164 */     if (value == null)
/* 165 */       return;
/* 166 */     name = name.toUpperCase();
/* 167 */     if (this.m_back == null)
/* 168 */       this.m_back = new HashMap();
/* 169 */     this.m_back.put(name, value);
/*     */   }
/*     */ 
/*     */   public void initPropertyNoUpperCase(String name, Object value) {
/* 173 */     initPropertyNoUpperCase(name, value, null);
/*     */   }
/*     */ 
/*     */   public void initPropertyNoUpperCase(String name, Object value, Object maskValue) {
/* 177 */     if (value == null)
/* 178 */       return;
/* 179 */     if (this.m_back == null)
/* 180 */       this.m_back = new HashMap();
/* 181 */     this.m_back.put(name, value);
/*     */ 
/* 184 */     if (maskValue != null) {
/* 185 */       if (this.mask == null) {
/* 186 */         this.mask = new HashMap();
/*     */       }
/* 188 */       this.mask.put(name, maskValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clearProperty(String name)
/*     */   {
/* 194 */     name = name.toUpperCase();
/* 195 */     if (this.m_back != null) this.m_back.remove(name);
/* 196 */     if (this.m_front != null) this.m_front.remove(name);
/* 197 */     if (this.m_AttrSet != null) this.m_AttrSet.remove(name);
/* 198 */     if (this.m_AttrSet_old == null) return; this.m_AttrSet_old.remove(name);
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value) {
/* 202 */     name = name.toUpperCase();
/* 203 */     checkKey(name, value);
/* 204 */     if (this.m_front == null) {
/* 205 */       this.m_front = new HashMap();
/*     */     }
/* 207 */     if (!getObjectType() instanceof ObjectTypeNull) {
/* 208 */       value = DataType.transfer(value, getObjectType().getProperty(name).getJavaDataType());
/*     */     }
/*     */ 
/* 219 */     this.m_front.put(name, value);
/*     */   }
/*     */ 
/*     */   public boolean isNull(String name) throws AIException {
/* 223 */     name = name.toUpperCase();
/* 224 */     if ((!getObjectType() instanceof ObjectTypeNull) && (getObjectType().hasProperty(name)))
/*     */     {
/* 227 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.no_attr", new String[] { this.m_type.getFullName(), name });
/* 228 */       throw new AIException(msg);
/*     */     }
/* 230 */     return get(name) == null;
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 235 */     name = name.toUpperCase();
/* 236 */     if ((this.m_front != null) && (this.m_front.containsKey(name))) {
/* 237 */       return this.m_front.get(name);
/*     */     }
/* 239 */     if ((this.mask != null) && (this.mask.containsKey(name))) {
/* 240 */       return this.mask.get(name);
/*     */     }
/* 242 */     if ((this.m_back != null) && (this.m_back.containsKey(name))) {
/* 243 */       return this.m_back.get(name);
/*     */     }
/*     */ 
/* 246 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getOldObj(String name)
/*     */   {
/* 251 */     name = name.toUpperCase();
/* 252 */     if ((this.m_back != null) && (this.m_back.containsKey(name)))
/* 253 */       return this.m_back.get(name);
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   public String getAsString(String name) {
/* 258 */     return DataType.getAsString(get(name));
/*     */   }
/*     */   public short getAsShort(String name) {
/* 261 */     return DataType.getAsShort(get(name));
/*     */   }
/*     */ 
/*     */   public int getAsInt(String name) {
/* 265 */     return DataType.getAsInt(get(name));
/*     */   }
/*     */ 
/*     */   public long getAsLong(String name) {
/* 269 */     return DataType.getAsLong(get(name));
/*     */   }
/*     */ 
/*     */   public double getAsDouble(String name) {
/* 273 */     return DataType.getAsDouble(get(name));
/*     */   }
/*     */ 
/*     */   public float getAsFloat(String name) {
/* 277 */     return DataType.getAsFloat(get(name));
/*     */   }
/*     */ 
/*     */   public byte getAsByte(String name) {
/* 281 */     return DataType.getAsByte(get(name));
/*     */   }
/*     */ 
/*     */   public boolean getAsBoolean(String name) {
/* 285 */     return DataType.getAsBoolean(get(name));
/*     */   }
/*     */ 
/*     */   public char getAsChar(String name) {
/* 289 */     return DataType.getAsChar(get(name));
/*     */   }
/*     */ 
/*     */   public Date getAsDate(String name) {
/* 293 */     return DataType.getAsDate(get(name));
/*     */   }
/*     */   public Time getAsTime(String name) {
/* 296 */     return DataType.getAsTime(get(name));
/*     */   }
/*     */ 
/*     */   public Timestamp getAsDateTime(String name) {
/* 300 */     return DataType.getAsDateTime(get(name));
/*     */   }
/*     */ 
/*     */   public Object getRelation(String name) {
/* 304 */     return null;
/*     */   }
/*     */ 
/*     */   public void setRelation(String name, Object value)
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean hasProperty(String name)
/*     */   {
/* 326 */     name = name.toUpperCase();
/* 327 */     return ((this.m_back != null) && (this.m_back.containsKey(name))) || ((this.m_front != null) && (this.m_front.containsKey(name)));
/*     */   }
/*     */ 
/*     */   public boolean hasPropertyName(String name)
/*     */   {
/* 333 */     if (getObjectType() instanceof ObjectTypeNull) {
/* 334 */       return true;
/*     */     }
/* 336 */     return getObjectType().hasProperty(name);
/*     */   }
/*     */ 
/*     */   public boolean hasRelation(String name)
/*     */   {
/* 342 */     name = name.toUpperCase();
/* 343 */     return (this.m_relation != null) && (this.m_relation.containsKey(name));
/*     */   }
/*     */ 
/*     */   public void setDiaplayAttr(String propertyName, String displayName, Object value)
/*     */   {
/* 348 */     propertyName = propertyName.toUpperCase();
/* 349 */     displayName = displayName.toUpperCase();
/* 350 */     if (this.m_AttrSet == null) {
/* 351 */       this.m_AttrSet = new HashMap();
/*     */     }
/* 353 */     Map map = (Map)this.m_AttrSet.get(propertyName);
/* 354 */     if (map == null) {
/* 355 */       map = new HashMap();
/* 356 */       this.m_AttrSet.put(propertyName, map);
/*     */     }
/* 358 */     map.put(displayName, value);
/*     */   }
/*     */ 
/*     */   public void setOldDiaplayAttr(String propertyName, String displayName, Object value) {
/* 362 */     propertyName = propertyName.toUpperCase();
/* 363 */     displayName = displayName.toUpperCase();
/* 364 */     if (this.m_AttrSet_old == null) {
/* 365 */       this.m_AttrSet_old = new HashMap();
/*     */     }
/* 367 */     Map map = (Map)this.m_AttrSet_old.get(propertyName);
/* 368 */     if (map == null) {
/* 369 */       map = new HashMap();
/* 370 */       this.m_AttrSet_old.put(propertyName, map);
/*     */     }
/* 372 */     map.put(displayName, value);
/*     */   }
/*     */ 
/*     */   public Object getDispalyAttr(String attrName, String displayAttrName)
/*     */   {
/* 377 */     attrName = attrName.toUpperCase();
/* 378 */     displayAttrName = displayAttrName.toUpperCase();
/* 379 */     if ((this.m_AttrSet != null) && (this.m_AttrSet.containsKey(attrName))) {
/* 380 */       return ((Map)this.m_AttrSet.get(attrName)).get(displayAttrName);
/*     */     }
/* 382 */     return null;
/*     */   }
/*     */   public Map getDisplayAttrHashMap(String attrName) {
/* 385 */     Map result = null;
/* 386 */     if ((this.m_AttrSet_old != null) && (this.m_AttrSet_old.containsKey(attrName))) {
/* 387 */       if (result == null)
/* 388 */         result = new HashMap();
/* 389 */       result.putAll((Map)this.m_AttrSet_old.get(attrName));
/*     */     }
/* 391 */     if ((this.m_AttrSet != null) && (this.m_AttrSet.containsKey(attrName))) {
/* 392 */       if (result == null)
/* 393 */         result = new HashMap();
/* 394 */       result.putAll((Map)this.m_AttrSet.get(attrName));
/*     */     }
/* 396 */     return result;
/*     */   }
/*     */ 
/*     */   public Object getOldDispalyAttr(String attrName, String displayAttrName) {
/* 400 */     attrName = attrName.toUpperCase();
/* 401 */     displayAttrName = displayAttrName.toUpperCase();
/* 402 */     if ((this.m_AttrSet_old != null) && (this.m_AttrSet_old.containsKey(attrName))) {
/* 403 */       return ((Map)this.m_AttrSet_old.get(attrName)).get(displayAttrName);
/*     */     }
/* 405 */     return null;
/*     */   }
/*     */ 
/*     */   public HashMap getDisplayAttrHashMap() {
/* 409 */     if (this.m_AttrSet == null)
/* 410 */       this.m_AttrSet = new HashMap();
/* 411 */     return this.m_AttrSet;
/*     */   }
/*     */   public HashMap getOldDisplayAttrHashMap() {
/* 414 */     if (this.m_AttrSet_old == null)
/* 415 */       this.m_AttrSet_old = new HashMap();
/* 416 */     return this.m_AttrSet_old;
/*     */   }
/*     */ 
/*     */   public HashMap getKeyProperties() {
/* 420 */     HashMap result = new HashMap();
/* 421 */     Iterator it = getObjectType().getKeyProperties().values().iterator();
/* 422 */     while (it.hasNext()) {
/* 423 */       Property p = (Property)it.next();
/* 424 */       result.put(p.getName(), get(p.getName()));
/*     */     }
/* 426 */     return result;
/*     */   }
/*     */ 
/*     */   public String[] getKeyPropertyNames() {
/* 430 */     return (String[])(String[])getObjectType().getKeyProperties().keySet().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public String[] getPropertyNames() {
/* 434 */     if (getObjectType() instanceof ObjectTypeNull) {
/* 435 */       ArrayList list = new ArrayList();
/* 436 */       if (this.m_front != null) {
/* 437 */         list.addAll(this.m_front.keySet());
/*     */       }
/* 439 */       if (this.m_back != null) {
/* 440 */         Iterator it = this.m_back.keySet().iterator();
/* 441 */         while (it.hasNext()) {
/* 442 */           String name = (String)it.next();
/* 443 */           if (!list.contains(name))
/* 444 */             list.add(name);
/*     */         }
/*     */       }
/* 447 */       return (String[])(String[])list.toArray(new String[0]);
/*     */     }
/*     */ 
/* 450 */     return (String[])(String[])getObjectType().getProperties().keySet().toArray(new String[0]);
/*     */   }
/*     */ 
/*     */   public HashMap getProperties() {
/* 454 */     HashMap result = new HashMap();
/* 455 */     if (this.m_back != null) result.putAll(this.m_back);
/* 456 */     if (this.m_front != null) result.putAll(this.m_front);
/* 457 */     return result;
/*     */   }
/*     */ 
/*     */   public HashMap getNewProperties() {
/* 461 */     HashMap result = new HashMap();
/* 462 */     if (this.m_front != null) result.putAll(this.m_front);
/* 463 */     return result;
/*     */   }
/*     */   public HashMap getOldProperties() {
/* 466 */     HashMap result = new HashMap();
/* 467 */     if (this.m_back != null) {
/* 468 */       result.putAll(this.m_back);
/*     */     }
/* 470 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isModified() {
/* 474 */     if (isDeleted()) return false;
/* 475 */     if (isNew()) return false;
/*     */ 
/* 477 */     return (this.m_front != null) && (this.m_front.size() > 0);
/*     */   }
/*     */ 
/*     */   public void delete()
/*     */   {
/* 483 */     this.m_isDeleted = true;
/*     */   }
/*     */ 
/*     */   public void unDelete() {
/* 487 */     this.m_isDeleted = false;
/*     */   }
/*     */ 
/*     */   public boolean isDeleted() {
/* 491 */     return this.m_isDeleted;
/*     */   }
/*     */ 
/*     */   public boolean isPropertyInitial(String name) {
/* 495 */     name = name.toUpperCase();
/* 496 */     return (this.m_back != null) && (this.m_back.containsKey(name));
/*     */   }
/*     */ 
/*     */   public boolean isPropertyModified(String name) {
/* 500 */     name = name.toUpperCase();
/* 501 */     return (this.m_front != null) && (this.m_front.containsKey(name));
/*     */   }
/*     */ 
/*     */   public boolean isNew() {
/* 505 */     if (isDeleted()) return false;
/* 506 */     return (this.m_back == null) || (this.m_back.size() == 0);
/*     */   }
/*     */ 
/*     */   public void setStsToNew()
/*     */   {
/* 511 */     this.rowIdFlag = false;
/* 512 */     this.mrowid___ = null;
/*     */ 
/* 515 */     if (this.m_back == null) {
/* 516 */       this.m_back = new HashMap();
/*     */     }
/* 518 */     if (this.m_front == null) {
/* 519 */       this.m_front = new HashMap();
/*     */     }
/* 521 */     for (Iterator it = this.m_back.entrySet().iterator(); it.hasNext(); ) {
/* 522 */       Map.Entry me = (Map.Entry)it.next();
/* 523 */       String key = (String)me.getKey();
/* 524 */       Object value = me.getValue();
/* 525 */       if (!this.m_front.containsKey(key))
/* 526 */         this.m_front.put(key, value);
/*     */     }
/* 528 */     this.m_back.clear();
/* 529 */     this.m_isDeleted = false;
/*     */   }
/*     */ 
/*     */   public void setStsToOld()
/*     */   {
/* 534 */     this.rowIdFlag = false;
/* 535 */     this.mrowid___ = null;
/*     */ 
/* 538 */     if (this.m_back == null) {
/* 539 */       this.m_back = new HashMap();
/*     */     }
/* 541 */     if (this.m_front == null) {
/* 542 */       this.m_front = new HashMap();
/*     */     }
/*     */ 
/* 545 */     for (Iterator it = this.m_front.entrySet().iterator(); it.hasNext(); ) {
/* 546 */       Map.Entry me = (Map.Entry)it.next();
/* 547 */       String key = (String)me.getKey();
/* 548 */       Object value = me.getValue();
/* 549 */       this.m_back.put(key, value);
/*     */     }
/* 551 */     this.m_front.clear();
/* 552 */     this.m_isDeleted = false;
/*     */   }
/*     */ 
/*     */   public void copy(DataStructInterface dc) throws AIException {
/* 556 */     DataContainerFactory.copy(dc, this);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface cloneMe() throws AIException {
/* 560 */     DataContainerInterface result = DataContainerFactory.createDataContainerInstance(super.getClass(), getType());
/* 561 */     DataContainerFactory.copy(this, result);
/* 562 */     return result;
/*     */   }
/*     */ 
/*     */   public String getPropertyType(String name) {
/* 566 */     return getType().getProperty(name).getJavaDataType();
/*     */   }
/*     */ 
/*     */   public String fetchTableName()
/*     */   {
/* 572 */     if (this.replaceTableName != null) {
/* 573 */       return this.replaceTableName;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 578 */       return getType().getMapingEnty();
/*     */     }
/*     */     catch (Exception e) {
/* 581 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void replaceTableName(String replaceTableName) {
/* 586 */     this.replaceTableName = replaceTableName;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 590 */     String strDC = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.dc");
/* 591 */     String strAttr = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.display_attr");
/* 592 */     String strOldAttr = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainer.old_display_attr");
/* 593 */     StringBuilder result = new StringBuilder();
/* 594 */     result.append(strDC + getObjectType().getFullName() + "\n");
/*     */     Iterator it;
/* 597 */     if (this.m_front != null)
/* 598 */       for (it = this.m_front.entrySet().iterator(); it.hasNext(); ) {
/* 599 */         Map.Entry me = (Map.Entry)it.next();
/* 600 */         String name = (String)me.getKey();
/* 601 */         Object obj = me.getValue();
/* 602 */         if (obj != null) {
/* 603 */           result.append(name + ":" + obj.toString());
/*     */         }
/* 605 */         Map boAttrDisplay = null;
/* 606 */         if (this.m_AttrSet != null) {
/* 607 */           boAttrDisplay = (Map)this.m_AttrSet.get(name);
/*     */         }
/* 609 */         if (boAttrDisplay != null) {
/* 610 */           result.append("(").append(strAttr);
/* 611 */           for (Iterator it2 = boAttrDisplay.entrySet().iterator(); it2.hasNext(); ) {
/* 612 */             Map.Entry me2 = (Map.Entry)it2.next();
/* 613 */             name = (String)me2.getKey();
/* 614 */             obj = me2.getValue();
/* 615 */             if (obj != null)
/* 616 */               result.append(name + ":" + obj.toString());
/*     */           }
/* 618 */           result.append(")");
/*     */         }
/* 620 */         Map boOldAttrDisplay = null;
/* 621 */         if (this.m_AttrSet_old != null) {
/* 622 */           boOldAttrDisplay = (Map)this.m_AttrSet_old.get(name);
/*     */         }
/* 624 */         if (boOldAttrDisplay != null) {
/* 625 */           result.append("(").append(strOldAttr);
/* 626 */           Iterator it2 = boOldAttrDisplay.entrySet().iterator();
/* 627 */           while (it2.hasNext()) {
/* 628 */             Map.Entry me2 = (Map.Entry)it2.next();
/* 629 */             name = (String)me2.getKey();
/* 630 */             obj = me2.getValue();
/* 631 */             if (obj != null)
/* 632 */               result.append(name + ":" + obj.toString());
/*     */           }
/* 634 */           result.append(")");
/*     */         }
/*     */ 
/* 637 */         result.append("   ");
/*     */       }
/*     */     Iterator it;
/* 641 */     if (this.m_back != null)
/* 642 */       for (it = this.m_back.entrySet().iterator(); it.hasNext(); ) {
/* 643 */         Map.Entry me = (Map.Entry)it.next();
/* 644 */         String name = (String)me.getKey();
/* 645 */         if ((this.m_front != null) && (this.m_front.containsKey(name)))
/*     */           continue;
/* 647 */         Object obj = me.getValue();
/* 648 */         if (obj != null) {
/* 649 */           result.append(name + ":" + obj.toString());
/*     */         }
/* 651 */         Map boAttrDisplay = null;
/* 652 */         if (this.m_AttrSet != null) {
/* 653 */           boAttrDisplay = (Map)this.m_AttrSet.get(name);
/*     */         }
/* 655 */         if (boAttrDisplay != null) {
/* 656 */           result.append("(").append(strAttr);
/* 657 */           for (Iterator it2 = boAttrDisplay.entrySet().iterator(); it2.hasNext(); ) {
/* 658 */             Map.Entry me2 = (Map.Entry)it2.next();
/* 659 */             name = (String)me2.getKey();
/* 660 */             obj = me2.getValue();
/* 661 */             if (obj != null)
/* 662 */               result.append(name + ":" + obj.toString()).append(" ");
/*     */           }
/* 664 */           result.append(")");
/*     */         }
/* 666 */         result.append("   ");
/*     */       }
/*     */     Iterator it;
/* 669 */     if (this.m_relation != null) {
/* 670 */       for (it = this.m_relation.entrySet().iterator(); it.hasNext(); ) {
/* 671 */         Map.Entry me = (Map.Entry)it.next();
/* 672 */         String name = (String)me.getKey();
/* 673 */         Object obj = me.getValue();
/* 674 */         if (obj != null)
/* 675 */           result.append(name + ":" + obj.toString());
/*     */       }
/*     */     }
/* 678 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public void setExtAttr(String pKey, Object pValue) {
/* 682 */     if (this.m_extAttr == null)
/* 683 */       this.m_extAttr = new HashMap();
/* 684 */     this.m_extAttr.put(pKey, pValue);
/*     */   }
/*     */ 
/*     */   public Object getExtAttr(String pKey) {
/* 688 */     if (this.m_extAttr == null) {
/* 689 */       return null;
/*     */     }
/* 691 */     return this.m_extAttr.get(pKey);
/*     */   }
/*     */ 
/*     */   protected void hasRowId()
/*     */   {
/* 697 */     this.rowIdFlag = true;
/*     */   }
/*     */   public boolean isHasRowId() {
/* 700 */     return this.rowIdFlag;
/*     */   }
/*     */   protected void setMRowId(String mrowid___) {
/* 703 */     this.mrowid___ = mrowid___;
/*     */   }
/*     */   public String getMRowId() {
/* 706 */     return this.mrowid___;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DataContainer
 * JD-Core Version:    0.5.4
 */