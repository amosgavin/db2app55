/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.CacheManager;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ObjectTypeFactoryFromClassImpl
/*     */   implements ObjectTypeFactory
/*     */ {
/*  14 */   private static transient Log log = LogFactory.getLog(ObjectTypeFactoryFromClassImpl.class);
/*     */ 
/*  16 */   private static String CACHE_TYPE = "BO";
/*     */ 
/*  18 */   public ObjectType getInstance() throws AIException { return getInstance("ObjectTypeNull"); }
/*     */ 
/*     */   public String[] getObjectTypeNames()
/*     */   {
/*  22 */     return ObjectTypeOfBoListLoad.getAllFileList();
/*     */   }
/*     */ 
/*     */   public ObjectType getInstance(String name) throws AIException {
/*  26 */     if ((name == null) || (name == ""))
/*     */     {
/*  28 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.obj_type_null");
/*  29 */       throw new AIException(msg);
/*     */     }
/*     */ 
/*  32 */     ObjectType result = (ObjectType)ServiceManager.getCacheManager().get(CACHE_TYPE, name);
/*     */ 
/*  34 */     if (result == null) {
/*  35 */       if (name.equalsIgnoreCase("ObjectTypeNull"))
/*  36 */         result = new ObjectTypeNull();
/*     */       else
/*     */         try {
/*  39 */           result = (ObjectType)Class.forName(getObjectTypeClassName(name)).newInstance();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*  43 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.read_type_from_db", new String[] { name }));
/*     */         }
/*  45 */       if (result == null)
/*     */       {
/*  47 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.no_objtype", new String[] { name });
/*  48 */         log.debug(msg);
/*  49 */         throw new AIException(msg);
/*     */       }
/*     */ 
/*  52 */       ServiceManager.getCacheManager().put(CACHE_TYPE, name, result);
/*     */     }
/*  54 */     return result;
/*     */   }
/*     */ 
/*     */   private static String getObjectTypeClassName(String objectTypeName) {
/*  58 */     int index = objectTypeName.lastIndexOf(".");
/*  59 */     String result = "";
/*  60 */     if (index < 0) {
/*  61 */       result = "BO" + objectTypeName + "Map";
/*     */     }
/*     */     else {
/*  64 */       result = objectTypeName.substring(0, index) + ".map.BO" + objectTypeName.substring(index + 1) + "Map";
/*     */     }
/*     */ 
/*  67 */     return result;
/*     */   }
/*     */ 
/*     */   public static String propertyToString(Property p) {
/*  71 */     String attrName = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.attr_name");
/*  72 */     String colName = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.col_name");
/*  73 */     String type = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.type");
/*  74 */     String maxLength = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.max_length");
/*  75 */     String floatLength = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.float_length");
/*  76 */     String relateObj = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.relate_obj");
/*  77 */     String condition = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.condition");
/*  78 */     String relateAttr = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.relate_attr");
/*  79 */     String displayAttr = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl.display_attr");
/*  80 */     StringBuilder result = new StringBuilder();
/*  81 */     result.append(attrName).append(p.getName()).append("(" + p.getRemark() + ")").append(colName).append(p.getMapingColName()).append(type).append(p.getType());
/*     */ 
/*  84 */     result.append(" JavaDataType:").append(p.getJavaDataType()).append(" DataBaseType:").append(p.getDatabaseDataType());
/*     */ 
/*  86 */     result.append(maxLength).append(p.getMaxLength()).append(floatLength).append(p.getFloatLength());
/*     */ 
/*  88 */     if ((p.getRelationObjectTypeName() != null) && (p.getRelationObjectTypeName().trim() != ""))
/*     */     {
/*  90 */       result.append("\n\t").append(relateObj).append(p.getRelationObjectTypeName()).append(condition).append(p.getRelationCondition());
/*     */ 
/*  92 */       String[] ds = p.getDisplayColNames();
/*  93 */       for (int i = 0; i < ds.length; ++i) {
/*  94 */         result.append("\n\t\t").append(relateAttr).append(displayAttr).append(ds[i]);
/*     */       }
/*     */     }
/*  97 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] createDCArray(Class javaDataType, int size) throws AIException
/*     */   {
/* 102 */     return DataContainerFactory.createDataContainerArray(javaDataType, size);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface createDCInstance(Class javaDataType, ObjectType type) throws AIException
/*     */   {
/* 107 */     return DataContainerFactory.createDataContainerInstance(javaDataType, type);
/*     */   }
/*     */ 
/*     */   public void copy(DataContainerInterface source, DataContainerInterface dest) throws AIException
/*     */   {
/* 112 */     DataContainerFactory.copy(source, dest);
/*     */   }
/*     */ 
/*     */   public Class getDefaultDCClass() {
/* 116 */     return DataContainerFactory.getDefaultDataContainerClass();
/*     */   }
/*     */ 
/*     */   public ObjectType getObjectTypeByClass(Class beanClass) throws Exception {
/* 120 */     return DataContainerFactory.getObjectTypeByClass(beanClass);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception
/*     */   {
/* 125 */     ObjectType type = new ObjectTypeFactoryFromClassImpl().getInstance("com.ai.appframe2.bo.IdGeneratorObject");
/* 126 */     System.out.println(type.getFullName());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeFactoryFromClassImpl
 * JD-Core Version:    0.5.4
 */