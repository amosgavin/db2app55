/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import com.ai.appframe2.common.Operator;
/*    */ import com.ai.appframe2.common.Property;
/*    */ import com.ai.appframe2.common.Relation;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ObjectTypeNull
/*    */   implements ObjectType, Serializable
/*    */ {
/* 11 */   private static String m_name = "ObjectTypeNull";
/*    */ 
/*    */   public String getName()
/*    */   {
/* 16 */     return m_name;
/*    */   }
/*    */   public String getFullName() {
/* 19 */     return m_name;
/*    */   }
/*    */   public String getMapingEntyType() {
/* 22 */     return "";
/*    */   }
/*    */   public String getDataFilter() {
/* 25 */     return "";
/*    */   }
/*    */ 
/*    */   public String getMapingEnty() throws AIException
/*    */   {
/* 30 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeNull.no_tablename");
/* 31 */     throw new AIException(msg);
/*    */   }
/*    */   public String getDataSource() {
/* 34 */     return null;
/*    */   }
/*    */   public String getMainAttr() {
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */   public String getClassName()
/*    */   {
/* 42 */     return null;
/*    */   }
/*    */ 
/*    */   public boolean isKeyProperty(String p)
/*    */   {
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   public HashMap getKeyProperties() {
/* 51 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   public HashMap getProperties() {
/* 55 */     return new HashMap();
/*    */   }
/*    */   public String[] getPropertyNames() {
/* 58 */     return new String[0];
/*    */   }
/*    */ 
/*    */   public boolean hasProperty(String name) {
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   public Property getProperty(String name)
/*    */   {
/* 67 */     return (Property)null;
/*    */   }
/*    */ 
/*    */   public HashMap getRelations() {
/* 71 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   public boolean hasRelation(String name) {
/* 75 */     return false;
/*    */   }
/*    */   public Relation getRelation(String name) {
/* 78 */     return (Relation)null;
/*    */   }
/*    */ 
/*    */   public HashMap getOperators() {
/* 82 */     return new HashMap();
/*    */   }
/*    */ 
/*    */   public boolean hasOperator(String name) {
/* 86 */     return false;
/*    */   }
/*    */ 
/*    */   public Operator getOperator(String name) {
/* 90 */     return (Operator)null;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 94 */     return getName();
/*    */   }
/*    */   public String debug() {
/* 97 */     return getName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeNull
 * JD-Core Version:    0.5.4
 */