/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import com.ai.appframe2.common.ObjectTypeFactory;
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class ObjectTypeFactoryImpl
/*    */   implements ObjectTypeFactory
/*    */ {
/*    */   private ObjectTypeFactoryFromFileImpl m_file;
/*    */   private ObjectTypeFactoryFromClassImpl m_class;
/*    */ 
/*    */   public ObjectTypeFactoryImpl()
/*    */   {
/* 20 */     this.m_file = new ObjectTypeFactoryFromFileImpl();
/* 21 */     this.m_class = new ObjectTypeFactoryFromClassImpl();
/*    */   }
/*    */   public ObjectType getInstance() throws AIException {
/* 24 */     return this.m_class.getInstance();
/*    */   }
/*    */ 
/*    */   public ObjectType getInstance(String name) throws AIException {
/* 28 */     ObjectType result = this.m_class.getInstance(name);
/* 29 */     if (result != null)
/* 30 */       result = this.m_file.getInstance(name);
/* 31 */     return result;
/*    */   }
/*    */   public String[] getObjectTypeNames() {
/* 34 */     ArrayList list = new ArrayList();
/* 35 */     String[] result = this.m_class.getObjectTypeNames();
/* 36 */     for (int i = 0; (result != null) && (i < result.length); ++i) {
/* 37 */       list.add(result[i]);
/*    */     }
/* 39 */     result = this.m_file.getObjectTypeNames();
/* 40 */     for (int i = 0; (result != null) && (i < result.length); ++i) {
/* 41 */       if (!list.contains(result[i]))
/* 42 */         list.add(result[i]);
/*    */     }
/* 44 */     return (String[])(String[])list.toArray(new String[0]);
/*    */   }
/*    */ 
/*    */   public DataContainerInterface[] createDCArray(Class javaDataType, int size) throws AIException
/*    */   {
/* 49 */     return DataContainerFactory.createDataContainerArray(javaDataType, size);
/*    */   }
/*    */ 
/*    */   public DataContainerInterface createDCInstance(Class javaDataType, ObjectType type) throws AIException
/*    */   {
/* 54 */     return DataContainerFactory.createDataContainerInstance(javaDataType, type);
/*    */   }
/*    */ 
/*    */   public void copy(DataContainerInterface source, DataContainerInterface dest) throws AIException
/*    */   {
/* 59 */     DataContainerFactory.copy(source, dest);
/*    */   }
/*    */ 
/*    */   public Class getDefaultDCClass() {
/* 63 */     return DataContainerFactory.getDefaultDataContainerClass();
/*    */   }
/*    */ 
/*    */   public ObjectType getObjectTypeByClass(Class beanClass) throws Exception {
/* 67 */     return DataContainerFactory.getObjectTypeByClass(beanClass);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeFactoryImpl
 * JD-Core Version:    0.5.4
 */