/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.StringReader;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DataStoreHisDataImpl extends DataStoreImpl
/*     */ {
/*  28 */   private static transient Log log = LogFactory.getLog(DataStoreHisDataImpl.class);
/*     */ 
/*     */   public void save(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  37 */     long start_time = System.currentTimeMillis();
/*     */     try {
/*  39 */       if (dc == null) { String msg;
/*     */         return; }
/*  41 */       if ((dc.getObjectType() instanceof ObjectTypeNull) || (dc.getObjectType() instanceof ObjectTypeSingleValue))
/*     */       {
/*  44 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.cannot_do_save", new String[] { dc.getObjectType().getFullName() });
/*  45 */         throw new AIException(msg);
/*     */       }
/*     */ 
/*  48 */       if (dc.isNew())
/*  49 */         insert(conn, dc);
/*  50 */       else if (dc.isDeleted()) {
/*  51 */         delete(conn, dc);
/*     */       }
/*  53 */       else if (dc.isModified()) {
/*  54 */         update(conn, dc);
/*     */       }
/*  56 */       dc.setStsToOld();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       String msg;
/*  63 */       if (System.currentTimeMillis() - start_time > 3000L)
/*     */       {
/*  66 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.sql_need_optmize");
/*  67 */         log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.save_data_time_high", new String[] { String.valueOf(System.currentTimeMillis() - start_time) }), new Exception(msg));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void insert(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  80 */     ArrayList plist = new ArrayList();
/*  81 */     ArrayList ptype = new ArrayList();
/*     */ 
/*  83 */     ArrayList col_list = new ArrayList();
/*     */ 
/*  85 */     StringBuilder sql = new StringBuilder();
/*  86 */     StringBuilder value = new StringBuilder();
/*     */ 
/*  88 */     String tableName = dc.fetchTableName();
/*  89 */     sql.append("insert into ").append(tableName).append("(");
/*  90 */     value.append("values(");
/*     */ 
/*  94 */     String masterTableName = dc.getObjectType().getMapingEnty().replaceAll("\\{", "").replaceAll("\\}", "").trim();
/*     */ 
/*  97 */     boolean bBackup = ServiceManager.getIdGenerator().getHisDataFlag(masterTableName);
/*     */ 
/*  99 */     boolean bDoneCode = ServiceManager.getIdGenerator().getHisDoneCodeFlag(masterTableName);
/*     */ 
/* 101 */     boolean isfirst = true;
/*     */ 
/* 104 */     ObjectType type = dc.getObjectType();
/* 105 */     int intertCount = 0;
/* 106 */     for (Iterator it = dc.getProperties().entrySet().iterator(); it.hasNext(); ) {
/* 107 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/* 108 */       String key = (String)me.getKey();
/* 109 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*     */         continue;
/*     */       }
/* 112 */       Object obj = me.getValue();
/*     */ 
/* 115 */       if ((((bBackup) || (bDoneCode))) && 
/* 116 */         (obj == null)) {
/*     */         continue;
/*     */       }
/* 119 */       if (isfirst == true) {
/* 120 */         isfirst = false;
/*     */       } else {
/* 122 */         sql.append(",");
/* 123 */         value.append(",");
/*     */       }
/*     */ 
/* 126 */       String colName = type.getProperty(key).getMapingColName();
/* 127 */       col_list.add(colName);
/* 128 */       sql.append(colName);
/*     */ 
/* 130 */       if (obj == null) {
/* 131 */         value.append("null");
/*     */       }
/*     */       else {
/* 134 */         value.append("?");
/* 135 */         ptype.add(dc.getPropertyType(key));
/* 136 */         plist.add(obj);
/* 137 */         if (log.isDebugEnabled()) {
/* 138 */           log.debug(key + " = " + obj);
/*     */         }
/*     */       }
/* 141 */       intertCount += 1;
/*     */     }
/* 143 */     if (intertCount == 0)
/*     */     {
/* 145 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_real_data_insert"));
/* 146 */       return;
/*     */     }
/*     */ 
/* 150 */     if ((bBackup) || (bDoneCode)) {
/* 151 */       recordInsertHisData(col_list, sql, value, plist, ptype);
/*     */     }
/*     */ 
/* 154 */     sql.append(")");
/* 155 */     value.append(")");
/* 156 */     String strSql = sql.toString() + value.toString();
/* 157 */     if (log.isDebugEnabled()) {
/* 158 */       log.debug(strSql);
/*     */     }
/* 160 */     PreparedStatement statement = conn.prepareStatement(strSql);
/* 161 */     for (int i = 0; i < plist.size(); ++i) {
/* 162 */       if (plist.get(i) instanceof String) {
/* 163 */         String content = (String)plist.get(i);
/* 164 */         if (content.length() > 2000) {
/* 165 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */         }
/*     */         else
/* 168 */           statement.setString(i + 1, content);
/*     */       }
/*     */       else
/*     */       {
/* 172 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*     */       }
/*     */     }
/* 175 */     long startTime = System.currentTimeMillis();
/*     */ 
/* 177 */     statement.execute();
/* 178 */     statement.close();
/*     */ 
/* 180 */     if (log.isDebugEnabled())
/* 181 */       log.debug("Thread " + Thread.currentThread().getName() + " insert time :" + (System.currentTimeMillis() - startTime));
/*     */   }
/*     */ 
/*     */   private void delete(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/* 187 */     ArrayList plist = new ArrayList();
/* 188 */     ArrayList ptype = new ArrayList();
/*     */ 
/* 190 */     StringBuilder where_sql = new StringBuilder(" where ");
/*     */ 
/* 192 */     String tableName = dc.fetchTableName();
/*     */ 
/* 194 */     String key = null;
/* 195 */     Object obj = null;
/* 196 */     boolean isfirst = true;
/* 197 */     for (Iterator it = dc.getObjectType().getKeyProperties().keySet().iterator(); it.hasNext(); ) {
/* 198 */       key = (String)it.next();
/* 199 */       obj = dc.getOldObj(key);
/*     */ 
/* 201 */       if (isfirst == true)
/* 202 */         isfirst = false;
/*     */       else {
/* 204 */         where_sql.append(" and ");
/*     */       }
/* 206 */       where_sql.append(key).append(" = ");
/* 207 */       if (obj == null)
/*     */       {
/* 209 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.pk_null");
/* 210 */         throw new AIException(msg);
/*     */       }
/*     */ 
/* 214 */       where_sql.append("?");
/* 215 */       ptype.add(dc.getPropertyType(key));
/* 216 */       plist.add(obj);
/* 217 */       if (log.isDebugEnabled());
/* 218 */       log.debug(key + " = " + obj);
/*     */     }
/*     */ 
/* 223 */     boolean bBackup = ServiceManager.getIdGenerator().getHisDataFlag(tableName);
/* 224 */     if (bBackup)
/*     */     {
/* 226 */       recordDeleteHisData(conn, dc, where_sql, plist, ptype);
/*     */     }
/*     */ 
/* 230 */     String strDelete_Sql = where_sql.insert(0, tableName).insert(0, "delete from ").toString();
/* 231 */     if (log.isDebugEnabled()) {
/* 232 */       log.debug(strDelete_Sql);
/*     */     }
/* 234 */     PreparedStatement statement = conn.prepareStatement(strDelete_Sql);
/* 235 */     for (int i = 0; i < plist.size(); ++i) {
/* 236 */       if (plist.get(i) instanceof String) {
/* 237 */         String content = (String)plist.get(i);
/* 238 */         if (content.length() > 2000) {
/* 239 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */         }
/*     */         else
/* 242 */           statement.setString(i + 1, content);
/*     */       }
/*     */       else
/*     */       {
/* 246 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*     */       }
/*     */     }
/* 249 */     long startTime = System.currentTimeMillis();
/*     */ 
/* 251 */     statement.execute();
/* 252 */     statement.close();
/*     */ 
/* 254 */     if (log.isDebugEnabled())
/* 255 */       log.debug("Thread " + Thread.currentThread().getName() + " delete time :" + (System.currentTimeMillis() - startTime));
/*     */   }
/*     */ 
/*     */   private void update(Connection conn, DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/* 261 */     ArrayList plist = new ArrayList();
/* 262 */     ArrayList ptype = new ArrayList();
/* 263 */     ArrayList update_col_list = null;
/*     */ 
/* 266 */     StringBuilder sql_update = new StringBuilder();
/* 267 */     String tableName = dc.fetchTableName();
/*     */ 
/* 270 */     boolean bBackup = ServiceManager.getIdGenerator().getHisDataFlag(tableName);
/* 271 */     boolean bDoneCode = ServiceManager.getIdGenerator().getHisDoneCodeFlag(tableName);
/* 272 */     if ((bBackup) || (bDoneCode)) {
/* 273 */       update_col_list = new ArrayList();
/*     */     }
/*     */ 
/* 276 */     sql_update.append("update ").append(tableName).append(" set ");
/* 277 */     boolean isfirst = true;
/*     */ 
/* 280 */     int intertCount = 0;
/* 281 */     for (Iterator it = dc.getNewProperties().entrySet().iterator(); it.hasNext(); ) {
/* 282 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/* 283 */       String key = (String)me.getKey();
/* 284 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*     */         continue;
/*     */       }
/* 287 */       Object obj = me.getValue();
/*     */ 
/* 289 */       if (isfirst == true) {
/* 290 */         isfirst = false;
/*     */       }
/*     */       else {
/* 293 */         sql_update.append(",");
/*     */       }
/*     */ 
/* 296 */       sql_update.append(key).append(" = ");
/* 297 */       if (obj == null) {
/* 298 */         sql_update.append("null");
/*     */       } else {
/* 300 */         sql_update.append("?");
/* 301 */         ptype.add(dc.getPropertyType(key));
/* 302 */         plist.add(obj);
/* 303 */         if (log.isDebugEnabled()) {
/* 304 */           log.debug(key + " = " + obj);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 309 */       if ((bBackup) || (bDoneCode)) {
/* 310 */         update_col_list.add(key);
/*     */       }
/* 312 */       intertCount += 1;
/*     */     }
/* 314 */     if (intertCount == 0)
/*     */     {
/* 316 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_real_data_insert"));
/* 317 */       return;
/*     */     }
/*     */ 
/* 320 */     if ((bBackup) || (bDoneCode)) {
/* 321 */       recordUpdateHisData(conn, dc, sql_update, plist, ptype, update_col_list);
/*     */     }
/*     */ 
/* 325 */     isfirst = true;
/*     */ 
/* 327 */     StringBuilder where_sql = new StringBuilder(" where  ");
/*     */ 
/* 329 */     Map keys = dc.getKeyProperties();
/* 330 */     if (keys.size() == 0)
/*     */     {
/* 332 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_pk_data");
/* 333 */       throw new AIException(msg);
/*     */     }
/* 335 */     for (Iterator it = keys.keySet().iterator(); it.hasNext(); ) {
/* 336 */       String key = (String)it.next();
/* 337 */       Object obj = dc.getOldObj(key);
/* 338 */       if (isfirst == true)
/* 339 */         isfirst = false;
/*     */       else {
/* 341 */         where_sql.append(" and ");
/*     */       }
/* 343 */       where_sql.append(key).append(" = ");
/* 344 */       if (obj == null)
/*     */       {
/* 346 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.pk_null");
/* 347 */         throw new AIException(msg);
/*     */       }
/*     */ 
/* 350 */       where_sql.append("?");
/* 351 */       ptype.add(dc.getPropertyType(key));
/* 352 */       plist.add(obj);
/*     */ 
/* 354 */       if (log.isDebugEnabled());
/* 355 */       log.debug(key + " = " + obj);
/*     */     }
/*     */ 
/* 359 */     String strSql = where_sql;
/* 360 */     if (log.isDebugEnabled()) {
/* 361 */       log.debug(strSql);
/*     */     }
/* 363 */     PreparedStatement statement = conn.prepareStatement(strSql);
/* 364 */     for (int i = 0; i < plist.size(); ++i) {
/* 365 */       if (plist.get(i) instanceof String) {
/* 366 */         String content = (String)plist.get(i);
/* 367 */         if (content.length() > 2000) {
/* 368 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */         }
/*     */         else
/* 371 */           statement.setString(i + 1, content);
/*     */       }
/*     */       else {
/* 374 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 379 */     long startTime = System.currentTimeMillis();
/*     */ 
/* 381 */     statement.execute();
/* 382 */     statement.close();
/*     */ 
/* 384 */     if (log.isDebugEnabled())
/* 385 */       log.debug("Thead " + Thread.currentThread().getName() + " update time :" + (System.currentTimeMillis() - startTime));
/*     */   }
/*     */ 
/*     */   public static void recordDeleteHisData(Connection conn, DataContainerInterface dc, StringBuilder where_sql, ArrayList where_sql_plist, ArrayList where_sql_ptype)
/*     */     throws Exception
/*     */   {
/* 401 */     ObjectType type = dc.getObjectType();
/* 402 */     String tableName = dc.fetchTableName();
/*     */ 
/* 404 */     ArrayList plist_backup1 = new ArrayList();
/* 405 */     ArrayList ptype_backup1 = new ArrayList();
/* 406 */     ArrayList plist_backup2 = new ArrayList();
/* 407 */     ArrayList ptype_backup2 = new ArrayList();
/*     */ 
/* 410 */     StringBuilder table_col = new StringBuilder();
/* 411 */     StringBuilder sql_backup1_col = new StringBuilder();
/* 412 */     StringBuilder sql_backup1_value = new StringBuilder();
/* 413 */     StringBuilder sql_backup2_col = new StringBuilder();
/* 414 */     StringBuilder sql_backup2_value = new StringBuilder();
/*     */ 
/* 416 */     String[] keys = dc.getPropertyNames();
/*     */ 
/* 418 */     for (int i = 0; i < keys.length; ++i) {
/* 419 */       if (type.getProperty(keys[i]).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*     */         continue;
/*     */       }
/* 422 */       String colName = type.getProperty(keys[i]).getMapingColName();
/*     */ 
/* 425 */       if ((colName.equalsIgnoreCase("state")) || (colName.equalsIgnoreCase("DONE_CODE")) || (colName.equalsIgnoreCase("CREATE_DATE")) || (colName.equalsIgnoreCase("DONE_DATE")) || (colName.equalsIgnoreCase("VALID_DATE")) || (colName.equalsIgnoreCase("EXPIRE_DATE")) || (colName.equalsIgnoreCase("OP_ID"))) continue; if (colName.equalsIgnoreCase("ORG_ID"))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 435 */       table_col.append(",").append(colName);
/*     */     }
/*     */ 
/* 438 */     String backupTableName = ServiceManager.getIdGenerator().getHisTableName(tableName);
/*     */ 
/* 440 */     sql_backup1_col.append("insert into ").append(backupTableName).append(" (H_ID").append(table_col);
/*     */ 
/* 444 */     sql_backup2_col.append("insert into ").append(backupTableName).append(" (H_ID").append(table_col);
/*     */ 
/* 448 */     sql_backup1_value.append(") select ? as H_ID").append(table_col);
/* 449 */     ptype_backup1.add("Long");
/* 450 */     plist_backup1.add(new Long(ServiceManager.getIdGenerator().getHisTableNewId(tableName).longValue()));
/*     */ 
/* 454 */     sql_backup2_value.append(") select ? as H_ID").append(table_col);
/* 455 */     ptype_backup2.add("Long");
/* 456 */     plist_backup2.add(new Long(ServiceManager.getIdGenerator().getHisTableNewId(tableName).longValue()));
/*     */ 
/* 461 */     sql_backup1_col.append(",DONE_CODE");
/* 462 */     sql_backup1_value.append(",DONE_CODE");
/* 463 */     sql_backup2_col.append(",DONE_CODE");
/* 464 */     sql_backup2_value.append(",?");
/* 465 */     ptype_backup2.add("Long");
/* 466 */     plist_backup2.add(new Long(ServiceManager.getDoneCode()));
/*     */ 
/* 468 */     sql_backup1_col.append(",CREATE_DATE");
/* 469 */     sql_backup1_value.append(",CREATE_DATE");
/* 470 */     sql_backup2_col.append(",CREATE_DATE");
/* 471 */     sql_backup2_value.append(",CREATE_DATE");
/*     */ 
/* 473 */     sql_backup1_col.append(",VALID_DATE");
/* 474 */     sql_backup1_value.append(",VALID_DATE");
/* 475 */     sql_backup2_col.append(",VALID_DATE");
/* 476 */     sql_backup2_value.append(",VALID_DATE");
/*     */ 
/* 478 */     sql_backup1_col.append(",DONE_DATE");
/* 479 */     sql_backup1_value.append(",DONE_DATE");
/* 480 */     sql_backup2_col.append(",DONE_DATE");
/* 481 */     sql_backup2_value.append(",?");
/* 482 */     ptype_backup2.add("DATETIME");
/* 483 */     plist_backup2.add(ServiceManager.getOpDateTime());
/*     */ 
/* 485 */     sql_backup1_col.append(",EXPIRE_DATE");
/* 486 */     sql_backup1_value.append(",?");
/* 487 */     ptype_backup1.add("DATETIME");
/* 488 */     plist_backup1.add(ServiceManager.getOpDateTime());
/* 489 */     sql_backup2_col.append(",EXPIRE_DATE");
/* 490 */     sql_backup2_value.append(",?");
/* 491 */     ptype_backup2.add("DATETIME");
/* 492 */     plist_backup2.add(ServiceManager.getOpDateTime());
/*     */ 
/* 494 */     sql_backup1_col.append(",OP_ID");
/* 495 */     sql_backup1_value.append(",OP_ID");
/* 496 */     sql_backup2_col.append(",OP_ID");
/* 497 */     sql_backup2_value.append(",?");
/* 498 */     ptype_backup2.add("Long");
/* 499 */     plist_backup2.add(new Long(ServiceManager.getUser().getID()));
/*     */ 
/* 501 */     sql_backup1_col.append(",ORG_ID");
/* 502 */     sql_backup1_value.append(",ORG_ID");
/* 503 */     sql_backup2_col.append(",ORG_ID");
/* 504 */     sql_backup2_value.append(",?");
/* 505 */     ptype_backup2.add("Long");
/* 506 */     plist_backup2.add(new Long(ServiceManager.getUser().getOrgId()));
/*     */ 
/* 510 */     sql_backup1_col.append(",STATE");
/* 511 */     sql_backup1_value.append(",0");
/*     */ 
/* 513 */     sql_backup2_col.append(",STATE");
/* 514 */     sql_backup2_value.append(",-1");
/*     */ 
/* 516 */     sql_backup1_col.append(sql_backup1_value).append(" from ").append(tableName).append(where_sql);
/*     */ 
/* 518 */     sql_backup2_col.append(sql_backup2_value).append(" from ").append(tableName).append(where_sql);
/*     */ 
/* 522 */     for (int i = 0; i < where_sql_plist.size(); ++i) {
/* 523 */       ptype_backup1.add(where_sql_ptype.get(i));
/* 524 */       plist_backup1.add(where_sql_plist.get(i));
/* 525 */       ptype_backup2.add(where_sql_ptype.get(i));
/* 526 */       plist_backup2.add(where_sql_plist.get(i));
/*     */     }
/*     */ 
/* 529 */     PreparedStatement statement_backup1 = conn.prepareStatement(sql_backup1_col.toString());
/*     */ 
/* 531 */     PreparedStatement statement_backup2 = conn.prepareStatement(sql_backup2_col.toString());
/*     */ 
/* 535 */     for (int i = 0; i < ptype_backup1.size(); ++i)
/*     */     {
/* 537 */       if (plist_backup1.get(i) instanceof String) {
/* 538 */         String content = (String)plist_backup1.get(i);
/* 539 */         if (content.length() > 2000) {
/* 540 */           statement_backup1.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */         }
/*     */         else
/*     */         {
/* 544 */           statement_backup1.setString(i + 1, content);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 549 */         DataType.setPrepareStatementParameter(statement_backup1, i + 1, (String)ptype_backup1.get(i), plist_backup1.get(i));
/*     */       }
/*     */     }
/*     */ 
/* 553 */     for (int i = 0; i < ptype_backup2.size(); ++i) {
/* 554 */       if (plist_backup2.get(i) instanceof String) {
/* 555 */         String content = (String)plist_backup2.get(i);
/* 556 */         if (content.length() > 2000) {
/* 557 */           statement_backup2.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */         }
/*     */         else
/*     */         {
/* 561 */           statement_backup2.setString(i + 1, content);
/*     */         }
/*     */       }
/*     */       else {
/* 565 */         DataType.setPrepareStatementParameter(statement_backup2, i + 1, (String)ptype_backup2.get(i), plist_backup2.get(i));
/*     */       }
/*     */     }
/*     */ 
/* 569 */     statement_backup1.execute();
/* 570 */     statement_backup1.close();
/* 571 */     statement_backup2.execute();
/* 572 */     statement_backup2.close();
/*     */   }
/*     */ 
/*     */   public static void recordInsertHisData(ArrayList insert_col_list, StringBuilder col_sql, StringBuilder value_sql, ArrayList plist, ArrayList ptype)
/*     */     throws Exception
/*     */   {
/* 591 */     if (!insert_col_list.contains("DONE_CODE")) {
/* 592 */       col_sql.append(",DONE_CODE");
/* 593 */       value_sql.append(",?");
/* 594 */       ptype.add("Long");
/* 595 */       plist.add(new Long(ServiceManager.getDoneCode()));
/*     */     }
/* 597 */     if (!insert_col_list.contains("CREATE_DATE")) {
/* 598 */       col_sql.append(",CREATE_DATE");
/* 599 */       value_sql.append(",?");
/* 600 */       ptype.add("DATETIME");
/* 601 */       plist.add(ServiceManager.getOpDateTime());
/*     */     }
/* 603 */     if (!insert_col_list.contains("VALID_DATE")) {
/* 604 */       col_sql.append(",VALID_DATE");
/* 605 */       value_sql.append(",?");
/* 606 */       ptype.add("DATETIME");
/* 607 */       plist.add(ServiceManager.getOpDateTime());
/*     */     }
/* 609 */     if (!insert_col_list.contains("DONE_DATE")) {
/* 610 */       col_sql.append(",DONE_DATE");
/* 611 */       value_sql.append(",?");
/* 612 */       ptype.add("DATETIME");
/* 613 */       plist.add(ServiceManager.getOpDateTime());
/*     */     }
/* 615 */     if (!insert_col_list.contains("EXPIRE_DATE")) {
/* 616 */       col_sql.append(",EXPIRE_DATE");
/* 617 */       value_sql.append(",?");
/* 618 */       ptype.add("DATETIME");
/* 619 */       plist.add(DataType.transfer("2099-1-1 01:30:30", "DateTime"));
/*     */     }
/*     */ 
/* 622 */     if (!insert_col_list.contains("OP_ID")) {
/* 623 */       col_sql.append(",OP_ID");
/* 624 */       value_sql.append(",?");
/* 625 */       ptype.add("Long");
/* 626 */       plist.add(new Long(ServiceManager.getUser().getID()));
/*     */     }
/* 628 */     if (!insert_col_list.contains("ORG_ID")) {
/* 629 */       col_sql.append(",ORG_ID");
/* 630 */       value_sql.append(",?");
/* 631 */       ptype.add("Long");
/* 632 */       plist.add(new Long(ServiceManager.getUser().getOrgId()));
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void recordUpdateHisData(Connection conn, DataContainerInterface dc, StringBuilder sql_update, ArrayList plist, ArrayList ptype, ArrayList update_col_list)
/*     */     throws Exception
/*     */   {
/* 649 */     String tableName = dc.fetchTableName();
/*     */ 
/* 652 */     boolean bBackup = ServiceManager.getIdGenerator().getHisDataFlag(tableName);
/*     */ 
/* 654 */     boolean bDoneCode = ServiceManager.getIdGenerator().getHisDoneCodeFlag(tableName);
/*     */ 
/* 658 */     ArrayList plist_backup1 = null;
/* 659 */     ArrayList ptype_backup1 = null;
/* 660 */     StringBuilder sql_backup_col = null;
/* 661 */     StringBuilder sql_backup_value = null;
/*     */ 
/* 663 */     if (bBackup) {
/* 664 */       plist_backup1 = new ArrayList();
/* 665 */       ptype_backup1 = new ArrayList();
/*     */ 
/* 667 */       ArrayList insert_col_list = new ArrayList();
/* 668 */       ObjectType type = dc.getObjectType();
/*     */ 
/* 671 */       StringBuilder table_col = new StringBuilder();
/* 672 */       sql_backup_col = new StringBuilder();
/* 673 */       sql_backup_value = new StringBuilder();
/*     */ 
/* 675 */       String[] props = dc.getPropertyNames();
/*     */ 
/* 677 */       for (int i = 0; i < props.length; ++i) {
/* 678 */         if (type.getProperty(props[i]).getType().equalsIgnoreCase("VIRTUAL") == true)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 683 */         String colName = type.getProperty(props[i]).getMapingColName();
/*     */ 
/* 686 */         if (colName.equalsIgnoreCase("STATE")) {
/*     */           continue;
/*     */         }
/* 689 */         table_col.append(",").append(colName);
/* 690 */         insert_col_list.add(colName);
/*     */       }
/*     */ 
/* 693 */       String backupTableName = ServiceManager.getIdGenerator().getHisTableName(tableName);
/*     */ 
/* 695 */       sql_backup_col.append("insert into ").append(backupTableName).append(" (H_ID").append(table_col);
/*     */ 
/* 699 */       sql_backup_value.append(") select ? as H_ID").append(table_col);
/*     */ 
/* 701 */       ptype_backup1.add("Long");
/* 702 */       plist_backup1.add(new Long(ServiceManager.getIdGenerator().getHisTableNewId(tableName).longValue()));
/*     */ 
/* 707 */       if (!insert_col_list.contains("DONE_CODE")) {
/* 708 */         sql_backup_col.append(",DONE_CODE");
/* 709 */         sql_backup_value.append(",DONE_CODE");
/*     */       }
/* 711 */       if (!insert_col_list.contains("CREATE_DATE")) {
/* 712 */         sql_backup_col.append(",CREATE_DATE");
/* 713 */         sql_backup_value.append(",CREATE_DATE");
/*     */       }
/* 715 */       if (!insert_col_list.contains("VALID_DATE")) {
/* 716 */         sql_backup_col.append(",VALID_DATE");
/* 717 */         sql_backup_value.append(",VALID_DATE");
/*     */       }
/* 719 */       if (!insert_col_list.contains("DONE_DATE")) {
/* 720 */         sql_backup_col.append(",DONE_DATE");
/* 721 */         sql_backup_value.append(",DONE_DATE");
/*     */       }
/* 723 */       if (!insert_col_list.contains("EXPIRE_DATE")) {
/* 724 */         sql_backup_col.append(",EXPIRE_DATE");
/* 725 */         sql_backup_value.append(",?");
/* 726 */         ptype_backup1.add("DATETIME");
/* 727 */         plist_backup1.add(ServiceManager.getOpDateTime());
/*     */       }
/*     */ 
/* 730 */       if (!insert_col_list.contains("OP_ID")) {
/* 731 */         sql_backup_col.append(",OP_ID");
/* 732 */         sql_backup_value.append(",OP_ID");
/*     */       }
/* 734 */       if (!insert_col_list.contains("ORG_ID")) {
/* 735 */         sql_backup_col.append(",ORG_ID");
/* 736 */         sql_backup_value.append(",ORG_ID");
/*     */       }
/*     */ 
/* 739 */       sql_backup_col.append(",STATE");
/* 740 */       sql_backup_value.append(",0");
/*     */     }
/*     */ 
/* 744 */     if (!update_col_list.contains("DONE_CODE")) {
/* 745 */       sql_update.append(",DONE_CODE=?");
/* 746 */       ptype.add("Long");
/* 747 */       plist.add(new Long(ServiceManager.getDoneCode()));
/*     */     }
/* 749 */     if (!update_col_list.contains("VALID_DATE")) {
/* 750 */       sql_update.append(",VALID_DATE=?");
/* 751 */       ptype.add("DATETIME");
/* 752 */       plist.add(ServiceManager.getOpDateTime());
/*     */     }
/* 754 */     if (!update_col_list.contains("DONE_DATE")) {
/* 755 */       sql_update.append(",DONE_DATE=?");
/* 756 */       ptype.add("DATETIME");
/* 757 */       plist.add(ServiceManager.getOpDateTime());
/*     */     }
/*     */ 
/* 760 */     if ((!update_col_list.contains("OP_ID")) && (ServiceManager.getUser() != null)) {
/* 761 */       sql_update.append(",OP_ID=?");
/* 762 */       ptype.add("Long");
/* 763 */       plist.add(new Long(ServiceManager.getUser().getID()));
/*     */     }
/*     */ 
/* 766 */     if ((!update_col_list.contains("ORG_ID")) && (ServiceManager.getUser() != null)) {
/* 767 */       sql_update.append(",ORG_ID=?");
/* 768 */       ptype.add("Long");
/* 769 */       plist.add(new Long(ServiceManager.getUser().getOrgId()));
/*     */     }
/*     */ 
/* 776 */     Object state = dc.get("STATE");
/* 777 */     if (state != null)
/*     */     {
/* 779 */       String state_str = "" + state;
/* 780 */       if ((state_str.equals("0")) && (!update_col_list.contains("EXPIRE_DATE")))
/*     */       {
/* 782 */         sql_update.append(",EXPIRE_DATE=?");
/* 783 */         ptype.add("DATETIME");
/* 784 */         plist.add(ServiceManager.getOpDateTime());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 789 */     boolean isfirst = true;
/*     */ 
/* 791 */     StringBuilder where_sql = new StringBuilder(" where  ");
/*     */ 
/* 793 */     Map keys = dc.getKeyProperties();
/* 794 */     if (keys.size() == 0)
/*     */     {
/* 796 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_pk_data");
/* 797 */       throw new AIException(msg);
/*     */     }
/* 799 */     for (Iterator it = keys.keySet().iterator(); it.hasNext(); ) {
/* 800 */       String key = (String)it.next();
/* 801 */       Object obj = dc.getOldObj(key);
/* 802 */       if (isfirst == true)
/* 803 */         isfirst = false;
/*     */       else {
/* 805 */         where_sql.append(" and ");
/*     */       }
/* 807 */       where_sql.append(key).append(" = ");
/* 808 */       if (obj == null)
/*     */       {
/* 810 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.pk_null");
/* 811 */         throw new AIException(msg);
/*     */       }
/*     */ 
/* 814 */       where_sql.append("?");
/*     */ 
/* 816 */       if (bBackup) {
/* 817 */         ptype_backup1.add(dc.getPropertyType(key));
/* 818 */         plist_backup1.add(obj);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 824 */     if (bBackup) {
/* 825 */       sql_backup_col.append(sql_backup_value).append(" from ").append(tableName).append(where_sql);
/*     */ 
/* 827 */       PreparedStatement statement_backup1 = conn.prepareStatement(sql_backup_col.toString());
/*     */ 
/* 831 */       for (int i = 0; i < ptype_backup1.size(); ++i) {
/* 832 */         if (plist_backup1.get(i) instanceof String) {
/* 833 */           String content = (String)plist_backup1.get(i);
/* 834 */           if (content.length() > 2000) {
/* 835 */             statement_backup1.setCharacterStream(i + 1, new StringReader(content), content.length());
/*     */           }
/*     */           else
/*     */           {
/* 839 */             statement_backup1.setString(i + 1, content);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 844 */           DataType.setPrepareStatementParameter(statement_backup1, i + 1, (String)ptype_backup1.get(i), plist_backup1.get(i));
/*     */         }
/*     */       }
/* 847 */       statement_backup1.execute();
/* 848 */       statement_backup1.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DataStoreHisDataImpl
 * JD-Core Version:    0.5.4
 */