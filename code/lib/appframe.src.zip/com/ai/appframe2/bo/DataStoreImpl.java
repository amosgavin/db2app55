/*      */ package com.ai.appframe2.bo;
/*      */ 
/*      */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*      */ import com.ai.appframe2.bo.dialect.IDialect;
/*      */ import com.ai.appframe2.bo.impl.BatchPstmtParaList;
/*      */ import com.ai.appframe2.common.AIConfigManager;
/*      */ import com.ai.appframe2.common.AIException;
/*      */ import com.ai.appframe2.common.DataContainerInterface;
/*      */ import com.ai.appframe2.common.DataStore;
/*      */ import com.ai.appframe2.common.DataType;
/*      */ import com.ai.appframe2.common.ObjectType;
/*      */ import com.ai.appframe2.common.ObjectTypeFactory;
/*      */ import com.ai.appframe2.common.Operator;
/*      */ import com.ai.appframe2.common.ParameterType;
/*      */ import com.ai.appframe2.common.Property;
/*      */ import com.ai.appframe2.common.Relation;
/*      */ import com.ai.appframe2.common.ServiceManager;
/*      */ import com.ai.appframe2.common.Session;
/*      */ import com.ai.appframe2.express.Operation;
/*      */ import com.ai.appframe2.express.OperatorManager;
/*      */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import sun.jdbc.rowset.CachedRowSet;
/*      */ 
/*      */ public class DataStoreImpl
/*      */   implements DataStore
/*      */ {
/*   59 */   private static transient Log log = LogFactory.getLog(DataStoreImpl.class);
/*      */   protected Operation m_operation;
/*   68 */   protected static int GLOCAL_RESULT_LEVEL = 0;
/*      */ 
/*      */   public DataStoreImpl()
/*      */   {
/*   61 */     this.m_operation = new Operation();
/*      */   }
/*      */ 
/*      */   public DataContainerInterface[] crateDtaContainerFromResultSet(Class dcClass, ObjectType type, ResultSet aDataRowSet, String[] attrList, boolean aFkFlag)
/*      */     throws Exception
/*      */   {
/*  100 */     Property[] propertys = null;
/*  101 */     if ((attrList == null) || (attrList.length == 0)) {
/*  102 */       propertys = (Property[])(Property[])type.getProperties().values().toArray(new Property[0]);
/*      */     }
/*      */     else {
/*  105 */       propertys = new Property[attrList.length];
/*  106 */       for (int i = 0; i < attrList.length; ++i) {
/*  107 */         propertys[i] = type.getProperty(attrList[i]);
/*      */       }
/*      */     }
/*      */ 
/*  111 */     boolean isGoFirst = false;
/*      */ 
/*  113 */     if (aDataRowSet instanceof CachedRowSet) {
/*  114 */       if (((CachedRowSet)aDataRowSet).size() == 0)
/*      */       {
/*  116 */         return DataContainerFactory.createDataContainerArray(dcClass, 0);
/*      */       }
/*      */ 
/*      */     }
/*  120 */     else if (aDataRowSet.next()) {
/*  121 */       isGoFirst = true;
/*      */     }
/*      */     else
/*      */     {
/*  125 */       return DataContainerFactory.createDataContainerArray(dcClass, 0);
/*      */     }
/*      */ 
/*  130 */     List tmp_colProp_list = new ArrayList();
/*  131 */     List tmp_colPK_list = new ArrayList();
/*      */ 
/*  134 */     ResultSetMetaData objMeat = aDataRowSet.getMetaData();
/*  135 */     HashMap dbCols = getMetaCols(objMeat);
/*      */ 
/*  138 */     boolean hasRowId = false;
/*  139 */     if ((DialectFactory.getDialect().isSupportRowId()) && (dbCols.containsKey("MROWID___"))) {
/*  140 */       dbCols.remove("MROWID___");
/*  141 */       hasRowId = true;
/*      */     }
/*      */ 
/*  145 */     for (int i = 0; i < propertys.length; ++i)
/*      */     {
/*  147 */       if (propertys[i].getType().equalsIgnoreCase("VIRTUAL") == true)
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/*  152 */       if (!isValidColumnName(dbCols, propertys[i].getName())) {
/*      */         continue;
/*      */       }
/*      */ 
/*  156 */       tmp_colProp_list.add(propertys[i]);
/*      */ 
/*  159 */       if ((aFkFlag) && (propertys[i].getRelationObjectTypeName() != null) && (!propertys[i].getRelationObjectTypeName().equals("")))
/*      */       {
/*  161 */         String[] displayColNames = propertys[i].getDisplayColNames();
/*  162 */         String pk_columnName = com.ai.appframe2.util.StringUtils.split(displayColNames[0], ';')[1];
/*      */ 
/*  165 */         if (isValidColumnName(dbCols, pk_columnName)) {
/*  166 */           tmp_colPK_list.add(Boolean.TRUE);
/*      */         }
/*      */         else
/*  169 */           tmp_colPK_list.add(Boolean.FALSE);
/*      */       }
/*      */       else
/*      */       {
/*  173 */         tmp_colPK_list.add(Boolean.FALSE);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  178 */     propertys = (Property[])(Property[])tmp_colProp_list.toArray(new Property[0]);
/*  179 */     boolean[] col_pk = new boolean[tmp_colPK_list.size()];
/*  180 */     for (int i = 0; i < tmp_colPK_list.size(); ++i) {
/*  181 */       col_pk[i] = ((Boolean)tmp_colPK_list.get(i)).booleanValue();
/*      */     }
/*      */ 
/*  185 */     String[] colNames = null;
/*  186 */     if (type instanceof ObjectTypeNull) {
/*  187 */       objMeat = aDataRowSet.getMetaData();
/*  188 */       colNames = new String[objMeat.getColumnCount()];
/*  189 */       for (int i = 0; i < objMeat.getColumnCount(); ++i)
/*  190 */         colNames[i] = objMeat.getColumnName(i + 1).toUpperCase();
/*      */     }
/*      */     else
/*      */     {
/*  194 */       colNames = new String[propertys.length];
/*  195 */       for (int i = 0; i < propertys.length; ++i) {
/*  196 */         colNames[i] = propertys[i].getName().toUpperCase();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  201 */     List list = new ArrayList();
/*      */ 
/*  204 */     if (isGoFirst) {
/*  205 */       DataContainerInterface result = DataContainerFactory.createDataContainerInstance(dcClass, type);
/*  206 */       fillData(aDataRowSet, type, result, colNames, propertys, col_pk, hasRowId);
/*  207 */       list.add(result);
/*      */     }
/*      */ 
/*  210 */     while (aDataRowSet.next()) {
/*  211 */       DataContainerInterface result = DataContainerFactory.createDataContainerInstance(dcClass, type);
/*  212 */       fillData(aDataRowSet, type, result, colNames, propertys, col_pk, hasRowId);
/*  213 */       list.add(result);
/*      */     }
/*      */ 
/*  216 */     int size = list.size();
/*  217 */     DataContainerInterface[] rtn = DataContainerFactory.createDataContainerArray(dcClass, size);
/*  218 */     DataContainerInterface[] tmp = (DataContainerInterface[])(DataContainerInterface[])list.toArray(new DataContainerInterface[0]);
/*  219 */     for (int i = 0; i < rtn.length; ++i) {
/*  220 */       rtn[i] = tmp[i];
/*      */     }
/*      */ 
/*  223 */     return rtn;
/*      */   }
/*      */ 
/*      */   protected void fillData(ResultSet aDataRowSet, ObjectType type, DataContainerInterface dc, String[] colNames, Property[] attrList, boolean[] col_pk, boolean hasRowId)
/*      */     throws Exception
/*      */   {
/*  241 */     if ((hasRowId) && (dc instanceof DataContainer)) {
/*  242 */       ((DataContainer)dc).hasRowId();
/*  243 */       ((DataContainer)dc).setMRowId(DialectFactory.getDialect().rowId2String(aDataRowSet.getObject("MROWID___")));
/*      */     }
/*      */ 
/*  246 */     if (type instanceof ObjectTypeNull)
/*      */     {
/*  248 */       for (int i = 0; i < colNames.length; ++i) {
/*  249 */         dc.initPropertyNoUpperCase(colNames[i], aDataRowSet.getObject(colNames[i]));
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  254 */       for (int i = 0; i < colNames.length; ++i)
/*      */       {
/*  256 */         dc.initPropertyNoUpperCase(colNames[i], aDataRowSet.getObject(colNames[i]));
/*      */ 
/*  259 */         if (col_pk[i] != 0) {
/*  260 */           fillFKDataContainerFromBoClass(aDataRowSet, attrList[i], dc);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  268 */       String boName = type.getFullName();
/*      */ 
/*  270 */       boolean isNeedMaskBO = BOMaskFactory.isNeedMask(boName);
/*      */ 
/*  273 */       if (isNeedMaskBO)
/*  274 */         for (int i = 0; i < colNames.length; ++i) {
/*  275 */           IBOMask objIBOMask = BOMaskFactory.getBOMask(boName, colNames[i]);
/*      */ 
/*  277 */           if (objIBOMask != null) {
/*  278 */             Object initValue = dc.get(colNames[i]);
/*      */ 
/*  280 */             Object maskedBOAttrValue = objIBOMask.maskBOAttr(ServiceManager.getUser(), dc, initValue);
/*  281 */             if (log.isDebugEnabled()) {
/*  282 */               log.debug("bo:" + boName + ",attr:" + colNames[i] + ",initValue=" + initValue + ",maskValue=" + maskedBOAttrValue);
/*      */             }
/*      */ 
/*  285 */             if (maskedBOAttrValue == null)
/*      */               continue;
/*  287 */             dc.initPropertyNoUpperCase(colNames[i], initValue, maskedBOAttrValue);
/*      */           }
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void fillDataContainerFromBoClass(ResultSet aDataRowSet, DataContainerInterface dc, Property[] attrList, boolean aFkFlag)
/*      */     throws Exception
/*      */   {
/*  307 */     ObjectType type = dc.getObjectType();
/*  308 */     if (type instanceof ObjectTypeNull) {
/*  309 */       ResultSetMetaData objMeat = aDataRowSet.getMetaData();
/*  310 */       for (int i = 0; i < objMeat.getColumnCount(); ++i)
/*  311 */         dc.initProperty(objMeat.getColumnName(i + 1), aDataRowSet.getObject(objMeat.getColumnName(i + 1)));
/*      */     }
/*      */     else
/*      */     {
/*  315 */       for (int i = 0; i < attrList.length; ++i) {
/*  316 */         if (attrList[i].getType().equalsIgnoreCase("VIRTUAL") == true) {
/*      */           continue;
/*      */         }
/*      */ 
/*  320 */         String col_name = attrList[i].getName();
/*      */         try
/*      */         {
/*  323 */           dc.initProperty(attrList[i].getName(), aDataRowSet.getObject(col_name));
/*  324 */           if ((aFkFlag) && (attrList[i].getRelationObjectTypeName() != null) && (attrList[i].getRelationObjectTypeName() != "")) {
/*  325 */             fillFKDataContainerFromBoClass(aDataRowSet, attrList[i], dc);
/*      */           }
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*  330 */           log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_data_from_resultSet", new String[] { col_name }));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void insert(Connection conn, DataContainerInterface dc)
/*      */     throws Exception
/*      */   {
/*  345 */     ArrayList plist = new ArrayList();
/*  346 */     ArrayList ptype = new ArrayList();
/*      */ 
/*  348 */     ArrayList col_list = new ArrayList();
/*      */ 
/*  350 */     StringBuilder sql = new StringBuilder();
/*  351 */     StringBuilder value = new StringBuilder();
/*      */ 
/*  353 */     String tableName = dc.fetchTableName();
/*  354 */     sql.append("insert into ").append(tableName).append("(");
/*  355 */     value.append("values(");
/*      */ 
/*  357 */     boolean isfirst = true;
/*      */ 
/*  360 */     ObjectType type = dc.getObjectType();
/*  361 */     int intertCount = 0;
/*  362 */     for (Iterator it = dc.getProperties().entrySet().iterator(); it.hasNext(); ) {
/*  363 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/*  364 */       String key = (String)me.getKey();
/*  365 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*      */         continue;
/*      */       }
/*  368 */       Object obj = me.getValue();
/*      */ 
/*  370 */       if (isfirst == true) {
/*  371 */         isfirst = false;
/*      */       }
/*      */       else {
/*  374 */         sql.append(",");
/*  375 */         value.append(",");
/*      */       }
/*      */ 
/*  378 */       String colName = type.getProperty(key).getMapingColName();
/*  379 */       col_list.add(colName);
/*  380 */       sql.append(colName);
/*      */ 
/*  382 */       if (obj == null) {
/*  383 */         value.append("null");
/*      */       }
/*      */       else
/*      */       {
/*  387 */         value.append("?");
/*  388 */         ptype.add(dc.getPropertyType(key));
/*  389 */         plist.add(obj);
/*      */ 
/*  391 */         if (log.isDebugEnabled()) {
/*  392 */           log.debug(key + " = " + obj);
/*      */         }
/*      */       }
/*  395 */       intertCount += 1;
/*      */     }
/*  397 */     if (intertCount == 0)
/*      */     {
/*  399 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_real_data_insert"));
/*  400 */       return;
/*      */     }
/*      */ 
/*  403 */     sql.append(")");
/*  404 */     value.append(")");
/*      */ 
/*  406 */     String strSql = sql.toString() + value.toString();
/*      */ 
/*  408 */     if (log.isDebugEnabled()) {
/*  409 */       log.debug(strSql);
/*      */     }
/*      */ 
/*  412 */     PreparedStatement statement = conn.prepareStatement(strSql);
/*  413 */     for (int i = 0; i < plist.size(); ++i) {
/*  414 */       if (plist.get(i) instanceof String) {
/*  415 */         String content = (String)plist.get(i);
/*  416 */         if (content.length() > 2000) {
/*  417 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*      */         }
/*      */         else {
/*  420 */           statement.setString(i + 1, content);
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  425 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*      */       }
/*      */     }
/*  428 */     long startTime = System.currentTimeMillis();
/*      */ 
/*  430 */     statement.execute();
/*  431 */     statement.close();
/*      */ 
/*  433 */     if (log.isDebugEnabled())
/*  434 */       log.debug("Thread " + Thread.currentThread().getName() + " insert time :" + (System.currentTimeMillis() - startTime));
/*      */   }
/*      */ 
/*      */   private void delete(Connection conn, DataContainerInterface dc)
/*      */     throws Exception
/*      */   {
/*  445 */     ArrayList plist = new ArrayList();
/*  446 */     ArrayList ptype = new ArrayList();
/*      */ 
/*  448 */     StringBuilder where_sql = new StringBuilder(" where ");
/*      */ 
/*  450 */     String tableName = dc.fetchTableName();
/*      */     String key;
/*      */     Object obj;
/*      */     Iterator it;
/*      */     String key;
/*      */     Object obj;
/*      */     boolean isfirst;
/*      */     Iterator it;
/*  453 */     if ((DialectFactory.getDialect().isSupportRowId()) && (dc instanceof DataContainer) && (((DataContainer)dc).isHasRowId())) {
/*  454 */       where_sql.append(" ROWID = ? ");
/*  455 */       ptype.add("String");
/*  456 */       plist.add(((DataContainer)dc).getMRowId());
/*      */ 
/*  459 */       if (log.isDebugEnabled()) {
/*  460 */         log.debug(" ROWID = " + ((DataContainer)dc).getMRowId());
/*      */ 
/*  462 */         key = null;
/*  463 */         obj = null;
/*  464 */         for (it = dc.getObjectType().getKeyProperties().keySet().iterator(); it.hasNext(); ) {
/*  465 */           key = (String)it.next();
/*  466 */           obj = dc.getOldObj(key);
/*      */ 
/*  468 */           if (log.isDebugEnabled());
/*  469 */           log.debug(key + " = " + obj);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  475 */       key = null;
/*  476 */       obj = null;
/*  477 */       isfirst = true;
/*  478 */       for (it = dc.getObjectType().getKeyProperties().keySet().iterator(); it.hasNext(); ) {
/*  479 */         key = (String)it.next();
/*  480 */         obj = dc.getOldObj(key);
/*      */ 
/*  482 */         if (isfirst == true) {
/*  483 */           isfirst = false;
/*      */         }
/*      */         else {
/*  486 */           where_sql.append(" and ");
/*      */         }
/*      */ 
/*  489 */         where_sql.append(key).append(" = ");
/*  490 */         if (obj == null)
/*      */         {
/*  492 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.pk_null");
/*  493 */           throw new AIException(msg);
/*      */         }
/*      */ 
/*  497 */         where_sql.append("?");
/*  498 */         ptype.add(dc.getPropertyType(key));
/*  499 */         plist.add(obj);
/*      */ 
/*  501 */         if (log.isDebugEnabled());
/*  502 */         log.debug(key + " = " + obj);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  510 */     String strDelete_Sql = where_sql.insert(0, tableName).insert(0, "delete from ").toString();
/*  511 */     if (log.isDebugEnabled()) {
/*  512 */       log.debug(strDelete_Sql);
/*      */     }
/*      */ 
/*  515 */     PreparedStatement statement = conn.prepareStatement(strDelete_Sql);
/*  516 */     for (int i = 0; i < plist.size(); ++i) {
/*  517 */       if (plist.get(i) instanceof String) {
/*  518 */         String content = (String)plist.get(i);
/*  519 */         if (content.length() > 2000) {
/*  520 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*      */         }
/*      */         else
/*  523 */           statement.setString(i + 1, content);
/*      */       }
/*      */       else
/*      */       {
/*  527 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*      */       }
/*      */     }
/*  530 */     long startTime = System.currentTimeMillis();
/*      */ 
/*  532 */     statement.execute();
/*  533 */     statement.close();
/*      */ 
/*  535 */     if (log.isDebugEnabled())
/*  536 */       log.debug("Thread " + Thread.currentThread().getName() + " delete time :" + (System.currentTimeMillis() - startTime));
/*      */   }
/*      */ 
/*      */   private void update(Connection conn, DataContainerInterface dc)
/*      */     throws Exception
/*      */   {
/*  548 */     ArrayList plist = new ArrayList();
/*  549 */     ArrayList ptype = new ArrayList();
/*      */ 
/*  552 */     StringBuilder sql_update = new StringBuilder();
/*  553 */     String tableName = dc.fetchTableName();
/*      */ 
/*  555 */     sql_update.append("update ").append(tableName).append(" set ");
/*  556 */     boolean isfirst = true;
/*      */ 
/*  559 */     int intertCount = 0;
/*  560 */     for (Iterator it = dc.getNewProperties().entrySet().iterator(); it.hasNext(); ) {
/*  561 */       Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/*  562 */       String key = (String)me.getKey();
/*  563 */       if (dc.getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*      */         continue;
/*      */       }
/*  566 */       Object obj = me.getValue();
/*      */ 
/*  568 */       if (isfirst == true) {
/*  569 */         isfirst = false;
/*      */       }
/*      */       else {
/*  572 */         sql_update.append(",");
/*      */       }
/*      */ 
/*  575 */       sql_update.append(key).append(" = ");
/*  576 */       if (obj == null) {
/*  577 */         sql_update.append("null");
/*      */       }
/*      */       else {
/*  580 */         sql_update.append("?");
/*  581 */         ptype.add(dc.getPropertyType(key));
/*  582 */         plist.add(obj);
/*      */ 
/*  584 */         if (log.isDebugEnabled()) {
/*  585 */           log.debug(key + " = " + obj);
/*      */         }
/*      */       }
/*      */ 
/*  589 */       intertCount += 1;
/*      */     }
/*      */ 
/*  592 */     if (intertCount == 0)
/*      */     {
/*  594 */       if (log.isDebugEnabled()) {
/*  595 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_real_data_insert"));
/*      */       }
/*  597 */       return;
/*      */     }
/*      */ 
/*  601 */     isfirst = true;
/*      */ 
/*  603 */     StringBuilder where_sql = new StringBuilder(" where  ");
/*      */     String _key;
/*      */     Object _obj;
/*      */     Iterator it;
/*      */     Iterator it;
/*  606 */     if ((DialectFactory.getDialect().isSupportRowId()) && (dc instanceof DataContainer) && (((DataContainer)dc).isHasRowId())) {
/*  607 */       where_sql.append(" ROWID = ? ");
/*  608 */       ptype.add("String");
/*  609 */       plist.add(((DataContainer)dc).getMRowId());
/*      */ 
/*  611 */       if (log.isDebugEnabled()) {
/*  612 */         log.debug("ROWID = " + ((DataContainer)dc).getMRowId());
/*  613 */         _key = null;
/*  614 */         _obj = null;
/*  615 */         for (it = dc.getObjectType().getKeyProperties().keySet().iterator(); it.hasNext(); ) {
/*  616 */           _key = (String)it.next();
/*  617 */           _obj = dc.getOldObj(_key);
/*      */ 
/*  619 */           if (log.isDebugEnabled());
/*  620 */           log.debug(_key + " = " + _obj);
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  626 */       Map keys = dc.getKeyProperties();
/*  627 */       if (keys.size() == 0)
/*      */       {
/*  629 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_pk_data");
/*  630 */         throw new AIException(msg);
/*      */       }
/*  632 */       for (it = keys.keySet().iterator(); it.hasNext(); ) {
/*  633 */         String key = (String)it.next();
/*  634 */         Object obj = dc.getOldObj(key);
/*  635 */         if (isfirst == true) {
/*  636 */           isfirst = false;
/*      */         }
/*      */         else {
/*  639 */           where_sql.append(" and ");
/*      */         }
/*      */ 
/*  642 */         where_sql.append(key).append(" = ");
/*      */ 
/*  644 */         if (obj == null)
/*      */         {
/*  646 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.pk_null");
/*  647 */           throw new AIException(msg);
/*      */         }
/*      */ 
/*  650 */         where_sql.append("?");
/*  651 */         ptype.add(dc.getPropertyType(key));
/*  652 */         plist.add(obj);
/*      */ 
/*  654 */         if (log.isDebugEnabled());
/*  655 */         log.debug(key + " = " + obj);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  661 */     String strSql = where_sql;
/*  662 */     if (log.isDebugEnabled()) {
/*  663 */       log.debug(strSql);
/*      */     }
/*      */ 
/*  666 */     PreparedStatement statement = conn.prepareStatement(strSql);
/*  667 */     for (int i = 0; i < plist.size(); ++i) {
/*  668 */       if (plist.get(i) instanceof String) {
/*  669 */         String content = (String)plist.get(i);
/*  670 */         if (content.length() > 2000) {
/*  671 */           statement.setCharacterStream(i + 1, new StringReader(content), content.length());
/*      */         }
/*      */         else
/*  674 */           statement.setString(i + 1, content);
/*      */       }
/*      */       else
/*      */       {
/*  678 */         DataType.setPrepareStatementParameter(statement, i + 1, (String)ptype.get(i), plist.get(i));
/*      */       }
/*      */     }
/*  681 */     long startTime = System.currentTimeMillis();
/*      */ 
/*  683 */     statement.execute();
/*  684 */     statement.close();
/*      */ 
/*  686 */     if (log.isDebugEnabled())
/*  687 */       log.debug("Thread " + Thread.currentThread().getName() + " update time :" + (System.currentTimeMillis() - startTime));
/*      */   }
/*      */ 
/*      */   public void save(Connection conn, DataContainerInterface[] dcs)
/*      */     throws Exception
/*      */   {
/*  698 */     for (int i = 0; (dcs != null) && (i < dcs.length); ++i)
/*  699 */       save(conn, dcs[i]);
/*      */   }
/*      */ 
/*      */   public void save(Connection conn, DataContainerInterface dc)
/*      */     throws Exception
/*      */   {
/*  710 */     long start_time = System.currentTimeMillis();
/*      */     try {
/*  712 */       if (dc == null) {
/*      */         String msg;
/*      */         return;
/*      */       }
/*  716 */       if ((dc.getObjectType() instanceof ObjectTypeNull) || (dc.getObjectType() instanceof ObjectTypeSingleValue))
/*      */       {
/*  718 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.cannot_do_save", new String[] { dc.getObjectType().getFullName() });
/*  719 */         throw new AIException(msg);
/*      */       }
/*      */ 
/*  722 */       if (dc.isNew()) {
/*  723 */         insert(conn, dc);
/*      */       }
/*  725 */       else if (dc.isDeleted()) {
/*  726 */         delete(conn, dc);
/*      */       }
/*  728 */       else if (dc.isModified()) {
/*  729 */         update(conn, dc);
/*      */       }
/*      */ 
/*  732 */       dc.setStsToOld();
/*      */     }
/*      */     catch (Throwable e)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       String msg;
/*  739 */       if (System.currentTimeMillis() - start_time > 3000L)
/*      */       {
/*  742 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_need_optmize");
/*  743 */         log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.save_data_time_high", new String[] { String.valueOf(System.currentTimeMillis() - start_time) }), new Exception(msg));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveBatch(Connection conn, DataContainerInterface[] dcs)
/*      */     throws Exception
/*      */   {
/*  755 */     HashMap pstmMap = new HashMap();
/*      */ 
/*  757 */     StringBuilder sql = new StringBuilder();
/*  758 */     StringBuilder value = new StringBuilder();
/*  759 */     String tableName = null;
/*  760 */     BatchPstmtParaList pstmtParaList = null;
/*  761 */     for (int i = 0; i < dcs.length; ++i) {
/*  762 */       if (dcs == null) {
/*  763 */         return;
/*      */       }
/*      */ 
/*  766 */       if ((dcs[i].getObjectType() instanceof ObjectTypeNull) || (dcs[i].getObjectType() instanceof ObjectTypeSingleValue))
/*      */       {
/*  768 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.cannot_do_save", new String[] { dcs[i].getObjectType().getFullName() });
/*  769 */         throw new AIException(msg);
/*      */       }
/*      */ 
/*  773 */       sql.setLength(0);
/*  774 */       value.setLength(0);
/*  775 */       tableName = dcs[i].fetchTableName();
/*  776 */       pstmtParaList = new BatchPstmtParaList();
/*      */ 
/*  779 */       if (dcs[i].isNew()) {
/*  780 */         sql.append("insert into ").append(tableName).append("(");
/*  781 */         value.append("values(");
/*  782 */         boolean isfirst = true;
/*      */ 
/*  785 */         ObjectType type = dcs[i].getObjectType();
/*      */ 
/*  787 */         for (Iterator it = dcs[i].getProperties().entrySet().iterator(); it.hasNext(); ) {
/*  788 */           Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/*  789 */           String key = (String)me.getKey();
/*  790 */           if (dcs[i].getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*      */             continue;
/*      */           }
/*  793 */           Object obj = me.getValue();
/*  794 */           if (isfirst == true) {
/*  795 */             isfirst = false;
/*      */           }
/*      */           else {
/*  798 */             sql.append(",");
/*  799 */             value.append(",");
/*      */           }
/*      */ 
/*  802 */           String colName = type.getProperty(key).getMapingColName();
/*  803 */           sql.append(colName);
/*  804 */           value.append(" ? ");
/*  805 */           pstmtParaList.add(key, dcs[i].getPropertyType(key), obj);
/*      */         }
/*  807 */         sql.append(")");
/*  808 */         value.append(")");
/*  809 */         sql.append(value);
/*      */       }
/*  812 */       else if (dcs[i].isDeleted())
/*      */       {
/*  814 */         sql.append("delete from ").append(tableName);
/*  815 */         boolean isfirst = true;
/*      */ 
/*  818 */         for (Iterator it = dcs[i].getObjectType().getKeyProperties().keySet().iterator(); it.hasNext(); ) {
/*  819 */           String key = (String)it.next();
/*  820 */           Object obj = dcs[i].getOldObj(key);
/*  821 */           if (isfirst == true) {
/*  822 */             isfirst = false;
/*      */           }
/*      */           else {
/*  825 */             value.append(" and ");
/*      */           }
/*  827 */           value.append(key).append(" = ");
/*      */ 
/*  829 */           if (obj == null)
/*      */           {
/*  831 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.pk_null");
/*  832 */             throw new AIException(msg);
/*      */           }
/*      */ 
/*  836 */           value.append(" ? ");
/*  837 */           pstmtParaList.add(key, dcs[i].getPropertyType(key), obj);
/*      */         }
/*  839 */         if (value.length() > 0) {
/*  840 */           sql.append(" where ").append(value);
/*      */         }
/*      */       }
/*  843 */       else if (dcs[i].isModified()) {
/*  844 */         sql.append("update ").append(tableName).append(" set ");
/*  845 */         boolean isfirst = true;
/*      */ 
/*  848 */         int intertCount = 0;
/*  849 */         for (Iterator it = dcs[i].getNewProperties().entrySet().iterator(); it.hasNext(); ) {
/*  850 */           Map.Entry me = (Map.Entry)(Map.Entry)it.next();
/*  851 */           String key = (String)me.getKey();
/*  852 */           if (dcs[i].getObjectType().getProperty(key).getType().equalsIgnoreCase("VIRTUAL") == true) {
/*      */             continue;
/*      */           }
/*  855 */           Object obj = me.getValue();
/*      */ 
/*  857 */           if (isfirst == true) {
/*  858 */             isfirst = false;
/*      */           }
/*      */           else {
/*  861 */             sql.append(",");
/*      */           }
/*  863 */           sql.append(key).append(" = ");
/*  864 */           sql.append(" ? ");
/*  865 */           pstmtParaList.add(key, dcs[i].getPropertyType(key), obj);
/*  866 */           intertCount += 1;
/*      */         }
/*  868 */         if (intertCount == 0)
/*      */         {
/*  870 */           if (log.isDebugEnabled()) {
/*  871 */             log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreHisDataImpl.no_real_data_insert"));
/*      */           }
/*  873 */           return;
/*      */         }
/*      */ 
/*  876 */         isfirst = true;
/*      */ 
/*  878 */         Map keys = dcs[i].getKeyProperties();
/*  879 */         if (keys.size() == 0)
/*      */         {
/*  881 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_pk_data");
/*  882 */           throw new AIException(msg);
/*      */         }
/*  884 */         for (Iterator it = keys.keySet().iterator(); it.hasNext(); ) {
/*  885 */           String key = (String)it.next();
/*  886 */           Object obj = dcs[i].getOldObj(key);
/*  887 */           if (isfirst == true) {
/*  888 */             isfirst = false;
/*      */           }
/*      */           else {
/*  891 */             value.append(" and ");
/*      */           }
/*  893 */           value.append(key).append(" = ");
/*  894 */           if (obj == null)
/*      */           {
/*  896 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.pk_null");
/*  897 */             throw new AIException(msg);
/*      */           }
/*      */ 
/*  900 */           value.append(" ? ");
/*  901 */           pstmtParaList.add(key, dcs[i].getPropertyType(key), obj);
/*      */         }
/*      */ 
/*  904 */         if (value.length() > 0) {
/*  905 */           sql.append(" where ").append(value);
/*      */         }
/*      */       }
/*  908 */       if (sql.length() > 0) {
/*  909 */         if (!pstmMap.containsKey(sql.toString())) {
/*  910 */           pstmMap.put(sql.toString(), new ArrayList());
/*      */         }
/*  912 */         ((List)pstmMap.get(sql.toString())).add(pstmtParaList);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  918 */     if (pstmMap.size() == 0)
/*      */     {
/*  920 */       log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_sql_to_deal"));
/*  921 */       return;
/*      */     }
/*      */ 
/*  924 */     for (Iterator iter = pstmMap.keySet().iterator(); iter.hasNext(); ) {
/*  925 */       String sqlStr = (String)iter.next();
/*  926 */       PreparedStatement ptmt = null;
/*      */       try {
/*  928 */         ptmt = conn.prepareStatement(sqlStr);
/*  929 */         if (log.isDebugEnabled()) {
/*  930 */           log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_to_exe", new String[] { sqlStr }));
/*      */         }
/*  932 */         List pstmList = (List)pstmMap.get(sqlStr);
/*  933 */         for (int j = 0; j < pstmList.size(); ++j) {
/*  934 */           BatchPstmtParaList paraList = (BatchPstmtParaList)pstmList.get(j);
/*  935 */           for (int k = 0; k < paraList.getTypes().size(); ++k) {
/*  936 */             DataType.setPrepareStatementParameter(ptmt, k + 1, (String)paraList.getTypes().get(k), paraList.getValues().get(k));
/*      */           }
/*      */ 
/*  939 */           ptmt.addBatch();
/*      */         }
/*  941 */         ptmt.executeBatch();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  945 */         throw e;
/*      */       }
/*      */       finally {
/*  948 */         if (ptmt != null)
/*  949 */           ptmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public int retrieveCount(Connection aConn, ObjectType aType, String aCondition, Map aParameterList, String[] aExtenBOArray)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/*  967 */       String strSql = DialectFactory.getDialect().getSelectSQL(aConn, aType, null, aCondition, -1, -1, false, false, aExtenBOArray);
/*      */ 
/*  969 */       StringBuilder buffer = new StringBuilder();
/*  970 */       if (aType.getMapingEntyType().equalsIgnoreCase("table")) {
/*  971 */         buffer = new StringBuilder("select count(*) ");
/*  972 */         buffer.append(strSql.substring(strSql.indexOf("from")));
/*      */       }
/*      */       else {
/*  975 */         buffer.append(" select count(*) from (").append(strSql).append(" )");
/*  976 */         if (DialectFactory.getDialect().getDatabaseType().equalsIgnoreCase("MYSQL")) {
/*  977 */           buffer.append(" __MC");
/*      */         }
/*      */       }
/*  980 */       buffer.append(" ");
/*  981 */       strSql = buffer.toString();
/*      */ 
/*  983 */       long start = System.currentTimeMillis();
/*  984 */       String[] parameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, ":", " ");
/*      */ 
/*  986 */       ArrayList tempList = new ArrayList();
/*      */ 
/*  988 */       for (int i = 0; (aParameterList != null) && (parameterNames != null) && (i < parameterNames.length); ++i) {
/*  989 */         if (aParameterList.containsKey(parameterNames[i])) {
/*  990 */           tempList.add(parameterNames[i]);
/*      */         }
/*      */       }
/*  993 */       parameterNames = (String[])(String[])tempList.toArray(new String[0]);
/*      */ 
/*  995 */       if (log.isDebugEnabled()) {
/*  996 */         log.debug(strSql);
/*      */       }
/*      */ 
/* 1000 */       if (DialectFactory.getDialect().getDatabaseType().equalsIgnoreCase("MYSQL")) {
/* 1001 */         strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, parameterNames, "? ", ":", " ");
/*      */       }
/*      */       else {
/* 1004 */         strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, parameterNames, "?", ":", " ");
/*      */       }
/*      */ 
/* 1008 */       String[] tableParameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, "{", "}");
/* 1009 */       if ((tableParameterNames != null) && (tableParameterNames.length > 0)) {
/* 1010 */         if (aParameterList == null)
/*      */         {
/* 1012 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1013 */           throw new AIException(msg);
/*      */         }
/*      */ 
/* 1016 */         for (int i = 0; i < tableParameterNames.length; ++i) {
/* 1017 */           String actual_table_name = (String)aParameterList.get(tableParameterNames[i].trim());
/* 1018 */           if (actual_table_name == null)
/*      */           {
/* 1020 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1021 */             throw new AIException(msg);
/*      */           }
/*      */ 
/* 1024 */           strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, "{" + tableParameterNames[i].trim() + "}", actual_table_name);
/*      */         }
/*      */       }
/*      */ 
/* 1028 */       int result = -1;
/* 1029 */       PreparedStatement ptmt = null;
/* 1030 */       ResultSet rs = null;
/*      */       try {
/* 1032 */         ptmt = aConn.prepareStatement(strSql);
/* 1033 */         for (int i = 0; (parameterNames != null) && (i < parameterNames.length); ++i) {
/* 1034 */           if (log.isDebugEnabled()) {
/* 1035 */             log.debug(parameterNames[i] + " = " + aParameterList.get(parameterNames[i]));
/*      */           }
/* 1037 */           DataType.setPrepareStatementParameter(ptmt, i + 1, "Object", aParameterList.get(parameterNames[i]));
/*      */         }
/*      */ 
/* 1040 */         rs = ptmt.executeQuery();
/*      */ 
/* 1042 */         if (rs.next()) {
/* 1043 */           result = rs.getInt(1);
/*      */         }
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*      */       }
/*      */       finally
/*      */       {
/* 1051 */         if (rs != null) {
/* 1052 */           rs.close();
/*      */         }
/* 1054 */         if (ptmt != null) {
/* 1055 */           ptmt.close();
/*      */         }
/*      */       }
/*      */ 
/* 1059 */       if (log.isDebugEnabled()) {
/* 1060 */         log.debug("Thread " + Thread.currentThread().getName() + " query cost:" + (System.currentTimeMillis() - start));
/*      */       }
/*      */ 
/* 1063 */       if (System.currentTimeMillis() - start > 3000L) {
/* 1064 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_need_optmize");
/* 1065 */         log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.query_data_time_high", new String[] { String.valueOf(System.currentTimeMillis() - start) }), new Exception(msg));
/*      */       }
/*      */ 
/* 1069 */       return result;
/*      */     }
/*      */     catch (Throwable e) {
/* 1072 */       log.error(e.getMessage(), e);
/* 1073 */       throw new Exception(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void retrieve(Connection aConn, DataContainerInterface dc, String[] attrList, String aCondition, Map aParameterList, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*      */     throws Exception
/*      */   {
/* 1093 */     ObjectType type = dc.getObjectType();
/* 1094 */     if (attrList != null) {
/* 1095 */       attrList = union(attrList, (String[])(String[])type.getKeyProperties().keySet().toArray(new String[0]));
/*      */     }
/*      */ 
/* 1098 */     ResultSet set = retrieve(aConn, type, attrList, aCondition, aParameterList, -1, -1, aFkFlag, aDistinctFlag, aExtenBOArray);
/*      */ 
/* 1100 */     Property[] propertys = null;
/* 1101 */     if ((attrList == null) || (attrList.length == 0)) {
/* 1102 */       propertys = (Property[])(Property[])type.getProperties().values().toArray(new Property[0]);
/*      */     }
/*      */     else {
/* 1105 */       propertys = new Property[attrList.length];
/* 1106 */       for (int i = 0; i < attrList.length; ++i) {
/* 1107 */         propertys[i] = type.getProperty(attrList[i]);
/*      */       }
/*      */     }
/*      */ 
/* 1111 */     if (set.next()) {
/* 1112 */       fillDataContainerFromBoClass(set, dc, propertys, aFkFlag);
/*      */     }
/* 1114 */     set.close();
/*      */   }
/*      */ 
/*      */   private ResultSet retrieveByResultLevel(Connection aConn, ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray, int resultLevel)
/*      */     throws Exception
/*      */   {
/* 1136 */     if ((attrList != null) && (attrList.length > 0)) {
/* 1137 */       attrList = union(attrList, (String[])(String[])aType.getKeyProperties().keySet().toArray(new String[0]));
/*      */     }
/*      */ 
/* 1140 */     String strSql = DialectFactory.getDialect().getSelectSQL(aConn, aType, attrList, aCondition, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/* 1141 */     return retrieveByResultLevel(aConn, strSql, aParameterList, resultLevel);
/*      */   }
/*      */ 
/*      */   public ResultSet retrieve(Connection aConn, ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*      */     throws Exception
/*      */   {
/* 1161 */     return retrieveByResultLevel(aConn, aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray, -1);
/*      */   }
/*      */ 
/*      */   public ResultSet retrieve(Connection aConn, String strSql, Map aParameterList)
/*      */     throws Exception
/*      */   {
/* 1173 */     return retrieveByResultLevel(aConn, strSql, aParameterList, -1);
/*      */   }
/*      */ 
/*      */   protected ResultSet retrieveByResultLevel(Connection aConn, String strSql, Map aParameterList, int resultLevel)
/*      */     throws Exception
/*      */   {
/* 1188 */     strSql = strSql + " ";
/*      */ 
/* 1190 */     String[] parameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, ":", " ");
/*      */ 
/* 1192 */     ArrayList tempList = new ArrayList();
/*      */ 
/* 1194 */     for (int i = 0; (aParameterList != null) && (parameterNames != null) && (i < parameterNames.length); ++i) {
/* 1195 */       if (aParameterList.containsKey(parameterNames[i])) {
/* 1196 */         tempList.add(parameterNames[i]);
/*      */       }
/*      */     }
/*      */ 
/* 1200 */     parameterNames = (String[])(String[])tempList.toArray(new String[0]);
/*      */ 
/* 1202 */     if (log.isDebugEnabled()) {
/* 1203 */       log.debug(strSql);
/*      */     }
/*      */ 
/* 1206 */     strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, parameterNames, "? ", ":", " ");
/*      */ 
/* 1209 */     String[] tableParameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, "{", "}");
/*      */ 
/* 1211 */     if ((tableParameterNames != null) && (tableParameterNames.length > 0)) {
/* 1212 */       if (aParameterList == null)
/*      */       {
/* 1214 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1215 */         throw new AIException(msg);
/*      */       }
/*      */ 
/* 1218 */       for (int i = 0; i < tableParameterNames.length; ++i) {
/* 1219 */         String actual_table_name = (String)aParameterList.get(tableParameterNames[i].trim());
/* 1220 */         if (actual_table_name == null)
/*      */         {
/* 1222 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1223 */           throw new AIException(msg);
/*      */         }
/*      */ 
/* 1226 */         strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, "{" + tableParameterNames[i].trim() + "}", actual_table_name);
/*      */       }
/*      */     }
/*      */ 
/* 1230 */     long start = System.currentTimeMillis();
/*      */ 
/* 1232 */     ResultSet rtn = null;
/*      */ 
/* 1235 */     if ((resultLevel >= 1) || (GLOCAL_RESULT_LEVEL > 1)) {
/* 1236 */       PreparedStatement ptmt = null;
/*      */       try {
/* 1238 */         ptmt = aConn.prepareStatement(strSql);
/* 1239 */         for (int i = 0; (parameterNames != null) && (i < parameterNames.length); ++i) {
/* 1240 */           if (log.isDebugEnabled()) {
/* 1241 */             log.debug(parameterNames[i] + " = " + aParameterList.get(parameterNames[i]));
/*      */           }
/* 1243 */           DataType.setPrepareStatementParameter(ptmt, i + 1, "Object", aParameterList.get(parameterNames[i]));
/*      */         }
/*      */ 
/* 1246 */         rtn = ptmt.executeQuery();
/*      */       }
/*      */       catch (Throwable e) {
/* 1249 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.data_query_error", new String[] { strSql }), e);
/*      */ 
/* 1253 */         if (ptmt != null) {
/*      */           try {
/* 1255 */             ptmt.close();
/*      */           }
/*      */           catch (Throwable ex) {
/* 1258 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.close_prepareStatement_error"), ex);
/*      */           }
/*      */         }
/* 1261 */         throw new Exception(e);
/*      */       }
/*      */     }
/*      */     else {
/* 1265 */       CachedRowSet objCRS = new CachedRowSet();
/*      */       try {
/* 1267 */         objCRS.setCommand(strSql);
/* 1268 */         for (int i = 0; (parameterNames != null) && (i < parameterNames.length); ++i)
/*      */         {
/* 1270 */           if (log.isDebugEnabled()) {
/* 1271 */             log.debug(parameterNames[i] + " = " + aParameterList.get(parameterNames[i]));
/*      */           }
/*      */ 
/* 1274 */           DataType.setPrepareStatementParameter(objCRS, i + 1, "Object", aParameterList.get(parameterNames[i]));
/*      */         }
/*      */ 
/* 1277 */         objCRS.execute(aConn);
/*      */       }
/*      */       catch (Throwable e)
/*      */       {
/* 1281 */         log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.data_query_error", new String[] { strSql }), e);
/* 1282 */         throw new Exception(e);
/*      */       }
/*      */ 
/* 1285 */       rtn = objCRS;
/*      */     }
/*      */ 
/* 1288 */     if (log.isDebugEnabled()) {
/* 1289 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.query_time", new String[] { Thread.currentThread().getName(), "" + (System.currentTimeMillis() - start) }));
/*      */     }
/*      */ 
/* 1292 */     if (System.currentTimeMillis() - start > 3000L) {
/* 1293 */       String tmp = String.valueOf(System.currentTimeMillis() - start) + " , " + strSql;
/* 1294 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_need_optmize");
/* 1295 */       log.warn(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.query_data_time_high", new String[] { tmp }), new Exception(msg));
/*      */     }
/*      */ 
/* 1298 */     return rtn;
/*      */   }
/*      */ 
/*      */   public DataContainerInterface[] retrieve(Connection aConn, Class dcClass, ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*      */     throws Exception
/*      */   {
/* 1321 */     if ((attrList != null) && (attrList.length > 0)) {
/* 1322 */       attrList = union(attrList, (String[])(String[])aType.getKeyProperties().keySet().toArray(new String[0]));
/*      */     }
/*      */ 
/* 1326 */     ResultSet set = null;
/* 1327 */     DataContainerInterface[] result = null;
/*      */     try {
/* 1329 */       set = retrieveByResultLevel(aConn, aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray, 1);
/* 1330 */       result = crateDtaContainerFromResultSet(dcClass, aType, set, attrList, aFkFlag);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */     }
/*      */     finally
/*      */     {
/*      */       Statement stmt;
/* 1336 */       Statement stmt = null;
/* 1337 */       if (set != null) {
/* 1338 */         stmt = set.getStatement();
/* 1339 */         set.close();
/*      */       }
/* 1341 */       if (stmt != null) {
/* 1342 */         stmt.close();
/*      */       }
/*      */     }
/*      */ 
/* 1346 */     return result;
/*      */   }
/*      */ 
/*      */   public DataContainerInterface[] exeOperation(Connection aConn, DataContainerInterface aDc, String aOperationName, Map aParams)
/*      */     throws Exception
/*      */   {
/* 1359 */     Operator op = aDc.getObjectType().getOperator(aOperationName);
/* 1360 */     Class dcClass = aDc.getClass();
/* 1361 */     if (op == null)
/*      */     {
/* 1363 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_operation");
/* 1364 */       throw new AIException(msg);
/*      */     }
/*      */ 
/* 1367 */     ParameterType[] parameters = (ParameterType[])(ParameterType[])op.getParameterTypes().values().toArray(new ParameterType[0]);
/* 1368 */     Map pValues = new HashMap();
/* 1369 */     for (int i = 0; (parameters != null) && (i < parameters.length); ++i) {
/* 1370 */       Object obj = null;
/*      */ 
/* 1372 */       if (parameters[i].getType().equalsIgnoreCase("inner")) {
/* 1373 */         obj = aDc.get(parameters[i].getValue());
/*      */       }
/* 1375 */       else if (parameters[i].getType().equalsIgnoreCase("outer")) {
/* 1376 */         obj = aParams.get(parameters[i].getName());
/*      */       }
/*      */ 
/* 1379 */       if (obj == null)
/*      */       {
/* 1381 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_param");
/* 1382 */         throw new AIException(msg + parameters[i].getName());
/*      */       }
/*      */ 
/* 1385 */       pValues.put(parameters[i].getName(), obj);
/*      */     }
/*      */ 
/* 1389 */     String[] strCommandArray = op.getCommandArray();
/* 1390 */     if (("query".equalsIgnoreCase(op.getOperationType())) && (strCommandArray.length > 1))
/*      */     {
/* 1392 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.operation_error");
/* 1393 */       throw new AIException(op.getName() + msg);
/*      */     }
/*      */ 
/* 1396 */     DataContainerInterface[] result = null;
/* 1397 */     if (!"query".equalsIgnoreCase(op.getOperationType())) {
/* 1398 */       result = DataContainerFactory.createDataContainerArray(DataContainerFactory.getDefaultDataContainerClass(), strCommandArray.length);
/*      */     }
/*      */ 
/* 1401 */     for (int i = 0; (strCommandArray != null) && (i < strCommandArray.length); ++i)
/*      */     {
/* 1403 */       strCommandArray[i] = (strCommandArray[i] + " ");
/* 1404 */       String[] parameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strCommandArray[i], ":", " ");
/* 1405 */       String strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strCommandArray[i], parameterNames, "? ", ":", " ");
/*      */ 
/* 1408 */       String[] tableParameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, "{", "}");
/* 1409 */       if ((tableParameterNames != null) && (tableParameterNames.length > 0)) {
/* 1410 */         if (aParams == null)
/*      */         {
/* 1412 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1413 */           throw new AIException(msg);
/*      */         }
/*      */ 
/* 1416 */         for (int k = 0; k < tableParameterNames.length; ++k) {
/* 1417 */           String actual_table_name = (String)aParams.get(tableParameterNames[k].trim());
/* 1418 */           if (actual_table_name == null)
/*      */           {
/* 1420 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1421 */             throw new AIException(msg);
/*      */           }
/*      */ 
/* 1424 */           strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, "{" + tableParameterNames[k].trim() + "}", actual_table_name);
/*      */         }
/*      */       }
/*      */ 
/* 1428 */       if (log.isDebugEnabled()) {
/* 1429 */         log.debug(strSql);
/*      */       }
/*      */ 
/* 1432 */       String opType = op.getOperationType();
/*      */       try {
/* 1434 */         if ((opType != null) && (opType.trim() != "") && (!opType.equalsIgnoreCase("query"))) {
/* 1435 */           PreparedStatement stmt = aConn.prepareStatement(strSql);
/* 1436 */           for (int j = 0; (parameterNames != null) && (j < parameterNames.length); ++j) {
/* 1437 */             DataType.setPrepareStatementParameter(stmt, j + 1, "Object", pValues.get(parameterNames[j]));
/*      */           }
/*      */ 
/* 1440 */           int updateCount = stmt.executeUpdate();
/*      */ 
/* 1442 */           result[i] = DataContainerFactory.createDataContainerInstance(null, ServiceManager.getObjectTypeFactory().getInstance());
/* 1443 */           result[i].initProperty("Result", new Integer(updateCount));
/* 1444 */           stmt.close();
/*      */         }
/*      */         else {
/* 1447 */           PreparedStatement stmt = null;
/* 1448 */           ResultSet rs = null;
/*      */           try {
/* 1450 */             stmt = aConn.prepareStatement(strSql);
/* 1451 */             for (int j = 0; (parameterNames != null) && (j < parameterNames.length); ++j) {
/* 1452 */               DataType.setPrepareStatementParameter(stmt, j + 1, "Object", pValues.get(parameterNames[j]));
/*      */             }
/*      */ 
/* 1455 */             long startTime = System.currentTimeMillis();
/*      */ 
/* 1457 */             rs = stmt.executeQuery();
/* 1458 */             result = crateDtaContainerFromSqlResultSet(dcClass, ServiceManager.getObjectTypeFactory().getInstance(), rs, null, false);
/* 1459 */             stmt.close();
/*      */           }
/*      */           finally {
/*      */             try {
/* 1463 */               if (rs != null)
/* 1464 */                 rs.close();
/*      */             }
/*      */             finally {
/* 1467 */               log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.close_resultSet"));
/*      */             }
/*      */             try {
/* 1470 */               if (stmt != null)
/* 1471 */                 stmt.close();
/*      */             }
/*      */             finally {
/* 1474 */               log.info(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.close_prepareStatement"));
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (SQLException e) {
/* 1480 */         log.error(e.getMessage() + " SQL :\n" + strSql);
/* 1481 */         throw e;
/*      */       }
/*      */     }
/* 1484 */     return result;
/*      */   }
/*      */ 
/*      */   private static String[] union(String[] a1, String[] a2)
/*      */   {
/* 1494 */     if ((a1 == null) && (a2 == null)) {
/* 1495 */       return new String[0];
/*      */     }
/*      */ 
/* 1498 */     if (a1 == null) {
/* 1499 */       return a2;
/*      */     }
/*      */ 
/* 1502 */     if (a2 == null) {
/* 1503 */       return a1;
/*      */     }
/*      */ 
/* 1506 */     ArrayList list = new ArrayList();
/* 1507 */     for (int i = 0; i < a1.length; ++i) {
/* 1508 */       list.add(a1[i]);
/*      */     }
/*      */ 
/* 1511 */     for (int i = 0; i < a2.length; ++i) {
/* 1512 */       boolean isfind = false;
/* 1513 */       for (int j = 0; j < a1.length; ++j) {
/* 1514 */         if (a2[i].equalsIgnoreCase(a1[j])) {
/* 1515 */           isfind = true;
/* 1516 */           break;
/*      */         }
/*      */       }
/*      */ 
/* 1520 */       if (!isfind) {
/* 1521 */         list.add(a2[i]);
/*      */       }
/*      */     }
/* 1524 */     return (String[])(String[])list.toArray(new String[0]);
/*      */   }
/*      */ 
/*      */   public DataContainerInterface[] retrieveRelation(Connection aConn, DataContainerInterface aDc, String aRelationName, Class childClass, String[] aAttrList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*      */     throws Exception
/*      */   {
/* 1545 */     Map ps = new HashMap();
/* 1546 */     ObjectType aType = aDc.getObjectType();
/* 1547 */     Relation r = aType.getRelation(aRelationName);
/* 1548 */     if (r == null)
/*      */     {
/* 1550 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_relate");
/* 1551 */       throw new AIException(aType.getName() + msg + aRelationName);
/*      */     }
/*      */ 
/* 1556 */     String[] objRs = this.m_operation.parseForDatabase(r.getRelationCondition());
/* 1557 */     StringBuilder buffer = new StringBuilder(" ");
/* 1558 */     for (int i = 0; (objRs != null) && (i < objRs.length); ++i) {
/* 1559 */       if ((this.m_operation.getOperatorManager().isOperator(objRs[i])) || (objRs[i].equals("?"))) {
/* 1560 */         buffer.append(objRs[i]);
/*      */       }
/*      */       else {
/* 1563 */         String propertypeName = isProperty(aType, objRs[i]);
/* 1564 */         if (propertypeName != null) {
/* 1565 */           buffer.append(" :rp" + i + " ");
/* 1566 */           Object v = aDc.get(propertypeName);
/* 1567 */           if (v == null)
/*      */           {
/* 1569 */             String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.no_attr_for_qry", new String[] { aRelationName, propertypeName });
/* 1570 */             throw new AIException(msg);
/*      */           }
/* 1572 */           ps.put("rp" + i, v);
/*      */         }
/*      */         else {
/* 1575 */           buffer.append(objRs[i]);
/*      */         }
/*      */       }
/*      */     }
/* 1579 */     String condition = buffer.toString();
/* 1580 */     ObjectType childType = ServiceManager.getObjectTypeFactory().getInstance(aType.getRelation(aRelationName).getChildBOName());
/*      */ 
/* 1582 */     return retrieve(aConn, childClass, childType, aAttrList, condition, ps, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/*      */   }
/*      */ 
/*      */   public int execute(Connection aConn, String strSql, Map aParameterList)
/*      */     throws Exception
/*      */   {
/* 1594 */     strSql = strSql + " ";
/* 1595 */     String[] parameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, ":", " ");
/* 1596 */     ArrayList tempList = new ArrayList();
/*      */ 
/* 1598 */     for (int i = 0; (aParameterList != null) && (parameterNames != null) && (i < parameterNames.length); ++i) {
/* 1599 */       if (aParameterList.containsKey(parameterNames[i])) {
/* 1600 */         tempList.add(parameterNames[i]);
/*      */       }
/*      */     }
/* 1603 */     parameterNames = (String[])(String[])tempList.toArray(new String[0]);
/* 1604 */     if (log.isDebugEnabled()) {
/* 1605 */       log.debug(strSql);
/*      */     }
/*      */ 
/* 1608 */     strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, parameterNames, "? ", ":", " ");
/*      */ 
/* 1611 */     String[] tableParameterNames = com.ai.appframe2.util.StringUtils.getParamFromString(strSql, "{", "}");
/* 1612 */     if ((tableParameterNames != null) && (tableParameterNames.length > 0)) {
/* 1613 */       if (aParameterList == null)
/*      */       {
/* 1615 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1616 */         throw new AIException(msg);
/*      */       }
/*      */ 
/* 1619 */       for (int k = 0; k < tableParameterNames.length; ++k) {
/* 1620 */         String actual_table_name = (String)aParameterList.get(tableParameterNames[k].trim());
/* 1621 */         if (actual_table_name == null)
/*      */         {
/* 1623 */           String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.sql_no_tableparam");
/* 1624 */           throw new AIException(msg);
/*      */         }
/*      */ 
/* 1627 */         strSql = com.ai.appframe2.util.StringUtils.replaceParamString(strSql, "{" + tableParameterNames[k].trim() + "}", actual_table_name);
/*      */       }
/*      */     }
/*      */ 
/* 1631 */     long ss = System.currentTimeMillis();
/* 1632 */     int result = -1;
/* 1633 */     PreparedStatement stmt = aConn.prepareStatement(strSql);
/*      */     try {
/* 1635 */       for (int i = 0; (parameterNames != null) && (i < parameterNames.length); ++i) {
/* 1636 */         if (log.isDebugEnabled()) {
/* 1637 */           log.debug(parameterNames[i] + " = " + aParameterList.get(parameterNames[i]));
/*      */         }
/*      */ 
/* 1640 */         DataType.setPrepareStatementParameter(stmt, i + 1, "Object", aParameterList.get(parameterNames[i]));
/*      */       }
/*      */ 
/* 1643 */       result = stmt.executeUpdate();
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/* 1647 */       throw e;
/*      */     }
/*      */     finally {
/* 1650 */       stmt.close();
/*      */     }
/*      */ 
/* 1653 */     if (log.isDebugEnabled()) {
/* 1654 */       log.debug("Thread " + Thread.currentThread().getName() + " query cost:" + (System.currentTimeMillis() - ss));
/*      */     }
/*      */ 
/* 1657 */     return result;
/*      */   }
/*      */ 
/*      */   public Timestamp getSysDateFromDB()
/*      */     throws Exception
/*      */   {
/* 1666 */     Timestamp result = null;
/* 1667 */     Connection conn = null;
/* 1668 */     boolean isStartTransaction = ServiceManager.getSession().isStartTransaction();
/* 1669 */     if (!isStartTransaction)
/* 1670 */       ServiceManager.getSession().startTransaction();
/*      */     try
/*      */     {
/* 1673 */       conn = ServiceManager.getSession().getConnection();
/* 1674 */       result = new Timestamp(DialectFactory.getDialect().getSysDate(conn));
/*      */     }
/*      */     finally {
/* 1677 */       if (conn != null) {
/* 1678 */         conn.close();
/*      */       }
/* 1680 */       if (!isStartTransaction) {
/* 1681 */         ServiceManager.getSession().rollbackTransaction();
/*      */       }
/*      */     }
/* 1684 */     return result;
/*      */   }
/*      */ 
/*      */   public static String clobToString(Clob clob)
/*      */     throws Exception
/*      */   {
/* 1694 */     StringBuilder sb = new StringBuilder();
/* 1695 */     Reader is = clob.getCharacterStream();
/* 1696 */     BufferedReader br = new BufferedReader(is);
/*      */     try {
/* 1698 */       String s = br.readLine();
/* 1699 */       while (s != null) {
/* 1700 */         sb.append(s).append("\r\n");
/* 1701 */         s = br.readLine();
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/* 1705 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.get_clob_error"), ex);
/*      */     }
/*      */ 
/* 1708 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public DataContainerInterface[] crateDtaContainerFromSqlResultSet(Class dcClass, ObjectType type, ResultSet aDataRowSet, String[] attrList, boolean aFkFlag)
/*      */     throws Exception
/*      */   {
/* 1724 */     Property[] propertys = null;
/* 1725 */     if ((attrList == null) || (attrList.length == 0)) {
/* 1726 */       propertys = (Property[])(Property[])type.getProperties().values().toArray(new Property[0]);
/*      */     }
/*      */     else {
/* 1729 */       propertys = new Property[attrList.length];
/* 1730 */       for (int i = 0; i < attrList.length; ++i) {
/* 1731 */         propertys[i] = type.getProperty(attrList[i]);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1736 */     List tmp_colProp_list = new ArrayList();
/* 1737 */     List tmp_colPK_list = new ArrayList();
/*      */ 
/* 1740 */     ResultSetMetaData objMeat = aDataRowSet.getMetaData();
/* 1741 */     HashMap dbCols = getMetaCols(objMeat);
/*      */ 
/* 1744 */     boolean hasRowId = false;
/* 1745 */     if ((DialectFactory.getDialect().isSupportRowId()) && (dbCols.containsKey("MROWID___"))) {
/* 1746 */       dbCols.remove("MROWID___");
/* 1747 */       hasRowId = true;
/*      */     }
/*      */ 
/* 1752 */     for (int i = 0; i < propertys.length; ++i)
/*      */     {
/* 1754 */       if (propertys[i].getType().equalsIgnoreCase("VIRTUAL") == true)
/*      */       {
/*      */         continue;
/*      */       }
/*      */ 
/* 1759 */       if (!isValidColumnName(dbCols, propertys[i].getName())) {
/*      */         continue;
/*      */       }
/*      */ 
/* 1763 */       tmp_colProp_list.add(propertys[i]);
/*      */ 
/* 1766 */       if ((aFkFlag) && (propertys[i].getRelationObjectTypeName() != null) && (!propertys[i].getRelationObjectTypeName().equals("")))
/*      */       {
/* 1769 */         String[] displayColNames = propertys[i].getDisplayColNames();
/* 1770 */         String pk_columnName = com.ai.appframe2.util.StringUtils.split(displayColNames[0], ';')[1];
/*      */ 
/* 1773 */         if (isValidColumnName(dbCols, pk_columnName)) {
/* 1774 */           tmp_colPK_list.add(new Boolean(true));
/*      */         }
/*      */         else
/* 1777 */           tmp_colPK_list.add(new Boolean(false));
/*      */       }
/*      */       else
/*      */       {
/* 1781 */         tmp_colPK_list.add(new Boolean(false));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1786 */     propertys = (Property[])(Property[])tmp_colProp_list.toArray(new Property[0]);
/* 1787 */     boolean[] col_pk = new boolean[tmp_colPK_list.size()];
/* 1788 */     for (int i = 0; i < tmp_colPK_list.size(); ++i) {
/* 1789 */       col_pk[i] = ((Boolean)tmp_colPK_list.get(i)).booleanValue();
/*      */     }
/*      */ 
/* 1793 */     String[] colNames = null;
/* 1794 */     if (type instanceof ObjectTypeNull) {
/* 1795 */       objMeat = aDataRowSet.getMetaData();
/* 1796 */       colNames = new String[objMeat.getColumnCount()];
/* 1797 */       for (int i = 0; i < objMeat.getColumnCount(); ++i)
/* 1798 */         colNames[i] = objMeat.getColumnName(i + 1).toUpperCase();
/*      */     }
/*      */     else
/*      */     {
/* 1802 */       colNames = new String[propertys.length];
/* 1803 */       for (int i = 0; i < propertys.length; ++i) {
/* 1804 */         colNames[i] = propertys[i].getName().toUpperCase();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1809 */     List resultList = new ArrayList();
/* 1810 */     while (aDataRowSet.next()) {
/* 1811 */       DataContainerInterface dci = DataContainerFactory.createDataContainerInstance(dcClass, type);
/* 1812 */       fillData(aDataRowSet, type, dci, colNames, propertys, col_pk, hasRowId);
/* 1813 */       resultList.add(dci);
/*      */     }
/*      */ 
/* 1816 */     DataContainerInterface[] result = DataContainerFactory.createDataContainerArray(dcClass, resultList.size());
/* 1817 */     for (int i = 0; i < resultList.size(); ++i) {
/* 1818 */       result[i] = ((DataContainerInterface)resultList.get(i));
/*      */     }
/* 1820 */     if (result.length > 0) {
/* 1821 */       return result;
/*      */     }
/* 1823 */     return DataContainerFactory.createDataContainerArray(dcClass, 0);
/*      */   }
/*      */ 
/*      */   private HashMap getMetaCols(ResultSetMetaData objMeat)
/*      */     throws Exception
/*      */   {
/* 1833 */     HashMap result = new HashMap();
/* 1834 */     int columnCount = objMeat.getColumnCount();
/* 1835 */     for (int i = 1; i <= columnCount; ++i) {
/* 1836 */       result.put(objMeat.getColumnName(i).toUpperCase(), null);
/*      */     }
/* 1838 */     return result;
/*      */   }
/*      */ 
/*      */   private boolean isValidColumnName(HashMap colNames, String columnName)
/*      */   {
/* 1848 */     return colNames.containsKey(columnName.toUpperCase());
/*      */   }
/*      */ 
/*      */   private static void fillFKDataContainerFromBoClass(ResultSet aDataRowSet, Property aProp, DataContainerInterface dc)
/*      */     throws Exception
/*      */   {
/* 1860 */     String[] displayColNames = aProp.getDisplayColNames();
/* 1861 */     ObjectType fkType = ServiceManager.getObjectTypeFactory().getInstance(aProp.getRelationObjectTypeName());
/*      */ 
/* 1863 */     for (int j = 0; j < displayColNames.length; ++j)
/*      */     {
/* 1865 */       String[] strCols = com.ai.appframe2.util.StringUtils.split(displayColNames[j], ';');
/*      */ 
/* 1867 */       Property fkP = fkType.getProperty(strCols[0]);
/*      */       try {
/* 1869 */         Object obj = aDataRowSet.getObject(strCols[1]);
/* 1870 */         dc.setDiaplayAttr(aProp.getName(), strCols[1], DataType.transfer(obj, fkP.getJavaDataType()));
/*      */       }
/*      */       catch (SQLException ex)
/*      */       {
/* 1874 */         log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.invalid_col", new String[] { strCols[1] }));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static String isProperty(ObjectType type, String aExp)
/*      */   {
/* 1886 */     String[] str = com.ai.appframe2.util.StringUtils.split(aExp, '.');
/* 1887 */     if (str == null) {
/* 1888 */       return null;
/*      */     }
/* 1890 */     String strAttrName = "";
/* 1891 */     String strBOName = "";
/* 1892 */     if (str.length > 1) {
/* 1893 */       strBOName = str[(str.length - 2)];
/* 1894 */       strAttrName = str[(str.length - 1)];
/*      */     }
/*      */     else {
/* 1897 */       strBOName = type.getName();
/* 1898 */       strAttrName = str[(str.length - 1)];
/*      */     }
/* 1900 */     Property p = type.getProperty(strAttrName);
/* 1901 */     if ((strBOName.equalsIgnoreCase(type.getName())) && (p != null)) {
/* 1902 */       return p.getName();
/*      */     }
/*      */ 
/* 1905 */     return null;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*   72 */       HashMap propertyMap = AIConfigManager.getConfigItemsByKind("AppFrameJdbc");
/*   73 */       String level = (String)propertyMap.get("appframe.jdbc.resultset_level");
/*   74 */       if ((!org.apache.commons.lang.StringUtils.isBlank(level)) && (org.apache.commons.lang.StringUtils.isNumeric(level)))
/*   75 */         GLOCAL_RESULT_LEVEL = Integer.parseInt(level);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*   79 */       GLOCAL_RESULT_LEVEL = 0;
/*   80 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataStoreImpl.parse_resultset_level_error"), ex);
/*      */     }
/*      */     finally {
/*   83 */       log.error("appframe.jdbc.resultset_level=" + GLOCAL_RESULT_LEVEL);
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DataStoreImpl
 * JD-Core Version:    0.5.4
 */