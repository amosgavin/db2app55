/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.util.StringUtils;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ class SpecialException extends Exception
/*    */ {
/*    */   public String getPosition()
/*    */   {
/*  7 */     StringWriter writer = new StringWriter();
/*  8 */     PrintWriter p = new PrintWriter(writer);
/*  9 */     printStackTrace(p);
/* 10 */     String[] s = StringUtils.split(writer.getBuffer().toString(), '\n');
/* 11 */     StringBuilder buffer = new StringBuilder();
/* 12 */     boolean isFirst = true;
/* 13 */     for (int i = 1; (s != null) && (i < s.length); ++i) {
/* 14 */       if (s[i].indexOf("at com.ai.appframe2.bo.Session") <= 0) {
/* 15 */         if (isFirst == true)
/* 16 */           isFirst = false;
/*    */         else
/* 18 */           buffer.append(" --- ");
/* 19 */         buffer.append(s[i].trim());
/*    */       }
/*    */     }
/* 22 */     return buffer.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.SpecialException
 * JD-Core Version:    0.5.4
 */