/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStructInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ 
/*     */ public class DataContainerFactory
/*     */ {
/*  22 */   static WrapBeanClassLoader m_wrapBeanClassLoader = new WrapBeanClassLoader();
/*     */ 
/*     */   public static DataContainerInterface[] createDataContainerArray(Class javaDataType, int size) throws AIException {
/*  25 */     if (javaDataType == null)
/*  26 */       javaDataType = DataContainer.class;
/*     */     try {
/*  28 */       if (!DataContainerInterface.class.isAssignableFrom(javaDataType))
/*     */       {
/*  30 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainerFactory.no_dcinterface", new String[] { javaDataType.toString() });
/*  31 */         throw new AIException(msg);
/*     */       }
/*  33 */       return (DataContainerInterface[])(DataContainerInterface[])Array.newInstance(javaDataType, size);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  37 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainerFactory.array_error", new String[] { javaDataType.toString() });
/*  38 */       throw new AIException(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static DataContainerInterface createDataContainerInstance(Class javaDataType, ObjectType type) throws AIException
/*     */   {
/*  44 */     if (javaDataType == null) {
/*  45 */       javaDataType = DataContainer.class;
/*  46 */     } else if (!DataContainerInterface.class.isAssignableFrom(javaDataType))
/*     */     {
/*  48 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainerFactory.no_dcinterface", new String[] { javaDataType.toString() });
/*  49 */       throw new AIException(msg);
/*     */     }
/*     */ 
/*  53 */     DataContainerInterface result = null;
/*     */     try {
/*  55 */       result = (DataContainerInterface)javaDataType.newInstance();
/*     */     } catch (Exception e) {
/*  57 */       throw new AIException(e.getMessage());
/*     */     }
/*     */ 
/*  62 */     if ((javaDataType == DataContainer.class) && (type != null))
/*  63 */       result.setObjectType(type);
/*  64 */     return result;
/*     */   }
/*     */ 
/*     */   public static void copy(DataStructInterface source, DataStructInterface dest)
/*     */     throws AIException
/*     */   {
/*  70 */     dest.clear();
/*  71 */     copyNoClearData(source, dest);
/*     */   }
/*     */ 
/*     */   public static void copy(DataStructInterface source, DataStructInterface dest, Map colMatch)
/*     */     throws AIException
/*     */   {
/*  77 */     dest.clear();
/*  78 */     copyNoClearData(source, dest, colMatch);
/*     */   }
/*     */ 
/*     */   public static void copyNoClearData(DataStructInterface source, DataStructInterface dest) throws AIException
/*     */   {
/*  83 */     String[] propertyNames = null;
/*  84 */     if (dest.getObjectType() instanceof ObjectTypeNull)
/*  85 */       propertyNames = source.getPropertyNames();
/*     */     else
/*  87 */       propertyNames = dest.getPropertyNames();
/*  88 */     Map colMatch = new HashMap();
/*  89 */     for (int i = 0; i < propertyNames.length; ++i) {
/*  90 */       colMatch.put(propertyNames[i], propertyNames[i]);
/*     */     }
/*  92 */     copyNoClearData(source, dest, colMatch);
/*     */   }
/*     */ 
/*     */   public static void copyNoClearData(DataStructInterface source, DataStructInterface dest, Map colMatch)
/*     */     throws AIException
/*     */   {
/* 100 */     HashMap destDisplayAttrMap = dest.getDisplayAttrHashMap();
/* 101 */     HashMap destOldDisplayAttrMap = dest.getOldDisplayAttrHashMap();
/* 102 */     HashMap sourceDisplayAttrMap = source.getDisplayAttrHashMap();
/* 103 */     HashMap sourceOldDisplayAttrMap = source.getOldDisplayAttrHashMap();
/*     */ 
/* 105 */     for (Iterator it = colMatch.entrySet().iterator(); it.hasNext(); ) {
/* 106 */       Map.Entry e = (Map.Entry)it.next();
/* 107 */       String destName = (String)e.getKey();
/* 108 */       String sourceName = (String)e.getValue();
/* 109 */       if (source.isPropertyInitial(sourceName))
/* 110 */         dest.initProperty(destName, source.getOldObj(sourceName));
/* 111 */       if (source.isPropertyModified(sourceName)) {
/* 112 */         dest.set(destName, source.get(sourceName));
/*     */       }
/*     */ 
/* 116 */       Map tmpMap = (Map)sourceDisplayAttrMap.get(sourceName);
/* 117 */       if (tmpMap != null) {
/* 118 */         destDisplayAttrMap.put(destName, tmpMap);
/*     */       }
/* 120 */       tmpMap = (Map)sourceOldDisplayAttrMap.get(sourceName);
/* 121 */       if (tmpMap != null) {
/* 122 */         destOldDisplayAttrMap.put(destName, tmpMap);
/*     */       }
/*     */     }
/* 125 */     if (source.isDeleted())
/* 126 */       dest.delete();
/*     */   }
/*     */ 
/*     */   public static void transfer(Object source, DataStructInterface dest) throws Exception {
/* 130 */     if (source instanceof DataStructInterface) {
/* 131 */       copy((DataStructInterface)source, dest);
/*     */     }
/*     */     else
/* 134 */       BeanUtils.copyProperties(source, dest);
/*     */   }
/*     */ 
/*     */   public static Class getDefaultDataContainerClass()
/*     */   {
/* 140 */     return DataContainer.class;
/*     */   }
/*     */   public static ObjectType getObjectTypeByClass(Class beanClass) throws Exception {
/* 143 */     if (!DataContainerInterface.class.isAssignableFrom(beanClass))
/*     */     {
/* 145 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainerFactory.no_dcinterface", new String[] { beanClass.toString() });
/* 146 */       throw new AIException(msg);
/*     */     }
/* 148 */     Constructor cons = beanClass.getConstructor(new Class[0]);
/* 149 */     return ((DataContainerInterface)cons.newInstance(null)).getObjectType();
/*     */   }
/*     */ 
/*     */   public static DataContainerInterface wrap(DataContainerInterface source, Class destClass, Map colMatch, boolean canModify) throws Exception {
/* 153 */     if (!DataContainer.class.isAssignableFrom(destClass))
/*     */     {
/* 155 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.DataContainerFactory.not_dc");
/* 156 */       throw new AIException(destClass.getName() + msg);
/*     */     }
/*     */ 
/* 159 */     String wrapClassName = destClass.getName() + "Wrap";
/* 160 */     Class wrapClass = m_wrapBeanClassLoader.loadClass(wrapClassName);
/* 161 */     Constructor constructor = wrapClass.getConstructor(new Class[] { DataContainerInterface.class, Map.class, Boolean.TYPE });
/*     */ 
/* 163 */     return (DataContainerInterface)constructor.newInstance(new Object[] { source, colMatch, new Boolean(canModify) });
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.DataContainerFactory
 * JD-Core Version:    0.5.4
 */