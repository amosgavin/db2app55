/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.CacheManager;
/*    */ import com.ai.appframe2.common.ServiceManager;
/*    */ import com.ai.appframe2.util.XmlUtil;
/*    */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class BOMatchFactory
/*    */ {
/* 12 */   private static String CACHE_TYPE = "BOMatch";
/*    */ 
/*    */   public static Map getBOMatch(String matchName, String sourceBO, String destBO) throws Exception {
/* 15 */     MatchItem item = (MatchItem)ServiceManager.getCacheManager().get(CACHE_TYPE, matchName);
/* 16 */     if (item == null) {
/* 17 */       String fileName = matchName.replace('.', '/') + ".map";
/* 18 */       InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/*    */ 
/* 20 */       item = new MatchItem(matchName, in, true);
/* 21 */       in.close();
/* 22 */       ServiceManager.getCacheManager().put(CACHE_TYPE, matchName, item);
/*    */     }
/* 24 */     if (item == null)
/*    */     {
/* 26 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.BOMatchFactory.load_matchinfo_error");
/* 27 */       throw new AIException(msg + matchName);
/*    */     }
/* 29 */     return item.getMatch(sourceBO, destBO);
/*    */   }
/*    */   public static void main(String[] args) throws Exception {
/* 32 */     String matchName = "demo.OrganizeToStaff";
/* 33 */     String sourceBO = "demo.Organize";
/* 34 */     String destBO = "demo.Staff";
/* 35 */     Map m = getBOMatch(matchName, sourceBO, destBO);
/*    */ 
/* 37 */     String fileName = matchName.replace('.', '/') + ".map";
/* 38 */     InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
/*    */ 
/* 40 */     MatchItem item = new MatchItem(matchName, in, true);
/* 41 */     item.addMatch(sourceBO, destBO, "abc", "abc1");
/* 42 */     item.addMatch("a", "b", "abc", "abc1");
/* 43 */     System.out.println(XmlUtil.formatElement(item.getRoot()));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.BOMatchFactory
 * JD-Core Version:    0.5.4
 */