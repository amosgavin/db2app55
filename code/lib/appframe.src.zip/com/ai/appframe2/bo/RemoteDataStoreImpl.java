/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIRootConfig;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.JVM;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.RemoteDataStore;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class RemoteDataStoreImpl
/*     */   implements RemoteDataStore
/*     */ {
/*     */   public void save(UserInfoInterface userInfo, DataContainerInterface[] dcs)
/*     */     throws Exception
/*     */   {
/*  29 */     ServiceManager.setServiceUserInfo(userInfo);
/*  30 */     Connection conn = null;
/*     */     try {
/*  32 */       conn = ServiceManager.getSession().getConnection();
/*  33 */       ServiceManager.getDataStore().save(conn, dcs);
/*  34 */       conn.close();
/*     */     } catch (Throwable e) {
/*  36 */       if (conn != null)
/*  37 */         conn.close();
/*  38 */       throw new Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int retrieveCount(ObjectType aType, String aCondition, Map aParameterList, String[] aExtenBOArray) throws Exception
/*     */   {
/*  44 */     Connection conn = null;
/*  45 */     int result = -1;
/*     */     try {
/*  47 */       conn = ServiceManager.getSession().getConnection();
/*  48 */       result = ServiceManager.getDataStore().retrieveCount(conn, aType, aCondition, aParameterList, aExtenBOArray);
/*     */ 
/*  51 */       conn.close();
/*     */     } catch (Throwable e) {
/*  53 */       if (conn != null)
/*  54 */         conn.close();
/*     */     }
/*  56 */     return result;
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] retrieve(Class dcClass, ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/*  68 */     Connection conn = null;
/*  69 */     DataContainerInterface[] result = null;
/*     */     try {
/*  71 */       conn = ServiceManager.getSession().getConnection();
/*  72 */       result = ServiceManager.getDataStore().retrieve(conn, dcClass, aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/*     */ 
/*  75 */       conn.close();
/*     */     }
/*     */     catch (Throwable e) {
/*  78 */       if (conn != null) {
/*  79 */         conn.close();
/*     */       }
/*     */     }
/*  82 */     return result;
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] retrieve(String strSql, Map aParameterList) throws Exception {
/*  86 */     DataContainerInterface[] result = null;
/*  87 */     Connection conn = null;
/*  88 */     ResultSet resultSet = null;
/*     */     try
/*     */     {
/*  91 */       conn = ServiceManager.getSession().getConnection();
/*  92 */       resultSet = ServiceManager.getDataStore().retrieve(conn, strSql, aParameterList);
/*  93 */       result = ServiceManager.getDataStore().crateDtaContainerFromResultSet(ServiceManager.getObjectTypeFactory().getDefaultDCClass(), ServiceManager.getObjectTypeFactory().getInstance(), resultSet, null, true);
/*     */ 
/*  97 */       conn.close();
/*     */     }
/*     */     catch (Throwable e) {
/* 100 */       if (resultSet != null)
/* 101 */         resultSet.close();
/* 102 */       if (conn != null) {
/* 103 */         conn.close();
/*     */       }
/*     */     }
/* 106 */     return result;
/*     */   }
/*     */ 
/*     */   public int execute(String strSql, Map aParameterList) throws Exception {
/* 110 */     Connection conn = null;
/* 111 */     int result = -1;
/*     */     try {
/* 113 */       conn = ServiceManager.getSession().getConnection();
/* 114 */       result = ServiceManager.getDataStore().execute(conn, strSql, aParameterList);
/*     */ 
/* 116 */       conn.close();
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 120 */       if (conn != null) {
/* 121 */         conn.close();
/*     */       }
/* 123 */       throw new Exception(e);
/*     */     }
/* 125 */     return result;
/*     */   }
/*     */ 
/*     */   public long getNewId(String tableName) throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 132 */       long result = ServiceManager.getIdGenerator().getNewId(tableName).longValue();
/*     */ 
/* 134 */       return result;
/*     */     }
/*     */     catch (Throwable e) {
/* 137 */       throw new Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ResultSet retrieve(ObjectType aType, String[] attrList, String aCondition, Map aParameterList, int aStartNum, int aEndNum, boolean aFkFlag, boolean aDistinctFlag, String[] aExtenBOArray)
/*     */     throws Exception
/*     */   {
/* 149 */     Connection conn = null;
/* 150 */     ResultSet result = null;
/*     */     try
/*     */     {
/* 153 */       conn = ServiceManager.getSession().getConnection();
/* 154 */       result = ServiceManager.getDataStore().retrieve(conn, aType, attrList, aCondition, aParameterList, aStartNum, aEndNum, aFkFlag, aDistinctFlag, aExtenBOArray);
/*     */ 
/* 160 */       conn.close();
/*     */     }
/*     */     catch (Throwable e) {
/* 163 */       if (conn != null) {
/* 164 */         conn.close();
/*     */       }
/* 166 */       throw new Exception(e);
/*     */     }
/* 168 */     return result;
/*     */   }
/*     */ 
/*     */   public Date getSysDate() throws Exception {
/* 172 */     Connection conn = null;
/* 173 */     Date rq = null;
/*     */     try
/*     */     {
/* 176 */       conn = ServiceManager.getSession().getConnection();
/* 177 */       Statement stmt = conn.createStatement();
/* 178 */       ResultSet set = stmt.executeQuery("select sysdate as rq from dual");
/*     */ 
/* 180 */       set.next();
/* 181 */       rq = new Date(set.getTimestamp("rq").getTime());
/* 182 */       set.close();
/* 183 */       stmt.close();
/* 184 */       conn.close();
/*     */     }
/*     */     catch (Throwable e) {
/* 187 */       if (conn != null) {
/* 188 */         conn.close();
/*     */       }
/* 190 */       throw new Exception(e);
/*     */     }
/* 192 */     return rq;
/*     */   }
/*     */ 
/*     */   public void fillDataContainerFromBoClass(ResultSet aDataRowSet, DataContainerInterface dc, Property[] attrList, boolean aFkFlag)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 201 */       ServiceManager.getDataStore().fillDataContainerFromBoClass(aDataRowSet, dc, attrList, aFkFlag);
/*     */     }
/*     */     catch (Throwable e)
/*     */     {
/* 206 */       throw new Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] createDtaContainerFromResultSet(Class dcClass, ObjectType type, ResultSet aDataRowSet, String[] attrList, boolean aFkFlag)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 217 */       DataContainerInterface[] result = ServiceManager.getDataStore().crateDtaContainerFromResultSet(dcClass, type, aDataRowSet, attrList, aFkFlag);
/*     */ 
/* 221 */       return result;
/*     */     }
/*     */     catch (Throwable e) {
/* 224 */       throw new Exception(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void registerAppframeServerInfo(JVM jvm, Date refreshDate)
/*     */     throws Exception
/*     */   {
/* 240 */     Connection conn = null;
/*     */     try {
/* 242 */       conn = ServiceManager.getSession().getConnection(AIRootConfig.getInstance().getRegisterDataSource());
/* 243 */       Map parameter = new HashMap();
/* 244 */       parameter.put("serverId", jvm.uuid);
/* 245 */       parameter.put("jmxHttpUrl", jvm.jmxHttpUrl);
/* 246 */       parameter.put("jmxRmiUrl", jvm.jmxRmiUrl);
/* 247 */       parameter.put("lastModifyDate", new Timestamp(refreshDate.getTime()));
/*     */ 
/* 249 */       String sql = "UPDATE APPFRAME_SERVER SET JMX_HTTP_URL =:jmxHttpUrl ,JMX_RMI_URL = :jmxRmiUrl ,LAST_REFRESH_DATE = :lastModifyDate  WHERE SERVER_ID = :serverId";
/*     */ 
/* 251 */       int count = ServiceManager.getDataStore().execute(conn, sql, parameter);
/* 252 */       if (count <= 0) {
/* 253 */         sql = "INSERT INTO APPFRAME_SERVER(SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE)values( :serverId , :jmxHttpUrl , :jmxRmiUrl , :lastModifyDate , :lastModifyDate )";
/*     */ 
/* 255 */         ServiceManager.getDataStore().execute(conn, sql, parameter);
/*     */       }
/*     */ 
/* 258 */       Timestamp deadTime = new Timestamp(refreshDate.getTime() - AIRootConfig.getInstance().getAppframeServerDeadInterval() * 1000L);
/* 259 */       sql = "INSERT INTO APPFRAME_SERVER_HIS(SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE) SELECT SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE FROM APPFRAME_SERVER  WHERE LAST_REFRESH_DATE < :aDeadTime AND SERVER_ID <> :serverId ";
/*     */ 
/* 262 */       parameter.put("aDeadTime", deadTime);
/* 263 */       ServiceManager.getDataStore().execute(conn, sql, parameter);
/*     */ 
/* 265 */       sql = "DELETE FROM APPFRAME_SERVER WHERE LAST_REFRESH_DATE < :aDeadTime AND SERVER_ID <> :serverId ";
/* 266 */       parameter.put("aDeadTime", deadTime);
/* 267 */       ServiceManager.getDataStore().execute(conn, sql, parameter);
/*     */     } finally {
/* 269 */       if (conn == null)
/* 270 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAppframeServerRegisterInfo(String uniqueServerId) throws Exception {
/* 275 */     Connection conn = null;
/*     */     try {
/* 277 */       conn = ServiceManager.getSession().getConnection(AIRootConfig.getInstance().getRegisterDataSource());
/* 278 */       Map parameter = new HashMap();
/* 279 */       parameter.put("serverId", uniqueServerId);
/*     */ 
/* 281 */       String sql = "INSERT INTO APPFRAME_SERVER_HIS(SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE) SELECT SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE FROM APPFRAME_SERVER  WHERE SERVER_ID = :serverId ";
/*     */ 
/* 284 */       ServiceManager.getDataStore().execute(conn, sql, parameter);
/* 285 */       sql = "DELETE FROM APPFRAME_SERVER  WHERE SERVER_ID = :serverId ";
/* 286 */       ServiceManager.getDataStore().execute(conn, sql, parameter);
/*     */     } finally {
/* 288 */       if (conn == null)
/* 289 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public JVM[] getAppframeServerInfo() throws Exception
/*     */   {
/* 295 */     Connection conn = null;
/* 296 */     List result = new ArrayList();
/*     */     try {
/* 298 */       conn = ServiceManager.getSession().getConnection(AIRootConfig.getInstance().getRegisterDataSource());
/* 299 */       String sql = "SELECT SERVER_ID,JMX_HTTP_URL,JMX_RMI_URL,CREATE_DATE,LAST_REFRESH_DATE FROM APPFRAME_SERVER ";
/* 300 */       ResultSet set = ServiceManager.getDataStore().retrieve(conn, sql, null);
/* 301 */       while (set.next()) {
/* 302 */         JVM temp = JVM.getEmptyJVM();
/* 303 */         temp.uuid = set.getString("SERVER_ID");
/* 304 */         temp.jmxHttpUrl = set.getString("JMX_HTTP_URL");
/* 305 */         temp.jmxRmiUrl = set.getString("JMX_RMI_URL");
/* 306 */         temp.createDate = set.getDate("CREATE_DATE");
/* 307 */         temp.lastRefreshDate = set.getDate("LAST_REFRESH_DATE");
/* 308 */         result.add(temp);
/*     */       }
/* 310 */       set.close();
/*     */     } finally {
/* 312 */       if (conn == null) {
/* 313 */         conn.close();
/*     */       }
/*     */     }
/* 316 */     return (JVM[])(JVM[])result.toArray(new JVM[0]);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.RemoteDataStoreImpl
 * JD-Core Version:    0.5.4
 */