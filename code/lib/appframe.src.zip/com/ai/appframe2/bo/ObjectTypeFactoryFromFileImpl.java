/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.boinfo.BORootNode;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.CacheManager;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Util;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ObjectTypeFactoryFromFileImpl
/*     */   implements ObjectTypeFactory
/*     */ {
/*  16 */   private static transient Log log = LogFactory.getLog(ObjectTypeFactoryFromFileImpl.class);
/*     */ 
/*  18 */   private static String CACHE_TYPE = "BO";
/*  19 */   private static Map m_cach = ServiceManager.getCacheManager().getMap(CACHE_TYPE);
/*     */ 
/*     */   public ObjectType getInstance()
/*     */     throws AIException
/*     */   {
/*  24 */     return getInstance("ObjectTypeNull");
/*     */   }
/*     */ 
/*     */   public String[] getObjectTypeNames() {
/*  28 */     return ObjectTypeOfBoListLoad.getAllFileList();
/*     */   }
/*     */ 
/*     */   public ObjectType getInstance(String name) throws AIException {
/*  32 */     if (name == null)
/*     */     {
/*  34 */       throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromFileImpl.obj_type_null"));
/*     */     }
/*  36 */     ObjectType type = (ObjectType)m_cach.get(name);
/*  37 */     if (type == null) {
/*  38 */       synchronized (name) {
/*  39 */         type = (ObjectType)m_cach.get(name);
/*  40 */         if (type != null) {
/*  41 */           return type;
/*     */         }
/*  43 */         if (name.equalsIgnoreCase("ObjectTypeNull"))
/*  44 */           type = new ObjectTypeNull();
/*     */         else {
/*     */           try {
/*  47 */             type = readFromFile(name);
/*     */           }
/*     */           catch (Throwable e)
/*     */           {
/*  51 */             log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromFileImpl.no_bo", new String[] { name }), e);
/*  52 */             throw new AIException(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeFactoryFromFileImpl.no_bo", new String[] { name }), e);
/*     */           }
/*     */         }
/*  55 */         m_cach.put(name, type);
/*     */       }
/*     */     }
/*  58 */     return type;
/*     */   }
/*     */ 
/*     */   private ObjectType readFromFile(String name) throws Exception {
/*  62 */     String fileName = name.replace('.', '/') + ".bo";
/*  63 */     URL url = Util.getResource(ObjectTypeFactoryFromFileImpl.class, fileName);
/*  64 */     if (url == null)
/*     */     {
/*  66 */       throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.not_load_file", new String[] { fileName }));
/*     */     }
/*  68 */     InputStream is = Util.getResourceAsStream(ObjectTypeFactoryFromFileImpl.class, fileName);
/*     */ 
/*  70 */     BORootNode node = new BORootNode(url, is);
/*  71 */     ObjectType type = (ObjectType)node.getBO();
/*  72 */     int index = name.lastIndexOf('.');
/*  73 */     if (index >= 0) {
/*  74 */       String packageName = name.substring(0, index);
/*  75 */       node.setPackage(packageName);
/*     */     }
/*     */ 
/*  78 */     return type;
/*     */   }
/*     */ 
/*     */   public DataContainerInterface[] createDCArray(Class javaDataType, int size) throws AIException
/*     */   {
/*  83 */     return DataContainerFactory.createDataContainerArray(javaDataType, size);
/*     */   }
/*     */ 
/*     */   public DataContainerInterface createDCInstance(Class javaDataType, ObjectType type) throws AIException
/*     */   {
/*  88 */     return DataContainerFactory.createDataContainerInstance(javaDataType, type);
/*     */   }
/*     */ 
/*     */   public void copy(DataContainerInterface source, DataContainerInterface dest) throws AIException
/*     */   {
/*  93 */     DataContainerFactory.copy(source, dest);
/*     */   }
/*     */ 
/*     */   public Class getDefaultDCClass() {
/*  97 */     return DataContainerFactory.getDefaultDataContainerClass();
/*     */   }
/*     */   public ObjectType getObjectTypeByClass(Class beanClass) throws Exception {
/* 100 */     return DataContainerFactory.getObjectTypeByClass(beanClass);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try {
/* 106 */       ObjectTypeFactoryFromFileImpl x = new ObjectTypeFactoryFromFileImpl();
/* 107 */       ObjectType t = x.getInstance("zrdemo.BOStaff");
/* 108 */       System.out.println(t.getProperty("REPORT_TO_STAFF_ID").getRelationObjectTypeOutJoin());
/*     */     }
/*     */     catch (AIException e) {
/* 111 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeFactoryFromFileImpl
 * JD-Core Version:    0.5.4
 */