/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.impl.PropertyImpl;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Operator;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.Relation;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class ObjectTypeSingleValue
/*     */   implements ObjectType
/*     */ {
/*  15 */   private static String m_name = "ObjectTypeSingleValue";
/*  16 */   HashMap m_property = new HashMap();
/*     */ 
/*     */   public ObjectTypeSingleValue(String javaType)
/*     */   {
/*  20 */     this.m_property.put("RESULT", new PropertyImpl("RESULT", javaType));
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  24 */     return m_name;
/*     */   }
/*     */   public String getDataFilter() {
/*  27 */     return "";
/*     */   }
/*     */   public String getMapingEntyType() {
/*  30 */     return "";
/*     */   }
/*     */ 
/*     */   public String getFullName() {
/*  34 */     return m_name;
/*     */   }
/*     */   public String getMainAttr() {
/*  37 */     return "";
/*     */   }
/*     */   public String getMapingEnty() throws AIException {
/*  40 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.ObjectTypeSingleValue.no_tablename");
/*  41 */     throw new AIException(msg);
/*     */   }
/*     */   public String getDataSource() {
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isKeyProperty(String p)
/*     */   {
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */   public HashMap getKeyProperties() {
/*  58 */     return new HashMap();
/*     */   }
/*     */   public String[] getPropertyNames() {
/*  61 */     return new String[0];
/*     */   }
/*     */ 
/*     */   public HashMap getProperties()
/*     */   {
/*  67 */     return this.m_property;
/*     */   }
/*     */ 
/*     */   public boolean hasProperty(String name)
/*     */   {
/*  72 */     return this.m_property.containsKey(name);
/*     */   }
/*     */ 
/*     */   public Property getProperty(String name)
/*     */   {
/*  77 */     if (this.m_property.containsKey(name))
/*  78 */       return (Property)this.m_property.get(name);
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public HashMap getRelations() {
/*  83 */     return new HashMap();
/*     */   }
/*     */ 
/*     */   public boolean hasRelation(String name) {
/*  87 */     return false;
/*     */   }
/*     */   public Relation getRelation(String name) {
/*  90 */     return (Relation)null;
/*     */   }
/*     */ 
/*     */   public HashMap getOperators() {
/*  94 */     return new HashMap();
/*     */   }
/*     */ 
/*     */   public boolean hasOperator(String name) {
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   public Operator getOperator(String name) {
/* 102 */     return (Operator)null;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 106 */     return getName();
/*     */   }
/*     */   public String debug() {
/* 109 */     return getName();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.ObjectTypeSingleValue
 * JD-Core Version:    0.5.4
 */