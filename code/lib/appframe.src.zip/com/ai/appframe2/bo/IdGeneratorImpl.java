/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.bo.dialect.DialectFactory;
/*     */ import com.ai.appframe2.bo.dialect.IDialect;
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.CacheManager;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.io.PrintStream;
/*     */ import java.math.BigDecimal;
/*     */ import java.rmi.RemoteException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class IdGeneratorImpl
/*     */   implements IdGenerator
/*     */ {
/*  25 */   private static transient Log log = LogFactory.getLog(IdGeneratorImpl.class);
/*     */ 
/*  27 */   private static final Map m_generators = ServiceManager.getCacheManager().getMap("SysIdGeneratorEngine");
/*  28 */   private static final Map m_hasInitialUser = ServiceManager.getCacheManager().getMap("SYSID_GENERATOR_INITIAL_USER");
/*     */ 
/*     */   // ERROR //
/*     */   public static void init(Connection conn) throws Exception { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokeinterface 2 1 0
/*     */     //   6: invokeinterface 3 1 0
/*     */     //   11: invokevirtual 4	java/lang/String:toUpperCase	()Ljava/lang/String;
/*     */     //   14: astore_1
/*     */     //   15: getstatic 5	com/ai/appframe2/bo/IdGeneratorImpl:m_hasInitialUser	Ljava/util/Map;
/*     */     //   18: aload_1
/*     */     //   19: invokeinterface 6 2 0
/*     */     //   24: ifeq +4 -> 28
/*     */     //   27: return
/*     */     //   28: aload_1
/*     */     //   29: dup
/*     */     //   30: astore_2
/*     */     //   31: monitorenter
/*     */     //   32: getstatic 5	com/ai/appframe2/bo/IdGeneratorImpl:m_hasInitialUser	Ljava/util/Map;
/*     */     //   35: aload_1
/*     */     //   36: invokeinterface 6 2 0
/*     */     //   41: ifeq +6 -> 47
/*     */     //   44: aload_2
/*     */     //   45: monitorexit
/*     */     //   46: return
/*     */     //   47: aload_0
/*     */     //   48: invokestatic 7	com/ai/appframe2/bo/SysIdGeneratorEngine:getBeans	(Ljava/sql/Connection;)[Lcom/ai/appframe2/bo/SysIdGeneratorBean;
/*     */     //   51: astore_3
/*     */     //   52: aload_3
/*     */     //   53: ifnull +69 -> 122
/*     */     //   56: aload_3
/*     */     //   57: arraylength
/*     */     //   58: ifeq +64 -> 122
/*     */     //   61: iconst_0
/*     */     //   62: istore 4
/*     */     //   64: iload 4
/*     */     //   66: aload_3
/*     */     //   67: arraylength
/*     */     //   68: if_icmpge +54 -> 122
/*     */     //   71: getstatic 8	com/ai/appframe2/bo/IdGeneratorImpl:m_generators	Ljava/util/Map;
/*     */     //   74: new 9	java/lang/StringBuilder
/*     */     //   77: dup
/*     */     //   78: invokespecial 10	java/lang/StringBuilder:<init>	()V
/*     */     //   81: aload_1
/*     */     //   82: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   85: ldc 12
/*     */     //   87: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   90: aload_3
/*     */     //   91: iload 4
/*     */     //   93: aaload
/*     */     //   94: invokevirtual 13	com/ai/appframe2/bo/SysIdGeneratorBean:fetchTableName	()Ljava/lang/String;
/*     */     //   97: invokevirtual 4	java/lang/String:toUpperCase	()Ljava/lang/String;
/*     */     //   100: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   103: invokevirtual 14	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   106: aload_3
/*     */     //   107: iload 4
/*     */     //   109: aaload
/*     */     //   110: invokeinterface 15 3 0
/*     */     //   115: pop
/*     */     //   116: iinc 4 1
/*     */     //   119: goto -55 -> 64
/*     */     //   122: getstatic 5	com/ai/appframe2/bo/IdGeneratorImpl:m_hasInitialUser	Ljava/util/Map;
/*     */     //   125: aload_1
/*     */     //   126: aload_1
/*     */     //   127: invokeinterface 15 3 0
/*     */     //   132: pop
/*     */     //   133: goto +72 -> 205
/*     */     //   136: astore_3
/*     */     //   137: ldc 17
/*     */     //   139: invokestatic 18	com/ai/appframe2/util/locale/AppframeLocaleFactory:getResource	(Ljava/lang/String;)Ljava/lang/String;
/*     */     //   142: astore 4
/*     */     //   144: getstatic 19	com/ai/appframe2/bo/IdGeneratorImpl:log	Lorg/apache/commons/logging/Log;
/*     */     //   147: new 9	java/lang/StringBuilder
/*     */     //   150: dup
/*     */     //   151: invokespecial 10	java/lang/StringBuilder:<init>	()V
/*     */     //   154: ldc 20
/*     */     //   156: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   159: aload 4
/*     */     //   161: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   164: invokevirtual 14	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   167: aload_3
/*     */     //   168: invokeinterface 21 3 0
/*     */     //   173: new 22	java/lang/RuntimeException
/*     */     //   176: dup
/*     */     //   177: new 9	java/lang/StringBuilder
/*     */     //   180: dup
/*     */     //   181: invokespecial 10	java/lang/StringBuilder:<init>	()V
/*     */     //   184: ldc 20
/*     */     //   186: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   189: aload 4
/*     */     //   191: invokevirtual 11	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   194: aload_3
/*     */     //   195: invokevirtual 23	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*     */     //   198: invokevirtual 14	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   201: invokespecial 24	java/lang/RuntimeException:<init>	(Ljava/lang/String;)V
/*     */     //   204: athrow
/*     */     //   205: aload_2
/*     */     //   206: monitorexit
/*     */     //   207: goto +10 -> 217
/*     */     //   210: astore 5
/*     */     //   212: aload_2
/*     */     //   213: monitorexit
/*     */     //   214: aload 5
/*     */     //   216: athrow
/*     */     //   217: return
/*     */     //
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   32	44	136	java/lang/Throwable
/*     */     //   47	133	136	java/lang/Throwable
/*     */     //   32	46	210	finally
/*     */     //   47	207	210	finally
/*     */     //   210	214	210	finally } 
/*  55 */   private static SysIdGeneratorBean getInstance(String _TableName) { Connection conn = null;
/*     */     try {
/*  57 */       conn = ServiceManager.getSession().getConnection();
/*  58 */       SysIdGeneratorBean localSysIdGeneratorBean = getInstance(conn, _TableName);
/*     */ 
/*  66 */       return localSysIdGeneratorBean;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/*  63 */         conn.close();
/*     */       }
/*     */       catch (SQLException ex1) {
/*  66 */         throw new RuntimeException(ex1);
/*     */       }
/*     */     } }
/*     */ 
/*     */ 
/*     */   private static SysIdGeneratorBean getInstance(Connection conn, String _TableName)
/*     */     throws Exception
/*     */   {
/*  74 */     _TableName = _TableName.toUpperCase();
/*  75 */     init(conn);
/*  76 */     String userName = conn.getMetaData().getUserName();
/*  77 */     SysIdGeneratorBean result = (SysIdGeneratorBean)m_generators.get(userName + "." + _TableName);
/*     */ 
/*  79 */     if ((result == null) && (log.isDebugEnabled()))
/*     */     {
/*  81 */       log.debug(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_record"));
/*     */     }
/*  83 */     return result;
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(ObjectType type) throws AIException {
/*  87 */     if ((type instanceof ObjectTypeNull) || (type instanceof ObjectTypeSingleValue))
/*     */     {
/*  90 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.cannot_do", new String[] { type.getFullName() });
/*  91 */       throw new AIException(msg);
/*     */     }
/*  93 */     return getNewId(type.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(String tableName) throws AIException
/*     */   {
/*  98 */     BigDecimal result = null;
/*  99 */     String sql = "";
/* 100 */     SysIdGeneratorBean bean = null;
/*     */     try {
/* 102 */       if (StringUtils.isBlank(tableName))
/*     */       {
/* 104 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.talbe_name_null");
/* 105 */         throw new Exception(msg);
/*     */       }
/* 107 */       Connection connInstance = ServiceManager.getSession().getNewConnection();
/* 108 */       bean = getInstance(connInstance, tableName);
/* 109 */       connInstance.close();
/* 110 */       if (bean == null)
/*     */       {
/* 112 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_record", new String[] { tableName });
/* 113 */         throw new Exception(msg);
/*     */       }
/* 115 */       if (bean.getGeneratorType().equalsIgnoreCase("S")) {
/* 116 */         Connection conn = null;
/*     */         try {
/* 118 */           conn = ServiceManager.getSession().getNewConnection();
/* 119 */           result = new BigDecimal(DialectFactory.getDialect().getNewId(conn, bean.getSequenceName()));
/*     */         } finally {
/* 121 */           if (conn != null)
/* 122 */             conn.close();
/*     */         }
/*     */       }
/* 125 */       else if (bean.getGeneratorType().equalsIgnoreCase("M")) {
/* 126 */         sql = "select max_id + 1 as id from SYS_ID_GENERATOR where TABLE_NAME ='" + bean.fetchTableName() + "'";
/*     */ 
/* 128 */         String sql2 = "update SYS_ID_GENERATOR set max_id = max_id + 1 where TABLE_NAME ='" + bean.fetchTableName() + "'";
/*     */ 
/* 130 */         synchronized (bean.fetchTableName()) {
/* 131 */           String transactionName = ServiceManager.getSession().getCurrentTransactionName();
/* 132 */           ServiceManager.getSession().suspend();
/*     */           try {
/* 134 */             ServiceManager.getSession().startTransaction(transactionName);
/* 135 */             Connection conn = ServiceManager.getSession().getConnection();
/* 136 */             Statement stmt = conn.createStatement();
/* 137 */             ResultSet rowSet = stmt.executeQuery(sql);
/* 138 */             if (rowSet.next())
/* 139 */               result = rowSet.getBigDecimal("id");
/* 140 */             rowSet.close();
/* 141 */             stmt.execute(sql2);
/* 142 */             stmt.close();
/* 143 */             ServiceManager.getSession().commitTransaction();
/*     */           } finally {
/* 145 */             ServiceManager.getSession().resume();
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 150 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.not_support_pk_type", new String[] { bean.getGeneratorType() });
/* 151 */         throw new AIException(msg);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 155 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.pk_error", new String[] { tableName });
/* 156 */       throw new AIException(msg + e.getMessage(), e);
/*     */     }
/*     */ 
/* 159 */     return (BigDecimal)result;
/*     */   }
/*     */ 
/*     */   public boolean getHisDataFlag(String tableName)
/*     */   {
/* 164 */     boolean flag = false;
/* 165 */     SysIdGeneratorBean bean = getInstance(tableName);
/* 166 */     if (bean == null) {
/* 167 */       return false;
/*     */     }
/* 169 */     String his_flag = bean.getHisDataFlag();
/* 170 */     if ((his_flag != null) && (his_flag.equalsIgnoreCase("Y"))) {
/* 171 */       flag = true;
/*     */     }
/* 173 */     return flag;
/*     */   }
/*     */ 
/*     */   public boolean getHisDoneCodeFlag(String tableName)
/*     */   {
/* 179 */     boolean flag = false;
/* 180 */     SysIdGeneratorBean bean = getInstance(tableName);
/* 181 */     if (bean == null) {
/* 182 */       return false;
/*     */     }
/*     */ 
/* 185 */     String his_doneCode_flag = bean.getHisDonecodeFlag();
/* 186 */     if ((his_doneCode_flag != null) && (his_doneCode_flag.equalsIgnoreCase("Y"))) {
/* 187 */       flag = true;
/*     */     }
/* 189 */     return flag;
/*     */   }
/*     */ 
/*     */   public String getHisTableName(String tableName)
/*     */   {
/* 194 */     String hisTableName = null;
/* 195 */     SysIdGeneratorBean bean = getInstance(tableName);
/* 196 */     if (bean == null) {
/* 197 */       return null;
/*     */     }
/* 199 */     hisTableName = bean.getHisTableName();
/* 200 */     return hisTableName;
/*     */   }
/*     */ 
/*     */   public BigDecimal getHisTableNewId(ObjectType type) throws AIException
/*     */   {
/* 205 */     if ((type instanceof ObjectTypeNull) || (type instanceof ObjectTypeSingleValue))
/*     */     {
/* 208 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.cannot_do", new String[] { type.getFullName() });
/* 209 */       throw new AIException(msg);
/*     */     }
/* 211 */     return getHisTableNewId(type.getMapingEnty());
/*     */   }
/*     */ 
/*     */   public BigDecimal getHisTableNewId(String tableName) throws AIException
/*     */   {
/* 216 */     BigDecimal result = null;
/* 217 */     String sql = "";
/* 218 */     SysIdGeneratorBean bean = null;
/*     */     try {
/* 220 */       Connection connInstance = ServiceManager.getSession().getNewConnection();
/* 221 */       bean = getInstance(connInstance, tableName);
/* 222 */       connInstance.close();
/* 223 */       if (bean == null)
/*     */       {
/* 225 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_record", new String[] { tableName });
/* 226 */         throw new Exception(msg);
/*     */       }
/*     */ 
/* 229 */       if (bean.getGeneratorType().equalsIgnoreCase("S")) {
/* 230 */         Connection conn = null;
/*     */         try {
/* 232 */           conn = ServiceManager.getSession().getNewConnection();
/* 233 */           result = new BigDecimal(DialectFactory.getDialect().getNewId(conn, bean.getHisSequenceName()));
/* 234 */           Statement stmt = conn.createStatement();
/* 235 */           ResultSet rowSet = stmt.executeQuery(sql);
/* 236 */           if (rowSet.next())
/* 237 */             result = rowSet.getBigDecimal("id");
/* 238 */           rowSet.close();
/* 239 */           stmt.close();
/*     */         } finally {
/* 241 */           if (conn != null) {
/* 242 */             conn.close();
/*     */           }
/*     */         }
/*     */       }
/* 246 */       else if (bean.getGeneratorType().equalsIgnoreCase("M")) {
/* 247 */         sql = "select his_max_id + 1 as id from SYS_ID_GENERATOR where TABLE_NAME ='" + bean.fetchTableName() + "'";
/*     */ 
/* 249 */         String sql2 = "update SYS_ID_GENERATOR set his_max_id = his_max_id + 1 where TABLE_NAME ='" + bean.fetchTableName() + "'";
/*     */ 
/* 252 */         synchronized (bean.fetchTableName()) {
/* 253 */           String transactionName = ServiceManager.getSession().getCurrentTransactionName();
/* 254 */           ServiceManager.getSession().suspend();
/*     */           try {
/* 256 */             ServiceManager.getSession().startTransaction(transactionName);
/* 257 */             Connection conn = ServiceManager.getSession().getConnection();
/* 258 */             Statement stmt = conn.createStatement();
/* 259 */             ResultSet rowSet = stmt.executeQuery(sql);
/* 260 */             if (rowSet.next())
/* 261 */               result = rowSet.getBigDecimal("id");
/* 262 */             rowSet.close();
/* 263 */             stmt.execute(sql2);
/* 264 */             stmt.close();
/* 265 */             ServiceManager.getSession().commitTransaction();
/*     */           } finally {
/* 267 */             ServiceManager.getSession().resume();
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 272 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.not_support_pk_type", new String[] { bean.getGeneratorType() });
/* 273 */         throw new AIException(msg);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 278 */       String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.bak_pk_error", new String[] { tableName });
/* 279 */       throw new AIException(msg + e.getMessage(), e);
/*     */     }
/*     */ 
/* 282 */     return result;
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(ObjectType type) throws Exception {
/* 286 */     return getSysDate();
/*     */   }
/*     */   public Timestamp getSysDate() throws Exception {
/* 289 */     Timestamp result = null;
/* 290 */     Connection conn = null;
/*     */     try {
/* 292 */       result = new Timestamp(DialectFactory.getDialect().getSysDate(conn));
/*     */     }
/*     */     finally {
/* 295 */       if (conn != null) {
/* 296 */         conn.close();
/*     */       }
/*     */     }
/* 299 */     return result;
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(Connection conn, ObjectType type) throws Exception {
/* 303 */     return getNewId(type);
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(Connection conn, ObjectType type) throws Exception {
/* 307 */     return getSysDate(type);
/*     */   }
/*     */ 
/*     */   public BigDecimal getNewId(Connection conn, String tableName) throws Exception {
/* 311 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_implement"));
/*     */   }
/*     */ 
/*     */   public BigDecimal getDirectNewId(Connection conn, ObjectType type)
/*     */     throws Exception
/*     */   {
/* 322 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_implement"));
/*     */   }
/*     */ 
/*     */   public BigDecimal getDirectNewId(Connection conn, String tableName)
/*     */     throws Exception
/*     */   {
/* 334 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_implement"));
/*     */   }
/*     */ 
/*     */   public long getNewId(String dataSourceName, String tableName)
/*     */     throws Exception, RemoteException
/*     */   {
/* 347 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_implement"));
/*     */   }
/*     */ 
/*     */   public Timestamp getSysDate(String dataSourceName) throws Exception
/*     */   {
/* 352 */     throw new Exception(AppframeLocaleFactory.getResource("com.ai.appframe2.bo.IdGeneratorImpl.no_implement"));
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 358 */     IdGeneratorImpl idg = new IdGeneratorImpl();
/* 359 */     System.out.println(idg.getHisDoneCodeFlag("PARTY"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.IdGeneratorImpl
 * JD-Core Version:    0.5.4
 */