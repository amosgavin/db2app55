/*    */ package com.ai.appframe2.bo.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.Relation;
/*    */ 
/*    */ public class RelationImpl
/*    */   implements Relation
/*    */ {
/*    */   String m_name;
/*    */   String m_javaDataType;
/*    */   String m_childBoName;
/*    */   String m_condition;
/*    */   boolean m_isCollection;
/*    */ 
/*    */   public RelationImpl(String name, String javaDataType, String childBoName, String condition, boolean isCollection)
/*    */   {
/* 13 */     this.m_name = name;
/* 14 */     this.m_javaDataType = javaDataType;
/* 15 */     this.m_childBoName = childBoName;
/* 16 */     this.m_condition = condition;
/* 17 */     this.m_isCollection = isCollection;
/*    */   }
/*    */   public String getName() {
/* 20 */     return this.m_name;
/*    */   }
/*    */   public String getJavaDataType() {
/* 23 */     return this.m_javaDataType;
/*    */   }
/*    */   public String getChildBOName() {
/* 26 */     return this.m_childBoName;
/*    */   }
/*    */   public boolean isCollection() {
/* 29 */     return this.m_isCollection;
/*    */   }
/*    */   public String getRelationCondition() {
/* 32 */     return this.m_condition;
/*    */   }
/*    */   public String toString() {
/* 35 */     return this.m_name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.RelationImpl
 * JD-Core Version:    0.5.4
 */