/*     */ package com.ai.appframe2.bo.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.Operator;
/*     */ import com.ai.appframe2.common.Property;
/*     */ import com.ai.appframe2.common.Relation;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ 
/*     */ public abstract class DefaultObjectType
/*     */   implements ObjectType
/*     */ {
/*     */   protected String m_fullName;
/*     */   protected String m_name;
/*     */   protected String m_dataSource;
/*     */   protected String m_tableName;
/*     */   protected String m_className;
/*     */   protected String m_MainAttr;
/*     */   protected String m_mapingEntyType;
/*     */   protected String m_dataFilter;
/*     */   protected HashMap m_keys;
/*     */   protected HashMap m_propertys;
/*     */   protected HashMap m_operators;
/*     */   protected HashMap m_relations;
/*     */   protected HashMap m_managerOperators;
/*     */ 
/*     */   public DefaultObjectType()
/*     */   {
/*  22 */     this.m_keys = new HashMap();
/*  23 */     this.m_propertys = new HashMap();
/*  24 */     this.m_operators = new HashMap();
/*  25 */     this.m_relations = new HashMap();
/*     */ 
/*  28 */     this.m_managerOperators = new HashMap();
/*     */   }
/*     */   public String getFullName() {
/*  31 */     return this.m_fullName;
/*     */   }
/*     */   public String getName() {
/*  34 */     return this.m_name;
/*     */   }
/*     */   public String getClassName() {
/*  37 */     return this.m_className;
/*     */   }
/*     */   public String getDataFilter() {
/*  40 */     return this.m_dataFilter;
/*     */   }
/*     */ 
/*     */   public String getMainAttr() {
/*  44 */     if (this.m_MainAttr == "")
/*  45 */       return null;
/*  46 */     return this.m_MainAttr;
/*     */   }
/*     */   public String getMapingEnty() throws AIException {
/*  49 */     return this.m_tableName;
/*     */   }
/*     */   public String getMapingEntyType() {
/*  52 */     return this.m_mapingEntyType;
/*     */   }
/*     */   public String getDataSource() {
/*  55 */     return this.m_dataSource;
/*     */   }
/*     */   public boolean isKeyProperty(String p) {
/*  58 */     return this.m_keys.containsKey(p.toUpperCase());
/*     */   }
/*     */   public HashMap getKeyProperties() {
/*  61 */     return this.m_keys;
/*     */   }
/*     */   public String[] getPropertyNames() {
/*  64 */     return (String[])(String[])this.m_propertys.keySet().toArray(new String[0]);
/*     */   }
/*     */   public HashMap getProperties() {
/*  67 */     return this.m_propertys;
/*     */   }
/*     */ 
/*     */   public HashMap getRelations() {
/*  71 */     return this.m_relations;
/*     */   }
/*     */   public HashMap getOperators() {
/*  74 */     return this.m_operators;
/*     */   }
/*     */   public boolean hasRelation(String name) {
/*  77 */     return this.m_relations.containsKey(name.toUpperCase());
/*     */   }
/*     */   public Relation getRelation(String name) {
/*  80 */     return (Relation)this.m_relations.get(name.toUpperCase());
/*     */   }
/*     */   public boolean hasProperty(String name) {
/*  83 */     name = name.toUpperCase();
/*  84 */     return (this.m_keys.containsKey(name)) || (this.m_propertys.containsKey(name));
/*     */   }
/*     */   public Property getProperty(String name) {
/*  87 */     name = name.toUpperCase();
/*  88 */     if (this.m_keys.containsKey(name))
/*  89 */       return (Property)this.m_keys.get(name);
/*  90 */     if (this.m_propertys.containsKey(name)) {
/*  91 */       return (Property)this.m_propertys.get(name);
/*     */     }
/*  93 */     return null;
/*     */   }
/*     */   public Operator getOperator(String name) {
/*  96 */     Object obj = this.m_operators.get(name.toUpperCase());
/*  97 */     return (Operator)obj;
/*     */   }
/*     */   public boolean hasOperator(String name) {
/* 100 */     return this.m_operators.containsKey(name.toUpperCase());
/*     */   }
/*     */ 
/*     */   public String debug() {
/* 104 */     String keyProp = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.key_prop");
/* 105 */     String propertyInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.property");
/* 106 */     String relationInfo = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.reference_obj");
/*     */ 
/* 108 */     String result = "ObjectType:" + getFullName() + "\n " + keyProp + ":\n";
/* 109 */     for (Iterator it = this.m_keys.values().iterator(); it.hasNext(); ) {
/* 110 */       result = result + ((Property)it.next()).toString() + "\n";
/*     */     }
/* 112 */     result = result + propertyInfo + ":\n";
/* 113 */     for (Iterator it = this.m_propertys.values().iterator(); it.hasNext(); )
/* 114 */       result = result + ((Property)it.next()).toString() + "\n";
/* 115 */     result = result + relationInfo + ":\n";
/* 116 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.DefaultObjectType
 * JD-Core Version:    0.5.4
 */