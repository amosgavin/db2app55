/*    */ package com.ai.appframe2.bo.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.ParameterType;
/*    */ 
/*    */ public class ParameterTypeImpl
/*    */   implements ParameterType
/*    */ {
/*    */   String m_name;
/*    */   String m_javaDataType;
/*    */   String m_type;
/*    */   String m_value;
/*    */   String m_remark;
/*    */ 
/*    */   public ParameterTypeImpl(String name, String type, String javaDataType, String value, String remark)
/*    */   {
/* 14 */     this.m_name = name;
/* 15 */     this.m_type = type;
/* 16 */     this.m_javaDataType = javaDataType;
/* 17 */     this.m_value = value;
/* 18 */     this.m_remark = remark;
/*    */   }
/*    */   public String getName() {
/* 21 */     return this.m_name;
/*    */   }
/*    */   public String getJavaDataType() {
/* 24 */     return this.m_javaDataType;
/*    */   }
/*    */   public String getType() {
/* 27 */     return this.m_type;
/*    */   }
/*    */   public String getValue() {
/* 30 */     return this.m_value;
/*    */   }
/*    */   public String getRemark() {
/* 33 */     return this.m_remark;
/*    */   }
/*    */   public String toString() {
/* 36 */     return this.m_name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.ParameterTypeImpl
 * JD-Core Version:    0.5.4
 */