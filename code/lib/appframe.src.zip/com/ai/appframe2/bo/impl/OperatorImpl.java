/*    */ package com.ai.appframe2.bo.impl;
/*    */ 
/*    */ import com.ai.appframe2.common.Operator;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class OperatorImpl
/*    */   implements Operator
/*    */ {
/*    */   String m_name;
/*    */   String m_opType;
/*    */   String m_remark;
/*    */   String m_resultDataType;
/*    */   String[] m_commands;
/*    */   HashMap m_parameters;
/*    */   boolean m_isCollection;
/*    */ 
/*    */   public OperatorImpl(String name, String type, String remark, String resultDataType, String[] commands, HashMap parameterTypes, boolean isCollection)
/*    */   {
/* 17 */     this.m_name = name;
/* 18 */     this.m_opType = type;
/* 19 */     this.m_remark = remark;
/* 20 */     this.m_resultDataType = resultDataType;
/* 21 */     this.m_commands = commands;
/* 22 */     this.m_parameters = parameterTypes;
/* 23 */     this.m_isCollection = isCollection;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 27 */     return this.m_name;
/*    */   }
/*    */   public String getOperationType() {
/* 30 */     return this.m_opType;
/*    */   }
/*    */   public String getCommandRemark() {
/* 33 */     return this.m_remark;
/*    */   }
/*    */   public String[] getCommandArray() {
/* 36 */     return this.m_commands;
/*    */   }
/*    */   public HashMap getParameterTypes() {
/* 39 */     return this.m_parameters;
/*    */   }
/*    */   public String getResultDataType() {
/* 42 */     return this.m_resultDataType;
/*    */   }
/*    */ 
/*    */   public boolean isCollectionOfResult() {
/* 46 */     return this.m_isCollection;
/*    */   }
/*    */   public String toString() {
/* 49 */     return this.m_name;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.OperatorImpl
 * JD-Core Version:    0.5.4
 */