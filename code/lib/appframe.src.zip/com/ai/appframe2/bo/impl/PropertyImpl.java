/*     */ package com.ai.appframe2.bo.impl;
/*     */ 
/*     */ import com.ai.appframe2.common.Property;
/*     */ 
/*     */ public class PropertyImpl
/*     */   implements Property
/*     */ {
/*   8 */   String m_name = "";
/*   9 */   String m_type = "COL";
/*  10 */   String m_mapingColName = "";
/*  11 */   String m_javaDataType = "String";
/*  12 */   String m_databaseDataType = "VARCHAR2";
/*  13 */   int m_maxLength = 10;
/*  14 */   int m_floatLength = 0;
/*  15 */   String m_defaultValue = "";
/*  16 */   String m_remark = "";
/*  17 */   String m_relationObjectTypeName = "";
/*  18 */   String m_relationCondition = "";
/*     */   String[] m_displayColNames;
/*     */ 
/*     */   public PropertyImpl(String name, String type, String mapingColName, String javaDataType, String databaseDataType, int maxLength, int floatLength, String defaultValue, String remark, String relationObjectTypeName, String relationCondition, String[] displayColNames)
/*     */   {
/*  25 */     this.m_name = name;
/*  26 */     this.m_type = type;
/*  27 */     this.m_mapingColName = mapingColName;
/*  28 */     this.m_javaDataType = javaDataType;
/*  29 */     this.m_databaseDataType = databaseDataType;
/*  30 */     this.m_maxLength = maxLength;
/*  31 */     this.m_floatLength = floatLength;
/*  32 */     this.m_defaultValue = defaultValue;
/*  33 */     this.m_remark = remark;
/*  34 */     this.m_relationObjectTypeName = relationObjectTypeName;
/*  35 */     this.m_relationCondition = relationCondition;
/*  36 */     this.m_displayColNames = displayColNames;
/*     */   }
/*     */ 
/*     */   public PropertyImpl(String name, String javaDataType) {
/*  40 */     this.m_name = name;
/*  41 */     this.m_javaDataType = javaDataType;
/*     */   }
/*     */   public String getType() {
/*  44 */     return this.m_type;
/*     */   }
/*     */   public String getMapingColName() {
/*  47 */     return this.m_mapingColName;
/*     */   }
/*     */ 
/*     */   public String getRelationObjectTypeName() {
/*  51 */     return this.m_relationObjectTypeName;
/*     */   }
/*     */   public String getRelationCondition() {
/*  54 */     return this.m_relationCondition;
/*     */   }
/*     */ 
/*     */   public String getJavaDataType() {
/*  58 */     return this.m_javaDataType;
/*     */   }
/*     */   public int getMaxLength() {
/*  61 */     return this.m_maxLength;
/*     */   }
/*     */   public String getDatabaseDataType() {
/*  64 */     return this.m_databaseDataType;
/*     */   }
/*     */   public boolean isCollection() {
/*  67 */     return false;
/*     */   }
/*     */   public String getDefaultValue() {
/*  70 */     return this.m_defaultValue;
/*     */   }
/*     */ 
/*     */   public int getFloatLength() {
/*  74 */     return this.m_floatLength;
/*     */   }
/*     */   public String getName() {
/*  77 */     return this.m_name;
/*     */   }
/*     */   public String getRemark() {
/*  80 */     return this.m_remark;
/*     */   }
/*     */ 
/*     */   public String[] getDisplayColNames() {
/*  84 */     if (this.m_displayColNames == null) {
/*  85 */       return new String[0];
/*     */     }
/*  87 */     return this.m_displayColNames;
/*     */   }
/*     */   public String toString() {
/*  90 */     return this.m_name;
/*     */   }
/*     */ 
/*     */   public String getRelationObjectTypeOutJoin()
/*     */   {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean hasAlias() {
/* 101 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.PropertyImpl
 * JD-Core Version:    0.5.4
 */