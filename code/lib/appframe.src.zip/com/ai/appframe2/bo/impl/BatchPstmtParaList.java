/*    */ package com.ai.appframe2.bo.impl;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class BatchPstmtParaList
/*    */ {
/* 13 */   private List keys = new ArrayList();
/*    */ 
/* 15 */   private List types = new ArrayList();
/*    */ 
/* 17 */   private List values = new ArrayList();
/*    */ 
/*    */   public void add(String pKey, String pType, Object pValue)
/*    */   {
/* 23 */     this.types.add(pType);
/* 24 */     this.values.add(pValue);
/* 25 */     this.keys.add(pKey);
/*    */   }
/*    */ 
/*    */   public List getTypes()
/*    */   {
/* 31 */     return this.types;
/*    */   }
/*    */ 
/*    */   public List getValues()
/*    */   {
/* 38 */     return this.values;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.impl.BatchPstmtParaList
 * JD-Core Version:    0.5.4
 */