/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.DataType;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import java.sql.Connection;
/*     */ 
/*     */ public class SysIdGeneratorBean extends DataContainer
/*     */   implements DataContainerInterface
/*     */ {
/*  16 */   private static String m_boName = "com.ai.appframe2.bo.SysIdGenerator";
/*     */   public static final String S_DomainId = "DOMAIN_ID";
/*     */   public static final String S_StartValue = "START_VALUE";
/*     */   public static final String S_HisDonecodeFlag = "HIS_DONECODE_FLAG";
/*     */   public static final String S_CycleFlag = "CYCLE_FLAG";
/*     */   public static final String S_HisDataFlag = "HIS_DATA_FLAG";
/*     */   public static final String S_MaxValue = "MAX_VALUE";
/*     */   public static final String S_TableName = "TABLE_NAME";
/*     */   public static final String S_SequenceName = "SEQUENCE_NAME";
/*     */   public static final String S_HisMaxId = "HIS_MAX_ID";
/*     */   public static final String S_SequenceCreateScript = "SEQUENCE_CREATE_SCRIPT";
/*     */   public static final String S_GeneratorType = "GENERATOR_TYPE";
/*     */   public static final String S_MaxId = "MAX_ID";
/*     */   public static final String S_HisSequenceName = "HIS_SEQUENCE_NAME";
/*     */   public static final String S_HisTableName = "HIS_TABLE_NAME";
/*     */   public static final String S_IncrementValue = "INCREMENT_VALUE";
/*     */   public static final String S_MinValue = "MIN_VALUE";
/*     */   public static final String S_CacheSize = "CACHE_SIZE";
/*     */ 
/*     */   public SysIdGeneratorBean()
/*     */     throws AIException
/*     */   {
/*  36 */     super(ServiceManager.getObjectTypeFactory().getInstance(m_boName));
/*     */   }
/*     */ 
/*     */   public static ObjectType getObjectTypeStatic() throws AIException {
/*  40 */     return ServiceManager.getObjectTypeFactory().getInstance(m_boName);
/*     */   }
/*     */ 
/*     */   public void setObjectType(ObjectType value) throws AIException
/*     */   {
/*  45 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.bo.SysIdGeneratorBean.cannot_reset");
/*  46 */     throw new AIException(msg);
/*     */   }
/*     */ 
/*     */   public void initDomainId(long value) {
/*     */     try {
/*  51 */       initProperty("DOMAIN_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/*  54 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDomainId(long value) {
/*     */     try {
/*  60 */       set("DOMAIN_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/*  63 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDomainIdNull() {
/*     */     try {
/*  69 */       set("DOMAIN_ID", null);
/*     */     }
/*     */     catch (Exception e) {
/*  72 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getDomainId() {
/*  77 */     return DataType.getAsLong(get("DOMAIN_ID"));
/*     */   }
/*     */ 
/*     */   public long getDomainIdInitialValue() {
/*  81 */     return DataType.getAsLong(getOldObj("DOMAIN_ID"));
/*     */   }
/*     */ 
/*     */   public void initStartValue(long value) {
/*  85 */     initProperty("START_VALUE", new Long(value));
/*     */   }
/*     */ 
/*     */   public void setStartValue(long value) {
/*  89 */     set("START_VALUE", new Long(value));
/*     */   }
/*     */ 
/*     */   public void setStartValueNull() {
/*  93 */     set("START_VALUE", null);
/*     */   }
/*     */ 
/*     */   public long getStartValue() {
/*  97 */     return DataType.getAsLong(get("START_VALUE"));
/*     */   }
/*     */ 
/*     */   public long getStartValueInitialValue() {
/* 101 */     return DataType.getAsLong(getOldObj("START_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initHisDonecodeFlag(String value) {
/* 105 */     initProperty("HIS_DONECODE_FLAG", value);
/*     */   }
/*     */ 
/*     */   public void setHisDonecodeFlag(String value) {
/* 109 */     set("HIS_DONECODE_FLAG", value);
/*     */   }
/*     */ 
/*     */   public void setHisDonecodeFlagNull() {
/* 113 */     set("HIS_DONECODE_FLAG", null);
/*     */   }
/*     */ 
/*     */   public String getHisDonecodeFlag() {
/* 117 */     return DataType.getAsString(get("HIS_DONECODE_FLAG"));
/*     */   }
/*     */ 
/*     */   public String getHisDonecodeFlagInitialValue()
/*     */   {
/* 122 */     return DataType.getAsString(getOldObj("HIS_DONECODE_FLAG"));
/*     */   }
/*     */ 
/*     */   public void initCycleFlag(String value) {
/*     */     try {
/* 127 */       initProperty("CYCLE_FLAG", value);
/*     */     }
/*     */     catch (Exception e) {
/* 130 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCycleFlag(String value) {
/*     */     try {
/* 136 */       set("CYCLE_FLAG", value);
/*     */     }
/*     */     catch (Exception e) {
/* 139 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCycleFlagNull() {
/*     */     try {
/* 145 */       set("CYCLE_FLAG", null);
/*     */     }
/*     */     catch (Exception e) {
/* 148 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getCycleFlag() {
/* 153 */     return DataType.getAsString(get("CYCLE_FLAG"));
/*     */   }
/*     */ 
/*     */   public String getCycleFlagInitialValue()
/*     */   {
/* 158 */     return DataType.getAsString(getOldObj("CYCLE_FLAG"));
/*     */   }
/*     */ 
/*     */   public void initHisDataFlag(String value) {
/*     */     try {
/* 163 */       initProperty("HIS_DATA_FLAG", value);
/*     */     }
/*     */     catch (Exception e) {
/* 166 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisDataFlag(String value) {
/*     */     try {
/* 172 */       set("HIS_DATA_FLAG", value);
/*     */     }
/*     */     catch (Exception e) {
/* 175 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisDataFlagNull() {
/*     */     try {
/* 181 */       set("HIS_DATA_FLAG", null);
/*     */     }
/*     */     catch (Exception e) {
/* 184 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getHisDataFlag() {
/* 189 */     return DataType.getAsString(get("HIS_DATA_FLAG"));
/*     */   }
/*     */ 
/*     */   public String getHisDataFlagInitialValue()
/*     */   {
/* 194 */     return DataType.getAsString(getOldObj("HIS_DATA_FLAG"));
/*     */   }
/*     */ 
/*     */   public void initMaxValue(long value) {
/*     */     try {
/* 199 */       initProperty("MAX_VALUE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 202 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxValue(long value) {
/*     */     try {
/* 208 */       set("MAX_VALUE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 211 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxValueNull() {
/*     */     try {
/* 217 */       set("MAX_VALUE", null);
/*     */     }
/*     */     catch (Exception e) {
/* 220 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getMaxValue() {
/* 225 */     return DataType.getAsLong(get("MAX_VALUE"));
/*     */   }
/*     */ 
/*     */   public long getMaxValueInitialValue() {
/* 229 */     return DataType.getAsLong(getOldObj("MAX_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initTableName(String value) {
/* 233 */     initProperty("TABLE_NAME", value);
/*     */   }
/*     */ 
/*     */   public void setTableName(String value) {
/* 237 */     set("TABLE_NAME", value);
/*     */   }
/*     */ 
/*     */   public void setTableNameNull() {
/* 241 */     set("TABLE_NAME", null);
/*     */   }
/*     */ 
/*     */   public String fetchTableName() {
/* 245 */     return DataType.getAsString(get("TABLE_NAME"));
/*     */   }
/*     */ 
/*     */   public String getTableNameInitialValue()
/*     */   {
/* 250 */     return DataType.getAsString(getOldObj("TABLE_NAME"));
/*     */   }
/*     */ 
/*     */   public void initSequenceName(String value) {
/*     */     try {
/* 255 */       initProperty("SEQUENCE_NAME", value);
/*     */     }
/*     */     catch (Exception e) {
/* 258 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSequenceName(String value) {
/*     */     try {
/* 264 */       set("SEQUENCE_NAME", value);
/*     */     }
/*     */     catch (Exception e) {
/* 267 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSequenceNameNull() {
/*     */     try {
/* 273 */       set("SEQUENCE_NAME", null);
/*     */     }
/*     */     catch (Exception e) {
/* 276 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSequenceName() {
/* 281 */     return DataType.getAsString(get("SEQUENCE_NAME"));
/*     */   }
/*     */ 
/*     */   public String getSequenceNameInitialValue()
/*     */   {
/* 286 */     return DataType.getAsString(getOldObj("SEQUENCE_NAME"));
/*     */   }
/*     */ 
/*     */   public void initHisMaxId(long value) {
/*     */     try {
/* 291 */       initProperty("HIS_MAX_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 294 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisMaxId(long value) {
/*     */     try {
/* 300 */       set("HIS_MAX_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 303 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisMaxIdNull() {
/*     */     try {
/* 309 */       set("HIS_MAX_ID", null);
/*     */     }
/*     */     catch (Exception e) {
/* 312 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getHisMaxId() {
/* 317 */     return DataType.getAsLong(get("HIS_MAX_ID"));
/*     */   }
/*     */ 
/*     */   public long getHisMaxIdInitialValue() {
/* 321 */     return DataType.getAsLong(getOldObj("HIS_MAX_ID"));
/*     */   }
/*     */ 
/*     */   public void initSequenceCreateScript(String value) {
/* 325 */     initProperty("SEQUENCE_CREATE_SCRIPT", value);
/*     */   }
/*     */ 
/*     */   public void setSequenceCreateScript(String value) {
/* 329 */     set("SEQUENCE_CREATE_SCRIPT", value);
/*     */   }
/*     */ 
/*     */   public void setSequenceCreateScriptNull() {
/* 333 */     set("SEQUENCE_CREATE_SCRIPT", null);
/*     */   }
/*     */ 
/*     */   public String getSequenceCreateScript() {
/* 337 */     return DataType.getAsString(get("SEQUENCE_CREATE_SCRIPT"));
/*     */   }
/*     */ 
/*     */   public String getSequenceCreateScriptInitialValue() {
/* 341 */     return DataType.getAsString(getOldObj("SEQUENCE_CREATE_SCRIPT"));
/*     */   }
/*     */ 
/*     */   public void initGeneratorType(String value) {
/* 345 */     initProperty("GENERATOR_TYPE", value);
/*     */   }
/*     */ 
/*     */   public void setGeneratorType(String value) {
/* 349 */     set("GENERATOR_TYPE", value);
/*     */   }
/*     */ 
/*     */   public void setGeneratorTypeNull() {
/*     */     try {
/* 354 */       set("GENERATOR_TYPE", null);
/*     */     }
/*     */     catch (Exception e) {
/* 357 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getGeneratorType() {
/* 362 */     return DataType.getAsString(get("GENERATOR_TYPE"));
/*     */   }
/*     */ 
/*     */   public String getGeneratorTypeInitialValue()
/*     */   {
/* 367 */     return DataType.getAsString(getOldObj("GENERATOR_TYPE"));
/*     */   }
/*     */ 
/*     */   public void initMaxId(long value) {
/*     */     try {
/* 372 */       initProperty("MAX_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 375 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxId(long value) {
/*     */     try {
/* 381 */       set("MAX_ID", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 384 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMaxIdNull() {
/*     */     try {
/* 390 */       set("MAX_ID", null);
/*     */     }
/*     */     catch (Exception e) {
/* 393 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getMaxId() {
/* 398 */     return DataType.getAsLong(get("MAX_ID"));
/*     */   }
/*     */ 
/*     */   public long getMaxIdInitialValue() {
/* 402 */     return DataType.getAsLong(getOldObj("MAX_ID"));
/*     */   }
/*     */ 
/*     */   public void initHisSequenceName(String value) {
/* 406 */     initProperty("HIS_SEQUENCE_NAME", value);
/*     */   }
/*     */ 
/*     */   public void setHisSequenceName(String value) {
/* 410 */     set("HIS_SEQUENCE_NAME", value);
/*     */   }
/*     */ 
/*     */   public void setHisSequenceNameNull() {
/* 414 */     set("HIS_SEQUENCE_NAME", null);
/*     */   }
/*     */ 
/*     */   public String getHisSequenceName() {
/* 418 */     return DataType.getAsString(get("HIS_SEQUENCE_NAME"));
/*     */   }
/*     */ 
/*     */   public String getHisSequenceNameInitialValue() {
/* 422 */     return DataType.getAsString(getOldObj("HIS_SEQUENCE_NAME"));
/*     */   }
/*     */ 
/*     */   public void initHisTableName(String value) {
/*     */     try {
/* 427 */       initProperty("HIS_TABLE_NAME", value);
/*     */     }
/*     */     catch (Exception e) {
/* 430 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisTableName(String value) {
/*     */     try {
/* 436 */       set("HIS_TABLE_NAME", value);
/*     */     }
/*     */     catch (Exception e) {
/* 439 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setHisTableNameNull() {
/*     */     try {
/* 445 */       set("HIS_TABLE_NAME", null);
/*     */     }
/*     */     catch (Exception e) {
/* 448 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getHisTableName() {
/* 453 */     return DataType.getAsString(get("HIS_TABLE_NAME"));
/*     */   }
/*     */ 
/*     */   public String getHisTableNameInitialValue()
/*     */   {
/* 458 */     return DataType.getAsString(getOldObj("HIS_TABLE_NAME"));
/*     */   }
/*     */ 
/*     */   public void initIncrementValue(long value) {
/*     */     try {
/* 463 */       initProperty("INCREMENT_VALUE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 466 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setIncrementValue(long value) {
/*     */     try {
/* 472 */       set("INCREMENT_VALUE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 475 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setIncrementValueNull() {
/*     */     try {
/* 481 */       set("INCREMENT_VALUE", null);
/*     */     }
/*     */     catch (Exception e) {
/* 484 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getIncrementValue() {
/* 489 */     return DataType.getAsLong(get("INCREMENT_VALUE"));
/*     */   }
/*     */ 
/*     */   public long getIncrementValueInitialValue() {
/* 493 */     return DataType.getAsLong(getOldObj("INCREMENT_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initMinValue(long value) {
/* 497 */     initProperty("MIN_VALUE", new Long(value));
/*     */   }
/*     */ 
/*     */   public void setMinValue(long value) {
/* 501 */     set("MIN_VALUE", new Long(value));
/*     */   }
/*     */ 
/*     */   public void setMinValueNull() {
/* 505 */     set("MIN_VALUE", null);
/*     */   }
/*     */ 
/*     */   public long getMinValue() {
/* 509 */     return DataType.getAsLong(get("MIN_VALUE"));
/*     */   }
/*     */ 
/*     */   public long getMinValueInitialValue() {
/* 513 */     return DataType.getAsLong(getOldObj("MIN_VALUE"));
/*     */   }
/*     */ 
/*     */   public void initCacheSize(long value) {
/*     */     try {
/* 518 */       initProperty("CACHE_SIZE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 521 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCacheSize(long value) {
/*     */     try {
/* 527 */       set("CACHE_SIZE", new Long(value));
/*     */     }
/*     */     catch (Exception e) {
/* 530 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCacheSizeNull() {
/*     */     try {
/* 536 */       set("CACHE_SIZE", null);
/*     */     }
/*     */     catch (Exception e) {
/* 539 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getCacheSize() {
/* 544 */     return DataType.getAsLong(get("CACHE_SIZE"));
/*     */   }
/*     */ 
/*     */   public long getCacheSizeInitialValue()
/*     */   {
/* 549 */     return DataType.getAsLong(getOldObj("CACHE_SIZE"));
/*     */   }
/*     */ 
/*     */   public void save() throws Exception
/*     */   {
/* 554 */     Connection conn = null;
/*     */     try {
/* 556 */       conn = ServiceManager.getSession().getConnection();
/* 557 */       ServiceManager.getDataStore().save(conn, this);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally {
/* 563 */       conn.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.SysIdGeneratorBean
 * JD-Core Version:    0.5.4
 */