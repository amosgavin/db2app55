/*     */ package com.ai.appframe2.bo;
/*     */ 
/*     */ import com.ai.appframe2.common.AIException;
/*     */ import com.ai.appframe2.common.DataContainerInterface;
/*     */ import com.ai.appframe2.common.DataStore;
/*     */ import com.ai.appframe2.common.IdGenerator;
/*     */ import com.ai.appframe2.common.ObjectType;
/*     */ import com.ai.appframe2.common.ObjectTypeFactory;
/*     */ import com.ai.appframe2.common.ServiceManager;
/*     */ import com.ai.appframe2.common.Session;
/*     */ import com.ai.appframe2.util.criteria.Criteria;
/*     */ import com.ai.appframe2.util.criteria.UniqueList;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class SysIdGeneratorEngine
/*     */ {
/*     */   public static SysIdGeneratorBean[] getBeans(DataContainerInterface dc)
/*     */     throws Exception
/*     */   {
/*  20 */     Map ps = dc.getProperties();
/*  21 */     StringBuilder buffer = new StringBuilder();
/*  22 */     Map pList = new HashMap();
/*  23 */     for (Iterator cc = ps.entrySet().iterator(); cc.hasNext(); ) {
/*  24 */       e = (Map.Entry)cc.next();
/*  25 */       if (buffer.length() > 0)
/*  26 */         buffer.append(" and ");
/*  27 */       buffer.append(e.getKey().toString() + " = :p_" + e.getKey().toString());
/*  28 */       pList.put("p_" + e.getKey().toString(), e.getValue());
/*     */     }
/*     */     Map.Entry e;
/*  30 */     Connection conn = ServiceManager.getSession().getConnection();
/*     */     try {
/*  32 */       e = getBeans(buffer.toString(), pList);
/*     */ 
/*  35 */       return e;
/*     */     }
/*     */     finally
/*     */     {
/*  34 */       if (conn != null)
/*  35 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean getBean(String _TableName) throws Exception {
/*  40 */     String condition = "TABLE_NAME = :tableName  ";
/*  41 */     Map map = new HashMap();
/*  42 */     map.put("tableName", _TableName);
/*  43 */     SysIdGeneratorBean[] beans = getBeans(condition, map);
/*  44 */     if ((beans != null) && (beans.length == 1))
/*  45 */       return beans[0];
/*  46 */     if ((beans != null) && (beans.length > 1)) {
/*  47 */       throw new Exception("[ERROR]more datas than one queryed by PK");
/*     */     }
/*  49 */     SysIdGeneratorBean bean = new SysIdGeneratorBean();
/*  50 */     bean.setTableName(_TableName);
/*  51 */     return bean;
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeans(Connection conn) throws Exception
/*     */   {
/*  56 */     return (SysIdGeneratorBean[])(SysIdGeneratorBean[])ServiceManager.getDataStore().retrieve(conn, SysIdGeneratorBean.class, SysIdGeneratorBean.getObjectTypeStatic(), null, "", null, -1, -1, false, false, null);
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeans(Criteria sql)
/*     */     throws Exception
/*     */   {
/*  62 */     return getBeans(sql, -1, -1, false);
/*     */   }
/*     */   public static SysIdGeneratorBean[] getBeans(Criteria sql, int startNum, int endNum, boolean isShowFK) throws Exception {
/*  65 */     String[] cols = null;
/*  66 */     String condition = "";
/*  67 */     if (sql != null) {
/*  68 */       cols = (String[])(String[])sql.getSelectColumns().toArray(new String[0]);
/*  69 */       condition = sql.toString();
/*     */     }
/*  71 */     return (SysIdGeneratorBean[])getBeans(cols, condition, null, startNum, endNum, isShowFK);
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeans(String condition, Map parameter)
/*     */     throws Exception
/*     */   {
/*  78 */     return getBeans(null, condition, parameter, -1, -1, false);
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK) throws Exception
/*     */   {
/*  83 */     Connection conn = null;
/*     */     try {
/*  85 */       conn = ServiceManager.getSession().getConnection();
/*  86 */       SysIdGeneratorBean[] arrayOfSysIdGeneratorBean = (SysIdGeneratorBean[])(SysIdGeneratorBean[])ServiceManager.getDataStore().retrieve(conn, SysIdGeneratorBean.class, SysIdGeneratorBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, null);
/*     */ 
/*  91 */       return arrayOfSysIdGeneratorBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/*  90 */       if (conn != null)
/*  91 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeans(String[] cols, String condition, Map parameter, int startNum, int endNum, boolean isShowFK, String[] extendBOAttrs) throws Exception
/*     */   {
/*  97 */     Connection conn = null;
/*     */     try {
/*  99 */       conn = ServiceManager.getSession().getConnection();
/* 100 */       SysIdGeneratorBean[] arrayOfSysIdGeneratorBean = (SysIdGeneratorBean[])(SysIdGeneratorBean[])ServiceManager.getDataStore().retrieve(conn, SysIdGeneratorBean.class, SysIdGeneratorBean.getObjectTypeStatic(), cols, condition, parameter, startNum, endNum, isShowFK, false, extendBOAttrs);
/*     */ 
/* 105 */       return arrayOfSysIdGeneratorBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 104 */       if (conn != null)
/* 105 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter) throws Exception
/*     */   {
/* 111 */     Connection conn = null;
/*     */     try {
/* 113 */       conn = ServiceManager.getSession().getConnection();
/* 114 */       int i = ServiceManager.getDataStore().retrieveCount(conn, SysIdGeneratorBean.getObjectTypeStatic(), condition, parameter, null);
/*     */ 
/* 119 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 118 */       if (conn != null)
/* 119 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int getBeansCount(String condition, Map parameter, String[] extendBOAttrs) throws Exception {
/* 124 */     Connection conn = null;
/*     */     try {
/* 126 */       conn = ServiceManager.getSession().getConnection();
/* 127 */       int i = ServiceManager.getDataStore().retrieveCount(conn, SysIdGeneratorBean.getObjectTypeStatic(), condition, parameter, extendBOAttrs);
/*     */ 
/* 132 */       return i;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 131 */       if (conn != null)
/* 132 */         conn.close(); 
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void save(SysIdGeneratorBean[] aBeans) throws Exception {
/* 136 */     Connection conn = null;
/*     */     try {
/* 138 */       conn = ServiceManager.getSession().getConnection();
/* 139 */       ServiceManager.getDataStore().save(conn, aBeans);
/*     */     } catch (Exception e) {
/*     */     }
/*     */     finally {
/* 143 */       if (conn != null)
/* 144 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeansFromQueryBO(String soureBO, Map parameter) throws Exception
/*     */   {
/* 150 */     Connection conn = null;
/* 151 */     ResultSet resultset = null;
/*     */     try {
/* 153 */       conn = ServiceManager.getSession().getConnection();
/* 154 */       String sql = ServiceManager.getObjectTypeFactory().getInstance(soureBO).getMapingEnty();
/* 155 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 156 */       SysIdGeneratorBean[] arrayOfSysIdGeneratorBean = (SysIdGeneratorBean[])(SysIdGeneratorBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(SysIdGeneratorBean.class, SysIdGeneratorBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 163 */       return arrayOfSysIdGeneratorBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 161 */       if (resultset != null) resultset.close();
/* 162 */       if (conn != null)
/* 163 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean[] getBeansFromSql(String sql, Map parameter) throws Exception {
/* 168 */     Connection conn = null;
/* 169 */     ResultSet resultset = null;
/*     */     try {
/* 171 */       conn = ServiceManager.getSession().getConnection();
/* 172 */       resultset = ServiceManager.getDataStore().retrieve(conn, sql, parameter);
/* 173 */       SysIdGeneratorBean[] arrayOfSysIdGeneratorBean = (SysIdGeneratorBean[])(SysIdGeneratorBean[])ServiceManager.getDataStore().crateDtaContainerFromResultSet(SysIdGeneratorBean.class, SysIdGeneratorBean.getObjectTypeStatic(), resultset, null, true);
/*     */ 
/* 180 */       return arrayOfSysIdGeneratorBean;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */     finally
/*     */     {
/* 178 */       if (resultset != null) resultset.close();
/* 179 */       if (conn != null)
/* 180 */         conn.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BigDecimal getNewId() throws Exception {
/* 185 */     return ServiceManager.getIdGenerator().getNewId(SysIdGeneratorBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static Timestamp getSysDate() throws Exception
/*     */   {
/* 190 */     return ServiceManager.getIdGenerator().getSysDate(SysIdGeneratorBean.getObjectTypeStatic());
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean wrap(DataContainerInterface source, Map colMatch, boolean canModify)
/*     */   {
/*     */     try {
/* 196 */       return (SysIdGeneratorBean)DataContainerFactory.wrap(source, SysIdGeneratorBean.class, colMatch, canModify);
/*     */     } catch (Exception e) {
/* 198 */       if (e.getCause() != null) {
/* 199 */         throw new RuntimeException(e.getCause());
/*     */       }
/* 201 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static SysIdGeneratorBean copy(DataContainerInterface source, Map colMatch, boolean canModify) {
/*     */     try {
/* 206 */       SysIdGeneratorBean result = new SysIdGeneratorBean();
/* 207 */       DataContainerFactory.copy(source, result, colMatch);
/* 208 */       return result;
/*     */     }
/*     */     catch (AIException ex) {
/* 211 */       if (ex.getCause() != null) {
/* 212 */         throw new RuntimeException(ex.getCause());
/*     */       }
/* 214 */       throw new RuntimeException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.SysIdGeneratorEngine
 * JD-Core Version:    0.5.4
 */