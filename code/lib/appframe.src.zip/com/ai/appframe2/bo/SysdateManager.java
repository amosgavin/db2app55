/*    */ package com.ai.appframe2.bo;
/*    */ 
/*    */ import java.sql.Date;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class SysdateManager
/*    */ {
/*  7 */   static long m_initial_server = -1L;
/*    */   static long m_initial_local;
/*    */ 
/*    */   /** @deprecated */
/*    */   public static Date getSysDate()
/*    */   {
/* 16 */     return new Date(System.currentTimeMillis());
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public static Timestamp getSysTimestamp()
/*    */   {
/* 25 */     return new Timestamp(System.currentTimeMillis());
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public static long getCurrentTimeMillis()
/*    */   {
/* 34 */     return System.currentTimeMillis();
/*    */   }
/*    */ 
/*    */   /** @deprecated */
/*    */   public static long getCurrentTimeMillisNotInitial()
/*    */   {
/* 44 */     return getCurrentTimeMillis();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.bo.SysdateManager
 * JD-Core Version:    0.5.4
 */