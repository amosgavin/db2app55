/*    */ package com.ai.appframe2.web;
/*    */ 
/*    */ import com.ai.appframe2.common.AIException;
/*    */ import com.ai.appframe2.common.DataContainerInterface;
/*    */ import com.ai.appframe2.common.ObjectType;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class DataContainerList
/*    */   implements Serializable
/*    */ {
/* 11 */   private Object[] list = null;
/* 12 */   private DataContainerInterface[] allList = null;
/* 13 */   private int m_rows = 0;
/* 14 */   private int m_cols = 0;
/*    */ 
/* 16 */   public DataContainerList(Object[] aList, DataContainerInterface[] aAllList) { this.list = aList;
/* 17 */     this.allList = aAllList;
/* 18 */     if (aList != null)
/* 19 */       this.m_cols = aList.length;
/* 20 */     if (this.m_cols > 0)
/* 21 */       this.m_rows = ((DataContainerInterface[])this.list[0]).length; }
/*    */ 
/*    */ 
/*    */   private DataContainerInterface[] getRowDataContainerInterface(int rowIndex)
/*    */   {
/* 26 */     DataContainerInterface[] result = (DataContainerInterface[])null;
/* 27 */     if ((rowIndex >= 0) && (rowIndex < this.m_cols)) {
/* 28 */       result = new DataContainerInterface[this.list.length];
/* 29 */       for (int i = 0; i < this.list.length; ++i)
/* 30 */         result[i] = ((DataContainerInterface[])this.list[i])[rowIndex];
/*    */     } else {
/* 32 */       result = new DataContainerInterface[0];
/* 33 */     }return result;
/*    */   }
/*    */ 
/*    */   public DataContainerInterface getDataContainerInterface(int rowIndex, String aBoName) throws AIException {
/* 37 */     if ((rowIndex < 0) || (rowIndex >= this.m_cols))
/* 38 */       return null;
/* 39 */     for (int i = 0; i < this.m_cols; ++i)
/* 40 */       if (((DataContainerInterface[])this.list[i])[rowIndex].getObjectType().getFullName().equalsIgnoreCase(aBoName))
/* 41 */         return ((DataContainerInterface[])this.list[i])[rowIndex];
/* 42 */     return null;
/*    */   }
/*    */ 
/*    */   public DataContainerInterface[] getColDataContainerInterface(String aBoName)
/*    */     throws AIException
/*    */   {
/* 48 */     if (this.m_rows == 0)
/* 49 */       return null;
/* 50 */     for (int i = 0; i < this.m_cols; ++i) {
/* 51 */       if (((DataContainerInterface[])this.list[i])[0].getObjectType().getFullName().equalsIgnoreCase(aBoName))
/* 52 */         return (DataContainerInterface[])this.list[i];
/*    */     }
/* 54 */     return null;
/*    */   }
/*    */ 
/*    */   public DataContainerInterface[] getColDataContainerInterface(int aBoIndex) {
/* 58 */     DataContainerInterface[] data = (DataContainerInterface[])this.list[aBoIndex];
/* 59 */     String[] name = data[0].getPropertyNames();
/* 60 */     String[] key = data[0].getKeyPropertyNames();
/* 61 */     String[] characterCfg = { "<", ">", "script", "alert", "document", "cookie", "session", "confirm", "prompt" };
/* 62 */     for (int i = 0; i < name.length; ++i) {
/* 63 */       String value = data[0].getAsString(name[i]);
/* 64 */       for (String k : key) {
/* 65 */         if (!k.equals(name[i])) {
/* 66 */           if (value != null) {
/* 67 */             for (int j = 0; j < characterCfg.length; ++j)
/* 68 */               if (value.contains(characterCfg[j])) {
/* 69 */                 value = value.replace(characterCfg[j], "");
/* 70 */                 data[0].set(name[i], value);
/*    */               }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 76 */     return (DataContainerInterface[])this.list[aBoIndex];
/*    */   }
/*    */   public int getBoCount() {
/* 79 */     return this.m_cols;
/*    */   }
/*    */   public int getRowCount() {
/* 82 */     return this.m_rows;
/*    */   }
/*    */ 
/*    */   public DataContainerInterface[] getAllDataContainerInterface()
/*    */   {
/* 87 */     DataContainerInterface[] result = (DataContainerInterface[])null;
/* 88 */     if ((this.allList != null) && (this.allList.length > 0))
/*    */     {
/* 90 */       result = this.allList;
/*    */     }
/* 92 */     return result;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.web.DataContainerList
 * JD-Core Version:    0.5.4
 */