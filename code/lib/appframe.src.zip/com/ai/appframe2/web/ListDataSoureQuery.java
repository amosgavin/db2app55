/*     */ package com.ai.appframe2.web;
/*     */ 
/*     */ import com.ai.appframe2.common.ListDataSourceFactory;
/*     */ import com.ai.appframe2.common.SessionManager;
/*     */ import com.ai.appframe2.complex.center.CenterFactory;
/*     */ import com.ai.appframe2.privilege.UserInfoInterface;
/*     */ import com.ai.appframe2.privilege.UserManager;
/*     */ import com.ai.appframe2.privilege.UserManagerFactory;
/*     */ import com.ai.appframe2.util.StringUtils;
/*     */ import com.ai.appframe2.util.locale.AppframeLocaleFactory;
/*     */ import com.ai.appframe2.web.ListDataSourceXml.ListDataSource;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ListDataSoureQuery extends HttpServlet
/*     */ {
/*  28 */   private static transient Log log = LogFactory.getLog(ListDataSoureQuery.class);
/*     */ 
/*     */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/*  32 */     doPost(request, response);
/*     */   }
/*     */ 
/*     */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
/*     */   {
/*  37 */     SessionManager.setRequest(request);
/*     */     try {
/*  39 */       String userSerialID = (String)request.getSession().getAttribute("USERINFO_ATTR");
/*     */ 
/*  41 */       if ((userSerialID != null) && (userSerialID.trim() != "")) {
/*  42 */         UserInfoInterface user = UserManagerFactory.getUserManager().getLogedUsersBySerialID(userSerialID);
/*     */ 
/*  44 */         SessionManager.setUser(user);
/*     */       }
/*     */     } catch (Exception e) {
/*  47 */       log.error(e.getMessage(), e);
/*     */     }
/*     */ 
/*  50 */     boolean isRoute = false;
/*     */     try
/*     */     {
/*  53 */       String centerType = HttpUtil.getParameter(request, "CenterType");
/*  54 */       String centerValue = HttpUtil.getParameter(request, "CenterValue");
/*     */ 
/*  56 */       if ((centerValue != null) && (!centerValue.trim().equals("")) && (centerType != null) && (!centerType.trim().equals("")))
/*     */       {
/*  58 */         CenterFactory.setCenterInfoByTypeAndValue(centerType, centerValue);
/*  59 */         isRoute = true;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  63 */       log.error(AppframeLocaleFactory.getResource("com.ai.appframe2.web.ListDataSoureQuery.set_center_error"), e);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  68 */       String eventId = request.getParameter("eventid");
/*  69 */       if ("dynamic".equalsIgnoreCase(eventId)) {
/*     */         try {
/*  71 */           queryDynamicListSource(request, response);
/*     */         } catch (Exception ex) {
/*  73 */           log.error(ex.getMessage(), ex);
/*  74 */           throw new IOException(ex.getMessage());
/*     */         }
/*  76 */       } else if ("static".equalsIgnoreCase(eventId)) {
/*     */         try {
/*  78 */           queryStaticListSource(request, response);
/*     */         } catch (Exception ex1) {
/*  80 */           log.error(ex1.getMessage(), ex1);
/*  81 */           throw new IOException(ex1.getMessage());
/*     */         }
/*  83 */       } else if ("html".equalsIgnoreCase(eventId)) {
/*     */         try {
/*  85 */           queryHTMLListSource(request, response);
/*     */         } catch (Exception ex1) {
/*  87 */           log.error(ex1.getMessage(), ex1);
/*  88 */           throw new IOException(ex1.getMessage());
/*     */         }
/*     */       }
/*     */       else {
/*  92 */         String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.web.ListDataSoureQuery.no_match_item", new String[] { "ACTION!" });
/*  93 */         throw new ServletException(msg);
/*     */       }
/*     */     } finally {
/*  96 */       if (isRoute)
/*  97 */         CenterFactory.setCenterInfoEmpty();
/*     */     }
/*  96 */     if (isRoute)
/*  97 */       CenterFactory.setCenterInfoEmpty();
/*     */   }
/*     */ 
/*     */   public void queryHTMLListSource(HttpServletRequest request, HttpServletResponse response)
/*     */     throws Exception
/*     */   {
/* 104 */     String dsId = "";
/* 105 */     HashMap pObj = new HashMap();
/* 106 */     String nullId = "";
/* 107 */     String nullText = "";
/* 108 */     boolean hasNull = false;
/* 109 */     for (Enumeration e = request.getParameterNames(); e.hasMoreElements(); ) {
/* 110 */       String tmpNameStr = (String)e.nextElement();
/* 111 */       String tmpValueStr = new String(request.getParameter(tmpNameStr).getBytes("8859_1"), "GB2312");
/*     */ 
/* 113 */       if (tmpNameStr.equalsIgnoreCase("DSID"))
/* 114 */         dsId = tmpValueStr;
/* 115 */       else if (tmpNameStr.equalsIgnoreCase("hasnull"))
/* 116 */         hasNull = true;
/* 117 */       else if (tmpNameStr.equalsIgnoreCase("nullid"))
/* 118 */         nullId = tmpValueStr;
/* 119 */       else if (tmpNameStr.equalsIgnoreCase("nulltext"))
/* 120 */         nullText = tmpValueStr;
/*     */       else {
/* 122 */         pObj.put(tmpNameStr, tmpValueStr);
/*     */       }
/*     */     }
/*     */ 
/* 126 */     String dynamicData = AppframeLocaleFactory.getResource("com.ai.appframe2.dynamic_data");
/* 127 */     String result = SessionManager.getListSrcFactory().getHTMLOutput(dsId, dsId, dynamicData, pObj, hasNull, nullId, nullText);
/*     */ 
/* 129 */     response.setContentType(HttpUtil.getXmlContentType());
/*     */ 
/* 131 */     response.getWriter().print(result);
/*     */   }
/*     */ 
/*     */   public void queryStaticListSource(HttpServletRequest request, HttpServletResponse response) throws Exception
/*     */   {
/* 136 */     String dsId = "";
/* 137 */     HashMap pObj = new HashMap();
/* 138 */     String nullId = "";
/* 139 */     String nullText = "";
/* 140 */     boolean hasNull = false;
/* 141 */     for (Enumeration e = request.getParameterNames(); e.hasMoreElements(); ) {
/* 142 */       String tmpNameStr = (String)e.nextElement();
/* 143 */       String tmpValueStr = new String(request.getParameter(tmpNameStr).getBytes("8859_1"), "GB2312");
/*     */ 
/* 145 */       if (tmpNameStr.equalsIgnoreCase("DSID"))
/* 146 */         dsId = tmpValueStr;
/* 147 */       else if (tmpNameStr.equalsIgnoreCase("hasnull"))
/* 148 */         hasNull = true;
/* 149 */       else if (tmpNameStr.equalsIgnoreCase("nullid"))
/* 150 */         nullId = tmpValueStr;
/* 151 */       else if (tmpNameStr.equalsIgnoreCase("nulltext"))
/* 152 */         nullText = tmpValueStr;
/*     */       else {
/* 154 */         pObj.put(tmpNameStr, tmpValueStr);
/*     */       }
/*     */     }
/*     */ 
/* 158 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.dynamic_data");
/* 159 */     String result = SessionManager.getListSrcFactory().getStaticOutput(dsId, dsId, msg, pObj, hasNull, nullId, nullText);
/*     */ 
/* 161 */     response.setContentType(HttpUtil.getXmlContentType());
/* 162 */     response.getWriter().print(HttpUtil.getXmlDeclare());
/* 163 */     response.getWriter().print(result);
/*     */   }
/*     */ 
/*     */   public void queryDynamicListSource(HttpServletRequest request, HttpServletResponse response)
/*     */   {
/* 168 */     String reqXml = HttpUtil.getStringFromBufferedReader(request);
/* 169 */     String filterXml = reqXml.replaceAll("!DOCTYPE", "")
/* 170 */       .replaceAll("!ENTITY", "")
/* 171 */       .replaceAll("SYSTEM", "")
/* 172 */       .replaceAll("PUBLIC", "");
/*     */     try {
/* 174 */       Reader reader = new StringReader(filterXml);
/* 175 */       ListDataSource source = ListDataSource.unmarshal(reader);
/* 176 */       String result = HttpUtil.getXmlDeclare();
/* 177 */       result = result + dealListDataSourceQuery(source);
/* 178 */       response.setContentType(HttpUtil.getXmlContentType());
/* 179 */       response.getWriter().print(result);
/*     */     } catch (Exception e) {
/* 181 */       log.error("com.ai.appframe2.web.ListDataSoureQuery.queryDynamicListSource", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String dealListDataSourceQuery(ListDataSource source) throws Exception
/*     */   {
/* 187 */     String result = null;
/* 188 */     HashMap pObj = new HashMap();
/* 189 */     ParameterInterface[] inPList = source.getParameters();
/*     */ 
/* 191 */     for (int i = 0; i < inPList.length; ++i) {
/* 192 */       pObj.put(inPList[i].getName(), inPList[i].getValue());
/*     */     }
/* 194 */     String msg = AppframeLocaleFactory.getResource("com.ai.appframe2.dynamic_data");
/* 195 */     if (source.getID().indexOf("$") != -1) {
/* 196 */       String[] aDateSrcArray = StringUtils.splitString(source.getID(), "$");
/*     */ 
/* 198 */       boolean aNullFlag = false;
/* 199 */       String nullId = "";
/* 200 */       if ((aDateSrcArray.length >= 2) && (aDateSrcArray[1].equalsIgnoreCase("Y")))
/*     */       {
/* 202 */         aNullFlag = true;
/* 203 */         if (aDateSrcArray.length >= 3) {
/* 204 */           nullId = aDateSrcArray[2];
/*     */         }
/*     */       }
/* 207 */       result = SessionManager.getListSrcFactory().getStaticOutput(aDateSrcArray[0], source.getID(), msg, pObj, aNullFlag, nullId, "");
/*     */     }
/*     */     else
/*     */     {
/* 211 */       result = SessionManager.getListSrcFactory().getStaticOutput(source.getID(), source.getID(), msg, pObj, false, "", "");
/*     */     }
/*     */ 
/* 214 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\appframe.jar
 * Qualified Name:     com.ai.appframe2.web.ListDataSoureQuery
 * JD-Core Version:    0.5.4
 */